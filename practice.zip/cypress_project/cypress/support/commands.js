// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
// Cypress.Commands.add('login', (email, password) => { ... })
//
//
// -- This is a child command --
// Cypress.Commands.add('drag', { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add('dismiss', { prevSubject: 'optional'}, (subject, options) => { ... })
//
//
// -- This will overwrite an existing command --
// Cypress.Commands.overwrite('visit', (originalFn, url, options) => { ... })
Cypress.Commands.add("loginapp",(username, password)=>{
    const url = "https://opensource-demo.orangehrmlive.com/auth/login"
    cy.visit(url)
    cy.get("[name='username']").clear().type(username)
    cy.get("[name='password']").clear().type(password)
    cy.get("[type='submit']").click()
})

Cypress.Commands.add("loginWithSession",()=>{
    cy.session([Cypress.env("username"),Cypress.env("password")], ()=>{
        cy.visit('/web/index.php/auth/login')
        cy.get("[name='username']").clear().type(Cypress.env("username"))
         cy.get("[name='password']").clear().type(Cypress.env("password"))
         cy.get("[type='submit']").click()
    })
})

Cypress.Commands.add("loginWithSession_using_api",()=>{
    cy.session([Cypress.env("username"),Cypress.env("password")],()=>{
            const url = "/web/index.php/auth/login"
            cy.visit(url)
            cy.get("[type='hidden']").invoke('attr',"value").as("token")
            cy.get("@token").then((token)=>{
                cy.log(token)
                cy.request({
                        method : 'POST',
                        url : '/web/index.php/auth/validate',
                        form : true,
                        body : {
                            username: Cypress.env("username"),
                            password: Cypress.env("password"),
                            _token: token
                        }
                    }).then(res =>{
                        cy.visit("/web/index.php/dashboard/index")
                        cy.title().should('contain',"OrangeHRM")
                    })
    
            })
    })
    })
