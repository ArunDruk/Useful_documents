
describe("reading_fixture_file", ()=>{
    let data
    before(()=>{
        cy.fixture('example').then((loginData)=>{
            data =loginData
            })
    })
    it("reading fixture file",()=>{
         cy.log(data.email);
         cy.log(data.name);
    
    })

})

