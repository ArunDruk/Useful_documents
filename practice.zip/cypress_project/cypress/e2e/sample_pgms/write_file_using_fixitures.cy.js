
it("writing_file_to_fixture",()=>{
    const data = {
        "name": "Arun Kumar",
        "email": "arun@coforge.com"
      };
    
    cy.writeFile('data.json',data)
})