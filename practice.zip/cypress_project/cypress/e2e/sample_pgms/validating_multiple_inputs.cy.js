describe("validating_multiple_inputs_login",()=>{
    it ("validating_logins",()=>{
        cy.visit("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login")
        cy.fixture("orangehrm.json").then((data)=>{
            data.forEach((element) => {
                // cy.log(element.username)
                // cy.log(element.password)
                cy.get("[name='username']").clear().type(element.username)
            cy.get("[name='password']").clear().type(element.password)
            cy.get("[type='submit']").click()

            if (element.username == "Admin" && element.password == "admin123")
            {
                // cy.title().should('have.text',"OrangeHRM")
                cy.get(".oxd-userdropdown-name").click()
                cy.wait(2000)
                cy.contains("Logout").click()
            }
            else
            {
                cy.xpath("//div[@class = 'oxd-alert-action']/preceding::p").should('have.text',"Invalid credentials")
            }

            });
        })

    })
})