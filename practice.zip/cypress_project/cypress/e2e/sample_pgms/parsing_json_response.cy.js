
describe("validation of Json responses",()=>{

    it("parsing_simple_json_response",()=>{

        cy.request({
            method:'GET',
            url : 'https://fakestoreapi.com/products',
        }).then((response)=>{
            expect(response.status).to.eq(203)
            cy.log(response.body[0].title)
            cy.log(response.body[0].rating.rate)
        })
    })

    it("summing_price_parameter_in_json_response",()=>{
        const arr = []
        let totalprice=0
        cy.request({
            method:'GET',
            url : 'https://fakestoreapi.com/products',
            qs: {limit:5}  // query string to limit the responses received
        }).then((response)=>{
            expect(response.status).to.eq(200)
            // cy.log(JSON.stringify(response.body))
            for (let i=0;i<5;i++)
            {
                if(response.body[i])
                {
                    arr.push(response.body[i].price)
                    totalprice = totalprice + response.body[i].price
                }
                // cy.log(i)
                // response.body[i].price
                // totalprice = totalprice + response?.body[i]?.price
                // arr.push(response?.body[i]?.price)
                // cy.log(response?.body[i]?.price)
            }
            cy.log(totalprice)
            // console.log(arr)    // TThis is not working need to check how to print completely
            // cy.log(Array.isArray(arr))

            // Looping through the response body and taking only the price
            // response.body.forEach(element => {
            //     totalprice=totalprice + element.price
            //     cy.log(totalprice)
            // });
            // expect(totalprice).to.equal(899.23)
    
            // Looping through the Array
            // arr.forEach((ele)=>{
            //     cy.log(ele)
            
        })
    
        // expect(totalprice).to.equal(899.23)
       
        
         })
         
        })

        
    // })
