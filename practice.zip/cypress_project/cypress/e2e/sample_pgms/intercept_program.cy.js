

describe("intercept program",()=>{
    it("validating response from intercept",()=>{

        const url = "https://dummyapi.io/explorer"
        cy.visit(url)
        cy.intercept({
            path : '/data/v1/post/60d21af267d0d8992e610b8d/comment?limit=10'
        }).as('comments')

        cy.get('.flex > :nth-child(5)').should('have.text','Comments List').click()
    cy.wait('@comments').then(intercept =>{
        // expect(intercept.response.body.limit).equal(10)
        let data = JSON.stringify(intercept.response.body)
        cy.log(data)
        //cy.log(intercept.response.body["data"][0]["message"])
        cy.log(intercept.response.body["data"][0].message)

        // cy.log(["data"][0].owner.firstName)
    })
    })

    // Mocking API response is used when the developer has not 
    //implemented API response, but we have to test using fake response
    it.only("mock API response",()=>{

        const url = "https://dummyapi.io/explorer"
        cy.visit(url)
        cy.intercept('GET', '/data/v1/post/60d21af267d0d8992e610b8d/comment?limit=10',
        {limit:10, Name:'Testing Funda'}).as('comments')

        cy.get('.flex > :nth-child(5)').should('have.text','Comments List').click()
    cy.wait('@comments').then(intercept =>{
        // expect(intercept.response.body.limit).equal(10)
        // expect(intercept.response.body.Name).equal('Testing Funda')
        expect(intercept.response.statusCode).to.equal(200)
        cy.log(intercept.response.body)
        cy.log(intercept.response.headers)

    })
    })

    // Using fixtures to provide data to the request
    it("Data driven Mock API using fixtures",()=>{

        const url = "https://dummyapi.io/explorer"
        cy.visit(url)
        cy.intercept('GET', '/data/v1/post/60d21af267d0d8992e610b8d/comment?limit=10',
        {fixture:'example.json'}).as('comments')

        cy.get('.flex > :nth-child(5)').should('have.text','Comments List').click()
    cy.wait('@comments').then(intercept =>{
        expect(intercept.response.body.limit).equal(10)
        expect(intercept.response.body.Name).equal('Testing Funda')
        // expect(intercept.response.status.code).equal(200)
        // cy.log(intercept.response.body)
        // cy.log(intercept.response.headers)

    })
    })

    
})