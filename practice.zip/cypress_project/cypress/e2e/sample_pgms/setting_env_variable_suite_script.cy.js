
describe("setting env variable suite level", 
{
    env:{
       user1 : "honda",
       user2 : "elevate",

    },
},

()=>{
        it("example1",()=>{
            const var1 = Cypress.env("user1")
       const var2 = Cypress.env("user2") 
       cy.log(var1)
       cy.log(Cypress.env("user2"))
        })

        it.only("script level env",
        {
            env:{
                    str2 : "opensource-demo.orangehrmlive.com/"
            },
        },
        
        ()=>{
                let url = `https://${Cypress.env("str2")}web/index.php/auth/login`
                cy.log(url)
                cy.visit(url)

        })
})

