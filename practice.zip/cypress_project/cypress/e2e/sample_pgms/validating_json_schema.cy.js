// Install ajv library
//npm install ajv 

const Ajv = require("ajv")
const ajv_obj = new Ajv()

/* Steps1:
1. Get the Json response and format according to Json response
2. take the Json response and get the schema from transform.tools
3. paste the schema in a fixture folder
4. Now using ajv_obj compile the schema and take the output to a variable
5. To the above variable pass the response body
6. If the output is true then it is response is matching the schema
7. If false response is not matching the schema 

*/

describe("schema validation",()=>{

    it("validating json schema against response",()=>{

        cy.request({
            method : 'GET',
            url : "https://fakestoreapi.com/products",
            qs: {limit:3}
        }).then((response)=>{
            expect(response.status).to.eq(200)
            // cy.log(JSON.stringify(response.body))
            cy.fixture('json_schema.json').then((schema)=>{
                // cy.log(schema.title)
                const validate = ajv_obj.compile(schema) 
                expect(validate(response.body)).to.be.true
            })
            
        })
    })
})