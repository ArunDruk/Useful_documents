

describe("using_login_with_session",()=>{
    beforeEach(()=>{
        cy.loginapp("Admin","admin123")
    })

    let data = ["Pending Self Review","Candidate to Interview"]
    it.only("validate children nodes data",()=>{
        cy.title().should("contain","OrangeHRM")
        cy.get(".orangehrm-todo-list").children().each((ele, index, eleArray)=>{
            cy.log(ele,index, eleArray)
            cy.wrap(ele).children().last().should('contain',data[index])
        })
        
    })

    it("verify local storage",()=>{
        cy.getAllLocalStorage().then(result =>{
            cy.wrap(JSON.stringify(result)).should('contain','https://opensource-demo.orangehrmlive.com')
            .and('contain','core/i18n/messages')
        })
        cy.clearLocalStorage('https://opensource-demo.orangehrmlive.com/')
        cy.getAllLocalStorage().then(result =>{
            cy.wrap(JSON.stringify(result)).should('not.have','https://opensource-demo.orangehrmlive.com')
        })
        cy.clearAllLocalStorage()
        cy.getAllLocalStorage().then(result =>{
            // cy.wrap(JSON.stringify(result)).should('be.empty')
            cy.log(JSON.stringify(result))

    })

})
})
