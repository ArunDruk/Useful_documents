describe("testing_iengage_page",()=>{
    it("login_test",()=>{
        const url = "https://www.techlistic.com/p/selenium-practice-form.html"
        cy.visit(url)
        cy.get("[name='firstname']").click().clear().type("Arun")
        cy.get("[name='lastname']").click().clear().type("Kumar")
        cy.get('#sex-0').click()
        cy.get('#exp-6').click()


    })
})