describe("orangehrm",()=>{
    it("login_test",()=>{
        const url = "/web/index.php/auth/login"
        cy.visit(url)
        cy.fixture("data.json").then(data =>{
            cy.get("[name='username']").clear().type(data.username)
            cy.get("[name='password']").clear().type(data.password)

        })
        cy.get("[type='submit']").click()
        cy.title().should('contain','OrangeHRM')
        let cookie = cy.getAllCookies()
        cy.log(cookie)
        cy.xpath("//span[text()='Leave']").click()
        cy.wait(5000)
        
    })

    it("login_using_custom_command",()=>{
        cy.loginapp("Admin","admin123")
        cy.title().should('contain','OrangeHRM')
        cy.contains("Admin").click()
        cy.contains("Nationalities").click()
        cy.get(".oxd-table-card --mobile").filter(":contains('Austrian')").should('have.length',1)
        
    })

    it.only("login using api",()=>{
        const url = "/web/index.php/auth/login"
        cy.visit(url)
        cy.get("[type='hidden']").invoke('attr',"value").as("token")
        cy.get("@token").then((token)=>{
            cy.log(token)
            cy.request({
                    method : 'POST',
                    url : '/web/index.php/auth/validate',
                    form : true,
                    body : {
                        username: Cypress.env("username"),
                        password: Cypress.env("password"),
                        _token: token
                    }
                }).then(res =>{
                    cy.visit("/web/index.php/dashboard/index")
                    cy.contains("Recruitment").click()
                })

        })
        

    })
})