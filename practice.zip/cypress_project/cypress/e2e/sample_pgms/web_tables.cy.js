describe("Handle tables",()=>{
    beforeEach('Login',()=>{
        const url = "https://demo.opencart.com/admin/index.php"
        cy.visit(url)
        cy.get('#input-username').clear().type("demo")
        cy.get('#input-password').clear().type('demo')
        cy.get("button[type='submit']").click()
        // Customers -> Customer
        cy.get("#menu-customer>a").click() //Customers main menu
        cy.get("#menu-customer>ul>li:first-child").click() //customers sub/child item

    })

    it.only('check number of rows and columns',()=>{
       cy.get("table[class='table table-bordered table-hover']>tbody>tr").should('have.length','10')
       cy.get("table[class='table table-bordered table-hover']>thead>tr>td").should('have.length','6')
       
    })

    it('check cell data from specific row and column',()=>{

    })

})