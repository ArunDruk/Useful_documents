//import cypress from "cypress"
import POData from "../../fixtures/POdata.json"


describe("fetching_values",()=>{
    it("keys and values",()=>{
        const accord = Object.keys(POData.attributes)
        const books = Object.values(POData.attributes)
        cy.log(accord)
        cy.log(books)
        console.log(accord)
        console.log(books)

    })

    it("math function",()=>{
        const random = Math.floor(Math.random()*10)
        cy.log(random)
    })

    it.only("reading_env_config_file",()=>{
        const user = Cypress.env("username") // reading from cypress.env.json
        const pwd = Cypress.env("password")
        const user1 = Cypress.env("user")   // reading from cypress.config.js
        const pwd1 = Cypress.env("pass")
        let val1 = Cypress.env()
        cy.log(user)
        cy.log(pwd)
        cy.log(user1)
        cy.log(pwd1)
        cy.log(val1.user)
    })
})