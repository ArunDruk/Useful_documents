/* different types of alert handling
1. Javascript alert - it will have some text and an "OK" button
2. JS confirm alert - it will have some text with 'OK' and 'Cancel' button
3. JS prompt alert - it will have some text with a text box for user input along with 'OK'
4. authenticated alert 

Cypress will automatically close the alert windows
*/

describe("validating alerts",()=>{
    const url = "https://the-internet.herokuapp.com/javascript_alerts"
    it("JS alert only Ok button",()=>{
        cy.visit(url)
        cy.get("button[onclick='jsAlert()']").should('have.text',"Click for JS Alert").click()

            // to trigger an event to verify text on alert window but the alert window will automatically closed by cypress
        cy.on('window:alert',(t)=>{
            expect(t).to.contains('I am a JS Alert')
        })

        cy.get("#result").should('have.text',"You successfully clicked an alert")

    })

    it("validating confirmation alert Ok and Cancel",()=>{
        cy.visit(url)
        let flag = false
        cy.get("button[onclick='jsConfirm()']").should('have.text',"Click for JS Confirm").click()

        // to fire an event to verify text on alert window 
        // Cypress by default clicks on OK, by returning false it clicks on Cancel
        cy.on('window:confirm',()=>false); 
        cy.get("#result").should('have.text',"You clicked: Cancel")
        // cy.on('window:confirm',(t)=>{
           
        //     expect(t).to.contains('I am a JS Confirm')
        //     return flag
        // })
        // if (flag == false)
        // {
        //     cy.get("#result").should('have.text',"You clicked: Cancel")
        // }
        // else{
        //     cy.get("#result").should('have.text',"You clicked: Ok")
        // }
    })

    it("JS prompt Alert enter some text",()=>{
        cy.visit(url)
        // to enter some text in the box, need to trigger an event
        // clicking OK will be handled automatically by Cypress
        cy.window().then((win)=>{
            cy.stub(win,'prompt').returns('welcome');
        })

        cy.get("button[onclick='jsPrompt()']").should('have.text',"Click for JS Prompt").click()
        // cy.get("#result").should('have.text',"You entered: welcome")

        // cy.on('window:prompt',()=>false); 
       
        // cy.get("#result").should('have.text',"You entered: null")

    })
    it.only("validate Authenticated Alert",()=>{
        // method 1: passing credentials inside auth in cy.visit
        // cy.visit("https://the-internet.herokuapp.com/basic_auth",
        // {auth: {username: "admin", password:"admin"}})
       
        // cy.get("#content").invoke('text').should('include','Congratulations')


        //method 2: passing credentials in URL itself
        cy.visit("https://admin:admin@the-internet.herokuapp.com/basic_auth")
       
        cy.get("#content").invoke('text').should('include','Congratulations')
        
        })
})