describe("handling new tabs",()=>{
    it("handling new window by removing target element",()=>{
        const url = "https://the-internet.herokuapp.com/windows" // parent tab
        cy.visit(url)
        // removing the target attribute in the html page, so it opens in the same window
        cy.get(".example >a").invoke('removeAttr','target').click(); // clicking on link
        cy.url().should('include','/new')

        cy.wait(5000)
        // navigating back to parent tab
        cy.go("back")

    })

    //limitation in this approach, the subdomain /windows/new should have main domain url https://the-internet.herokuapp.com
    it.only("handling new window by altering the url",()=>{
        const url = "https://the-internet.herokuapp.com/windows" // parent tab
        cy.visit(url)
        // getting the href attribute in the html page and opening in the same window
        // cy.get(".example >a").invoke('attr','href').then((newtab)=>{
        //     cy.log(newtab)
        //     const new_url ="https://the-internet.herokuapp.com" + newtab
        //     cy.visit(new_url)
        // }) 

        //extracting href value from the html page
        cy.get(".example >a").then((ele)=>{
            let url1 = ele.prop('href')
            cy.log(url1)
            cy.visit(url1)
        }) 
        
        cy.url().should('include','/new')
        cy.wait(5000)
        // navigating back to parent tab
        cy.go("back")

    })
})