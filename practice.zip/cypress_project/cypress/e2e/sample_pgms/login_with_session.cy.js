describe("using_login_with_session",()=>{

    it.only("tc_001",()=>{
        cy.loginWithSession()
        cy.log("test_001")
    })

    it("tc_002",()=>{
        cy.loginWithSession("Admin","admin123")
        cy.log("test_002")
    })

    it("tc_003",()=>{
        cy.loginWithSession("Admin","admin123")
        cy.log("test_003")
    })

    it("tc_004",()=>{
        cy.loginWithSession("Admin","admin123")
        cy.log("test_004")
    })
})