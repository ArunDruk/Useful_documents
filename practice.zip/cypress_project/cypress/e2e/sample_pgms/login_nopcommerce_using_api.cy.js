describe("login_via_api",()=>{
    it("login using api",()=>{
        const url = "https://admin-demo.nopcommerce.com/"
        cy.visit(url)
        cy.get("[type='hidden']").invoke('attr',"value").as("token")
        cy.get("@token").then((token)=>{
            cy.log(token)
            cy.request({
                    method : 'POST',
                    url : 'https://admin-demo.nopcommerce.com/login?ReturnUrl=%2Fadmin%2F',
                    form : true,
                    body : {
                        username:"admin@yourstore.com", // Cypress.env("username"),
                        password: "admin", //Cypress.env("password"),
                        __RequestVerificationToken: token
                    }
                }).then(res =>{
                    cy.visit("admin/")
                    cy.title().contains("Dashboard / nopCommerce administration")
                })    
})
    })
})