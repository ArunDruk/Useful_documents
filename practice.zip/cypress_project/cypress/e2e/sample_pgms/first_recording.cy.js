describe("first_recording.cy.js", () => {
  it("tests first_recording.cy.js", () => {
    // cy.viewport(708, 516);
    cy.visit("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
    cy.get("form > div:nth-of-type(1) input").click();
    cy.get("form > div:nth-of-type(1) input").type("Admin");
    cy.get("form > div:nth-of-type(2) input").click();
    cy.get("form > div:nth-of-type(2) input").type("admin123");
    cy.get("button").click();
    cy.location("href").should("eq", "https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index");
    cy.get("div.oxd-topbar-header-userarea span").click();
    cy.get("header li:nth-of-type(4) > a").click();
    cy.location("href").should("eq", "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
  });
});
