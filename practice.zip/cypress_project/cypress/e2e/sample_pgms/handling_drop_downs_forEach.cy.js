/// <reference types="Cypress" />

describe("handling different dropdowns",()=>{

// Handling normal dropdowns having Select tag
    it.skip("Dropdown with select tag",()=>{
        const url = "https://www.zoho.com/commerce/free-demo.html"
        cy.visit(url)
        // should("have.value") can be used if we have select tag
        cy.get("#zcf_address_country").select("Haiti").should('have.value','Haiti') 
        
    })

    // Handling bootstrap dropdowns, without Select tag
    it.skip("Dropdown without select tag, span tag",()=>{
        const url = "https://www.dummyticket.com/dummy-ticket-for-visa-application/"
        cy.visit(url)
        // Delivery options
        cy.get("#select2-reasondummy-container").click()
        cy.wait(500)
        cy.get(".select2-search__field").type("Prank a friend").type('{enter}')
        cy.wait(500)
        // cy.get("#select2-reasondummy-container").should('have.text','xPrank a friend')

        //Billing details
        cy.get("#select2-billing_country-container").click()
        cy.wait(500)
        cy.get(".select2-search__field").type("Ivory Coast{enter}")
        cy.get("#select2-billing_country-container").should('have.text','Ivory Coast')
    })

    it("Dropdown with static auto-suggestions",()=>{
        const url = "https://www.wikipedia.org/"
        cy.visit(url)
        cy.get("#searchInput").type("Delhi")
        // take all the suggestions into an array and print those
        cy.get(".suggestion-title").each((ele,index,arr) => {
            cy.log(ele.text())
            
        })
        cy.get(".suggestion-title").contains('Delhi University').click()
    })

    it.only("Dropdown with dynamic auto-suggestions",()=>{
        const url = "https://www.google.com/"
        cy.visit(url)
        // cy.wait(4000)
        // how to click on Stay signed out in chrome
        // cy.get(".QlyBfb").first().find("button[aria-label='Stay signed out']").click()
        // cy.get("input[name='q']").type("cypress automation")
        cy.get("textarea.gLFyf").type("cypress automation")
        cy.wait(2000)
        // take all the suggestions into an array and print those
        cy.get("div.wM6W7d>span").should('have.length',13)

        cy.get("div.wM6W7d>span").each(($ele,index, $list)=>{
            cy.log($ele.text())
            if($ele.text() == "cypress automation tutorial"){
                cy.wrap($ele).click()
            }

        })
        })
})