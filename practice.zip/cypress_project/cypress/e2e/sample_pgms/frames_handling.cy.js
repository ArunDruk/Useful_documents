import 'cypress-iframe'

describe("handling_frames",()=>{
    it("aproach_1",()=>{
        const url ="https://the-internet.herokuapp.com/iframe"
        cy.visit(url)
        // using 0 here, because contains only 1 frame
        const iframe=cy.get('#mce_0_ifr').its('0.contentDocument.body').should('be.visible')
        .then(cy.wrap)

        iframe.clear().type('welcome')
        // To select the text and highlight to Bold characters
        iframe.clear().type("Coding {ctrl+a}")
        cy.get("[aria-label='Bold']").click()

        /* as an custom command
        Cypress.Commands.add('getIframe',(iframe)=>{
           return cy.get(iframe)
            .its('0.contentDocument.body').should('be.visible')
        .then(cy.wrap)  
        })
        */

    })
    it.only("approach_2_using_cypress_iFrame_plugin",()=>{
        const url ="https://the-internet.herokuapp.com/iframe"
        cy.visit(url)
        // loads the iframe
        cy.frameLoaded('#mce_0_ifr')  //load the frame
        cy.iframe('#mce_0_ifr').clear().type("Welcome {ctrl+a}")  // to interact with the frame
        cy.get("[aria-label='Bold']").click()



    })
})