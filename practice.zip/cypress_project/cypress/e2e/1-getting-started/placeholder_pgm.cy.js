describe("placeholder pgms",()=>{
    it("pgm1",()=>{
        const name = "notice_period"
        for (let i=0; i<5; i++){
            let j=4
            cy.log(`${name}{j}`)
        }
    })
})