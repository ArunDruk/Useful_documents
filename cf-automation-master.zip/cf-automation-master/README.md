# cf-automation
Core Financials - Automated E2E Tests
