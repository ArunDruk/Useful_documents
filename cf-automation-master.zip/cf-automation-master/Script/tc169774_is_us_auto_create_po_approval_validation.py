﻿from ebiz import *
import web_utils
import form_utils
import file_system_utils
import ebiz
import dbhelper


class tc169774_is_us_auto_create_po_approval_validation(Ebiz):
  global rowno, val
  rowno = 2
  def login(self):
#    self.login_user="rmaran"
#    super().login()
    pass
  
  def logout(self):
    pass
  
  def goto_url(self,url):
#   super().goto_url(self.testConfig['ebiz']['oci_is_url'])
    pass
  
  
  def action(self,book):
    
    self.op_log_path="C:\\TC_PO"
    app = book.Sheets.item["Invoice"]   
    app1 = book.Sheets.item["Requisition"]
    req = app1.Cells.Item[rowno,15]
    delay(2000)
    dsn = self.testConfig['man_oracle_db']['dsn']
    user_id = self.testConfig['man_oracle_db']['userid']
    pwd = self.testConfig['man_oracle_db']['pwd']
    po_number = dbhelper.query_po_no(dsn,user_id,pwd,VarToStr(req))
    app.Cells.Item[rowno,14] = po_number
    
    dsn = self.testConfig['man_oracle_db']['dsn']
    user_id = self.testConfig['man_oracle_db']['userid']
    pwd = self.testConfig['man_oracle_db']['pwd']
    approval_status = dbhelper.po_approval_status(dsn,user_id,pwd,VarToStr(po_number))
    web_utils.log_checkpoint("PO Approval Validated Successfully",500,'')
    
#    self.wait_until_page_loaded()    
#    web_utils.log_checkpoint("Login to Oracle Applications Successful",500,self.page) 
#    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='menuContent']//div[contains(text(),'PO Supervisor')]")         
#    self.wait_until_page_loaded()  
#    
#    self.page.Find("contentText","Buyer Work Center",30).Click()  
#    web_utils.log_checkpoint("Click 'Buyer Work Center' - Successful",500,self.page)       
#    self.wait_until_page_loaded()  
#    self.page.Keys("[Down]")
#    self.page.Keys("[Down]")
#    
#    self.page.NativeWebObject.Find("contentText","Orders","A").Click()
#    web_utils.log_checkpoint("Click 'Orders' Successful",500,self.page) 
#    self.wait_until_page_loaded()
#    
#     
##    self.page.EvaluateXPath("//div[@class='x6p']//button[@class='x80']")[0].Click() 
#    self.page.EvaluateXPath("//button[@title='Search']")[0].Click()
#    web_utils.log_checkpoint("On Order Headers Page : Click 'Search' button - Successful",500,self.page)
#    self.wait_until_page_loaded()
#    Delay(5000)
#    
#    search = web_utils.clk_link_by_xpath(self.page,"//table[@id = 'AdvSearchHeading']//span[@id = 'Value_0__xc_1']//input[@title = 'Search Value: Order']")
#    Delay(1000)
#    self.page.Keys(po_number)
#    web_utils.log_checkpoint("In Search Criteria : PO Number entered successfully",500,self.page)
#    Delay(2000)
#    self.page.Keys("[Tab]")
#    Delay(2000)
#    web_utils.clk_link_by_xpath(self.page,"//table[@id = 'AdvSearchHeading']//td//button[@title = 'Go']")
#    self.wait_until_page_loaded()
#    Delay(2000)
#    orderStatus = self.page.Find("idStr","HeaderResultsTable:StatusNoLink:0",30)
#    if orderStatus.contentText == 'Approved':
#      web_utils.log_checkpoint("Purchase Order "+VarToStr(po_number)+" Status Validated and it is 'Approved'",500,self.page)
#    elif orderStatus.contentText == 'Requires Reapproval' or orderStatus.contentText == 'Incomplete':
#      delay(1200)
#      if orderStatus.contentText == 'Incomplete':
#        web_utils.log_checkpoint("Purchase Order "+VarToStr(po_number)+" is in status 'Incomplete': Re-Submitting for approval",500,self.page)
#      actionDropdown = self.page.EvaluateXpath("//table[@id = 'AdvSearchHeading']//div[@id='HeaderResultsTable:ControlBar']//tr//select[@id='ActionsPoplist']")[0]
#      actionDropdown.ClickItem("Update")
#      Delay(2300)
#      web_utils.clk_link_by_xpath(self.page,"//table[@id = 'AdvSearchHeading']//div[@id='HeaderResultsTable:ControlBar']//button[@title='Go']")
#      self.wait_until_page_loaded()
#      pro = ("ObjectType","contentText") 
#      val = ("TextNode","Update Standard Purchase Order *")
#      apprPage = self.page.Find(pro,val,30)
#      self.verify_aqobject_chkproperty(apprPage,"contentText",cmpContains,"Update Standard Purchase Order "+VarToStr(po_number))
#      Delay(2000)
#      web_utils.clk_link_by_xpath(self.page,"//table[@id = 'PageActionButtonsRN']//button[@id='SubmitButton']")
#      self.wait_until_page_loaded()
#      confirmMessage = self.page.EvaluateXpath("//table[@id ='FwkErrorBeanId']//td//h1")
#      
#      if confirmMessage[0].contentText == "Confirmation":
#        web_utils.log_checkpoint("Purchase Order : "+VarToStr(po_number)+" submitted for Approval",500,self.page)
#        orderStatus == 'In Process'
#        while orderStatus != 'Approved':
#         web_utils.clk_link_by_xpath(self.page,"//table[@id = 'AdvSearchHeading']//td//button[@title = 'Go']")
#         self.wait_until_page_loaded()
#         Delay(2000)
#         orderStatus = self.page.Find("idStr","HeaderResultsTable:Status:0",30).contentText
#        web_utils.log_checkpoint("Purchase Order " +VarToStr(po_number)+" Status Validated and it is 'Approved'",500,self.page)
#      else:
#        web_utils.log_checkpoint("Unable to Submit PO :"+VarToStr(po_number)+" for Approval",500,self.page)
#
#
#    Delay(2000)      
#    self.page.EvaluateXpath("//table[@id = 'globalHeaderID']//a/div/img[@title = 'Home']")[0].Click()
#    self.wait_until_page_loaded()
#    

