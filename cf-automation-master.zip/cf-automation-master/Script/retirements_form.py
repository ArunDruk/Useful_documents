﻿import gvar

def retirements_window():
  prop_names = ["AWTComponentAccessibleName","JavaClassName"]
  prop_values = ["Retirements","ExtendedFrame"]
  return gvar.dataprep['jformobject'].FindChildEx(prop_names,prop_values,30,True,5000)

def retire_date_textfield(rtr_wdw):
  return rtr_wdw.FindChildEx("AWTComponentAccessibleName","Retire Date Required",20,True,1000)

def status_textfield(rtr_wdw):
  return rtr_wdw.FindChildEx("AWTComponentAccessibleName","Status Required",20,True,1000)
  
def current_cost_textfield(rtr_wdw):
  return rtr_wdw.FindChildEx("AWTComponentAccessibleName","Current Cost",20,True,1000)
  
def cost_retired_textfield(rtr_wdw):
  return rtr_wdw.FindChildEx("AWTComponentAccessibleName","Cost Retired Required",20,True,1000)
  
def proceeds_of_sale_textfield(rtr_wdw):
  return rtr_wdw.FindChildEx("AWTComponentAccessibleName","Proceeds of Sale",20,True,1000)
  
def gain_loss_amount_textfield(rtr_wdw):
  return rtr_wdw.FindChildEx("AWTComponentAccessibleName","Gain/Loss Amount",20,True,1000)
