﻿import gvar 

def submit_request_extended_frame():
  return gvar.dataprep['jformobject'].Find('AWTComponentAccessibleName','Submit Request',5000)
  
def request_name_textfield():
  return gvar.dataprep['jformobject'].Find('AWTComponentAccessibleName','Request Set RequiredList of Values',5000)
  
def submit_button():
  return gvar.dataprep['jformobject'].Find('AWTComponentAccessibleName','Submit',5000)
  
def cancel_button():
  return gvar.dataprep['jformobject'].Find('AWTComponentAccessibleName','Cancel alt n',5000)
  
def delivery_opts_button():
  return gvar.dataprep['jformobject'].Find('AWTComponentAccessibleName','Delivery Opts alt y',5000)

def ok_button():
  return gvar.dataprep['jformobject'].Find('AWTComponentAccessibleName','OK alt O',1000)
 
def parameters_1_textfield():
   properties = ['AWTComponentAccessibleName','AWTComponentIndex']
   values     = ['Parameters','15']
   return gvar.dataprep['jformobject'].Find(properties,values,60)
   
def parameters_2_textfield():
   properties = ['AWTComponentAccessibleName','AWTComponentIndex']
   values     = ['Parameters','16']
   return gvar.dataprep['jformobject'].Find(properties,values,60)

def parameters_3_textfield():
   properties = ['AWTComponentAccessibleName','AWTComponentIndex']
   values     = ['Parameters','17']
   return gvar.dataprep['jformobject'].Find(properties,values,60)

def submit_request_set():
  prop_names = ["AWTComponentAccessibleName","JavaClassName"]
  prop_values = ["Submit Request Set","ExtendedFrame"]
  return gvar.dataprep['jformobject'].FindChildEx(prop_names,prop_values,20,True,5000)
  
def request_set_textfield(request_set_wdw):
  return request_set_wdw.FindChildEx("AWTComponentAccessibleName","Request Set RequiredList of Values",20,True,5000)
  
def program_textfield(request_set_wdw,index):
  prop_names = ["AWTComponentAccessibleName","AWTComponentIndex"]
  prop_values = ["Program",index]
  return request_set_wdw.FindChildEx(prop_names,prop_values,20,True,5000)
  
def parameters_textfield(request_set_wdw,index):
  prop_names = ["AWTComponentAccessibleName","AWTComponentIndex"]
  prop_values = ["Parameters",index]
  return request_set_wdw.FindChildEx(prop_names,prop_values,20,True,5000)
  
  
####### Paramaters DFF ##############3

def parameters_dff():
  prop_names = ["AWTComponentAccessibleName","JavaClassName"]
  prop_values = ["Parameters","FlexWindow"]
  return gvar.dataprep['jformobject'].FindChildEx(prop_names,prop_values,20,True,5000)
  
def file_path_textfield(param_window):
  prop_names = ["AWTComponentAccessibleName","JavaClassName"]
  prop_values = ["File Path REQUIRED","FlexTextField"]
  return param_window.FindChildEx(prop_names,prop_values,20,True,5000)
  
def transaction_source_textfield():
  properties = ['AWTComponentAccessibleName','AWTComponentIndex','JavaClassName']
  values = ["Transaction Source REQUIRED List Values",0,"FlexTextField*"]
  return gvar.dataprep['jformobject'].Find(properties,values,60)
  
def default_date_textfield():
  properties = ['AWTComponentAccessibleName','AWTComponentIndex','JavaClassName']
  values = ["Default Date REQUIRED",0,"FlexTextField*"]
  return gvar.dataprep['jformobject'].Find(properties,values,60)
  
def inv_src_textfield():
   properties = ['AWTComponentAccessibleName','AWTComponentIndex','JavaClassName']
   values     = ["Invoice Source REQUIRED List Values",0,"FlexTextField*"]
   return gvar.dataprep['jformobject'].Find(properties,values,60)
   
def low_btc_num_textfield():
   properties = ['AWTComponentAccessibleName','AWTComponentIndex','JavaClassName']
   values     = ["(Low) Bill To Customer Number List Values",0,"FlexTextField*"]
   return gvar.dataprep['jformobject'].Find(properties,values,60)
   
def high_btc_num_textfield():
   properties = ['AWTComponentAccessibleName','AWTComponentIndex','JavaClassName']
   values     = ["(High) Bill To Customer Number List Values",0,"FlexTextField*"]
   return gvar.dataprep['jformobject'].Find(properties,values,60)
   
def email_text_field():
   properties = ['AWTComponentAccessibleName','AWTComponentIndex','JavaClassName']
   values     = ["Email ID REQUIRED",0,"FlexTextField*"]
   return gvar.dataprep['jformobject'].Find(properties,values,60)

def operating_unit_textfield():
   properties = ['AWTComponentAccessibleName','AWTComponentIndex','JavaClassName']
   values     = ["Operating Unit List Values",0,"FlexTextField*"]
   return gvar.dataprep['jformobject'].Find(properties,values,60)

def score_engine1_textfield():
   properties = ['AWTComponentAccessibleName','AWTComponentIndex','JavaClassName']
   values     = ["Score Engine 1 List Values",0,"FlexTextField*"]
   return gvar.dataprep['jformobject'].Find(properties,values,60)

def score_engine2_textfield():
   properties = ['AWTComponentAccessibleName','AWTComponentIndex','JavaClassName']
   values     = ["Score Engine 2 List Values",0,"FlexTextField*"]
   return gvar.dataprep['jformobject'].Find(properties,values,60)
  
def score_engine3_textfield():
   properties = ['AWTComponentAccessibleName','AWTComponentIndex','JavaClassName']
   values     = ["Score Engine 3 List Values",0,"FlexTextField*"]
   return gvar.dataprep['jformobject'].Find(properties,values,60)
  
def max_number_records_textfield():
   properties = ['AWTComponentAccessibleName','AWTComponentIndex','JavaClassName']
   values     = ["Maximum Number of Records: 1000",0,"FlexTextField*"]
   return gvar.dataprep['jformobject'].Find(properties,values,60)
  

  
  
  
