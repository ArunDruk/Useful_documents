﻿import gvar
from dbhelper import *
from ebiz import *
import web_utils
from wci_supplier_maintenance_queue import *
import re

class WCC_Supplier_Maintenance_Queue_V12(wci_supplier_maintenance_queue):


 def action(self,book):   
 
  rowno = 2
  app = book.Sheets.item["Invoice"]     

#Validate login: 

#  welcome_msg=self.page.FindChildEx("contentText","SupplierMaintenance - 1…",30,True,40000) 
  Login_form=Sys.Browser("iexplore").Page("https://core*.epfinnp.coxautoinc.com/imaging/faces/AxfFacade*")
  welcome_msg=Login_form.FindChild("contentText","SupplierMaintenance*",40)
  count =  0  
  while not welcome_msg.Exists:
    Delay(2000)
    welcome_msg=self.page.Find("contentText","SupplierMaintenance*",30) 
    count = count + 1 
    if count == 10:
      self.log_error_message("Unable to Login to Supplier Maintenance Queue Application")    
  web_utils.log_checkpoint("Logged in to Supplier Maintenance Queue Application Successfully",500,self.page) 
  self.page.wait_until_loaded()
  supp_queue_form = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/imaging/faces/AxfFacade*")
  delay(2000)
 # profile =  Sys.Browser("iexplore").Page("https://core*.epfinnp.coxautoinc.com/imaging/faces/AxfFacade*").Frame("contentFrame").Panel("doc1").Form("mnFrm").Panel(0).Panel("s").Panel(0).Panel("f").Panel(0).Panel("c").Panel("conTabs").Panel("tabb").Panel("tabbc").Panel("body").Panel(0).Panel(0).Panel(0).Panel("c").Panel("dhjdf").Panel("c").Panel("outTL").Panel("c").Panel(0).Panel("otrWpr").Panel("t").Panel("tbx").Panel(0).Table(0).Cell(0, 1).Panel(0).Panel(0).Panel("oc").Table(0).Cell(0, 1).Table("vPick").Cell(0, 1).Select("content")
  profile =  Sys.Browser("iexplore").Page("https://core*.epfinnp.coxautoinc.com/imaging/faces/AxfFacade*").Frame("contentFrame1").Panel("doc1").Form("mnFrm").Panel(0).Panel("s").Panel(0).Panel("f").Panel(0).Panel("c").Panel("conTabs").Panel("tabb").Panel("tabbc").Panel("body").Panel(0).Panel(0).Panel(0).Panel("c").Panel("dhjdf").Panel("c").Panel("outTL").Panel("c").Panel(0).Panel("otrWpr").Panel("t").Panel("tbx").Panel(0).Table(0).Cell(0, 1).Panel(0).Panel(0).Panel("oc").Table(0).Cell(0, 1).Table("vPick").Cell(0, 1).Select("content")
  profile.click()
  profile.ClickItem("CAI-SupplierMaintenance")
  self.page.wait_until_loaded()
  delay(6000)
  web_utils.log_checkpoint("Selected 'CAI-SupplierMaintenance' from the Profile dropdown",500,self.page)
  
  view_task = supp_queue_form.FindChild("contentText","View Task",40)
  if view_task.Exists:
    Sys.HighlightObject(view_task)
    web_utils.log_checkpoint("Tasks exists in 'CAI-SupplierMaintenance' Queue",500,self.page)
  else:
    self.log_error_message("No Tasks exists in 'CAI-SupplierMaintenance'")
  
# Searching the tasks
  search_task = supp_queue_form.FindChild("idStr","axfTpl:pt_rgn0:0:pc1:it1::content",40)
  Sys.HighlightObject(search_task)
  search_task.Click()
  delay(4000)
  search_task.Keys(app.Cells.Item[rowno,13])
  delay(4000)
  search_button = supp_queue_form.FindChild("idStr","axfTpl:pt_rgn0:0:pc1:task_search::icon",40)
  search_button.Click()
  delay(8000)

  
  view_task_link = supp_queue_form.FindChild("idStr","axfTpl:pt_rgn0:0:pc1:t1:*:vLink::text",40)
  if view_task_link.Exists:
    Sys.HighlightObject(view_task_link)
    web_utils.log_checkpoint("Task for "+aqConvert.VarToStr(app.Cells.Item[rowno,13])+" exists in 'CAI-SupplierMaintenance' Queue",500,self.page)
  else:
    self.log_error_message("No Tasks exists for " +aqConvert.VarToStr(app.Cells.Item[rowno,13]))


#Working on Tasks
  web_utils.log_checkpoint("Click on 'View Task' next",500,self.page)
  view_task_link.Click()
  delay(20000)
  self.page.wait_until_loaded()
  
# Viewing the image
  count = 0
  #while not Sys.Browser("iexplore").Page("https://core*.epfinnp.coxautoinc.com/imaging/faces/AxfFacade*").Frame("contentFrame").Panel("doc1").Form("mnFrm").Panel(0).Panel("s").Panel(0).Panel("f").Panel(0).Panel("c").Panel("conTabs").Panel("tabb").Panel("tabbc").Panel("body").Panel(0).Panel(0).Panel(0).Panel("c").Panel(0).Panel("s").Panel(0).Panel("f").Panel("dhjdf").Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("c").Panel("panelSplitterTopAndBottom").Panel("f").Panel("panelSplitterTopLeftAndRight").Panel("s").Panel("boxWrap").Panel("c").Panel(0).Panel("panelStretchLayoutApplet").Panel(0).Panel(0).Panel("c").Object("oraImgVwr").AWTObject("PluginEmbeddedFrame", "").SwingObject("Viewer", "", 0).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("ImageView", "", 0).SwingObject("JViewport", "", 0).Exists:
  while not Sys.Browser("iexplore").Page("https://core*.epfinnp.coxautoinc.com/imaging/faces/AxfFacade*").Frame("contentFrame1").Panel("doc1").Form("mnFrm").Panel(0).Panel("s").Panel(0).Panel("f").Panel(0).Panel("c").Panel("conTabs").Panel("tabb").Panel("tabbc").Panel("body").Panel(0).Panel(0).Panel(0).Panel("c").Panel(0).Panel("s").Panel(0).Panel("f").Panel("dhjdf").Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("c").Panel("panelSplitterTopAndBottom").Panel("f").Panel("panelSplitterTopLeftAndRight").Panel("s").Panel("boxWrap").Panel("c").Panel(0).Panel("panelStretchLayoutApplet").Panel(0).Panel(0).Panel("c").Object("oraImgVwr").AWTObject("PluginEmbeddedFrame", "").SwingObject("Viewer", "", 0).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("ImageView", "", 0).SwingObject("JViewport", "", 0).Exists:
    delay(5000) 
    if count == 5:
      self.log_error_message("Unable to retrieve the Invoice Image")  
    count=count+1
  #image_view = Sys.Browser("iexplore").Page("https://core*.epfinnp.coxautoinc.com/imaging/faces/AxfFacade*").Frame("contentFrame").Panel("doc1").Form("mnFrm").Panel(0).Panel("s").Panel(0).Panel("f").Panel(0).Panel("c").Panel("conTabs").Panel("tabb").Panel("tabbc").Panel("body").Panel(0).Panel(0).Panel(0).Panel("c").Panel(0).Panel("s").Panel(0).Panel("f").Panel("dhjdf").Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("c").Panel("panelSplitterTopAndBottom").Panel("f").Panel("panelSplitterTopLeftAndRight").Panel("s").Panel("boxWrap").Panel("c").Panel(0).Panel("panelStretchLayoutApplet").Panel(0).Panel(0).Panel("c").Object("oraImgVwr").AWTObject("PluginEmbeddedFrame", "").SwingObject("Viewer", "", 0).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("ImageView", "", 0).SwingObject("JViewport", "", 0)
  image_view =Sys.Browser("iexplore").Page("https://core*.epfinnp.coxautoinc.com/imaging/faces/AxfFacade*").Frame("contentFrame1").Panel("doc1").Form("mnFrm").Panel(0).Panel("s").Panel(0).Panel("f").Panel(0).Panel("c").Panel("conTabs").Panel("tabb").Panel("tabbc").Panel("body").Panel(0).Panel(0).Panel(0).Panel("c").Panel(0).Panel("s").Panel(0).Panel("f").Panel("dhjdf").Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("c").Panel("panelSplitterTopAndBottom").Panel("f").Panel("panelSplitterTopLeftAndRight").Panel("s").Panel("boxWrap").Panel("c").Panel(0).Panel("panelStretchLayoutApplet").Panel(0).Panel(0).Panel("c").Object("oraImgVwr").AWTObject("PluginEmbeddedFrame", "").SwingObject("Viewer", "", 0).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("ImageView", "", 0).SwingObject("JViewport", "", 0)
  Sys.HighlightObject(image_view)
  web_utils.log_checkpoint("Invoice Image exists for "+aqConvert.VarToStr(app.Cells.Item[rowno,13]),500,self.page)
  

#Complete the invoice
  web_utils.log_checkpoint("Complete the Task next",500,self.page)
  complete_link = supp_queue_form.FindChild("contentText","Complete",40)
  complete_link.Click()
  delay(5000) 
  self.page.wait_until_loaded()
  
# Validating the completion process

  if view_task_link.Exists:
    self.log_error_message("Tasks exists for "+aqConvert.VarToStr(app.Cells.Item[rowno,13]))
  else:
    web_utils.log_checkpoint("Task completed successfully for "+aqConvert.VarToStr(app.Cells.Item[rowno,13]),500,self.page)

  
  


