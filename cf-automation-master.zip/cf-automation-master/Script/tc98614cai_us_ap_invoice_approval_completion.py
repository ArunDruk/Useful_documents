﻿from ebiz import *
#Author:            Prabhakaran Rajendran
#TestCaseID:        TC21502
#UserStoryID:       US126644
#Reviewed_By:       Syed,Husain && Seelam,Lakshmi



class tc98614cai_us_ap_invoice_approval_completion(Ebiz):
  #declare variables to be used in the methods
  global v, val, val1, app, book, rowno

  def login(self):
    self.login_user="amalappan"
    super().login()
  #action method to call all sub functions(methods)
  def action(self,book):
    
      rowno=2 
      app = book.Sheets.item["Invoice"]
      RowCount = app.UsedRange.Rows.Count      
      while rowno<(RowCount+1):
        val =VarToString(app.cells.Item[rowno,17])
        val1 = val+"%"
        if rowno == 2:
          self.nav_appr()
        self.key_data(val1)
        self.appr_req(app,rowno)
        self.key_data(val1)
        self.apprv_val()
#        val = aqConvert.StrToInt(val)+1
        rowno = rowno+1
        delay(1000)
        self.page.EvaluateXpath("//table[@id='AdvancedSearchRegion']//button[@id='ClearButton']")[0].Click()
      self.wait_until_page_loaded()  
#      self.page.EvaluateXPath("//a[text()='Home']")[0].Click()  
      self.page.EvaluateXpath("//table[@id = 'globalHeaderID']//a/div/img[@title = 'Home']")[0].Click()
      self.wait_until_page_loaded()
      book.save()  
      del app,RowCount,val,val1   
#      delay(1000)
#      book.close() 
  
  #method to navigate to 'Status Monitor' to pick requisition pending for approval
  def nav_appr(self):  
      self.wait_until_page_loaded()      
      self.page.Find("contentText","Workflow Administrator Web Applications",30).Click()
      self.wait_until_page_loaded()
      self.page.Find("contentText","Administrator Workflow",30).Click()
      self.wait_until_page_loaded()
      self.page.Keys("[Down]")
      delay(2000)
      web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Status Monitor')]")
#      self.page.EvaluateXPath("//table[@id='respList']//li/a[contains(text(),'Status Monitor')]")[0].Click()
      self.wait_until_page_loaded()
      
  #method to query for specific requistion for approval        
  def key_data(self,val1):
      self.wait_until_page_loaded()
      obj=self.page.EvaluateXpath("//table[@id='AdvancedSearchRegion']//input[@id='WfItemTypeName2']")[0]
      if obj.Exists:
        self.log_checkpoint_message_web("Workflow Status Monitor Page Launched Successfully")
      else:
        self.log_message_web("Unable to Launch Workflow Approval Form")
      
      self.page.EvaluateXpath("//table[@id='AdvancedSearchRegion']//input[@id='WfItemTypeName2']")[0].Click()
      delay(1000)
      self.page.EvaluateXpath("//table[@id='AdvancedSearchRegion']//input[@id='WfItemTypeName2']")[0].Keys("APINV")
      delay(2000)
      self.page.EvaluateXpath("//table[@id='AdvancedSearchRegion']//input[@id='WfProcessItemKey']")[0].SetText(val1)
      delay(2000)
      self.page.EvaluateXpath("//table[@id='AdvancedSearchRegion']//select[@id='WfProcessStartList']")[0].Click()
      self.wait_until_page_loaded()
      delay(1000)
      self.page.EvaluateXpath("//table[@id='AdvancedSearchRegion']//select[@id='WfProcessStartList']")[0].ClickItem("Last 2 Weeks")
      delay(3000)
      self.page.EvaluateXpath("//table[@id='AdvancedSearchRegion']//button[@id='GoButton']")[0].HoverMouse()
      delay(1000)
      self.page.EvaluateXpath("//table[@id='AdvancedSearchRegion']//button[@id='GoButton']")[0].Click()
      self.wait_until_page_loaded()      
  
  #method to open the workflow activity and to approve the requisition        
  def appr_req(self,app,rowno):
#      self.page.Find("idStr","WfMonActivitiesCtrl",30).Click()
      self.page.EvaluateXPath("//div[@id='ResultsTable:ControlBar']//button[@id='WfMonActivitiesCtrl']")[0].Click()
      delay(1000)
      self.log_message_web("Reviewing Activity status of the Requisition Workflow")
      self.wait_until_page_loaded()      
      P_names = ["contentText","idStr"]
      P_values = ["open","N*:NoticeActivity:0"]
      if self.page.Find(P_names,P_values,30).Exists:
        self.page.Find(P_names,P_values,30).Click()
        delay(2000)
        self.wait_until_page_loaded()
        self.log_message_web("Ready for Approval")
        self.page.EvaluateXpath("//table[@id='pgBtnBarTbl']//button[@title='Approve']")[0].Click()
        delay(2000)
        self.wait_until_page_loaded()
        inv = VarToString(app.cells.Item[rowno,13])
        self.log_message_web("Approved Invoice"+inv)
        delay(2000)
        self.page.EvaluateXpath("//form[@id='DefaultFormName']//a[@id='WF_STATUS_MONITOR']")[0].Click()
        delay(2000)
        self.wait_until_page_loaded()
      self.page.EvaluateXpath("//form[@id='DefaultFormName']//a[@id='WF_STATUS_MONITOR']")[0].Click()
      self.wait_until_page_loaded()  
      
  def apprv_val(self):    
      var1 = 'Active'
      while var1 != 'Complete':
        self.log_message_web("AP Invoice Approval Workflow in Progress")
        delay(6000)
        self.page.EvaluateXpath("//table[@id='AdvancedSearchRegion']//button[@id='GoButton']")[0].Click()
        delay(2000)
        var1 = self.page.EvaluateXpath("//table[@id='ResultsRegion']//span[@id='N19:WfStatusNoterrText:0']")[0].contentText
      self.log_message_web("Invoice Approval Validated Successfully")

def sample():
  Sys.Browser("iexplore").Page("*").EvaluateXPath("//div[@id='ResultsTable:ControlBar']//button[@id='WfMonActivitiesCtrl']")[0].Click()