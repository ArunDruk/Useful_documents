﻿import gvar

### In this method objects for below pages have been captured ###

#REPORTING > PERFOMANCE PAGE


def reporting_performance_page_link():
  prop_names = ["contentText","idStr","ObjectType"]
  prop_values = ["Performance","PJI_VIEW_PROJ_PERF","Link"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def show_details_parameters_link():
  show_details_parameters = gvar.dataprep['page'].NativeWebObject.Find("contentText","Show Details and Parameters","A")
  return show_details_parameters


def currency_code_dropdown():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["CurrencyRecordType","Select"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
  

def calender_type_dropdown():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["CalendarType","Select"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
  

def cost_budget_type_dropdown():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["BudgetCostPlanTypeID","Select"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def cost_forecast_type_dropdown():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["ForecastCostPlanTypeID","Select"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def cost_budget_type2_dropdown():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["Budget2CostPlanTypeID","Select"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
  

def effective_uom_dropdown():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["EffortUnitOfMeasure","Select"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
  

def factor_by_dropdown():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["FactorBy","Select"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def revenue_budget_type_dropdown():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["BudgetRevenuePlanTypeID","Select"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def revenue_forecast_type_dropdown():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["ForecastRevenuePlanTypeID","Select"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def revenue_forecast_type2_dropdown():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["Budget2RevenuePlanTypeID","Select"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def cost_export_button():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["OverviewTableRN_oracle_apps_pji_projperf_reporting_webui_OverviewRowRN_devSeed2:_oracle_apps_pji_projperf_reporting_webui_OverviewRowRN_devSeed2:0","Button"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
  

def effort_export_button():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["OverviewTableRN_oracle_apps_pji_projperf_reporting_webui_OverviewRowRN_devSeed6:_oracle_apps_pji_projperf_reporting_webui_OverviewRowRN_devSeed6:0","Button"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
  

def capital_cost_export_button():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["OverviewTableRN_oracle_apps_pji_projperf_reporting_webui_OverviewRowRN_devSeed9:_oracle_apps_pji_projperf_reporting_webui_OverviewRowRN_devSeed9:0","Button"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def earned_value_export_button():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["OverviewTableRN_oracle_apps_pji_projperf_reporting_webui_OverviewRowRN_devSeed5:_oracle_apps_pji_projperf_reporting_webui_OverviewRowRN_devSeed5:0","Button"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def hide_details_parameters_link():
  hide_details_parameters = gvar.dataprep['page'].NativeWebObject.Find("contentText","Hide Details and Parameters","A")
  return hide_details_parameters


def show_status_indicator_keys_link():
  show_status_indicator = gvar.dataprep['page'].NativeWebObject.Find("contentText","Show Status Indicator Keys","A")
  return show_status_indicator


def task_summary_dropdown():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["gotoSummaryList","Select"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def go_button():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["summaryPageGOButton","Button"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

