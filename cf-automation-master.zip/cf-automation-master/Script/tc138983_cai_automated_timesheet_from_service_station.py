﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils
import winscp_utility


###This testcase is to place the CAIAUTOSUB_US_LABOR_TEST.txt file in the PA inbound directory using WINSCP### 
###and submit CAI PA Automated Time Interface Request Set and capture Output and validate Employee Time record in CAI EBIZ###

class tc138983_cai_automated_timesheet_from_service_station(Ebiz):

 op_log_path="C:\\TC_Logs"
 empl_time_files="C:\\EMPL_TIME_Files"

 def login(self):
    self.login_user="rmaran"
    super().login()

 def action(self,book):
    global jrnl_imp_pro 
    self.modify_empl_time_file_details()
    self.place_empl_time_file_winscp()
    
### Modifying CAIAUTOSUB_US_LABOR_TEST.txt file 
 def modify_empl_time_file_details(self):
#    file_name= Project.Path+"DataSheets\\Oracle-PA-Other\\CAIAUTOSUB_US_LABOR_TEST.txt"
    file_name= "C:\\EMPL_TIME_Files\\CAIAUTOSUB_US_LABOR_TEST.txt"
    file_system_utils.create_folder(self.empl_time_files)
    file_exist=aqFileSystem.FindFiles("C:\\EMPL_TIME_Files","CAIAUTOSUB_US_LABOR_TEST.txt")    
    if file_exist != None:
     aqFileSystem.DeleteFile("C:\\EMPL_TIME_Files\\CAIAUTOSUB_US_LABOR_TEST.txt")
    aqFileSystem.CopyFile(Project.Path+"DataSheets\\Oracle-PA-Other\\CAIAUTOSUB_US_LABOR_TEST.txt", "C:\\EMPL_TIME_Files\\CAIAUTOSUB_US_LABOR_TEST.txt")    
    week_end_date = aqConvert.DateTimeToFormatStr(aqDateTime.AddDays(aqDateTime.Today(), -aqDateTime.GetDayOfWeek(aqDateTime.Today())+7),"%m/%d/%Y")
    work_date = aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%m/%d/%Y")
    uniq_ref = aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%m%d%Y")
    fo=open(file_name,"r+")
    lines=fo.readlines()  
    fo.close()
    fo=open(file_name,"r+")
    data=fo.read()
    Log.Message (fo.tell())
    fo.seek(185,0)
    fo.write(work_date)
    fo.seek(196,0)
    fo.write(week_end_date) 
    fo.seek(215,0)
    fo.write (uniq_ref)
    fo.close()
    log_path = ("C:\\EMPL_TIME_Files\\CAIAUTOSUB_US_LABOR_TEST.txt")
    Log.Enabled=True
    Log.File(log_path, "CAIAUTOSUB_US_LABOR ATTACHED")
    Log.Enabled=False 
    
# Placing CAIAUTOSUB_US_LABOR_20190708.csv file in //DAUT2I//incoming//ATG_OU//I18

 def place_empl_time_file_winscp(self):
    Stored_session = "cai_snow@mftstg.manheim.com"
#    Stored_session = "opc@stage-fin-iad1-ebsapp1.private.stagefin.oraclevcn.com"
    local_dir = "C:\\EMPL_TIME_Files"
    remote_dir =  self.testConfig['winscp']['labor_file_remote_dir']
#    remote_dir = self.winscpConfig[self.testConfig['ebiz']['env']]['remote_dir']+"incoming//ATG_OU//I18"
    upload_file_name = "CAIAUTOSUB_US_LABOR_TEST.txt"
    winscp_utility.upload_file(Stored_session,local_dir,remote_dir,upload_file_name)
    Log.Enabled=True       
    Log.Message("CAIAUTOSUB_US_LABOR_TEST.txt file placed in the I18 directory")           
    Log.Enabled=False

# Login to Oracle EBIZ and select the responsibility        
    self.page.WaitProperty("contentText","CAI US PA JOB SCHEDULER",6000)
    cai_gl_submit_link=self.page.Find("contentText","CAI US PA JOB SCHEDULER",30)
    self.verify_aqobject_chkproperty(cai_gl_submit_link,"contentText",cmpIn,"CAI US PA JOB SCHEDULER")
    cai_gl_submit_link.Click() 
    self.log_message_web("Click 'CAI US PA JOB SCHEDULER' - Successful")        
    self.page.Wait()
    self.page.NativeWebObject.Find("contentText","Submit Request","A").Click()
    self.log_message_web("Click 'Submit Request' - Successful") 
    
    web_utils.validate_security_box()
    delay(2000)
    jFrame=self.initializeJFrame()
    Delay(2000)
    form_utils.click_ok_btn(jFrame)
    Delay(4000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit a New Request","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,50,True,90000)  
    Sys.HighlightObject(req_form)     
#    jFrame.Keys("~s")
#    Delay(1000)
#    jFrame.Keys("~o")
#    Delay(2000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["What type of request do you want to run? Request Set alt s","ExtendedCheckbox"]   
    req_form.FindChild(prop,val,10).Click()
    Delay(1000)
    req_form.FindChild("AWTComponentAccessibleName","OK alt O",10).Click()
    
    
# Submitting "CAI PA Automated Time Interface Request Set" Request Set using CAI US PA JOB SCHEDULER' responsibility
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit Request Set","ExtendedFrame"]
    par_form=jFrame.FindChildEx(prop,val,60,90000)
    par_form.Find("AWTComponentAccessibleName","Request Set RequiredList of Values",30).Click()
    delay(1000)
    par_form.Find("AWTComponentAccessibleName","Request Set RequiredList of Values",30).SetText("CAI PA Automated Time Interface Request Set")
    delay(1000)
    jFrame.Keys("[Tab]")
    delay(1000)
#    jFrame.Keys("~m")
    par_form.FindChild("AWTComponentAccessibleName","Submit",10).Click()
#    jFrame.keys("~m")
    Delay(1000)
    jFrame.Keys("~o")
#   Delay(1000)
    self.log_message_oracle_form(jFrame,"'CAI PA Automated Time Interface' Request Set Submitted")   
    RequestID = aqConvert.VarToInt(''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit()))
    Log.Message("Request ID Of  " + aqConvert.VarToStr(RequestID))
    self.log_checkpoint_message_web("Request ID Of 'CAI PA Automated Time Interface' Request Set" + aqConvert.VarToStr(RequestID))
    Delay(2000)
    jFrame.Keys("~n")
    Delay(4000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000) 

# Gathering Request ID and Output File for the "CAI Pre-processor for Validate Labor Hours"  
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Requests","ExtendedFrame"]
#    req_form=jFrame.FindChildEx(prop,val,30,True,60000)
#    self.req_set_save_output(jFrame,req_form,"CAI Pre-processor for Validate Labor Hours",RequestID)
#    Delay(2000)
#    jFrame.Click()
#    Delay(2000)
#    jFrame.Keys("~w")
#    Delay(2000)
#    jFrame.Keys("2")
#    Delay(2000)
#    jFrame.Keys("[F4]")
#    Delay(2000)
#    jFrame.Keys("~v")
#    Delay(1000)
#    jFrame.Keys("r")
#    Delay(1000)
#    jFrame.Keys("~i")
#    Delay(1000)
    
## Gathering Request ID and Output File for the "PRC: Transaction Import"  
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Requests","ExtendedFrame"]
#    req_form=jFrame.FindChildEx(prop,val,30,True,60000)
#    self.req_set_save_output(jFrame,req_form,"PRC: Transaction Import",RequestID)
#    Delay(2000)
#    jFrame.Click()
#    Delay(2000)
#    jFrame.Keys("~w")
#    Delay(2000)
#    jFrame.Keys("2")
#    Delay(2000)
#    jFrame.Keys("[F4]")
#    Delay(2000)
#    jFrame.Keys("~v")
#    Delay(1000)
#    jFrame.Keys("r")
#    Delay(1000)
#    jFrame.Keys("~i")
#    Delay(1000)

## Gathering Request ID and Output File for the "PRC: Distribute Labor Costs"  
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Requests","ExtendedFrame"]
#    req_form=jFrame.FindChildEx(prop,val,30,True,60000)
#    self.req_set_save_output(jFrame,req_form,"PRC: Distribute Labor Costs",RequestID)
#    Delay(2000)
#    jFrame.Click()    
#    Delay(2000)
#    jFrame.Keys("~w")
#    Delay(2000)
#    jFrame.Keys("2")
#    Delay(2000)    
#    jFrame.Keys("[F4]")
#    Delay(1000)
#    jFrame.Keys("~v")
#    Delay(1000)
#    jFrame.Keys("r")
#    Delay(1000)
#    jFrame.Keys("~i")
#    Delay(1000)

# Checking in the DB for the completion of the Concurrent programs
    dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
    user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
    pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
    dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,aqConvert.VarToStr(RequestID))
    
# Gathering Request ID and Output File for the "PRC: Generate Cost Accounting Events"  
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,60000)
    self.req_set_save_output(jFrame,req_form,"PRC: Generate Cost Accounting Events",RequestID)
    Delay(2000)
    jFrame.Click()    
    Delay(2000)
    jFrame.Keys("~w")
    Delay(2000)
    jFrame.Keys("2")
    Delay(2000)    
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000)
    
# Gathering Request ID and Output File for the "CAI PA AutoSub Labor Import Reconciliation Report"  
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,60000)
    self.req_set_save_output(jFrame,req_form,"CAI PA AutoSub Labor Import Reconciliation Report",RequestID)
    Delay(2000)
    jFrame.Click()
    fo=open(self.log_path,"r")
    lines=fo.readlines()
    recon_pa_batch=lines[6][23:].strip()
    Log.Enabled=True
#   self.log_message_web("Asset Number: - "+lines[6][23:].strip())
    Log.Message("Imported Recon PA BATCH: "+lines[6][23:].strip())
    Log.Enabled=False   
    Delay(2000)
    jFrame.Keys("~w")
    Delay(2000)
    jFrame.Keys("2")
    Delay(2000)    
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000)
 
    
# Gathering Request ID and Output File for the "PRC:Update Project Summary Amounts"  
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,60000)
    self.req_set_save_output(jFrame,req_form,"PRC: Update Project Summary Amounts",RequestID)
    Delay(1000)
    jFrame.Click()
    Delay(2000)
    jFrame.Keys("[F4]")
    Delay(2000)
    jFrame.Keys("~f")
    Delay(1000)
    jFrame.Keys("w")
    Delay(2000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Responsibilities","FWindow"]
    resp_form=jFrame.FindChildEx(prop,val,30,True,40000)
    resp_form.Find("AWTComponentName","LWTextField*",10).Click()
    Delay(1000)
    resp_form.Find("AWTComponentName","LWTextField*",10).Keys("[BS]")
    Delay(1000)
    resp_form.Find("AWTComponentName","LWTextField*",10).keys("CAI "+self.oper_unit+" PA PROJECT CONTROLS")
    Delay(2000)
    resp_form.Find("AWTComponentName","LWTextField*",10).Click() 
    self.verify_aqobject_chkproperty(resp_form,"AWTComponentAccessibleName",cmpContains,"Responsibilities")   
    Delay(5000)
    jFrame.Keys("~f")
    Delay(1000)
    jFrame.Keys("~0")
    self.log_message_oracle_form(jFrame,"Changed Responsibility to 'CAI "+self.oper_unit+" PA PROJECT CONTROLS'")  
    Delay(3000)
    jFrame.keys("e")
    Delay(1000)
    jFrame.keys("e")
    Delay(1000)
    jFrame.keys("a")
    Delay(3000)
    self.log_message_oracle_form(jFrame,"'Find Expenditure Items' form launched successfully")  
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Expenditure Items","ExtendedFrame"]
    exp_batch_form=jFrame.FindChildEx(prop,val,30,True,40000)
    exp_batch_form.FindChild("AWTComponentAccessibleName","Expenditure BatchList of Values",10).Click()
    Delay(1000)        
    exp_batch_form.FindChild("AWTComponentAccessibleName","Expenditure tab page Expenditure BatchList of Values",10).SetText(VarToStr(recon_pa_batch))
    Delay(1000)
    self.log_message_oracle_form(jFrame,"In 'Find Expenditure Items' form Expenditure Batch entered successfully")
    Delay(1000)
    self.log_message_oracle_form(jFrame,"In 'Find Expenditure Items' form click 'Find' button next")
    exp_batch_form.FindChild("AWTComponentAccessibleName","Find alt i",10).Click()
#    jFrame.Keys("~i")
    Delay(10000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Expenditure Items","ExtendedFrame"]
    exp_items_form=jFrame.FindChildEx(prop,val,30,True,40000)
    Delay(1000)
    self.log_message_oracle_form(jFrame,"On 'Expenditure Items' form click on 'Item Details' next")
    exp_items_form.FindChild("AWTComponentAccessibleName","Item Details alt D",10).Click()
    Delay(8000)
    self.log_message_oracle_form(jFrame,"On 'Item Details' form click on 'OK' button next")
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Item Details","ExtendedFrame"]
    item_details_form=jFrame.FindChildEx(prop,val,30,True,40000)
    item_details_form.FindChild("AWTComponentAccessibleName","OK alt O",10).Click()
    Delay(8000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Cost Distribution Lines","ExtendedFrame"]
    cost_dist_form=jFrame.FindChildEx(prop,val,30,True,40000)
    self.log_message_oracle_form(cost_dist_form,"'Cost Distribution Lines' reviewed successfully")
    Delay(4000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~o")
    Delay(4000)  
#    self.close_forms(jFrame)
#    Delay(4000)
    

 def req_set_save_output(self,jFrame,req_form,srch_child_name,Preqid):
    self.log_message_oracle_form(req_form,"Checking for "+aqConvert.VarToStr(srch_child_name)+ " Child Program Status")
    req_form.FindChild("AWTComponentAccessibleName","Refresh Data alt R",20).Click()
#    req_form.keys("~r")
    i=20
    for x in range(1,180):     
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Name",i]
        child_name=req_form.Find(prop,val,10).wText 
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Phase",i+20]
        phase=req_form.Find(prop,val,10).wText 
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Request ID",i-10]
        creqid=VarToInt(req_form.Find(prop,val,10).wText)
#        self.log_message_oracle_form(req_form,"Request ID of "+aqConvert.VarToStr(srch_child_name)+" is "+aqConvert.VarToStr(creqid))                                                
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Status",i+30]         
        status =req_form.FindChild(prop,val,60)            
        if (child_name==srch_child_name) and (creqid>=Preqid) and (phase == "Completed"):
            self.log_message_oracle_form(req_form,aqConvert.VarToStr(srch_child_name)+" Phase Completed Successfuly")            
#            self.verify_aqobject_chkproperty(status,"wText",cmpContains,"Normal")                  
            status.Keys("[Enter]")
            Delay(1000)
            req_form.FindChild("AWTComponentAccessibleName","View Output alt p",20).Click()
#            jFrame.Keys("~p")    
            Delay(3000)
            output_page=Sys.Browser("iexplore").Page("https://core*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.*")
            output_page.Click()
            Delay(2000)
            output_page.Keys("~f")
            Delay(2000)
            output_page.Keys("a")
            Delay(2000)
            file_system_utils.create_folder(self.op_log_path)             
            log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"File"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"_%d%b%Y_%H%M")+".txt"    
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
            Delay(1000)
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
            Delay(1000)
            Log.Enabled=True
            Log.File(log_path, aqConvert.VarToStr(srch_child_name)+" is Completed And Output file is attached")
            Log.Enabled=False     
            web_utils.close_additional_browsers()  
            if status.wText == "Error":
               self.log_message_oracle_form(req_form,aqConvert.VarToStr(srch_child_name)+" failed with error status")   
               self.log_error_message("Failed with error status.")
            Filesaved = 'True'
            self.log_path=log_path
            return creqid                      
        elif i >=50:
           Delay(20000)
#           req_form.keys("~r")
           req_form.FindChild("AWTComponentAccessibleName","Refresh Data alt R",20).Click()
           Delay(3000)
           i=20
           val=["Name",i]
           child_name=req_form.Find(prop,val,10).wText

        else:  
           Delay(3000)
           i=i+1 
           req_form.Keys("[Down]")
           



  
