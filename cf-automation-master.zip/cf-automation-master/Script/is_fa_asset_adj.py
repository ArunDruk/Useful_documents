﻿from ebiz import *
import random

class is_fa_asset_adj(Ebiz):  
 global rowno, app, jFrame

 def login(self):
   self.login_user='naggarwal'
   super().login()

 def action(self):
   
  self.navigate_assetworkbench()
  #Click OK Button on Note Window
#  if(self.jFrame.FindChild("AWTComponentName","FormButton*",60).Exists): 
#    self.log_message_web("Click 'OK Button'")  
#    self.jFrame.FindChild("AWTComponentName","FormButton*",60).Click()
#  else:
#     self.log_message_web("Button not found'") 
     
  app = Sys.OleObject["Excel.Application"]
  Delay(1000)
#      app.Visible = True
  book = app.Workbooks.Open(Project.Path+"\\Datasheets\\Oracle-FA-Adjustments\\Assets.xls")
  RowCount = book.ActiveSheet.UsedRange.Rows.Count
     # txnum = VarToInt(app.cells.Item[rowno,1])
  rowno = 2    
  while rowno<(RowCount+1):
         self.asset_adj(self.jFrame,rowno,app)
         rowno=rowno+1
  book.save()
  delay(1000)
  book.close()
  self.closeall(self.jFrame)      
 
  
 def navigate_assetworkbench(self):

  prop_names = ("innerHTML")
  prop_values = ("Oracle Applications Home Page")
  obj =  Sys.Browser("iexplore").Page("*").FindChild(prop_names,prop_values,30)
  self.verify_aqobject_chkproperty(obj,"contentText",cmpContains,"Oracle Applications Home Page")
  Sys.Browser("iexplore").Page("*").EvaluateXPath("//a[@id='AppsNavLink' and contains(text(),'AM Super User')]")[0].Click()
  Delay(5000)
  self.wait_until_page_loaded()
  self.log_message_web("Click 'AM SUPER USER' - Successful") 
  Sys.Browser("iexplore").Page("*").EvaluateXPath("//a[@id='N109']")[0].Click()
  self.log_message_web("Click 'Asset Work Bench' - Successful") 
  Delay(3000)
  self.wait_until_page_loaded()
  self.jFrame=Sys.Browser("iexplore").SwingObject("JBufferedFrame", "*", -1, 1)
  Delay(1000)
  self.jFrame.Keys("~o")
#  self.jFrame.FindChild("AWTComponentName","FormButton*",60).Click()
     
 def asset_adj(self,jFrame,rowno,app):
#  jFrame passed as parameter

  prop=["AWTComponentAccessibleName","JavaClassName"]
  val=["Find Assets","ExtendedFrame"]
  find_asset_form=jFrame.FindChild(prop,val,60)
  self.verify_aqobject_chkproperty(find_asset_form,"AWTComponentAccessibleName",cmpContains,"Find Assets")
  find_asset_form.Find("AWTComponentAccessibleName","Asset Number",10).Click() 
  find_asset_form.Find("AWTComponentAccessibleName","Asset Number",10).SetText(app.Cells.Item[rowno,1])
  self.log_message_oracle_form(find_asset_form,"Asset# '"+ aqConvert.VarToStr(app.Cells.Item[rowno,1]))
#click Find on Find Assets Window
  jFrame.Keys("~i") 
  Delay(1000)
  # click Books button on Assets Window
  
  prop_names=["AWTComponentAccessibleName","JavaClassName"]
  prop_values=["Assets","ExtendedFrame"]
  obj =  self.jFrame.FindChild(prop_names,prop_values,30)
  self.verify_aqobject_chkproperty(obj,"AWTComponentAccessibleName",cmpContains,"Assets")
  self.log_message_oracle_form(jFrame,"Assets Window Opened")  
  jFrame.keys("~b")
  Delay(5000)
#Books window 
  prop_names=["AWTComponentAccessibleName","JavaClassName"]
  prop_values=["Books","ExtendedFrame"]
  obj = self.jFrame.FindChild(prop_names,prop_values,30)
  self.verify_aqobject_chkproperty(obj,"AWTComponentAccessibleName",cmpContains,"Books")
  
  prop=["AWTComponentAccessibleName","JavaClassName"]
  val=["Books","ExtendedFrame"]
  books_form=Sys.Browser("iexplore").SwingObject("JBufferedFrame", "Oracle Applications*", -1).FindChild(prop,val,60) 
  books_form.Find("AWTComponentAccessibleName","Book*",30).Click()
  books_form.Find("AWTComponentAccessibleName","Book*",30).Keys("MAN USPOLI BOOK")    
  books_form.Find("AWTComponentAccessibleName","Current Cost*",30).Click() 
  books_form.Find("AWTComponentAccessibleName","Current Cost*",30).Keys(random.randint(1111,9999))
  # click done Button
  self.log_message_oracle_form(books_form,"Asset Cost updated")
  books_form.Keys("~d")
  self.log_message_oracle_form(books_form,"Transaction Complete")
   # Click Ok
  prop_names = ("AWTComponentAccessibleName","JavaClassName")
  prop_values = ("Forms FRM*","FWindow")
  obj = jFrame.FindChild(prop_names,prop_values,30)
  self.verify_aqobject_chkproperty(obj,"Name",cmpContains,"Transaction complete")
  
  books_form.keys("~o") 
  Delay(1000)
  # Navigate to View > Find 
  jFrame.Keys("~v")
  Delay(1000)
  jFrame.Keys("f")

 def closeall(self,jFrame):
    jFrame.Keys("[F4]") # Close Form ( Find Assets)
    Delay(1000)
    jFrame.Keys("[F4]") # close Form ( Close Navigator)
    Delay(3000)
    jFrame.keys("~o") # Click OK to Exit Oracle Applications 
    Delay(1000)
    Sys.Browser("iexplore").Page("*").Close()
  #  Sys.Process("java").SwingObject("JBufferedFrame", "Oracle Applications - TMNH2I - Cloned from PMNHMI on 08-OCT-2018", -1, 1).AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("FWindow", "Forms FRM-40400: Transaction complete: 1 records applied and saved.", 0).AWTObject("LWComponent", "", 0).AWTObject("AlertPane", "FRM-40400: Transaction complete: 1 records applied and saved.", 0).AWTObject("LWContainer", "", 0).Keys("~o")
    

