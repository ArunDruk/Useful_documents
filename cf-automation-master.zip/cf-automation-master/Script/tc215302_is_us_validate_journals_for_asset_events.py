﻿from ebiz import *
import dbhelper 
from file_system_utils import *



class tc215302_is_us_validate_journals_for_asset_events(Ebiz):
 global rowno 
 
  
 def login(self):
    self.login_user="mfallwell"
    super().login()

 def goto_url(self,url):
   super().goto_url(self.testConfig['ebiz']['oci_is_url'])
    
 def action(self,book): 
   
    rowno = 2
    app = book.Sheets.item["Assets"]
    app1 = book.sheets.item["asset_creation"]
    web_utils.log_checkpoint("Logged in to Oracle Applications Home Page Successfully",500,self.page) 
    self.wait_until_page_loaded()      
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='menuContent']//div[contains(text(),'GL Corporate Accounting User')]") 
    self.wait_until_page_loaded()
    self.page.NativeWebObject.Find("contentText","Journals","A").Click()
    web_utils.log_checkpoint("Click 'Journals' - Successful",500,self.page)
    delay(2000)
    self.page.NativeWebObject.Find("contentText","Enter","A").Click()
    web_utils.log_checkpoint("Click 'Enter' - Successful",500,self.page)
    web_utils.validate_security_box()
    Delay(20000)
    jFrame=self.initializeJFrame()
    form_utils.click_ok_btn(jFrame)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Journals","ExtendedFrame"]
    fnd_jrnl=jFrame.FindChildEx(prop,val,60,True,90000)
    asset_depr = VarToStr(app.Cells.Item[2,5])
    if asset_depr == 'Depreciated' or asset_depr == 'Retired':
      batch_name = VarToStr(app.Cells.item[rowno,3])
    else:
      batch_name = VarToStr(app.Cells.item[rowno,1])
    fnd_jrnl.Find("AWTComponentAccessibleName","BatchList of Values",10).Click()
    fnd_jrnl.Find("AWTComponentAccessibleName","BatchList of Values",10).SetText(batch_name)
    web_utils.log_checkpoint(" Enter Journal Import Batch ID : "+VarToStr(app.Cells.item[rowno,1]),500,jFrame) 
    delay(2000) 
    jFrame.Keys("~i")
    Delay(20000)
    web_utils.log_checkpoint("Find Journal Successful",500,jFrame) 
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Enter Journals*","ExtendedFrame"]
    ent_journals = jFrame.FindchildEx(prop,val,60,True,200000)  
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Batch Status",16]
    batch_status = ent_journals.Find(prop,val,60)
    while batch_status.wText =="":
      Delay(2000)
      batch_status = ent_journals.Find(prop,val,60)  
    delay(4000) 
    jFrame.Keys("~u")
    delay(4000) 
    web_utils.log_checkpoint("Review Journal Successful",500,jFrame) 
    delay(1000)
    val = ["Category Required",3] 
    category = jFrame.FindChild(prop,val,60)
    cat_val = category.wText
    web_utils.log_checkpoint("Journal Category: "+cat_val,500,jFrame)
    if asset_depr == 'Depreciated':
     aqObject.CheckProperty(category,"wText",cmpIn,"Depreciation")
    elif asset_depr == 'Retired':
      aqObject.CheckProperty(category,"wText",cmpIn,"Retirements")
    else:
      aqObject.CheckProperty(category,"wText",cmpIn,"Addition")      
    delay(1000)
#    prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
#    val = ["[]","VTextField",16]
#    jFrame.FindChild(prop,val,60).Click()
    dff = Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("ExtendedFrame", "Journals (MAN GLB ALL) - *", 19).AWTObject("LWComponent", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("FScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("DrawnPanel", "", 0).AWTObject("FScrollBox", "", 5).AWTObject("ScrollBox$1", "", 0).AWTObject("DrawnPanel", "", 0).AWTObject("VTextField", "[ ]", 16)
    Sys.HighlightObject(dff)
    dff.Click()
    #validate dff on first row:
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val = ["Enter Journals: Lines","FlexWindow"]
    dff_window = jFrame.FindChild(prop,val,60)
    if dff_window.Exists:
      Sys.HighlightObject(dff_window)
      val = ["VIN Number*","FlexTextField"]
      vin = jFrame.FindChild(prop,val,60)
      Sys.HighlightObject(vin)
      sno = VarToStr(vin.AWTComponentAccessibleName)
      sno_vin = (sno.strip().split(':')[1])
      web_utils.log_checkpoint("Serial Number Available in Journal DFF"+VarToStr(sno_vin[1:]),500,jFrame) 
      val = ["OK ALT O","FormButton"]
      jFrame.FindChild(prop,val,60).Click()
    else:
      self.log_error_message("Unable to launch DFF window for journals")
    delay(2000)
      
    #validate other information:
    val=["Journals (MAN GLB ALL)*","ExtendedFrame"]
    jrnls=jFrame.FindChildEx(prop,val,60,True,60000)
    jrnls.FindChild("AWTComponentName","FormsTabPanel*",60).ClickTab("Other Information")
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Status: Posting",0]
    val1 = ["Source",3]
    jrnl_val = jFrame.FindChild(prop,val,60)
    jrnl_status=jrnl_val.wText  
    
    #validate journal source:
    source = jFrame.FindChild(prop,val1,60)
    source_val = source.wText
    web_utils.log_checkpoint("Journal Status: "+jrnl_status,500,jFrame) 
    Log.Enabled=True
#    aqObject.CheckProperty(jrnl_val,"wText",cmpIn,"Posted")
    aqObject.CheckProperty(source,"wText",cmpIn,"Assets")
    Log.Enabled=False
    web_utils.log_checkpoint("Journal Source is 'Assets'",500,jFrame) 
    delay(4000) 
    jrnls.FindChild("AWTComponentName","FormsTabPanel*",60).ClickTab("Lines")
    delay(4000) 
    dsn = self.testConfig['man_oracle_db']['dsn']
    user_id = self.testConfig['man_oracle_db']['userid']
    pwd = self.testConfig['man_oracle_db']['pwd']
    dbhelper.verify_is_journal_status(dsn,user_id,pwd,VarToStr(app.Cells.item[rowno,1]))
    web_utils.log_checkpoint("Review Journal Successful",500,jFrame) 
    app.Cells.Item[2,5] = "None"
    self.close_forms(jFrame)
    Delay(1000)



def test():
    jFrame = Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1)
#    dff = Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("ExtendedFrame", "Journals (MAN GLB ALL) - Assets A 5031592 162825307", 19).AWTObject("LWComponent", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("FScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("DrawnPanel", "", 0).AWTObject("FScrollBox", "", 5).AWTObject("ScrollBox$1", "", 0).AWTObject("DrawnPanel", "", 0).AWTObject("VTextField", "[ ]", 16)
#    Sys.HighlightObject(dff)
#    dff.Click()
    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val = ["Enter Journals: Lines","FlexWindow"]
#    dff_window = jFrame.FindChild(prop,val,60)
#    if dff_window.Exists:
#      Sys.HighlightObject(dff_window)
#      val = ["VIN Number*","FlexTextField"]
#      vin = jFrame.FindChild(prop,val,60)
#      Sys.HighlightObject(vin)
#      sno = VarToStr(vin.AWTComponentAccessibleName)
#      sno_vin = (sno.strip().split(':')[1])
#
#      val = ["OK ALT O","FormButton"]
#      jFrame.FindChild(prop,val,60).Click()

    val=["Journals (MAN GLB ALL)*","ExtendedFrame"]
    jrnls=jFrame.FindChildEx(prop,val,60,True,60000)
    jrnls.FindChild("AWTComponentName","FormsTabPanel*",60).ClickTab("Other Information")
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Status: Posting",0]
    val1 = ["Source",3]
    jrnl_val = jFrame.FindChild(prop,val,60)
    jrnl_status=jrnl_val.wText  
    
    #validate journal source:
    source = jFrame.FindChild(prop,val1,60)
    source_val = source.wText
    web_utils.log_checkpoint("Journal Status: "+jrnl_status,500,jFrame) 
    Log.Enabled=True
    aqObject.CheckProperty(jrnl_val,"wText",cmpIn,"Posted")
    aqObject.CheckProperty(source,"wText",cmpIn,"Assets")
    Log.Enabled=False