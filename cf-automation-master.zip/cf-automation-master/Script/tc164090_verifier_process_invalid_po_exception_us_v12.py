﻿from base import *
from driverchain import *
from ebiz import *
  
  
class Driver(Driverchain):
    global classarr,env
    
    def __init__(self):
      global test_env, sheet_obj, book     
      app = Sys.OleObject["Excel.Application"]
      Delay(1000)
      self.book = app.Workbooks.Open(Project.Path+"\\datasheets\\WCI\\wc_verifier_us_invaid_po_exception.xls")          
      app.Visible = "True"    
      gvar.dataprep['book'] = self.book
      self.test_env="OCI_DEV" #BuiltIn.ParamStr(14)
      self.oper_unit="US" #BuiltIn.ParamStr(15)
      gvar.dataprep['test_env'] = self.test_env
      gvar.dataprep['oper_unit']= self.oper_unit
      self.classarr=["WFR_Process_Email_Batches_V12()"]
      super().__init__(self.classarr)
      
    def close_excel(self):    
      self.book.save()
      delay(1000)
      self.book.close()
      
      
      
def main():  
  try:
      gvar.dataprep['env'] = 'oci_dev'
      obj=Driver()
      test_utility.start_test(__name__.center(70,'*'),'Req2Check - CF','VERIFIER','164065','prabha_wci_regression') 
      cobj = obj.run()
      print('evoke test_utility')
  except:
      gvar.dataprep['verdict'] = 'Fail'
      tc_logs.header_name('Test Failed - traceback shown below')       
      tc_logs.error_with_no_picture(traceback.format_exc(),'')       
      print('evoke test_utility')
  finally:
      test_utility.end_test()
      obj.close_excel()


