﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils
import winscp_utility
import web_utils
import random
from  datetime import datetime
from  datetime import timedelta

class is_gl_daily_rates_file_import_from_wellsfargo_ete26b(Ebiz):
 
 global inv_date,inv_num
  
 def login(self):
    self.login_user="mfallwell"
    super().login()
 
 def goto_url(self,url):
   super().goto_url(self.testConfig['ebiz']['oci_is_url'])
   
 def action(self,book):
    self.app = book.Sheets.item["Daily_Rates"] 
    my_date = datetime.today().weekday()
#    my_date = 3
    if my_date == 5 or my_date == 6:
      self.wknd_date = aqConvert.DateTimeToFormatStr(datetime.today(),"%d-%b-%Y")
#      self.wknd_date = "30-APR-2020"
      if my_date == 5:
        i = 1
      else:
        i = 2
      self.refer_date = aqConvert.DateTimeToFormatStr(aqDateTime.AddDays(self.wknd_date,-i),"%d-%b-%Y")
#      self.refer_date = "29-MAY-2020"
      self.op_log_path="C:\\TC_Logs"
      self.oracle_process(self.app,my_date)
    else:
      self.op_log_path="C:\\TC_Logs"
      self.daily_rate_files="C:\\Daily_Rate_Files"
      self.daily_rate_files_1="C:\\Daily_Rate_Files_1"
      new_file_name = "FX_EOD_"+(datetime.now().strftime("%Y%m%d%H%M%S")+".csv")
#      new_file_name = "FX_EOD_20200430123.csv"
      self.place_files_local(new_file_name)
      self.place_files_local_1(new_file_name)
      self.process_file_ftp(new_file_name)
      self.oracle_process(self.app,my_date)
    
#_______________________________________________________Prabha:
# Clear existing (WINSCP) logfile in local:

    file_exist=aqFileSystem.FindFiles("C:\\Users\\Administrator\\Documents\\","logfile.log")
    if file_exist != None:
     aqFileSystem.DeleteFile("C:\\Users\\Administrator\\Documents\\logfile.log")
    log_path = ("C:\\Users\\Administrator\\Documents\\logfile.log")    
    
#Changes to copy daily rates file from project to local folder: Prabha

 def place_files_local(self,new_file_name):   
    
    file_system_utils.create_folder(self.daily_rate_files)
    file_exist=aqFileSystem.FindFiles("C:\\Daily_Rate_Files","*.csv")
    if file_exist != None:
     aqFileSystem.DeleteFile("C:\\Daily_Rate_Files\\*.csv")
    aqFileSystem.CopyFile(Project.Path+"DataSheets\\Oracle-GL-Journal\\IS\\FX_EOD_20200610034909.csv", "C:\\Daily_Rate_Files\\"+new_file_name)
    log_path = ("C:\\Daily_Rate_Files\\"+new_file_name)
    Log.Enabled=True
    Log.File(log_path, "Existing Daily Rates File Attached")
    Log.Enabled=False 

    
#_______________________________________________________Prabha:  
# file download, sort and copy validation data in Local Folder(C://Daily_Rate_Files)

    foundFiles = aqFileSystem.FindFiles("C:\\Daily_Rate_Files\\", "*.csv")
    if foundFiles != None:
#     while foundFiles.HasNext():
      if foundFiles.Count ==1:
        aFile = foundFiles.Next()
        file_path =  ("C:\\Daily_Rate_Files\\"+aFile.Name)
        Log.Message(aFile.Name)
      else:
       from operator import itemgetter 
       FolderInfo = aqFileSystem.GetFolderInfo("C:\\Daily_Rate_Files\\")
       latest_file_path = sorted([{'modified_date':str(FolderInfo.Files.Item(i).DateLastModified),'path':str(FolderInfo.Files.Item(i).path),'name':str(FolderInfo.Files.Item(i).Name)}for i in range(FolderInfo.Files.count)],key=itemgetter('modified_date'),reverse=True)[0]['name']
       file_path =  ("C:\\Daily_Rate_Files\\"+latest_file_path)
    else:
      Log.Error("File Not Available in the Folder")
#      Log.File(log_path, "WinScp Log File Attached")
#      Log.Enabled=False 
    self.modify_date(file_path)
    
 def modify_date(self,file_path):
    import re
    from datetime import datetime
    read_Lines=[]
    write_Lines=[]
    with open(file_path,'r') as fr:
        read_Lines=fr.readlines()
        for line in read_Lines:
            cur_date = datetime.now().strftime("%m/%d/%Y")
#            cur_date = "07/31/2020"
            new_string=re.sub(r'(0|1)[0-9]/[0-9]{2}/[0-9]{4}',cur_date,line)
            write_Lines.append(new_string)   
    with open(file_path,'w') as fw:
        fw.writelines(write_Lines)
    self.modify_rate(file_path)
    
 def modify_rate(self,file_path):
    fo=open(file_path,"r")
    with open(file_path,"r") as fo:
      lines=fo.readlines()
    with open(file_path,"w") as fo:
      for line in lines:
        val_date = aqString.SubString(line,0,10)
        val_curr_from = aqString.SubString(line,11,3)
        val_curr_to = aqString.SubString(line,15,3)
        val_rate =  aqString.SubString(line,19,8).strip('\n')
        if val_curr_from =="USD" and val_curr_to =="BRL":
          self.val_curr_from = aqString.SubString(line,11,3)
          self.val_curr_to = aqString.SubString(line,15,3)
          self.app.Cells.Item[2,1] = val_date
          self.app.Cells.Item[2,2] = self.val_curr_from
          self.app.Cells.Item[2,3] = self.val_curr_to
          self.req_date = aqConvert.DateTimeToFormatStr(val_date,"%d-%b-%Y")
#          self.req_date = "31-JUL-20"
          new_rate = "4."+VarToStr(random.randint(3000,6000))
          self.app.Cells.Item[2,4] = new_rate
          line_rewrite = line.replace(val_rate,new_rate)
          fo.write(line_rewrite)
        else:
          fo.write(line)
      fo.close()
      Log.Enabled=True       
      Log.Message("New Rate Published for USD > BRL Conversion"+new_rate)    
      Log.File(file_path, "Modified Daily Rates File Attached")
      Log.Enabled=False 
    
 def place_files_local_1(self,new_file_name):   
    
    file_system_utils.create_folder(self.daily_rate_files_1)
    file_exist=aqFileSystem.FindFiles("C:\\Daily_Rate_Files","*.csv")
    if file_exist != None:
      aqFileSystem.CopyFile("C:\\Daily_Rate_Files\\"+new_file_name,"C:\\Daily_Rate_Files_1\\"+new_file_name)
    else:
      self.log_error_message("Modified Daily Rates File not found in destined folder")
    log_path = ("C:\\Daily_Rate_Files_1\\"+new_file_name)
#______________________________________________________________________________Prabha:
# Place Modified File in FTP Location:
 def process_file_ftp(self,new_file_name):
    Stored_session = "wellsfargo@mftstg.manheim.com" 
    local_dir = "C:\\Daily_Rate_Files_1"
#      remote_dir =  self.testConfig['winscp']['remote_dir'] 
    remote_dir = "Outbox//DailyRates//SMNH2I"
    upload_file_name = "C:\\Daily_Rate_Files_1\\"+new_file_name
    winscp_utility.upload_file(Stored_session,local_dir,remote_dir,upload_file_name)
    Log.Enabled=True       
    Log.Message("Daily Rates File "+new_file_name+" placed in the "+ remote_dir)           
    Log.Enabled=False


#______________________________________________________________________________Prabha:
#Log in to Oracle Applications and Submit Daily Rates Import Program:
 def oracle_process(self,app,my_date):

    Log.Message("Login to Oracle and Submit Request to import Daily Rates File...") 
    delay(4000)
    self.page.EvaluateXpath("//table[@id='respList']//div[contains(text(),'GL SCHEDULER')]")[0].scrollIntoView()
    self.page.EvaluateXpath("//table[@id='respList']//div[contains(text(),'GL SCHEDULER')]")[0].Click()
    web_utils.log_checkpoint("Click 'GL SCHEDULER' - Successful",500,self.page)
    Delay(1000)         
    self.page.Wait()
    self.page.NativeWebObject.Find("contentText","Requests","A").Click()
    web_utils.log_checkpoint("Click 'Requests' - Successful",500,self.page) 
    self.page.Wait()
    self.page.NativeWebObject.Find("contentText","Run","A").Click()
    web_utils.log_checkpoint("Click 'Run' - Successful",500,self.page)
    delay(2000)
    self.page.wait()
    web_utils.validate_security_box()
    jFrame= self.initializeJFrame()
    Delay(5000)
    form_utils.click_ok_btn(jFrame)
    Delay(5000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit a New Request","ExtendedFrame"]
    par_form=jFrame.FindChildEx(prop,val,60,True,40000)
    jFrame.Keys("~s")
    delay(2000)
    self.log_message_oracle_form( jFrame,"Select Request set and Click Ok Button in Submit new Request Window")
    jFrame.Keys("~o")
    delay(2000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit Request Set","ExtendedFrame"]
    Submit_req_set_form=jFrame.FindChild(prop,val,60)
    Submit_req_set_form.FindChild("AWTComponentAccessibleName","Request Set RequiredList of Values",30).Keys("MAN : GL Daily Rates Import Process Req Set")
    self.log_message_oracle_form( jFrame," Enter Request set Name: MAN : GL Daily Rates Import Process Req Set")
    delay(2000)
    jFrame.Keys("[Tab]")
    prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
    val=["Parameters","VTextField","15"]
    Submit_req_set_form.FindChild(prop,val,60).Click()
    Delay(2000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Parameters","FlexWindow"]
    Parameters_win=jFrame.FindChild(prop,val,60)
    delay(180000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Exchange Rates Date*","FlexTextField"]
    Parameters_win.FindChild(prop,val,60).Click()
#    if my_date == 5 or my_date == 6:
#      Parameters_win.FindChild(prop,val,60).Keys(self.wknd_date)
#    else:
    Parameters_win.FindChild(prop,val,60).Keys(self.req_date)
        
    self.log_message_oracle_form( jFrame," Entered today's date for Exchange Rates Date")
    delay(2000)
    Parameters_win.Keys("~o")
    delay(2000)    
    prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
    val=["Parameters","VTextField","16"]
    Submit_req_set_form.FindChild(prop,val,60).Click()
    Delay(2000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Parameters","FlexWindow"]
    Parameters_win=jFrame.FindChild(prop,val,60)
    Parameters_win.Keys("~o")
    Delay(2000)
    self.log_message_oracle_form( jFrame," Click Submit Button ")
    jFrame.Keys("[Tab]")
    jFrame.Keys("[Enter]")

    delay(2000) 
      
    RequestID = ''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit())
    
    self.log_message_oracle_form( jFrame,"Request ID Generated: "+ aqConvert.VarToStr(RequestID))
    #self.log_checkpoint_message_web("Request ID for CAI US Daily Rates File Import from WellsFargo is " + aqConvert.VarToStr(RequestID))    
    delay(1000)    
    jFrame.Keys("~n")
    delay(1000)
#    jFrame.Keys("~i")
#    delay(5000)
    
    jFrame.Keys("~v")
    Delay(2000)
    jFrame.Keys("r")
    Delay(2000)
#    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#    val=["Find alt i",3]
#    find_button=jFrame.FindChild(prop,val,20)
#    find_button.FindChild(prop,val,20).Click()
    jFrame.Find("AWTComponentAccessibleName","Find alt i",30).Click()
#    jFrame.Keys("~i")
    Delay(2000) 
    self.log_message_oracle_form( jFrame,"Navigation Successul: View > Request; Click Find")
       

    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,40000)
    self.log_message_oracle_form(req_form,"Requests Window Opened;Click Refresh next")
    req_form.keys("~r")
    form_utils.req_set_save_log(self,jFrame,req_form,"MAN: GL Daily Exchange Rates Upload",RequestID)
    Delay(2000)
    form_utils.req_set_save_log(self,jFrame,req_form,"MAN : GL Daily Rates Import Process Req Set (Request Set MAN : GL Daily Rates Import Process Req Set)",RequestID)
    Delay(4000)
    self.program_date = aqConvert.DateTimeToFormatStr(self.req_date,"%d-%b-%y")
    form_utils.req_set_save_log(self,jFrame,req_form,"Period Average - Daily Rates Import and Calculation for Date "+VarToStr(self.program_date).upper()+" (Program - Daily Rates Import and Calculation)",RequestID)
    delay(2000)
    jFrame.Keys("[F4]")

    
    jFrame.Keys("~f")
    Delay(1000)
    jFrame.Keys("w")
    Delay(3000)
    self.log_message_oracle_form( jFrame,"Swith Responsibility to 'GL Administrator' by clicking File > Switch Responsibility")       
# Navigate to CAI GL ALL SETUP > Currencies > Rates > Daily

    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Responsibilities","FWindow"]
    resp_form=jFrame.FindChildEx(prop,val,30,True,40000)
    resp_form.Find("AWTComponentName","LWTextField*",10).Click() 
    resp_form.Find("AWTComponentName","LWTextField*",10).keys("GL Administrator")
    self.verify_aqobject_chkproperty(resp_form,"AWTComponentAccessibleName",cmpContains,"Responsibilities")   
    Delay(2000)
  #   resp_form.Keys("~f")
    jFrame.Keys("~f")
    self.log_message_oracle_form( jFrame,"Navigation Details")
    Delay(4000)
    jFrame.Keys("s")
    Delay(2000)
    jFrame.Keys("c")
    Delay(2000)
    jFrame.Keys("r")

    self.log_message_oracle_form(jFrame,"Navigation Successful : Setup> Currencies > Rates; Click Enter on Daily")
    #________________________________________#
    Delay(2000)
    jFrame.Keys("[Enter]")
    Delay(2000)
    
        
    jFrame.Keys("~v")
    Delay(2000)
    jFrame.Keys("f")
    Delay(2000)

    self.log_message_oracle_form(jFrame,"Navigation Successful : View > Find")    
    #________________________________________#
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Daily Rates","ExtendedFrame"]
    Find_daily_rates_form=jFrame.FindChildEx(prop,val,30,True,30000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Currency: FromList of Values","VTextField"]
    Find_daily_rates_form.FindChild(prop,val,30).Click()
    if my_date == 5 or my_date == 6:
      Find_daily_rates_form.FindChild(prop,val,30).Keys("USD")
    else:
      Find_daily_rates_form.FindChild(prop,val,30).Keys(VarToStr(app.Cells.Item[2,2]))
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Currency: ToList of Values","VTextField"]
    Find_daily_rates_form.FindChild(prop,val,30).Click()
    if my_date == 5 or my_date == 6:
      Find_daily_rates_form.FindChild(prop,val,30).Keys("BRL")
    else:
      Find_daily_rates_form.FindChild(prop,val,30).Keys(VarToStr(app.Cells.Item[2,3]))
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Conversion: From DateList of Values","VTextField"]
    Find_daily_rates_form.FindChild(prop,val,30).Click()
#    if my_date == 5 or my_date == 6:
#      Find_daily_rates_form.FindChild(prop,val,30).Keys(self.wknd_date)
#    else:
    Find_daily_rates_form.FindChild(prop,val,30).Keys(self.req_date)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Conversion: To DateList of Values","VTextField"]
    Find_daily_rates_form.FindChild(prop,val,30).Click()
#    if my_date == 5 or my_date == 6:
#      Find_daily_rates_form.FindChild(prop,val,30).Keys(self.wknd_date)
#    else:
    Find_daily_rates_form.FindChild(prop,val,30).Keys(self.req_date)
#    Find_daily_rates_form.FindChild(prop,val,30).Keys("[Tab]")
    Delay(3000)
    val=["Conversion: TypeList of Values","VTextField"]
    Find_daily_rates_form.FindChild(prop,val,30).Click()
    delay(500)
    Find_daily_rates_form.FindChild(prop,val,30).Keys("Spot")
    Find_daily_rates_form.Keys("[Tab]")
    Delay(3000)
    #__________________________________#
    prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
    val=["Find alt i","Button",2]
    Find_daily_rates_form.FindChild(prop,val,30).Click()
    #_____________________________________________________#
    Delay(3000)
    self.log_message_oracle_form(jFrame,"Daily Rates Details Available for all available conversion type")  
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Daily Rates","ExtendedFrame"]
    daily_rates_form=jFrame.FindChildEx(prop,val,30,True,30000)
    
    prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
    val=["Conversion Rate","VTextField","32"]  
    conv_rates=jFrame.FindChild(prop,val,30)
    conv_rates_num=aqConvert.StrToFloat(conv_rates.wText)
    if my_date == 5 or my_date == 6:
          daily_rates_form.Keys("~v")
          delay(1000)
          daily_rates_form.Keys("f")
          delay(1500)
          self.log_message_oracle_form(jFrame,"Navigation Successful : View > Find")    
          #________________________________________#prabha, added steps to compare rate with friday's, in case of running on weekend
          prop=["AWTComponentAccessibleName","JavaClassName"]
          val=["Find Daily Rates","ExtendedFrame"]
          Find_daily_rates_form=jFrame.FindChildEx(prop,val,30,True,30000)
          prop=["AWTComponentAccessibleName","JavaClassName"]
          val=["Conversion: From DateList of Values","VTextField"]
          Find_daily_rates_form.FindChild(prop,val,30).Click()
          Find_daily_rates_form.FindChild(prop,val,30).Keys("^a[Del]")
          delay(500)
          Find_daily_rates_form.FindChild(prop,val,30).Keys(self.refer_date)
          prop=["AWTComponentAccessibleName","JavaClassName"]
          val=["Conversion: To DateList of Values","VTextField"]
          Find_daily_rates_form.FindChild(prop,val,30).Click()
          Find_daily_rates_form.FindChild(prop,val,30).Keys("^a[Del]")
          delay(500)
          Find_daily_rates_form.FindChild(prop,val,30).Keys(self.refer_date)
          Delay(3000)
          val=["Conversion: TypeList of Values","VTextField"]
          Find_daily_rates_form.FindChild(prop,val,30).Click()
          delay(500)
          Find_daily_rates_form.FindChild(prop,val,30).Keys("Spot")
          Find_daily_rates_form.Keys("[Tab]")
          Delay(3000)
          prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
          val=["Find alt i","Button",2]
          Find_daily_rates_form.FindChild(prop,val,30).Click()
          #_____________________________________________________#
          Delay(3000)
          self.log_message_oracle_form(jFrame,"Daily Rates Details Available for Last Day of Weekend")  
          prop=["AWTComponentAccessibleName","JavaClassName"]
          val=["Daily Rates","ExtendedFrame"]
          daily_rates_form=jFrame.FindChildEx(prop,val,30,True,30000)
    
          prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
          val=["Conversion Rate","VTextField","32"]  
          conv_rates=jFrame.FindChild(prop,val,30)
          rate=aqConvert.StrToFloat(conv_rates.wText)
    else:
      rate=VarToFloat(app.Cells.Item[2,4])
    Log.Enabled = True
    Log.Message("Conversion rate obtained from inbound file for USD to BRL: "+FloatToStr(rate))
    Log.Message("Converison rate available in Oracle Currencies > Daily Rates for USD to BRL: "+FloatToStr(conv_rates_num))
    if conv_rates_num == rate:
      self.log_message_oracle_form(jFrame,"Daily Rate Validation for Currencies: "+self.val_curr_from+"to"+self.val_curr_to+"successful")
    else:
      self.log_error_message("Daily Rate Validation for Currencies:"+self.val_curr_from+"to"+self.val_curr_to+"Failed") 
      
#month end rate validations:
    day_of_month = aqConvert.DateTimeToFormatStr(datetime.today(),"%d")
    tomorrow = aqConvert.DateTimeToFormatStr(datetime.today()+timedelta(days=1),"%d") 
    if (VarToInt(day_of_month)-VarToInt(tomorrow)) != -1:
      Log.Enabled = True
      Log.Message("Today is Month End and thus publishing Period Average/End Rates for current Date...")
      Log.Enabled = False
      delay(1000)
      jFrame.Keys("~v")
      delay(2000)
      jFrame.Keys("f")
      delay(1500)
      self.log_message_oracle_form(jFrame,"Navigation Successful : View > Find")    
      #________________________________________#prabha, added steps to publish period average rates at month end:
      prop=["AWTComponentAccessibleName","JavaClassName"]
      val=["Find Daily Rates","ExtendedFrame"]
      Find_daily_rates_form=jFrame.FindChildEx(prop,val,30,True,30000)
      prop=["AWTComponentAccessibleName","JavaClassName"]
      val=["Conversion: From DateList of Values","VTextField"]
      Find_daily_rates_form.FindChild(prop,val,30).Click()
      Find_daily_rates_form.FindChild(prop,val,30).Keys("^a[Del]")
      delay(500)
#      if my_date == 5 or my_date == 6:
      Find_daily_rates_form.FindChild(prop,val,30).Keys(self.req_date)
#      else:
#        Find_daily_rates_form.FindChild(prop,val,30).Keys(self.req_date)
      prop=["AWTComponentAccessibleName","JavaClassName"]
      val=["Conversion: To DateList of Values","VTextField"]
      Find_daily_rates_form.FindChild(prop,val,30).Click()
      Find_daily_rates_form.FindChild(prop,val,30).Keys("^a[Del]")
      delay(500)
#      if my_date == 5 or my_date == 6:
#       Find_daily_rates_form.FindChild(prop,val,30).Keys(self.wknd_date)
#      else:
      Find_daily_rates_form.FindChild(prop,val,30).Keys(self.req_date)
      Delay(3000)
      val=["Conversion: TypeList of Values","VTextField"]
      Find_daily_rates_form.FindChild(prop,val,30).Click()
      delay(500)
      Find_daily_rates_form.FindChild(prop,val,30).Keys("^a[Del]")
      Find_daily_rates_form.Keys("[Tab]")
      Delay(3000)
      self.log_message_oracle_form(jFrame,"Enter Required details to find all rates for month end:")
      prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
      val=["Find alt i","Button",2]
      Find_daily_rates_form.FindChild(prop,val,30).Click()
      #_____________________________________________________#
      Delay(3000)
      self.log_message_oracle_form(jFrame,"Rate Details for the last day of month - run")
      val = ["Conversion: Type RequiredList of Values","VTextField",24]
      rate_type = daily_rates_form.FindChild(prop,val,30).wText
      if rate_type == "Period Average":
        val = ["Conversion Rate","VTextField",32]
        rate_val = daily_rates_form.FindChild(prop,val,30).wText
        self.log_message_oracle_form(jFrame,"Period Average Rate:"+VarToStr(rate_val))
        val = ["Conversion Rate","VTextField",33]
        rate_val = daily_rates_form.FindChild(prop,val,30).wText
        self.log_message_oracle_form(jFrame,"Period End Rate:"+VarToStr(rate_val))
      else:
        self.log_error_message("Unable to Find Period Average Rate for the Queried Date")

    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~o")
    Delay(1000)
#    self.browser.page("*").Close()   
    web_utils.close_additional_browsers()
    
     
# def req_set_save_Log(self,jFrame,req_form,srch_child_name,Preqid):  
#   
#        #____Michael Bennett Update 9/18/2019____#
##        self.log_message_oracle_form(req_form,"Checking for Child Program")
#        self.log_message_oracle_form(req_form,"Checking for " + srch_child_name)
#        #________________________________________#
#        req_form.keys("~r")
#        i=20
#        for x in range(1,180):     
#            prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#            val=["Name",i]
#            child_name=req_form.Find(prop,val,10).wText 
#            prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#            val=["Phase",i+20]
#            phase=req_form.Find(prop,val,10).wText 
#            prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#            val=["Request ID",i-10]
#            creqid=StrToInt(req_form.Find(prop,val,10).wText)                                         
#            prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#            val=["Status",i+30]
#            index =i+30         
#            status =req_form.FindChild(prop,val,60)            
#            if (child_name==srch_child_name) and (VarToInt(creqid) > VarToInt(Preqid)) and (phase == "Completed"):
#                self.log_message_oracle_form(req_form,"phase Completed Successfuly")            
#                #self.log_message_oracle_form(req_form,"Status"+status+"Status Index" +VarToStr(index)) 
#                self.verify_aqobject_chkproperty(status,"wText",cmpIn,"Normal,Warning")        
#                status.Keys("[Enter]")
#                Delay(6000)
#                prop=["AWTComponentAccessibleName","AWTComponentIndex", "AWTComponentName"]
#                val=["View Log alt K",15,"Button43"]
#                req_form.FindChild(prop,val,10).Click()
##                jFrame.Keys("~g")    
##                jFrame.Keys("~k")
#                Delay(5000)
#                output_page=Sys.Browser("iexplore").Page("https://core-*.epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
#                output_page.Click()
#                screenshot=output_page.PagePicture()
#                if (srch_child_name== "CAI Inbound Global File Validation Program"):
#                  Log.Enabled=True
##                  Log.Message("File Location for Daily Rates File is displayed under 'Program Variable values'")
#                  Log.Picture(screenshot,"File Location for Daily Rates File is displayed under 'Program Variable values'")
#                  Log.Enabled=False
#                  
#                Delay(4000)
#                output_page.Keys("~f")
#                Delay(4000)
#                output_page.Keys("a")
#                Delay(4000)
#                file_system_utils.create_folder(self.op_log_path)             
#                log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"File"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"_%d%b%Y_%H%M")+".txt"    
#                Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
#                Delay(1000)
#                Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
#                Delay(1000)
#                Log.Enabled=True
#                Log.File(log_path, aqConvert.VarToStr(srch_child_name)+" Log File Attached")
#                Log.Enabled=False     
#                Sys.Browser("iexplore").Page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close()
#                Sys.Browser("iexplore").Page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close()
#                Filesaved = 'True'
#                return                           
#            elif i >=25:
#               Delay(20000)
#               #___________________#
#               #Michael Bennett changes 8/30/2019
#               req_form.Click()
#               prop=["AWTComponentAccessibleName","AWTComponentName"]
#               val=["Refresh Data alt R","Button28"]
#               req_form.FindChild(prop,val,60).Click()
#    
#               Delay(3000)
#               i=20
#               val=["Name",i]
#               child_name=req_form.Find(prop,val,10).wText
#    
#            else:  
#               Delay(3000)
#               i=i+1 
#         
#
#                              
##def test():
##  
##    file_system_utils.create_folder(self.exl_inv_files)
##  
##    Stored_session = "opc@stage-fin-iad1-ebsapp1.private.stagefin.oraclevcn.com"
##    local_dir = "C:\\Daily_Import_Files"    
##    remote_dir =  self.winscpConfig[self.testConfig['ebiz']['env']]['remote_dir']+"incoming//ATG_OU//I33"
##    file_name = "FX_EOD_20190830034253.csv"
###prabha________________________________________________Add winscp methods to sort/download prod file
##    winscp.utility.download_file(stored_session,local_dir,remote_dir,file_name)
##    winscp_utility.upload_file(Stored_session,local_dir,remote_dir,upload_file_name)
##    Log.Enabled=True       
##    Log.Message("FX_EOD_"+savetime+".csv file placed WINSCP at //U024//fin_datafiles//incoming//ATG_OU//I33 directory")           
##    Log.Enabled=False  
#    
#def test1():
#    file_exist=aqFileSystem.FindFiles("C:\\Users\\answin\\Documents\\","logfile.log")
#    if file_exist != None:
#     aqFileSystem.DeleteFile("C:\\Users\\answin\\Documents\\logfile.log")
#    log_path = ("C:\\Users\\answin\\Documents\\logfile.log")  




