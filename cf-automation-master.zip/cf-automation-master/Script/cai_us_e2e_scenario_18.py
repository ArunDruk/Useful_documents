﻿from base import *
from driverchain import *
from ebiz import *
import test_utility
import gvar
import tc_logs



class Driver(Driverchain):
  global classarr,env
  
  def __init__(self):
    global test_env, sheet_obj, book     
    app = Sys.OleObject["Excel.Application"]
    Delay(1000)
    self.book = app.Workbooks.Open(Project.Path+"\\datasheets\\E2E\\E2E_018.xls")          
#    app.Visible = "True"
    self.test_env= BuiltIn.ParamStr(14)
    self.oper_unit= BuiltIn.ParamStr(15)  
    ProjectSuite.Variables.currency= BuiltIn.ParamStr(17)
#    self.test_env= "oci_stage" #BuiltIn.ParamStr(14)
#    self.oper_unit="US" #BuiltIn.ParamStr(15)  
#    ProjectSuite.Variables.currency= "USD" #BuiltIn.ParamStr(17)
    self.classarr=["ie_clear_cache()","tc84514_cai_us_gl_enter_and_post_webadi_journal_ete18()","tc84514_cai_us_Journal_workflow_approval_ete18()","tc84514_cai_us_journal_posting_ete18()"] 
#    self.classarr=["tc84514_cai_us_gl_enter_and_post_webadi_journal_ete18()"]
    super().__init__(self.classarr)
	
  def close_excel(self):    
    self.book.save()
    delay(1000)
    self.book.close()

#def main():
#  gvar.dataprep['browser']='ie'
#  obj=Driver()
#  cobj=obj.run()
#  obj.close_excel()
	
	
### Added utilities in the main method for Rally TestComplete API Integration (Pushing to GIT in TOGGLE:OFF mode)###
    	
def main():
  try:
    gvar.dataprep['env'] =BuiltIn.ParamStr(14)
    obj=Driver()
    if obj.test_env.lower()=="oci_stage":
      test_utility.start_test(__name__.center(70,'*'),'Core Financials - CF','CAI E2E','123070','CAI E2E - OCI Stage') 
    elif obj.test_env.lower()=="oci_test":
      test_utility.start_test(__name__.center(70,'*'),'Core Financials - CF','CAI E2E','123070','CAI E2E - OCI Test')
    cobj = obj.run()
    print('evoke test_utility')
  except:
    gvar.dataprep['verdict'] = 'Fail'
    tc_logs.header_name('Test Failed - traceback shown below')       
    tc_logs.error_with_no_picture(traceback.format_exc(),'')       
    print('evoke test_utility')
  finally:
    test_utility.end_test()
    obj.close_excel()

