﻿from base import *
from driverchain import *
from ebiz import *



class Driver(Driverchain):
  global classarr
  
  def __init__(self):
    global test_env
    self.test_env="dauti"
    self.classarr=["tc84510cai_us_create_manual_ap_invoice_match()"]     
    super().__init__(self.classarr)
	
	
	
	


def main():
   global browser,page
   cobj=Driver().run()
  
