﻿from base import *
from driverchain import *
from ebiz import *
import test_utility
import gvar
import tc_logs

  
class Driver(Driverchain):
    global classarr,env
    
    def __init__(self):
      global test_env, sheet_obj, book     
      app = Sys.OleObject["Excel.Application"]
      Delay(1000)
      self.book = app.Workbooks.Open(Project.Path+"\\datasheets\\WCI\\wcc_us_single_po.xls")          
#      app.Visible = "True"   
      gvar.dataprep['book'] = self.book 
      
      self.test_env=BuiltIn.ParamStr(14)
      self.oper_unit=BuiltIn.ParamStr(15)
      self.user = BuiltIn.ParamStr(16)
#      
#      self.test_env="oci_dev"
#      self.oper_unit="US"
#      self.user = "mkumar"
      
      gvar.dataprep['user'] = self.user
      self.classarr=["ie_clear_cache()","tc85181cai_us_project_creation()","tc93546cai_us_create_non_catalog_req()","ie_clear_cache()","test_approve_requisition()","ie_clear_cache()","tc93548cai_us_CreatePO_wci()","tc16319cai_us_ReceivePoItems()","WCC_Verify_batch_creation_scan_V12()","ie_clear_cache()","WFR_Process_Email_Batches_V12()","ie_clear_cache()","tc194049_run_payable_open_interface_import_process()","ie_clear_cache()","tc130335_validateInvoice()","tc93849cai_us_create_accounting()","tc130335_validate_invoice_validated_approved_accounted_status()"]
      super().__init__(self.classarr)
      
    def close_excel(self):    
      self.book.save()
      delay(1000)
      self.book.close()
      
#def main():
#  gvar.dataprep['browser']='ie'
#  obj=Driver()
#  cobj=obj.run()
#  obj.close_excel()      
      
def main():  
  try:
    gvar.dataprep['env'] = BuiltIn.ParamStr(14)
    obj=Driver()
    test_utility.start_test(__name__.center(70,'*'),'Core Financials - CF','VERIFIER','163839','CAI WCI E2E - OCI Test') 
    cobj = obj.run()
    print('evoke test_utility')
  except:
    gvar.dataprep['verdict'] = 'Fail'
    tc_logs.header_name('Test Failed - traceback shown below')       
    tc_logs.error_with_no_picture(traceback.format_exc(),'')       
    print('evoke test_utility')
  finally:
    test_utility.end_test()
    obj.close_excel()




