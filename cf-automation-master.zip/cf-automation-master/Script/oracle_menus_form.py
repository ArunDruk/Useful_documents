﻿import gvar
 
def find_textfield():
  return gvar.dataprep['jformobject'].Find("AWTComponentAccessibleName","Find",1000)

def ok_button_notification_window():
  #return gvar.dataprep['jformobject'].Find('AWTComponentName','FormButton*',5000)
  return gvar.dataprep['jformobject'].Find("AWTComponentAccessibleName","OK ALT O",5000)
  
def note_window():
  return gvar.dataprep['jformobject'].Find('AWTComponentAccessibleName','Note*',5000)
  
def view_tab():
  return gvar.dataprep['jformobject'].Find('AWTComponentAccessibleName','View mnemonic V',5000)
      
##  submit new request window
def submit_a_new_request_extended_frame():
  return gvar.dataprep['jformobject'].Find('AWTComponentAccessibleName','Submit a New Request',5000)

def single_request_radio_btn():
  return gvar.dataprep['jformobject'].Find('AWTComponentAccessibleName','What type of request do you want to run? Single Request alt R',5000)
  
def request_set_radio_btn():
  return gvar.dataprep['jformobject'].Find('AWTComponentAccessibleName','What type of request do you want to run? Request Set alt s',5000)
  
##decision choicebox  
def decision_choicebox():
  return gvar.dataprep['jformobject'].Find('AWTComponentAccessibleName','Decision Request submitted.*',5000)

def yes_button():
  return gvar.dataprep['jformobject'].Find('AWTComponentAccessibleName','Yes ALT Y',5000)

def no_button():
  return gvar.dataprep['jformobject'].Find('AWTComponentAccessibleName','No ALT N',5000)

def note_popup_window():
  return gvar.dataprep['jformobject'].Find("AWTComponentAccessibleName","Note Request submitted. (Request ID = *)",100)

def book_textfield():
  return gvar.dataprep['jformobject'].Find("AWTComponentAccessibleName","Book REQUIRED List Values",100)
  
## Run Depreciation ##

def run_depreciation_book_textfield():
  return gvar.dataprep['jformobject'].Find("AWTComponentAccessibleName","Book RequiredList of Values",100)
  
def close_period_checkbox():
  return gvar.dataprep['jformobject'].Find("AWTComponentAccessibleName","Close Period alt C",100)
  
def caution_choicebox():
  return gvar.dataprep['jformobject'].Find("AWTComponentAccessibleName","Caution APP-OFA-*: Run depreciation?  Once the program closes the period, you cannot reopen it.",100)

def note_choicebox():
  return gvar.dataprep['jformobject'].Find("AWTComponentAccessibleName","Note APP-OFA-*: Concurrent Request * submitted.",100)
  
def navigator_form():
  return Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("ExtendedFrame", "Navigator - *", 4).AWTObject("LWComponent", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("FScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("DrawnPanel", "", 0).AWTObject("FormsTabPanel", "", 0).AWTObject("TabPanelSheet", "", 0).AWTObject("FScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("DrawnPanel", "", 0).AWTObject("VTList", "Function List", 0).AWTObject("ScrollBox", "", 0).AWTObject("LWDataSourceList$Content", "", 0) 

def collapse_button():
  return Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("ExtendedFrame", "Navigator - *", 63).AWTObject("LWComponent", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("FScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("DrawnPanel", "", 0).AWTObject("FormsTabPanel", "", 0).AWTObject("TabPanelSheet", "", 0).AWTObject("FScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("DrawnPanel", "", 0).AWTObject("VButton", "Collapse All", 3)
