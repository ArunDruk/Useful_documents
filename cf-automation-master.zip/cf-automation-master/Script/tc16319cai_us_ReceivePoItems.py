﻿from ebiz import *
import web_utils
import form_utils
import file_system_utils
import ebiz


class tc16319cai_us_ReceivePoItems(Ebiz):
  global rowno
  rowno = 2
  
  def login(self):
    self.login_user="rmaran"
    super().login()
  
  def action(self,book):
    app = book.Sheets.item["Invoice"]    
    rowno = 2
    self.wait_until_page_loaded()
    web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" iPROC USER')]")  
    delay(4000)
    web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'iProcurement Home Page')]")
    self.page.wait_until_page_loaded()
    web_utils.clk_link_by_xpath(self.page,"//a[@id='ICXPOR_RECEIVING_HOME']")
    web_utils.clk_link_by_xpath(self.page,"//a[@id='ReceiveItemsLink1']")
    web_utils.set_text(self.page,"//input[@id='Requester']","")
    web_utils.set_text(self.page,"//input[@id='OrderNumber']",app.cells.Item[rowno,14])
    self.page.EvaluateXpath("//table[@id='SearchMessageComponentLayout']//select[@id='ItemsDueSelect']")[0].ClickItem("Any Time")
    web_utils.clk_btn_by_xpath(self.page,"//table[@id='SearchMessageComponentLayout']//button[contains(text(),'Go')]")  
    self.wait_until_page_loaded()
    web_utils.slct_chkbox_by_xpath(self.page,"//span[@id='ResultsTableRN']//input[@name='N3:selected:0']")
    qty=self.page.EvaluateXPath("//span[@id='ResultsTableRN']//input[@id='N3:ReceiptQuantity:0']")[0].Text
    self.log_message_web("Quantity: "+aqConvert.VarToStr(qty))
    ordered=web_utils.get_content_text_by_xpath(self.page,"//span[@id='ResultsTableRN']//span[@id='N3:QuantityOrdered:0']")
    self.log_message_web("Ordered: "+aqConvert.VarToStr(ordered))    
    self.page.Keys("~x")
    self.wait_until_page_loaded()
    self.page.Keys("~x")
    self.wait_until_page_loaded()
    self.page.Keys("~x")
    self.wait_until_page_loaded()    
    self.page.Keys("~m")
    self.wait_until_page_loaded()
    # commented by SR
#    receipt_no=self.page.NativeWebObject.Find("innerText", "*has been created for you.", "div").innerText.split(" ",2)[1]
    receipt_no=self.page.EvaluateXPath("//table[@class='x1h']//b")[0].innerText.split(" ")[2]
    receipt_no = aqConvert.VarToStr(receipt_no)
    self.log_message_web("Receipt No: "+receipt_no)
    app.cells.Item[rowno,18] = receipt_no    
    book.save()
    del app,qty,ordered,rowno
      

  
 

