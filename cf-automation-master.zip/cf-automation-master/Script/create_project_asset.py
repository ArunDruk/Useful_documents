﻿from dbhelper import *
from ebiz import *
import web_utils
import dbhelper
import file_system_utils 

class create_project_asset(Ebiz):
  op_log_path="C:\\Tc_Logs"

  def login(self):
     self.login_user='pkjami'
     super().login()
  
  def goto_url(self,url):
    super().goto_url(self.testConfig['ebiz']['oci_is_url'])
   

  def action(self,book): 
     global rowno
     rowno = 2
     app1 = book.Sheets.item["Requisition"]
     app = book.Sheets.item["PA-FA"] 
     app1.Cells.item[rowno,11] = BuiltIn.ParamStr(16)
     web_utils.log_checkpoint("Logged in to Oracle Applications Home Page Successfully",500,self.page)
     self.wait_until_page_loaded()   
     self.page.EvaluateXPath("//table[@id='menuContent']//div[contains(text(),'PC User')]")[0].Click() 
     web_utils.log_checkpoint("Click 'PC User' - Successful",500,self.page)  
     self.wait_until_page_loaded()
     self.page.Keys("[Down]")
     self.page.Keys("[Down]")
     Delay(2000)
     self.page.NativeWebObject.Find("contentText","Capitalization","A").Click()
     web_utils.log_checkpoint("Click 'CAPITALIZATION' - Successful",500,self.page)
     self.page.Keys("[Down]") 
     Delay(2000)
     self.wait_until_page_loaded() 
     self.page.NativeWebObject.Find("contentText","Capital Projects","A").Click()
     web_utils.log_checkpoint("Click 'Capital Projects' - Successful",500,self.page)  
     Delay(2000)
     web_utils.validate_security_box()
     Delay(15000)
     jFrame=self.initializeJFrame()
     form_utils.click_ok_btn(jFrame)
     Delay(4000)
     
# Navigating to Find Capital Projects form
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Find Capital Projects","ExtendedFrame"]
     findcapitalprojects_form=jFrame.FindChildEx(prop,val,60,True,90000)
     self.verify_aqobject_chkproperty(findcapitalprojects_form,"AWTComponentAccessibleName",cmpContains,"Find Capital Projects")
     findcapitalprojects_form.Find("AWTComponentAccessibleName","Project: NumberList of Values",10).SetText(app1.Cells.item[rowno,11])
     web_utils.log_checkpoint("Project Number Entered in Capital Projects screen is : "+ VarToStr(app1.Cells.item[rowno,11]),500,jFrame)  
     findcapitalprojects_form.Keys("[Tab]")
     findcapitalprojects_form.Keys("[Tab]")
     Delay(3000)
     findcapitalprojects_form.Find("AWTComponentAccessibleName","Find alt i",10).Click()
     Delay(3000)
     
     
# Navigating to Capital Projects form
     self.verify_aqobject_chkproperty(findcapitalprojects_form,"AWTComponentAccessibleName",cmpContains,"Capital Projects")
     web_utils.log_checkpoint("Capital Projects Details form launched successfully",500,jFrame)
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Capital Projects (Manheim Corporate Services)","ExtendedFrame"]
     capitalprojects_form=jFrame.FindChildEx(prop,val,60,True,90000)
     prop = ["AWTComponentAccessibleName","AWTComponentIndex","JavaClassName"]
     val = ["CIP","40","VTextField"]
     cip_value = capitalprojects_form.FindChild(prop,val,30).wText
     if(VarToFloat(cip_value) <= 0.00):
       self.log_error_message(f"CIP: {cip_value}. CIP should be greater than '0'")
     capitalprojects_form.Find("AWTComponentAccessibleName","Assets alt A",10).Click()  
     
  
# Navigating to Assets Form
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=[" Assets*","ExtendedFrame"]
     asset_form=jFrame.FindChildEx(prop,val,60,True,40000)
     Delay(2000) 
     while not asset_form.Exists:
       Delay(2000)
       asset_form=jFrame.FindChild(prop,val,60)
     web_utils.log_checkpoint("'Assets' form launched successfully",500,jFrame)     
     Delay(2000) 
     self.verify_aqobject_chkproperty(asset_form,"AWTComponentAccessibleName",cmpContains,f" Assets (Manheim Corporate Services) - {VarToStr(app1.Cells.item[rowno,11])}")
     Delay(2000)
     asset_form.Find("AWTComponentAccessibleName","Open alt O",10).Click() 
     Delay(2000)  
     web_utils.log_checkpoint("'Asset Details' form launched successfully",500,jFrame)     
     Delay(1000)
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Asset Details (Manheim Corporate Services)*","ExtendedFrame"]
     asset_details_form=jFrame.FindChildEx(prop,val,60,True,40000)
     self.verify_aqobject_chkproperty(asset_details_form,"AWTComponentAccessibleName",cmpContains,f"Asset Details (Manheim Corporate Services) - {VarToStr(app1.Cells.item[rowno,11])}, ")
     

# Entering Asset Details
     asset_name=asset_details_form.Find("AWTComponentAccessibleName", "Asset Name Required",10)
     asset_name.Click()
     ast_name="TST_Asset: "+aqConvert.DateTimeToFormatStr(aqDateTime.Time(),"%H:%M")
     asset_name.Keys(ast_name)
     web_utils.log_checkpoint("Asset Name is : "+VarToStr(ast_name),500,jFrame) 
     Delay(2000)
     
     
     desc=asset_details_form.Find("AWTComponentAccessibleName", "Description RequiredList of Values",10)
     desc.Click()
     ast_desc="TST_Asset: "+aqConvert.DateTimeToFormatStr(aqDateTime.Time(),"%H:%M")
     desc.Keys(ast_desc)
     web_utils.log_checkpoint("Asset Description Entered is "+VarToStr(ast_desc),500,jFrame) 
     Delay(2000)
     
     Asset_Cat=asset_details_form.Find("AWTComponentAccessibleName", "Asset CategoryList of Values",10)
     Asset_Cat.Click()
     Asset_Cat.SetText(app.cells.Item[rowno,4])
     web_utils.log_checkpoint("Asset Category Entered is : "+ VarToStr(app.Cells.item[rowno,4]),500,jFrame) 
     Delay(2000)
     
     jFrame.keys("~f")
     Delay(2000)
     jFrame.keys("s")
     Delay(4000)
     
     Asset_key=asset_details_form.Find("AWTComponentAccessibleName", "Asset KeyList of Values",10)
     Asset_key.Click()
     Delay(2000)
     Asset_key.SetText(app.cells.Item[rowno,5])
     web_utils.log_checkpoint("Assets Key Value Entered is : "+ VarToStr(app.Cells.item[rowno,5]),500,jFrame) 
     Delay(2000)
     
     
     BookList_Values=asset_details_form.Find("AWTComponentAccessibleName", "BookList of Values",10)
     BookList_Values.Click()
     BookList_Values.SetText(app.cells.Item[rowno,6])
     Delay(2000)
     web_utils.log_checkpoint("Assets Book Entered is : "+ VarToStr(app.Cells.item[rowno,6]),500,jFrame) 

     
     Loc_Values=asset_details_form.Find("AWTComponentAccessibleName", "LocationList of Values",10)
     Loc_Values.Click()
     Loc_Values.SetText(app.cells.Item[rowno,7])
     web_utils.log_checkpoint("Assets Location Entered is : "+ VarToStr(app.Cells.item[rowno,7]),500,jFrame) 
     
         
     asset_details_form.Keys("[Tab]")
     Delay(2000)
     prop = ["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
     val = ["Project Asset Type RequiredList of Values","VTextField",7]
     asset_details_form.Find(prop,val,10).SetText(app.cells.Item[rowno,8])
     asset_details_form.Find(prop,val,10).Click()  
     Delay(2000)
     web_utils.log_checkpoint("Project Asset Type Entered is : "+ VarToStr(app.Cells.item[rowno,8]),500,jFrame) 

     
     asset_details_form.Keys("[Tab]")
     Delay(2000)
     asset_details_form.Find("AWTComponentAccessibleName", "Date In Service: EstimatedList of Values",10).Click() 
     asset_details_form.Find("AWTComponentAccessibleName", "Date In Service: EstimatedList of Values",10).SetText(aqConvert.DateTimeToFormatStr(aqDateTime.Today(),"%d-%b-%Y"))
     Delay(2000)
     jFrame.Keys("[Tab]")
     jFrame.Keys("[Tab]")
     asset_details_form.Find("AWTComponentAccessibleName", "Date In Service: ActualList of Values",10).Click() 
     asset_details_form.Find("AWTComponentAccessibleName", "Date In Service: ActualList of Values",10).SetText(aqConvert.DateTimeToFormatStr(aqDateTime.Today(),"%d-%b-%Y"))
     delay(1000)

     
     Actual_unit=asset_details_form.Find("AWTComponentAccessibleName", "Actual Units",10)
     Actual_unit.Click()
     Actual_unit.SetText(app.cells.Item[rowno,10])
     Delay(2000)
     web_utils.log_checkpoint(" Actual Units Entered is : "+ VarToStr(app.Cells.item[rowno,10]),500,jFrame) 
     
     
     Depreciation_Acct=asset_details_form.Find("AWTComponentAccessibleName", "Depreciation  AccountList of Values",10)
     Depreciation_Acct.Click()
     Depreciation_Acct.SetText(app.cells.Item[rowno,11])
     web_utils.log_checkpoint(" Assets Depreciation Entered is : "+ VarToStr(app.Cells.item[rowno,11]),500,jFrame) 
     Delay(4000)
     

# Assigning Asset to Project
     jFrame.keys("~f")
     Delay(2000)
     jFrame.keys("s")
     Delay(2000)
     jFrame.keys("^s")
     Delay(2000)
     jFrame.keys("~s")
     Delay(2000)
     jFrame.keys("~p")
     Delay(2000)
     web_utils.log_checkpoint("Assets Number " +ast_name+ " assigned to a Project " +VarToStr(app1.Cells.item[rowno,11])+ "successfully",500,jFrame) 
#     jFrame.keys("^s")
#     Delay(3000)
     jFrame.keys("~f")
     Delay(2000)
     jFrame.keys("s")
     Delay(2000)
     
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Assign Assets*","ExtendedFrame"]
     assign_assets_form=jFrame.FindChildEx(prop,val,60,True,20000)
     delay(2000)
     assign_assets_form.Close()
     delay(3000)
     asset_details_form.Close()
     delay(3000)
     web_utils.log_checkpoint("Create Project Asset is done successfully",500,jFrame)
     delay(2000)
     jFrame.Close()
     delay(3000)
     jFrame.Keys("~o")


  