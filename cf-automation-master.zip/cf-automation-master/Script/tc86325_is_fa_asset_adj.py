﻿from is_fa_asset_adj import *
from ebiz import *
from base import *
from driverchain import *

class Driver(Driverchain):
  global classarr
  
  def __init__(self):
    Project.Variables.test_env="tmnh2i"
    self.classarr=["is_fa_asset_adj()"]     
    super().__init__(self.classarr)

def main():
   global browser,page
   cobj=Driver().run()
