﻿import doc_delivery_api_req_resp_body
import gvar
import tc_logs
import traceback
import batch_print_utility
import pdf_db_validation
from datetime import date
              
def validate_bos():
  try:
    tc_name = 'i2c_manheim_e2e_internal_test'
    tc_logs.test_name("***"+tc_name+"***")
    gvar.dataprep['env'] = BuiltIn.ParamStr(14)
    gvar.load_environment_files()
    set_parameters(tc_name)
    doc_delivery_api_req_resp_body.api_request_response()
#    pdf_db_validation.count_validation()
  except Exception as e:
    tc_logs.error_with_no_picture("Exception occured" + VarToStr(e)+": "+traceback.format_exc(),'')
          
def set_parameters(tc_name):
  tc_logs.header_name("***TEST DATA PROVIDES***")
  gvar.dataprep['document_type'] = 'BOS'
  gvar.dataprep['p_del_method'] = 'PDF'
  var_list = batch_print_utility.load_parameters(tc_name)
  gvar.dataprep['p_dealer'] = gvar.dataprep['buyer']
#  gvar.dataprep['p_dealer'] = '5189326'#'5207499'
  ## '5306399'
  batch_print_utility.get_dealer_name()
#  gvar.store('date','02/07/2020')
  ##gvar.store('date','8/15/2018')
  gvar.store('date',date.today().strftime("%m/%d/%Y"))
  gvar.store('date_range',10)
  gvar.dataprep['p_inv_high_date'] = aqConvert.DateTimeToFormatStr(gvar.dataprep['date'],"%Y-%m-%d")
  gvar.dataprep['p_inv_low_date'] = aqConvert.DateTimeToFormatStr(aqDateTime.AddDays(gvar.dataprep['date'],-gvar.dataprep['date_range']),"%Y-%m-%d")
  batch_print_utility.print_parameters(var_list)
