﻿from gvar import dataprep as DATAPREP 

def post_seller_payload():
  return {
           "consignmentId": DATAPREP['consignment_id'],
           "orderSoldToCustomer": DATAPREP['seller'],
           "orderBillToCustomer": DATAPREP['seller'],
           "orderThirdPartyRemarketer": None,
           "orderOrderType": "US SELLER",
           "orderReferenceId": f"SELLER{DATAPREP['consignment_id']}",
           "orderSalesChannel": "RMS",
           "orderLateFeeExempt": "TRUE",
           "orderBusinessUnit": "NULL",
           "orderSalesType": "WHOLE",
           "orderAuctionFormat": "Open",
           "orderLeaseAccountNr": None,
           "orderLessee": None,
           "orderLine": [
             {
               "orderLineReferenceId": f"SELL{DATAPREP['consignment_id']}",
               "orderLineItem": "V",
               "orderLineUserItemDescription": "2013 Porsche Boxster",
               "orderLineQuantity": -1,
               "orderLineUnitPrice": DATAPREP['seller_unit_price'],
               "orderLineDate": __get_current_time_stampe_with_timezone(),
               "orderLineStatus": "FULFILLED",
               "orderLinePurchaseLocation": "PFSR",
               "orderLineCreditOrderNumber": None,
               "orderLineCreditLineNumber": None,
               "orderLineBidderNr": None,
               "orderLineCustomerOrderNr": None
             },
             {
               "orderLineReferenceId": f"SELL{DATAPREP['consignment_id']}",
               "orderLineItem": "RMSSELL",
               "orderLineUserItemDescription": "RMS Overnight Title Fee",
               "orderLineQuantity": -1,
               "orderLineUnitPrice": DATAPREP['seller_2_unit_price'],
               "orderLineDate": __get_current_time_stampe_with_timezone(),
               "orderLineStatus": "FULFILLED",
               "orderLinePurchaseLocation": "PFSR",
               "orderLineCreditOrderNumber": None,
               "orderLineCreditLineNumber": None,
               "orderLineBidderNr": None,
               "orderLineCustomerOrderNr": None
             }
           ],
           "orderAttachment": [
             {
               "orderAttachmentDocumentCategory": "NOTE",
               "orderAttachmentDocumentText": "This is a test"
             }
           ]
         }
   	
def post_buyer_payload():
   return {
            "consignmentId": DATAPREP['consignment_id'],
            "orderSoldToCustomer": DATAPREP['buyer'],
            "orderBillToCustomer": None,
            "orderThirdPartyRemarketer": None,
            "orderOrderType": "US BUYER",
            "orderReferenceId": f"BUYER{DATAPREP['consignment_id']}",
            "orderSalesChannel": "RMS",
            "orderLateFeeExempt": "TRUE",
            "orderBusinessUnit": "NULL",
            "orderSalesType": "WHOLE",
            "orderAuctionFormat": "Closed",
            "orderLeaseAccountNr": None,
            "orderLessee": None,
            "orderLine": 
            [
              {
                "orderLineReferenceId": f"BUY{DATAPREP['consignment_id']}",
                "orderLineItem": "V",
                "orderLineUserItemDescription": "2014 Honda Accord Hybrid",
                "orderLineQuantity": 1,
                "orderLineUnitPrice": DATAPREP['buyer_unit_price'],
                "orderLineDate": __get_current_time_stampe_with_timezone(),
                "orderLineStatus": "FULFILLED",
                "orderLinePurchaseLocation": "PFSR",
                "orderLineCreditOrderNumber": None,
                "orderLineCreditLineNumber": None,
                "orderLineBidderNr": None,
                "orderLineCustomerOrderNr": None
              },
              {
                "orderLineReferenceId": f"BUY{DATAPREP['consignment_id']}", 
                "orderLineItem": "RMSBUY",
                "orderLineUserItemDescription": "RMS Buy Fee",
                "orderLineQuantity": 1,
                "orderLineUnitPrice": DATAPREP['buyer_2_unit_price'],
                "orderLineDate": __get_current_time_stampe_with_timezone(),
                "orderLineStatus": "FULFILLED",
                "orderLinePurchaseLocation": "PFSR",
                "orderLineCreditOrderNumber": None,
                "orderLineCreditLineNumber": None,
                "orderLineBidderNr": None,
                "orderLineCustomerOrderNr": None
              },
              {
                "orderLineReferenceId": f"BUY{DATAPREP['consignment_id']}",
                "orderLineItem": "RMS_SERVICE",
                "orderLineUserItemDescription": "RMS Overnight Title Fee",
                "orderLineQuantity": 1,
                "orderLineUnitPrice": DATAPREP['buyer_3_unit_price'],
                "orderLineDate": __get_current_time_stampe_with_timezone(),
                "orderLineStatus": "FULFILLED",
                "orderLinePurchaseLocation": "HOND",
                "orderLineCreditOrderNumber": None,
                "orderLineCreditLineNumber": None,
                "orderLineBidderNr": None,
                "orderLineCustomerOrderNr": None
              }
            ],
            "orderAttachment": [
              {
                "orderAttachmentDocumentCategory": "NOTE",
                "orderAttachmentDocumentText": "This is a test"
              }
            ]
          }

    
def __get_current_time_stampe_with_timezone():
     from datetime import datetime
     return datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%f")

def __get_current_date():
     from datetime import datetime   
     return datetime.now().strftime("%Y-%m-%d")
     
def __get_current_year():
   import datetime
   return (datetime.datetime.now().year)
   
def __get_current_week():
     import datetime 
     return (str(datetime.date.today().isocalendar()[1]))
   
   
   
