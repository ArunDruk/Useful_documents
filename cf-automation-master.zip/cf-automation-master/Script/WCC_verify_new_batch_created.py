﻿from dbhelper import *
from ebiz import *
import web_utils

class WCC_verify_new_batch_created(Ebiz):
  
 def login(self):
    self.login_user="pburugupal"
    prop=["idStr","ObjectType"]
    val=["userid","TextBox"]
    self.page.FindChild(prop,val,30).SetText(self.login_user) 
#    self.log_message_web("Set User ID:  "+self.login_user+" Successful")
    self.page.Keys("[Tab]")
    prop=["idStr","ObjectType"]
    val=["password","PasswordBox"]
    self.page.FindChild(prop,val,30).SetText(self.testConfig['ebiz']['password']) 
    self.page.wait_until_loaded()
    prop=["ObjectIdentifier","ObjectType"]
    val=["Log In","SubmitButton"]
    self.page.FindChild(prop,val,30).Click() 
    
    self.wait_until_page_loaded()    
    
 def goto_url(self,url):
   super().goto_url(self.testConfig['ebiz']['webCenCapUrl'])
   
 def logout(self):
   self.page.wait()
   self.page.FindChild("idStr","pt1:pt_np1:linkLogout",20).Click()
   web_utils.log_checkpoint("Completed WCI Capture Application Validation Successfully: Logging out from Applications",500,self.page)
   Sys.Browser("iexplore").Page("https://*.manheim.com/dc-client/faces/dc-client.jspx?*").Close()
   
 def wait_until_page_loaded(self):
   Delay(5000)  
   
 def action(self,book):
  app = book.Sheets.item["mail_1NonPO"]   
  Delay(6000)
  if Sys.Browser("iexplore").Page(self.testConfig['ebiz']['webCenCapUrl']+"*").Alert.Exists:
    Sys.Browser("iexplore").Page(self.testConfig['ebiz']['webCenCapUrl']+"*").Alert.Button("OK").Click()
    Delay(2000)
  self.wait_until_page_loaded()
  if Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).Tab("WebCenter Capture - Internet Explorer").Window("Shell DocObject View", "", 1).Window("Internet Explorer_Server", "", 1).Window("Java Plug-in Control Window", "", 1).AWTObject("PluginEmbeddedFrame", "").SwingObject("RMCApplet", "", 0).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("FormManagerPanel", "", 0).SwingObject("JPanel", "", 0).SwingObject("ExistingSessionPanel", "", 0).SwingObject("RoundedCornerPanel", "", 0).Exists:
    Sys.Browser("iexplore").BrowserWindow(0).Keys("[Enter]")
    Delay(2000)
  # Check security warning window exists
  security_wnd=Sys.Browser("iexplore").WaitSwingObject("JDialog", "Security Warning", -1, 1,10000)  
  if security_wnd.Exists:
    Sys.Browser("iexplore").SwingObject("JDialog", "Security Warning", -1, 1).FindChild("AWTComponentAccessibleName","I accept the risk and want to run this application.",30).Click()
    Sys.Browser("iexplore").SwingObject("JDialog", "Security Warning", -1, 1).Keys("[Enter]")
  Delay(2000)
  self.wait_until_page_loaded()
  if Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).Tab("WebCenter Capture - Internet Explorer").Window("Shell DocObject View", "", 1).Window("Internet Explorer_Server", "", 1).Window("Java Plug-in Control Window", "", 1).AWTObject("PluginEmbeddedFrame", "").SwingObject("RMCApplet", "", 0).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("FormManagerPanel", "", 0).SwingObject("JPanel", "", 0).SwingObject("ExistingSessionPanel", "", 0).SwingObject("RoundedCornerPanel", "", 0).Exists:
    Sys.Browser("iexplore").BrowserWindow(0).Keys("[Enter]")
  self.wait_until_page_loaded()  
  batch_list=self.page.FindChildEx("JavaClassName","BatchEditForm$30",30,True,90000)
  count =  0
  
  #Enter Applications and Validate the Home Page:
  while not batch_list.Exists:
    Delay(2000)
    batch_list=self.page.Find("JavaClassName","BatchEditForm$30",30) 
    count = count + 1 
    if count == 10:
      self.log_error_message("Unable to Login to WCI Capture Application")    
  web_utils.log_checkpoint("Logged in to Web Center Capture Applications Successfully",500,self.page) 
  Delay(3000)
  Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).FindChild("JavaClassName","VetoableComboBox",40).click()
  delay(1000)
  Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).FindChild("JavaClassName","VetoableComboBox",40).keys(app.Cells.item[2,3])
  web_utils.log_checkpoint("Selected Capture Location Sucessfully",500,self.page)
  b_id = batch_list.Id
  batch_list.FindID(b_id).click() 
  delay(2000) 
  
  # Get Batch Details and Validate for Required Batch:
  batch_name=Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).FindChild("AWTComponentAccessibleName","Batch Name:",40)
  i = 0
  while batch_name.Exists == None: 
    batch_list.FindID(b_id).click()
    i = i + 1
    if i == 4:
      self.log_error_message("Unable to Find Details for the Selected Batch")
      
  batch_name,date_time,batch_notes = self.get_batch_details()
  comp = VarToStr(app.Cells.item[2,1])
  j = 0
  while StrMatches(comp,batch_notes) != True:
#     batch_list.FindID(b_id).click()
     batch_list.Keys("[Down]")
     delay(2000)
     batch_name,date_time,batch_notes = self.get_batch_details()
     j = j + 1
     if j == 5:
       self.log_error_message("Batch Not Created in WCI Capture for the email sent: Test Failed")
  self.log_message_web("Batch Name: "+batch_name)
  self.log_message_web("Batch Creation Date/Time: "+date_time)
  app.Cells.item[2,2]=VarToStr(batch_name)
  web_utils.log_checkpoint("Verified the Batch Details Successfully",500,self.page)
       
# Validate Document Profile and Release the Batch to WFR Form for Verification:
  batch_list.Keys("[Right]")
  self.wait_until_page_loaded()
  Delay(3000)
  pro = ["JavaClassName","wText"]
  val = ["JComboBox","CAIAP Invoices"]
  ImageViewer = Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).FindChild("JavaClassName","ImageViewer",40)
  value = ImageViewer.VisibleOnScreen

  if value == False:  
    delay(2000)
    batch_list.Keys("[Right]")
    self.wait_until_page_loaded()
    Delay(13000)
#    combo_box = Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).FindChild(pro,val,40)
    cnt=Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).FindAllChildren("JavaClassName","JSplitPane",60)
    combo_list=cnt[1].FindAllChildren("AWTComponentName","ComboBox.textField",40)
    self.log_message_web("Invoice Category: "+VarToStr(combo_list[4].wText))
    ImageViewer = Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).FindChild("JavaClassName","ImageViewer",40)
    Sys.HighlightObject(ImageViewer)
    web_utils.log_checkpoint("Verified the Document Profile Details Successfully: Ready to Release",500,self.page)

  else:
      Sys.HighlightObject(ImageViewer)
      web_utils.log_checkpoint("Verified the Document Profile Details Successfully: Ready to Release",500,self.page)


    
#  self.log_message_web("Default Coder: "+VarToStr(combo_list[4].wText))
#  Sys.HighlightObject(combo_box)
#  web_utils.log_checkpoint("Verified the Document Profile Details Successfully: Ready to Release",500,self.page)

  Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).FindChild("AWTComponentAccessibleName","Release",40).Click()
  Delay(10000)
  self.refresh()
  web_utils.log_checkpoint("Click 'Release' button - Successfull for the batch: "+batch_name,500,self.page)
  self.validate_batch_release(app)
#  self.log_message_web("Click 'Release' button successful")


 def get_batch_details(self):
  batch_name=Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).FindChild("AWTComponentAccessibleName","Batch Name:",40).wText
#  self.log_message_web("Batch Name: "+VarToStr(batch_name))
  delay(1000)
#  book.Save()

  date_time=Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).FindChild("AWTComponentAccessibleName","Date/Time Created:",40).wText
#  self.log_message_web("Date Time: "+VarToStr(date_time))
  delay(1000)
  pro = ("JavaClassName","AWTComponentAccessibleName")
  val = ("JTextArea","Batch Notes:")

  batch_notes = Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).FindChild(pro,val,30).wText 
#  self.log_message_web("Batch_Notes: "+VarToStr(batch_notes))
  return batch_name,date_time,batch_notes
  
 def refresh(self):
   url_bar = Sys.Browser("iexplore").BrowserWindow(0).Window("WorkerW", "Navigation Bar", 1).Window("ReBarWindow32", "", 1).Window("Address Band Root", "Address Bar", 1).Window("AddressDisplay Control", "", 1)
#   url_bar.Click()
   delay(1200)
   url_bar.Keys("[F5]")
   self.page.wait_until_loaded()
   if Sys.Browser("iexplore").Page(self.testConfig['ebiz']['webCenCapUrl']+"*").Alert.Exists:
    Sys.Browser("iexplore").Page(self.testConfig['ebiz']['webCenCapUrl']+"*").Alert.Button("OK").Click()
    Delay(2000)
   self.wait_until_page_loaded()
   if Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).Tab("WebCenter Capture - Internet Explorer").Window("Shell DocObject View", "", 1).Window("Internet Explorer_Server", "", 1).Window("Java Plug-in Control Window", "", 1).AWTObject("PluginEmbeddedFrame", "").SwingObject("RMCApplet", "", 0).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("FormManagerPanel", "", 0).SwingObject("JPanel", "", 0).SwingObject("ExistingSessionPanel", "", 0).SwingObject("RoundedCornerPanel", "", 0).Exists:
     Sys.Browser("iexplore").BrowserWindow(0).Keys("[Enter]")
     Delay(2000)
  # Check security warning window exists
   security_wnd=Sys.Browser("iexplore").WaitSwingObject("JDialog", "Security Warning", -1, 1,10000)  
   if security_wnd.Exists:
     Sys.Browser("iexplore").SwingObject("JDialog", "Security Warning", -1, 1).FindChild("AWTComponentAccessibleName","I accept the risk and want to run this application.",30).Click()
     Sys.Browser("iexplore").SwingObject("JDialog", "Security Warning", -1, 1).Keys("[Enter]")
     Delay(2000)
     self.wait_until_page_loaded()
   if Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).Tab("WebCenter Capture - Internet Explorer").Window("Shell DocObject View", "", 1).Window("Internet Explorer_Server", "", 1).Window("Java Plug-in Control Window", "", 1).AWTObject("PluginEmbeddedFrame", "").SwingObject("RMCApplet", "", 0).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("FormManagerPanel", "", 0).SwingObject("JPanel", "", 0).SwingObject("ExistingSessionPanel", "", 0).SwingObject("RoundedCornerPanel", "", 0).Exists:
      Sys.Browser("iexplore").BrowserWindow(0).Keys("[Enter]")
   self.page.wait_until_loaded()
   
 def validate_batch_release(self,app):
    
    batch_list=self.page.FindChildEx("JavaClassName","BatchEditForm$30",30,True,90000)
    b_id = batch_list.Id
    batch_list.FindID(b_id).click() 
    delay(2000)  
  # Get Batch Details and Validate for Required Batch:
    batch_name=Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).FindChild("AWTComponentAccessibleName","Batch Name:",40)
    i = 0
    while batch_name.Exists == None: 
     batch_list.FindID(b_id).click()
     i = i + 1
     if i == 4:
      self.log_error_message("Unable to Validate the Release: Test Failed")
      
    batch_name,date_time,batch_notes = self.get_batch_details()
    if batch_name == VarToStr(app.Cells.item[2,2]):
       self.log_error_message("Unable to Verify the Release for Batch : "+VarToStr(app.Cells.item[2,2])+" Batch Record Still Present - Test Failed")
    web_utils.log_checkpoint("Able to Verify the Release for :"+VarToStr(app.Cells.item[2,2])+" - Batch Record Removed from the Page",500,self.page)
     
     
def test():
   url_bar = Sys.Browser("iexplore").BrowserWindow(0).Window("WorkerW", "Navigation Bar", 1).Window("ReBarWindow32", "", 1).Window("Address Band Root", "Address Bar", 1).Window("AddressDisplay Control", "", 1)
#   url_bar.Click()
   delay(1200)
   url_bar.Keys("[F5]")
#   Sys.Browser("iexplore").BrowserWindow(0).Window("WorkerW", "Navigation Bar", 1).Window("ReBarWindow32", "", 1).Window("Address Band Root", "Address Bar", 1).Window("AddressDisplay Control", "", 1).Keys("[Enter]")
   self.page.wait_until_loaded()  








