﻿from ebiz import *
import web_utils


class tc260160cai_us_ReturnReceipt(Ebiz):
  global rowno, RowCount
  
  def login(self):
    self.login_user="rmaran"
    super().login()
  
  def action(self,book):
    rowno = 2
    app = book.Sheets.item["Invoice"]
    app1 = book.Sheets.item["Requisition"]    
    RowCount = app.UsedRange.Rows.Count    
    self.wait_until_page_loaded()
    web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" iPROC USER')]")  
    Delay(6000)
    self.page.wait()
    self.wait_until_page_loaded()
    web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'iProcurement Home Page')]")
    web_utils.clk_link_by_xpath(self.page,"//a[@id='ICXPOR_RECEIVING_HOME']")
    web_utils.clk_link_by_xpath(self.page,"//a[@id='ReturnItemsLink1']")
    web_utils.set_text(self.page,"//input[@id='ReceiptNumber']",app.cells.Item[rowno,18])
    Delay(2000)
    web_utils.clk_btn_by_xpath(self.page,"//table[@id='SearchMessageComponentLayout']//button[contains(text(),'Go')]")  
    self.wait_until_page_loaded()
    self.page.wait()
    Delay(6000)
#    actual_qty=web_utils.get_content_text_by_xpath(self.page,"//table[@id='ResultsTableRN:Content']//input[@id='N3:QuantityLinkDisabled:0:sw']")
    actual_qty=self.page.EvaluateXPath("//table[@id='ResultsTableRN:Content']//span[@id='N3:QuantityLinkDisabled:0']")[0].innertext
#    actual_qty=web_utils.get_content_text_by_xpath(self.page,"//span[@id='ResultsTableRN']//span[@id='N3:QuantityLinkDisabled:0']")
    self.log_message_web("Actual Quantity: "+VarToStr(actual_qty))
    index = 0
    var = VarToStr(app.Cells.item[rowno,19])
    var1 = var.split(',')
    temp = 0
    while rowno<RowCount+1:
      unit_price = aqConvert.VarToFloat(app1.Cells.item[rowno,7])
      self.page.EvaluateXPath("//table[@id='ResultsTableRN:Content']//input[@id='N3:ReturnQuantity:"+aqConvert.VarToStr(index)+"']")[0].SetText(var1[index])
#      web_utils.set_text(self.page,"//span[@id='ResultsTableRN']//input[@id='N3:ReturnQuantity:']"+aqConvert.VarToStr(index)+"']",var1[index])    
      amount = aqConvert.StrToInt(var1[index])*unit_price
      temp = StrToInt(temp)+amount
      index = index+1
      rowno = rowno+1
    app.Cells.item[2,15] = temp
    self.page.Keys("~x")
    self.wait_until_page_loaded()
    # Enter reason
    web_utils.set_text(self.page,"//input[@id='Reason']","DEFECTIVE/DAMAGED")  
    self.page.wait()
    Delay(5000) 
    self.page.EvaluateXPath("//table[@id='PageFooterTableLayout']//button[@title='Next']")[0].Click()
#    self.page.Keys("~x")
    self.wait_until_page_loaded()
    Delay(5000) 
    self.page.Keys("~m")
    self.wait_until_page_loaded()
    conf_msg=self.page.NativeWebObject.Find("innerText", "Your returns have been submitted.", "div")
    self.log_message_web("Confirmation message found "+aqConvert.VarToStr(conf_msg)) 
    #Click return to Receiving
    web_utils.clk_link_by_xpath(self.page,"//a[@title='Return to Receiving']")
    web_utils.clk_link_by_xpath(self.page,"//a[@id='ReturnItemsLink1']")
    web_utils.set_text(self.page,"//input[@id='ReceiptNumber']",app.cells.Item[2,18])
    web_utils.clk_btn_by_xpath(self.page,"//table[@id='SearchMessageComponentLayout']//button[contains(text(),'Go')]")  
    self.wait_until_page_loaded()    
#    updated_qty=web_utils.get_content_text_by_xpath(self.page,"//table[@id='ResultsTableRN:Content']//span[@id='N3:QuantityLinkDisabled:0']")
#    updated_qty=self.page.EvaluateXPath("//table[@id='ResultsTableRN:Content']//span[@id='N3:QuantityLinkDisabled:0']")[0].innertext
#    self.log_message_web("Updated Quantity: "+VarToStr(updated_qty))
#    if (VarToInt(actual_qty) - VarToInt(app.Cells.item[2,19]) ) == VarToInt(updated_qty):
#      self.log_message_web("Expected Quantity found: "+VarToStr(updated_qty))
#    else:
#      self.log_error_message("Quantity  "+VarToStr(updated_qty)+" is not expected.")        
    book.save()
    del app,app1,RowCount,var,var1,index,rowno,conf_msg
    


