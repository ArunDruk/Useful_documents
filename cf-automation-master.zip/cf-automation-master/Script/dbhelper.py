﻿#import all_routine_list
import traceback
import gvar


def verify_oracle_concurrent_job_status(dsn,user_id,pwd,req_id):      
  try:  
    Found=False 
    adoCon=ADO.CreateADOConnection()
    adoCon.ConnectionString="Provider=MSDASQL.1;Password="+pwd+";Persist Security Info=True;User ID="+user_id+";Data Source="+dsn+""
    adoCon.LoginPrompt=False
    adoCon.Open()    
    sqlQuery =  "select * from FND_CONC_REQ_SUMMARY_V where request_id = '" + req_id + "'"      
    Log.Message(sqlQuery)
    for x in range(0,60):
      rec_set=adoCon.Execute_(sqlQuery)
      rec_set.MoveFirst()
      while (not rec_set.EOF) and (rec_set.Fields.Item["PHASE_CODE"]=='C'):        
        Log.Message("Oracle Concurrent Program Phase Code status :  "+rec_set.Fields.Item["PHASE_CODE"].Value)
        Log.Message("Oracle Concurrent Program Status Code status : "+rec_set.Fields.Item["STATUS_CODE"].Value)              
        Found=True
        rec_set.MoveNext()
      Delay(10000)
      if Found==True:
        break        
  except Exception as e:
      Log.Error("Error : - " + str(e))   
  finally:    
      adoCon.Close()
        
def get_selfAssessed_tax_From_Db(dsn,user_id,pwd,inv_id,Supplier_id):      
      try:  
        Found=False 
        adoCon=ADO.CreateADOConnection()
        adoCon.ConnectionString="Provider=MSDASQL.1;Password="+pwd+";Persist Security Info=True;User ID="+user_id+";Data Source="+dsn+""
        adoCon.LoginPrompt=False
        adoCon.Open()
        Delay(5000)    
        sqlQuery = """select NVL(self_assessed_tax_amount,0) self_assessed_tax_amount 
                        from ap_invoices_all api,ap_suppliers aps
                       where api.vendor_id = aps.vendor_id
                         and api.invoice_num = '%s'  
                         and aps.segment1 = '%s' """
                        
 #       Log.Message("Inv_id"+inv_id+", Sup_id="+Supplier_id+", tax_name="+tax_name)       
                        
        sqlQuery = aqString.Format(sqlQuery,inv_id,Supplier_id)
        Log.Enabled=True
        Log.Message("Executing SQL Query In Oracle Database " +sqlQuery) 
        Log.Enabled=False         
        for x in range(0,10):
          rec_set=adoCon.Execute_(sqlQuery)
          rec_set.MoveFirst()
                                
          while (not rec_set.EOF):
            Found=True
            SAAmount=aqConvert.VartoStr(rec_set.Fields.Item["self_assessed_tax_amount"].Value)
            rec_set.MoveNext()
          if Found==True:
            return SAAmount
            break        
      except Exception as e:
          Log.Enabled=True 
          Log.Error("Error : - " + traceback.format_exc())  
          Log.Enabled=False 
      finally:    
          adoCon.Close()
      
      
def verify_oracle_journal_status(journal_name):      
    try:  
      Found=False 
      adoCon=ADO.CreateADOConnection()
      adoCon.ConnectionString="Provider=MSDASQL.1;Password=oracle123;Persist Security Info=True;User ID=appsqauser;Data Source=TMNH2I"
      adoCon.LoginPrompt=False
      adoCon.Open()    
      sqlQuery = "Select Name,Description,JE_Header_ID,JE_Source,Period_Name,Currency_code,Status,Creation_date,posted_date,"\
                  "ACCRUAL_REV_STATUS,running_total_dr,running_total_cr,running_total_accounted_dr,running_total_accounted_cr "\
                  "from gl_je_headers where name = '"+journal_name+"'"
      Log.Message("Executing SQL query" +(sqlQuery))
      for x in range(0,60):
        rec_set=adoCon.Execute_(sqlQuery)
        rec_set.MoveFirst()
        while (not rec_set.EOF):
          Log.Enabled=True
          Log.Message("Journal Information : Journal_Name is "+(rec_set.Fields.Item["NAME"].Value))        
          Log.Message("Journal Description is "+aqConvert.VartoStr(rec_set.Fields.Item["DESCRIPTION"].Value))
          Log.Message("Journal Header_ID is "+aqConvert.InttoStr(rec_set.Fields.Item["JE_HEADER_ID"].Value))
          Log.Message("Journal Source is "+(rec_set.Fields.Item["JE_SOURCE"].Value))
          Log.Message("Period Name is "+(rec_set.Fields.Item["PERIOD_NAME"].Value))
          Log.Message("Currency Code is "+(rec_set.Fields.Item["CURRENCY_CODE"].Value))
          Log.Message("Journal Status is "+(rec_set.Fields.Item["STATUS"].Value))
          Log.Message("Journal creation date is "+aqConvert.DateTimeToStr(rec_set.Fields.Item["CREATION_DATE"].Value))
          Log.Message("Journal Posted date is "+aqConvert.DateTimeToStr(rec_set.Fields.Item["POSTED_DATE"].Value))
          Log.Message("Journal Reverse Status is "+aqConvert.VarToStr(rec_set.Fields.Item["ACCRUAL_REV_STATUS"].Value))
          Log.Message("Running Total Debit "+aqConvert.InttoStr(rec_set.Fields.Item["RUNNING_TOTAL_DR"].Value)) 
          Log.Message("Running Total Credit "+aqConvert.InttoStr(rec_set.Fields.Item["RUNNING_TOTAL_CR"].Value))  
          Log.Message("Running Total Accounted Debit "+aqConvert.InttoStr(rec_set.Fields.Item["RUNNING_TOTAL_ACCOUNTED_DR"].Value))  
          Log.Message("Running Total Accounted Credit "+aqConvert.InttoStr(rec_set.Fields.Item["RUNNING_TOTAL_ACCOUNTED_CR"].Value))               
          Log.Enabled=False
          Found=True
          rec_set.MoveNext()
        if Found==True:
          break        
    except Exception as e:
        Log.Error("Error : - " + traceback.format_exc())   
    finally:    
        adoCon.Close()
        
        

def verify_oracle_payment_status(dsn,user_id,pwd,invoice_num):      
    try:  
      Found=False 
      adoCon=ADO.CreateADOConnection()
      adoCon.ConnectionString="Provider=MSDASQL.1;Password="+pwd+";Persist Security Info=True;User ID="+user_id+";Data Source="+dsn+""
      adoCon.LoginPrompt=False
      adoCon.Open()    
      sqlQuery = """ SELECT  asa.segment1 "Supplier Number",
         asa.vendor_name "Supplier Name",
         aia.invoice_num,
         aia.source "Invoice Source",
         aia.Invoice_type_lookup_code "Invoice Type" ,
         aia.invoice_amount,
         APPS.AP_INVOICES_PKG.GET_APPROVAL_STATUS (aia.INVOICE_ID,
                                              aia.INVOICE_AMOUNT,
                                              aia.PAYMENT_STATUS_FLAG,
                                              aia.INVOICE_TYPE_LOOKUP_CODE) "Invoice Acct Status",
         aipa.AMOUNT "Payment Amount",
         aca.CURRENCY_CODE "Payment Currency",
         aca.check_number "Document Number",
         aca.STATUS_LOOKUP_CODE "Payment Reconcilation Status"
         FROM ap_checks_all aca,
         ap_invoice_payments_all aipa,
         ap_invoices_all aia,
         ap_suppliers asa
         WHERE aca.check_id = aipa.check_id
         AND aipa.invoice_id = aia.invoice_id
         AND aia.vendor_id = asa.vendor_id
         AND aia.invoice_num = '%s' """
      sqlQuery = aqString.Format(sqlQuery,invoice_num) 
      Log.Enabled=True
      Log.Message("Executing SQL Query In Oracle Database" +(sqlQuery)) 
      Log.Enabled=False      
      for x in range(0,60):
        rec_set=adoCon.Execute_(sqlQuery)
        rec_set.MoveFirst()
        while (not rec_set.EOF):
          Log.Enabled=True
          Log.Message(" Invoice Information : Supplier Number is "+(rec_set.Fields.Item["Supplier Number"].Value))        
          Log.Message("Supplier Name is "+aqConvert.VartoStr(rec_set.Fields.Item["Supplier Name"].Value))
          Log.Message("Invoice Number is "+aqConvert.VartoStr(rec_set.Fields.Item["invoice_num"].Value))
          Log.Message("Invoice Source is "+(rec_set.Fields.Item["Invoice Source"].Value))
          Log.Message("Invoice Type is "+(rec_set.Fields.Item["Invoice Type"].Value))
          Log.Message("Invoice Amount is "+aqConvert.VartoStr(rec_set.Fields.Item["INVOICE_AMOUNT"].Value))
          Log.Message("Invoice Accounting Status is "+(rec_set.Fields.Item["Invoice Acct Status"].Value))
          Log.Message("Payment Amount is "+aqConvert.VartoStr(rec_set.Fields.Item["Payment Amount"].Value))
          Log.Message("Payment Currency is "+(rec_set.Fields.Item["Payment Currency"].Value))
          Log.Message("Document Number is "+aqConvert.VartoStr(rec_set.Fields.Item["Document Number"].Value))
          Log.Message("Payment Reconcilation Status is "+(rec_set.Fields.Item["Payment Reconcilation Status"].Value))
          Log.Enabled=False
          Found=True
          rec_set.MoveNext()
        if Found==True:
          break        
    except Exception as e:
        Log.Error("Error : - " + traceback.format_exc())   
    finally:    
        adoCon.Close()

      
        
def verify_invoice_accting_posting_status(dsn,user_id,pwd,invoice_num):      
    try:  
      Found=False 
      adoCon=ADO.CreateADOConnection()
      adoCon.ConnectionString="Provider=MSDASQL.1;Password="+gvar.config['oracle_db']['pwd ']+";Persist Security Info=True;User ID="+gvar.config['oracle_db']['userid']+";Data Source="+gvar.config['oracle_db']['dsn']+""
      adoCon.LoginPrompt=False
      adoCon.Open()    
      sqlQuery = """ SELECT  asa.segment1 "Supplier Number",
         asa.vendor_name "Supplier Name",
         aia.invoice_num,
         aia.source "Invoice Source",
         aia.Invoice_type_lookup_code "Invoice Type" ,
         aia.invoice_amount,
         APPS.AP_INVOICES_PKG.GET_APPROVAL_STATUS (aia.INVOICE_ID,
                                              aia.INVOICE_AMOUNT,
                                              aia.PAYMENT_STATUS_FLAG,
                                              aia.INVOICE_TYPE_LOOKUP_CODE) "Invoice Acct Status",
         APPS.ap_invoices_pkg.get_posting_status(aia.invoice_id) "POSTING STATUS"                                     
         FROM ap_checks_all aca,
         ap_invoice_payments_all aipa,
         ap_invoices_all aia,
         ap_suppliers asa
         WHERE aca.check_id = aipa.check_id
         AND aipa.invoice_id = aia.invoice_id
         AND aia.vendor_id = asa.vendor_id
         AND aia.invoice_num = '%s' """
      sqlQuery = aqString.Format(sqlQuery,invoice_num)
      Log.Enabled=True
      Log.Message("Executing SQL Query In Oracle Database" +(sqlQuery)) 
      Log.Enabled=False         
      for x in range(0,60):
        rec_set=adoCon.Execute_(sqlQuery)
        rec_set.MoveFirst()
        while (not rec_set.EOF):
          Log.Enabled=True
          Log.Message(" Invoice Information : Supplier Number is "+(rec_set.Fields.Item["Supplier Number"].Value))        
          Log.Message("Supplier Name is "+aqConvert.VartoStr(rec_set.Fields.Item["Supplier Name"].Value))
          Log.Message("Invoice Number is "+aqConvert.VartoStr(rec_set.Fields.Item["invoice_num"].Value))
          Log.Message("Invoice Source is "+(rec_set.Fields.Item["Invoice Source"].Value))
          Log.Message("Invoice Type is "+(rec_set.Fields.Item["Invoice Type"].Value))
          Log.Message("Invoice Amount is "+aqConvert.VartoStr(rec_set.Fields.Item["INVOICE_AMOUNT"].Value))
          Log.Message("Invoice Accounting Status is "+(rec_set.Fields.Item["Invoice Acct Status"].Value))
          Log.Message("Invoice Posting Status is "+aqConvert.VartoStr(rec_set.Fields.Item["Posting Status"].Value))
          Log.Enabled=False
          Found=True
          rec_set.MoveNext()
        if Found==True:
          break        
    except Exception as e:
        Log.Error("Error : - " + traceback.format_exc())   
    finally:    
        adoCon.Close()



def verify_cai_journal_status(dsn,user_id,pwd,jrnl_desc):      
    try:  
      Found=False 
      adoCon=ADO.CreateADOConnection()
      adoCon.ConnectionString="Provider=MSDASQL.1;Password="+pwd+";Persist Security Info=True;User ID="+user_id+";Data Source="+dsn+""
      adoCon.LoginPrompt=False
      adoCon.Open()    
      sqlQuery = "Select Name,Description,JE_Header_ID,JE_Source,Period_Name,Currency_code,Status,Creation_date,posted_date,"\
                  "ACCRUAL_REV_STATUS,running_total_dr,running_total_cr,running_total_accounted_dr,running_total_accounted_cr "\
                  "from gl_je_headers where Description like '%"+VarToStr(jrnl_desc)+":'"
      Log.Enabled=True
      Log.Message("Executing SQL Query In Oracle Database" +(sqlQuery)) 
      Log.Enabled=False
      for x in range(0,60):
        rec_set=adoCon.Execute_(sqlQuery)
        rec_set.MoveFirst()
        while (not rec_set.EOF):
          Log.Enabled=True
          Log.Message("Journal Information : Journal_Name is "+(rec_set.Fields.Item["NAME"].Value))        
          Log.Message("Journal Description is "+aqConvert.VartoStr(rec_set.Fields.Item["DESCRIPTION"].Value))
          Log.Message("Journal Header_ID is "+aqConvert.InttoStr(rec_set.Fields.Item["JE_HEADER_ID"].Value))
          Log.Message("Journal Source is "+(rec_set.Fields.Item["JE_SOURCE"].Value))
          Log.Message("Period Name is "+(rec_set.Fields.Item["PERIOD_NAME"].Value))
          Log.Message("Currency Code is "+(rec_set.Fields.Item["CURRENCY_CODE"].Value))
          Log.Message("Journal Status is "+(rec_set.Fields.Item["STATUS"].Value))
          Log.Message("Journal creation date is "+aqConvert.DateTimeToStr(rec_set.Fields.Item["CREATION_DATE"].Value))
          Log.Message("Journal Posted date is "+aqConvert.DateTimeToStr(rec_set.Fields.Item["POSTED_DATE"].Value))
          Log.Message("Journal Reverse Status is "+aqConvert.VarToStr(rec_set.Fields.Item["ACCRUAL_REV_STATUS"].Value))
          Log.Message("Running Total Debit "+aqConvert.InttoStr(rec_set.Fields.Item["RUNNING_TOTAL_DR"].Value)) 
          Log.Message("Running Total Credit "+aqConvert.InttoStr(rec_set.Fields.Item["RUNNING_TOTAL_CR"].Value))  
          Log.Message("Running Total Accounted Debit "+aqConvert.InttoStr(rec_set.Fields.Item["RUNNING_TOTAL_ACCOUNTED_DR"].Value))  
          Log.Message("Running Total Accounted Credit "+aqConvert.InttoStr(rec_set.Fields.Item["RUNNING_TOTAL_ACCOUNTED_CR"].Value))               
          Log.Enabled=False
          Found=True
          rec_set.MoveNext()
        if Found==True:
          break        
    except Exception as e:
        Log.Error("Error : - " + traceback.format_exc())   
    finally:    
        adoCon.Close()



def get_invoice_id(dsn,user_id,pwd,invoice_num):      
    try:  
      Found=False 
      adoCon=ADO.CreateADOConnection()
      adoCon.ConnectionString="Provider=MSDASQL.1;Password="+pwd+";Persist Security Info=True;User ID="+user_id+";Data Source="+dsn+""
      adoCon.LoginPrompt=False
      adoCon.Open()    
      sqlQuery = "select invoice_id from ap_invoices_all where invoice_num = '%s'"
      sqlQuery = aqString.Format(sqlQuery,invoice_num) 
      Log.Enabled=True
      Log.Message("Executing SQL Query In Oracle Database to retrieve Item Key" +(sqlQuery)) 
      Log.Enabled=False      
      for x in range(0,60):
        rec_set=adoCon.Execute_(sqlQuery)
        rec_set.MoveFirst()
        while (not rec_set.EOF):
          Log.Enabled=True
          Log.Message(" Item Key for the Invoice: Invoice ID  "+aqConvert.FloatToStr(rec_set.Fields.Item["INVOICE_ID"].Value))        
          Log.Enabled=False
          key = (rec_set.Fields.Item["INVOICE_ID"].Value)
          Found=True
          return key
          rec_set.MoveNext()
        if Found==True:
          break        
    except Exception as e:
        Log.Error("Error : - " + traceback.format_exc())   
    finally:    
        adoCon.Close()

def verify_subledger_accting_information(dsn,user_id,pwd,invoice_num):      
        try:  
          Found=False 
          adoCon=ADO.CreateADOConnection()
          adoCon.ConnectionString="Provider=MSDASQL.1;Password="+pwd+";Persist Security Info=True;User ID="+user_id+";Data Source="+dsn+""
          adoCon.LoginPrompt=False
          adoCon.Open()    
          sqlQuery = """ SELECT DISTINCT XEH.* FROM XLA_AE_HEADERS XEH ,AP_INVOICES_ALL AI ,XLA_EVENTS XE ,
             XLA.XLA_TRANSACTION_ENTITIES XTE
             WHERE XTE.APPLICATION_ID        =200
             AND XEH.APPLICATION_ID          =200
             AND XE.APPLICATION_ID           =200
             AND XE.ENTITY_ID                =XTE.ENTITY_ID
             AND XE.EVENT_ID                 =XEH.EVENT_ID
             AND XTE.ENTITY_ID               =XEH.ENTITY_ID
             AND XTE.LEDGER_ID               =AI.SET_OF_BOOKS_ID
             AND XTE.ENTITY_CODE             ='AP_INVOICES'
             AND NVL(XTE.SOURCE_ID_INT_1,-99)=AI.INVOICE_ID
             AND INVOICE_NUM = '%s'
             order by XEH.EVENT_ID ,
             XEH.AE_HEADER_ID ASC;"""
          sqlQuery = aqString.Format(sqlQuery,invoice_num)
          Log.Enabled=True
          Log.Message("Executing SQL Query In Oracle Database" +(sqlQuery)) 
          Log.Enabled=False        
          for x in range(0,60):
            rec_set=adoCon.Execute_(sqlQuery)
            rec_set.MoveFirst()
            while (not rec_set.EOF):
              Log.Enabled=True
              Log.Message(" SLA Information : SLA Event_ID is "+aqConvert.VartoStr(rec_set.Fields.Item["EVENT_ID"].Value))        
              Log.Message("SLA_EVENT_TYPE_CODE is "+aqConvert.VartoStr(rec_set.Fields.Item["EVENT_TYPE_CODE"].Value))
              Log.Message("ACCOUNTING_DATE is "+aqConvert.VartoStr(rec_set.Fields.Item["ACCOUNTING_DATE"].Value))
              Log.Message("ACCOUNTING_ENTRY_STATUS_CODE is "+aqConvert.VartoStr(rec_set.Fields.Item["ACCOUNTING_ENTRY_STATUS_CODE"].Value))
              Log.Message("ACCOUNTING_ENTRY_TYPE_CODE is "+aqConvert.VartoStr(rec_set.Fields.Item["ACCOUNTING_ENTRY_TYPE_CODE"].Value))
              Log.Message("GL_TRANSFER_STATUS_CODE is "+aqConvert.VartoStr(rec_set.Fields.Item["GL_TRANSFER_STATUS_CODE"].Value))
              Log.Message("GL_TRANSFER_DATE is "+aqConvert.VartoStr(rec_set.Fields.Item["GL_TRANSFER_DATE"].Value))
              Log.Message("JE_CATEGORY_NAME is "+aqConvert.VartoStr(rec_set.Fields.Item["JE_CATEGORY_NAME"].Value))
              Log.Message("PRODUCT_RULE_CODE is "+aqConvert.VartoStr(rec_set.Fields.Item["PRODUCT_RULE_CODE"].Value))
              Log.Message("DESCRIPTION is "+aqConvert.VartoStr(rec_set.Fields.Item["DESCRIPTION"].Value))
              Log.Enabled=False
              Found=True
              rec_set.MoveNext()
            if Found==True:
              break        
        except Exception as e:
            Log.Error("Error : - " + traceback.format_exc())   
        finally:    
            adoCon.Close()

            
def vfy_oracle_concurrent_job_status(dsn,user_id,pwd,req_id):      
     try:  
       Found=False 
       adoCon=ADO.CreateADOConnection()
       adoCon.ConnectionString="Provider=MSDASQL.1;Password="+pwd+";Persist Security Info=True;User ID="+user_id+";Data Source="+dsn+""
       adoCon.LoginPrompt=False
       adoCon.Open()    
       sqlQuery =  "select * from apps.FND_CONC_REQ_SUMMARY_V where request_id = '" + req_id + "'"      
       Log.Message(sqlQuery)
       for x in range(0,240):
         rec_set=adoCon.Execute_(sqlQuery)
         rec_set.MoveFirst()
         while (not rec_set.EOF) and (rec_set.Fields.Item["PHASE_CODE"]=='C'):     
           Log.Enabled = True   
           Log.Message("Oracle Concurrent Program Phase Code status :  "+rec_set.Fields.Item["PHASE_CODE"].Value)
           Log.Message("Oracle Concurrent Program Status Code status : "+rec_set.Fields.Item["STATUS_CODE"].Value)  
           Log.Enabled = False            
           Found=True
           rec_set.MoveNext()
         Delay(10000)
         if Found==True:
           break        
     except Exception as e:
          Log.Message("Error : - " + str(e))   
     finally:    
         adoCon.Close()

         
         
def verify_excel_invoice_info(dsn,user_id,pwd,invoice_num):      
    try:  
      Found=False 
      adoCon=ADO.CreateADOConnection()
      adoCon.ConnectionString="Provider=MSDASQL.1;Password="+pwd+";Persist Security Info=True;User ID="+user_id+";Data Source="+dsn+""
      adoCon.LoginPrompt=False
      adoCon.Open()    
      sqlQuery = """ select aps.vendor_name,aps.segment1,
                     aia.INVOICE_NUM,aia.INVOICE_ID,
                     aia.AMOUNT_APPLICABLE_TO_DISCOUNT,
                     aia.INVOICE_CURRENCY_CODE,
                     aia.INVOICE_DATE,aia.SOURCE,
                     aia.INVOICE_TYPE_LOOKUP_CODE,
                     aia.PAYMENT_METHOD_CODE,aia.PAYMENT_STATUS_FLAG  
                     from apps.ap_invoices_all aia,
                     apps.ap_suppliers aps
                     where 1=1
                     and aia.vendor_id = aps.vendor_id
                     and invoice_num = '%s' """
      sqlQuery = aqString.Format(sqlQuery,invoice_num)
      Log.Enabled=True
      Log.Message("Executing SQL Query In Oracle Database" +(sqlQuery)) 
      Log.Enabled=False         
      for x in range(0,60):
        rec_set=adoCon.Execute_(sqlQuery)
        rec_set.MoveFirst()
        while (not rec_set.EOF):
          Log.Enabled=True
          Log.Message(" Invoice Information : Supplier Name is "+aqConvert.VartoStr(rec_set.Fields.Item["vendor_name"].Value))        
          Log.Message("Supplier Number is "+aqConvert.VartoStr(rec_set.Fields.Item["segment1"].Value))
          Log.Message("Invoice Number is "+aqConvert.VartoStr(rec_set.Fields.Item["invoice_num"].Value))
          Log.Message("Invoice ID is "+aqConvert.VartoStr(rec_set.Fields.Item["invoice_id"].Value))
          Log.Message("Invoice Amount is "+aqConvert.VartoStr(rec_set.Fields.Item["amount_applicable_to_discount"].Value))
          Log.Message("Invoice Currency Code is "+aqConvert.VartoStr(rec_set.Fields.Item["invoice_currency_code"].Value))
          Log.Message("Invoice Date is "+aqConvert.VartoStr(rec_set.Fields.Item["invoice_date"].Value))
          Log.Message("Invoice Source is "+aqConvert.VartoStr(rec_set.Fields.Item["source"].Value))
          Log.Message("Invoice Type is "+aqConvert.VartoStr(rec_set.Fields.Item["invoice_type_lookup_code"].Value))
          Log.Message("Payment Method is "+aqConvert.VartoStr(rec_set.Fields.Item["payment_method_code"].Value))
          Log.Message("Payment Stauts Flag is "+aqConvert.VartoStr(rec_set.Fields.Item["payment_Status_flag"].Value))
          Log.Enabled=False
          Found=True
          invoice_no = (rec_set.Fields.Item["invoice_num"].Value)
          rec_set.MoveNext()
          return invoice_no
        if Found==True:
          break        
    except Exception as e:
        Log.Error("Error : - " + traceback.format_exc())   
    finally:    
        adoCon.Close()
        
def verify_costar_invoice_info(dsn,user_id,pwd,invoice_num):      
    try:  
      Found=False 
      adoCon=ADO.CreateADOConnection()
      adoCon.ConnectionString="Provider=MSDASQL.1;Password="+pwd+";Persist Security Info=True;User ID="+user_id+";Data Source="+dsn+""
      adoCon.LoginPrompt=False
      adoCon.Open()    
      sqlQuery = """ select aps.vendor_name,aps.segment1,
                     aia.INVOICE_NUM,aia.INVOICE_ID,
                     aia.AMOUNT_APPLICABLE_TO_DISCOUNT,
                     aia.INVOICE_CURRENCY_CODE,
                     aia.INVOICE_DATE,aia.SOURCE,
                     aia.INVOICE_TYPE_LOOKUP_CODE,
                     aia.PAYMENT_METHOD_CODE,aia.PAYMENT_STATUS_FLAG  
                     from apps.ap_invoices_all aia,
                     apps.ap_suppliers aps
                     where 1=1
                     and aia.vendor_id = aps.vendor_id
                     and invoice_num = '%s' """
      sqlQuery = aqString.Format(sqlQuery,invoice_num)
      Log.Enabled=True
      Log.Message("Executing SQL Query In Oracle Database" +(sqlQuery)) 
      Log.Enabled=False         
      for x in range(0,60):
        rec_set=adoCon.Execute_(sqlQuery)
        rec_set.MoveFirst()
        while (not rec_set.EOF):
          Log.Enabled=True
          Log.Message(" Invoice Information : Supplier Name is "+aqConvert.VartoStr(rec_set.Fields.Item["vendor_name"].Value))        
          Log.Message("Supplier Number is "+aqConvert.VartoStr(rec_set.Fields.Item["segment1"].Value))
          Log.Message("Invoice Number is "+aqConvert.VartoStr(rec_set.Fields.Item["invoice_num"].Value))
          Log.Message("Invoice ID is "+aqConvert.VartoStr(rec_set.Fields.Item["invoice_id"].Value))
          Log.Message("Invoice Amount is "+aqConvert.VartoStr(rec_set.Fields.Item["amount_applicable_to_discount"].Value))
          Log.Message("Invoice Currency Code is "+aqConvert.VartoStr(rec_set.Fields.Item["invoice_currency_code"].Value))
          Log.Message("Invoice Date is "+aqConvert.VartoStr(rec_set.Fields.Item["invoice_date"].Value))
          Log.Message("Invoice Source is "+aqConvert.VartoStr(rec_set.Fields.Item["source"].Value))
          Log.Message("Invoice Type is "+aqConvert.VartoStr(rec_set.Fields.Item["invoice_type_lookup_code"].Value))
          Log.Message("Payment Method is "+aqConvert.VartoStr(rec_set.Fields.Item["payment_method_code"].Value))
          Log.Message("Payment Stauts Flag is "+aqConvert.VartoStr(rec_set.Fields.Item["payment_Status_flag"].Value))
          Log.Enabled=False
          Found=True
          invoice_no = (rec_set.Fields.Item["invoice_num"].Value)
          rec_set.MoveNext()
          return invoice_no
        if Found==True:
          break        
    except Exception as e:
        Log.Error("Error : - " + traceback.format_exc())   
    finally:    
        adoCon.Close()

        
def verify_journal_import_details(dsn,user_id,pwd,batch_name):      
    try:  
      Found=False 
      adoCon=ADO.CreateADOConnection()
      adoCon.ConnectionString="Provider=MSDASQL.1;Password="+pwd+";Persist Security Info=True;User ID="+user_id+";Data Source="+dsn+""
      adoCon.LoginPrompt=False
      adoCon.Open()    
# Aruna Gutha, 2021Q2-3, Added case statement to determine journal future period status for US473210
      sqlQuery = """SELECT distinct gl.je_line_num,jb.NAME, gh.period_name, gjs.USER_JE_SOURCE_NAME, gjc.user_je_category_name,
                 gh.currency_code, gc.concatenated_segments, gl.entered_cr,
                 gl.entered_dr, gl.accounted_cr, gl.accounted_dr , gh.status,gp.period_name current_period,
                 CASE
                      WHEN gh.period_name <> gp.period_name AND gh.status = 'P' THEN
                        'POSTED_IN_VALID'
                 END status_value 
                 FROM apps.gl_je_batches jb,
                 apps.gl_je_headers gh,
                 apps.gl_je_lines gl,
                 apps.gl_code_combinations_kfv gc,
                 apps.gl_je_sources gjs,
                 apps.GL_JE_CATEGORIES gjc,
                 apps.gl_periods gp
                 WHERE jb.je_batch_id = gh.je_batch_id
                 AND gh.je_header_id = gl.je_header_id
                 AND gl.code_combination_id = gc.code_combination_id
                 AND gjc.JE_CATEGORY_NAME=gh.JE_CATEGORY
                 AND gh.je_source=gjs.je_source_name
                 AND trunc (sysdate) between gp.start_date and gp.end_date
                 AND jb.NAME like '%s'
                 ORDER BY gl.je_line_num  ASC """
      sqlQuery = aqString.Format(sqlQuery,batch_name)
      Log.Enabled=True
      Log.Message("Executing SQL Query In Oracle Database " +sqlQuery) 
      Log.Enabled=False
               
      for x in range(0,60):
        rec_set=adoCon.Execute_(sqlQuery)
        rec_set.MoveFirst()
        while (not rec_set.EOF):
          Log.Enabled=True
          Log.Message(" Journal Information : Journal Line Number  "+aqConvert.VartoStr(rec_set.Fields.Item["JE_LINE_NUM"].Value))
          Log.Message(" Journal Batch Name is "+aqConvert.VartoStr(rec_set.Fields.Item["Name"].Value))        
          Log.Message("Period Name is "+aqConvert.VartoStr(rec_set.Fields.Item["period_name"].Value))
          Log.Message("JE_Source is "+aqConvert.VartoStr(rec_set.Fields.Item["user_je_source_name"].Value))
          Log.Message("JE_Category is "+aqConvert.VartoStr(rec_set.Fields.Item["user_je_category_name"].Value))
          Log.Message("Currency_Code is "+aqConvert.VartoStr(rec_set.Fields.Item["currency_code"].Value))
          Log.Message("Accounting Code Combination is "+aqConvert.VartoStr(rec_set.Fields.Item["concatenated_segments"].Value))
          Log.Message("Entered Credit Amount is "+aqConvert.InttoStr(rec_set.Fields.Item["entered_cr"].Value))
          Log.Message("Entered Debit Amount is "+aqConvert.InttoStr(rec_set.Fields.Item["entered_dr"].Value))
          Log.Message("Accounted Credit Amount is "+aqConvert.InttoStr(rec_set.Fields.Item["accounted_cr"].Value))
          Log.Message("Accounted Debit Amount is "+aqConvert.InttoStr(rec_set.Fields.Item["accounted_dr"].Value))
          Log.Message("Journal Posting Status is "+aqConvert.VartoStr(rec_set.Fields.Item["status"].Value))
# Aruna Gutha, 2021Q2-3, Added status_value for US473210
          status_value=aqConvert.VartoStr(rec_set.Fields.Item["status_value"].Value)
          Log.Enabled=False
          Found=True
          rec_set.MoveNext()
        if Found==True:
          break        
    except Exception as e:
        Log.Enabled=True 
        Log.Error("Error : - " + traceback.format_exc())  
        Log.Enabled=False 
    finally:
         adoCon.Close()
# Aruna Gutha, 2021Q2-3, Added return status_value for US473210
    return status_value         
        

def return_journal_import_details(dsn,user_id,pwd,batch_name):      
    try:  
      Found=False 
      adoCon=ADO.CreateADOConnection()
      adoCon.ConnectionString="Provider=MSDASQL.1;Password="+pwd+";Persist Security Info=True;User ID="+user_id+";Data Source="+dsn+""
      adoCon.LoginPrompt=False
      adoCon.Open()    
      sqlQuery = """SELECT distinct gl.je_line_num,jb.NAME, gh.period_name, gjs.USER_JE_SOURCE_NAME, gjc.user_je_category_name,
                 gh.currency_code, gc.concatenated_segments, gl.entered_cr,
                 gl.entered_dr, gl.accounted_cr, gl.accounted_dr , gh.status
                 FROM apps.gl_je_batches jb,
                 apps.gl_je_headers gh,
                 apps.gl_je_lines gl,
                 apps.gl_code_combinations_kfv gc,
                 apps.gl_je_sources gjs,
                 apps.GL_JE_CATEGORIES gjc
                 WHERE jb.je_batch_id = gh.je_batch_id
                 AND gh.je_header_id = gl.je_header_id
                 AND gl.code_combination_id = gc.code_combination_id
                 AND gjc.JE_CATEGORY_NAME=gh.JE_CATEGORY
                 AND gh.je_source=gjs.je_source_name
                 AND jb.NAME like '%s'
                 ORDER BY gl.je_line_num  ASC """
      sqlQuery = aqString.Format(sqlQuery,batch_name)
      Log.Enabled=True
      Log.Message("Executing SQL Query In Oracle Database " +sqlQuery) 
      Log.Enabled=False         
      for x in range(0,60):
        rec_set=adoCon.Execute_(sqlQuery)
        rec_set.MoveFirst()
        while (not rec_set.EOF):
          Log.Enabled=True
          Log.Message(" Journal Information : Journal Line Number  "+aqConvert.VartoStr(rec_set.Fields.Item["JE_LINE_NUM"].Value))
          Log.Message(" Journal Batch Name is "+aqConvert.VartoStr(rec_set.Fields.Item["Name"].Value))        
          Log.Message("Period Name is "+aqConvert.VartoStr(rec_set.Fields.Item["period_name"].Value))
          Log.Message("JE_Source is "+aqConvert.VartoStr(rec_set.Fields.Item["user_je_source_name"].Value))
          Log.Message("JE_Category is "+aqConvert.VartoStr(rec_set.Fields.Item["user_je_category_name"].Value))
          Log.Message("Currency_Code is "+aqConvert.VartoStr(rec_set.Fields.Item["currency_code"].Value))
          Log.Message("Accounting Code Combination is "+aqConvert.VartoStr(rec_set.Fields.Item["concatenated_segments"].Value))
          Log.Message("Entered Credit Amount is "+aqConvert.InttoStr(rec_set.Fields.Item["entered_cr"].Value))
          Log.Message("Entered Debit Amount is "+aqConvert.InttoStr(rec_set.Fields.Item["entered_dr"].Value))
          Log.Message("Accounted Credit Amount is "+aqConvert.InttoStr(rec_set.Fields.Item["accounted_cr"].Value))
          Log.Message("Accounted Debit Amount is "+aqConvert.InttoStr(rec_set.Fields.Item["accounted_dr"].Value))
          Log.Message("Journal Posting Status is "+aqConvert.VartoStr(rec_set.Fields.Item["status"].Value))
          Log.Enabled=False
          Found=True
          return VartoStr(rec_set.Fields.Item["Name"].Value)
          rec_set.MoveNext()
        if Found==True:
          break   
        
    except Exception as e:
        Log.Enabled=True 
        Log.Error("Error : - " + traceback.format_exc())  
        Log.Enabled=False 
    finally:    
        adoCon.Close()

def return_journal_batch_name(dsn,user_id,pwd,batch_name):      
    try:  
      Found=False 
      adoCon=ADO.CreateADOConnection()
      adoCon.ConnectionString="Provider=MSDASQL.1;Password="+pwd+";Persist Security Info=True;User ID="+user_id+";Data Source="+dsn+""
      adoCon.LoginPrompt=False
      adoCon.Open()    
      sqlQuery = """SELECT distinct gl.je_line_num,jb.NAME, gh.period_name, gjs.USER_JE_SOURCE_NAME, gjc.user_je_category_name,
                 gh.currency_code, gc.concatenated_segments, gl.entered_cr,
                 gl.entered_dr, gl.accounted_cr, gl.accounted_dr , gh.status
                 FROM apps.gl_je_batches jb,
                 apps.gl_je_headers gh,
                 apps.gl_je_lines gl,
                 apps.gl_code_combinations_kfv gc,
                 apps.gl_je_sources gjs,
                 apps.GL_JE_CATEGORIES gjc
                 WHERE jb.je_batch_id = gh.je_batch_id
                 AND gh.je_header_id = gl.je_header_id
                 AND gl.code_combination_id = gc.code_combination_id
                 AND gjc.JE_CATEGORY_NAME=gh.JE_CATEGORY
                 AND gh.je_source=gjs.je_source_name
                 AND jb.NAME like '%s'
                 ORDER BY gl.je_line_num  ASC """
      sqlQuery = aqString.Format(sqlQuery,batch_name)
#      Log.Enabled=True
#      Log.Message("Executing SQL Query In Oracle Database " +sqlQuery) 
#      Log.Enabled=False         
      for x in range(0,60):
        rec_set=adoCon.Execute_(sqlQuery)
        rec_set.MoveFirst()
        while (not rec_set.EOF):
          Log.Enabled=True
#          Log.Message(" Journal Information : Journal Line Number  "+aqConvert.VartoStr(rec_set.Fields.Item["JE_LINE_NUM"].Value))
          Log.Message(" Journal Batch Name is "+aqConvert.VartoStr(rec_set.Fields.Item["Name"].Value))        
          Log.Message("Period Name is "+aqConvert.VartoStr(rec_set.Fields.Item["period_name"].Value))
#          Log.Message("JE_Source is "+aqConvert.VartoStr(rec_set.Fields.Item["user_je_source_name"].Value))
#          Log.Message("JE_Category is "+aqConvert.VartoStr(rec_set.Fields.Item["user_je_category_name"].Value))
#          Log.Message("Currency_Code is "+aqConvert.VartoStr(rec_set.Fields.Item["currency_code"].Value))
#          Log.Message("Accounting Code Combination is "+aqConvert.VartoStr(rec_set.Fields.Item["concatenated_segments"].Value))
#          Log.Message("Entered Credit Amount is "+aqConvert.InttoStr(rec_set.Fields.Item["entered_cr"].Value))
#          Log.Message("Entered Debit Amount is "+aqConvert.InttoStr(rec_set.Fields.Item["entered_dr"].Value))
#          Log.Message("Accounted Credit Amount is "+aqConvert.InttoStr(rec_set.Fields.Item["accounted_cr"].Value))
#          Log.Message("Accounted Debit Amount is "+aqConvert.InttoStr(rec_set.Fields.Item["accounted_dr"].Value))
#          Log.Message("Journal Posting Status is "+aqConvert.VartoStr(rec_set.Fields.Item["status"].Value))
          Log.Enabled=False
          Found=True
          return VartoStr(rec_set.Fields.Item["Name"].Value)
          rec_set.MoveNext()
        if Found==True:
          break   
        
    except Exception as e:
        Log.Enabled=True 
        Log.Error("Error : - " + traceback.format_exc())  
        Log.Enabled=False 
    finally:    
        adoCon.Close()

        

def query_po_no(dsn,user_id,pwd,req_no):      
    try:  
      Found=False 
      adoCon=ADO.CreateADOConnection()
      adoCon.ConnectionString="Provider=MSDASQL.1;Password="+pwd+";Persist Security Info=True;User ID="+user_id+";Data Source="+dsn+""
      adoCon.LoginPrompt=False
      adoCon.Open()    
      sqlQuery = """SELECT POH. PO_HEADER_ID, POH. SEGMENT1
        FROM PO_HEADERS_ALL POH, 
       PO_DISTRIBUTIONS_ALL PDA ,
       PO_REQ_DISTRIBUTIONS_ALL PRDA ,
       PO_REQUISITION_LINES_ALL PRLA ,
       PO_REQUISITION_HEADERS_ALL PRHA
       WHERE POH. PO_HEADER_ID = PDA. PO_HEADER_ID 
       AND    PDA. REQ_DISTRIBUTION_ID = PRDA.DISTRIBUTION_ID
       AND    PRDA. REQUISITION_LINE_ID = PRLA. REQUISITION_LINE_ID
       AND      PRLA. REQUISITION_HEADER_ID = PRHA. REQUISITION_HEADER_ID
       AND    PRHA. SEGMENT1 = '%s' """
      sqlQuery = aqString.Format(sqlQuery,req_no)
      Log.Enabled=True
      Log.Message("Executing SQL Query In Oracle Database " +sqlQuery) 
      Log.Enabled=False         
      for x in range(0,60):
        rec_set=adoCon.Execute_(sqlQuery)
        rec_set.MoveFirst()
        while (not rec_set.EOF):
          Log.Enabled=True
          Log.Message(" Purchase Order Number  "+aqConvert.VartoStr(rec_set.Fields.Item["SEGMENT1"].Value))
          Log.Enabled=False
          po = (rec_set.Fields.Item["SEGMENT1"].Value)
          Found=True
          rec_set.MoveNext()
          return po
        if Found==True:
          break        
    except Exception as e:
        Log.Enabled=True 
        Log.Error("Error : - " + traceback.format_exc())  
        Log.Enabled=False 
    finally:    
        adoCon.Close()

                
def get_po_details(dsn,user_id,pwd,proj_no):      
    try:  
      Found=False 
      adoCon=ADO.CreateADOConnection()
      adoCon.ConnectionString="Provider=MSDASQL.1;Password="+pwd+";Persist Security Info=True;User ID="+user_id+";Data Source="+dsn+""
      adoCon.LoginPrompt=False
      adoCon.Open()   
       
      sqlQuery = """select LAST_UPDATE_DATE,PROJECT_ID,NAME,SEGMENT1,PROJECT_STATUS_CODE from PA_PROJECTS_ALL where segment1 = '%s'; """
      
      sqlQuery = aqString.Format(sqlQuery,proj_no)
      Log.Enabled=True
      Log.Message("Executing SQL Query In Oracle Database " +sqlQuery) 
      Log.Enabled=False         
      for x in range(0,60):
        rec_set=adoCon.Execute_(sqlQuery)
        rec_set.MoveFirst()
        while (not rec_set.EOF):
          Log.Enabled=True
          Log.Message("Last Update Date  "+aqConvert.VartoStr(rec_set.Fields.Item["LAST_UPDATE_DATE"].Value))
          Log.Message("Project ID  "+aqConvert.VartoStr(rec_set.Fields.Item["PROJECT_ID"].Value))
          Log.Message("Name "+aqConvert.VartoStr(rec_set.Fields.Item["NAME"].Value))
          Log.Message("Project No "+aqConvert.VartoStr(rec_set.Fields.Item["SEGMENT1"].Value))
          Log.Message("Last Update Date  "+aqConvert.VartoStr(rec_set.Fields.Item["PROJECT_STATUS_CODE"].Value))
          Log.Enabled=False
          Found=True
          rec_set.MoveNext()
          return po
        if Found==True:
          break        
    except Exception as e:
        Log.Enabled=True 
        Log.Error("Error : - " + traceback.format_exc())  
        Log.Enabled=False 
    finally:    
        adoCon.Close()

def po_approval_status(dsn,user_id,pwd,po_no):      
    try:  
      Found=False 
      adoCon=ADO.CreateADOConnection()
      adoCon.ConnectionString="Provider=MSDASQL.1;Password="+pwd+";Persist Security Info=True;User ID="+user_id+";Data Source="+dsn+""
      adoCon.LoginPrompt=False
      adoCon.Open()    
      sqlQuery = """select prh.segment1, prh.AUTHORIZATION_STATUS
          from apps.po_headers_all prh
          where prh.segment1 = '%s' """    
      sqlQuery = aqString.Format(sqlQuery,po_no)
      Log.Enabled=True
      Log.Message("Executing SQL Query In Oracle Database " +sqlQuery) 
      Log.Enabled=False         
      for x in range(0,60):
        rec_set=adoCon.Execute_(sqlQuery)
        rec_set.MoveFirst()
        while (not rec_set.EOF):
          Log.Enabled=True
          Log.Message(" Purchase Order Number:  "+aqConvert.VartoStr(rec_set.Fields.Item["SEGMENT1"].Value))
          Log.Message(" Approval Status:  "+aqConvert.VartoStr(rec_set.Fields.Item["AUTHORIZATION_STATUS"].Value))
          Log.Enabled=False
          Approval_status = (rec_set.Fields.Item["AUTHORIZATION_STATUS"].Value)
          Found=True
          rec_set.MoveNext()
          return Approval_status
        if Found==True:
          break        
    except Exception as e:
        Log.Enabled=True 
        Log.Error("Error : - " + traceback.format_exc())  
        Log.Enabled=False 
    finally:    
        adoCon.Close()

def req_approval_status(dsn,user_id,pwd,req_no):      
    try:  
      Found=False 
      adoCon=ADO.CreateADOConnection()
      adoCon.ConnectionString="Provider=MSDASQL.1;Password="+pwd+";Persist Security Info=True;User ID="+user_id+";Data Source="+dsn+""
      adoCon.LoginPrompt=False
      adoCon.Open()    
      sqlQuery = """select prh.segment1, prh.AUTHORIZATION_STATUS
      from apps.po_requisition_headers_all prh
      where prh.segment1 ='%s' """    
      sqlQuery = aqString.Format(sqlQuery,req_no)
      Log.Enabled=True
      Log.Message("Executing SQL Query In Oracle Database " +sqlQuery) 
      Log.Enabled=False         
      for x in range(0,60):
        rec_set=adoCon.Execute_(sqlQuery)
        rec_set.MoveFirst()
        while (not rec_set.EOF):
          Log.Enabled=True
          Log.Message(" Requisition Number:  "+aqConvert.VartoStr(rec_set.Fields.Item["SEGMENT1"].Value))
          Log.Message(" Approval Status:  "+aqConvert.VartoStr(rec_set.Fields.Item["AUTHORIZATION_STATUS"].Value))
          Log.Enabled=False
          Approval_status = (rec_set.Fields.Item["AUTHORIZATION_STATUS"].Value)
          Found=True
          rec_set.MoveNext()
          return Approval_status
        if Found==True:
          break        
    except Exception as e:
        Log.Enabled=True 
        Log.Error("Error : - " + traceback.format_exc())  
        Log.Enabled=False 
    finally:    
        adoCon.Close()

def asset_ret(dsn,user_id,pwd):      
    try:  
      Found=False 
      adoCon=ADO.CreateADOConnection()
      adoCon.ConnectionString="Provider=MSDASQL.1;Password="+pwd+";Persist Security Info=True;User ID="+user_id+";Data Source="+dsn+""
      adoCon.LoginPrompt=False
      adoCon.Open()    
      sqlQuery = "select distinct DATE_RETIRED, BOOK_TYPE_CODE, ASSET_ID from fa_retirements where ROWNUM = 1 and DATE_RETIRED between '01-Jan-2019' and '31-dec-2019'"
      sqlQuery = aqString.Format(sqlQuery) 
      Log.Enabled=True
      Log.Message("Executing SQL Query In Oracle Database to retrieve Item Key" +(sqlQuery)) 
      Log.Enabled=False      
      for x in range(0,60):
        rec_set=adoCon.Execute_(sqlQuery)
        rec_set.MoveFirst()
        while (not rec_set.EOF):
          Log.Enabled=True
          Log.Message(" Asset ID  "+aqConvert.FloatToStr(rec_set.Fields.Item["ASSET_ID"].Value))        
          Log.Enabled=False
          key = (rec_set.Fields.Item["ASSET_ID"].Value)
          Found=True
          return key
          rec_set.MoveNext()
        if Found==True:
          break        
    except Exception as e:
        Log.Enabled=True
        Log.Error("Error while running query : - " + traceback.format_exc())
        Log.Enabled=False   
    finally:    
        adoCon.Close()

        
def verify_pa_trns_import_details(dsn,user_id,pwd,prc_dis_lab_cost_id):      
    try:  
      Found=False 
      adoCon=ADO.CreateADOConnection()
      adoCon.ConnectionString="Provider=MSDASQL.1;Password="+pwd+";Persist Security Info=True;User ID="+user_id+";Data Source="+dsn+""
      adoCon.LoginPrompt=False
      adoCon.Open()     
      sqlQuery = """ Select DISTINCT papf.employee_number,papf.full_name,pra.name,pra.segment1,pra.project_type,pra.project_status_code,pae.project_id,pra.description,pae.transaction_source,pae.expenditure_item_id,pae.expenditure_item_date,pae.expenditure_type,pat.task_number,pat.task_name,pae.raw_cost,pae.raw_cost_rate,pae.attribute1,pae.attribute2,pae.request_id from PA_EXPENDITURE_ITEMS_ALL pae,PA_PROJECTS_ALL pra,PA_TASKS pat,pa_expenditures_all pea,per_all_people_f papf where Pae.project_id=pra.project_id and pat.task_id = pae.task_id  and papf.person_id= pea.INCURRED_BY_PERSON_ID and pae.expenditure_id=pea.expenditure_id and pae.request_id = '%s'"""
      sqlQuery = aqString.Format(sqlQuery,prc_dis_lab_cost_id)
      Log.Enabled=True
      Log.Message("Executing SQL Query In Oracle Database " +sqlQuery) 
      Log.Enabled=False         
      for x in range(0,60):
        rec_set=adoCon.Execute_(sqlQuery)
        rec_set.MoveFirst()
        while (not rec_set.EOF):
          Log.Enabled=True
          Log.Message(" Transaction Information : Employee Number is  "+aqConvert.VartoStr(rec_set.Fields.Item["EMPLOYEE_NUMBER"].Value))
          Log.Message(" Full Name is  "+aqConvert.VartoStr(rec_set.Fields.Item["FULL_NAME"].Value))
          Log.Message(" Project Name is  "+aqConvert.VartoStr(rec_set.Fields.Item["NAME"].Value))
          Log.Message(" Project Number is "+aqConvert.VartoStr(rec_set.Fields.Item["SEGMENT1"].Value))        
          Log.Message(" Project Type  is "+aqConvert.VartoStr(rec_set.Fields.Item["PROJECT_TYPE"].Value))
          Log.Message(" Project Status Code is "+aqConvert.VartoStr(rec_set.Fields.Item["PROJECT_STATUS_CODE"].Value))
          Log.Message(" Project id is "+aqConvert.VartoStr(rec_set.Fields.Item["PROJECT_ID"].Value))
          Log.Message(" Project Description is "+aqConvert.VartoStr(rec_set.Fields.Item["DESCRIPTION"].Value))
          Log.Message(" Transaction Source is "+aqConvert.VartoStr(rec_set.Fields.Item["TRANSACTION_SOURCE"].Value))
          Log.Message(" Expenditure Item ID is "+aqConvert.VartoStr(rec_set.Fields.Item["EXPENDITURE_ITEM_ID"].Value))
          Log.Message(" Expenditure Item Date is "+aqConvert.VartoStr(rec_set.Fields.Item["EXPENDITURE_ITEM_DATE"].Value))
          Log.Message(" Expenditure Type is "+aqConvert.VartoStr(rec_set.Fields.Item["EXPENDITURE_TYPE"].Value))
          Log.Message(" Task Number is "+aqConvert.FloatToStr(rec_set.Fields.Item["TASK_NUMBER"].Value))
          Log.Message(" Task Name is "+aqConvert.VartoStr(rec_set.Fields.Item["TASK_NAME"].Value))
          Log.Message(" Raw Cost is "+aqConvert.FloatToStr(rec_set.Fields.Item["RAW_COST"].Value))
          Log.Message(" Raw Cost Rate is "+aqConvert.FloatToStr(rec_set.Fields.Item["RAW_COST_RATE"].Value))
          Log.Message(" Distribution Line Date is "+aqConvert.VartoStr(rec_set.Fields.Item["ATTRIBUTE1"].Value))
          Log.Message(" PA_EXPENDITURE Request ID is "+aqConvert.VartoStr(rec_set.Fields.Item["REQUEST_ID"].Value))
          Log.Enabled=False
          Found=True
          rec_set.MoveNext()
        if Found==True:
          break        
    except Exception as e:
        Log.Enabled=True 
        Log.Error("Error : - " + traceback.format_exc())  
        Log.Enabled=False 
    finally:    
        adoCon.Close()


def asset_add(dsn,user_id,pwd):      
    try:  
      Found=False 
      adoCon=ADO.CreateADOConnection()      
      adoCon.ConnectionString="Provider=MSDASQL.1;Password="+pwd+";Persist Security Info=True;User ID="+user_id+";Data Source="+dsn+""
      adoCon.LoginPrompt=False
      adoCon.Open()    
      sqlQuery = "select ASSET_ID from fa_books where 1=1 and book_type_code = 'ATG CORP' and DATE_PLACED_IN_SERVICE between '01-Jan-2018' and '31-dec-2018'and asset_id not in (select distinct Asset_Id from fa_retirements)and ROWNUM = 1;"
      sqlQuery = aqString.Format(sqlQuery) 
      Log.Enabled=True
      Log.Message("Executing SQL Query In Oracle Database to retrieve Item Key" +(sqlQuery)) 
      Log.Enabled=False      
      for x in range(0,60):
        rec_set=adoCon.Execute_(sqlQuery)
        rec_set.MoveFirst()
        while (not rec_set.EOF):
          Log.Enabled=True
          Log.Message("'Asset Number' which is being used for this test is "+aqConvert.FloatToStr(rec_set.Fields.Item["ASSET_ID"].Value))        
          Log.Enabled=False
          key = (rec_set.Fields.Item["ASSET_ID"].Value)
          Found=True
          return key
          rec_set.MoveNext()
        if Found==True:
          break        
    except Exception as e:
        Log.Enabled=True
        Log.Error("Error while running query : - " + traceback.format_exc())
        Log.Enabled=False   
    finally:    
        adoCon.Close()
        
def is_asset_add(dsn,user_id,pwd):      
    try:  
      Found=False 
      adoCon=ADO.CreateADOConnection()      
      adoCon.ConnectionString="Provider=MSDASQL.1;Password="+pwd+";Persist Security Info=True;User ID="+user_id+";Data Source="+dsn+""
      adoCon.LoginPrompt=False
      adoCon.Open()    
      sqlQuery = "select ASSET_ID from fa_books where 1=1 and book_type_code = 'MAN USCORP BOOK' and DATE_PLACED_IN_SERVICE between '01-Jan-2018' and '28-Apr-2020'and asset_id not in (select distinct Asset_Id from fa_retirements)and ROWNUM = 1;"
      sqlQuery = aqString.Format(sqlQuery) 
      Log.Enabled=True
      Log.Message("Executing SQL Query In Oracle Database to retrieve Item Key" +(sqlQuery)) 
      Log.Enabled=False      
      for x in range(0,60):
        rec_set=adoCon.Execute_(sqlQuery)
        rec_set.MoveFirst()
        while (not rec_set.EOF):
          Log.Enabled=True
          Log.Message("'Asset Number' which is being used for this test is "+aqConvert.FloatToStr(rec_set.Fields.Item["ASSET_ID"].Value))        
          Log.Enabled=False
          key = (rec_set.Fields.Item["ASSET_ID"].Value)
          Found=True
          return key
          rec_set.MoveNext()
        if Found==True:
          break        
    except Exception as e:
        Log.Enabled=True
        Log.Error("Error while running query : - " + traceback.format_exc())
        Log.Enabled=False   
    finally:    
        adoCon.Close()

        
                
def invoice_num(dsn,user_id,pwd):      
    try:  
      Found=False 
      adoCon=ADO.CreateADOConnection()      
      adoCon.ConnectionString="Provider=MSDASQL.1;Password="+pwd+";Persist Security Info=True;User ID="+user_id+";Data Source="+dsn+""
      adoCon.LoginPrompt=False
      adoCon.Open()    
      sqlQuery = "select * from ap_invoices_all where creation_date > = sysdate-5 and wfapproval_status <> 'INITIATED' and INVOICE_CURRENCY_CODE = 'USD'and rownum = 1;"
      sqlQuery = aqString.Format(sqlQuery) 
      Log.Enabled=True
      Log.Message("Executing SQL Query In Oracle Database to retrieve Invoice Number" +(sqlQuery)) 
      Log.Enabled=False      
      for x in range(0,60):
        rec_set=adoCon.Execute_(sqlQuery)
        rec_set.MoveFirst()
        while (not rec_set.EOF):
          Log.Enabled=True
          Log.Message("'Invoice Number' which is being used for this test is "+aqConvert.VarToStr(rec_set.Fields.Item["INVOICE_NUM"].Value))        
          Log.Enabled=False
          key = (rec_set.Fields.Item["INVOICE_NUM"].Value)
          Found=True
          return key
          rec_set.MoveNext()
        if Found==True:
          break        
    except Exception as e:
        Log.Enabled=True
        Log.Error("Error while running query : - " + traceback.format_exc())
        Log.Enabled=False   
    finally:    
        adoCon.Close()

def test():
    invoice_num = dbhelper.invoice_num('OCI_STAGE','RAC_ACCNT','Y4bLC5sb')
    
def get_journal_name_from_batchname(dsn,user_id,pwd,batch_name):
    try:  
      Found=False 
      adoCon=ADO.CreateADOConnection()
      adoCon.ConnectionString="Provider=MSDASQL.1;Password="+pwd+";Persist Security Info=True;User ID="+user_id+";Data Source="+dsn+""
      adoCon.LoginPrompt=False
      adoCon.Open()    
      sqlQuery = """SELECT distinct gh.name as journal_name, jb.name
                    FROM apps.gl_je_batches jb,
                    apps.gl_je_headers gh
                    WHERE jb.je_batch_id = gh.je_batch_id
                    AND jb.NAME like '%s'
                    ORDER BY jb.NAME  ASC"""
      sqlQuery = aqString.Format(sqlQuery,batch_name)
      Log.Enabled=True
      Log.Message("Executing SQL Query In Oracle Database " +sqlQuery) 
      Log.Enabled=False         
      for x in range(0,60):
        rec_set=adoCon.Execute_(sqlQuery)
        rec_set.MoveFirst()
        journal_names = []
        while (not rec_set.EOF):
#          Log.Enabled=True
#          Log.Message(aqConvert.VartoStr(rec_set.Fields.Item["JOURNAL_NAME"].Value))
#          Log.Enabled=False
          Found=True
          journal_names.append(aqConvert.VartoStr(rec_set.Fields.Item["JOURNAL_NAME"].Value))
          rec_set.MoveNext()
        if Found==True:
          return journal_names
          break        
    except Exception as e:
        Log.Enabled=True 
        Log.Error("Error : - " + traceback.format_exc())  
        Log.Enabled=False 
    finally:    
        adoCon.Close()
        
def verify_journal_details(dsn,user_id,pwd,journal_name):      
    try:  
      Found=False 
      adoCon=ADO.CreateADOConnection()
      adoCon.ConnectionString="Provider=MSDASQL.1;Password="+pwd+";Persist Security Info=True;User ID="+user_id+";Data Source="+dsn+""
      adoCon.LoginPrompt=False
      adoCon.Open()    
      sqlQuery = """SELECT distinct gl.je_line_num,jb.NAME, gh.period_name, gjs.USER_JE_SOURCE_NAME, gjc.user_je_category_name,
                 gh.currency_code, gc.concatenated_segments, gl.entered_cr,
                 gl.entered_dr, gl.accounted_cr, gl.accounted_dr , gh.status
                 FROM apps.gl_je_batches jb,
                 apps.gl_je_headers gh,
                 apps.gl_je_lines gl,
                 apps.gl_code_combinations_kfv gc,
                 apps.gl_je_sources gjs,
                 apps.GL_JE_CATEGORIES gjc
                 WHERE jb.je_batch_id = gh.je_batch_id
                 AND gh.je_header_id = gl.je_header_id
                 AND gl.code_combination_id = gc.code_combination_id
                 AND gjc.JE_CATEGORY_NAME=gh.JE_CATEGORY
                 AND gh.je_source=gjs.je_source_name
                 AND gh.NAME like '%s'
                 ORDER BY gl.je_line_num  ASC """
      sqlQuery = aqString.Format(sqlQuery,journal_name)
      Log.Enabled=True
      Log.Message("Executing SQL Query In Oracle Database " +sqlQuery) 
      Log.Enabled=False         
      for x in range(0,60):
        rec_set=adoCon.Execute_(sqlQuery)
        rec_set.MoveFirst()
        while (not rec_set.EOF):
          Log.Enabled=True
          Log.Message(" Journal Information : Journal Line Number  "+aqConvert.VartoStr(rec_set.Fields.Item["JE_LINE_NUM"].Value))
          Log.Message(" Journal Batch Name is "+aqConvert.VartoStr(rec_set.Fields.Item["Name"].Value))        
          Log.Message("Period Name is "+aqConvert.VartoStr(rec_set.Fields.Item["period_name"].Value))
          Log.Message("JE_Source is "+aqConvert.VartoStr(rec_set.Fields.Item["user_je_source_name"].Value))
          Log.Message("JE_Category is "+aqConvert.VartoStr(rec_set.Fields.Item["user_je_category_name"].Value))
          Log.Message("Currency_Code is "+aqConvert.VartoStr(rec_set.Fields.Item["currency_code"].Value))
          Log.Message("Accounting Code Combination is "+aqConvert.VartoStr(rec_set.Fields.Item["concatenated_segments"].Value))
          Log.Message("Entered Credit Amount is "+aqConvert.InttoStr(rec_set.Fields.Item["entered_cr"].Value))
          Log.Message("Entered Debit Amount is "+aqConvert.InttoStr(rec_set.Fields.Item["entered_dr"].Value))
          Log.Message("Accounted Credit Amount is "+aqConvert.InttoStr(rec_set.Fields.Item["accounted_cr"].Value))
          Log.Message("Accounted Debit Amount is "+aqConvert.InttoStr(rec_set.Fields.Item["accounted_dr"].Value))
          Log.Message("Journal Posting Status is "+aqConvert.VartoStr(rec_set.Fields.Item["status"].Value))
          Log.Enabled=False
          Found=True
          rec_set.MoveNext()
        if Found==True:
          break        
    except Exception as e:
        Log.Enabled=True 
        Log.Error("Error : - " + traceback.format_exc())  
        Log.Enabled=False 
    finally:    
        adoCon.Close()

def get_journal_approval_limit(dsn,user_id,pwd):
  
  try:  
      Found=False 
      adoCon=ADO.CreateADOConnection()
      adoCon.ConnectionString="Provider=MSDASQL.1;Password="+pwd+";Persist Security Info=True;User ID="+user_id+";Data Source="+dsn+""
      adoCon.LoginPrompt=False
      adoCon.Open()    
      sqlQuery = """ SELECT Fvl.Lookup_Code
          FROM APPS.FND_LOOKUP_VALUES_VL Fvl
          WHERE Fvl.Lookup_Type='XXCAI_GL_JE_THRESHOLD_AMT_APPR'
          AND Fvl.Enabled_Flag = 'Y'
          AND SYSDATE BETWEEN NVL(fvl.start_date_active, SYSDATE-1) AND NVL(fvl.end_date_active, SYSDATE+1)"""
      Log.Enabled=True
      Log.Message("Executing SQL Query In Oracle Database " +sqlQuery) 
      Log.Enabled=False         
      for x in range(0,60):
        rec_set=adoCon.Execute_(sqlQuery)
        rec_set.MoveFirst()
        while (not rec_set.EOF):
          Log.Enabled=True
          Log.Message("Journal Threshold Amount for Approver Process is: "+aqConvert.VartoStr(rec_set.Fields.Item["lookup_code"].Value))
          Log.Enabled=False
          Found=True
          appr_amount = aqConvert.VartoStr(rec_set.Fields.Item["lookup_code"].Value)
          rec_set.MoveNext()
        if Found==True:
          return appr_amount        
  except Exception as e:
        Log.Enabled=True 
        Log.Error("Error : - " + traceback.format_exc())  
        Log.Enabled=False 
  finally:    
        adoCon.Close()

        
def verify_is_journal_status(dsn,user_id,pwd,jrnl_desc):      
    try:  
      Found=False 
      adoCon=ADO.CreateADOConnection()
      adoCon.ConnectionString="Provider=MSDASQL.1;Password="+pwd+";Persist Security Info=True;User ID="+user_id+";Data Source="+dsn+""
      adoCon.LoginPrompt=False
      adoCon.Open()    
      sqlQuery = "Select Name,Description,JE_Header_ID,JE_Source,Period_Name,Currency_code,Status,Creation_date,posted_date,"\
                  "ACCRUAL_REV_STATUS,running_total_dr,running_total_cr,running_total_accounted_dr,running_total_accounted_cr "\
                  "from gl_je_headers where Description like '%"+VarToStr(jrnl_desc)+"%'"
      Log.Enabled=True
      Log.Message("Executing SQL Query In Oracle Database" +(sqlQuery)) 
      Log.Enabled=False
      for x in range(0,60):
        rec_set=adoCon.Execute_(sqlQuery)
        rec_set.MoveFirst()
        while (not rec_set.EOF):
          Log.Enabled=True
          Log.Message("Journal Information : Journal_Name is "+(rec_set.Fields.Item["NAME"].Value))        
          Log.Message("Journal Description is "+aqConvert.VartoStr(rec_set.Fields.Item["DESCRIPTION"].Value))
          Log.Message("Journal Header_ID is "+aqConvert.InttoStr(rec_set.Fields.Item["JE_HEADER_ID"].Value))
          Log.Message("Journal Source is "+(rec_set.Fields.Item["JE_SOURCE"].Value))
          Log.Message("Period Name is "+(rec_set.Fields.Item["PERIOD_NAME"].Value))
          Log.Message("Currency Code is "+(rec_set.Fields.Item["CURRENCY_CODE"].Value))
          Log.Message("Journal Status is "+(rec_set.Fields.Item["STATUS"].Value))
          Log.Message("Journal creation date is "+aqConvert.DateTimeToStr(rec_set.Fields.Item["CREATION_DATE"].Value))
          Log.Message("Journal Posted date is "+aqConvert.DateTimeToStr(rec_set.Fields.Item["POSTED_DATE"].Value))
          Log.Message("Journal Reverse Status is "+aqConvert.VarToStr(rec_set.Fields.Item["ACCRUAL_REV_STATUS"].Value))
          Log.Message("Running Total Debit "+aqConvert.InttoStr(rec_set.Fields.Item["RUNNING_TOTAL_DR"].Value)) 
          Log.Message("Running Total Credit "+aqConvert.InttoStr(rec_set.Fields.Item["RUNNING_TOTAL_CR"].Value))  
          Log.Message("Running Total Accounted Debit "+aqConvert.InttoStr(rec_set.Fields.Item["RUNNING_TOTAL_ACCOUNTED_DR"].Value))  
          Log.Message("Running Total Accounted Credit "+aqConvert.InttoStr(rec_set.Fields.Item["RUNNING_TOTAL_ACCOUNTED_CR"].Value))               
          Log.Enabled=False
          Found=True
          rec_set.MoveNext()
        if Found==True:
          break        
    except Exception as e:
        Log.Error("Error : - " + traceback.format_exc())   
    finally:    
        adoCon.Close()

 
def get_man_journal_approval_limit(dsn,user_id,pwd):
  
  try:  
      Found=False 
      adoCon=ADO.CreateADOConnection()
      adoCon.ConnectionString="Provider=MSDASQL.1;Password="+pwd+";Persist Security Info=True;User ID="+user_id+";Data Source="+dsn+""
      adoCon.LoginPrompt=False
      adoCon.Open()    
      sqlQuery = """ SELECT Fvl.Lookup_Code
          FROM APPS.FND_LOOKUP_VALUES_VL Fvl
          WHERE Fvl.Lookup_Type='MAN_GL_JE_THRESHOLD_AMT_APPR'
          AND Fvl.Enabled_Flag = 'Y'
          AND SYSDATE BETWEEN NVL(fvl.start_date_active, SYSDATE-1) AND NVL(fvl.end_date_active, SYSDATE+1)"""
      Log.Enabled=True
      Log.Message("Executing SQL Query In Oracle Database " +sqlQuery) 
      Log.Enabled=False         
      for x in range(0,60):
        rec_set=adoCon.Execute_(sqlQuery)
        rec_set.MoveFirst()
        while (not rec_set.EOF):
          Log.Enabled=True
          Log.Message("Journal Threshold Amount for Approver Process is: "+aqConvert.VartoStr(rec_set.Fields.Item["lookup_code"].Value))
          Log.Enabled=False
          Found=True
          appr_amount = aqConvert.VartoStr(rec_set.Fields.Item["lookup_code"].Value)
          rec_set.MoveNext()
        if Found==True:
          return appr_amount        
  except Exception as e:
        Log.Enabled=True 
        Log.Error("Error : - " + traceback.format_exc())  
        Log.Enabled=False 
  finally:    
        adoCon.Close()

        
def vfy_oracle_concurrent_job_je(dsn,user_id,pwd,req_id):      
     try:  
       Found=False 
       adoCon=ADO.CreateADOConnection()
       adoCon.ConnectionString="Provider=MSDASQL.1;Password="+pwd+";Persist Security Info=True;User ID="+user_id+";Data Source="+dsn+""
       adoCon.LoginPrompt=False
       adoCon.Open()       
#       sqlQuery =  "select * from apps.FND_CONC_REQ_SUMMARY_V where parent_request_id in (select request_id from apps.FND_CONC_REQ_SUMMARY_V where parent_request_id = '" + VarToStr(req_id) + "') and program = 'Journal Import'"  
       sqlQuery =  f"select * from apps.FND_CONC_REQ_SUMMARY_V where request_id > '{VarToStr(req_id)}' and program = 'Journal Import'" 
       Log.Enabled = True
       Log.Message(sqlQuery)
       Log.Enabled = False
       for x in range(0,240):
         rec_set=adoCon.Execute_(sqlQuery)
         rec_set.MoveFirst()
         while (not rec_set.EOF) and (rec_set.Fields.Item["PHASE_CODE"]=='C'):     
           Log.Enabled = True   
           Log.Message("Oracle Concurrent Request "+VarToStr(req_id)+" Completed Successfully")
           Log.Message("Oracle Concurrent Program Phase Code status :  "+rec_set.Fields.Item["PHASE_CODE"].Value)
           Log.Message("Oracle Concurrent Program Status Code status : "+rec_set.Fields.Item["STATUS_CODE"].Value) 
           Log.Message("Journal Import Request ID generated for Create Accounting Program : "+VarToStr(rec_set.Fields.Item["REQUEST_ID"].Value)) 
           Log.Enabled = False            
           Found=True
           Request_ID = aqConvert.VartoStr(rec_set.Fields.Item["REQUEST_ID"].Value)
           return Request_ID
           rec_set.MoveNext()
           Delay(10000)
         if Found==True:
           break        
     except Exception as e:
          Log.Message("Error : - " + str(e))   
     finally:    
         adoCon.Close()
         
##Query to find distribution status and debit account of  Expenditure Batch
def verify_exp_batch_details_by_project(dsn,user_id,pwd,proj_num):
    Log.Enabled = True
    Log.Checkpoint("-------- Verifying distribution status and debit account of Expenditure Batch --------")
    Log.Enabled = True
    try:  
      Found=False 
      adoCon=ADO.CreateADOConnection()
      adoCon.ConnectionString="Provider=MSDASQL.1;Password="+pwd+";Persist Security Info=True;User ID="+user_id+";Data Source="+dsn+""
      adoCon.LoginPrompt=False
      adoCon.Open()    
      sqlQuery = f""" select  pei.expenditure_item_id,pei.cost_distributed_flag,glc.concatenated_segments
                      from 
                      apps.pa_expenditure_items_all pei,
                      apps.pa_expenditures_all pea,
                      apps.pa_cost_distribution_lines_all pcd,
                      apps.gl_code_combinations_kfv glc,
                      apps.pa_projects_all ppa
                      where 
                      pei.Expenditure_id = pea.expenditure_id
                      and pei.expenditure_item_id = pcd.expenditure_item_id
                      and pcd.dr_code_combination_id = glc.code_combination_id
                      and pei.project_id = ppa.project_id
                      and ppa.segment1 = '{proj_num}'"""
      Log.Message(sqlQuery)
      for x in range(0,240):
          rec_set=adoCon.Execute_(sqlQuery)
          rec_set.MoveFirst()
          while (not rec_set.EOF) and (rec_set.Fields.Item["COST_DISTRIBUTED_FLAG"]=='Y'):
              Log.Enabled = True 
              Log.Checkpoint("For Expenditure_Item_id: "+VartoStr(rec_set.Fields.Item["EXPENDITURE_ITEM_ID"].Value))
              Log.Checkpoint("Cost Distribution Flag: "+rec_set.Fields.Item["COST_DISTRIBUTED_FLAG"].Value)
              Log.Checkpoint("Debit account: "+VartoStr(rec_set.Fields.Item["CONCATENATED_SEGMENTS"].Value))
              Log.Enabled = False            
              Found=True
              rec_set.MoveNext()
          Delay(10000)
          if Found==True:
           break        
    except Exception as e:
          Log.Message("Error : - " + str(e))   
    finally:    
         adoCon.Close()

         
def test1():
  
   RequestID = 172844960
#verifying for request completion
   REQUEST_ID = dbhelper.vfy_oracle_concurrent_job_je("MAN_OCI_TEST","appsread","oracle123",RequestID)