﻿from webcenterverifier_V12 import *
import gvar
import tc_logs
import wfr_home_page_v12


class WFR_Process_Email_Batches_V12(Webcenterverifier_V12):
  


    def action(self,book): 
        #Load the datasheet to dictionary
        gvar.store_excel_to_dict1("mail_wcc")
        gvar.store_excel_to_dict1("wci_verifier")
        
        #get operating_unit and inv_number
        op_unit = aqString.SubString(VarToStr(gvar.excel['wci_verifier']['Description'].split(',')[0]),5,2)
                
        #applying filter to batch_name/capture_batch_id and verify whether batch created/exists
        Webcenterverifier_V12.apply_filter_and_verify_batch_exists()
        
        # Check the verifier batch id's(invoices) created for "Capture batch id" and select/open the invoice
        Webcenterverifier_V12.get_batch_count_using_batch_name()
         
        #select the first invoice/batch
        batch_id, batch_name_ui = Webcenterverifier_V12.select_first_invoice_batch()
        
        #enter all invoice data fields required and validate the invoices for the batch selected 
        while VarToStr(gvar.excel['mail_wcc']['Batch_Name'])==VarToStr(batch_name_ui):  
            tc_logs.msg_with_picture("Batch Name match successfully")
            
            #get company code  
            company_code = wfr_home_page_v12.company_code_textfield().value
            tc_logs.msg_with_picture("Company code: "+VarToStr(company_code))
            
            #get operating unit
            operating_unit = wfr_home_page_v12.operating_unit_textfield().value
            tc_logs.msg_with_picture("Operating unit: "+VarToStr(operating_unit))
            
            #set invoice number
            gvar.dataprep['invoice_number'] = gvar.excel['wci_verifier']['Invoice Number']+"_"+VarToStr(aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%m_%d"))+"_"+VarToStr(random.randint(1111,9999))
            gvar.write_dict_data_to_excel("wci_verifier","InvNO",gvar.dataprep['invoice_number'])
            gvar.write_dict_data_to_excel("Invoice","Invoice Number",gvar.dataprep['invoice_number'])
            # compare inv_type & project in datasheet and UI, if different, then set according to datasheet
            Webcenterverifier_V12.compare_set_inv_type_and_project()
            
            # enter invoice number, invoice date
            Webcenterverifier_V12.enter_inv_num_and_date(gvar.dataprep['invoice_number'])
            
            #get po_number if invoice_type is po
            Webcenterverifier_V12.get_po_number()
            
               
            #set invalid reason if one mentioned in datasheet
            Webcenterverifier_V12.set_invalid_reason()
            
            #enter po if invoice type is po
            Webcenterverifier_V12.enter_po_number()
            
            #Update Vendor/site details for the invoice
            Webcenterverifier_V12.update_vendor_details()
            
            #Update the shipping details accordingly based on datasheet
            Webcenterverifier_V12.update_shipping_details()
            
            #Clear all the existing lines and add the lines as in datasheet
            Webcenterverifier_V12.clear_replace_existing_po_lines()
            Webcenterverifier_V12.create_add_po_lines()

            #Enter all the tax fields and calculate the total amount
            Webcenterverifier_V12.enter_tax_fields(op_unit)
            
            #Verify if all fields are properly entered, else validation fails
            multiple_inv = Webcenterverifier_V12.verify_msg_popup(batch_id)
      
            if not multiple_inv:
                break
            else: 
                batch_name_ui=wfr_home_page_v12.batch_name_field().value 
              
        tc_logs.validation("All invoices are verified and released for batch: "+batch_id)
       # tc_logs.validation("Successfully verified and released WFR BatchID: "+batch_id+" for WCC Batch Name: "+gvar.excel['mail_wcc']['Batch_Name'])
   

        
   #wfr_home_page_v12.options_tab().Exists     
        
        
    
