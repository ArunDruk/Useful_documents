﻿from ebiz import *
import web_utils
import form_utils
import dbhelper
import file_system_utils


class tc84513_cai_us_journals_approve(Ebiz):

 op_log_path ="C:\\TC_Logs"

 def login(self):
   self.login_user='Bbristow'
   super().login()
   
 def action(self,book): 
    if ProjectSuite.Variables.currency =="USD": 
      app = book.Sheets.item["ManualJournal_USD"]
    elif ProjectSuite.Variables.currency=="CAD":
      app = book.Sheets.item["ManualJournal_CAD"]
    else:
      app = book.Sheets.item["Autocopy"]
    self.page.Wait()
    self.page.EvaluateXPath("//button[@id='NtfFullList']")[0].Click()
    self.page.Wait()
    table_obj=self.page.EvaluateXPath("//table[@id='NtfWorklist:Content']")[0]
    tot_rows=table_obj.RowCount    
    self.log_message_web("Total Number Of Open Notifications : " + VarToStr(tot_rows))    
    batch_name=VarToStr(app.Cells.Item[2,9])
    Delay(2000)
   
    for i in range(0,VarToInt(tot_rows)-1):
      subject=table_obj.FindChild("name","Cell("+aqConvert.VarToStr(i)+",3)",10).contentText
      Delay(2000)
#      Subject_batch_name=subject[14:49]
#      if (VarToStr(Subject_batch_name) == batch_name):
      if batch_name in subject:   
        self.log_message_web("Journal Name: "+ subject)
        self.page.Find("idStr","N*:NtfSubject:"+aqConvert.VarToStr(i),30).Click()
        Delay(3000)
        self.log_message_web("Found Batch Name : " + VarToStr(batch_name) + " ; Click Approve next")
        Delay(3000)        
        self.page.EvaluateXPath("//button[@title='Approve']")[0].Click()
        self.page.wait()
        break

    


    
