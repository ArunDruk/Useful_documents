﻿from dbhelper import *
from ebiz import *
from file_system_utils import *


#tc84515 is to reverse journals manually 
#Capturing the journal header &line level information from DB 
#Capturing Reverse Journals Concurrent Program Log Messages

class journals_reversal(Ebiz): 
 global rowno
 op_log_path="C:\\TC_Logs"
 
 def login(self):
    self.login_user="sburugupal"
    super().login()
 
 def action(self):  
    
    DDT.ExcelDriver(Project.Path+"\\DataSheets\\Oracle-GL-Journal\\Journals_2.xls","Sheet1",True) #provide relative path
    rowno=0
    while not DDT.CurrentDriver.EOF(): #loop to execute functions till last row in excel
       self.navigate_gladmin(rowno)
       rowno=+1
       DDT.CurrentDriver.Next()
    DDT.CloseDriver(DDT.CurrentDriver.Name)  

    
 def navigate_gladmin(self,rowno):  
    Log.Message("Inside action") 
    Delay(4000)
    if rowno ==0:    
     self.page.WaitProperty("contentText","GL Administrator",6000)    
     self.page.EvaluateXPath("//a[@id='AppsNavLink' and contains(text(),'GL Administrator')]")[0].Click() 
     self.log_message_web("Click 'GL Administrator' - Successful")        
     self.page.Wait()
    self.page.WaitProperty("contentText","Enter",6000) 
    self.page.EvaluateXPath("//a[@id='N57']")[0].Click()    
    self.page.wait()
    Log.Checkpoint("Click 'Enter Journals' - Successful")
    self.log_message_web("Click 'Enter Journals' - Successful") 
    aqUtils.Delay(3000)
    jFrame=Sys.Browser("iexplore").WaitSwingObject("JBufferedFrame", "*", -1, 10000)
    ok_btn=Sys.Browser("iexplore").SwingObject("JBufferedFrame", "Oracle Applications*", -1).FindChild("AWTComponentName","ChoiceBox*",60)
    ok_btn.Find("AWTComponentAccessibleName","OK ALT O",40).Click()
    aqUtils.Delay(5000) 
    
    #Entering the Journal name that needs to be reversed
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Journals","ExtendedFrame"]
    find_jrnl_form=Sys.Browser("iexplore").SwingObject("JBufferedFrame", "Oracle Applications*", -1).FindChild(prop,val,60)
    find_jrnl_form.Find("AWTComponentAccessibleName","JournalList of Values",10).Click()
    find_jrnl_form.Find("AWTComponentAccessibleName","JournalList of Values",10).SetText(DDT.CurrentDriver.Value[0])
    obj=find_jrnl_form.Find("AWTComponentAccessibleName","JournalList of Values",10)
    if obj.Exists:
        self.log_checkpoint_message_web("Finding Journal is successful")
    else:
        self.log_message_oracle_form(jFrame,"Unable to find Journal")
    aqUtils.Delay(1000)
    jFrame.Keys("~i")
    aqUtils.Delay(1000)
    jFrame.Keys("~u")
    aqUtils.Delay(1000)
    
    #Reversing the Journal
    jFrame.Keys("~r")
    aqUtils.Delay(1000)
    jFrame.Keys("~o")
    aqUtils.Delay(1000)
    Log.Checkpoint("Click 'Journal Reversal' - Successful")
    
    #Capturing Reverse Journals Concurrent Program Request ID
    self.log_message_oracle_form(jFrame,"Jouranl Reversal Initiated") 
    RequestID = ''.join(x for x in jFrame.find("AWTComponentAccessibleName","Your concurrent request ID is*",100).AWTComponentAccessibleName if x.isdigit()) 
    Log.Enabled=True 
    Log.Message("Reverse Journals Concurrent Program Request ID " + aqConvert.VarToStr(RequestID))
    aqUtils.Delay(1000)
    jFrame.Keys("~o")
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    
    #Capturing Reverse Journals Concurrent Program status from Database
    dbhelper.verify_oracle_concurrent_job_status(RequestID) 
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~s")
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Requests","ExtendedFrame"]
    jFrame=Sys.Browser("iexplore").SwingObject("JBufferedFrame", "*", -1, 1)
    find_req_form=jFrame.FindChild(prop,val,10)
    find_req_form.Find("AWTComponentAccessibleName","Request ID",10).Click()
    find_req_form.Find("AWTComponentAccessibleName","Request ID",10).SetText(RequestID)
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000)
    jFrame.Keys("~g")
    Delay(1000)
    log_page=Sys.Browser("iexplore").Page(self.testConfig['ebiz']['url']+"/OA_CGI/FNDWRR.*")
    log_page.Click()
    log_page.TextNode(0).Click()
    Delay(1000)
    log_page.Keys("~f")
    Delay(1000)
    log_page.Keys("a")
    Delay(1000) 
    
    #Capturing Reverse Journals Concurrent Program Log Message    
    file_system_utils.create_folder(self.op_log_path)             
    log_path=self.op_log_path+"\\output_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
    Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
    Delay(1000)
    Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
    Delay(1000)
    Log.Enabled=True
    Log.File(log_path, "Log file attached.")
    Log.Enabled=False        
    Delay(1000)
    jFrame.Click()
    Delay(1000)
    
  #Capturing Journal Header and Line Level Information from the data base 
    dbhelper.verify_oracle_journal_status(DDT.CurrentDriver.Value[0])
    Log.Checkpoint("'verify_oracle_journal_status' - Successful")
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~o")
    Delay(1000)
    self.browser.page("*").Close() 
    Delay(1000)
    self.browser.page("*").Close()  
