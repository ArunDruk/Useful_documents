﻿from base import *
from driverchain import *
from ebiz import *
import test_utility
import gvar
import tc_logs



class Driver(Driverchain):
  global classarr,env
  
  def __init__(self):
    global test_env, sheet_obj, book     
    app = Sys.OleObject["Excel.Application"]
    Delay(1000)
    self.book = app.Workbooks.Open(Project.Path+"\\datasheets\\E2E\\E2E_002_IS.xls")          
#    app.Visible = "True"    
    self.test_env=BuiltIn.ParamStr(14)
    self.oper_unit=BuiltIn.ParamStr(15) 
#    self.test_env="oci_stage"
#    self.oper_unit="US"
    self.classarr=["ie_clear_cache()","tc173265_is_us_project_creation()","tc169768_is_us_create_non_catalog_req()","tc244955_is_us_approve_requisition()","tc169773_is_us_create_po()","tc169774_is_us_auto_create_po_approval_validation()","ie_clear_cache()","tc186234_prc_update_summary_amounts_single_project()","tc202082_is_us_review_project_commitments_po()","tc170429_is_us_ReceivePoItems()","tc170430_is_us_create_manual_ap_invoice_match()","ie_clear_cache()","tc170432_is_us_create_accounting()","tc170974_is_us_ap_invoices_initiate_approval()","ie_clear_cache()","tc170976_is_us_validate_subledger_accounting()","tc172393_is_us_next_day_check_payment()","tc172759_is_us_journal_validation()","ie_clear_cache()","tc199631_is_us_create_manual_expenditure_entry()","tc201347_us_run_prc_nightly_request_set()","validate_db_nightly_process_completion()","tc202036_us_validate_prc_nightly_request_set()","ie_clear_cache()","tc185103_is_create_project_asset()","tc185165_is_prc_generate_asset_lines_for_a_single_project()","tc185166_is_prc_interface_assets_to_oracle_assets()","ie_clear_cache()","tc185936_is_post_mass_additions()","tc186160_is_asset_tieback()"]             
    super().__init__(self.classarr)
        
  def close_excel(self):    
    self.book.save()
    delay(1000)
    self.book.close()
    

def main():
 try:
   gvar.dataprep['env'] = BuiltIn.ParamStr(14)
   obj=Driver()
   #As part of stabilization work - Sindhu
#   test_utility.start_test(__name__.center(70,'*'),'Core Financials - CF','MAN E2E','190532','MAN E2E - OCI Stage')
   if obj.test_env.lower()=="oci_stage":
     test_utility.start_test(__name__.center(70,'*'),'Core Financials - CF','MAN E2E','190532','MAN E2E - OCI Stage')
   elif obj.test_env.lower()=="oci_test":
     test_utility.start_test(__name__.center(70,'*'),'Core Financials - CF','MAN E2E','190532','MAN E2E - OCI Test')
   cobj = obj.run()
   print('evoke test_utility')
 except:
   gvar.dataprep['verdict'] = 'Fail'
   tc_logs.header_name('Test Failed - traceback shown below')       
   tc_logs.error_with_no_picture(traceback.format_exc(),'')       
   print('evoke test_utility')
 finally:
   test_utility.end_test()
   obj.close_excel()


