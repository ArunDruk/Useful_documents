﻿from base import *
from driverchain import *
from ebiz import *
  
  
class Driver(Driverchain):
    global classarr,env
    
    def __init__(self):
      global test_env, sheet_obj, book     
      app = Sys.OleObject["Excel.Application"]
      Delay(1000)
      self.book = app.Workbooks.Open(Project.Path+"\\datasheets\\WCI\\wcc_ca_2_npo.xls")          
      app.Visible = "True"    
      self.test_env="oci_stage"
      self.oper_unit="US"
      self.classarr=["capture_invoice_via_email()","ie_clear_cache()","WCC_verify_batch_creation_2page()"]
#      self.classarr=["WCC_verify_batch_creation_2page()"]
      super().__init__(self.classarr)
      
    def close_excel(self):    
      self.book.save()
      delay(1000)
      self.book.close()
      
      
      
def main():  
    obj=Driver()
    cobj = obj.run()
    obj.close_excel()
