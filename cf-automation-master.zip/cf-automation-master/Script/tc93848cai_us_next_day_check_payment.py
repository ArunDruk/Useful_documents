﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils
import web_utils

#This test case is to make nextday check payment for an AP INVOICE and retrieving the payment status

class tc93848cai_us_next_day_check_payment(Ebiz):
 global rowno, app

  
 def login(self):
    self.login_user="mcampbell8"
    super().login()

 def action(self,book): 
    self.page.wait_until_page_loaded()
    app = book.Sheets.item["Invoice"]
    app1 = book.Sheets.item["Requisition"]
    rowno = 2
    
    Log.Message("Inside action...") 
    self.page.WaitProperty("contentText","CAI "+self.oper_unit+" AP PAYMENT PROCESSING",6000)
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" AP PAYMENT PROCESSING')]")
#    cai_ap_paypro_link=self.page.NativeWebObject.Find("contentText","CAI "+self.oper_unit+" AP PAYMENT PROCESSING","A")
#    self.verify_aqobject_chkproperty(cai_ap_paypro_link,"contentText",cmpIn,"CAI "+self.oper_unit+" AP PAYMENT PROCESSING")
#    cai_ap_paypro_link.Click() 
    self.log_message_web("Click 'CAI "+self.oper_unit+" AP PAYMENT PROCESSING' - Successful")
    
#    self.page.wait_until_page_loaded()
    Delay(2000)
    self.page.EvaluateXpath("//table[@id='respList']//div[text()='Payments']")[0].Click()
    self.log_message_web("Click 'Payments' - Successful")
#    self.page.NativeWebObject.Find("contentText","Payments","A").Click()
#    self.page.wait_until_page_loaded()
    Delay(2000)
    self.page.EvaluateXpath("//table[@id='respList']//div[text()='Entry']")[0].Click()
    self.log_message_web("Click 'Entry' - Successful")
#    self.page.NativeWebObject.Find("contentText","Entry","A").Click()
#    self.page.wait_until_page_loaded()  
    Delay(2000)
    self.page.EvaluateXpath("//table[@id='respList']//div[text()='Payments Manager']")[0].Click()
    self.log_message_web("Click 'Payments Manager' - Successful")
#    self.page.NativeWebObject.Find("contentText","Payments Manager","A").Click()
    self.page.wait_until_page_loaded()
    Delay(2000)
    while self.page.contentDocument.readyState != "complete":
      Delay(1000)
    
    cai_ap_subreq_link=self.page.Find("contentText","Submit Single Payment Process Request",30)
#    self.verify_aqobject_chkproperty(cai_ap_subreq_link,"contentText",cmpIn,"Submit Single Payment Process Request")
    cai_ap_subreq_link.Click() 
    self.log_message_web("Click Submit Single Payment Process Request - Successful")
    self.page.wait_until_page_loaded()
    Delay(3000)
    
#Entering Payment Process Request Name
    self.page.Find("idStr","CheckrunName",30).Click()
    pay_des="CAI_AP_Payment_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")
    self.page.Find("idStr","CheckrunName",30).Keys(pay_des)
    self.log_message_web("Enter Payment Process Request Name - Successful")
    delay(2000)
    
#Entering Payment Template
    self.page.Find("idStr","TemplateName",30).Click()
    self.page.Find("idStr","TemplateName",30).Keys("WFPM Next Day Check")
    self.page.Keys("[Tab]")
    self.log_message_web("Select Payment Template - Successful")
    delay(2000)
    
#Entering Payee Information  
    self.page.Find("idStr","Payee",30).Click()
    payee = app1.Cells.Item[rowno,9]
    self.log_message_web("payee value "+VarToStr(payee))
    self.page.Find("idStr","Payee",30).Keys(payee)
    self.page.Keys("[Tab]")
    delay(2000)
#    self.page.Find("idStr","Payee",30).Click()
    self.page.Find("idStr","Submit",30).Click()
    self.page.wait_until_page_loaded()
    Delay(2000)
    self.page.Find("idStr","SearchCheckrunName",30).Click()
    self.page.Find("idStr","SearchCheckrunName",30).Keys(pay_des)
    self.page.Keys("[Tab]")
    delay(2000)
    
#Submitting for the payment
    self.page.Find("contentText","Go",30).Click()
    self.log_message_web(pay_des+" - Payment Submitted")
    self.page.wait_until_page_loaded()
    Delay(2000) 
#Invoice Pending Review
    paymnt_status=self.page.EvaluateXPath("//span[@id='ResultsTable:StatusCodeDsp:0']")[0].contentText
    while paymnt_status != 'Invoices Pending Review':
      Delay(4000)
      self.page.Find("idStr","ResultsTable:Refresh:*",30).Click()
      self.page.wait_until_page_loaded()
      paymnt_status=self.page.EvaluateXPath("//span[@id='ResultsTable:StatusCodeDsp:0']")[0].contentText
      if paymnt_status == "Cancelled - No Invoices Selected":
        web_utils.log_error("No Invoices Selected for Payment")
      
    delay(2000) 
    self.page.Find("namePropStr","takeaction_enabled.gif",30).Click()
    self.page.wait_until_page_loaded()
    self.page.Find("idStr","ResubmitPsr",30).Click() 
    self.log_message_web(pay_des+" - Invoices Pending Review")
    self.page.wait_until_page_loaded()

#Pending Proposed Payment Review   
    while paymnt_status != 'Pending Proposed Payment Review':
     Delay(4000)
     self.page.Find("idStr","ResultsTable:Refresh:*",30).Click()
     self.page.wait_until_page_loaded()
     paymnt_status=self.page.EvaluateXPath("//span[@id='ResultsTable:StatusCodeDsp:0']")[0].contentText 
    self.page.wait_until_page_loaded()
    self.page.Find("namePropStr","takeaction_enabled.gif",30).Click()
    self.page.wait_until_page_loaded()
#    self.page.Find("contentText","Go",30).Click()
    self.log_message_web("Invoices Selected")
    delay(2000)
    self.page.EvaluateXPath("//button[@title='Go']")[0].Click()
    self.page.wait_until_page_loaded()
    self.page.Find("idStr","SearchCheckrunName",30).Click()
    self.page.wait_until_page_loaded()
    self.page.Find("idStr","SearchCheckrunName",30).SetText("")
    Delay(1000)
    self.page.Find("idStr","SearchCheckrunName",30).Keys(pay_des)
    Delay(1000)
    self.page.Keys("[Tab]")
    delay(2000)
    self.log_message_web("Invoices Selected for Payment")
    delay(2000)
    self.page.FindChildEx("contentText","Go",60,True,60000).Click()
    self.log_message_web(pay_des+" - Pending Proposed Payment Review")
    self.page.wait_until_page_loaded()
    
#Confirmed Payment    
    while paymnt_status != 'Confirmed':
       Delay(4000)
       self.page.Find("idStr","ResultsTable:Refresh:*",30).Click()
       self.page.wait_until_page_loaded()
       paymnt_status=self.page.EvaluateXPath("//span[@id='ResultsTable:StatusCodeDsp:0']")[0].contentText
    self.log_message_web(pay_des+" - Confirmed Payment")

#Invoice Inquiry 
#    self.page.Find("contentText","Home",30).Click()
    self.page.EvaluateXPath("//img[@title='Home']")[0].Click()
    self.page.wait_until_page_loaded()
#    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" AP INQUIRY')]")
#    self.log_message_web("Click 'CAI "+self.oper_unit+" AP INVOICE INQUIRY' - Successful")
#    Delay(1000)
#    self.wait_until_page_loaded() 
#    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Invoices Inquiry')]")
#    self.log_message_web("Click 'Invoices' - Successful") 
#    Delay(1000)
#    self.wait_until_page_loaded()
#    self.page.EvaluateXPath("//div[text()='Invoices']")[0].Click()
#    self.log_message_web("Click 'Invoices' - Successful")
#    delay(5000)
#    web_utils.validate_security_box()
#    delay(5000)
#    jFrame = self.initializeJFrame()
#    Delay(10000)
#    form_utils.click_ok_btn(jFrame)
#    Delay(10000)
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Find Invoices","ExtendedFrame"]
#    par_form=jFrame.FindChild(prop,val,60)
#    prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
#    val=["Invoice: Number","VTextField","6"]
#    inv_num=par_form.FindChild(prop,val,60)
#    inv_num.Find("AWTComponentAccessibleName","Invoice: Number").Click()
#    Delay(10000)
#    inv_num.Find("AWTComponentAccessibleName","Invoice: Number",10).SetText(app.Cells.item[rowno,13])
#    Delay(4000)
#    prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
#    val=["Invoice: Dates: StartList of Values","VTextField","12"]
#    inv_num=par_form.FindChild(prop,val,60)
#    inv_num.Find("AWTComponentAccessibleName","Invoice: Dates: StartList of Values").Click()
#    inv_num.SetText(aqConvert.DateTimeToFormatStr(aqDateTime.Today(),"%d-%b-%Y"))
#    Delay(4000)
#    prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
#    val=["Invoice: Dates: EndList of Values","VTextField","13"]
#    inv_num=par_form.FindChild(prop,val,60)
#    inv_num.Find("AWTComponentAccessibleName","Invoice: Dates: EndList of Values").Click()
#    inv_num.SetText(aqConvert.DateTimeToFormatStr(aqDateTime.Today(),"%d-%b-%Y"))
#    delay(1000) 
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Find Invoices","ExtendedFrame"]
#    Findinvoices=jFrame.FindChild(prop,val,60)
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Find alt i","Button"]
#    Findbutton=Findinvoices.FindChild(prop,val,60)
#    Findbutton.Find("AWTComponentAccessibleName","Find alt i").Click()
##    jFrame.Keys("~i")
#    delay(8000)
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Invoice Workbench*","ExtendedFrame"]
#    inv_wrkbch=jFrame.FindChild(prop,val,60)
#
#    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#    val=["Status",4]
#    inv_status=inv_wrkbch.FindChild(prop,val,60)
#    Log.Enabled=True
#    aqObject.CheckProperty(inv_status,"wText",cmpIn,"Validated")
#    Log.Enabled=False
#    self.log_message_oracle_form(jFrame,"Invoice Is Validated")
#    
#    jFrame.Keys("~4")
#    delay(2000)
#    jFrame.Keys("~p")
#    delay(2000)
#    
#    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#    val=["Status",7]
#    pay_recon_status=jFrame.FindChildEx(prop,val,60,True,90000)
#    Log.Enabled=True
#    aqObject.CheckProperty(pay_recon_status,"wText",cmpIn,"Negotiable")
#    Log.Enabled=False
#    self.log_message_oracle_form(jFrame,"Invoice Is Paid")
    dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
    user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
    pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
    dbhelper.verify_oracle_payment_status(dsn,user_id,pwd,VarToStr(app.Cells.item[rowno,13]))
#    dbhelper.verify_oracle_payment_status(VarToStr(app.Cells.item[rowno,13]))
    delay(2000)
#    jFrame.Keys("[F4]")
#    Delay(1000)
#    jFrame.Keys("[F4]")
#    Delay(1000)
#    jFrame.Keys("[F4]")
#    Delay(1000)
#    jFrame.Keys("~o")
#    Delay(1000)
#    Sys.Browser("iexplore").page("https://core-*.epfinnp.coxautoinc.com/forms/frmservlet*").Close()
#    del app,jFrame,val,prop,inv_status



