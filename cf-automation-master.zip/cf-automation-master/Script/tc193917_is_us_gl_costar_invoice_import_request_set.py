﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils
import winscp_utility
import tc_logs
from File_Handler import File_Handler as _TXTOBJ
from text_headers import payroll_txt_file_header as _HEADERS
import web_utils
import form_utils
import datetime as dt

class tc193917_is_us_gl_costar_invoice_import_request_set(Ebiz):
  
  op_log_path="C:\\TC_Logs"
  is_gl_costar_files="C:\\IS_GL_Costar_Files"
  
  def login(self):
      self.login_user="mfallwell"
      super().login()

  def goto_url(self,url):
    super().goto_url(self.testConfig['ebiz']['oci_is_url'])
    
    
  def action(self,book):
    self.files = "CoStar_GL_IS_US_2020.txt"
    self.place_files_local()
    self.process_files()
    self.place_files_winscp()
    
## Place Costar Files in Local Folder:

  def place_files_local(self):   
    Log.Message("Entering into function 'place_files_local'")
    file_system_utils.create_folder(self.is_gl_costar_files)
    file_exist=aqFileSystem.FindFiles("C:\\IS_GL_Costar_Files",self.files)
    if file_exist != None:
     aqFileSystem.DeleteFile("C:\\IS_GL_Costar_Files\\"+self.files)
    aqFileSystem.CopyFile(Project.Path+"DataSheets\\Oracle-GL-Journal\\IS\\"+self.files, "C:\\IS_GL_Costar_Files\\"+self.files)
    log_path = ("C:\\IS_GL_Costar_Files\\"+self.files)
    Log.Enabled=True
    Log.File(log_path, "CoStar GL File Attached")
    Log.Enabled=False 


## Read/Modify/Write CoStar Files:

  def process_files(self):  
    sys_lease_id_line = aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%S%M")
    journal_entry_id_line = aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%S%M")
    journal_name_line = aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%S%M")
    accounting_date = aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%m/%d/%Y")
    path = "C:\IS_GL_Costar_Files\\"+self.files
    cobj = _TXTOBJ(path,"|")
    List_of_Dict=cobj.Read()
    count =1
    
    for index,Dict in enumerate(List_of_Dict):
        for k in Dict.keys():
            if(k=="System_Lease_ID"):
                Dict[k]=sys_lease_id_line
            elif(k=="Journal_Entry_ID"):
                Dict[k]=journal_entry_id_line
            elif(k=="Journal_Name"):
                L=Dict[k].split("-")
                ele=journal_name_line+'-'+L[-1]
                Dict[k]=ele

            elif(k=="Accounting_Date"):
                Dict[k]=accounting_date
            
        if (count < len(List_of_Dict)):
           Dict['Journal_Line_ID'] = VarToStr(int(dt.datetime.now().strftime("%Y%m%d%H%M%S%f"))+int(index))
           Delay((1000))
           count+=1                    
    
    def Write(rows):
      def return_str(row):
        return "|".join(item for item in row.values())+'\n'
      
      header = "|".join(key for key in rows[0].keys())
      with open(path, 'w') as file:
        file.write(header+'\n')
        file.writelines("".join([return_str(row)
                                for row in rows]))
    
    Write(List_of_Dict)


## Place CoStar Files on server
  def place_files_winscp(self): 
    Stored_session = "costar@mftstg.manheim.com"  
    local_dir = "C:\\IS_GL_Costar_Files"
    remote_dir =  self.testConfig['winscp']['gl_blkn_dir'] 
    upload_file_name = "C:\\IS_GL_Costar_Files\\CoStar_GL_IS_US_2020.txt"
    winscp_utility.upload_file(Stored_session,local_dir,remote_dir,upload_file_name)
    Log.Enabled=True       
    Log.Message("CoStar File CoStar_GL_IS_US_2020.txt placed in the //Outbox//IS// directory")           
    Log.Enabled=False
    
    web_utils.log_checkpoint("Login to Oracle Appications Successful",500,self.page)
    self.page.WaitProperty("contentText","GL SCHEDULER",6000)
    cai_GL_Scheduler_link=self.page.Find("contentText","GL SCHEDULER",30)
    self.verify_aqobject_chkproperty(cai_GL_Scheduler_link,"contentText",cmpIn,"GL SCHEDULER")
    cai_GL_Scheduler_link.Click()
    web_utils.log_checkpoint("Click 'GL SCHEDULER' - Successful",500,self.page)
    delay(2000)   
    self.wait_until_page_loaded()
    self.page.Find("contentText","Requests",30).Click()
    web_utils.log_checkpoint("Click 'Requests' - Successful",500,self.page)
    delay(1000)
    self.wait_until_page_loaded()
    self.page.Find("contentText","Run",30).Click()
    web_utils.log_checkpoint("Click 'Run' - Successful",500,self.page)
    delay(3000) 
    web_utils.validate_security_box()
    Delay(15000)
    jFrame=self.initializeJFrame()
    form_utils.click_ok_btn(jFrame)  
    Delay(3000)
  
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit a New Request","ExtendedFrame"]
    submit_new_req_form=jFrame.FindChildEx(prop,val,60,True,90000)
    jFrame.Keys("~s")
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["What type of request do you want to run? Request Set alt s","ExtendedCheckbox"]  
    submit_new_req_form.FindChild(prop,val,10).Click()       
    Delay(3000)
    jFrame.Keys("~o")
    Delay(5000)
    
    jFrame.Find("AWTComponentAccessibleName","Request Set RequiredList of Values",60).setText("MAN Oracle GL Inbound JE Interface Request Set - CoStar")
    web_utils.log_checkpoint("Going to submit 'MAN Oracle GL Inbound JE Interface Request Set - CoStar' ",500,jFrame)
    Delay(3000)
    jFrame.Find("AWTComponentAccessibleName","Program",60).Click()
    delay(3000)
    jFrame.Find("AWTComponentName","VTextField28",60).Click()   
    Delay(3000)
    jFrame.Keys("~o")
    Delay(3000)
    jFrame.Find("AWTComponentName","VTextField29",60).Click()
    Delay(3000)
    jFrame.Keys("~o")
    Delay(3000)
    jFrame.Find("AWTComponentName","VTextField30",60).Click()
    Delay(3000)
    jFrame.Keys("~o")
    Delay(3000)
    jFrame.Find("AWTComponentName","VTextField31",60).Click()
    Delay(3000)
    jFrame.Keys("~o")
    Delay(3000)
    web_utils.log_checkpoint("'MAN Oracle GL Inbound JE Interface Request Set - CoStar' parameters entered successfully ",500,jFrame)
    jFrame.Find("AWTComponentAccessibleName","Submit",60).Click()
    Delay(5000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Decision Request Submitted*","ChoiceBox"]
    decision_form=jFrame.FindChildEx(prop,val,60,True,40000)  
    RequestID = ''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit())
    web_utils.log_checkpoint("'MAN Oracle GL Inbound JE Interface Request Set - CoStar' is submitted and Request ID is " + aqConvert.VarToStr(RequestID),500,jFrame)
    Delay(2000)
    Rid =aqConvert.VarToStr(RequestID)
    jFrame.Keys("~n")
    Delay(9900)  
    dsn = self.testConfig['man_oracle_db']['dsn']
    user_id = self.testConfig['man_oracle_db']['userid']
    pwd = self.testConfig['man_oracle_db']['pwd']
    dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,RequestID)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000) 

# Gathering Request ID and Log File for the "MAN Global Data Loader" 
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,90000)
    self.req_set_save_log(jFrame,req_form,"MAN Global Data Loader",RequestID)
    fo=open(self.log_path,"r")
    lines=fo.readlines()
    Log.Enabled=True
    Log.Message(lines[30][0:100].strip())
    Log.Message(lines[59][0:100].strip())
    Log.Message(lines[60][0:110].strip())
    Log.Message(lines[165][:85].strip())
    Log.Message(lines[166][0:104].strip())
    Log.Message(lines[167][0:104].strip())
    Log.Message(lines[168][0:104].strip())
    Log.Enabled=False
    jFrame.Click()
    Delay(2000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000)
  

# Gathering Request ID and Log File for the "MAN Oracle CoStar GL Preprocessor Program" 
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,90000)
    self.req_set_save_output(jFrame,req_form,"MAN Oracle CoStar GL Preprocessor Program",RequestID)
    jFrame.Click()
    Delay(2000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000)
       

# Gathering Request ID and Log File for the "MAN Oracle GL Inbound JE Interface Program" 
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,90000)
    self.req_set_save_output(jFrame,req_form,"MAN Oracle GL Inbound JE Interface Program",RequestID)
    jFrame.Click()
    Delay(2000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000)


# Gathering Request ID and Log File for the "Journal Import" 
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,90000)
    req_id_parent=self.req_set_save_output(jFrame,req_form,"Journal Import",RequestID)
    jFrame.Click()
    Delay(2000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~o")
    Delay(1000)

# Reviewing and posting the journal and capturing the Posting: Single Ledger output
    web_utils.log_checkpoint("Validating CoStar Journal Import Process",500,self.page)
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='menuContent']//div[contains(text(),'GL Corporate Accounting User')]") 
    self.wait_until_page_loaded()
    self.page.NativeWebObject.Find("contentText","Journals","A").Click()
    web_utils.log_checkpoint("Click 'Journals' - Successful",500,self.page)
    delay(2000)
    self.page.NativeWebObject.Find("contentText","Enter","A").Click()
    web_utils.log_checkpoint("Click 'Enter' - Successful",500,self.page)
    web_utils.validate_security_box()
    Delay(15000)
    jFrame=self.initializeJFrame()
    Delay(5000)
    form_utils.click_ok_btn(jFrame)
    Delay(3000) 
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Journals","ExtendedFrame"]
    #j_req_id = app.Cells.Item[2,14]
    fnd_jrnl=jFrame.FindChildEx(prop,val,60,True,90000)
    fnd_jrnl.Find("AWTComponentAccessibleName","BatchList of Values",10).Click()
    fnd_jrnl.Find("AWTComponentAccessibleName","BatchList of Values",10).Keys("%"+VarToStr(req_id_parent)+"%")
    delay(1000) 
    jFrame.Keys("~i")
    web_utils.log_checkpoint("Finding the CoStar Journal' ",500,jFrame)
    delay(20000) 
    web_utils.log_checkpoint("Find CoStar Journal Successful' ",500,jFrame)
    jFrame.Keys("~u")
    delay(10000) 
    web_utils.log_checkpoint("Review Journal Header and Line Information",500,jFrame)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Journals*","ExtendedFrame"]
    jrnls=jFrame.FindChildEx(prop,val,60,True,60000)
    jrnls.FindChild("AWTComponentName","FormsTabPanel*",60).ClickTab("Other Information")
    Log.Enabled=False
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Status: Posting",0]
    jrnl_val = jFrame.FindChild(prop,val,60)
    jrnl_status=jrnl_val.wText   
    Log.Enabled=True
    aqObject.CheckProperty(jrnl_val,"wText",cmpIn,"Unposted")
    Log.Enabled=False
    web_utils.log_checkpoint("Journal is 'Unposted'",500,jFrame)
    delay(4000) 
    jrnls.FindChild("AWTComponentName","FormsTabPanel*",60).ClickTab("Lines")
    delay(5000) 
    web_utils.log_checkpoint("Post the Journal next",500,jFrame)
    jFrame.Keys("~p")
    delay(10000)
    RequestID = ''.join(x for x in jFrame.find("AWTComponentAccessibleName","Your concurrent request ID*",100).AWTComponentAccessibleName if x.isdigit())
    web_utils.log_checkpoint("'Posting: Single Ledger' is submitted and Request ID is " + aqConvert.VarToStr(RequestID),500,jFrame)
    Delay(2000)
    Rid =aqConvert.VarToStr(RequestID)
    jFrame.Keys("~o")
    Delay(9900)  
    dsn = self.testConfig['man_oracle_db']['dsn']
    user_id = self.testConfig['man_oracle_db']['userid']
    pwd = self.testConfig['man_oracle_db']['pwd']
    dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,RequestID)
    delay(1000) 
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,90000)
    self.req_set_save_output(jFrame,req_form,"Posting: Single Ledger",RequestID)
    Delay(1000)
    jFrame.Click()
    Delay(2000)
    jFrame.Keys("[F4]")
    Delay(2000)

# Reviewing journal and validating the check points
    jFrame.Keys("j")
    delay(2000) 
    jFrame.Keys("e")
    delay(2000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Journals","ExtendedFrame"]
    fnd_jrnl=jFrame.FindChildEx(prop,val,60,True,90000)
    fnd_jrnl.Find("AWTComponentAccessibleName","BatchList of Values",10).Click()
    fnd_jrnl.Find("AWTComponentAccessibleName","BatchList of Values",10).Keys("%"+VarToStr(req_id_parent)+"%")
    web_utils.log_checkpoint("Requering the Journal to the check the 'Journal Posting Status'",500,jFrame)
    jFrame.Keys("~i")
    delay(20000) 
    jFrame.Keys("~u")
    delay(10000) 
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Journals*","ExtendedFrame"]
    jrnls=jFrame.FindChildEx(prop,val,60,True,60000)
    jrnls.FindChild("AWTComponentName","FormsTabPanel*",60).ClickTab("Other Information")
    Log.Enabled=False
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Status: Posting",0]
    jrnl_val = jFrame.FindChild(prop,val,60)
    jrnl_status=jrnl_val.wText   
    Log.Enabled=True
    aqObject.CheckProperty(jrnl_val,"wText",cmpIn,"Posted")
    Log.Enabled=False
    web_utils.log_checkpoint("Journal is 'Posted'",500,jFrame)
    delay(4000) 
    jrnls.FindChild("AWTComponentName","FormsTabPanel*",60).ClickTab("Lines")
    delay(2000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~o")
    
    

  def req_set_save_output(self,jFrame,req_form,srch_child_name,Preqid):
     web_utils.log_checkpoint("Checking for "+aqConvert.VarToStr(srch_child_name)+ " Child Program Status",500,jFrame)
     i=20
     prop=["AWTComponentAccessibleName","AWTComponentIndex"]
     val=["Request ID",i-10] 
     creqid=VarToInt(req_form.Find(prop,val,10).wText)
              
              
     for x in range(i,50):
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Name",x]
        child_name=req_form.Find(prop,val,10)
        child_name.Keys("[Enter]")
        child_name.Click()
        child_name=child_name.wText
        
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Phase",i+20]
        phase=req_form.Find(prop,val,10).wText 
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Request ID",i-10]
        creqid=VarToInt(req_form.Find(prop,val,10).wText) 
        
                            
        if x>20:
           jFrame.Keys("[Down]") 
           
           Delay(1000)
           prop=["AWTComponentAccessibleName","AWTComponentIndex"]
           val=["Phase",i+20]
           phase=req_form.Find(prop,val,10).wText 
           prop=["AWTComponentAccessibleName","AWTComponentIndex"]
           val=["Request ID",i-10]
           creqid=VarToInt(req_form.Find(prop,val,10).wText)

                          
           
        if (child_name==srch_child_name) and (creqid >= VarToInt(Preqid)): # and (phase == "Completed")
          web_utils.log_checkpoint(aqConvert.VarToStr(srch_child_name)+" Phase Completed Successfuly",500,jFrame)         
          Delay(600)
          prop=["AWTComponentAccessibleName","JavaClassName"]
          val=["View Output alt p","Button"]
          output_button=req_form.FindChild(prop,val,60)
          output_button.Find("AWTComponentAccessibleName","View Output alt p").Click()         
          #jFrame.Keys("~p")    
          Delay(3000)
          output_page=Sys.Browser("iexplore").Page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")            
          output_page.Click()
          Delay(2000)
          output_page.Keys("~f")
          Delay(6000)
          output_page.Keys("a")
          Delay(6000)
          file_system_utils.create_folder(self.op_log_path)             
          log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"Is Attached_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
          Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
          Delay(1000)
          Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
          Delay(2000)
          Log.Enabled=True
          Log.File(log_path, aqConvert.VarToStr(srch_child_name)+" is completed and Output File Is Attached")
          Log.Enabled=False       
          Sys.Browser("iexplore").page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close()  
          web_utils.close_additional_browsers()
          Delay(2000)   
 #         jFrame.Click()
          Delay(2000)
          val=["Name",20]
          req_form.Find(prop,val,10).Keys("[Enter]")
          Delay(500)
          if (srch_child_name=="Journal Import"): # Returning the Log path for the screenshot of Journal created
            return creqid
          return creqid
          break 
        elif i >=28:
           Delay(20000)
           prop=["AWTComponentAccessibleName","JavaClassName"]
           val = ["Refresh Data alt R","Button"]
           req_form.FindChild(prop,val,2000).Click()

           Delay(3000)
           i=20
           val=["Name",i]
           child_name=req_form.Find(prop,val,10).wText 

 
  def req_set_save_log(self,jFrame,req_form,srch_child_name,Preqid):
    web_utils.log_checkpoint("Checking for "+aqConvert.VarToStr(srch_child_name)+ " Child Program Status",500,jFrame)
    req_form.FindChild("AWTComponentAccessibleName","Refresh Data alt R",20).Click()
    i=20
    for x in range(1,180):     
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Name",i]
        child_name=req_form.Find(prop,val,10).wText 
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Phase",i+20]
        phase=req_form.Find(prop,val,10).wText 
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Request ID",i-10]
        creqid=VarToInt(req_form.Find(prop,val,10).wText)
                                       
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Status",i+30]         
        status =req_form.FindChild(prop,val,60)            
        if (child_name==srch_child_name) and (creqid>=VarToInt(Preqid)) and (phase == "Completed"):
            web_utils.log_checkpoint(aqConvert.VarToStr(srch_child_name)+" Phase Completed Successfuly",500,jFrame)                            
            status.Keys("[Enter]")
            Delay(1000)
            req_form.FindChild("AWTComponentAccessibleName","View Log alt K",20).Click()  
            Delay(4000)
            output_page=Sys.Browser("iexplore").Page("https://manheim*.epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
            output_page.Click()
            Delay(2000)
            output_page.Keys("~f")
            Delay(2000)
            output_page.Keys("a")
            Delay(5000)
            file_system_utils.create_folder(self.op_log_path)             
            self.log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"File"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"_%d%b%Y_%H%M")+".txt"    
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(self.log_path)
            Delay(1000)
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
            Delay(8000)
            Log.Enabled=True
            Log.File(self.log_path, aqConvert.VarToStr(srch_child_name)+" is Completed And Log file is attached")
            Log.Enabled=False     
            web_utils.close_additional_browsers()         
            Filesaved = 'True'
            return                           
        elif i >=29:
           Delay(15000)           
           req_form.FindChild("AWTComponentAccessibleName","Refresh Data alt R",20).Click()
           Delay(3000)
           i=20
           val=["Name",i]
           child_name=req_form.Find(prop,val,10).wText
        else:  
           Delay(2000)
           i=i+1 


    
