﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils
import re 
import string
import web_utils
import random
import winscp_utility
import tc_logs
from File_Handler import File_Handler as _TXTOBJ
from text_headers import concur_txt_file_header as _HEADERS


class tc104273_is_us_concur_import_interface_prgm(Ebiz):
  op_log_path="C:\\TC_Logs"
  is_concur_extract_files="C:\\IS_Concur_Extract_Files"
  global rowno

  rowno = 2
  
  def login(self):
      self.login_user="rmaran"
      super().login()
      
  def goto_url(self,url):
   super().goto_url(self.testConfig['ebiz']['oci_is_url'])

  def action(self,book):  
    self.extract_file_name = "extract_CES_SAE_testfile_ML1"
    self.place_files_local(book)
#    self.process_files(book)
#    self.place_files_winscp()
    
## Place Payroll Files in Local Folder:
  def place_files_local(self, book):   
    import datetime as dt
    timestamp=int(dt.datetime.now().strftime("%Y%m%d%H%M%S%f"))
    file_system_utils.create_folder(self.is_concur_extract_files)
    file_exist=aqFileSystem.FindFiles("C:\\IS_Concur_Extract_Files",self.extract_file_name+".txt")
    if file_exist != None:
     aqFileSystem.DeleteFile("C:\\IS_Concur_Extract_Files\\"+self.extract_file_name+".txt")
    aqFileSystem.CopyFile(Project.Path+"DataSheets\\Oracle-AP-Other\\IS\\"+self.extract_file_name+".txt", "C:\\IS_Concur_Extract_Files\\"+self.extract_file_name+".txt")
    log_path = ("C:\\IS_Concur_Extract_Files\\"+self.extract_file_name+".txt")
    Log.Enabled=True
    Log.File(log_path, "Concur Original Extract File "+self.extract_file_name+".txt"+" Attached")
    Log.Enabled=False 

## Read/Modify/Write Payroll Files:
  
    app = book.Sheets.item["Concur"]
    import datetime as dt 
    import random
    new_rep_key = random.randint(111111,999999) + int(dt.datetime.now().strftime("%Y%m%d%H%M%S%f"))
    def counter(index,**kwargs):
#      kwargs['Report ID'] = int(dt.datetime.now().strftime("%Y%m%d%H%M%S%f"))+int(index)
      if kwargs['Constant'] == 'DETAIL':
        kwargs['Report Key'] = new_rep_key
      return kwargs 
    path = "C:\\IS_Concur_Extract_Files\\"+self.extract_file_name+VarToStr(timestamp)
    cobj = _TXTOBJ(log_path,"|")
    cobj.Write_txt_without_header([counter(index+1,**row) for index, row in enumerate(
            cobj.Read_txt_with_header(_HEADERS()))])
   
    WshShell.Run("notepad.exe", SW_NORMAL);
#    Utilities.FileOpen("C:\\IS_Concur_Extract_Files\\Concur mockup file with personal charges.txt", 2)
#    notepad = aqFile.OpenTextFile("C:\\IS_Concur_Extract_Files\\Concur mockup file with personal charges.txt", aqFile.faReadWrite, aqFile.ctUnicode)
    notepad=Sys.Process("notepad")
    wndNotepad = notepad.Window("Notepad")
    
    wndNotepad.MainMenu.Click("File|Open...")
    notepad.Window("#32770", "Open").OpenFile(log_path)
    Delay(2000)
    
    #New Concur Report Key
    app.Cells.item[rowno, 6] = VarToStr(new_rep_key)
    
    num_rmv=("|"+VarToStr(new_rep_key))
    Delay(1000)
    wndNotepad.Keys("^f")
    Delay(1000)
    wndNotepad.Keys(num_rmv)
    Delay(1000)
    wndNotepad.Keys("[Enter]")
    Delay(1000)
    wndNotepad.Keys("[Esc]")
    Delay(1000)
    wndNotepad.Keys("[Del]")
    Delay(1000)
    wndNotepad.Keys("~fa")
    Delay(3000)
    Sys.Keys(VarToStr(path)+".txt[Enter]")
    Delay(1000)
    self.log_active_screen("Concur Extract File updated; ready for processing")
    Delay(1000)
    show_file_in_log=VarToStr(path)+".txt"
    Log.Enabled=True
    Log.File(show_file_in_log, "Concur Updated Extract File "+show_file_in_log+" Attached")
    Log.Enabled=False 
    wndNotepad.Close()
#    
#    app.Cells.item[rowno, 1] = VarToStr(path)
#    app.Cells.item[rowno+1,1] = self.extract_file_name+VarToStr(timestamp)
#    
#    web_utils.close_additional_browsers()

### Place Payroll Files in WinScp:
#  def place_files_winscp(self,file):
##    for index in range(0,4):
#    Stored_session = "man_oracle@mftstg.manheim.com" 
#    local_dir = "C:\\IS_Concur_Extract_Files"
#    remote_dir =  self.testConfig['winscp']['remote_dir'] 
#    remote_dir = self.winscpConfig[self.testConfig['ebiz']['env']]['remote_dir']+"incoming//ATG_OU//GL_JE_BALANCES_INTF"
#    upload_file_name = self.files[index]
#    winscp_utility.upload_file(Stored_session,local_dir,remote_dir,upload_file_name)
#    Log.Enabled=True       
#    Log.Message("Payroll File "+self.files[index]+" placed in the GL_JE_BALANCES_INTF directory")           
#    Log.Enabled=False
