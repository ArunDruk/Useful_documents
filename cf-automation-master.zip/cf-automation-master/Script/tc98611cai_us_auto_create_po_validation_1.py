﻿from ebiz import *
import web_utils
import form_utils
import file_system_utils
import ebiz
import dbhelper


class tc98611cai_us_auto_create_po_validation_1(Ebiz):
  global rowno, val
  rowno = 2
  def login(self):
    self.login_user="rmaran"
    super().login()
  
  
  def action(self,book):
    
    self.op_log_path="C:\\TC_PO"
    
    app = book.Sheets.item["Invoice"]   
    app1 = book.Sheets.item["Requisition"]
    
    req = app1.Cells.Item[rowno,15]
    delay(2000)
    dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
    user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
    pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
    po_number = dbhelper.query_po_no(dsn,user_id,pwd,VarToStr(req).strip())
    app.Cells.Item[rowno,14] = po_number
 
# Query to check the approval status   
    dbhelper.po_approval_status(dsn,user_id,pwd,VarToStr(po_number).strip())
    
#    self.wait_until_page_loaded()    
#    self.log_checkpoint_message_web("Login Successful")    
#    temp=web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" PO PROCESS PURCHASE ORDERS')]")       
#    self.verify_aqobject_chkproperty(temp[0],"contentText",cmpIn,"CAI "+self.oper_unit+" PO PROCESS PURCHASE ORDERS")
#    self.log_message_web("Click 'CAI "+self.oper_unit+" PO PROCESS PURCHASE ORDERS' - Successful")      
#    self.wait_until_page_loaded()        
#    web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Buyer Work Center')]") 
#    self.wait_until_page_loaded()
#    self.page.EvaluateXpath("//table[@id='respList']//div[contains(text(),'Orders')]")[1].Click()    
#    self.wait_until_page_loaded()
#    
#    Delay(5000)
#    search = web_utils.clk_link_by_xpath(self.page,"//table[@id = 'AdvSearchHeading']//span[@id = 'Value_0__xc_1']//input[@title = 'Search Value: Order']")
#    Delay(1000)
#    self.page.Keys(po_number)
#    Delay(2000)
#    self.page.Keys("[Tab]")
#    Delay(1000)
#    web_utils.clk_link_by_xpath(self.page,"//table[@id = 'AdvSearchHeading']//td//button[@title = 'Go']")
#    self.wait_until_page_loaded()
#    Delay(2000)
#    orderStatus = self.page.Find("idStr","HeaderResultsTable:StatusNoLink:0",30)
#    if orderStatus.contentText == 'Approved':
#      self.log_message_web("Purchase Order Status Valdiated - Approved")
#    elif orderStatus.contentText == 'Requires Reapproval' or orderStatus.contentText == 'Incomplete':
#      delay(1200)
#      if orderStatus.contentText == 'Incomplete':
#        self.log_message_web(f"Purchase Order {po_number} is in status 'Incomplete': Re-Submitting for approval")
#      actionDropdown = self.page.EvaluateXpath("//table[@id = 'AdvSearchHeading']//div[@id='HeaderResultsTable:ControlBar']//tr//select[@id='ActionsPoplist']")[0]
#      actionDropdown.ClickItem("Update")
#      Delay(2300)
#      web_utils.clk_link_by_xpath(self.page,"//table[@id = 'AdvSearchHeading']//div[@id='HeaderResultsTable:ControlBar']//button[@title='Go']")
#      self.wait_until_page_loaded()
#      pro = ("ObjectType","contentText") 
#      val = ("TextNode","Update Standard Purchase Order *")
#      apprPage = self.page.Find(pro,val,30)
#      self.verify_aqobject_chkproperty(apprPage,"contentText",cmpContains,"Update Standard Purchase Order "+VarToStr(po_number))
#      Delay(2000)
#      web_utils.clk_link_by_xpath(self.page,"//table[@id = 'PageActionButtonsRN']//button[@id='SubmitButton']")
#      self.wait_until_page_loaded()
#      confirmMessage = self.page.EvaluateXpath("//table[@id ='FwkErrorBeanId']//td//h1")
#      
#      if confirmMessage[0].contentText == "Confirmation":
#        self.log_message_web("Purchase Order :"+po_number+"Submitted for Approval")
#        orderStatus == 'In Process'
#        while orderStatus != 'Approved':
#         web_utils.clk_link_by_xpath(self.page,"//table[@id = 'AdvSearchHeading']//td//button[@title = 'Go']")
#         self.wait_until_page_loaded()
#         Delay(2000)
#         orderStatus = self.page.Find("idStr","HeaderResultsTable:Status:0",30).contentText
#        self.log_message_web("Purchase Order Status Valdiated - Approved")
#      else:
#        self.log_error_message("Unable to Submit PO :"+po_number+"for Approval")
#
#
#    Delay(2000)      
#    self.page.EvaluateXpath("//table[@id = 'globalHeaderID']//a/div/img[@title = 'Home']")[0].Click()
#    self.wait_until_page_loaded()
    
    
#def test():
#  page = Sys.Browser("iexplore").page("*")
#  Log.Enabled = True
#  actionDropdown = page.EvaluateXpath("//table[@id = 'AdvSearchHeading']//div[@id='HeaderResultsTable:ControlBar']//tr//select[@id='ActionsPoplist']")[0]
#  actionDropdown.ClickItem("Update")
##  pro = ("idStr","ObjectType")
##  val = ("ActionsPoplist","Select")
##  page.FindChild(pro,val,30).ClickItem("Update")
#  Log.Enabled = False
#
#
#def Test1():
#  Browsers.Item[btIExplorer].Navigate("https://core-dev.epfinnp.coxautoinc.com/OA_HTML/OA.jsp?page=/oracle/apps/po/document/order/webui/OrdersSummaryHeadersPG&OAHP=PO_BUYER_HOME_PAGE&OASF=PO_ORDERS_SUMMARY&language_code=US&OAFMID=79723&searchType=customize&fwkQBSearchTypeSource=/oracle/apps/po/document/order/webui/OrdersSummaryHeadersPG__HeaderQueryRN__201&_ti=1486146816&retainAM=N&addBreadCrumb=N&OAPB=PO_BRAND&oapc=4&oas=EpZHUph9ugak8f4qCJC8mw..")
#  form = Aliases.browser.pageOrders.formDefaultformname
#  form.cellDescriptioncol.HoverMouse(29, 0)
#  panel = form.tableAdvsearchheading.cell.table.cell.panelX7m.panel
#  panel.selectActionspoplist.ClickItem("Update")
#  panel.HoverMouse(303, 37)


#def po_approval_status(dsn,user_id,pwd,po_no):      
#    try:  
#      Found=False 
#      adoCon=ADO.CreateADOConnection()
#      adoCon.ConnectionString="Provider=MSDASQL.1;Password="+pwd+";Persist Security Info=True;User ID="+user_id+";Data Source="+dsn+""
#      adoCon.LoginPrompt=False
#      adoCon.Open()    
#      sqlQuery = """select prh.segment1, prh.AUTHORIZATION_STATUS
#          from apps.po_headers_all prh
#          where prh.segment1 = '%s' """    
#      sqlQuery = aqString.Format(sqlQuery,po_no)
#      Log.Enabled=True
#      Log.Message("Executing SQL Query In Oracle Database " +sqlQuery) 
#      Log.Enabled=False         
#      for x in range(0,60):
#        rec_set=adoCon.Execute_(sqlQuery)
#        rec_set.MoveFirst()
#        while (not rec_set.EOF):
#          Log.Enabled=True
#          Log.Message(" Purchase Order Number:  "+aqConvert.VartoStr(rec_set.Fields.Item["SEGMENT1"].Value))
#          Log.Message(" Approval Status:  "+aqConvert.VartoStr(rec_set.Fields.Item["AUTHORIZATION_STATUS"].Value))
#          Log.Enabled=False
#          Approval_status = (rec_set.Fields.Item["AUTHORIZATION_STATUS"].Value)
#          Found=True
#          rec_set.MoveNext()
#          return Approval_status
#        if Found==True:
#          break        
#    except Exception as e:
#        Log.Enabled=True 
#        Log.Error("Error : - " + traceback.format_exc())  
#        Log.Enabled=False 
#    finally:    
#        adoCon.Close()
#
#def req_approval_status(dsn,user_id,pwd,req_no):      
#    try:  
#      Found=False 
#      adoCon=ADO.CreateADOConnection()
#      adoCon.ConnectionString="Provider=MSDASQL.1;Password="+pwd+";Persist Security Info=True;User ID="+user_id+";Data Source="+dsn+""
#      adoCon.LoginPrompt=False
#      adoCon.Open()    
#      sqlQuery = """select prh.segment1, prh.AUTHORIZATION_STATUS
#      from apps.po_requisition_headers_all prh
#      where prh.segment1 ='%s' """    
#      sqlQuery = aqString.Format(sqlQuery,req_no)
#      Log.Enabled=True
#      Log.Message("Executing SQL Query In Oracle Database " +sqlQuery) 
#      Log.Enabled=False         
#      for x in range(0,60):
#        rec_set=adoCon.Execute_(sqlQuery)
#        rec_set.MoveFirst()
#        while (not rec_set.EOF):
#          Log.Enabled=True
#          Log.Message(" Requisition Number:  "+aqConvert.VartoStr(rec_set.Fields.Item["SEGMENT1"].Value))
#          Log.Message(" Approval Status:  "+aqConvert.VartoStr(rec_set.Fields.Item["AUTHORIZATION_STATUS"].Value))
#          Log.Enabled=False
#          Approval_status = (rec_set.Fields.Item["AUTHORIZATION_STATUS"].Value)
#          Found=True
#          rec_set.MoveNext()
#          return Approval_status
#        if Found==True:
#          break        
#    except Exception as e:
#        Log.Enabled=True 
#        Log.Error("Error : - " + traceback.format_exc())  
#        Log.Enabled=False 
#    finally:    
#        adoCon.Close()

#def test_po_validation():
#  req_approval_status("OCI_STAGE","RAC_ACCNT","Y4bLC5sb","37088")
#  po_approval_status("OCI_STAGE","RAC_ACCNT","Y4bLC5sb","115118")#(dsn,user_id,pwd,po_no)

def test1_po_validation():
#  req_approval_status("OCI_STAGE","RAC_ACCNT","Y4bLC5sb","37088")
  import dbhelper
  journal_names = dbhelper.get_journal_name_from_batchname("OCI_TEST","RAC_ACCNT","Y4bLC5sb","%"+VarToStr(30939018))#(dsn,user_id,pwd,"%"+VarTostr(creqid))
#  status_value = dbhelper.verify_journal_import_details("OCI_TEST","RAC_ACCNT","Y4bLC5sb","%"+VarToStr(30796817)) #(dsn,user_id,pwd,"%"+VarTostr(x))
#  approval_status = dbhelper.verify_exp_batch_details_by_project("OCI_STAGE","RAC_ACCNT","Y4bLC5sb","1014157")#(dsn,user_id,pwd,VarToStr(proj_num))
#  approval_status = dbhelper.verify_exp_batch_details_by_project("MAN_OCI_STAGE","appsread","oracle123","112363")
  Log.Enabled=True
  Log.Message("The Value we are expecting is:  "+aqConvert.VartoStr(journal_names))
  Log.Enabled=False
  


