﻿import gvar
from dbhelper import *
from ebiz import *
import web_utils
from webcentercoding import *
import re

class WCC_Update_Batches_Coding_Form_V12_Test(webcentercoding):
  
 def login(self):
   if gvar.dataprep['user'] == 'BOTUSER':
      self.login_user = 'COXAUTOARROBOT9'
   elif gvar.dataprep['user'] == 'REGUSER':
      self.login_user = 'MKUMAR'
   super().login()

   
 def action(self,book):   
   
# Check Alerts while loggin in to coding form:
  app = book.Sheets.item["wci_coding"]   
  app1 = book.Sheets.item["wci_verifier"] 
  verifier_sheet = app1.Cells.Item
  coding_sheet = app.Cells.Item  
  Delay(6000)
  if Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf/faces/command/CommandExecutor.jspx?*").Alert.Exists:
    Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf/faces/command/CommandExecutor.jspx?*").Alert.Button("OK").Click()
    Delay(3000)
  if Sys.Browser("iexplore").WaitPage("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*",60000).Alert.Exists:
    Sys.Browser("iexplore").WaitPage("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*",60000).Alert.Button("OK").Click()
    Delay(2000)
  self.wait_until_page_loaded()
  security_wnd=Sys.Browser("iexplore").WaitSwingObject("JDialog", "Security Warning", -1, 1,5000)  
  if security_wnd.Exists:
    Sys.Browser("iexplore").SwingObject("JDialog", "Security Warning", -1, 1).FindChild("AWTComponentAccessibleName","I accept the risk and want to run this application.",30).Click()
    Sys.Browser("iexplore").SwingObject("JDialog", "Security Warning", -1, 1).Keys("[Enter]")     

#Validate Welcome Message and Views on the Left Pane: 
  welcome_msg=self.page.FindChildEx("contentText","WebCenter*",30,True,40000) 
  count =  0  
  while not welcome_msg.Exists:
    Delay(2000)
    welcome_msg=self.page.Find("contentText","WebCenter*",30) 
    count = count + 1 
    if count == 10:
      self.log_error_message("Unable to Login to WCI Coding Application")    
  web_utils.log_checkpoint("Logged in to Web Center Coding Applications Successfully",500,self.page) 
  coding_form = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0)
#  coding_form = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*")
  delay(2000)
  views_left_pane = coding_form.FindChild("contentText","Views",40)
  if views_left_pane.Exists:
    Sys.HighlightObject(views_left_pane)
    web_utils.log_checkpoint("Verified 'Views' Section Successfully in WCI Coding Application",500,self.page)
  else:
    self.log_error_message("Unable to Verify Object: 'Views' in WCI - Coding Application")
  self.page.wait_until_loaded()
  
#Validate Shared View - CAI Account Distribution:
  Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("f").Panel(0).Panel("c").Panel("bpmViewsList").Panel(1).Panel(0).Panel(0).Panel(0).Panel(1).Panel(0).Panel(3).Panel(0).Table(0).Cell(0, 1).Link(0).Click()
  self.verify_shared_view(VarToStr(coding_sheet[2,13]),coding_form)
  
#Vaidate the user (launch application in Enterprise mode if BOTUSER):
#  if gvar.dataprep['user'] == 'BOTUSER':
#      self.en_enterp_mode(coding_form)
#      self.page.wait_until_loaded()
  for x in range(0,10):
    prop = ("idStr","ObjectType")
    val = ("pt1:r1:0:r1:0:tldc:refreshTaskListButton::icon","Image")
    refresh_task_button = coding_form.FindChild(prop,val,50)
    refresh_task_button.Click()
    delay(10000)
  Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("f").Panel("taskListPanel").Panel("c").Panel("subTaskSwitcherPanel").Panel("c").Panel(0).Panel("c").Panel("taskTable").Panel("ch").Table("t").Cell(1, 1).Panel(1).Click()
  delay(5000)
  coding_form.Keys("^[PageUp]")
  coding_form.Keys("^[PageUp]")
  delay(5000)
  
  created_by1=self.page.Find("idStr", "pt1:r1:0:r1:0:tldc:taskTable:j_id__ctru133pc15j_id_4",100)
  
  Sys.HighlightObject(created_by1)
  created_by1.Click()

#  created_by2=Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("f").Panel("taskListPanel").Panel("c").Panel("subTaskSwitcherPanel").Panel("c").Panel(0).Panel("c").Panel("taskTable").Panel("ch").Table("t").Cell(1, 6).Panel(1)
#
#  Sys.HighlightObject(created_by2)
#  created_by2.Click()

  sort_desc1=Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("f").Panel("taskListPanel").Panel("c").Panel("subTaskSwitcherPanel").Panel("c").Panel(0).Panel("c").Panel("taskTable").Panel("ch").Table("t").Cell(1, 6).Panel(0).Table("afrSI").Cell(0, 1).Link(0)
  
  Sys.HighlightObject(sort_desc1)
  sort_desc1.Click()


#Select top batch record from the batch list; validate coding form:   
#  batch_list = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("f").Panel("taskListPanel").Panel("c").Panel("subTaskSwitcherPanel").Panel("c").Panel(0).Panel("c").Panel("taskTable").Panel("db").Table(0).Cell(0, 9)
  batch_list = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("f").Panel("taskListPanel").Panel("c").Panel("subTaskSwitcherPanel").Panel("c").Panel(0).Panel("c").Panel("taskTable").Panel("db").Table(0).Cell(0, 9).TextNode(0)
  batch_list.Click()
  self.refresh_task_form(coding_form)
       
#Validate Invoice Number:
#  verifier_inv_no = gvar.dataprep['invoice_number']
  verifier_inv_no = VarToStr(verifier_sheet[2,36])
  verifier_shipto = VarToStr(verifier_sheet[2,8])
  verifier_amt = "%.2f" %VarToFloat(verifier_sheet[2,16])
  self.log_message_web("Verifier Amount : "+VarToStr(verifier_amt))
#  task_form = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("s").Panel("detailsFrame").Panel("c").Panel("taskDetailInlineFrame").Frame("f").Panel("d1").Form("f1").Panel("ps1").Panel("s").Panel("pt1").Panel("tabb").Panel(0)
  task_form = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("s").Panel("detailsFrame").Panel("c").Panel("taskDetailInlineFrame").Frame("f").Panel("d1").Form("f1").Panel("ps1").Panel("s").Panel("pt1").Panel("tabb").Panel("tabbc")
#  task_bar = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("s").Panel("detailsFrame").Panel("c").Panel("taskDetailInlineFrame").Frame("f").Panel("d1").Form("f1").Panel("ps1").Panel("f").Panel("ph1")
  task_bar = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("s").Panel("detailsFrame").Panel("c").Panel("taskDetailInlineFrame").Frame("f").Panel("d1").Form("f1").Panel("ps1").Panel("f").Panel("ph1")

  
  for x in range(0,20):
    coding_inv_no = task_form.FindChildEx("idStr","it7::content",30,True,2000).contentText
    if coding_inv_no == verifier_inv_no:
      web_utils.log_checkpoint("Invoice Number Match Successfull - "+VarToStr(coding_inv_no),500,coding_form)
      break
    else:
      if task_bar.FindChildEx("idStr","cil12::icon",30,True,2000).Visible == False:
        self.log_message_web("arrow doesnt exist")
#        restore_pane = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("s").Panel("detailsFrame").Panel("c").Panel("taskDetailInlineFrame").Frame("f").Panel("d1").Form("f1").Panel("ps1").Panel("d").Panel(0).Link("i").Image("splittervr_png")
        restore_pane = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("s").Panel("detailsFrame").Panel("c").Panel("taskDetailInlineFrame").Frame("f").Panel("d1").Form("f1").Panel("ps1").Panel("d").Panel(0).Link("i").Image("splittervr_png")
        Sys.HighlightObject(restore_pane)
        restore_pane.Click()
        delay(2000)
#      next_batch = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("s").Panel("detailsFrame").Panel("c").Panel("taskDetailInlineFrame").Frame("f").Panel("d1").Form("f1").Panel("ps1").Panel("f").Panel("ph1").Panel(0).Panel(0).Table(0).Cell(0, 4).Table("g1").Cell(0, 18).Link("cil12").Image("icon")
      next_batch = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("s").Panel("detailsFrame").Panel("c").Panel("taskDetailInlineFrame").Frame("f").Panel("d1").Form("f1").Panel("ps1").Panel("f").Panel("ph1").Panel(0).Panel(0).Table(0).Cell(0, 4).Table("g1").Cell(0, 18).Link("cil12").Image("icon")
      Sys.HighlightObject(next_batch)
      delay(500)
      next_batch.Click()
      if x==20:
        self.log_error_message("Unable to Find Invoice Batch - "+verifier_inv_no+ " - in Coding Form")
      self.refresh_task_form(coding_form)
      


#Fetch Existing Invoice Details:
  if not task_form.FindChild("idStr","it8::content",30).Exists:
    delay(10000)
  Operating_unit = task_form.FindChild("idStr","it8::content",30).contentText
  self.log_message_web("Operating_unit: "+VarToStr(Operating_unit))
  Invoice_type   = task_form.FindChild("idStr","it9::content",30).contentText
  self.log_message_web("Invoice_type: "+VarToStr(Invoice_type))
  Invoice_date   = task_form.FindChild("idStr","id5::content",30).contentText
  self.log_message_web("Invoice_date: "+VarToStr(Invoice_date))   
  Invoice_curr   = task_form.FindChild("idStr","it5::content",30).contentText
  self.log_message_web("Invoice_curr: "+VarToStr(Invoice_curr))
  Supplier       = task_form.FindChild("idStr","it3::content",30).contentText
  self.log_message_web("Supplier: "+VarToStr(Supplier))
  Site           = task_form.FindChild("idStr","it4::content",30).contentText
  self.log_message_web("Site: "+VarToStr(Site))
  Invoice_Total  = task_form.FindChild("idStr","it6::content",30).contentText
  self.log_message_web("Invoice Header Total: "+VarToStr(Invoice_Total))
#  Source_tab     = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("s").Panel("detailsFrame").Panel("c").Panel("taskDetailInlineFrame").Frame("f").Panel("d1").Form("f1").Panel("ps1").Panel("s").Panel("pt1").Panel("tabb").Panel(0).Panel(0).Panel("sdi1").Panel("psl1").Panel("t").Panel("pfl2").Table(0).Cell(0, 2).Table(0).Cell(1, 1) 
  Source_tab     = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("s").Panel("detailsFrame").Panel("c").Panel("taskDetailInlineFrame").Frame("f").Panel("d1").Form("f1").Panel("ps1").Panel("s").Panel("pt1").Panel("tabb").Panel("tabbc").Panel("body").Panel("sdi1").Panel("psl1").Panel("t").Panel("pfl2").Table(0).Cell(0, 2).Table(0).Cell(1, 1) 
  Source         = Source_tab.contentText
  self.log_message_web("Source: "+VarToStr(Source))
  Description    = task_form.FindChild("idStr","sit3::content",60).contentText
  self.log_message_web("Description: "+VarToStr(Description))
  Def_approver   = task_form.FindChild("idStr","globalAttribute1Id::content",60).contentText
  self.log_message_web("Default approver: "+VarToStr(Def_approver))
  Location       = task_form.FindChild("idStr","sebsdffc1:j_id2",30).contentText
  
#Validate inline invoice details:
  found = False
  inv_line_amt = 0
  for i in range (0,5):
#    if Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("s").Panel("detailsFrame").Panel("c").Panel("taskDetailInlineFrame").Frame("f").Panel("d1").Form("f1").Panel("ps1").Panel("s").Panel("pt1").Panel("tabb").Panel(0).Panel(0).Panel("sdi1").Panel("psl1").Panel("c").Panel("psl2").Panel("c").Panel("pc1").Panel("otrWpr").Panel("c").Panel(0).Panel("db").Table(0).Cell(i, 0).Exists:
    if Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("s").Panel("detailsFrame").Panel("c").Panel("taskDetailInlineFrame").Frame("f").Panel("d1").Form("f1").Panel("ps1").Panel("s").Panel("pt1").Panel("tabb").Panel("tabbc").Panel("body").Panel("sdi1").Panel("psl1").Panel("c").Panel("psl2").Panel("c").Panel("pc1").Panel("otrWpr").Panel("c").Panel(0).Panel("db").Table(0).Cell(i, 0).Exists:
        found = True
#        line = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("s").Panel("detailsFrame").Panel("c").Panel("taskDetailInlineFrame").Frame("f").Panel("d1").Form("f1").Panel("ps1").Panel("s").Panel("pt1").Panel("tabb").Panel(0).Panel(0).Panel("sdi1").Panel("psl1").Panel("c").Panel("psl2").Panel("c").Panel("pc1").Panel("otrWpr").Panel("c").Panel(0).Panel("db").Table(0).Cell(i, 0)
        line = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("s").Panel("detailsFrame").Panel("c").Panel("taskDetailInlineFrame").Frame("f").Panel("d1").Form("f1").Panel("ps1").Panel("s").Panel("pt1").Panel("tabb").Panel("tabbc").Panel("body").Panel("sdi1").Panel("psl1").Panel("c").Panel("psl2").Panel("c").Panel("pc1").Panel("otrWpr").Panel("c").Panel(0).Panel("db").Table(0).Cell(i, 0)
#        line_type = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("s").Panel("detailsFrame").Panel("c").Panel("taskDetailInlineFrame").Frame("f").Panel("d1").Form("f1").Panel("ps1").Panel("s").Panel("pt1").Panel("tabb").Panel(0).Panel(0).Panel("sdi1").Panel("psl1").Panel("c").Panel("psl2").Panel("c").Panel("pc1").Panel("otrWpr").Panel("c").Panel(0).Panel("db").Table(0).Cell(i, 1).Select("content").title
        line_type = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("s").Panel("detailsFrame").Panel("c").Panel("taskDetailInlineFrame").Frame("f").Panel("d1").Form("f1").Panel("ps1").Panel("s").Panel("pt1").Panel("tabb").Panel("tabbc").Panel("body").Panel("sdi1").Panel("psl1").Panel("c").Panel("psl2").Panel("c").Panel("pc1").Panel("otrWpr").Panel("c").Panel(0).Panel("db").Table(0).Cell(i, 1).Select("content").title
        self.log_message_web("Line Type: "+VarToStr(line_type))
      
# Ship-To:
        if line_type == "ITEM":
          Ship_to_coding = task_form.FindChild("idStr","pc1:t1:"+VarToStr(i)+":shipToLocationCodeId::content",30).value
          self.log_message_web("shipto: "+VarToStr(Ship_to_coding))
          if Ship_to_coding == verifier_shipto:
            web_utils.log_checkpoint("Ship to Match Successfull - "+VarToStr(Ship_to_coding),500,coding_form)
          else:
            self.log_error_message("Incorrect or No Ship to Available for the Invoice - "+VarToStr(coding_inv_no)+" in coding form")
    
# Invoice Line Amount:
        Inv_amt_coding = "%.2f" %VarToFloat(task_form.FindChild("idStr","pc1:t1:"+VarToStr(i)+":it14::content",30).value)
        inv_line_amt = VarToFloat(inv_line_amt) + VarToFloat(Inv_amt_coding)
        self.log_message_web("Invoice Amount for line "+VarToStr(i+1)+" - "+VarToStr(line_type)+" :"+VarToStr(Inv_amt_coding))
        self.log_message_web("Line Amount: "+VarToStr(inv_line_amt))

# Enter Purchase Category:
        if line_type == "ITEM":
#          searchproj_dtls=  test = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("s").Panel("detailsFrame").Panel("c").Panel("taskDetailInlineFrame").Frame("f").Panel("d1").Form("f1").Panel("DhtmlZOrderManagerLayerContainer").Panel("af_Z_window").Panel(0).Table(0).Cell(i, 0).Panel("content").Panel("lovDialogId")  
          searchproj_dtls1=  test = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("s").Panel("detailsFrame").Panel("c").Panel("taskDetailInlineFrame").Frame("f").Panel("d1").Form("f1").Panel("DhtmlZOrderManagerLayerContainer").Panel("af_Z_window").Panel(0).Table(0).Cell(i, 0).Panel("content").Panel("lovDialogId")  
#          searchproj_dtls = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("s").Panel("detailsFrame").Panel("c").Panel("taskDetailInlineFrame").Frame("f").Panel("d1").Form("f1").Panel("DhtmlZOrderManagerLayerContainer").Panel("af_Z_window").Panel(0).Table(0).Cell(i, 0).Panel("content").Panel("lovDialogId")  
          searchproj_dtls=  test = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("s").Panel("detailsFrame").Panel("c").Panel("taskDetailInlineFrame").Frame("f").Panel("d1").Form("f1").Panel("ps1").Panel("s").Panel("pt1").Panel("tabb").Panel("tabbc").Panel("body").Panel("sdi1").Panel("psl1").Panel("c").Panel("psl2").Panel("c").Panel("pc1").Panel("otrWpr").Panel("c").Panel(0).Panel("db").Table(0).Cell(0, 7).Link("lovIconId")
#          searchproj_dtls = self.page.Find("idStr","pc1:t1:0:ilovProjectName::lovIconId",30)
          Purch_category = task_form.FindChild("idStr","pc1:t1:"+VarToStr(i)+":purchasingCategoryId::content",30)
          Purch_category.Click()
          Purch_category.Keys(coding_sheet[i+2,1])
          Purch_category.Keys("[Tab]")
          web_utils.log_checkpoint("Purchasing Category Entered - "+VarToStr(coding_sheet[i+2,1]),500,coding_form)
  
# Validate if Distribution account is needed:       
        if  VarToStr(verifier_sheet[i+2,3])== 'No' and line_type == 'ITEM':
           company = VarToStr(aqString.SubString((coding_sheet[i+2,6]),2,3))
           department=VarToStr(coding_sheet[i+2,7])
           account=VarToStr(coding_sheet[i+2,8])
           product=VarToStr(coding_sheet[i+2,9])
           location=aqString.SubString((coding_sheet[i+2,10]),2,4)
           future=aqString.SubString((coding_sheet[i+2,11]),2,7)
           intercompany=aqString.SubString((coding_sheet[i+2,10]),2,14)
           customertype=aqString.SubString((coding_sheet[i+2,10]),2,15)
           
#           acc_img = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("s").Panel("detailsFrame").Panel("c").Panel("taskDetailInlineFrame").Frame("f").Panel("d1").Form("f1").Panel("ps1").Panel("s").Panel("pt1").Panel("tabb").Panel(0).Panel(0).Panel("sdi1").Panel("psl1").Panel("c").Panel("psl2").Panel("c").Panel("pc1").Panel("otrWpr").Panel("c").Panel(0).Panel("db").Table(0).Cell(i, 5).Panel(0).Panel(0).Link(0).Image("icon")
           acc_img = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("s").Panel("detailsFrame").Panel("c").Panel("taskDetailInlineFrame").Frame("f").Panel("d1").Form("f1").Panel("ps1").Panel("s").Panel("pt1").Panel("tabb").Panel("tabbc").Panel("body").Panel("sdi1").Panel("psl1").Panel("c").Panel("psl2").Panel("c").Panel("pc1").Panel("otrWpr").Panel("c").Panel(0).Panel("db").Table(0).Cell(i, 5).Panel(0).Panel(0).Link(0).Image("icon")
           acc_img.Click()
           delay(3000)
           count = 1
#           while not Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("s").Panel("detailsFrame").Panel("c").Panel("taskDetailInlineFrame").Frame("f").Panel("d1").Form("f1").Panel("DhtmlZOrderManagerLayerContainer").Panel("af_Z_window").Panel(0).Table(0).Cell(i, 0).Panel("content").Panel(0).Exists:
#           while not Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("s").Panel("detailsFrame").Panel("c").Panel("taskDetailInlineFrame").Frame("f").Panel("d1").Form("f1").Panel("DhtmlZOrderManagerLayerContainer").Panel("af_Z_window").Panel("popup_container").Table(0).Cell(i, 0).Panel("content").Panel(0).Exists:
           while not Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("s").Panel("detailsFrame").Panel("c").Panel("taskDetailInlineFrame").Frame("f").Panel("d1").Form("f1").Panel("DhtmlZOrderManagerLayerContainer").Panel("af_Z_window").Panel("popup_container").Panel(0).Table(0).Cell(0, 0).Panel("content").Panel(0).Exists:
            delay(2000)
            count+=1
            if count == 3:
              self.log_error_message("Unable to launch Project Details Form")
#           acc_panel = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("s").Panel("detailsFrame").Panel("c").Panel("taskDetailInlineFrame").Frame("f").Panel("d1").Form("f1").Panel("DhtmlZOrderManagerLayerContainer").Panel("af_Z_window").Panel(0).Table(0).Cell(i, 0).Panel("content").Panel(0)
#           acc_panel = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("s").Panel("detailsFrame").Panel("c").Panel("taskDetailInlineFrame").Frame("f").Panel("d1").Form("f1").Panel("DhtmlZOrderManagerLayerContainer").Panel("af_Z_window").Panel("popup_container").Table(0).Cell(i, 0).Panel("content").Panel(0)
           acc_panel = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("s").Panel("detailsFrame").Panel("c").Panel("taskDetailInlineFrame").Frame("f").Panel("d1").Form("f1").Panel("DhtmlZOrderManagerLayerContainer").Panel("af_Z_window").Panel("popup_container").Panel(0).Table(0).Cell(0, 0).Panel("content").Panel(0)
           acc_panel.FindChild("idStr","pc1:t1:"+VarToStr(i)+":ebskffc1:lkc_0::content",40).Click()
           acc_panel.FindChild("idStr","pc1:t1:"+VarToStr(i)+":ebskffc1:lkc_0::content",40).Keys(company)
           acc_panel.Keys("[Tab]")
           
           delay(3000)
           acc_panel.FindChild("idStr","pc1:t1:"+VarToStr(i)+":ebskffc1:lkc_1::content",40).Click()
           acc_panel.FindChild("idStr","pc1:t1:"+VarToStr(i)+":ebskffc1:lkc_1::content",40).keys(department)
           acc_panel.Keys("[Tab]")
           
           delay(3000)
           acc_panel.FindChild("idStr","pc1:t1:"+VarToStr(i)+":ebskffc1:lkc_2::content",40).Click()
           acc_panel.FindChild("idStr","pc1:t1:"+VarToStr(i)+":ebskffc1:lkc_2::content",40).keys(account)
           acc_panel.Keys("[Tab]")
           
           delay(3000)
           acc_panel.FindChild("idStr","pc1:t1:"+VarToStr(i)+":ebskffc1:lkc_3::content",40).Click()
           acc_panel.FindChild("idStr","pc1:t1:"+VarToStr(i)+":ebskffc1:lkc_3::content",40).keys(product)
           acc_panel.Keys("[Tab]")
           
           delay(3000)
           acc_panel.FindChild("idStr","pc1:t1:"+VarToStr(i)+":ebskffc1:lkc_4::content",40).Click()
           acc_panel.FindChild("idStr","pc1:t1:"+VarToStr(i)+":ebskffc1:lkc_4::content",40).keys(location)
           acc_panel.Keys("[Tab]")

           
           delay(3000)
           web_utils.log_checkpoint("Account String details entered for the Invoice",500,coding_form)
           self.log_message_web("Company : "+VarToStr(company))
           self.log_message_web("Department : "+VarToStr(department))
           self.log_message_web("Account : "+VarToStr(account))
           self.log_message_web("Product : "+VarToStr(product))
           self.log_message_web("Location : "+VarToStr(location))
           acc_panel.FindChild("idStr","pc1:t1:"+VarToStr(i)+":ebskffc1:c14_dok",40).Click()
           delay(10000)
           i=0


         
      #Input Purch.Category & Project Details:
        elif VarToStr(verifier_sheet[i+2,3])== 'Yes' and line_type == 'ITEM':

            delay(2000)
            taskproj       = task_form.FindChild("idStr","pc1:t1:"+VarToStr(i)+":ilovProjectName::content",30)
            task           = task_form.FindChild("idStr","pc1:t1:"+VarToStr(i)+":ilovTaskNumber::content",30)
            exp_org        = task_form.FindChild("idStr","pc1:t1:"+VarToStr(i)+":ilovExpenditureOrganizationName::content",30)
            exp_type       = task_form.FindChild("idStr","pc1:t1:"+VarToStr(i)+":ilovExpenditureType::content",30)
            taskproj.Click()
            taskproj.Keys(coding_sheet[i+2,2])
            self.log_message_web("Project : "+VarToStr(taskproj.value))
            delay(1000)
            taskproj.Keys("[Tab]")
            delay(2000)
  
            if searchproj_dtls.FindChild("idStr","pc1:t1:"+VarToStr(i)+":ilovProjectName::lovDialogId::_ttxt",40).Exists:
              self.log_error_message("Invalid/No Project details are entered")  
     
            task.Click()
            task_no = "%.1f" %(VarToInt(coding_sheet[i+2,3]))
            task.Keys(task_no)
            self.log_message_web("Task : "+VarToStr(task.value))
            delay(1000)
            exp_org.Click()
  
            if searchproj_dtls.FindChild("idStr","pc1:t1:"+VarToStr(i)+":ilovTaskNumber::lovDialogId::_ttxt",40).Exists:
              self.log_error_message("Invalid/No Task details are entered")  
     
            exp_org.Keys(coding_sheet[i+2,4])
            self.log_message_web("Expenditure Org : "+VarToStr(exp_org.value))
            delay(1000)
            exp_type.Click()
  
            if searchproj_dtls.FindChild("idStr","pc1:t1:"+VarToStr(i)+":ilovExpenditureOrganizationName::lovDialogId::_ttxt",40).Exists:
              self.log_error_message("Invalid/No Expenditure Org details are entered") 
     
            exp_type.Keys(coding_sheet[i+2,5])
            self.log_message_web("Expenditure Type : "+VarToStr(exp_type.value))
            exp_type.Keys("[Tab]")
            delay(2000)
  
            if searchproj_dtls.FindChild("idStr","pc1:t1:"+VarToStr(i)+":ilovExpenditureType::lovDialogId::_ttxt",40).Exists:
              self.log_error_message("Invalid/No Expenditure Type details are entered") 
    else:
      found = False      
          
    if found == False:
      self.log_message_web("Inside inv_val loop")
      val = self.val_invoice_line_amt(inv_line_amt,verifier_amt,coding_inv_no,i,coding_form)               
      if val == True:
        break
         
              
# Validate Invoice Image:
#  coding_button_bar = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("s").Panel("detailsFrame").Panel("c").Panel("taskDetailInlineFrame").Frame("f").Panel("d1").Form("f1").Panel("ps1").Panel("s").Panel("pt1").Panel("tabh")
  coding_button_bar = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("s").Panel("detailsFrame").Panel("c").Panel("taskDetailInlineFrame").Frame("f").Panel("d1").Form("f1").Panel("ps1").Panel("s").Panel("pt1").Panel("tabh").Panel(0).Panel("cbc")
  coding_button_bar.FindChild("idStr","sdi2::disAcr",40).Click()
  delay(15000)
  if Sys.Browser("iexplore").WaitSwingObject("JDialog", "Security Warning", -1, 10000).Exists:
    jsecurity_warning = Sys.Browser("iexplore").SwingObject("JDialog", "Security Warning", -1, 1)
    Sys.HighlightObject(jsecurity_warning)  
    if jsecurity_warning.FindChild("AWTComponentAccessibleName","Update",40).Exists:
      jsecurity_warning.FindChild("AWTComponentAccessibleName","Run",40).Click()
      delay(3000)
    else:
      jsecurity_warning.FindChild("AWTComponentAccessibleName","I accept the risk and want to run this application.",30).Click()
      delay(2000)
      jsecurity_warning.Keys("[Enter]")
  delay(2000)
  if Sys.Process("java").WaitSwingObject("JDialog", "Security Warning", -1, 5000).Exists:
    jbox = Sys.Process("java").SwingObject("JDialog", "Security Warning", -1, 1)
    Sys.HighlightObject(jbox)  
    jbox.FindChild("AWTComponentAccessibleName","I accept the risk and want to run this application.",30).Click()
    Delay(1000)
    jbox.Keys("[Enter]")
    Delay(1000)
#    jbox.Keys("[Enter]")
  count = 0
  while not Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("s").Panel("detailsFrame").Panel("c").Panel("taskDetailInlineFrame").Frame("f").Panel("d1").Form("f1").Panel("ps1").Panel("s").Panel("pt1").Panel("tabb").Panel("tabbc").Panel("body_2").Panel("sdi2").Panel("dc_psl1").Panel("c").Panel("dc_if1").Frame("f").Panel("ptd1").Form("mnFrm").Panel(0).Panel("s").Panel("cpyRgt").Panel("f").Panel("imgNvPn").Table(0).Cell(0, 1).Panel("mnpsl").Panel("c").Panel("CntRgn").Panel(0).Panel("c").Panel("panelSplitterTopAndBottom").Panel("f").Panel("panelSplitterTopLeftAndRight").Panel("s").Panel("boxWrap").Panel("c").Panel(0).Panel("panelStretchLayoutApplet").Panel(0).Panel(0).Panel("c").Object("oraImgVwr").AWTObject("PluginEmbeddedFrame", "").SwingObject("Viewer", "", 0).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("ImageView", "", 0).SwingObject("JViewport", "", 0).Exists:
    delay(5000) 
    if count == 5:
      self.log_error_message("Unable to retrieve the Invoice Image")  
    count=count+1
  image_view = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("s").Panel("detailsFrame").Panel("c").Panel("taskDetailInlineFrame").Frame("f").Panel("d1").Form("f1").Panel("ps1").Panel("s").Panel("pt1").Panel("tabb").Panel("tabbc").Panel("body_2").Panel("sdi2").Panel("dc_psl1").Panel("c").Panel("dc_if1").Frame("f").Panel("ptd1").Form("mnFrm").Panel(0).Panel("s").Panel("cpyRgt").Panel("f").Panel("imgNvPn").Table(0).Cell(0, 1).Panel("mnpsl").Panel("c").Panel("CntRgn").Panel(0).Panel("c").Panel("panelSplitterTopAndBottom").Panel("f").Panel("panelSplitterTopLeftAndRight").Panel("s").Panel("boxWrap").Panel("c").Panel(0).Panel("panelStretchLayoutApplet").Panel(0).Panel(0).Panel("c").Object("oraImgVwr").AWTObject("PluginEmbeddedFrame", "").SwingObject("Viewer", "", 0).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("ImageView", "", 0).SwingObject("JViewport", "", 0)
  Sys.HighlightObject(image_view)
#  image_view = Sys.Browser("iexplore").Page("https://core-capture-dev.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?cid=f05cf930-bc17-4825-8397-704388b00147").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("s").Panel("detailsFrame").Panel("c").Panel("taskDetailInlineFrame").Frame("f").Panel("d1").Form("f1").Panel("ps1").Panel("s").Panel("pt1").Panel("tabb").Panel("tabbc").Panel("body_2").Panel("sdi2").Panel("dc_psl1").Panel("c").Panel("dc_if1").Frame("f").Panel("ptd1").Form("mnFrm").Panel(0).Panel("s").Panel("cpyRgt").Panel("f").Panel("imgNvPn").Table(0).Cell(0, 1).Panel("mnpsl").Panel("c").Panel("CntRgn").Panel(0).Panel("c").Panel("panelSplitterTopAndBottom").Panel("f").Panel("panelSplitterTopLeftAndRight").Panel("s").Panel("boxWrap").Panel("c").Panel(0).Panel("panelStretchLayoutApplet").Panel(0).Panel(0).Panel("c").Object("oraImgVwr").AWTObject("PluginEmbeddedFrame", "").SwingObject("Viewer", "", 0).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("ImageView", "", 0).SwingObject("JViewport", "", 0)
  web_utils.log_checkpoint("Invoice Image Exists for Invoice "+VarToStr(coding_inv_no),500,coding_form)
  delay(2000)
#  coding_button_bar.FindChild("idStr","sdi1::disAcr",40).Click()
#  invoice_button = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("s").Panel("detailsFrame").Panel("c").Panel("taskDetailInlineFrame").Frame("f").Panel("d1").Form("f1").Panel("ps1").Panel("s").Panel("pt1").Panel("tabh").Panel(0).Panel("oc").Panel("ti").Panel(0).Link("disAcr")
  coding_button_bar = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("s").Panel("detailsFrame").Panel("c").Panel("taskDetailInlineFrame").Frame("f").Panel("d1").Form("f1").Panel("ps1").Panel("s").Panel("pt1").Panel("tabh").Panel(0).Panel("cbc")
  coding_button_bar.FindChild("idStr","sdi1::disAcr",40).Click()
#  invoice_button = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("s").Panel("detailsFrame").Panel("c").Panel("taskDetailInlineFrame").Frame("f").Panel("d1").Form("f1").Panel("ps1").Panel("s").Panel("pt1").Panel("tabh").Panel(0).Panel("cbc").Panel("ti").Panel(0).Panel("afrTabCnt").Link("disAcr")
#  invoice_button.Click()
  delay(4000)

#Complete Processing Invoice:
#  task_frame = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("s").Panel("detailsFrame").Panel("c")
  task_frame = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("s").Panel("detailsFrame").Panel("c")
  self.log_message_web("inside completion loop")
  complete_button = task_bar.FindChildEx("idStr","cbApprove",30,True,2000)
  Sys.HighlightObject(complete_button)
  delay(1000)
  complete_button.Click()
  delay(5000)
  conf_text = "Please select a task to see the details"
  for x in range(0,3):
    if task_frame.contentText == conf_text:
      web_utils.log_checkpoint("Successfully Completed Processing Updates for Invoice No: "+VarToStr(coding_inv_no),500,coding_form)
      break
    else:
      delay(3000)
  if Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("s").Panel("detailsFrame").Panel("c").Panel("taskDetailInlineFrame").Frame("f").Panel("d1").Form("f1").Panel("DhtmlZOrderManagerLayerContainer").Panel("af_Z_window").Panel("popup_container").Table(0).Cell(0, 0).Panel("d1_msgDlg").Exists:
    error_box = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?*").Panel("d1").Form("f1").Panel("pt_headerPs").Panel("s").Panel(0).Panel("c").Panel("contentBody").Panel("c").Panel(0).Panel("pt_psGT").Panel("s").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("s").Panel(0).Panel(0).Panel("s").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("c").Panel(0).Panel("s").Panel("detailsFrame").Panel("c").Panel("taskDetailInlineFrame").Frame("f").Panel("d1").Form("f1").Panel("DhtmlZOrderManagerLayerContainer").Panel("af_Z_window").Panel("popup_container").Table(0).Cell(0, 0).Panel("d1_msgDlg")
#  error_box = error_pane.FindChild("idStr","d1::msgDlg",30)
    Sys.Highlightobject(error_box)
    error_msg = re.sub("\n","",error_box.contentText)
    self.log_error_message("Validation Errors while completing the Invoice - :"+VarToStr(error_msg))

 def en_enterp_mode(self,page):
    page.Keys("~")
    delay(1000)
    page.Keys("t")
    delay(2000)
    page.Keys("r")
    delay(1000)
    page.Keys("[Enter]")
    
 def refresh_task_form(self,coding_form):
  prop = ("contentText","ObjectType")
  val = ("CAI Coding Form","TextNode")
  coding_image = coding_form.FindChild(prop,val,50)
  for x in range(0,4):
    delay(2100)
    if coding_image.Visible == True:
       Sys.HighlightObject(coding_image)
       break
    else:
       delay(3200) 
#Validate Alert:
#       if Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf/faces/command/CommandExecutor.jspx?*").Alert.Exists:
#          Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/axf/faces/command/CommandExecutor.jspx?*").Alert.Button("OK").Click()
#          Delay(3000)
#       if Sys.Browser("iexplore").WaitPage("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?_*",60000).Alert.Exists:
#          Sys.Browser("iexplore").WaitPage("https://*.epfinnp.coxautoinc.com/axf-solutionWorkspace/faces/solutionworkspace?_*",60000).Alert.Button("OK").Click()
#          Delay(2000)
#       if x == 1:
#         break
         
 def verify_shared_view(self,view_name,coding_form):     
  coding_form.Keys("^[PageDown]")
  coding_form.Keys("^[PageDown]")   
  shared_view = coding_form.FindChild("contentText",view_name,60)
  Sys.HighlightObject(shared_view)
  shared_view.Click()
  delay(5000)
  text = shared_view.contentText
  for x in range(0,2):
    delay(5000)
    text = shared_view.contentText
    if text.find("(") != -1:
      pos1 = text.index('(')
      pos2 = text.index(')')
      val = aqString.SubString(text,pos1,pos2)
      web_utils.log_checkpoint("Tasks available in Shared View: CAI Account Distribution - "+VarToStr(val),500,coding_form)
      break
    else:
      if x == 1:
        self.log_error_message("No Tasks are available in Shared View - CAI Account Distribution")
      self.en_enterp_mode(coding_form)
      self.page.wait_until_loaded()
      shared_view.Click()

 def val_invoice_line_amt(self,inv_line_amt,verifier_amt,coding_inv_no,i,coding_form):
         
  if i > 0:
    if VarToFloat(inv_line_amt) == VarToFloat(verifier_amt):
        web_utils.log_checkpoint("Invoice Amount Match Successfull - "+VarToStr(inv_line_amt),500,coding_form)
        return True     
    else:
        self.log_error_message("Invoice Amount Match Unsuccessfull/not available for batch - "+VarToStr(coding_inv_no)+" in coding form")
  else:
      self.log_error_message("Line Details not available for batch - "+VarToStr(coding_inv_no)+" in coding form")

          
