﻿import gvar

### In this method objects for below pages have been captured ###

#PROJECT > SETUP > CAI ADDITIONAL PROJECT INFORMATION link page

def prj_setup_addnl_prj_info_cmpny_textfeild():
  prop_names = ["idStr","ObjectIdentifier","ObjectType"]
  prop_values = ["PA_PROJ_ATTR_GROUP_TYPE222902LOVDisp","PA_PROJ_ATTR_GROUP_TYPELOVDisp","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def prj_setup_addnl_prj_info_product_textfeild():
  prop_names = ["idStr","ObjectIdentifier","ObjectType"]
  prop_values = ["PA_PROJ_ATTR_GROUP_TYPE222903LOVDisp","PA_PROJ_ATTR_GROUP_TYPELOVDisp","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def prj_setup_addnl_prj_info_location_textfeild():
  prop_names = ["idStr","ObjectIdentifier","ObjectType"]
  prop_values = ["PA_PROJ_ATTR_GROUP_TYPE222904LOVDisp","PA_PROJ_ATTR_GROUP_TYPELOVDisp","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def prj_setup_addnl_prj_info_cus_type_textfeild():
  prop_names = ["idStr","ObjectIdentifier","ObjectType"]
  prop_values = ["PA_PROJ_ATTR_GROUP_TYPE222905LOVDisp","PA_PROJ_ATTR_GROUP_TYPELOVDisp","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def prj_setup_addnl_prj_info_legacy_prj_textfeild():
  prop_names = ["idStr","ObjectIdentifier","ObjectType"]
  prop_values = ["PA_PROJ_ATTR_GROUP_TYPE221901","PA_PROJ_ATTR_GROUP_TYPE","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def prj_setup_addnl_prj_info_allowexpnstooverride_textfeild():
  prop_names = ["idStr","ObjectIdentifier","ObjectType"]
  prop_values = ["PA_PROJ_ATTR_GROUP_TYPE221901","PA_PROJ_ATTR_GROUP_TYPE","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def prj_setup_addnl_prj_info_man_prjno_textfeild():
  prop_names = ["idStr","ObjectIdentifier","ObjectType"]
  prop_values = ["PA_PROJ_ATTR_GROUP_TYPE261941","PA_PROJ_ATTR_GROUP_TYPE","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def prj_setup_addnl_prj_info_cus_billtype_textfeild():
  prop_names = ["idStr","ObjectIdentifier","ObjectType"]
  prop_values = ["PA_PROJ_ATTR_GROUP_TYPE281961LOVDisp","PA_PROJ_ATTR_GROUP_TYPELOVDisp","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def prj_setup_addnl_prj_info_cus_name_textfeild():
  prop_names = ["idStr","ObjectIdentifier","ObjectType"]
  prop_values = ["PA_PROJ_ATTR_GROUP_TYPE281962LOVDisp","PA_PROJ_ATTR_GROUP_TYPELOVDisp","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)




