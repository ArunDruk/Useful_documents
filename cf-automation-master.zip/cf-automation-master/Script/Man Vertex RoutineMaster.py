from dbhelper import *
from ebiz import *
import form_utils
import file_system_utils
import dbhelper
#import traceback

class tc1000_man_us_vertex_inv_testset6_routine(Ebiz):
  global login_user
  
  def login(self):
    self.login_user="mkumar"
    super().login()
    #new change for MAN URL
  def goto_url(self,url):
     super().goto_url(self.testConfig['ebiz']['oci_is_url'])
  op_log_path="C:\\TC_Logs"
#######
  def action(self,book):
      global rowno, app, p_names, flg, hdr_Index_value, hdr_Suppliername_Index, hdr_SupplierSite_Index, hdr_Invoicedate_Index, hdr_Invnumber_Index, hdr_Invamt_Index, hdr_terms_Index, inv_name,sup_num,inv_amount
      rowno=139 #Row number also should be changed at the Line Folder Level ro w nu 270     
      app = book.Sheets.item["Manual_Entry_Invoices"]
      RowCount = app.UsedRange.Rows.Count
      p_names = ("JavaClassName","AWTComponentAccessibleName","AWTComponentIndex")  
      self.nav_ap1(p_names)    
      self.multi_inv()
      inv_name = "1"
      tx_name = "2" 
      sup_num = "3"
      sum_tax_name1_line = "5"
      inv_amount = "6"
      dst_acnt_afr_crt_acnt_tx_nme1 = "7"
      sum_alltaxlines = "8"
#Chnaged Code begin
      flg=0
      hdr_Index_value=8
      hdr_Suppliername_Index=16
      hdr_SupplierSite_Index=24
      hdr_Invoicedate_Index=28
      hdr_Invnumber_Index=32
      hdr_Invamt_Index=40
      hdr_terms_Index=112
              
              

      for i in range(rowno,RowCount+1):
           if VarToStr(app.Cells.Item[rowno,6]) == "Header":
              inv_name = ("VRTX_INV: "+aqConvert.DateTimeToFormatStr(aqDateTime.Time(),"%H:%M:%S"))
              sup_num = VarToStr(app.Cells.Item[rowno,41])
              inv_amount = VarToStr(app.Cells.Item[rowno,13])
              sa_tax_amt_from_excel =  VarToStr(app.Cells.Item[rowno,39])  #Added for SA Tax 
              vtx_hold_from_excel =  VarToStr(app.Cells.Item[rowno,40]) #Added for Vtx Tax Link Hold 
              flg=flg+1
              self.ap_inv_hdr(p_names)
              self.ap_inv_lns(p_names,book,inv_name, sup_num, sa_tax_amt_from_excel, vtx_hold_from_excel) #Added SA Tax amount & Vtx hold from Excel . Removed after_val_accnt for US
              delay(1000)
              book.save()
            
              hdr_Index_value=hdr_Index_value+1
              hdr_Suppliername_Index=hdr_Suppliername_Index+1
              hdr_SupplierSite_Index=hdr_SupplierSite_Index+1
              hdr_Invoicedate_Index=hdr_Invoicedate_Index+1
              hdr_Invnumber_Index=hdr_Invnumber_Index+1
              hdr_Invamt_Index=hdr_Invamt_Index+1
              hdr_terms_Index=hdr_terms_Index+1
            
              if hdr_Index_value > 11: 
                hdr_Index_value = 11
                hdr_Suppliername_Index = 19
                hdr_SupplierSite_Index = 27
                hdr_Invoicedate_Index = 31
                hdr_Invnumber_Index = 35
                hdr_Invamt_Index = 43
                hdr_terms_Index = 115
               
#            del app,p_names
           elif VarToStr(app.Cells.Item[rowno,6]) == "":
             break 
           rowno	=	rowno+1
      del RowCount
      self.jFrame.Keys("[F4]")
      delay(5000)
      self.jFrame.Keys("[F4]")
      delay(5000)
      self.jFrame.Keys("~o")
      
  def nav_ap1(self,p_names): 
    web_utils.log_checkpoint("Logged in to Oracle Applications Home Page Successfully",500,self.page)
    self.wait_until_page_loaded()      
    self.page.EvaluateXPath("//table[@id='menuContent']//div[contains(text(),'AP Home Office Super User')]")[0].Click() 
    web_utils.log_checkpoint("Click 'AP Home Office Super User' - Successful",500,self.page) 
    self.page.Keys("[Down]")
    self.wait_until_page_loaded()
    self.page.NativeWebObject.Find("contentText","Invoices","A").Click()
    web_utils.log_checkpoint("Click 'Invoices' - Successful",500,self.page) 
    self.page.Keys("[Down]")
    self.wait_until_page_loaded()
    self.page.NativeWebObject.Find("contentText","Entry","A").Click()
    web_utils.log_checkpoint("Click 'Entry' - Successful",500,self.page) 
    self.page.Keys("[Down]")
    self.wait_until_page_loaded()
    self.page.EvaluateXpath("//table[@id='respList']//div[contains(text(),'Invoices')]")[1].Click() 
    web_utils.log_checkpoint("Click 'Invoices' - Successful",500,self.page)
    web_utils.validate_security_box()   
    self.jFrame = self.initializeJFrame()
    Delay(2000)
    form_utils.click_ok_btn(self.jFrame)
    delay(5000)
    p_names = ("JavaClassName","AWTComponentAccessibleName") 
    p_values = ("ExtendedFrame","Invoice Workbench*")
    obj=self.jFrame.FindChild(p_names,p_values,50)
    if obj.Exists:
     web_utils.log_checkpoint("Invoice Workbench (AP Home Office Super User) Launched Successfully",500,self.jFrame)
    else:
     web_utils.log_checkpoint("Unable to Launch Invoice Workbench Form",500,self.jFrame)
    Delay(10000)
        
      
  def multi_inv(self):

    self.jFrame.Keys("~l")
    Delay(1000)
    self.jFrame.Keys("o")
    delay(3000)
    p_names=["AWTComponentAccessibleName","JavaClassName"]
    val=["Open Folder","FWindow"]
    open_fldr_form=self.jFrame.FindChildEx(p_names,val,30,True,60000)
    delay(1000)
    web_utils.log_checkpoint("Opened Invoice Folder",500,self.jFrame)
#    self.log_message_oracle_form(self.jFrame,"Opened Invoice Folder")
    p_names=["JavaClassName","AWTComponentAccessibleName","AWTComponentIndex"]
    val=["LWTextField"," Find",0]
    fnd=open_fldr_form.FindChildEx(p_names,val,30,True,6000)
#    fnd.Click()# Select Custom Folder name at Invoice Header Level
    fnd.SetText("akimb2")
    delay(2300)
    self.jFrame.Keys("~f")
    Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("FWindow", "Open Folder", 0).AWTObject("LWComponent", "", 0).AWTObject("EwtContainer", "", 0).AWTObject("ButtonBar", "", 0).AWTObject("ButtonBar", "", 1).AWTObject("PushButton", "OK ALT O", 0).Click()
    web_utils.log_checkpoint("Invoice Folder Invoice Workbench displayed",500,self.jFrame)
#    self.log_message_oracle_form(self.jFrame,"Invoice Folder Invoice Workbench displayed")
    delay(3000)
          
  def ap_inv_hdr(self,p_names):   
         
      if flg !=0:
         self.jFrame.Keys("[Down]")
         delay(1000)
      
      p_names=["AWTComponentAccessibleName","JavaClassName", "AWTComponentIndex"]
      val=["Invoice Workbench*","ExtendedFrame",24]
      inv_wb_form=self.jFrame.FindChild(p_names,val,60)
      inv_wb_form.Keys("[Tab]")
      self.jFrame.Keys("~f")
      delay(1000)
      self.jFrame.keys("n")   
      delay(5000) # Increased the Delay to 5 seconds

      #Changed Code to get ObjectSpy for Invoice Type Field on the Invoice Workbench Form
      #inv_Type=inv_wb_form.FindChild("AWTComponentAccessibleName","Type RequiredList of Values",hdr_Index_value,20)
      pi_names = ("JavaClassName","AWTComponentAccessibleName","AWTComponentIndex")
      p_values = ("VTextField","Type RequiredList of Values", hdr_Index_value)
      inv_Type=inv_wb_form.Find(pi_names,p_values,20)

      inv_Type.Click()
      Delay(3000)
      #inv_Type.Keys("^a[Del]")
      Delay(1000)
      inv_Type.Keys("[End]")
      inv_Type.Keys("[BS][BS][BS][BS][BS][BS][BS][BS][BS][BS][BS][BS][BS][BS][BS][BS][BS]")
      Delay(1000)
      inv_Type.SetText(app.Cells.Item[rowno,7])
      Delay(5000)
#      inv_Type.Keys(app.Cells.Item[rowno,7])
      inv_Type.Click()
      self.log_message_oracle_form(self.jFrame,"**************** NEW INVOICE# "+VarToStr(flg)+"***************")
      web_utils.log_checkpoint("Invoice Type: "+VarToStr(app.Cells.Item[rowno,7]),500,self.jFrame)
#      self.log_message_oracle_form(self.jFrame,"Invoice Type: "+VarToStr(app.Cells.Item[rowno,7]))
#      inv_Type.Keys("[Tab]")
#      self.jFrame.Keys("[Tab]")
      inv_wb_form.Keys("[Tab]")
#      self.log_message_oracle_form(self.jFrame,"Invoice Type: "+VarToStr(app.Cells.Item[rowno,7]))
      if app.Cells.Item[rowno,7] == "Debit Memo" or app.Cells.Item[rowno,7] == "Credit Memo":
         self.jFrame.Keys("[Enter]")  
  
      pi_names = ("JavaClassName","AWTComponentAccessibleName","AWTComponentIndex")
      p_values = ("VTextField","Trading Partner RequiredList of Values", hdr_Suppliername_Index)
      trading_Partner=inv_wb_form.Find(pi_names,p_values,20)
      trading_Partner.Click()
      if app.Cells.Item[rowno,7] == "Debit Memo" or app.Cells.Item[rowno,7] == "Credit Memo":
        self.jFrame.Keys("[Enter]")  

      trading_Partner.SetText(app.Cells.Item[rowno,8])
      Delay(2000)
      web_utils.log_checkpoint("Trading Partner: "+VarToStr(app.Cells.Item[rowno,8]),500,self.jFrame)
      p_values = ("VTextField","Supplier Site Name RequiredList of Values",hdr_SupplierSite_Index)
      sup_SiteName=inv_wb_form.Find(pi_names,p_values,20)
      sup_SiteName.Click()
      sup_SiteName.Keys("[Del]")
      sup_SiteName.Keys(app.Cells.Item[rowno,9])      
      web_utils.log_checkpoint("Supplier Site "+VarToStr(app.Cells.Item[rowno,9]),500,self.jFrame)
      p_values = ("VTextField","Invoice Date RequiredList of Values",hdr_Invoicedate_Index)
      inv_wb_form.Find(pi_names,p_values,30).Click()
      delay(2000)
      inv_wb_form.Keys("[Tab]")
      pi_names = ("JavaClassName","AWTComponentAccessibleName","AWTComponentIndex")
      p_values = ("VTextField","Invoice Num Required",hdr_Invnumber_Index)
      Delay(1000)
      inv_wb_form.Find(pi_names,p_values,11).Click()
      # Dynamically populates Invoice Number
#      inv_name = ("VRTX_INV: "+aqConvert.DateTimeToFormatStr(aqDateTime.Time(),"%H:%M:%S"))
      inv_wb_form.FindChild(pi_names, p_values, 20).SetText(inv_name)
      web_utils.log_checkpoint("Vertex Invoice Number is : "+inv_name,500,self.jFrame)
      app.Cells.Item[rowno,11] = inv_name
      
      # Read Invoice No from Excel
#      inv_wb_form.FindChild(pi_names, p_values, 20).SetText(app.Cells.Item[rowno,10]+aqConvert.DateTimeToFormatStr(aqDateTime.Time(),"%H:%M:%S"))
#      self.log_message_web("Vertex Invoice Number is : - "+app.Cells.Item[rowno,10])
      delay(1000)
      inv_wb_form.Keys("[Tab]")
      delay(1000)      
      p_values = ("VTextField","Invoice Amount Required",hdr_Invamt_Index)
      inv_wb_form.Find(pi_names,p_values,10).Click()
      delay(1000)
      
      inv_wb_form.Find(pi_names,p_values,10).Keys(app.Cells.Item[rowno,13])
      delay(1000)
      web_utils.log_checkpoint("Invoice Amount: "+VarToStr(app.Cells.Item[rowno,13]),500,self.jFrame)
      inv_wb_form.Keys("[Tab]")

      p_values = ("VTextField","Terms RequiredList of Values",hdr_terms_Index)
      delay(1000)
      inv_wb_form.Find(pi_names,p_values,20).Click()
      delay(1000)
     
      delay(3000)
      self.jFrame.Keys("^s")
      Delay(4000)
      self.log_message_oracle_form(self.jFrame,VarToStr(flg)+"==Invoice Header Details Entered Successfully")
          
  #def ap_inv_lns(self,p_names,book,inv_name, sup_num,  tx_name, after_val_acnt,sa_tax_amt_from_excel,vtx_hold_from_excel): # Added SA tax amount and Vtx Hold from excel 
  def ap_inv_lns(self,p_names,book,inv_name, sup_num,sa_tax_amt_from_excel,vtx_hold_from_excel): # Added SA tax amount and Vtx Hold from excel . Removed AFter Val accnt for US
      delay(1000)
      
      self.jFrame=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1,1)
      p_names=["AWTComponentAccessibleName","JavaClassName"]
      val=["Invoice Workbench*","ExtendedFrame"]
      self.jFrame.Keys("~2")
      Delay(3000)
      inv_wb_form=self.jFrame.FindChild(p_names,val,30)     
      delay(4000)
      #################
      p_names_names=["AWTComponentAccessibleName","AWTComponentIndex"]
      p_names_val=["Type Required*", 5]
#      self.log_message_oracle_form(self.jFrame,"::"+VarToStr(p_names_val))
      item=inv_wb_form.FindChild(p_names_names,p_names_val,20)
      item.Click()
#      Type_Req=item.Findhild("AWTComponentAccessibleName","Type Required*",10).wText
#      self.log_message_oracle_form(self.jFrame,"::"+VarToStr(Type_Req))

#      pro = ["AWTComponentAccessibleName","AWTComponentIndex"]
#      val = ["Type Required*", 5]
#      line_validation_field = jFrame.FindChild(pro,val)
#      if line_validaton_field.Exists:
#      proceed
#      else:
#      self.log_error_message("unable to open lines section")
      ########################
      #Invoice Line Folder Start
      if rowno == 139:   
        self.jFrame.Keys("~l")
        Delay(2000)
        self.jFrame.Keys("o")
        delay(3000)
        p_names=["AWTComponentAccessibleName","JavaClassName"]
        val=["Open Folder","FWindow"]
        open_fldr_form=self.jFrame.FindChildEx(p_names,val,30,True,60000)
        delay(6000)
        web_utils.log_checkpoint("Opened Invoice Folder",500,self.jFrame)
        p_names=["JavaClassName","AWTComponentAccessibleName","AWTComponentIndex"]
        val=["LWTextField"," Find",0]
        fnd=open_fldr_form.FindChildEx(p_names,val,30,True,6000)
        fnd.SetText("Acade AP Lines")
        delay(9000)
        self.jFrame.Keys("~f")
        Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("FWindow", "Open Folder", 0).AWTObject("LWComponent", "", 0).AWTObject("EwtContainer", "", 0).AWTObject("ButtonBar", "", 0).AWTObject("ButtonBar", "", 1).AWTObject("PushButton", "OK ALT O", 0).Click()
        web_utils.log_checkpoint("Invoice Folder Invoice Workbench displayed",500,self.jFrame)
        delay(3000)
        
      #Folder Section End
      
      self.log_message_oracle_form(self.jFrame,"Entering Lines info")
      inv_lines_count= book.ActiveSheet.UsedRange.Rows.Count
      Index_value=10
      Purchase_Index=420
      shipLoc_Index=255
      Disacct_Index=100
      Intduse_Index=245
      Chkbox_Index=11
      for eachline in range(rowno+1,inv_lines_count+1): 
        if VarToStr(app.Cells.Item[eachline,19]) == "":
          break
         
        if eachline!=5:         
#          act_seg=inv_wb_form.FindChild("AWTComponentAccessibleName","Account  Segment",20)
          act_seg=inv_wb_form.FindChild("AWTComponentAccessibleName","Description",20)
          act_seg.Click()
          Delay(1000)
          act_seg.Keys("[Down]")
          Delay(5000)
         
        p_names_names=["AWTComponentAccessibleName","AWTComponentIndex"]
        p_names_val=["Type Required*", VarToInt(Index_value)-5]
        item=inv_wb_form.FindChild(p_names_names,p_names_val,20)
        item.Click()
        item.Keys("[End]")
        item.Keys("[BS][BS][BS][BS][BS][BS][BS][BS][BS][BS][BS][BS][BS]")
        item.SetText(app.Cells.Item[eachline,19]) 
        #delay(5000) #Delay added before entereing ship to
        item.Keys("[Tab]") 
        delay(2000)#Delay added before entereing ship to
        web_utils.log_checkpoint("Invoice Line Type: "+VarToStr(app.Cells.Item[eachline,19]),500,self.jFrame)

        #Adding logic to not populate shipto for tax line
        line_type = VarToStr(app.Cells.Item[eachline,19])
        if line_type != 'Tax':
          
            p_names_names=["AWTComponentAccessibleName","AWTComponentIndex"]
#            p_names_val=["Ship To LocationList of Values",shipLoc_Index]
            p_names_val=["Ship toList of Values",shipLoc_Index]        
            ship_to_loc=inv_wb_form.FindChild(p_names_names,p_names_val,20)
            ship_to_loc.Click()
            ship_to_loc.Keys("[End]")
        
            ship_to_loc.Keys("[BS][BS][BS][BS][BS][BS][BS][BS][BS][BS][BS][BS][BS][BS][BS][BS][BS][BS][BS][BS][BS][BS][BS][BS][BS][BS]")
            ship_to_loc.SetText(VarToStr(app.Cells.Item[eachline,21]))
            delay(2000) 
            web_utils.log_checkpoint("ShipToLocation: "+VarToStr(app.Cells.Item[eachline,21]),500,self.jFrame)
 
        p_names_names=["AWTComponentAccessibleName","AWTComponentIndex"]
        p_names_val=["Amount Required",Index_value]
        inv_wb_form.FindChild(p_names_names,p_names_val,20).SetText(VarToStr(app.Cells.Item[eachline,20]))
        web_utils.log_checkpoint("Amount : "+VarToStr(app.Cells.Item[eachline,20]),500,self.jFrame)
#        self.log_message_oracle_form(self.jFrame,"Amount : "+VarToStr(app.Cells.Item[eachline,20]))

        Delay(3000)
        p_names_names=["AWTComponentAccessibleName","AWTComponentIndex"]
        p_names_val=["Purchasing CategoryList of Values",Purchase_Index]
        #01/27/2020: Added below code to Click on the Purchasing Category Field. 
        #This is to prevent the Error message "No Changes to Save" from appearing
        purchase_category=inv_wb_form.FindChild(p_names_names,p_names_val,20)
        purchase_category.Click()        
        #inv_wb_form.FindChild(p_names_names,p_names_val,20).SetText(VarToStr(app.Cells.Item[eachline,22]))
        purchase_category.SetText(VarToStr(app.Cells.Item[eachline,22]))
        web_utils.log_checkpoint("Purchase Category: "+VarToStr(app.Cells.Item[eachline,22]),500,self.jFrame)


# Added Primary Intended Use - Eshwar
        p_names_names=["AWTComponentAccessibleName","AWTComponentIndex"]
        p_names_val=["Primary Intended UseList of Values",Intduse_Index]
        Intended_use=inv_wb_form.FindChild(p_names_names,p_names_val,20)
        Intended_use.Click()
        Intended_use.SetText(VarToStr(app.Cells.Item[eachline,23]))
        web_utils.log_checkpoint("Primary Indended Use: "+VarToStr(app.Cells.Item[eachline,23]),500,self.jFrame)
        
        #01/27/2020: Define variable and add the coNdition for a scenario where the supplier has a default Distribution set populated               
        dist_acct_from_excel = VarToStr(app.Cells.Item[eachline,24])
        web_utils.log_checkpoint("Distribution Account Type From Excel: "+VarToStr(dist_acct_from_excel),500,self.jFrame)
#        self.log_message_oracle_form(self.jFrame,"Distribution Account Type From Excel: "+VarToStr(dist_acct_from_excel))  
  
        if dist_acct_from_excel != 'Distribution_Set': 
          p_names_names=["AWTComponentAccessibleName","AWTComponentIndex"]
#          p_names_val=["Default Distribution AccountList of Values",Disacct_Index]
          p_names_val=["Distribution AccountList of Values",Disacct_Index]
          dis_acct=inv_wb_form.FindChild(p_names_names,p_names_val,20)
          dis_acct.Click()
          dis_acct.SetText(VarToStr(app.Cells.Item[eachline,24]))
  #        inv_wb_form.FindChild("AWTComponentAccessibleName","Default Distribution AccountList of Values",20).SetText(VarToStr(app.Cells.Item[eachline,19]))
        Delay(2000)
        
        #Prorate Check Box value from excelsheet
        chkboxvalue_excel = VarToStr(app.Cells.Item[eachline,34])
        
        if chkboxvalue_excel == 'Checked':

          p_names_names=["AWTComponentAccessibleName","AWTComponentName"]
          p_names_val=["Prorate Across All Item Lines","CheckBox"+VarToStr(Chkbox_Index)]

          prorate_chkbox=inv_wb_form.FindChild(p_names_names,p_names_val,20)

          prorate_chkbox.click()
          self.log_message_oracle_form(self.jFrame,"Prorate Across All Item Lines  : "+chkboxvalue_excel)
#        prorate_chkbox.Keys(" ")  
       

# Commented the below 2 lines as part of debugging the distribution set logic.
#        p_names_names=["AWTComponentAccessibleName","AWTComponentIndex"]
#        p_names_val=["Account  Segment",80]
               
        Index_value=Index_value+1
        Purchase_Index=Purchase_Index+1
        shipLoc_Index=shipLoc_Index+1
        Disacct_Index=Disacct_Index+1
        Intduse_Index=Intduse_Index+1
        Chkbox_Index=Chkbox_Index+1
        
        Delay(4000)
        self.jFrame.Keys("~f")
        Delay(3000)
        self.jFrame.Keys("s")
        self.log_message_oracle_form(self.jFrame,"Invoice line Saved ")
        
        Delay(2000)
        Log.Message("saved")
      self.jFrame.Keys("~c")    
      Delay(2000)
      self.jFrame.Keys("~v")  
      web_utils.log_checkpoint("Invoice Validation window",500,self.jFrame)
#      self.log_message_oracle_form(self.jFrame,"Invoice Validation window ")
      Delay(4000)
              
      p_names=["AWTComponentAccessibleName","JavaClassName"]
      val=["Invoice Actions","ExtendedFrame"]
           
      inv_action_form=self.jFrame.FindChildEx(p_names,val,25,True,60000) 
      
      inv_action_form.FindChild("AWTComponentAccessibleName","OK alt K",10).Click()
      Delay(16000) 
      
      #Invoice Status addedby Eshwar
      prop=["AWTComponentAccessibleName","AWTComponentIndex"]
      val=["Status",4]
      inv_val = self.jFrame.FindChild(prop,val,60)
      inv_statuss=inv_val.wText
      web_utils.log_checkpoint("Invoice Status: "+inv_statuss,500,self.jFrame) 
      
#      self.jFrame.Keys("~2")
#      Delay(6000)
#Log Message after Invoice is Validated           
#      web_utils.log_checkpoint("Invoice Validated",500,self.jFrame)
#      log_message_oracle_form(self.jFrame,"Invoice Validated")
      p_names = ("JavaClassName","AWTComponentAccessibleName")      
      p_values = ("ExtendedFrame","Invoice Workbench (CAI "+self.oper_unit+" AP INVOICE PROCESSING)")  
      status_field=self.jFrame.FindChildEx(p_names,p_values,20,True,60000)
      Status=status_field.FindChild("AWTComponentAccessibleName","Status",10).wText                 


      # Added the Vertex Tax Link Hold Logic.
      # Verifying the tax link hold field on the datasheet is VERTEX TAX LINK HOLD. Only in that scenario, status and tax link hold verification is done.
      if VarToStr (vtx_hold_from_excel) == 'VERTEX TAX LINK HOLD':
        self.vtx_hold_validate(p_names,book,inv_name,sup_num,inv_statuss,vtx_hold_from_excel)     
      else: 
      # End of Vertex Tax Link Hold Logic.
      # Below execution is for non tax link hold scenario.
      
  #Start Create Accounting Process
        self.jFrame.Keys("~c")    
        Delay(5000)
        self.jFrame.Keys("~t")  
        Delay(5000)  
        self.jFrame.Keys("~o")  
        Delay(5000)    
        web_utils.log_checkpoint("Create Accounting Window",500,self.jFrame)
#        self.log_message_oracle_form(self.jFrame,"Create Accounting Window")   
        p_names=["AWTComponentAccessibleName","JavaClassName"]
        val=["Invoice Actions","ExtendedFrame"]
        inv_action_form=self.jFrame.FindChildEx(p_names,val,25,True,60000) 
      
        inv_action_form.FindChild("AWTComponentAccessibleName","OK alt K",10).Click()
        Delay(7000)  
        web_utils.log_checkpoint("Invoice Accounted Successfully",500,self.jFrame)
#        self.log_message_oracle_form(self.jFrame,"Invoice Accounted Successfully ")    
        p_names=["AWTComponentAccessibleName","JavaClassName"]
        val=["Note Accounting has been successfully created*","ChoiceBox"] 
        #self.jFrame.Keys("~b")  
  #      Delay(2000)
        #self.jFrame.Keys("[F4]")
        self.jFrame.FindChildEx(p_names,val,25,True,60000).Keys("[Enter]") 
        Delay(1000)

          
        self.sa_tax_validate(p_names,book,inv_name,sup_num,sa_tax_amt_from_excel) 
              
  # Added for Self-Assessed Tax Validation
  def sa_tax_validate(self,p_names,book,inv_name,sup_num,sa_tax_amt_from_excel,):
  #SQL Added for SA_Tax amount
      dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn_man']
      user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid_man']
      pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd_man']
      
      self.log_message_oracle_form(self.jFrame,"Invoice Number: "+VarToStr(inv_name))
      self.log_message_oracle_form(self.jFrame,"Supplier Number: "+VarToStr(sup_num))
      Delay(5000)
      selfAssessed_tax=dbhelper.get_selfAssessed_tax_From_Db (dsn,user_id,pwd,VarToStr(inv_name),VarToStr(sup_num))  
      web_utils.log_checkpoint("SA Tax Amount from Database: "+VarToStr(selfAssessed_tax),500,self.jFrame)
      
      self.log_message_oracle_form(self.jFrame,"SA Tax Amount from Excel "+VarToStr(sa_tax_amt_from_excel))
      self.log_message_oracle_form(self.jFrame,"SA Tax Amount from DB "+VarToStr(selfAssessed_tax))
      
      if VarToStr(selfAssessed_tax)  == VarToStr(sa_tax_amt_from_excel) :
        Log.Enabled=True
        Log.Checkpoint("SA Tax Amount from Database matches Excel Tax Amount")    
        Log.Enabled=False
      else:
        Log.Enabled=True
        Log.Warning("Failed!!.SA Tax Amount from Database doesn't match with Excel Tax Amount.: "+VarToStr(sa_tax_amt_from_excel)+" Database SA Tax Amount: "+VarToStr(selfAssessed_tax))
        Log.Enabled=False   


    # Added  for Vertex Tax Link hold Validation
  def vtx_hold_validate(self,p_names,book,inv_name,sup_num, inv_status,vtx_hold_from_excel):
      dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn_man']
      user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid_man']
      pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd_man']
      
      self.log_message_oracle_form(self.jFrame,"Invoice Number: "+VarToStr(inv_name))
      self.log_message_oracle_form(self.jFrame,"Supplier Number: "+VarToStr(sup_num))
      
      self.log_message_oracle_form(self.jFrame,"Vertex Tax Link Hold Name from Excel "+VarToStr(vtx_hold_from_excel))

      if VarToStr(inv_status)  == 'Needs Revalidation' :
        Log.Enabled=True
        Log.Checkpoint("Invoice is in Needs Revalidation Status")    
        Log.Enabled=False
        vtx_hold_from_db=dbhelper.get_CheckTaxLinkHold_From_Db (dsn,user_id,pwd,VarToStr(inv_name),VarToStr(sup_num))  
        web_utils.log_checkpoint("Vertx Tax Link Hold Name from Database: "+VarToStr(vtx_hold_from_db),500,self.jFrame)
        if VarToStr(vtx_hold_from_db) == VarToStr(vtx_hold_from_excel):
          Log.Enabled=True
          Log.Checkpoint("Invoice is on VERTEX TAX LINK HOLD")    
          Log.Enabled=False
        else:
          Log.Enabled=True
          Log.Warning("Failed!!. Invoice did not go on VERTEX TAX LINK HOLD. DB Value: "+VarToStr(vtx_hold_from_db))
          Log.Enabled=False   

      else:
        Log.Enabled=True
        Log.Warning("Failed!!. Invoice is not on hold. Invoice Status: "+VarToStr(inv_status))
        Log.Enabled=False   
      
      
  #End for Vertex Tax Link Hold Validation

  
  

  
def test():
  
 jFrame = Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1)
 p_names_names=["AWTComponentAccessibleName","AWTComponentName"]
 p_names_val=["Prorate Across All Item Lines","CheckBox11"]
 cbox = jFrame.FindChild(p_names_names,p_names_val,60)
 Sys.HighlightObject(cbox)
 cbox.Click()

 
 

def Test1():
  menu_bar=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications - *", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWMenuBar", "", 0)
  OCR.Recognize(menu_bar).BlockByText("Folder").Click()
  Delay(1000)

  view_menu=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("LWPopupMenu", "", 0)
  OCR.Recognize(view_menu).BlockByText("Open").Click()
