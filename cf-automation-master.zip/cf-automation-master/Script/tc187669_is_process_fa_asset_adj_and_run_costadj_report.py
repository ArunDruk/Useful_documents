﻿from ebiz import *
import web_utils
import dbhelper
import file_system_utils
import form_utils

class tc187669_is_process_fa_asset_adj_and_run_costadj_report(Ebiz):  
 
 global rowno, app, jFrame
 op_log_path ="C:\\TC_Logs"

 def login(self):
   self.login_user='pkjami'
   super().login()
 
 def goto_url(self,url):
   super().goto_url(self.testConfig['ebiz']['oci_is_url'])

 def action(self,book):
   
  app = book.Sheets.item["PA-FA"]
  RowCount = book.ActiveSheet.UsedRange.Rows.Count
  rowno = 2 
  web_utils.log_checkpoint("Logged in to Oracle Applications Home Page Successfully",500,self.page)
  self.wait_until_page_loaded()   
  self.page.EvaluateXPath("//table[@id='menuContent']//div[contains(text(),'AM Supervisor')]")[0].Click() 
  web_utils.log_checkpoint("Click 'AM Supervisor' - Successful",500,self.page) 
  self.wait_until_page_loaded()
  self.page.Keys("[Down]")
  self.page.Keys("[Down]")
  Delay(2000)
  self.page.NativeWebObject.Find("contentText","Assets","A").Click()
  web_utils.log_checkpoint("Click 'Assets' - Successful",500,self.page) 
  self.wait_until_page_loaded()
  self.page.Keys("[Down]")
  Delay(2000)
  self.page.wait()
  self.page.NativeWebObject.Find("contentText","Asset Workbench","A").Click()
  web_utils.log_checkpoint("Click 'Asset Workbench' - Successful",500,self.page) 
  web_utils.validate_security_box()
  Delay(15000)
  jFrame=self.initializeJFrame()
  form_utils.click_ok_btn(jFrame) 
  Delay(8000)   

# Form Validation

  prop=["AWTComponentAccessibleName","JavaClassName"]
  val=["Find Assets","ExtendedFrame"]
  find_asset_form=jFrame.FindChildEx(prop,val,60,True,90000)
  if find_asset_form.Exists:
   web_utils.log_checkpoint("Navigation Successful : AM Supervisor > Assets > Asset Workbench; 'Find Assets' form launched successfully",500,jFrame)
  else:
   self.log_message_oracle_form(jFrame,"Unable to Launch 'Find Assets' form")
   
# Finding the Asset that needs to be adjusted

  find_asset_form.Find("AWTComponentAccessibleName","Asset Number",10).Click() 
  find_asset_form.Find("AWTComponentAccessibleName","Asset Number",10).SetText(app.Cells.Item[rowno,1])
  web_utils.log_checkpoint("In 'Find Assets' form: Enter Asset Number "+VarToStr(app.Cells.Item[rowno,1]),500,jFrame)
  web_utils.log_checkpoint("In 'Find Assets' Form: Click 'Find' button next",500,jFrame)
  jFrame.Keys("~i") 
  Delay(1000)
   
# Click Books button on Assets Window 
 
  prop_names=["AWTComponentAccessibleName","JavaClassName"]
  prop_values=["Assets","ExtendedFrame"]
  Assets_obj = jFrame.FindChildEx(prop_names,prop_values,30,True,60000)
  web_utils.log_checkpoint("In 'Assets' form : Click 'Books' button next",500,jFrame) 
  jFrame.keys("~b")
  Delay(5000)
 
# Performing Asset Adjustment 

  prop=["AWTComponentAccessibleName","JavaClassName"]
  val=["Books","ExtendedFrame"]
  books_form=jFrame.FindChildEx(prop,val,60,True,60000) 
  books_form.Find("AWTComponentAccessibleName","Book RequiredList of Values",30).Click()
  Delay(2000)
  books_form.Find("AWTComponentAccessibleName","Book RequiredList of Values",30).Keys(app.Cells.Item[rowno,6]) 
  web_utils.log_checkpoint("In 'Find Assets Form': Click 'Find' button next",500,jFrame)   
  books_form.Find("AWTComponentAccessibleName","Current Cost Required",30).Click() 
  Delay(2000)
  cost =books_form.Find("AWTComponentAccessibleName","Current Cost Required",30).wText
  web_utils.log_checkpoint("In 'Books' form: Enter Current Cost - "+ VarToStr(cost),500,jFrame)
  adjamt=aqConvert.DateTimeToFormatStr(aqDateTime.Time(),"%H%M")
  costadj=VarToInt(cost)+ VarToInt(adjamt)
  app.Cells.Item[rowno,13]= costadj
  books_form.Find("AWTComponentAccessibleName","Current Cost Required",30).Keys(VarToStr(costadj))
  web_utils.log_checkpoint("In 'Books' form: Enter Adjustment Cost - "+ VarToStr(costadj),500,jFrame)
  web_utils.log_checkpoint("Asset Cost updated and Click 'Done' Button Next",500,jFrame)
  books_form.FindChild("AWTComponentAccessibleName","Done alt D",10).Click()
  web_utils.log_checkpoint("Transaction Complete Confimation displayed; Click 'OK' Button Next",500,jFrame)
  prop_names = ("AWTComponentAccessibleName","JavaClassName")
  prop_values = ("Forms*","FWindow")
  ok_obj = jFrame.FindChildEx(prop_names,prop_values,30,True,20000)
  self.verify_aqobject_chkproperty(ok_obj,"Name",cmpContains,"Transaction complete")
  prop_names = ("AWTComponentAccessibleName","JavaClassName")
  prop_values = ("OK ALT O","PushButton")
  ok_obj.FindChild(prop_names,prop_values,60).Click()
  Delay(3000)

# Performing Asset financial inquiry and reviewing the cost history information

  web_utils.log_checkpoint("In 'Assets' form : Click 'Financial Inquiry' button next",500,jFrame)
  prop_names=["AWTComponentAccessibleName","JavaClassName"]
  prop_values=["Assets","ExtendedFrame"]
  Assets_obj = jFrame.FindChildEx(prop_names,prop_values,30,True,60000)
  Assets_obj.FindChild("AWTComponentAccessibleName","Financial Inquiry alt i",10).Click()
  Delay(4000)
  web_utils.log_checkpoint("View Financial Information' form : Review Financial Information of an Asset",500,jFrame)
  Delay(1000)
  prop=["AWTComponentAccessibleName","JavaClassName"]
  val=["View Financial Information*","ExtendedFrame"]
  view_fin_form=jFrame.FindChildEx(prop,val,60,True,90000) 
  web_utils.log_checkpoint("View Financial Information form launched successfully",500,jFrame)
  web_utils.log_checkpoint("In 'View Financial Information' form click on 'Cost History' Tab next",500,jFrame)
  view_fin_form.FindChild("AWTComponentName","FormsTabPane*",20).ClickTab("Cost History")
  Delay(1000)
  prop=["AWTComponentAccessibleName","AWTComponentIndex"]
  val=["Transaction Type Required",12]
  trx_type = view_fin_form.FindChild(prop,val,60) 
  Log.Enabled=True
  aqObject.CheckProperty(trx_type,"wText",cmpIn,"ADJUSTMENT")
  Log.Enabled=False  
  web_utils.log_checkpoint("Reviewed Asset Adjustment Information on 'Cost History' Tab",500,jFrame)           
  Delay(2000) 
  jFrame.Keys("[F4]")
  Delay(2000)
  jFrame.Keys("[F4]")
  Delay(2000)
  jFrame.keys("~o")
  Delay(5000)

# Navigating to Single request and submitting Cost Adjustments Report

  self.page.NativeWebObject.Find("contentText","Other","A").Click()
  web_utils.log_checkpoint("Click 'Other' - Successful",500,self.page) 
  self.page.Keys("[Down]")
  self.page.Keys("[Down]")
  self.page.NativeWebObject.Find("contentText","Requests","A").Click()
  web_utils.log_checkpoint("Click 'Requests' - Successful",500,self.page)
  self.page.Keys("[Down]")
  self.page.NativeWebObject.Find("contentText","Run","A").Click()
  web_utils.log_checkpoint("Click 'Run' - Successful",500,self.page)
  web_utils.validate_security_box()
  Delay(15000)
  jFrame=self.initializeJFrame()
  form_utils.click_ok_btn(jFrame)  

  prop=["AWTComponentAccessibleName","JavaClassName"]
  val=["Submit a New Request","ExtendedFrame"]
  submit_req_form=jFrame.FindChildEx(prop,val,30,True,60000)
  submit_req_form.FindChild("AWTComponentAccessibleName","OK alt O",10).Click()
  Delay(2000)
  jFrame.Keys("Cost Adjustments Report")
  jFrame.Keys("[Tab]")
  prop=["AWTComponentAccessibleName","JavaClassName"]
  val=["Parameters","FlexWindow"]
  parameters_form=jFrame.FindChildEx(prop,val,60,True,20000)
  prop=["AWTComponentAccessibleName","JavaClassName"]
  val=["Book REQUIRED List Values","FlexTextField"]
  parameters_form.FindChild(prop,val,60).Click()
  parameters_form.FindChild(prop,val,60).Keys(VarToStr(app.Cells.item[2,6])) 
  Delay(1000) 
  parameters_form.FindChild(prop,val,60).Keys("[Tab]")
  parameters_form.Keys("[Tab]")
  prop=["AWTComponentAccessibleName","JavaClassName"]
  val=["From Period REQUIRED List Values","FlexTextField"]
  parameters_form.FindChild(prop,val,60).Click()  
  Lastmonth = aqDateTime.AddMonths(aqDateTime.Now(),-1)
  parameters_form.FindChild(prop,val,60).Keys(aqConvert.DateTimeToFormatStr(Lastmonth,"%b-%Y"))
  prop=["AWTComponentAccessibleName","JavaClassName"]
  val=["To Period REQUIRED List Values","FlexTextField"]
  parameters_form.FindChild(prop,val,60).Click() 
  parameters_form.FindChild(prop,val,60).Keys(aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%b-%Y"))
  web_utils.log_checkpoint("Cost Adjustments Report Parameters values 'Book', 'Set of Books Currency', 'From Period', 'To Period' entered successfully",500,jFrame)
  parameters_form.keys("~o")
  Delay(1000) 
  web_utils.log_checkpoint("Click 'OK' Button on Parameters window Successful; Click Submit Button next",500,jFrame)

# Submitting Cost Adjustments Report and capturing Output
  
  prop=["AWTComponentAccessibleName","JavaClassName"]
  val=["Submit Request","ExtendedFrame"]
  submit_req_form=jFrame.FindChildEx(prop,val,30,True,60000)
  submit_req_form.FindChild("AWTComponentAccessibleName","Submit alt m",10).Click()
  Delay(3000)
  prop=["AWTComponentAccessibleName","JavaClassName"]
  val=["Decision Request submitted*","ChoiceBox"]
  decision_form=jFrame.FindChildEx(prop,val,60,True,40000)
  RequestID = ''.join(x for x in decision_form.AWTComponentAccessibleName if x.isdigit())
  web_utils.log_checkpoint("Request ID Of 'Cost Adjustments Report' is " + aqConvert.VarToStr(RequestID),500,jFrame)
  Delay(2000)    
  jFrame.Keys("~n")  
  Delay(2000)    
  dsn = self.testConfig['man_oracle_db']['dsn']
  user_id = self.testConfig['man_oracle_db']['userid']
  pwd = self.testConfig['man_oracle_db']['pwd']
  dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,RequestID)
  jFrame.Keys("~v")
  Delay(2000)
  jFrame.Keys("r")
  Delay(2000)
  jFrame.Keys("~s")
  Delay(3000)
  prop_names=["JavaClassName","AWTComponentAccessibleName"]
  prop_values=["VTextField","Request ID"]
  temp=jFrame.FindAll(prop_names,prop_values,60)
  jFrame.Find("AWTComponentName",temp[10].AWTComponentName,60).Click()
  jFrame.Find("AWTComponentName",temp[10].AWTComponentName,60).SetText(RequestID)
  Delay(2000)
  web_utils.log_checkpoint("Query for Submitted Request ID:" +RequestID,500,jFrame)
  jFrame.Keys("~i")
  Delay(2000)
  prop=["AWTComponentAccessibleName","JavaClassName"]
  val=["Requests","ExtendedFrame"]
  req_form=jFrame.FindChildEx(prop,val,30,True,60000)
  prop=["AWTComponentAccessibleName","AWTComponentIndex"]
  val=["Phase",40]
  phase=req_form.Find(prop,val,10).wText 
  while phase != 'Completed':
     Delay(1000)
     req_form.keys("~r")
     Delay(4000)
  web_utils.log_checkpoint("'Cost Adjustments Report' program phase Completed",500,jFrame)
  jFrame.Keys("~p")
  file_type = 'Output'
  self.save_log(file_type)
  Delay(6000)
  jFrame.Keys("[F4]")
  Delay(4000)
  jFrame.Keys("~v")
  Delay(2000)
  jFrame.Keys("r")
  Delay(2000)
  jFrame.Keys("~n")
  
# Submitting Create Accounting-Assets Program and capturing the Journal Imported Batch   

  prop=["AWTComponentAccessibleName","JavaClassName"]
  val=["Submit Request","ExtendedFrame"]
  submitrequest_form=jFrame.FindChildEx(prop,val,60,True,60000)
  web_utils.log_checkpoint("Submitting 'Create Accounting' Program",500,jFrame)
  name = submitrequest_form.Find("AWTComponentAccessibleName","Name RequiredList of Values",20)
  name.Click()
  name.SetText("Create Accounting - Assets")
  Delay(5000)
  jFrame.Keys("[Tab]")
  Delay(2000)
  prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
  val=["Parameters","FlexWindow","0"]
  parameters_form=jFrame.FindChildEx(prop,val,60,True,90000)
  book_txtfield=parameters_form.FindChild("AWTComponentAccessibleName","Book Type Code REQUIRED List Values",10)
  book_txtfield.Click()
  book_txtfield.Keys("MAN USCORP BOOK")
  Delay(1000)
  parameters_form.Keys("[Tab]")
  Delay(1000)
  parameters_form.Keys("[Tab]")
  Delay(1000)
#  parameters_form.Keys("[Tab]")
#  Delay(1000)
  jFrame.Keys(aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d-%b-%Y"))
  Delay(1000)
  parameters_form.Keys("[Tab]")
  Delay(1000)
  parameters_form.Keys("[Tab]")
  Delay(1000)
  parameters_form.Keys("[Tab]")
  Delay(1000)
  report_txtfield=parameters_form.FindChild("AWTComponentAccessibleName","Report REQUIRED List Values: No Report",10)
  report_txtfield.Click()
  report_txtfield.Keys("Detail")
  delay(2000)
  parameters_form.Keys("[Tab]")
  delay(2000)
  web_utils.log_checkpoint("'Create Accounting - Assets' Program Parameters entered successfully",500,jFrame)
  prop=["AWTComponentAccessibleName","JavaClassName"]
  val = ["OK ALT O","FormButton"]
  parameters_form.FindChild(prop,val,60).Click()
  Delay(2000)
  prop=["AWTComponentAccessibleName","JavaClassName"]
  val=["Submit alt m","Button"]
  submitrequest_form.FindChild(prop,val,60).Click()
  Delay(2000)
  val = ["Decision Request submitted*","ChoiceBox"]
  decision_box = jFrame.FindChildEx(prop,val,60,True,12000)
  RequestID = aqConvert.VarToStr(''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit()))
  web_utils.log_checkpoint("'Create Accounting - Assets' program submitted successfully and Request ID is "+VarToStr(RequestID),500,jFrame)
  jFrame.Keys("~n")
  Delay(2000)
  
# Verifying create accounting concurrent job completing from the database

  dsn = self.testConfig['man_oracle_db']['dsn']
  user_id = self.testConfig['man_oracle_db']['userid']
  pwd = self.testConfig['man_oracle_db']['pwd']
  dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,RequestID)
  jFrame.Keys("~v")
  Delay(2000)
  jFrame.Keys("r")
  Delay(2000)
  jFrame.Keys("~i")
  Delay(2000)
  
  prop=["AWTComponentAccessibleName","JavaClassName"]
  val=["Requests","ExtendedFrame"]
  req_form=jFrame.FindChildEx(prop,val,30,True,90000)
  creq_id,log_path = form_utils.req_set_save_output(self,jFrame,req_form,"Journal Import",RequestID)
  web_utils.close_additional_browsers()
#  form_utils.save_output_singlereq(self,jFrame,self.op_log_path,"Create Accounting - Assets",RequestID) 
#  Delay(5000) 
   

# Capturing Journal Import Batch Name from the Journal Import program output file

  fo=open(log_path,"r") 
  lines=fo.readlines()
  self.log_message_web("Journal Imported Batch Name is : - "+lines[17][8:36].strip())
  app.Cells.Item[rowno,15] = lines[17][8:33].strip()    
  jFrame.Click()
  Delay(2000)
  self.close_forms(jFrame)   
  book.save()


 def save_log(self,file_type):
   Delay(8000)
   log_page=Sys.Browser("iexplore").Page("https://manheim-*.epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
   Delay(1000)
   log_page.Click()
   log_page.TextNode(0).Click()
   Delay(1000)
   Log.Enabled=True     
   screenshot=log_page.PagePicture()
   msg = (file_type+" File Opened Successfully")
   Log.Picture(screenshot,msg)
   Log.Enabled=False
   log_page.Keys("~f")
   Delay(5000)
   log_page.Keys("a")
   Delay(5000) 
   file_system_utils.create_folder(self.op_log_path)             
   log_path=self.op_log_path+"\\prc generate asset lines for a single project "+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
   Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
   Delay(3000)
   Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
   Delay(5000)
   Log.Enabled=True
   Log.File(log_path," Cost Adjustments Report "+file_type+" File Attached")
   Log.Enabled=False     
   Sys.Browser("iexplore").Page("https://manheim-*.epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close()
   web_utils.close_additional_browsers()

     
 
  
  
  
  
  
  
