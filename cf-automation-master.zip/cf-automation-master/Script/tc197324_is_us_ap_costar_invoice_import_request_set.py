﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils
import winscp_utility
import tc_logs
from File_Handler import File_Handler as _TXTOBJ
from text_headers import payroll_txt_file_header as _HEADERS
import web_utils
import form_utils
import datetime as dt



class tc197324_is_us_ap_costar_invoice_import_request_set(Ebiz):
 
 op_log_path="C:\\TC_Logs"
 is_ap_costar_files="C:\\IS_AP_Costar_Files"
  
 def login(self):
      self.login_user="mfallwell"
      super().login()
 
 def goto_url(self,url):
    super().goto_url(self.testConfig['ebiz']['oci_is_url'])
 
 def action(self,book):
     global Invoice_num1,rowno
     rowno = 2
     app = book.Sheets.item["Invoice"]
     app1 = book.Sheets.item["Requisition"]
     self.files = "CoStar_INV_IS_US_2020.txt"
     self.place_files_local()
     self.process_files()
     self.place_files_winscp(app,app1) #(self.files)
     #self.submit_request(self.app)
     
   
## Place AP Costar Files in Local Folder:
 def place_files_local(self):   
    Log.Message("Entering into function 'place_files_local'")
#    for index in range(0,1):
    file_system_utils.create_folder(self.is_ap_costar_files)
    file_exist=aqFileSystem.FindFiles("C:\\IS_AP_Costar_Files",self.files)
    if file_exist != None:
     aqFileSystem.DeleteFile("C:\\IS_AP_Costar_Files\\"+self.files)
    aqFileSystem.CopyFile(Project.Path+"DataSheets\\Oracle-AP-Other\\IS\\"+self.files, "C:\\IS_AP_Costar_Files\\"+self.files)
    log_path = ("C:\\IS_AP_Costar_Files\\"+self.files)
    Log.Enabled=True
    Log.File(log_path, "CoStar AP File Attached")
    Log.Enabled=False 
    
## Read/Modify/Write Payroll Files:
 def process_files(self):  
   invoice_date = aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%m/%d/%Y")
    #journal_id_line = aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%M%S")
   path = "C:\IS_AP_Costar_Files\\"+self.files
   cobj = _TXTOBJ(path,"|")
   List_of_Dict=cobj.Read()
 
# The below code is to take the unique values in the invoice description and store it in the list variable.
   List_invoice_des_val=[]
   
   for Dict in List_of_Dict:
   
       for k in Dict.keys():
           if (k=='Invoice Description'):
               val=Dict[k]
               List_invoice_des_val.append(val)
           elif(k=='Invoice Date'):
                Dict[k]=invoice_date

   List_invoice_des_val=list(set(List_invoice_des_val))
   
   self.Invoice_num1="Costar-"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%M%S%m-%d-%y")
   Delay(1000)
   self.Invoice_num2="Costar-"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%M%S%m-%d-%y")
   Delay(1000)
#   self.Invoice_num3="Costar-"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%M%S%m-%d-%y")
#   Delay(1000)

# The below code is to modify the Invoice number based on the unique values of Invoice description.
   
   for index,Dict in enumerate(List_of_Dict):
       for k,v in Dict.items():  
           if(Dict['Invoice Description'] == List_invoice_des_val[0]):
                Dict['Invoice Number']=self.Invoice_num1
           elif(Dict['Invoice Description'] == List_invoice_des_val[1]):
                Dict['Invoice Number']=self.Invoice_num2
#           elif(Dict['Invoice Description'] == List_invoice_des_val[2]):
#                Dict['Invoice Number']=self.Invoice_num3
                
#           elif(k=='Invoice Date'):
#                Dict[k]=invoice_date
                
   #cobj.Write(List_of_dict)  
   def Write(rows):
   
      def return_str(row):
        return "|".join(map(str, [f'"{item}"' for item in row.values()]))+'\n'
   
      header = "|".join(map(str,[f'"{key}"' for key in rows[0].keys()]))
      with open(path, 'w') as file:
        file.write(header+'\n')
        file.writelines("".join([return_str(row)for row in rows]))
                                   
   Write(List_of_Dict)                    
    
     

 def place_files_winscp(self,app,app1):
#    Stored_session = "opc@stage-fin-iad1-ebsapp1.private.stagefin.oraclevcn.com"
    Stored_session = "costar@mftstg.manheim.com"
    local_dir = "C:\\IS_AP_Costar_Files"
    remote_dir =  self.testConfig['winscp']['gl_blkn_dir']  
#    remote_dir =  self.winscpConfig[self.testConfig['ebiz']['env']]['remote_dir']+"incoming//ATG_OU//AP_INV_IMP_COSTAR"
#    remote_dir="//Outbox//IS//SMNH2I"
    upload_file_name = "CoStar_INV_IS_US_2020.txt"
    winscp_utility.upload_file(Stored_session,local_dir,remote_dir,upload_file_name)
    Log.Enabled=True       
    Log.Message("CoStar_INV_IS_US_2020.txt file placed in the AP_INV_IMP_COSTAR directory")           
    Log.Enabled=False
    
  
# Submitting the MAN CoStar Invoice Import Request Set in Oracle
 #def submit_request(self,app):

    Log.Message("Inside action...")    
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'AP Home Office Super User')]")
    self.log_message_web("Click 'AP Home Office Super User' - Successful")
    delay(1000)
#    self.page.keys("[Down]")
    self.wait_until_page_loaded()
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Other')]")
    self.log_message_web("Click 'Other' Folder - Successful")
    delay(1000)
#    self.page.keys("[Down]")
    self.wait_until_page_loaded()
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Requests')]")
    self.log_message_web("Click 'Requests' Folder - Successful")
    self.wait_until_page_loaded()
    self.page.NativeWebObject.Find("contentText","Run","A").Click()
    self.log_message_web("Click 'Run' Options - Successful")
    Delay(10000) 
#    self.page.wait_until_load()
    web_utils.validate_security_box()
    jFrame=self.initializeJFrame()
    delay(5000)
    form_utils.click_ok_btn(jFrame)

    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["*Request Set alt s","ExtendedCheckbox"]
    jFrame.Find(prop,val,30).Click()
    Delay(3000)

    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit a New Request","ExtendedFrame"]
    jFrame.Find(prop,val,30).Click()

    prop1=["AWTComponentAccessibleName","JavaClassName"]
    val1=["OK alt O","Button"]
    jFrame.FindChildEx(prop,val,60,True,60000).Find(prop1,val1,30).Click()
 
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit Request Set","ExtendedFrame"]
    par_form=jFrame.FindChildEx(prop,val,60,True,60000)
    par_form.Find("AWTComponentAccessibleName","Request Set RequiredList of Values",30).SetText("MAN CoStar Invoice Import Request Set")#MANAP Telecom Invoice Interface Request Set")# Updated to SetText
    delay(2000)
    
    jFrame.Find("AWTComponentAccessibleName","Program",60).Click()
    delay(2000)
    
    jFrame.Find("AWTComponentName","VTextField28",60).Click()   
    Delay(2000)
    jFrame.Keys("~o")
    Delay(2000)
    jFrame.Find("AWTComponentName","VTextField29",60).Click()
    Delay(2000)
    jFrame.Keys("~o")
    Delay(2000)
    jFrame.Find("AWTComponentName","VTextField30",60).Click()
    Delay(2000)
    jFrame.Keys("~o")
    

##    jFrame.Keys("DIMENSION_DATA_ATG_INV_20190924.csv.gpg")
  
    
    jFrame.Find("AWTComponentAccessibleName","Submit",60).Click()
    Delay(4000)
 
    RequestID = ''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit())
    Log.Message("Request ID Of  " + aqConvert.VarToStr(RequestID))
    #app.Cells.Item[2,21] = VarToStr(RequestID)
    self.log_checkpoint_message_web("Request ID Of MAN CoStar Invoice Import Request Set is " + aqConvert.VarToStr(RequestID))    
    delay(1000)    
    jFrame.Keys("~n")
    delay(1000)
    #jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000)
    
    
    dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
    user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
    pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
    dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,VarToStr(RequestID)) 
    delay(200000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,90000)
    
    # Gathering Request ID and Output File for the "CAI Payables Invoice Import Program" 
    
    
    file_format = "log"
    self.req_set_save_file(jFrame,req_form,"MAN CoStar Invoice Import Request Set (Report Set)",RequestID,file_format)
    jFrame.Click()
    Delay(2000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000)

    file_format = "log"
    self.req_set_save_file(jFrame,req_form,"MAN Global Data Loader",RequestID,file_format)
    jFrame.Click()
    Delay(2000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000)

    
    file_format = "output"
    self.req_set_save_file(jFrame,req_form,"MAN Invoice Validation and Import Program",RequestID,file_format)
    jFrame.Click()
    Delay(2000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000)
    
    dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
    user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
    pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
    dbhelper.verify_costar_invoice_info(dsn,user_id,pwd,self.Invoice_num1)    
    app.Cells.Item[rowno,13] = self.Invoice_num1 #self.inv_num
    Delay(1000)
    web_utils.close_additional_browsers()
    Delay(1000)
    jFrame.Click()
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(3000)
#    jFrame.Keys("[F4]")
#    Delay(1000)
#    jFrame.Keys("~o")
#    Delay(5000)    
    
    jFrame.Keys("~o")
    Delay(4000)
    jFrame.Keys("~o")
    Delay(4000)
    jFrame.Keys("[Down]")
    Delay(4000)
    jFrame.Keys("~o")
    Delay(7000)


#   Validating the Invoice in the Front end and checking Headerlevel DFF and Linelevel DFF
#    self.page.WaitProperty("contentText","AP Home Office Super User",6000)
#    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" AP INVOICE PROCESSING')]") 
#    self.log_message_web("Click 'CAI US AP INVOICE PROCESSING' - Successful")    
#    self.page.keys("[Down]")
#    Delay(1000)
#    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Invoices')]")
#    self.log_message_web("Click 'Invoices' - Successful")
#    delay(20000) 
    
    Delay(2000)
    #self.page.Keys("[PageUp]")
#    self.page.Keys("[F5]")
#    Delay(10000)
#    self.page.WaitProperty("contentText","AP Home Office Super User",6000)
#    self.page.EvaluateXPath("//table[@id='menuContent']//div[contains(text(),'AP Home Office Super User')]")[0].scrollIntoView()
#    delay(1000)
#    self.page.EvaluateXPath("//table[@id='menuContent']//div[contains(text(),'AP Home Office Super User')]")[0].Click() 
#    web_utils.log_checkpoint("Click 'AP Home Office Super User' - Successful",500,self.page) 
#    self.page.Keys("[Down]")
#    self.wait_until_page_loaded()
#    self.page.NativeWebObject.Find("contentText","Invoices","A").Click()
#    web_utils.log_checkpoint("Click 'Invoices' - Successful",500,self.page) 
#    self.page.Keys("[Down]")
#    self.wait_until_page_loaded()
#    self.page.NativeWebObject.Find("contentText","Entry","A").Click()
#    web_utils.log_checkpoint("Click 'Entry' - Successful",500,self.page) 
#    self.page.Keys("[Down]")
#    self.wait_until_page_loaded()
#    self.page.EvaluateXpath("//table[@id='respList']//div[contains(text(),'Invoices')]")[1].Click() 
#    web_utils.log_checkpoint("Click 'Invoices' - Successful",500,self.page)
#    Delay(3000)
#    
#    web_utils.validate_security_box()
#    jFrame=self.initializeJFrame() 
#    Delay(10000)
#    form_utils.click_ok_btn(jFrame)
#    Delay(6000)
    jFrame.Keys("~v")
    delay(6000)
    jFrame.Keys("f")
    delay(6000)
    
#   Finding Invoice
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Invoices","ExtendedFrame"]
    par_form=jFrame.FindChildEx(prop,val,60,True,60000)
    par_form.Find("AWTComponentAccessibleName","Invoice: Number",10).Click()
    par_form.Find("AWTComponentAccessibleName","Invoice: Number",10).Keys(app.Cells.Item[rowno,13])

    delay(5000) 
    jFrame.Keys("~i")
    Delay(10000)
    self.log_message_oracle_form(jFrame,"'Invoice Workbench' form launched successfully")
    
#        Below code is for capturing the invoice num from Invoice Workbench and saving it to Excel    
    p_names = ("JavaClassName","AWTComponentAccessibleName")
    p_values = ("ExtendedFrame","Invoice Workbench (AP Home Office Super User)")
    inv_form=jFrame.FindChildEx(p_names,p_values,60,True,120000)
    
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Trading Partner Required",16]
    trading_partner = inv_form.Find(prop,val,30)
    Supplier_name = trading_partner.wText
    
    app.Cells.Item[rowno,3] = Supplier_name
    app1.Cells.Item[rowno,9] = Supplier_name
    
    menu_bar=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWMenuBar", "", 0)
    OCR.Recognize(menu_bar).BlockByText("Folder").Click()
    Delay(2000)
    jFrame.Keys("o")
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Invoice Workbench*","ExtendedFrame"]
#    invoice=jFrame.FindChildEx(prop,val,60,True,60000)
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Open Folder*","VButton"]
#    open_fldr_form=invoice.FindChildEx(prop,val,30,True,60000)
#    open_fldr_form.Click()
    Delay(4000)
    jFrame.Keys("AP HEADER")
    delay(5000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Open Folder","FWindow"]
    open_folder=jFrame.FindChildEx(prop,val,50,True,90000)  
    Sys.HighlightObject(open_folder)     
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["OK ALT O","PushButton"]   
    open_folder.FindChild(prop,val,10).Click()
    
#    Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications - EBS", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("FWindow", "Open Folder", 0).AWTObject("LWComponent", "", 0).AWTObject("EwtContainer", "", 0).AWTObject("ButtonBar", "", 0).AWTObject("ButtonBar", "", 1).AWTObject("PushButton", "OK ALT O", 0).Click()
    delay(4000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Invoice Workbench*","ExtendedFrame"]
    invoice=jFrame.FindChildEx(prop,val,60,True,60000)
    prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
    val=["[ ]","VTextField","196"]
    hdr_level_dff=invoice.FindChildEx(prop,val,30,True,60000)
    hdr_level_dff.Click()
    delay(4000)
    self.log_message_oracle_form(jFrame,"'Telecom' Invoice Header Level DFF values reviewed successfully")
    delay(4000)
    jFrame.Keys("[F4]")
    delay(4000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Invoice Workbench*","ExtendedFrame"]
    invoice=jFrame.FindChildEx(prop,val,60,True,60000)
    self.log_message_oracle_form(jFrame,"Click on 'Lines' on 'Invoice Workbench' next")
    Delay(5000)
    invoice.FindChild("AWTComponentName","FormsTabPanel*",60).ClickTab("2 Lines")
    Delay(5000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Open Folder*","VButton"]
    open_fldr_form=jFrame.FindChildEx(prop,val,30,True,60000)
    open_fldr_form.Click()
    Delay(6000)
    jFrame.Keys("AP Lines")
    delay(5000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Open Folder","FWindow"]
    open_folder=jFrame.FindChildEx(prop,val,50,True,90000)  
    Sys.HighlightObject(open_folder)     
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["OK ALT O","PushButton"]   
    open_folder.FindChild(prop,val,10).Click()
#    Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications - EBS", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("FWindow", "Open Folder", 0).AWTObject("LWComponent", "", 0).AWTObject("EwtContainer", "", 0).AWTObject("ButtonBar", "", 0).AWTObject("ButtonBar", "", 1).AWTObject("PushButton", "OK ALT O", 0).Click()
    delay(4000)
    prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
    val=["[ ]","VTextField","405"]
    line_level_dff=jFrame.FindChildEx(prop,val,30,True,60000)
    line_level_dff.Click()
    delay(4000)
    self.log_message_oracle_form(jFrame,"'Telecom' Invoice Line Level DFF values reviewed successfully")
    delay(4000)
    jFrame.Keys("[F4]")
    delay(6000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~o")
    Delay(5000) 
    self.close_forms(jFrame)
    Delay(4000)
    
    
    
    
    
    

 def req_set_save_file(self,jFrame,req_form,srch_child_name,Preqid,file_format):
      self.log_message_oracle_form(req_form,"Checking for "+aqConvert.VarToStr(srch_child_name)+ " Child Program Status")
      req_form.FindChild("AWTComponentAccessibleName","Refresh Data alt R",20).Click()
      i=20
      for x in range(1,180):     
          prop=["AWTComponentAccessibleName","AWTComponentIndex"]
          val=["Name",i]
          child_name=req_form.Find(prop,val,10).wText 
          prop=["AWTComponentAccessibleName","AWTComponentIndex"]
          val=["Phase",i+20]
          phase=req_form.Find(prop,val,10).wText 
          prop=["AWTComponentAccessibleName","AWTComponentIndex"]
          val=["Request ID",i-10]
          creqid=VarToInt(req_form.Find(prop,val,10).wText)
  #        self.log_message_oracle_form(req_form,"Request ID of "+aqConvert.VarToStr(srch_child_name)+" is "+aqConvert.VarToStr(creqid))                                         
          prop=["AWTComponentAccessibleName","AWTComponentIndex"]
          val=["Status",i+30]         
          status =req_form.FindChild(prop,val,60)            
          if (child_name==srch_child_name) and (creqid>=VarToInt(Preqid)) and (phase == "Completed"):
              self.log_message_oracle_form(req_form, aqConvert.VarToStr(srch_child_name)+" Phase Completed Successfuly")             
  #            self.verify_aqobject_chkproperty(status,"wText",cmpContains,"Normal")        
              status.Keys("[Enter]")
              Delay(1000)
  #            jFrame.Keys("~g")  
              if file_format == "log":
                req_form.FindChild("AWTComponentAccessibleName","View Log alt K",20).Click()
              elif file_format == "output":
                req_form.FindChild("AWTComponentAccessibleName","View Output alt p",20).Click()  
              Delay(3000)
#              if(self.test_env=="oci_stage"):
#                output_page=Sys.Browser("iexplore").Page("https://manheim*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.*")
#              elif(self.test_env=="oci_dev"):
#                output_page=Sys.Browser("iexplore").Page("https://core*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.*")
              output_page=Sys.Browser("iexplore").Page("https://manheim*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.*")     
              output_page.Click()
              Delay(2000)
              output_page.Keys("~f")
              Delay(2000)
              output_page.Keys("a")
              Delay(5000)
              file_system_utils.create_folder(self.op_log_path)             
              log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"File"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"_%d%b%Y_%H%M")+".txt"    
              Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
              Delay(1000)
              Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
              Delay(2000)
              Log.Enabled=True
              Log.File(log_path, aqConvert.VarToStr(srch_child_name)+" Log/Output File Attached")
              Log.Enabled=False     
              Sys.Browser("iexplore").Page("https://manheim*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.*").Close()
              Filesaved = 'True'
              web_utils.close_additional_browsers()
              Filesaved = 'True'
              return                           
          elif i >=28:
             Delay(20000)
  #           req_form.keys("~r")
             req_form.FindChild("AWTComponentAccessibleName","Refresh Data alt R",20).Click()
             Delay(3000)
             i=20
             val=["Name",i]
             child_name=req_form.Find(prop,val,10).wText
  
          else:  
             Delay(3000)
             i=i+1 
