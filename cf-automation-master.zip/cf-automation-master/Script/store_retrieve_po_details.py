﻿import database_service
import gvar
import file_utility
import tc_logs

def send_results_to_db():
  
  gvar.store_excel_to_dict1("Project")
  gvar.store_excel_to_dict1("Requisition")
  gvar.store_excel_to_dict1('Invoice')
  date = aqDateTime.Today()
  req_no = gvar.excel['Requisition']['Requisition No'].strip()
  database_service.update_delete_mysql(f"insert into po_details (project_number, requistion, po_number, creation_date, env, operating_unit, status) VALUES ('{gvar.excel['Requisition']['Project']}', '{req_no}', '{gvar.excel['Invoice']['PO Number']}','{date}' , '{gvar.dataprep['test_env']}', '{gvar.dataprep['oper_unit']}', 'Available')")  
  Log.Enabled ='True'
  tc_logs.checkpt_with_no_picture(f"PO Results have been stored in table")
  Log.Enabled ='False' 
  
def get_po_from_db():
  details = database_service.query_mysql(f"select * from po_details where env = '{gvar.dataprep['test_env']}' and operating_unit = '{gvar.dataprep['oper_unit']}' and status = 'Available' order by creation_date")
  po_number = details[0]['po_number']
  Log.Enabled ='True'
  tc_logs.checkpt_with_no_picture(f"PO Results have been stored in table")
  Log.Enabled ='False'
  return po_number
  
def update_po_to_processed(po_number):
   database_service.update_delete_mysql(f"update po_details set status = 'Processed' where env = '{gvar.dataprep['test_env']}' and operating_unit = '{gvar.dataprep['oper_unit']}' and status = 'Available' and po_number = '{po_number}'")

  
