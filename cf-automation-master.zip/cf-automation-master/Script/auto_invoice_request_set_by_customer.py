﻿import gvar
import database_helper
import oracle_menus_form
import submit_request_set_form
import login_logout_utility
import oracle_responsibility_utility
import form_utility
import tc_logs

def run(customer):
   CurrentDate = aqConvert.DateTimeToFormatStr(aqDateTime.Today(),"%d-%b-%Y")
   login_logout_utility.oracle_login()
   oracle_responsibility_utility.ar_home_office_super_user('Run')
   form_utility.get_java_parent_form()
   delay(5000)

   if oracle_menus_form.submit_a_new_request_extended_frame().Exists:
      oracle_menus_form.request_set_radio_btn().Click()
      gvar.dataprep['jformobject'].Keys("~o")
      
   if submit_request_set_form.submit_request_extended_frame().Exists:
      submit_request_set_form.request_name_textfield().setText("MAN: AR Auto Invoice Request Set")
      gvar.dataprep['jformobject'].Keys("[Tab]")
      tc_logs.checkpt_with_picture("Submit RequestSet Form Window launch - Successful","",gvar.dataprep['jformobject'])
      
      #Autoinvoice Master Program - Line1 Parameter Entry Begin
      submit_request_set_form.parameters_1_textfield().Click()
      submit_request_set_form.inv_src_textfield().Keys("OM")
      gvar.dataprep['jformobject'].Keys("[Tab]")
      submit_request_set_form.default_date_textfield().Keys(CurrentDate)
      #submit_request_set_form.default_date_textfield().Keys(aqConvert.DateTimeToFormatStr(aqDateTime.Today(),"%d-%b-%Y"))
      submit_request_set_form.transaction_source_textfield()
      gvar.dataprep['jformobject'].Keys("[Tab]")
      submit_request_set_form.low_btc_num_textfield().Keys(customer)
      gvar.dataprep['jformobject'].Keys("[Tab]")
      submit_request_set_form.high_btc_num_textfield().Keys(customer)
      gvar.dataprep['jformobject'].Keys("[Tab]")
      tc_logs.checkpt_with_picture("Autoinvoice Master Program - Line1 Parameter Entry Successful","",gvar.dataprep['jformobject'])
      submit_request_set_form.ok_button().Click()
      #Autoinvoice Master Program - Line1 Parameter Entry End
      
      #Autoinvoice Master Program - Line2 Parameter Entry Begin
      submit_request_set_form.parameters_2_textfield().Click() 
      submit_request_set_form.inv_src_textfield().Keys("OM")
      gvar.dataprep['jformobject'].Keys("[Tab]")
      submit_request_set_form.default_date_textfield().Keys(CurrentDate)
      #submit_request_set_form.default_date_textfield().Keys(aqConvert.DateTimeToFormatStr(aqDateTime.Today(),"%d-%b-%Y"))
      submit_request_set_form.transaction_source_textfield()
      gvar.dataprep['jformobject'].Keys("[Tab]")
      submit_request_set_form.low_btc_num_textfield().Keys(customer)
      gvar.dataprep['jformobject'].Keys("[Tab]")
      submit_request_set_form.high_btc_num_textfield().Keys(customer)
      gvar.dataprep['jformobject'].Keys("[Tab]")
      tc_logs.checkpt_with_picture("Autoinvoice Master Program - Line2 Parameter Entry Successful","",gvar.dataprep['jformobject'])
      submit_request_set_form.ok_button().Click()
      #Autoinvoice Master Program - Line2 Parameter Entry End
      
      #MAN: AR Auto Invoice Exceptions Program - Begin
      submit_request_set_form.parameters_3_textfield().Click() 
      submit_request_set_form.email_text_field().Keys("dave.egan@coxautoinc.com")
      gvar.dataprep['jformobject'].Keys("[Tab]")
      tc_logs.checkpt_with_picture("Exception: email id - Line3 Parameter Entry Successful","",gvar.dataprep['jformobject'])
      submit_request_set_form.ok_button().Click()
      tc_logs.checkpt_with_picture("All Parameters are entered - successfully","",gvar.dataprep['jformobject'])
      #MAN: AR Auto Invoice Exceptions Program - End
      
      #Submit AutoInvoice RequestSet
      submit_request_set_form.submit_button().Click()
      delay(5000)

      #Capture Concurrent RequestID 
      request_id = form_utility.get_requestid()
      oracle_menus_form.no_button().Click()
      tc_logs.msg_with_no_picture("AutoInvoice RequestSet Submit - Successful","")
      form_utility.get_specific_request_details(request_id)
      database_helper.get_requestid_details(request_id,wait_time=80000) 
      gvar.dataprep['jformobject'].Keys("~r")
      form_utility.close_form()
      login_logout_utility.oracle_logout()
      return request_id
