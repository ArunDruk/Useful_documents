﻿from dbhelper import *
from ebiz import *
import web_utils
import dbhelper
import file_system_utils 
import form_utils

class tc97767cai_us_fa_depreciation(Ebiz):
 op_log_path="C:\\Tc_Logs"

 def login(self):
   self.login_user='rmaran'
   super().login()
   
 def action(self,book): 
   
   self.wait_until_page_loaded()    
   self.log_checkpoint_message_web("Login Successful")
   
   web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" FA PERIOD END')]")
   self.log_message_web("Click 'CAI "+self.oper_unit+" FA PERIOD END' - Successful")
   Delay(3000)
   self.page.EvaluateXPath("//ul[@rel='open']//div[text()='Depreciation']")[1].Click()
   self.log_message_web("Click 'Depreciation' - Successful")
   Delay(1000)
   self.page.NativeWebObject.Find("contentText","Run Depreciation","A").Click()
   self.log_message_web("Click 'Run Depreciation' - Successful")
   Delay(5000)
   jFrame= self.initializeJFrame()
   Delay(1000)
   form_utils.click_ok_btn(jFrame)
   self.log_message_oracle_form(jFrame,"'Run Depreciation' form launched succesfully")
   Delay(4000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Run Depreciation","ExtendedFrame"]
   Depreciation_form=jFrame.FindChild(prop,val,60)
   
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Book RequiredList of Values","VTextField"]
   book = Depreciation_form.FindChildEx(prop,val,60,True,10000)
   #book.Click()
   book.SetText("ATG CORP")
   Delay(5000)
   jFrame.keys("[Tab]")
   Delay(5000)
   self.log_message_oracle_form(jFrame,"In Run Deprciation form: 'Book' and 'Period' entered successfully")
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Run alt R","Button"]
   Depreciation_form.FindChild(prop,val,20).Click()

   Delay(2000)
   prop = ["AWTComponentAccessibleName","JavaClassName"]
   val = ["Note APP-OFA-*","ChoiceBox"]
   note = jFrame.FindChildEx(prop,val,60,True,10000)
   
   RequestID = ''.join(x for x in (note.AWTComponentAccessibleName.strip().split(':'))[1] if x.isdigit())
   
   prop = ["AWTComponentAccessibleName","JavaClassName"]
   val = ["OK ALT O","FormButton"]
   ok_button = note.FindChild(prop,val,10).Click()

#   jFrame.keys("~o")
   Delay(2000)
   jFrame.keys("~v")
   Delay(2000)
   jFrame.keys("r")
   Delay(5000)
   jFrame.keys("~i")
   
   Delay(2000) 
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Requests","ExtendedFrame"]
   req_form=jFrame.FindChild(prop,val,30)
   self.verify_aqobject_chkproperty(req_form,"AWTComponentAccessibleName",cmpContains,"Requests") 
   self.log_message_oracle_form(jFrame,"Requests form launched successfully") 
   job_name_child="false"
   phase_parent="false"  
   i=20
   
   form_utils.req_set_save_output(self,jFrame,req_form,"Journal Entry Reserve Ledger Report",RequestID)
#   while not (job_name_child == "Journal Entry Reserve Ledger Report" and phase_parent == "Completed"):
#     Delay(2000)
#     prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#     val=["Name",i]
#     job_name_child=req_form.Find(prop,val,10).wText    
#     req_form.Find(prop,val,10).Keys("[Enter]")
#     Delay(2000)
#     prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#     val=["Phase",i+20]
#     phase_parent=req_form.Find(prop,val,10).wText    
#     if i==25:
#          prop=["AWTComponentAccessibleName","JavaClassName"]
#          val = ["Refresh Data alt R","Button"]
#          req_form.FindChild(prop,val,2000).Click() 
#          i=20 
#     else:          
#          i+=1
#   Delay(2000)
#    
#   prop=["AWTComponentAccessibleName","JavaClassName"]
#   val = ["View Output alt p","Button"]
#   req_form.FindChild(prop,val,2000).Click()
#   Delay(3000)
#   output_page=Sys.Browser("iexplore").Page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
#   output_page.Click()
#   Delay(2000)
#   output_page.Keys("~f")
#   output_page.Keys("a")
#   Delay(2000)
#   file_system_utils.create_folder(self.op_log_path)             
#   log_path=self.op_log_path+"\\Journal Entry Reserve Ledger Report Output Is Attached_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
#   Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
#   Delay(1000)
#   Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
#   Delay(5000)
#   Log.Enabled=True
#   Log.File(log_path, "Journal Entry Reserve Ledger Report")
#   Log.Enabled=False     
#   Sys.Browser("iexplore").Page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close()
   jFrame.Keys("[F4]")
   Delay(2000)
   jFrame.Keys("[F4]")
   Delay(2000)
   jFrame.Keys("~o")
   Delay(2000)
   web_utils.close_additional_browsers()   
#   Sys.Browser("iexplore").page("https://*epfinnp.coxautoinc.com/forms/frmservlet*").Close()
  
   
   
