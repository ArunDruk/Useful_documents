﻿from base import *
from driverchain import *
from ebiz import *
import test_utility
import gvar
import tc_logs

  
  
class Driver(Driverchain):
    global classarr,env
    
    def __init__(self):
      global test_env, sheet_obj, book     
      app = Sys.OleObject["Excel.Application"]
      Delay(1000)
      self.book = app.Workbooks.Open(Project.Path+"\\datasheets\\WCI\\wcc_us_1_npo_V12.xls")          
#      app.Visible = "True" 
      gvar.dataprep['book'] = self.book 
         
      self.test_env=BuiltIn.ParamStr(14)
      self.oper_unit=BuiltIn.ParamStr(15)
      self.user = "mkumar"
#      
#      self.test_env="oci_test"
#      self.oper_unit="US"
#      self.user = "mkumar"
#      
      gvar.dataprep['user'] = self.user
#      self.classarr=["ie_clear_cache()","capture_invoice_via_email()","ie_clear_cache()","WCC_Verify_batch_creation_email_V12()","ie_clear_cache()","WFR_Process_Email_Batches_V12()","ie_clear_cache()","WCC_Update_Batches_Coding_Form_V12_Test()","tc194049_run_payable_open_interface_import_process()","ie_clear_cache()","tc130335_validateInvoice()","tc93849cai_us_create_accounting()","ie_clear_cache()","tc95047cai_us_validate_subledger_accounting()","tc93848cai_us_next_day_check_payment()"]
#      self.classarr=["ie_clear_cache()","capture_invoice_via_email()","ie_clear_cache()","WCC_Verify_batch_creation_email_V12()","ie_clear_cache()","WFR_Process_Email_Batches_V12()","ie_clear_cache()","WCC_Update_Batches_Coding_Form_V12()","tc194049_run_payable_open_interface_import_process()","ie_clear_cache()","tc130335_validateInvoice()","tc93849cai_us_create_accounting()","ie_clear_cache()","tc95047cai_us_validate_subledger_accounting()","tc93848cai_us_next_day_check_payment()"]

      self.classarr=["ie_clear_cache()","capture_invoice_via_email()","ie_clear_cache()","WCC_Verify_batch_creation_email_V12()","WFR_Process_Email_Batches_V12()","ie_clear_cache()","WCC_Update_Batches_Coding_Form_V12_Test()","ie_clear_cache()","tc194049_run_payable_open_interface_import_process()","ie_clear_cache()","tc130335_validateInvoice()","ie_clear_cache()","tc93849cai_us_create_accounting()","ie_clear_cache()","tc95047cai_us_validate_subledger_accounting()","ie_clear_cache()","tc95046cai_us_domestic_ach_payment()"]
      super().__init__(self.classarr)
      #
    def close_excel(self):    
      self.book.save()
      delay(1000)
      self.book.close()
      
      
      
def main():  
  try:
     gvar.dataprep['env'] =BuiltIn.ParamStr(14)
#     gvar.dataprep['browser'] = "chrome"
     obj=Driver()    
     test_utility.start_test(__name__.center(70,'*'),'Core Financials - CF','VERIFIER','163778','CAI WCI E2E - OCI TEST')  
     cobj = obj.run()   
     print('evoke test_utility')
  except:
     gvar.dataprep['verdict'] = 'Fail'
     tc_logs.header_name('Test Failed - traceback shown below')       
     tc_logs.error_with_no_picture(traceback.format_exc(),'')       
     print('evoke test_utility')
  finally:
     test_utility.end_test()
     obj.close_excel()
