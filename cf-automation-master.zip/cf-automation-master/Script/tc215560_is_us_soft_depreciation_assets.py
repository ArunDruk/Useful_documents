﻿from dbhelper import *
from ebiz import *
import web_utils
import dbhelper
import file_system_utils 
import form_utils

class tc215560_is_us_soft_depreciation_assets(Ebiz):
 op_log_path="C:\\Tc_Logs"

 def login(self):
   self.login_user='naggarwal'
   super().login()
   
 def goto_url(self,url):
   super().goto_url(self.testConfig['ebiz']['oci_is_url'])
   
 def action(self,book): 
   app = book.Sheets.item["asset_creation"]
   app1 = book.Sheets.item["Assets"]
   self.wait_until_page_loaded()    
   self.log_checkpoint_message_web("Login Successful")
   web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'AM Super User')]")
   self.log_message_web("Click 'AM Supervisor' - Successful")
   Delay(3000)
   self.page.NativeWebObject.Find("contentText","Depreciation","A").Click()
   self.log_message_web("Click 'Depreciation' - Successful")
   Delay(2000)
   self.page.wait()
   self.page.NativeWebObject.Find("contentText","Run Depreciation","A").Click()
   self.log_message_web("Click Run Depreciation' - Successful")
   Delay(2000)
   self.page.wait()
   #Handling the security pop-up and opening forms
   web_utils.validate_security_box()
   jFrame= self.initializeJFrame()
   Delay(5000)
   form_utils.click_ok_btn(jFrame)
   Delay(5000)
   self.log_message_oracle_form(jFrame,"'Run Depreciation' form launched succesfully")
   Delay(4000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Run Depreciation","ExtendedFrame"]
   Depreciation_form=jFrame.FindChild(prop,val,60)
   
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Book RequiredList of Values","VTextField"]
   book = Depreciation_form.FindChildEx(prop,val,60,True,10000)
   book.SetText(VarToStr(app.Cells.Item[2,3]))
   Delay(5000)
   jFrame.keys("[Tab]")
   Delay(5000)
   self.log_message_oracle_form(jFrame,"In Run Deprciation form: 'Book' and 'Period' entered successfully")
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Run alt R","Button"]
   Depreciation_form.FindChild(prop,val,20).Click()

   Delay(2000)
   prop = ["AWTComponentAccessibleName","JavaClassName"]
   val = ["Note APP-OFA-*","ChoiceBox"]
   note = jFrame.FindChildEx(prop,val,60,True,10000)
   
   RequestID = ''.join(x for x in (note.AWTComponentAccessibleName.strip().split(':'))[1] if x.isdigit())
   
   prop = ["AWTComponentAccessibleName","JavaClassName"]
   val = ["OK ALT O","FormButton"]
   ok_button = note.FindChild(prop,val,10).Click()

#   jFrame.keys("~o")
#   dbhelper.verify_oracle_concurrent_job_status(RequestID)
   
   Delay(20000)
   jFrame.keys("~v")
   Delay(2000)
   jFrame.keys("r")
   Delay(5000)
   jFrame.keys("~i")
   
   Delay(2000) 
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Requests","ExtendedFrame"]
   req_form=jFrame.FindChild(prop,val,30)
   self.verify_aqobject_chkproperty(req_form,"AWTComponentAccessibleName",cmpContains,"Requests") 
   self.log_message_oracle_form(jFrame,"Requests form launched successfully") 
   job_name_child="false"
   phase_parent="false"  
   i=20
   
   form_utils.req_set_save_output(self,jFrame,req_form,"Journal Entry Reserve Ledger Report",RequestID)
   web_utils.close_additional_browsers()
   delay(2000)
   ####   #Submit new request
   jFrame.Keys("~m") 
   
# submit create accounting program:
   delay(180000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Submit Request","ExtendedFrame"]
   submitrequest_form=jFrame.FindChildEx(prop,val,60,True,60000)
   submitrequest_form.Find("AWTComponentAccessibleName","Name RequiredList of Values",10).Click()
   Delay(4000)
   submitrequest_form.Find("AWTComponentAccessibleName","Name RequiredList of Values",10).SetText("Create Accounting - Assets")
   delay(3000)
   jFrame.Keys("[Tab]")
   delay(4000) 
   
#Entering Parameters
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Parameters","FlexWindow"]
   parameters_form=jFrame.FindChildEx(prop,val,60,True,60000)
   book_txtfield=parameters_form.FindChild("AWTComponentAccessibleName","Book Type Code REQUIRED List Values",10)
   book_txtfield.Click()
   book_txtfield.Keys(VarToStr(app1.Cells.Item[2,6]))
   Delay(1000)
   parameters_form.Keys("[Tab]")
   Delay(1000)
   report = parameters_form.FindChild("AWTComponentAccessibleName","Report REQUIRED List Values: No Report",10)
   report.Click()
   report.Keys("Detail")
   Delay(1000)
   parameters_form.Keys("[Tab]")
   Delay(1000)
   self.log_message_oracle_form(jFrame,"'Create Accounting - Assets' Program Parameters entered successfully")
   val = ["OK ALT O","FormButton"]
   parameters_form.FindChild(prop,val,60).Click()
   Delay(2000)
   
#submit create  accounting
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Submit alt m","Button"]
   submitrequest_form.FindChild(prop,val,60).Click()
   self.log_message_oracle_form(jFrame,"Create Accounting - Assets job submitted")
   Delay(2000)
   
   val = ["Decision Request submitted*","ChoiceBox"]
   decision_box = jFrame.FindChildEx(prop,val,60,True,12000)
   RequestID = aqConvert.VarToStr(''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit()))
   self.log_message_oracle_form( jFrame,"'Create Accounting-Assets' program submitted successfully and Request ID is "+VarToStr(RequestID))
   delay(1000)
   jFrame.Keys("~n")
   delay(1000)
   jFrame.Keys("~o")
   delay(1000)
   jFrame.Keys("~[F4]")
   delay(1000)
#   jFrame.Keys("~[F4]")
#   self.close_forms(jFrame)
   wscript=Sys.OleObject["WScript.Shell"]
   wscript.Run("taskkill.exe /F /IM jp2launcher.exe /T")
#   RequestID = VarToStr(162033163)
#verifying for request completion
   delay(180000)
   dsn = self.dbconfig[self.testConfig['ebiz']['env']]['man_dsn']
   user_id = self.dbconfig[self.testConfig['ebiz']['env']]['man_userid']
   pwd = self.dbconfig[self.testConfig['ebiz']['env']]['man_pwd']
   je_req_id = dbhelper.vfy_oracle_concurrent_job_je(dsn,user_id,pwd,RequestID)
   delay(2000)
   
# launch jframe againt to validate journal import
     
   self.page.EvaluateXpath("//table[@id='respList']//div[contains(text(),'Other')]")[0].scrollIntoView()
   web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Other')]")
   self.wait_until_page_loaded()  
   self.page.EvaluateXpath("//table[@id='respList']//div[contains(text(),'Requests')]")[0].scrollIntoView()
   web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Requests')]")
   self.wait_until_page_loaded() 
   self.log_message_web("Navigate AM Super User > Other > Requests Successful")
   self.page.EvaluateXpath("//li[@id='LIRequests']/a/div[2]")[0].scrollIntoView()
   self.page.EvaluateXpath("//li[@id='LIRequests']/a/div[2]")[0].Click()
   
   web_utils.log_checkpoint("Navigating to Requests Form to Validate Create Accounting and Journal Import Report",500,self.page)   
   web_utils.validate_security_box()
   Delay(6000)
   jFrame=self.initializeJFrame()
   Delay(20000)
   form_utils.click_ok_btn(jFrame) 
   Delay(7000)
   jFrame.Keys("~c")
   Delay(3000)
   web_utils.log_checkpoint("*******Validating output for Create Accounting Program*********",500,jFrame) 
   form_utils.save_output_singlereq(self,jFrame,self.op_log_path,"Create Accounting - Assets",RequestID)
   delay(2000)
   if je_req_id == None:
     self.log_error_message("Jounal Import Transaction is not Triggered for Create Accounting Program: "+VarToStr(RequestID))
   self.close_forms(jFrame)
   Delay(5000)
   self.log_message_web("Navigate AM Super User > Other > Requests > Run")
   self.page.EvaluateXpath("//li[@id='LIRequests']/a/div[2]")[0].scrollIntoView()
   self.page.EvaluateXpath("//li[@id='LIRequests']/a/div[2]")[0].Click()
   web_utils.validate_security_box()
   Delay(10000)
   jFrame=self.initializeJFrame()
   Delay(20000)
   form_utils.click_ok_btn(jFrame) 
   Delay(7000)
   jFrame.Keys("~c")
   Delay(3000)
   web_utils.log_checkpoint("Journal Import Request ID : "+VarToStr(je_req_id),500,jFrame) 
   web_utils.log_checkpoint("*******Validating output for Journal Import*********",500,jFrame) 
   log_path = form_utils.save_output_ji(self,jFrame,self.op_log_path,"Journal Import",je_req_id)
   fo=open(log_path,"r") 
   lines=fo.readlines()
   self.log_message_web("Journal Imported Batch Name is : - "+lines[17][8:39].strip())
   app1.Cells.Item[2,3] = lines[17][8:39].strip()  
   app1.Cells.Item[2,4] = VarToStr(je_req_id)
   app1.Cells.Item[2,5] = "Depreciated"
   jFrame.Click()
   Delay(3000)
   jFrame.Keys("[F4]")
   Delay(3000)
   wscript=Sys.OleObject["WScript.Shell"]
   wscript.Run("taskkill.exe /F /IM jp2launcher.exe /T")
   Delay(2000)
   web_utils.close_additional_browsers()   
#   Sys.Browser("iexplore").page("https://*epfinnp.coxautoinc.com/forms/frmservlet*").Close()
  
   
def test():
   self.page = Sys.Browser("iexplore").Page("*")
   self.page.EvaluateXpath("//table[@id='respList']//div[contains(text(),'Other')]")[0].scrollIntoView()
   web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Other')]")
   self.wait_until_page_loaded()  
   self.page.EvaluateXpath("//table[@id='respList']//div[contains(text(),'Requests')]")[0].scrollIntoView()
   web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Requests')]")
   
