﻿import gvar

def find_assets_window():
  prop_names = ["AWTComponentAccessibleName","JavaClassName"]
  prop_values = ["Find Assets","ExtendedFrame"]
  return gvar.dataprep['jformobject'].FindChildEx(prop_names,prop_values,30,True,5000)
  
def asset_number_textfield(fnd_assets_wdw):
  prop_names = ["AWTComponentAccessibleName","AWTComponentName"]
  prop_values = ["Asset Number","VTextField199"]
  return fnd_assets_wdw.FindChildEx(prop_names,prop_values,20,True,1000)
  
def find_button(fnd_assets_wdw):
  return fnd_assets_wdw.FindChildEx("AWTComponentAccessibleName","Find alt i",20,True,1000)
