﻿from dbhelper import *
from ebiz import *
import web_utils
import dbhelper
import file_system_utils

class tc186234_prc_update_summary_amounts_single_project(Ebiz):

 op_log_path ="C:\\TC_Logs"

 def login(self):
  self.login_user='pkjami'
  super().login()
  
 def goto_url(self,url):
  super().goto_url(self.testConfig['ebiz']['oci_is_url'])
   
 def action(self,book): 
   
   app = book.Sheets.item["Requisition"]
   rowno = 2
   web_utils.log_checkpoint("Logged in to Oracle Applications Home Page Successfully",500,self.page)
   self.wait_until_page_loaded()       
   self.page.EvaluateXPath("//table[@id='menuContent']//div[contains(text(),'PC User')]")[0].Click() 
   web_utils.log_checkpoint("Click 'PC User' - Successful",500,self.page) 
   self.page.Keys("[Down]")
   self.page.Keys("[Down]")
   self.page.Keys("[Down]")
   self.page.Keys("[Down]")
   self.wait_until_page_loaded()
   self.page.NativeWebObject.Find("contentText","Other","A").Click()
   web_utils.log_checkpoint("Click 'Other' - Successful",500,self.page) 
   self.page.Keys("[Down]")
   self.page.Keys("[Down]")
   self.page.NativeWebObject.Find("contentText","Requests","A").Click()
   web_utils.log_checkpoint("Click 'Requests' - Successful",500,self.page)
   self.page.Keys("[Down]")
   self.page.NativeWebObject.Find("contentText","Run","A").Click()
   web_utils.log_checkpoint("Click 'Run' - Successful",500,self.page)
   web_utils.validate_security_box()
   Delay(15000)
   jFrame=self.initializeJFrame()
   form_utils.click_ok_btn(jFrame)  
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Submit a New Request","ExtendedFrame"]
   submit_req_form=jFrame.FindChildEx(prop,val,30,True,60000)
   submit_req_form.FindChild("AWTComponentAccessibleName","OK alt O",10).Click()
   Delay(2000)

  
#Submit PRC: Update Project Summary Amounts for a Single Project

   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Submit Request","ExtendedFrame"]
   submitrequest_form=jFrame.FindChildEx(prop,val,60,True,90000)
   self.verify_aqobject_chkproperty(submitrequest_form,"AWTComponentAccessibleName",cmpContains,"Submit Request")
   submitrequest_form.Find("AWTComponentAccessibleName","Name RequiredList of Values",30).SetText("PRC: Update Project Summary Amounts for a Single Project")
   web_utils.log_checkpoint("Request Name: 'PRC: Update Project Summary Amounts for a Single Project' - populated Successfully",500,jFrame)
   jFrame.Keys("[Tab]")
   Delay(8000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Parameters","FlexWindow"]
   parameters_form=jFrame.FindChildEx(prop,val,60,True,20000)
   jFrame.Find("AWTComponentAccessibleName","Project Number REQUIRED List Values",30).Click()  
   jFrame.Find("AWTComponentAccessibleName","Project Number REQUIRED List Values",30).Keys(app.Cells.Item[rowno,11])
   Delay(3000)
   jFrame.Keys("[Tab]")
   Delay(3000)
   web_utils.log_checkpoint("'PRC: Update Project Summary Amounts for a Single Project' parameters entered successfully",500,jFrame)
   jFrame.keys("~o")
   Delay(2000)
   jFrame.keys("~m")
   Delay(3000)

# Capturing RequestID

   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Decision","LWLabel"]
   parameters_form=jFrame.FindChildEx(prop,val,60,True,60000)
   Delay(2000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Decision Request Submitted*","ChoiceBox"]
   decision_form=jFrame.FindChild(prop,val,60)
   RequestID = ''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit())
   web_utils.log_checkpoint("'PRC: Update Project Summary Amounts for a Single Project' is submitted and Request ID is " + aqConvert.VarToStr(RequestID),500,jFrame)
   Delay(2000)
   Rid =aqConvert.VarToStr(RequestID)
   jFrame.Keys("~n")
   Delay(9900)   
   dsn = self.testConfig['man_oracle_db']['dsn']
   user_id = self.testConfig['man_oracle_db']['userid']
   pwd = self.testConfig['man_oracle_db']['pwd']
   dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,RequestID)
   
#Capturing Outputs for PRC: Interface Assets to Oracle Assets 

   jFrame.Keys("~v")
   Delay(4000)
   jFrame.Keys("r")
   Delay(4000)
   jFrame.Keys("~s")
   prop_names=["JavaClassName","AWTComponentAccessibleName"]
   prop_values=["VTextField","Request ID"]
   temp=jFrame.FindAll(prop_names,prop_values,60)
   jFrame.Find("AWTComponentName",temp[10].AWTComponentName,60).Click()
   jFrame.Find("AWTComponentName",temp[10].AWTComponentName,60).SetText(RequestID)
   Delay(2000)
   web_utils.log_checkpoint("Query for 'PRC: Update Project Summary Amounts for a Single Project' submitted Request ID:" +RequestID,500,jFrame)
   jFrame.Keys("~i")
   Delay(2000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Requests","ExtendedFrame"]
   req_form=jFrame.FindChildEx(prop,val,30,True,60000)
   prop=["AWTComponentAccessibleName","AWTComponentIndex"]
   val=["Phase",40]
   phase=req_form.Find(prop,val,10).wText 
   while phase != "Completed":
     Delay(1000)
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val = ["Refresh Data alt R","Button"]
     req_form.FindChild(prop,val,2000).Click() 
     Delay(4000)
     phase=req_form.Find(prop,val,10).wText 
   web_utils.log_checkpoint("'PRC: Update Project Summary Amounts for a Single Project' program phase Completed",500,jFrame)
   Delay(1000)
   jFrame.Keys("~k")
   file_type = 'Log'
   self.save_log(file_type)
   delay(4000)
   jFrame.Keys("~p")
   file_type = 'Output'
   self.save_log(file_type)
   Delay(6000)
   jFrame.Keys("[F4]")
   Delay(4000)
   jFrame.Keys("[F4]")
   Delay(2000)
   jFrame.Keys("~o")
   Delay(2000)

   
   
 def save_log(self,file_type):
   
   Delay(15000)
   self.wait_until_page_loaded()
   log_page=Sys.Browser("iexplore").Page("https://manheim-*.epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
   Delay(1000)
   log_page.Click()
   log_page.TextNode(0).Click()
   Delay(1000)
   Log.Enabled=True     
   screenshot=log_page.PagePicture()
   msg = (file_type+" File Opened Successfully")
   Log.Picture(screenshot,msg)
   Log.Enabled=False
   log_page.Keys("~f")
   Delay(5000)
   log_page.Keys("a")
   Delay(5000) 
   file_system_utils.create_folder(self.op_log_path)             
   log_path=self.op_log_path+"\\prc update project summary amount "+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
   Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
   Delay(1000)
   Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
   Delay(5000)
   Log.Enabled=True
   Log.File(log_path,"PRC: Update Project Summary Amounts for a Single Project "+file_type+" file Attached")
   Log.Enabled=False     
   Sys.Browser("iexplore").Page("https://manheim-*.epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
   web_utils.close_additional_browsers()
   
   
   

