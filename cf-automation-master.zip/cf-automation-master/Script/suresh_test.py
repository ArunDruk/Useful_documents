﻿from base import *
from driverchain import *
from ebiz import *


class Driver(Driverchain):
  global classarr,env
  
  def __init__(self):
    global test_env, sheet_obj, book     
    app = Sys.OleObject["Excel.Application"]
    Delay(1000)
    self.book = app.Workbooks.Open(Project.Path+"\\datasheets\\E2E\\suresh_test.xls")          
    app.Visible = "True"    
    self.test_env=BuiltIn.ParamStr(14)
    self.oper_unit=BuiltIn.ParamStr(15)
#    
    self.test_env="oci_stage"
    self.oper_unit="US"
   
#    self.classarr=["ie_clear_cache()","tc85181cai_us_project_creation()","tc93546cai_us_create_non_catalog_req()","ie_clear_cache()","test_approve_requisition()","ie_clear_cache()","tc93548cai_us_CreatePO()","tc98611cai_us_auto_create_po_validation_1()","tc16319cai_us_ReceivePoItems()","ie_clear_cache()","tc98612cai_us_CorrectReceipt()","ie_clear_cache()","tc84510cai_us_create_manual_ap_invoice_match()","tc93849cai_us_create_accounting()","ie_clear_cache()","tc98616cai_us_ap_invoices_initiate_approval()","ie_clear_cache()","tc95047cai_us_validate_subledger_accounting()","tc93848cai_us_next_day_check_payment()","ie_clear_cache()","tc93850cai_us_journal_validation()","ie_clear_cache()","tc97359cai_us_cai_pa_nightly_request_set()","tc97750cai_us_create_project_asset()","tc93484cai_us_prc_generate_asset_lines_for_a_single_project()","ie_clear_cache()","tc93485cai_us_prc_interface_assets_to_oracle_assets()","tc93507cai_us_post_mass_additions()","tc99685cai_us_asset_inquiry()","tc97761cai_us_asset_tieback()"]    
#    self.classarr=["tc93548cai_us_CreatePO()","tc93549cai_us_ApprovePO()","tc16319cai_us_ReceivePoItems()","ie_clear_cache()","tc98612cai_us_CorrectReceipt()","ie_clear_cache()","tc84510cai_us_create_manual_ap_invoice_match()","tc93849cai_us_create_accounting()","ie_clear_cache()","tc98616cai_us_ap_invoices_initiate_approval()","tc98614cai_us_ap_invoice_approval_completion()","ie_clear_cache()","tc95047cai_us_validate_subledger_accounting()","tc93848cai_us_next_day_check_payment()","ie_clear_cache()","tc93850cai_us_journal_validation()","ie_clear_cache()","tc97359cai_us_cai_pa_nightly_request_set()","tc97750cai_us_create_project_asset()","tc93484cai_us_prc_generate_asset_lines_for_a_single_project()","ie_clear_cache()","tc93485cai_us_prc_interface_assets_to_oracle_assets()","tc93507cai_us_post_mass_additions()","tc99685cai_us_asset_inquiry()","tc97761cai_us_asset_tieback()"]    
#    self.classarr=["tc93548cai_us_CreatePO()","tc16319cai_us_ReceivePoItems()","ie_clear_cache()","tc98612cai_us_CorrectReceipt()","ie_clear_cache()","tc84510cai_us_create_manual_ap_invoice_match()","tc93849cai_us_create_accounting()","ie_clear_cache()","tc98616cai_us_ap_invoices_initiate_approval()","tc98614cai_us_ap_invoice_approval_completion()","ie_clear_cache()","tc95047cai_us_validate_subledger_accounting()","tc93848cai_us_next_day_check_payment()","ie_clear_cache()","tc93850cai_us_journal_validation()","ie_clear_cache()","tc97359cai_us_cai_pa_nightly_request_set()","tc97750cai_us_create_project_asset()","tc93484cai_us_prc_generate_asset_lines_for_a_single_project()","ie_clear_cache()","tc93485cai_us_prc_interface_assets_to_oracle_assets()","tc93507cai_us_post_mass_additions()","tc99685cai_us_asset_inquiry()","tc97761cai_us_asset_tieback()"]        
    self.classarr=["tc95047cai_us_validate_subledger_accounting()"]
    super().__init__(self.classarr)
        
  def close_excel(self):    
    self.book.save()
    delay(1000)
    self.book.close()
	
def main():  
  obj=Driver()
  cobj = obj.run()
  obj.close_excel()
