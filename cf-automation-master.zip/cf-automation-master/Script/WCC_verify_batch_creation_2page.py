﻿from dbhelper import *
from ebiz import *
import web_utils
import wcc_login_page
import wcc_home_page

class WCC_verify_batch_creation_2page(Ebiz):
  
 def login(self):
    self.login_user="pburugupal"
#    prop=["idStr","ObjectType"]
#    val=["userid","TextBox"]
    wcc_login_page.username_textfield().SetText(self.login_user) 
#    self.log_message_web("Set User ID:  "+self.login_user+" Successful")
    self.page.Keys("[Tab]")
#    prop=["idStr","ObjectType"]
#    val=["password","PasswordBox"]
    wcc_login_page.password_textfield().SetText(self.testConfig['ebiz']['password']) 
    self.page.wait_until_loaded()
#    prop=["ObjectIdentifier","ObjectType"]
#    val=["Log In","SubmitButton"]
    wcc_login_page.login_button().Click()
    self.wait_until_page_loaded()    
    
 def goto_url(self,url):
   super().goto_url(self.testConfig['ebiz']['webCenCapUrl'])
   
 def logout(self):
   self.page.wait()
   wcc_home_page.sign_out_link().Click()
#   self.page.FindChild("idStr","pt1:pt_np1:linkLogout",20).Click()
   web_utils.log_checkpoint("Completed WCI Capture Application Validation Successfully: Logging out from Applications",500,self.page)
   wcc_home_page.final_page().Close()
#   Sys.Browser("iexplore").Page("https://*.manheim.com/dc-client/faces/dc-client.jspx?*").Close()
   
 def wait_until_page_loaded(self):
   Delay(5000)  
   
 def action(self,book):
  app = book.Sheets.item["mail_wcc"]   
  Delay(6000)
#  if wcc_login_page.login_alert_popup().Exists:
  wcc_login_page.login_alert_popup().Click()
#  if Sys.Browser("iexplore").Page(self.testConfig['ebiz']['webCenCapUrl']+"*").Alert.Exists:
#    Sys.Browser("iexplore").Page(self.testConfig['ebiz']['webCenCapUrl']+"*").Alert.Button("OK").Click()
  Delay(2000)
  self.wait_until_page_loaded()
#  if Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).Tab("WebCenter Capture - Internet Explorer").Window("Shell DocObject View", "", 1).Window("Internet Explorer_Server", "", 1).Window("Java Plug-in Control Window", "", 1).AWTObject("PluginEmbeddedFrame", "").SwingObject("RMCApplet", "", 0).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("FormManagerPanel", "", 0).SwingObject("JPanel", "", 0).SwingObject("ExistingSessionPanel", "", 0).SwingObject("RoundedCornerPanel", "", 0).Exists:
#    Sys.Browser("iexplore").BrowserWindow(0).Keys("[Enter]")
  Delay(2000)
#  round_panel = wcc_login_page.java_plugin_ok_button()
  if wcc_login_page.java_plugin_ok_button().Exists:
    Sys.Browser("iexplore").BrowserWindow(0).Keys("[Enter]")
  # Check security warning window exists
#  security_wnd=Sys.Browser("iexplore").WaitSwingObject("JDialog", "Security Warning", -1, 1,10000)  
#  if security_wnd.Exists:
#    Sys.Browser("iexplore").SwingObject("JDialog", "Security Warning", -1, 1).FindChild("AWTComponentAccessibleName","I accept the risk and want to run this application.",30).Click()
#    Sys.Browser("iexplore").SwingObject("JDialog", "Security Warning", -1, 1).Keys("[Enter]")
  wcc_login_page.security_window_checkbox().Click()
  wcc_login_page.security_window_enter().Keys("[Enter]")
  Delay(2000)
  self.wait_until_page_loaded()
#  if Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).Tab("WebCenter Capture - Internet Explorer").Window("Shell DocObject View", "", 1).Window("Internet Explorer_Server", "", 1).Window("Java Plug-in Control Window", "", 1).AWTObject("PluginEmbeddedFrame", "").SwingObject("RMCApplet", "", 0).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("FormManagerPanel", "", 0).SwingObject("JPanel", "", 0).SwingObject("ExistingSessionPanel", "", 0).SwingObject("RoundedCornerPanel", "", 0).Exists:
#    Sys.Browser("iexplore").BrowserWindow(0).Keys("[Enter]")
  if wcc_login_page.java_plugin_ok_button().Exists:
    Sys.Browser("iexplore").BrowserWindow(0).Keys("[Enter]")
  self.wait_until_page_loaded()  
  batch_list = wcc_home_page.batch_edit_form()
#  batch_list=self.page.FindChildEx("JavaClassName","BatchEditForm$30",30,True,90000)
  count =  0
  
  #Enter Applications and Validate the Home Page:
  while not batch_list.Exists:
    Delay(2000)
    batch_list=wcc_home_page.batch_edit_form() 
    count = count + 1 
    if count == 10:
      self.log_error_message("Unable to Login to WCI Capture Application")    
  web_utils.log_checkpoint("Logged in to Web Center Capture Applications Successfully",500,self.page) 
  Delay(3000)
#  Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).FindChild("JavaClassName","VetoableComboBox",40).click()
  wcc_home_page.location_dropdown().Click()
  delay(1000)
  location = VarToStr(app.Cells.item[2,3])[2:]
#  Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).FindChild("JavaClassName","VetoableComboBox",40).keys(location)
  wcc_home_page.location_dropdown().keys(location)
  web_utils.log_checkpoint("Selected Capture Location Sucessfully"+location,500,self.page)
  self.wait_until_page_loaded()
  b_id = batch_list.Id
  batch_list.FindID(b_id).click() 
  delay(2210) 
  
  # Get Batch Details and Validate for Required Batch:
#  batch_name=Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).FindChild("AWTComponentAccessibleName","Batch Name:",40)
  batch_name = wcc_home_page.batch_name_textfield()
  i = 0
  while batch_name.Exists == None: 
    batch_list.FindID(b_id).click()
    i = i + 1
    if i == 4:
      self.log_error_message("Unable to Find Details for the Selected Batch")
      
  batch_name,date_time,batch_notes = self.get_batch_details()
  comp = VarToStr(app.Cells.item[2,1])
  j = 0
  while StrMatches(comp,batch_notes) != True:
#     batch_list.FindID(b_id).click()
     batch_list.Keys("[Down]")
     delay(2000)
     batch_name,date_time,batch_notes = self.get_batch_details()
     j = j + 1
     if j == 5:
       batch_list.FindID(b_id).click()
       batch_name,date_time,batch_notes = self.get_batch_details()
       if StrMatches(comp,batch_notes) != True:   
         self.log_error_message("Batch Not Created in WCI Capture for the email sent: Test Failed")
#  self.log_message_web("Batch Name: "+batch_name)
#  self.log_message_web("Batch Creation Date/Time: "+date_time)
  app.Cells.item[2,2]=VarToStr(batch_name)
  web_utils.log_checkpoint("Verified the Batch Details Successfully",500,self.page)
       
# Validate Document Profile and Release the Batch to WFR Form for Verification:
  batch_list.Keys("[Right][Right]")
  self.wait_until_page_loaded()
  Delay(3000)
  pro = ["JavaClassName","wText"]
  val = ["JComboBox","CAIAP Invoices"]
#  ImageViewer = Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).FindChild("JavaClassName","ImageViewer",40)
  ImageViewer = wcc_home_page.image_viewer()
  value = ImageViewer.VisibleOnScreen
  document_no = 1
#  if value == False:  
  while value == True:
      self.wait_until_page_loaded()
      Delay(2000)
      self.validate_doc_panel(document_no,app)
      delay(2000)
      batch_list.Keys("[Down]")
      Delay(7000)
      document_no = document_no+1
      value = ImageViewer.VisibleOnScreen

  if value == False:
      batch_list.Keys("[Down]")
      value = ImageViewer.VisibleOnScreen
      while value == True:
        delay(2000)
        self.validate_doc_panel(document_no,app)
        delay(2000)
        batch_list.Keys("[Down]")
        Delay(7000)
        document_no = document_no+1
        value = ImageViewer.VisibleOnScreen
      
  web_utils.log_checkpoint("Verified and Updated the Document Profile Details Successfully: Ready to Release",500,self.page)


    
#  self.log_message_web("Default Coder: "+VarToStr(combo_list[4].wText))
#  Sys.HighlightObject(combo_box)
#  web_utils.log_checkpoint("Verified the Document Profile Details Successfully: Ready to Release",500,self.page)
  batch_list.FindID(b_id).click() 
  Delay(1000)
  batch_list.FindID(b_id).click() 
  Delay(1000)
#  Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).FindChild("AWTComponentAccessibleName","Release",40).Click()
  wcc_home_page.release_link().Click()
  Delay(10000)
  self.refresh()
  web_utils.log_checkpoint("Click 'Release' button - Successfull for the batch: "+batch_name,500,self.page)
  self.validate_batch_release(app)
#  self.log_message_web("Click 'Release' button successful")


 def get_batch_details(self):
  batch_name = wcc_home_page.batch_name_textfield().wText
#  batch_name=Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).FindChild("AWTComponentAccessibleName","Batch Name:",40).wText
  self.log_message_web("Batch Name: "+VarToStr(batch_name))
  delay(1000)
#  book.Save()
  date_time = wcc_home_page.batch_date_time_created_textfield().wText
#  date_time=Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).FindChild("AWTComponentAccessibleName","Date/Time Created:",40).wText
  self.log_message_web("Date Time: "+VarToStr(date_time))
  delay(1000)
  batch_notes = wcc_home_page.batch_notes_textfield().wText
#  pro = ("JavaClassName","AWTComponentAccessibleName")
#  val = ("JTextArea","Batch Notes:")
#
#  batch_notes = Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).FindChild(pro,val,30).wText 
  self.log_message_web("Batch_Notes: "+VarToStr(batch_notes))
  return batch_name,date_time,batch_notes
  
 def refresh(self):
#   url_bar = Sys.Browser("iexplore").BrowserWindow(0).Window("WorkerW", "Navigation Bar", 1).Window("ReBarWindow32", "", 1).Window("Address Band Root", "Address Bar", 1).Window("AddressDisplay Control", "", 1)
#   url_bar.Click()
   delay(1200)
   wcc_home_page.url_bar().Keys("[F5]")
   self.page.wait_until_loaded()
#   if Sys.Browser("iexplore").Page(self.testConfig['ebiz']['webCenCapUrl']+"*").Alert.Exists:
#    Sys.Browser("iexplore").Page(self.testConfig['ebiz']['webCenCapUrl']+"*").Alert.Button("OK").Click()
   if wcc_login_page.login_alert_ref().Exists:
      wcc_login_page.login_alert_ref().Button("OK").Click()
   Delay(2000)
   self.wait_until_page_loaded()
#   if Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).Tab("WebCenter Capture - Internet Explorer").Window("Shell DocObject View", "", 1).Window("Internet Explorer_Server", "", 1).Window("Java Plug-in Control Window", "", 1).AWTObject("PluginEmbeddedFrame", "").SwingObject("RMCApplet", "", 0).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("FormManagerPanel", "", 0).SwingObject("JPanel", "", 0).SwingObject("ExistingSessionPanel", "", 0).SwingObject("RoundedCornerPanel", "", 0).Exists:
##    Sys.Browser("iexplore").Page("https://tmnh1oc.manheim.com/dc-client/faces/dc-client.jspx?_afrLoop=2464566809846782&_afrWindowMode=0&_adf.ctrl-state=5sj61sehx_4").Panel("d1").Form("appletForm").Panel(0).Panel("s").Panel(0).Panel("f").Panel(0).Applet("captureApp").AWTObject("PluginEmbeddedFrame", "").SwingObject("RMCApplet", "", 0).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("FormManagerPanel", "", 0).SwingObject("JPanel", "", 0).SwingObject("ExistingSessionPanel", "", 0).SwingObject("RoundedCornerPanel", "", 0) 
#     Sys.Browser("iexplore").BrowserWindow(0).Keys("[Enter]")
   round_panel = wcc_login_page.java_plugin_ok_button()
   if round_panel.Exists:
     Sys.Browser("iexplore").BrowserWindow(0).Keys("[Enter]")
     Delay(2000)
  # Check security warning window exists
   if wcc_login_page.security_window().Exists:
      wcc_login_page.security_window_checkbox().Click()
      wcc_login_page.security_window_enter().Keys("[Enter]")
#   security_wnd=Sys.Browser("iexplore").WaitSwingObject("JDialog", "Security Warning", -1, 1,10000)  
#   if security_wnd.Exists:
#     Sys.Browser("iexplore").SwingObject("JDialog", "Security Warning", -1, 1).FindChild("AWTComponentAccessibleName","I accept the risk and want to run this application.",30).Click()
#     Sys.Browser("iexplore").SwingObject("JDialog", "Security Warning", -1, 1).Keys("[Enter]")
   Delay(2000)
   self.wait_until_page_loaded()
#   if Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).Tab("WebCenter Capture - Internet Explorer").Window("Shell DocObject View", "", 1).Window("Internet Explorer_Server", "", 1).Window("Java Plug-in Control Window", "", 1).AWTObject("PluginEmbeddedFrame", "").SwingObject("RMCApplet", "", 0).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("FormManagerPanel", "", 0).SwingObject("JPanel", "", 0).SwingObject("ExistingSessionPanel", "", 0).SwingObject("RoundedCornerPanel", "", 0).Exists:
#      Sys.Browser("iexplore").BrowserWindow(0).Keys("[Enter]")
   if round_panel.Exists:
     Sys.Browser("iexplore").BrowserWindow(0).Keys("[Enter]")
     Delay(2000)
#   round_panel = wcc_login_page.java_plugin_ok_button()
#   if round_panel.Exists:
#     Sys.Browser("iexplore").BrowserWindow(0).Keys("[Enter]")
   self.page.wait_until_loaded()
   
 def validate_batch_release(self,app):
    
#    batch_list=self.page.FindChildEx("JavaClassName","BatchEditForm$30",30,True,90000)
    batch_list = wcc_home_page.batch_edit_form()
    b_id = batch_list.Id
    batch_list.FindID(b_id).click() 
    delay(2000)  
  # Get Batch Details and Validate for Required Batch:
#    batch_name=Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).FindChild("AWTComponentAccessibleName","Batch Name:",40)
    batch_name = wcc_home_page.batch_name_textfield()
    i = 0
    while batch_name.Exists == None: 
     batch_list.FindID(b_id).click()
     i = i + 1
     if i == 4:
      self.log_error_message("Unable to Validate the Release: Test Failed")
      
    batch_name,date_time,batch_notes = self.get_batch_details()
    if batch_name == VarToStr(app.Cells.item[2,2]):
       self.log_error_message("Unable to Verify the Release for Batch : "+VarToStr(app.Cells.item[2,2])+" Batch Record Still Present - Test Failed")
    web_utils.log_checkpoint("Able to Verify the Release for :"+VarToStr(app.Cells.item[2,2])+" - Batch Record Removed from the Page",500,self.page)
    
 def validate_doc_panel(self,document_no,app):
    delay(11000)
#    cnt=Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).FindAllChildren("JavaClassName","JSplitPane",60)
#    combo_list=cnt[1].FindAllChildren("AWTComponentName","ComboBox.textField",40)
    combo_list = wcc_home_page.combo_list_table()
#    self.log_message_web("Invoice Category: "+VarToStr(combo_list[4].wText))
#    ImageViewer = Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).FindChild("JavaClassName","ImageViewer",40)
    ImageViewer = wcc_home_page.image_viewer()
    Sys.HighlightObject(ImageViewer)
    wcc_home_page.default_coder_field().Keys(app.Cells.item[2,7])
    wcc_home_page.invoice_category_field().Keys(app.Cells.item[2,10])
    Delay(1000)
    wcc_home_page.print_local_field().Keys(app.Cells.item[2,8])
    Delay(1000)
    wcc_home_page.advance_charge_field().Keys(app.Cells.item[2,9])
#    combo_list[5].Keys("PBurugupal")
#    combo_list[4].Keys("SPL")
#    delay(2000)
#    combo_list[2].Keys("Yes")
#    Delay(1000)
#    combo_list[3].Keys("No")
    web_utils.log_checkpoint("Verified the Document Profile Details Successfully for document no - "+IntToStr(document_no)+": Ready to Release",500,self.page)
     
     
def test():

  if Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).Tab("WebCenter Capture - Internet Explorer").Window("Shell DocObject View", "", 1).Window("Internet Explorer_Server", "", 1).Window("Java Plug-in Control Window", "", 1).AWTObject("PluginEmbeddedFrame", "").SwingObject("RMCApplet", "", 0).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("FormManagerPanel", "", 0).SwingObject("JPanel", "", 0).SwingObject("ExistingSessionPanel", "", 0).SwingObject("RoundedCornerPanel", "", 0).Exists:
    Sys.Browser("iexplore").BrowserWindow(0).Keys("[Enter]")








