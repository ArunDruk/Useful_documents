﻿import gvar

### In this method objects for below pages have been captured ###

#RESOURCES > SCHEDULED PEOPLE page

def scheduled_people_page_link():
  prop_names = ["contentText","ObjectIdentifier","ObjectType"]
  prop_values = ["Scheduled People","PA_TEAM","Link"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def scheduled_people_viewlist_radiobutton():
  prop_names = ["idStr","ObjectLabel","ObjectType"]
  prop_values = ["ViewList","List","RadioButton"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def scheduled_people_viewtimeline_radiobutton():
  prop_names = ["idStr","ObjectLabel","ObjectType"]
  prop_values = ["ViewTimeline","Timeline","RadioButton"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def scheduled_people_displaygo_button():
  prop_names = ["contentText","ObjectType"]
  prop_values = ["Go","Button"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def scheduled_people_savedsrch_dropdown():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["customizationsPoplist","Select"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def scheduled_people_personalize_button():
  prop_names = ["contentText","ObjectType"]
  prop_values = ["Personalize","Button"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
  

def scheduled_people_actions_dropdown():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["TeamListActionsPopList1","Select"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def sched_ppl_updateschedulepeople_button():
  prop_names = ["contentText","ObjectType"]
  prop_values = ["Update Scheduled People","Button"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def sched_ppl_simplesearch_button():
  prop_names = ["contentText","ObjectType"]
  prop_values = ["Simple Search","Button"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def sched_ppl_advsearch_button():
  prop_names = ["contentText","ObjectType"]
  prop_values = ["Advanced Search","Button"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
  

def sched_ppl_savedsearch_button():
  prop_names = ["contentText","ObjectType"]
  prop_values = ["Saved Searches","Button"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def simplesearch_startdate_textfeild():
  prop_names = ["contentText","ObjectType"]
  prop_values = ["TeamStartDate","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def simplesearch_enddate_textfeild():
  prop_names = ["contentText","ObjectType"]
  prop_values = ["TeamEndDate","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def simplesearch_schedulestatus_textfeild():
  prop_names = ["contentText","ObjectType"]
  prop_values = ["TeamStatus","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
  

def simplesearch_apprvstatus_textfeild():
  prop_names = ["contentText","ObjectType"]
  prop_values = ["ApprvlStatus","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def simplesearch_go_button():
  prop_names = ["contentText","ObjectType"]
  prop_values = ["Go","Button"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def simplesearch_clear_button():
  prop_names = ["contentText","ObjectType"]
  prop_values = ["Clear","Button"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def actions_dropdown():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["TeamListActionsPopList1","Select"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def actions_go_button():
  prop_names = ["contentText","ObjectType","idStr"]
  prop_values = ["Go","Button","ActionsBtn1"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def actions_checkbox():
  prop_names = ["idStr","ObjectIdentifier","ObjectType"]
  prop_values = ["N3:triState","triState","Checkbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

