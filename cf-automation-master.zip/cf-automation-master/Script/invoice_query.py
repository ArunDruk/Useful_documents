﻿import database_service
import gvar
import tc_logs

def add_group_code_filter_inv():
    if gvar.dataprep['p_group_code']:  
        gc_inv_query = """ ,((SELECT /*+ no_expand */ RAC.trx_number,RAC.Bill_to_customer_id,RAC.bill_to_site_use_id,RAC.attribute_category,RAC.attribute13,
                       RAC.attribute2,RAC.attribute10,RAC.sold_to_customer_id,RAC.trx_date,RAC.attribute8,RAC.customer_trx_id,
                       RAC.ship_to_customer_id,RAC.org_id,RAC.ship_to_site_use_id,RAC.batch_source_id,RAC.remit_to_address_id,
                       RAC.primary_salesrep_id,RAC.cust_trx_type_id
                       FROM HZ_CUST_ACCOUNTS_ALL HCA,ra_customer_trx_all RAC
                       WHERE HCA.account_number = RAC.attribute10 
                       AND hca.attribute15 = '%s'  
                       AND RAC.attribute10 IS NOT NULL
                       )
                       UNION ( SELECT /*+ no_expand */ RAC.trx_number,RAC.Bill_to_customer_id,RAC.bill_to_site_use_id,RAC.attribute_category,RAC.attribute13,
                       RAC.attribute2,RAC.attribute10,RAC.sold_to_customer_id,RAC.trx_date,RAC.attribute8,RAC.customer_trx_id,
                       RAC.ship_to_customer_id,RAC.org_id,RAC.ship_to_site_use_id,RAC.batch_source_id,RAC.remit_to_address_id,
                       RAC.primary_salesrep_id,RAC.cust_trx_type_id 
                       FROM HZ_CUST_ACCOUNTS_ALL hca,ra_customer_trx_all RAC 
                       WHERE hca.cust_account_id = (RAC.sold_to_customer_id)  --4.8  Defect# 9071  Unable to see Invoice template in CSA/CP 
                       AND hca.attribute15 = '%s'  
                       )
                       UNION ( SELECT /*+ no_expand */ RAC.trx_number,RAC.Bill_to_customer_id,RAC.bill_to_site_use_id,RAC.attribute_category,RAC.attribute13,
                       RAC.attribute2,RAC.attribute10,RAC.sold_to_customer_id,RAC.trx_date,RAC.attribute8,RAC.customer_trx_id,
                       RAC.ship_to_customer_id,RAC.org_id,RAC.ship_to_site_use_id,RAC.batch_source_id,RAC.remit_to_address_id,
                       RAC.primary_salesrep_id,RAC.cust_trx_type_id
                       FROM HZ_CUST_ACCOUNTS_ALL hca,ra_customer_trx_all RAC 
                       WHERE hca.cust_account_id = (RAC.bill_to_customer_id)   
                       AND hca.attribute15 = '%s'  
                       ))RAC"""
        gc_inv_query = aqString.Format(gc_inv_query,gvar.dataprep['p_group_code'],gvar.dataprep['p_group_code'],gvar.dataprep['p_group_code'])
    else:
        gc_inv_query = ''
    return gc_inv_query
  
def add_group_code_filter_ord():
    if gvar.dataprep['p_group_code']:  
        gc_ord_query = """ ,((SELECT /*+ no_expand */ OE.header_id,OE.order_number,OE.invoice_to_org_id,OE.context,OE.sold_to_org_id,OE.attribute2,OE.attribute10,
                       OE.attribute8,OE.ship_to_org_id,OE.order_type_id,OE.ordered_date,OE.flow_status_code, OE.salesrep_id,OE.org_id
                       FROM hz_cust_accounts_all hca, oe_order_headers_all OE
                       WHERE hca.attribute15 = '%s'
                       AND OE.sold_to_org_id = hca.cust_account_id)
                       UNION
                       (SELECT /*+ no_expand */ OE.header_id,OE.order_number,OE.invoice_to_org_id,OE.context,OE.sold_to_org_id,OE.attribute2,OE.attribute10,
                       OE.attribute8,OE.ship_to_org_id,OE.order_type_id,OE.ordered_date,OE.flow_status_code, OE.salesrep_id,OE.org_id
                       FROM hz_cust_accounts_all hca
                       , hz_cust_acct_sites_all hcasa
                       , hz_cust_site_uses_all hcsu
                       , oe_order_headers_all OE
                       WHERE hca.attribute15 = '%s'
                       AND hca.cust_account_id     = hcasa.cust_account_id
                       AND hcasa.cust_acct_site_id = hcsu.cust_acct_site_id
                       AND hcsu.site_use_code    = ''BILL_TO''
                       AND oe.invoice_to_org_id  = hcsu.site_use_id)
                       UNION
                       (SELECT /*+ no_expand */ OE.header_id,OE.order_number,OE.invoice_to_org_id,OE.context,OE.sold_to_org_id,OE.attribute2,OE.attribute10,
                       OE.attribute8,OE.ship_to_org_id,OE.order_type_id,OE.ordered_date,OE.flow_status_code, OE.salesrep_id,OE.org_id
                       FROM HZ_CUST_ACCOUNTS_ALL HCA, oe_order_headers_all OE
                       WHERE HCA.account_number = OE.attribute10 AND OE.attribute10 IS NOT NULL
                       AND hca.attribute15 = '%s')
                       ) OE'"""
        gc_ord_query = aqString.Format(gc_ord_query,gvar.dataprep['p_group_code'],gvar.dataprep['p_group_code'],gvar.dataprep['p_group_code'])
    else:
        gc_ord_query = ''
    return gc_ord_query

  
def add_dealer_filter_inv():
    if gvar.dataprep['p_dealer']:
        d_inv_query = """ ,(( SELECT /*+ no_expand */ RAC.trx_number,RAC.Bill_to_customer_id,RAC.bill_to_site_use_id,RAC.attribute_category,RAC.attribute13,
                      RAC.attribute2,RAC.attribute10,RAC.sold_to_customer_id,RAC.trx_date,RAC.attribute8,RAC.customer_trx_id,
                      RAC.ship_to_customer_id,RAC.org_id,RAC.ship_to_site_use_id,RAC.batch_source_id,RAC.remit_to_address_id,
                      RAC.primary_salesrep_id,RAC.cust_trx_type_id
                      FROM HZ_CUST_ACCOUNTS_ALL HCA,ra_customer_trx_all RAC
                      WHERE HCA.account_number = RAC.attribute10 
                      AND hca.account_number = '%s'
                      AND RAC.attribute10 IS NOT NULL
                      )
                       UNION ( SELECT /*+ no_expand */ RAC.trx_number,RAC.Bill_to_customer_id,RAC.bill_to_site_use_id,RAC.attribute_category,RAC.attribute13,
                      RAC.attribute2,RAC.attribute10,RAC.sold_to_customer_id,RAC.trx_date,RAC.attribute8,RAC.customer_trx_id,
                      RAC.ship_to_customer_id,RAC.org_id,RAC.ship_to_site_use_id,RAC.batch_source_id,RAC.remit_to_address_id,
                      RAC.primary_salesrep_id,RAC.cust_trx_type_id 
                      FROM HZ_CUST_ACCOUNTS_ALL hca,ra_customer_trx_all RAC 
                      WHERE hca.cust_account_id = (RAC.sold_to_customer_id)  
                      AND hca.account_number = '%s'
                      )
                      UNION ( SELECT /*+ no_expand */ RAC.trx_number,RAC.Bill_to_customer_id,RAC.bill_to_site_use_id,RAC.attribute_category,RAC.attribute13,
                      RAC.attribute2,RAC.attribute10,RAC.sold_to_customer_id,RAC.trx_date,RAC.attribute8,RAC.customer_trx_id,
                      RAC.ship_to_customer_id,RAC.org_id,RAC.ship_to_site_use_id,RAC.batch_source_id,RAC.remit_to_address_id,
                      RAC.primary_salesrep_id,RAC.cust_trx_type_id
                      FROM HZ_CUST_ACCOUNTS_ALL hca,ra_customer_trx_all RAC 
                      WHERE hca.cust_account_id = (RAC.bill_to_customer_id)  
                      AND hca.account_number = '%s'
                      ))RAC"""
        d_inv_query = aqString.Format(d_inv_query,gvar.dataprep['p_dealer'],gvar.dataprep['p_dealer'],gvar.dataprep['p_dealer'])
    else:
        d_inv_query = ''
    return d_inv_query
 
def add_dealer_filter_ord():
    if gvar.dataprep['p_dealer']:
        d_ord_query = """ ,((SELECT /*+ no_expand */ OE.header_id,OE.order_number,OE.invoice_to_org_id,OE.context,OE.sold_to_org_id,OE.attribute2,OE.attribute10,
				              OE.attribute8,OE.ship_to_org_id,OE.order_type_id,OE.ordered_date,OE.flow_status_code,OE.salesrep_id,OE.org_id
					            FROM hz_cust_accounts_all hca, oe_order_headers_all OE
					            WHERE hca.account_number = '%s'
					            AND OE.sold_to_org_id = hca.cust_account_id)
                      UNION ( SELECT /*+ no_expand */ OE.header_id,OE.order_number,OE.invoice_to_org_id,OE.context,OE.sold_to_org_id,OE.attribute2,OE.attribute10,
                      OE.attribute8,OE.ship_to_org_id,OE.order_type_id,OE.ordered_date,OE.flow_status_code, OE.salesrep_id,OE.org_id
                      FROM hz_cust_accounts_all hca
                      , hz_cust_acct_sites_all hcasa
                      , hz_cust_site_uses_all hcsu
                      , oe_order_headers_all OE
                      WHERE hca.account_number = '%s'
                      AND hca.cust_account_id     = hcasa.cust_account_id
                      AND hcasa.cust_acct_site_id = hcsu.cust_acct_site_id
                      AND hcsu.site_use_code    = 'BILL_TO'
                      AND oe.invoice_to_org_id  = hcsu.site_use_id)
                      UNION ( SELECT /*+ no_expand */ OE.header_id,OE.order_number,OE.invoice_to_org_id,OE.context,OE.sold_to_org_id,OE.attribute2,OE.attribute10,
                      OE.attribute8,OE.ship_to_org_id,OE.order_type_id,OE.ordered_date,OE.flow_status_code, OE.salesrep_id,OE.org_id
                      FROM HZ_CUST_ACCOUNTS_ALL HCA, oe_order_headers_all OE
                      WHERE HCA.account_number = OE.attribute10 AND OE.attribute10 IS NOT NULL
                      AND hca.account_number = '%s')
                      ) OE"""
        d_ord_query = aqString.Format(d_ord_query,gvar.dataprep['p_dealer'],gvar.dataprep['p_dealer'],gvar.dataprep['p_dealer'])
    else:
        d_ord_query = ''
    return d_ord_query
   
def add_date_range_filter_inv():
    dr_inv_query = """AND TRUNC (RAC.trx_date) BETWEEN TO_DATE('%s','YYYY/MM/DD') AND TO_DATE('%s','YYYY/MM/DD')""" 
    dr_inv_query = aqString.Format(dr_inv_query,gvar.dataprep['p_inv_low_date'],gvar.dataprep['p_inv_high_date'])
    return dr_inv_query
    
def add_date_range_filter_ord():
    dr_ord_query = """AND TRUNC (OE.ordered_date) BETWEEN TO_DATE('%s','YYYY/MM/DD') AND TO_DATE('%s','YYYY/MM/DD')"""
    dr_ord_query = aqString.Format(dr_ord_query,gvar.dataprep['p_inv_low_date'],gvar.dataprep['p_inv_high_date'])
    return dr_ord_query


def base_start_query_inv():
    base_start_query_inv = """SELECT DISTINCT 
                          INV_DETAIL.header_id,
                          INV_DETAIL.trx_type, 
                          INV_DETAIL.trx_number trx_number,
                          INV_DETAIL.payee_number,
                          INV_DETAIL.payee_name,
                          INV_DETAIL.owner_number,
                          INV_DETAIL.owner,
                          INV_DETAIL.buyer_number,
                          INV_DETAIL.buyer,
                          INV_DETAIL.remarketer_number,
                          INV_DETAIL.remarketer,
                          INV_DETAIL.remit_to,
                          INV_DETAIL.inv_type,
                          INV_DETAIL.buyer_rep,
                          INV_DETAIL.trx_location,    
                          INV_DETAIL.lease_acc_no,
                          INV_DETAIL.vin,
                          INV_DETAIL.off_vlocation,
                          INV_DETAIL.work_order,
                          INV_DETAIL.universal_key,
                          INV_DETAIL.sale_year,
                          INV_DETAIL.sale_week,
                          INV_DETAIL.sale_lane,
                          INV_DETAIL.sale_run ,
                          INV_DETAIL.balance,
                          INV_DETAIL.auction_location
                          FROM (
                          (SELECT /*+ push_pred(TAX) */ RCTL.customer_trx_line_id trx_line_id,
                            0 header_id,
                            DECODE (RACT.TYPE, 'CM', 'Credit Memo', 'INV', 'Invoice', RACT.TYPE) trx_type,
                            TO_CHAR (RAC.trx_number) trx_number,
                            hz1.account_number payee_number,
                            HZ1.account_name  payee_name, 
                            DECODE(RAC.ATTRIBUTE_CATEGORY,'US VEHICLE SERVICES', HZ2.account_number,
                            CASE 
                                WHEN MOC1.owner_acct_id != DECODE(RAC.attribute_category,'US SELLER',MOC1.payee_acct_id,RAC.bill_to_customer_id)
                                THEN HZ5.account_number 
                                ELSE NULL
                            END) owner_number,                                              
                            DECODE(RAC.ATTRIBUTE_CATEGORY,'US VEHICLE SERVICES', HZ2.account_name,
                            CASE 
                                WHEN MOC1.owner_acct_id != DECODE(RAC.attribute_category,'US SELLER',MOC1.payee_acct_id,RAC.bill_to_customer_id)
                                THEN HZ5.account_name 
                                ELSE NULL
                            END) OWNER,
                            HZ3.account_number buyer_number,
                            HZ3.account_name buyer,
                            DECODE( RAC.ATTRIBUTE_CATEGORY, 'Floorplan Invoice','','US BUYER','', 'US VEHICLE SERVICES','', HZ4.account_number) remarketer_number,
                            DECODE( RAC.ATTRIBUTE_CATEGORY, 'Floorplan Invoice','','US BUYER','', 'US VEHICLE SERVICES','', HZ4.account_name) remarketer,
                            ( DECODE (RAA_REMIT_LOC.address1, NULL, NULL, RAA_REMIT_LOC.address1)
                            || DECODE (RAA_REMIT_LOC.address2, NULL, NULL, CHR(10)|| RAA_REMIT_LOC.address2)
                            || DECODE(RAA_REMIT_LOC.address3, NULL,'', CHR(10) || RAA_REMIT_LOC.address3)  
                            || DECODE(RAA_REMIT_LOC.address4, NULL,'',' '|| RAA_REMIT_LOC.address4)
                            || DECODE (RAA_REMIT_LOC.city, NULL, NULL, CHR (10)|| RAA_REMIT_LOC.city)
                            || DECODE (RAA_REMIT_LOC.STATE, NULL, NULL, ','||' '|| RAA_REMIT_LOC.STATE)
                            || DECODE (RAA_REMIT_LOC.postal_code, NULL, NULL, ' '||RAA_REMIT_LOC.postal_code)
                            || DECODE (RAA_REMIT_LOC.country, NULL, NULL,' '|| RAA_REMIT_LOC.country) ) remit_to,
                            RACT.attribute1 inv_type,
                            DECODE (RACT.TYPE, 
                                         'CM', (SELECT DISTINCT acv.last_name || ', ' || acv.first_name
                                  FROM ar_contacts_v            acv,
                                       oe_order_headers_all     H,
                                       oe_transaction_types_tl  ottl
                                 WHERE     h.attribute2 = TO_CHAR (RAC.attribute2)
                                       AND h.cancelled_flag = 'N'
                                       AND ottl.NAME <> 'US SELLER'
                                       AND ottl.LANGUAGE = USERENV ('LANG')
                                       AND ottl.transaction_type_id = h.order_type_id
                                       AND acv.contact_id = h.sold_to_contact_id),
                                         'INV', (SELECT DISTINCT acv.last_name || ', ' || acv.first_name
                                  FROM ar_contacts_v            acv,
                                       oe_order_headers_all     H,
                                       oe_transaction_types_tl  ottl
                                 WHERE     h.attribute2 = TO_CHAR (RAC.attribute2)
                                       AND h.cancelled_flag = 'N'
                                       AND ottl.NAME <> 'US SELLER'
                                       AND ottl.LANGUAGE = USERENV ('LANG')
                                       AND ottl.transaction_type_id = h.order_type_id
                                       AND acv.contact_id = h.invoice_to_contact_id),'')  buyer_rep,
                            JRD.attribute6 trx_location,  
                            DECODE( RAC.ATTRIBUTE_CATEGORY, 'Floorplan Invoice','',
                                                            'US SELLER',NVL (RAC.attribute8, ''),
                                                            'US VEHICLE SERVICES',NVL (RAC.attribute8, ''),
                                                            (SELECT MAX(RAC1.attribute8)
                                                               FROM ra_customer_trx_all RAC1
                                                              WHERE RAC1.attribute2 = RAC.attribute2
                                                                AND (RAC1.ATTRIBUTE_CATEGORY = 'US SELLER' OR RAC1.ATTRIBUTE_CATEGORY = 'US NG SELLER'))
                                    ) lease_acc_no, 
                            MOC1.vin vin,
                            (SELECT HL.address1
                              || DECODE (HL.address2, NULL, '',' '
                              || HL.address2)
                             || DECODE (HL.city, NULL, '',' '
                              || HL.city)
                              || DECODE (HL.state, NULL, '',' '
                              || HL.state)
                              || DECODE (HL.postal_code, NULL, '', ' '
                              || HL.postal_code)
                              || DECODE ( HL.country, NULL, '', ' '
                              || HL.country)
                            FROM hz_locations HL,
                              ra_customer_trx_lines_all RACTl
                            WHERE HL.location_id          = TO_NUMBER (RACTl.attribute11)
                            AND RAC.customer_trx_id       = RACTl.customer_trx_id
                            AND RACTl.attribute_category IN ('US VEH SALE', 'US VEH BUY')
                            ) off_vlocation,
                                       RCTL.attribute1 work_order,
                            (MOC1.sale_year
                            || DECODE( MOC1.sale_week, NULL, '', '-')
                            || MOC1.sale_week
                            || DECODE( MOC1.sale_lane, NULL, '', '-')
                            || MOC1.sale_lane
                            || DECODE( MOC1.sale_run, NULL, '', '-')
                            || MOC1.sale_run ) universal_key,
                            TO_NUMBER(MOC1.sale_year)  sale_year, 
                            TO_NUMBER(MOC1.sale_week)  sale_week, 
                            TO_NUMBER(MOC1.sale_lane)  sale_lane, 
                            TO_NUMBER(MOC1.sale_run)   sale_run,
                            DECODE(RCTL.attribute_category ,'US VEH SALE',1, 'US VEH BUY',1,99) temp_line_no ,
                            NVL(ARP.amount_due_remaining, 0) balance,
                            JRD.attribute1  auction_location
                          FROM ra_customer_trx_lines_all RCTL,
                            (SELECT SUM(ZL.tax_amt) tax_amt,
                              RCTL1.link_to_cust_trx_line_id
                            FROM zx_lines ZL,
                              ra_customer_trx_lines_all RCTL1
                            WHERE 1=1 
                            AND ZL.tax_line_id = RCTL1.tax_line_id
                            AND ZL.trx_id      = RCTL1.customer_trx_id
                            GROUP BY RCTL1.link_to_cust_trx_line_id
                            ) TAX,
                            hz_cust_accounts_all HZ1, 
                            hz_cust_accounts_all HZ2, 
                            hz_cust_accounts_all HZ3,
                            hz_cust_accounts_all HZ4,
                                       hz_cust_accounts_all HZ5,
                            ar_payment_schedules_all ARP,
                            ra_cust_trx_types_all RACT,
                            ra_batch_sources_all ABSA,
                            apps.man_om_consignments MOC1,
                            hz_cust_acct_sites_all ACCT_SITE,
                            hz_party_sites HZPS,
                            hz_cust_accounts_all HZC1,
                            hz_locations HZL,
                            hz_cust_site_uses_all HZCSA,
                            hz_cust_acct_sites_all RAA_REMIT,
                            hz_party_sites RAA_REMIT_PS,
                            hz_locations RAA_REMIT_LOC,
                            jtf_rs_salesreps JRS,
                            jtf_rs_defresources_v JRD"""
    tc_logs.msg_with_no_picture(base_start_query_inv,'')
    return base_start_query_inv
  
def base_end_query_inv():
    base_end_query_inv = """ WHERE RCTL.customer_trx_id = RAC.customer_trx_id
                          AND HZ1.cust_account_id             = RAC.Bill_to_customer_id 
                          AND HZ2.cust_account_id(+)          = RAC.sold_to_customer_id 
                          AND HZ3.cust_account_id(+)          = MOC1.buyer_account_id 
                          AND HZ4.account_number(+)           = RAC.attribute10  
                          AND HZ5.cust_account_id(+)          =       MOC1.owner_acct_id
                          AND RAC.ship_to_site_use_id         = HZCSA.site_use_id(+)
                          AND HZL.location_id(+)              = HZPS.location_id
                          AND HZPS.party_site_id(+)           = ACCT_SITE.party_site_id
                          AND ACCT_SITE.cust_account_id       = HZC1.cust_account_id(+)
                          AND HZCSA.cust_acct_site_id         = ACCT_SITE.cust_acct_site_id(+)
                          AND RAC.cust_trx_type_id            = RACT.cust_trx_type_id
                          AND RAC.org_id                      = RACT.org_id
                          AND moc1.consignment_id(+) = RAC.attribute2                
                          AND TAX.link_to_cust_trx_line_id(+) = RCTL.customer_trx_line_id
                          AND JRS.salesrep_id(+)              = RAC.primary_salesrep_id
                          AND JRD.resource_id(+)              = JRS.resource_id
                          AND RCTL.customer_trx_id            = ARP.customer_trx_id(+)
                          AND RAC.remit_to_address_id         = RAA_REMIT.cust_acct_site_id(+)
                          AND RAA_REMIT.party_site_id         = RAA_REMIT_PS.party_site_id(+)
                          AND RAA_REMIT_LOC.location_id(+)    = RAA_REMIT_PS.location_id
                          AND RCTL.description               IS NOT NULL
                          AND RAC.batch_source_id             = ABSA.batch_source_id
                          AND ABSA.org_id                     = RAC.org_id
                          AND ABSA.batch_source_id            = NVL('%s', ABSA.batch_source_id)
                          AND RAC.trx_number BETWEEN NVL ('%s', RAC.trx_number) AND NVL ('%s', RAC.trx_number)"""
    base_end_query_inv = aqString.Format(base_end_query_inv,gvar.dataprep['p_trx_src'],gvar.dataprep['p_inv_num_low'],gvar.dataprep['p_inv_num_high'])
    tc_logs.msg_with_no_picture(base_end_query_inv,'')
    return base_end_query_inv

def base_start_query_ord():
    base_start_query_ord = """ UNION ALL
                          (SELECT
                            OEL.line_id trx_line_id,
                            oe.header_id header_id,
                            OETT.attribute4 trx_type,
                            TO_CHAR (OE.order_number) trx_number,
                            HCA1.account_number payee_number,
                            HCA1.account_name payee_name,  
                            DECODE(OE.context,'US VEHICLE SERVICES', HCA2.account_number,
                                 CASE WHEN MOC.owner_acct_id != DECODE(OE.context,'US SELLER',MOC.payee_acct_id, 'US NG SELLER',HZC.cust_account_id,OE.sold_to_org_id)
                                    THEN HCA5.account_number ELSE NULL
                            END) OWNER_number,     
                            DECODE(OE.context,'US VEHICLE SERVICES', HCA2.account_name,
                                 CASE WHEN MOC.owner_acct_id != DECODE(OE.context,'US SELLER',MOC.payee_acct_id, 'US NG SELLER',HZC.cust_account_id,OE.sold_to_org_id)
                                    THEN HCA5.account_name ELSE NULL
                            END) OWNER, 
                            DECODE(OE.context, 'US SELLER', HCA3.account_number, 'US NG SELLER', HCA3.account_number, 'US VEHICLE SERVICES', NULL, HCA3.account_number) buyer_number,
                            DECODE(OE.context, 'US SELLER', HCA3.account_name, 'US NG SELLER', HCA3.account_name, 'US VEHICLE SERVICES', NULL, HCA3.account_name) buyer,
                            DECODE (OE.context,'US VEHICLE SERVICES','', 'US BUYER','',HCA4.account_number)  remarketer_number, 
                            DECODE (OE.context,'US VEHICLE SERVICES','', 'US BUYER','',HCA4.account_name)  remarketer, 
                            'Manheim'
                                       || CHR(10)
                                       ||'Accounts Receivable'
                            || CHR(10)
                            || 'PO Box 105511'
                            || CHR(10)
                            ||'Atlanta, GA 30348 US' remit_to,
                            OETT.attribute4 inv_type,
                           (           
                            SELECT
                              ACV.last_name
                              || ', '
                              || ACV.first_name
                            FROM
                              ar_contacts_v ACV
                            , oe_order_headers_all OOHA1
                            WHERE
                              ACV.contact_id     = OOHA1.invoice_to_contact_id
                            AND OOHA1.attribute2 = OE.attribute2
                            AND OOHA1.context    = 'US BUYER'
                            AND OOHA1.cancelled_flag = 'N'
                            AND OOHA1.header_id = OE.header_id
                            ) buyer_rep,
                            JRD.attribute6 trx_location,    
                            NVL (OE.attribute8, '') lease_acc_no,
                            MOC.vin vin,
                            (SELECT HL.address1
                              || DECODE (HL.address2, NULL, '', ' '
                              || HL.address2)
                              || DECODE (HL.city, NULL, '', ' '
                              || HL.city)
                              || DECODE (HL.state, NULL, '', ' '
                              || HL.state)
                              || DECODE (HL.postal_code, NULL, '', ' '
                              || HL.postal_code)
                              || DECODE ( HL.country, NULL, '', ' '
                              || HL.country)
                            FROM hz_locations HL,
                              OE_transaction_types_tl OTTT,
                              OE_transaction_types_all OTTA,
                              OE_order_lines_all OELX
                            WHERE HL.location_id         = OELX.attribute11
                            AND OEL.header_id            = OELX.header_id
                            AND OELX.context             = OTTT.name
                            AND OTTT.transaction_type_id = OTTA.transaction_type_id
                            AND OTTA.attribute2          = 'SALE'
                            AND OTTT.language            = USERENV ('LANG')
                            ) off_vlocation,
                                       OEL.attribute1 work_order,
                            (MOC.sale_year
                            || DECODE( MOC.sale_week, NULL, '', '-')
                            || MOC.sale_week
                            || DECODE( MOC.sale_lane, NULL, '', '-')
                            || MOC.sale_lane
                            || DECODE( MOC.sale_run, NULL, '', '-')
                            || MOC.sale_run ) universal_key,
                            TO_NUMBER(MOC.sale_year)  sale_year, 
                            TO_NUMBER(MOC.sale_week)  sale_week, 
                            TO_NUMBER(MOC.sale_lane)  sale_lane, 
                            TO_NUMBER(MOC.sale_run)   sale_run ,
                            DECODE( (SELECT MTl.item_type 
                                      FROM mtl_system_items_b MTL 
                                      WHERE MTL.inventory_item_id = OEL.inventory_item_id 
                                      AND MTL.item_type = 'MAN_OFFERING' 
                                      AND MTL.inventory_item_id     = OEL.inventory_item_id
                                      AND MTL.organization_id       = OEL.ship_from_org_id), 'MAN_OFFERING', 1, 99) temp_line_no ,
                            0 balance,
                            JRD.attribute1  auction_location
                          FROM 
                            hz_cust_acct_sites_all HCAS1,
                            hz_cust_site_uses_all HCUA1,
                            hz_cust_accounts_all HCA1,
                            hz_cust_accounts_all HCA2,
                            hz_cust_accounts_all HCA3,
                            hz_cust_accounts_all HCA4,
                            hz_cust_accounts_all HCA5,
                            oe_order_lines_all OEL,
                            apps.man_om_consignments MOC,
                            oe_transaction_types_all OETT,
                            hz_parties HZP,
                            hz_cust_accounts_all HZC,
                            hz_locations HZL,
                            hz_cust_site_uses_all HZCSA,
                            hz_cust_ACCT_SITEs_all ACCT_SITE,
                            hz_party_sites HZPS,
                            hz_cust_ACCT_SITEs_all ACCT_SITE1,
                            hz_party_sites HZPS1,
                            hz_parties HZP1,
                            hz_cust_accounts_all HZC1,
                            hz_locations HZL1,
                            hz_cust_site_uses_all HZCSA1,
                            jtf_rs_salesreps JRS,
                            jtf_rs_defresources_v JRD"""
    tc_logs.msg_with_no_picture(base_start_query_ord,'')
    return base_start_query_ord
  
def base_end_query_ord():
    base_end_query_ord = """ WHERE hcas1.cust_acct_site_id = hcua1.cust_acct_site_id 
                          AND HCA1.cust_account_id =HCAS1.cust_account_id 
                          AND hcua1.site_use_id(+)=OE.INVOICE_TO_ORG_ID 
                          AND HCA2.cust_Account_id(+) = OE.SOLD_TO_ORG_ID 
                          AND HCA5.cust_account_id(+) = MOC.owner_acct_id
                          AND HCA4.account_number(+) = OE.attribute10 
                          AND HCA3.cust_account_id = (SELECT MAX(OOHA1.sold_to_org_id)
                                                        FROM oe_order_headers_all OOHA1
                                                       WHERE OOHA1.attribute2 = OE.attribute2
                                                         AND OOHA1.context = 'US BUYER'
                                                         AND OOHA1.flow_status_code <> 'CANCELLED') 
                          AND OEL.header_id            = OE.header_id
                          AND OEL.org_id               = OE.org_id
                          AND moc.consignment_id(+) = OE.attribute2     
                          AND OETT.transaction_type_id = OE.order_type_id
                          AND HZP.party_id              = HZC.party_id
                          AND OE.invoice_to_org_id      = HZCSA.site_use_id
                          AND HZL.location_id           = HZPS.location_id
                          AND HZPS.party_site_id        = ACCT_SITE.party_site_id
                          AND ACCT_SITE.cust_account_id = HZC.cust_account_id
                          AND HZCSA.cust_acct_site_id   = ACCT_SITE.cust_acct_site_id
                          AND HZP1.party_id              = HZC1.party_id
                          AND OE.ship_to_org_id          = HZCSA1.site_use_id
                          AND HZL1.location_id           = HZPS1.location_id
                          AND HZPS1.party_site_id        = ACCT_SITE1.party_site_id
                          AND ACCT_SITE1.cust_account_id = HZC1.cust_account_id
                          AND HZCSA1.cust_acct_site_id   = ACCT_SITE1.cust_acct_site_id
                          AND JRS.salesrep_id(+)   = OE.salesrep_id
                          AND JRD.resource_id(+)   = JRS.resource_id
                          AND OE.flow_status_code <> 'CANCELLED' 
                          AND NOT EXISTS
                            (SELECT /*+ push_subq no_unnest */ 1
                            FROM ra_customer_trx_lines_all RAL,
                              ra_customer_trx_all RCTA
                            WHERE RCTA.org_id             = OE.org_id
                            AND RCTA.sold_to_customer_id  = OE.sold_to_org_id
                            AND RCTA.customer_trx_id      = RAL.customer_trx_id
                            AND RAL.line_type             = 'LINE'
                            AND TO_CHAR (OE.order_number) = RCTA.interface_header_attribute1
                            AND OEL.line_id               = RAL.interface_line_attribute6
                            )
                            AND EXISTS
                              (
                                SELECT
                                  1
                                FROM
                                  mtl_system_items_b MTL
                                WHERE
                                  MTL.invoiceable_item_flag   = 'Y'
                                AND MTL.invoice_enabled_flag = 'Y'
                                AND MTL.inventory_item_id    = OEL.inventory_item_id
                                AND MTL.organization_id      = OEL.ship_from_org_id
                              )
                          AND OETT.invoice_source_id     = NVL('%s', OETT.invoice_source_id)
                          AND OE.order_number BETWEEN NVL ('%s', OE.order_number) AND NVL ('%s', OE.order_number)"""
    base_end_query_ord = aqString.Format(base_end_query_ord,gvar.dataprep['p_trx_src'],gvar.dataprep['p_inv_num_low'],gvar.dataprep['p_inv_num_high'])
    tc_logs.msg_with_no_picture(base_end_query_ord,'')
    return base_end_query_ord
  
def order_by_end():
    orderby = """) ) INV_DETAIL ORDER BY INV_DETAIL.auction_location ,INV_DETAIL.sale_year, INV_DETAIL.sale_week, INV_DETAIL.sale_lane,    INV_DETAIL.sale_run,INV_DETAIL.work_order,INV_DETAIL.trx_number"""
    return orderby
  
def auction_loc_inv():
    if(gvar.dataprep['p_auction_locations'] != 'ALL') and gvar.dataprep['p_auction_locations']:
        auction_loc_inv_query = """ AND 
        tc_logs.checkpt_with_no_picture("IE Browser opened Successfully") IN ('%s')""" 
        auction_loc_inv_query = aqString.Format(auction_loc_inv_query,gvar.dataprep['p_auction_locations'])
    else:
        auction_loc_inv_query = ''
    return auction_loc_inv_query

def auction_loc_ord():
    if(gvar.dataprep['p_auction_locations'] != 'ALL') and gvar.dataprep['p_auction_locations']: 
        auction_loc_ord_query = """ AND moc.PURCHASE_LOCATION_CODE IN ('%s')""" 
        auction_loc_ord_query = aqString.Format(auction_loc_ord_query,gvar.dataprep['p_auction_locations'])
    else:
        auction_loc_ord_query = ''
    return auction_loc_ord_query

def inv_type_inv():
    if(gvar.dataprep['p_invoice_type'] != 'ALL') and gvar.dataprep['p_invoice_type']:
        inv_type_inv_query = """ AND upper(RACT.attribute1) IN ('%s')"""
        inv_type_inv_query = aqString.Format(inv_type_inv_query,gvar.dataprep['p_invoice_type'])
    else:
        inv_type_inv_query = ''
    return inv_type_inv_query
  
def inv_type_ord():
    if(gvar.dataprep['p_invoice_type'] != 'ALL') and gvar.dataprep['p_invoice_type']:
        inv_type_ord_query = """ AND upper(OETT.attribute1) IN ('%s')"""
        inv_type_ord_query = aqString.Format(inv_type_ord_query,gvar.dataprep['p_invoice_type'])
    else:
        inv_type_ord_query = ''
    return inv_type_ord_query

def pay_type_inv():
    pay_type_inv_query = """ AND (('%s' = 'PAID' AND  NVL(ARP.amount_due_remaining,0) = 0 ) 
                         OR ('%s' = 'UNPAID' AND  NVL(ARP.amount_due_remaining,0) != 0)
                         OR ('%s' = 'ALL' OR '%s' IS NULL ))
                         )"""
    pay_type_inv_query = aqString.Format(pay_type_inv_query,gvar.dataprep['p_payment_status'],gvar.dataprep['p_payment_status'],gvar.dataprep['p_payment_status'],gvar.dataprep['p_payment_status'])
    return pay_type_inv_query
  
def pay_type_ord():
    pay_type_ord_query = """ AND (('%s' ='UNPAID' OR '%s' = 'ALL' OR '%s' IS NULL ))"""
    pay_type_ord_query = aqString.Format(pay_type_ord_query,gvar.dataprep['p_payment_status'],gvar.dataprep['p_payment_status'],gvar.dataprep['p_payment_status'])
    return pay_type_ord_query

def batch_print_sql_query_inv():
    query_inv = base_start_query_inv()+add_dealer_filter_inv()+add_group_code_filter_inv()+base_end_query_inv()+add_date_range_filter_inv()+inv_type_inv()+pay_type_inv()#+auction_loc_inv()
    query_ord = base_start_query_ord()+add_dealer_filter_ord()+add_group_code_filter_ord()+base_end_query_ord()+add_date_range_filter_ord()+inv_type_ord()+pay_type_ord()#+auction_loc_ord()
    union_query = query_inv+query_ord+order_by_end()
    tc_logs.msg_with_no_picture(union_query,'')
    return union_query
  
def oracle_sql_count_inv():
    gvar.dataprep['p_inv_low_date'] = aqConvert.DateTimeToFormatStr(aqDateTime.AddDays(gvar.dataprep['date'],-gvar.dataprep['date_range']),"%Y/%m/%d")
    gvar.dataprep['p_inv_high_date'] = aqConvert.DateTimeToFormatStr(gvar.dataprep['date'],"%Y/%m/%d")
    Log.Message(batch_print_sql_query_inv())
    rows = database_service.query_oracle_db(batch_print_sql_query_inv())
    if (GetVarType(rows)== VarToInt(9)):
        sql_count = len(rows)
        tc_logs.msg_with_no_picture("Number of Vins in Ebiz: "+ VarToStr(len(rows)),'')
    else:
        sql_count = 0
        tc_logs.checkpt_with_no_picture("No records found for the input parameters. Please enter the proper input parameters to the query")
    return sql_count,rows  
    
def invoice_fetch_query(vin,consignment_id):
  
        invoice_query = f"""select TRX_NUMBER INVOICE_NUMBER from ra_customer_trx_all ract where attribute_category IN ('US SELLER','US BUYER') AND
        (ract.ATTRIBUTE2= '{consignment_id}'  OR ract.ATTRIBUTE4= '{vin}')"""
        rows = database_service.query_oracle_db(invoice_query)
        if (GetVarType(rows)== VarToInt(9)) and len(rows) > 0 :
            for row in rows:
              tc_logs.checkpt_with_no_picture(f" INVOICE NUMBER : {row['INVOICE_NUMBER']}")
        else:
            tc_logs.error_with_no_picture("No records found for the input parameters. Please enter the proper input parameters to the query")
            
