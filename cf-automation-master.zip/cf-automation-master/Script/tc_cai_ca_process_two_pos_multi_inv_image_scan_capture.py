﻿from base import *
from driverchain import *
from ebiz import *
import test_utility
import gvar
import tc_logs



class Driver(Driverchain):
  global classarr,env
  
  def __init__(self):
    global test_env, sheet_obj, book     
    app = Sys.OleObject["Excel.Application"]
    Delay(1000)
    self.book = app.Workbooks.Open(Project.Path+"\\datasheets\\WCI\\wcc_us_two_po.xls")          
    app.Visible = "True" 
    self.test_env="oci_stage" #BuiltIn.ParamStr(14)
    self.oper_unit="US"#BuiltIn.ParamStr(15)  
    self.classarr=["capture_two_po_multi_invoice_scan_ca()"] 
    super().__init__(self.classarr)
	
  def close_excel(self):    
    self.book.save()
    delay(1000)
    self.book.close()
	
	
### Added utilities in the main method for Rally TestComplete API Integration (Pushing to GIT in TOGGLE:OFF mode)###
    	
def main():
  try:
    gvar.dataprep['env'] = 'oci_stage'
    obj=Driver()
    #test_utility.start_test(__name__.center(70,'*'),'Core Financials - CF','E2E CAI US','161576','CF ETE Regression') 
    cobj = obj.run()
  except:
    gvar.dataprep['verdict'] = 'Fail'
    tc_logs.header_name('Test Failed - traceback shown below')       
    tc_logs.error_with_no_picture(traceback.format_exc(),'')       
    print('evoke test_utility')
  finally:
    obj.close_excel()
    test_utility.end_test()

