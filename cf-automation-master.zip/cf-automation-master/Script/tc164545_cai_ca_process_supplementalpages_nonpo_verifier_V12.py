﻿from base import *
from driverchain import *
from ebiz import *
import test_utility
import gvar
import tc_logs
import dbhelper

  
class Driver(Driverchain):
    global classarr,env
    
    def __init__(self):
      global test_env, sheet_obj, book     
      app = Sys.OleObject["Excel.Application"]
      Delay(1000)
      self.book = app.Workbooks.Open(Project.Path+"\\datasheets\\WCI\\wcc_ca_supplementpages.xls")          
#      app.Visible = "True"   
      gvar.dataprep['book'] = self.book       
      self.test_env=BuiltIn.ParamStr(14)
      self.oper_unit=BuiltIn.ParamStr(15)
      self.user = BuiltIn.ParamStr(16)
      
#      self.test_env="oci_test"
#      self.oper_unit="CA"
#      self.user = "mkumar"
      
      gvar.dataprep['user'] = self.user
      self.classarr=["ie_clear_cache()","capture_invoice_via_email()","ie_clear_cache()","WCC_Verify_batch_creation_supplementalpages_V12()","ie_clear_cache()","WFR_Process_Email_Batches_V12()","ie_clear_cache()","WCC_Update_Batches_Coding_Form_V12_Test()","ie_clear_cache()","tc194049_run_payable_open_interface_import_process()","ie_clear_cache()","tc130335_check_invoice_attachments()","tc130335_validateInvoice()","ie_clear_cache()","tc93849cai_us_create_accounting()","tc130335_validate_invoice_validated_approved_accounted_status()","Scotia_EFT_English_Payment()"]
#      self.classarr=["ie_clear_cache()","WCC_Verify_batch_creation_supplementalpages_V12()","ie_clear_cache()","WFR_Process_Email_Batches_V12()","ie_clear_cache()","WCC_Update_Batches_Coding_Form_V12_Test()","ie_clear_cache()","tc194049_run_payable_open_interface_import_process()","ie_clear_cache()","tc130335_check_invoice_attachments()","tc130335_validateInvoice()","ie_clear_cache()","tc93849cai_us_create_accounting()","tc130335_validate_invoice_validated_approved_accounted_status()","Scotia_EFT_English_Payment()"]
      super().__init__(self.classarr)
      
    def close_excel(self):    
      self.book.save()
      delay(1000)
      self.book.close()
      
#def main():
#  gvar.dataprep['browser']='ie'
#  gvar.dataprep['env']="oci_test"
#  obj=Driver()
#  cobj=obj.run()
#  obj.close_excel()
            
      
def main():  
  try:
    gvar.dataprep['env'] =BuiltIn.ParamStr(14)
    obj=Driver()
    test_utility.start_test(__name__.center(70,'*'),'Core Financials - CF','VERIFIER','164545','CAI WCI E2E - OCI Test') 
    cobj = obj.run()
    print('evoke test_utility')
  except:
    gvar.dataprep['verdict'] = 'Fail'
    tc_logs.header_name('Test Failed - traceback shown below')       
    tc_logs.error_with_no_picture(traceback.format_exc(),'')       
    print('evoke test_utility')
  finally:
    test_utility.end_test()
    obj.close_excel()

    
    
def workaround_sa_tax():
              delay(3000)
              jFrame=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1)
              jFrame.Click()
              jFrame.Keys("~2")
              Delay(3000)
              jFrame.Click()
              p_names=["AWTComponentAccessibleName","JavaClassName"]
              p_values=["Invoice Workbench (AP Home Office Super User)","ExtendedFrame"]
              inv_wb_form=jFrame.FindChildEx(p_names,p_values,60,True,120000)
              pi_names = ("JavaClassName","AWTComponentAccessibleName","AWTComponentIndex")
              p_values = ("VTextField","Primary Intended UseList of Values",245)
              Delay(1000)
              int_use = inv_wb_form.Find(pi_names,p_values,60)
              Sys.HighlightObject(int_use)
              int_use = inv_wb_form.Find(pi_names,p_values,60)
              int_use.Click()
              delay(2000)
              int_use.Keys("[BS]") # ("^a[Del]")
              delay(2000)
              int_use.Keys("SGA Manheim")#(app.Cells.Item[rowno,24]) #
              delay(3000)
              jFrame.Keys("~1")
              delay(3000)
              jFrame.Keys("~c")
              delay(1500)
              jFrame.Keys("~v")
              delay(1000)
              jFrame.Keys("~k")
              delay(10000)
              jFrame.Keys("^s")
              delay(2000)

def sa_tax_calc():
  Log.Enabled = True
  selfAssessed_tax=dbhelper.get_selfAssessed_tax_From_Db("OCI_TEST","RAC_ACCNT","Y4bLC5sb","VRTX_INV: 15:58:28","131718")#(dsn,user_id,pwd,VarToStr(inv_name),VarToStr(sup_num))
  Log.Message("Self Assessed tax =",selfAssessed_tax)
  Log.Enabled=False
  