﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils
import form_utils

#This test case is to make Domestic ACH payment for an AP INVOICE and retrieving the payment information

class tc95046cai_us_domestic_ach_payment(Ebiz):
  
 op_log_path="C:\\TC_Logs"

 def login(self):
    self.login_user="mcampbell8"
    super().login()

 def action(self,book): 
    rowno = 2
    app = book.Sheets.item["Invoice"]    
    app1 = book.Sheets.item["Requisition"]
    
    self.wait_until_page_loaded()    
    self.log_checkpoint_message_web("Login Successful")
    
    self.page.WaitProperty("contentText","CAI "+self.oper_unit+" AP PAYMENT PROCESSING",6000)
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" AP PAYMENT PROCESSING')]")
    self.log_message_web("Click 'CAI "+self.oper_unit+" AP PAYMENT PROCESSING' - Successful")
    delay(2000)
    self.page.wait()
    self.wait_until_page_loaded()
   
    self.page.NativeWebObject.Find("contentText","Payments","A").Click()
    delay(2000)
    self.page.wait()
    self.wait_until_page_loaded()
    
    self.page.NativeWebObject.Find("contentText","Entry","A").Click()
    delay(2000)  
    self.page.wait()
    self.wait_until_page_loaded()
    
    self.page.NativeWebObject.Find("contentText","Payments Manager","A").Click()
    delay(2000) 
    self.page.wait()
    self.wait_until_page_loaded()
    
    cai_ap_subreq_link=self.page.Find("contentText","Submit Single Payment Process Request",30)
    self.verify_aqobject_chkproperty(cai_ap_subreq_link,"contentText",cmpIn,"Submit Single Payment Process Request")
    cai_ap_subreq_link.Click() 
    self.log_message_web("Click Submit Single Payment Process Request - Successful")
    delay(2000)
    self.page.wait()

    
#Entering ACH Payment Process Request Name
    self.page.Find("idStr","CheckrunName",30).Click()
    pay_des="CAI_Domestic_ACH_Payment_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")
    self.page.Find("idStr","CheckrunName",30).Keys(pay_des)
    self.log_message_web("Enter Payment Process Request Name - Successful")
    delay(2000)
    
#Entering Payment Template
    self.page.Find("idStr","TemplateName",30).Click()
    self.page.Find("idStr","TemplateName",30).Keys("WFPM Domestic ACH")
    self.page.Keys("[Tab]")
    self.log_message_web("Select Payment Template - Successful")
    delay(2000)
    
#Entering 'Vendor' Pay Group Information
#    self.page.Find("idStr","AddPg",30).Click()
    Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/OA_HTML/OA.jsp?*").Panel("oafOraBodyContainer").Form("DefaultFormName").Panel("oafcontent").Panel(0).Panel("oafusercontent").Panel(0).Panel("p_SwanPageLayout").Panel(0).Panel(1).Table("SubTabRN").Cell(0, 1).Table(0).Cell(0, 2).Table(0).Cell(1, 0).Panel(0).Table("ScheduledPaymentsTabRN").Cell(0, 1).Table(0).Cell(0, 2).Table("MultiSelectLayout").Cell(0, 0).Table("PayGroupsHeader").Cell(3, 0).Table(0).Cell(0, 0).Panel(0).Panel(1).Panel("PsrPayGroupTable").Panel("PsrPayGroupTable").Panel("PsrPayGroupTable").Table(0).Cell(0, 0).Panel("ControlBar").Table(0).Cell(0, 0).Button("AddPg").Click()
    pay_grp_select=Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/OA_HTML/cabo/jsps/a.jsp?*").Frame(0)
    Sys.HighlightObject(pay_grp_select)
#    pay_grp_select.Find("ObjectIdentifier","searchText",30).Click()
    Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/OA_HTML/cabo/jsps/a.jsp?*").Frame(0).Panel("oafOraBodyContainer").Panel(0).Panel(1).Form("LOVResFrm").Table(0).Cell(3, 0).Table(0).Cell(0, 0).Panel(0).Panel(0).Textbox("searchText").Click()
    Sys.Keys("Vendor[Enter]")
    Delay(3000)
    Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/OA_HTML/cabo/jsps/a.jsp?*").Frame(0).Panel("oafOraBodyContainer").Panel(0).Panel(1).Form("LOVResFrm").Table(1).Cell(3, 0).Table(0).Cell(0, 0).Panel(0).Panel(2).Panel("PayGroupsTable").Panel("PayGroupsTable").Panel("PayGroupsTable").Panel("PayGroupsTable").Table("Content").Cell(1, 0).Checkbox(0).Click()
#    pay_grp_select.Find("outerHTML","<input name=\"N1:selected:0\" title=\"Select\" type=\"checkbox\" value=\"0\">",30).Click()
    pay_grp_select.Find("contentText","Select",30).Click()
    Delay(4000)
    
#Entering Payee Information  
    self.page.Find("idStr","Payee",30).Click()
    self.page.Find("idStr","Payee",30).Keys(app1.Cells.Item[rowno,9])
    self.page.Keys("[Tab]")
    delay(2000)

    self.page.Find("idStr","Submit",30).Click()
    Delay(2000)
    self.page.wait()
    self.wait_until_page_loaded()
    
    self.page.Find("idStr","SearchCheckrunName",30).Click()
    self.page.Find("idStr","SearchCheckrunName",30).Keys(pay_des)
    self.page.Keys("[Tab]")
    delay(2000)
    
#Submitting for the payment
    self.page.Find("contentText","Go",30).Click()
    self.log_message_web(pay_des+" - Payment Submitted")
    delay(4000)
    self.page.wait()
    self.wait_until_page_loaded()
#Invoice Pending Review
    paymnt_status=self.page.EvaluateXPath("//span[@id='ResultsTable:StatusCodeDsp:0']")[0].contentText
    while paymnt_status != 'Invoices Pending Review':
      Delay(4000)
      self.page.Find("idStr","ResultsTable:Refresh:*",30).Click()
      Delay(1000)
      self.page.wait()
      self.wait_until_page_loaded()
      paymnt_status=self.page.EvaluateXPath("//span[@id='ResultsTable:StatusCodeDsp:0']")[0].contentText
    delay(2000) 
    self.page.Find("namePropStr","takeaction_enabled.gif",30).Click()
    delay(2000)
    self.wait_until_page_loaded()
    self.page.Find("idStr","ResubmitPsr",30).Click() 
    self.log_message_web(pay_des+" - Invoices Pending Review")
    delay(2000)
    self.page.wait()
    self.wait_until_page_loaded()
#Pending Proposed Payment Review   
    while paymnt_status != 'Pending Proposed Payment Review':
     Delay(4000)
     self.page.Find("idStr","ResultsTable:Refresh:*",30).Click()
     Delay(1000)
     self.page.wait()
     self.wait_until_page_loaded()
     paymnt_status=self.page.EvaluateXPath("//span[@id='ResultsTable:StatusCodeDsp:0']")[0].contentText 
    delay(2000)
    self.page.Find("namePropStr","takeaction_enabled.gif",30).Click()
    delay(4000)
    self.page.wait()
    self.wait_until_page_loaded()
    self.log_message_web("Invoices Selected")
    Delay(2000)
    self.page.EvaluateXPath("//button[@title='Go']")[0].Click()
    delay(4000)
    self.page.wait()
    self.wait_until_page_loaded()
    self.page.Find("idStr","SearchCheckrunName",30).Click()
    self.page.Find("idStr","SearchCheckrunName",30).SetText("")
    self.page.Find("idStr","SearchCheckrunName",30).Keys(pay_des)
    self.page.Keys("[Tab]")
    delay(2000)
    self.page.Find("contentText","Go",30).Click()
    self.page.wait()
    self.wait_until_page_loaded()
    self.log_message_web(pay_des+" - Pending Proposed Payment Review")
    delay(4000)
    
#Confirmed Payment    
    while paymnt_status != 'Confirmed':
     Delay(4000)
     self.page.Find("idStr","ResultsTable:Refresh:*",30).Click()
     Delay(1000)
     paymnt_status=self.page.EvaluateXPath("//span[@id='ResultsTable:StatusCodeDsp:0']")[0].contentText
    self.log_message_web(pay_des+" - Confirmed Payment")
    Delay(2500)

#Review Concurrent Program Outputs
    self.page.EvaluateXPath("//img[@title='Home']")[0].Click()
    self.page.wait_until_page_loaded()
#    Delay(4000)
#    self.page.NativeWebObject.Find("contentText","Other","A").Click()
#    delay(4000)
#    self.page.Keys("[Down]")
#    self.page.Keys("[Down]")  
#    self.page.NativeWebObject.Find("contentText","Requests","A").Click()  
#    delay(4000)  
#    self.page.NativeWebObject.Find("contentText","Run","A").Click()
#    delay(5000) 
#    jFrame=self.initializeJFrame()
#    Delay(2000)
#    form_utils.click_ok_btn(jFrame)
#    Delay(5000)
#    jFrame.Keys("[F4]")
#    Delay(1000)
#    jFrame.Keys("~v")
#    Delay(1000)
#    jFrame.Keys("r")
#    Delay(2000)
#    jFrame.Keys("~i")
#    Delay(1000) 
#
## Gathering Request ID and Output File for the Format Payment Instructions Program
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Requests","ExtendedFrame"]
#    req_form=jFrame.FindChildEx(prop,val,30,True,90000)  
#    job_name_parent="false"
#    phase_parent="false"
#    i=20
#    while (job_name_parent != "Format Payment Instructions with Text Output") or (phase_parent != "Completed") :
#     prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#     val=["Name",i]
#     job_name_parent=req_form.Find(prop,val,10).wText
#     prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#     val=["Phase",i+20]
#     phase_parent=req_form.Find(prop,val,10).wText          
#     i+=1     
#     if i==30:
#       req_form.keys("~r") 
#       i=20
#    self.log_message_oracle_form(req_form,"Job Name "+aqConvert.VarToStr(job_name_parent))
#    self.log_message_oracle_form(req_form,"Phase code of Format Payment Instructions with Text Program Output is "+aqConvert.VarToStr(phase_parent))   
#    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#    val=["Request ID",i-11]
#    req_id_parent=req_form.Find(prop,val,10).wText
#    self.log_message_oracle_form(req_form,"Request ID of Format Payment Instructions with Text Program Output is "+aqConvert.VarToStr(req_id_parent))
#    jFrame.Keys("[F4]")
#    Delay(1000)
#    jFrame.Keys("~v")
#    Delay(1000)
#    jFrame.Keys("r")
#    Delay(1000)
#    jFrame.Keys("~s")
#    
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Find Requests","ExtendedFrame"]
#    Delay(2000)
#    find_req_form=jFrame.FindChildEx(prop,val,10,True,90000)
#    find_req_form.Find("AWTComponentAccessibleName","Request ID",10).Click()
#    find_req_form.Find("AWTComponentAccessibleName","Request ID",10).SetText(req_id_parent)
#    Delay(1000)
#    find_req_form.Find("AWTComponentAccessibleName","Find alt i",30).Click()
##    Delay(2000)
##    jFrame.Keys("~i")
#    Delay(1000)
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Requests","ExtendedFrame"]
#    req_form=jFrame.FindChildEx(prop,val,30,True,60000)
#    req_form.Find("AWTComponentAccessibleName","View Output alt p",30).Click()                   
##    jFrame.Keys("~p")
#    Delay(1000)
#    log_page=Sys.Browser("iexplore").Page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe*")
#    log_page.Click()
#    log_page.TextNode(0).Click()
#    Delay(5000)
#    Sys.Keys("~f")
#    Delay(3000)
#    Sys.Keys("a")
#    Delay(5000)  
#    file_system_utils.create_folder(self.op_log_path)             
#    log_path=self.op_log_path+"\\Format Payment Instructions Program Output Is Attached_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
#    Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
#    Delay(3000)
#    Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
#    Delay(8000)
#    Log.Enabled=True
#    Log.File(log_path, "Format Payment Instructions with Text Program Output File Attached")
#    Log.Enabled=False     
#    self.browser.page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe*").Close()    
#    Delay(2000)
#    
##    pro = ["AWTComponentAccessibleName","JavaClassName"]
##    val = ["Requests","ExtendedFrame"]
##    req_form = jFrame.Find(pro,val,60)
##    Delay(1000)
##    req_form.Click()
##    Delay(2000)
##    jFrame.Keys("[F4]")
##    Delay(1000)
##    jFrame.Keys("~v")
##    Delay(1000)
##    jFrame.Keys("r")
##    Delay(1000)
##    jFrame.Keys("~i")
##    Delay(1000)
##
### Gathering Request ID and Output File for the Payment Instruction Register Program 
##    prop=["AWTComponentAccessibleName","JavaClassName"]
##    val=["Requests","ExtendedFrame"]
##    req_form=jFrame.FindChild(prop,val,30)  
##    job_name="false"
##    phase="false"
##    i=20
##    while (job_name!="Payment Instruction Register") or (phase!="Completed") :
##     prop=["AWTComponentAccessibleName","AWTComponentIndex"]
##     val=["Name",i]
##     job_name=req_form.Find(prop,val,10).wText
##     prop=["AWTComponentAccessibleName","AWTComponentIndex"]
##     val=["Phase",i+20]
##     phase=req_form.Find(prop,val,10).wText          
##     i+=1     
##     if i==25:
##       req_form.keys("~r") 
##       i=20
##    self.log_message_oracle_form(req_form,"Job Name "+aqConvert.VarToStr(job_name))
##    self.log_message_oracle_form(req_form,"Phase Code of Payment Instruction Register Program is "+aqConvert.VarToStr(phase))   
##    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
##    val=["Request ID",i-11]
##    req_id=req_form.Find(prop,val,10).wText
##    self.log_message_oracle_form(req_form,"Request ID of Payment Instruction Register Program is  "+aqConvert.VarToStr(req_id)) 
##    delay(2000)
#    jFrame.Keys("[F4]")
#    Delay(1000)
#    jFrame.Keys("[F4]")
#    Delay(2000)
#    jFrame.Keys("~o")
#    Delay(1000)
##    Sys.Browser("iexplore").page("https://*epfinnp.coxautoinc.com/forms/frmservlet*").Close()
#
##Invoice Inquiry 
##    self.page.Find("contentText","Home",30).Click()
#    self.page.EvaluateXPath("//img[@title='Home']")[0].Click()
#    self.page.wait_until_page_loaded()
#    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" AP INQUIRY')]")
#    self.log_message_web("Click 'CAI "+self.oper_unit+" AP INVOICE INQUIRY' - Successful")
#    Delay(1000)
#    self.wait_until_page_loaded() 
#    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Invoices Inquiry')]")
#    self.log_message_web("Click 'Invoices' - Successful") 
#    Delay(1000)
#    self.wait_until_page_loaded()
#    self.page.EvaluateXPath("//div[text()='Invoices']")[0].Click()
#    self.log_message_web("Click 'Invoices' - Successful")
#    delay(5000)
#    web_utils.validate_security_box()
#    delay(5000)
#    jFrame = self.initializeJFrame()
#    Delay(10000)
#    form_utils.click_ok_btn(jFrame)
#    Delay(10000)
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Find Invoices","ExtendedFrame"]
#    par_form=jFrame.FindChild(prop,val,60)
#    prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
#    val=["Invoice: Number","VTextField","6"]
#    inv_num=par_form.FindChild(prop,val,60)
#    inv_num.Find("AWTComponentAccessibleName","Invoice: Number").Click()
#    Delay(10000)
#    inv_num.Find("AWTComponentAccessibleName","Invoice: Number",10).SetText(app.Cells.item[rowno,13])
#    Delay(4000)
#    prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
#    val=["Invoice: Dates: StartList of Values","VTextField","12"]
#    inv_num=par_form.FindChild(prop,val,60)
#    inv_num.Find("AWTComponentAccessibleName","Invoice: Dates: StartList of Values").Click()
#    inv_num.SetText(aqConvert.DateTimeToFormatStr(aqDateTime.Today(),"%d-%b-%Y"))
#    Delay(4000)
#    prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
#    val=["Invoice: Dates: EndList of Values","VTextField","13"]
#    inv_num=par_form.FindChild(prop,val,60)
#    inv_num.Find("AWTComponentAccessibleName","Invoice: Dates: EndList of Values").Click()
#    inv_num.SetText(aqConvert.DateTimeToFormatStr(aqDateTime.Today(),"%d-%b-%Y"))
#    delay(1000) 
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Find Invoices","ExtendedFrame"]
#    Findinvoices=jFrame.FindChild(prop,val,60)
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Find alt i","Button"]
#    Findbutton=Findinvoices.FindChild(prop,val,60)
#    Findbutton.Find("AWTComponentAccessibleName","Find alt i").Click()
##    jFrame.Keys("~i")
#    delay(8000)
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Invoice Workbench*","ExtendedFrame"]
#    inv_wrkbch=jFrame.FindChild(prop,val,60)
#
#    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#    val=["Status",4]
#    inv_status=inv_wrkbch.FindChild(prop,val,60)
#    Log.Enabled=True
#    aqObject.CheckProperty(inv_status,"wText",cmpIn,"Validated")
#    Log.Enabled=False
#    self.log_message_oracle_form(jFrame,"Invoice Is Validated")
#    
#    jFrame.Keys("~4")
#    delay(2000)
#    jFrame.Keys("~p")
#    delay(2000)
#    
#    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#    val=["Status",7]
#    pay_recon_status=jFrame.FindChildEx(prop,val,60,True,90000)
#    Log.Enabled=True
#    aqObject.CheckProperty(pay_recon_status,"wText",cmpIn,"Negotiable")
#    Log.Enabled=False
#    self.log_message_oracle_form(jFrame,"Invoice Is Paid")
    dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
    user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
    pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
    dbhelper.verify_oracle_payment_status(dsn,user_id,pwd,VarToStr(app.Cells.item[rowno,13]))
#    dbhelper.verify_oracle_payment_status(VarToStr(app.Cells.item[rowno,13]))
#    delay(2000)
#    jFrame.Keys("[F4]")
#    Delay(1000)
#    jFrame.Keys("[F4]")
#    Delay(1000)
#    jFrame.Keys("[F4]")
#    Delay(1000)
#    jFrame.Keys("~o")
#    Delay(1000)
#    Sys.Browser("iexplore").page("https://core-*.epfinnp.coxautoinc.com/forms/frmservlet*").Close()
#    del app,jFrame,val,prop,inv_status

