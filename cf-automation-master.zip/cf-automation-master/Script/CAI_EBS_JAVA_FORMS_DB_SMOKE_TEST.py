﻿from base import *
from driverchain import *
from ebiz import *


class Driver(Driverchain):
  global classarr,env
  
  def __init__(self):
    global test_env, sheet_obj, book     
    app = Sys.OleObject["Excel.Application"]
    Delay(1000)
    self.book = app.Workbooks.Open(Project.Path+"\\datasheets\\E2E\\CAI_EBS_Smoke_Test.xls")          
    app.Visible = "True"    
    self.test_env=BuiltIn.ParamStr(14)
    self.oper_unit=BuiltIn.ParamStr(15)
    
    #self.test_env="oci_stage"
    #self.oper_unit="US"
    gvar.dataprep['browser']= 'ie'
#    
    self.classarr=["OCI_Oracle_EBS_Smoke_Test()"]
    super().__init__(self.classarr)
        
  def close_excel(self):    
    self.book.save()
    delay(1000)
    self.book.close()
	
def main():  
  obj=Driver()
  cobj = obj.run()
  obj.close_excel()
