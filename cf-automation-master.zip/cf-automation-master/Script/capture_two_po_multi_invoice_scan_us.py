﻿from ebiz import *
import configparser
import file_system_utils
import gvar
import wcc_login_page
import wcc_home_page


class capture_two_po_multi_invoice_scan_us(Ebiz):
  
 def login(self):
    self.login_user="pburugupal"
    wcc_login_page.username_textfield().SetText(self.login_user)
    self.log_message_web("Set User ID:  "+self.login_user+" Successful")
    wcc_login_page.password_textfield().setText(self.testConfig['ebiz']['password'])
    self.log_message_web("Set Password:  'oracle123' Successful") 
    wcc_login_page.login_button().Click() 

 def goto_url(self,url):
   self.testConfig=configparser.ConfigParser()
   self.testConfig.read(Project.Path+"test_configs\\testconfig_oci_stage.ini")    
   super().goto_url(self.testConfig['ebiz']['webCenCapUrl'])
   
 def logout(self):
   self.page.wait()
   self.page.FindChild("idStr","pt1:pt_np1:linkLogout",20).Click()
   self.log_message_web("Logout Successful")
   
 def action(self,book):
  Delay(3000)
  file_system_utils.create_folder("C:\\TC_Logs")
  app = book.Sheets.item["wci_capture"]   
  wcc_login_page.login_alert_popup().Click()

  Delay(2000)
  self.wait_until_page_loaded()
  
  if wcc_login_page.java_plugin_ok_button().Exists:
    Sys.Browser("iexplore").BrowserWindow(0).Keys("[Enter]")
    
  self.wait_until_page_loaded()
  
#  if Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).Tab("WebCenter Capture - Internet Explorer").Window("Shell DocObject View", "", 1).Window("Internet Explorer_Server", "", 1).Window("Java Plug-in Control Window", "", 1).AWTObject("PluginEmbeddedFrame", "").SwingObject("RMCApplet", "", 0).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("FormManagerPanel", "", 0).SwingObject("JPanel", "", 0).SwingObject("ExistingSessionPanel", "", 0).SwingObject("RoundedCornerPanel", "", 0).Exists:
#    Sys.Browser("iexplore").BrowserWindow(0).Keys("[Enter]")
  
  Delay(2000)
  
  if wcc_login_page.security_window().Exists:
    wcc_login_page.security_window_checkbox().Click()
    wcc_login_page.security_window_enter().Keys("[Enter]")

  delay(20000)
  
  # Set the location to ATC 
  wcc_home_page.location_dropdown().Click()
  delay(2000)
  location = VarToStr(app.Cells.item[2,1])
  wcc_home_page.location_dropdown().keys(location)
  web_utils.log_checkpoint("Selected Capture Location Sucessfully",500,self.page) 
  self.wait_until_page_loaded()
  wcc_home_page.capture_link().DblClick()
  Delay(3000)
  wcc_home_page.import_dialog_ok_button().Click()
  Delay(3000)
  wcc_home_page.select_files_to_import_textfield().SetText("C:\TC_Logs\ETS-Doctwodiffinv.tif")
  delay(1000)
  wcc_home_page.select_files_to_import_textfield().Click()
  wcc_home_page.select_files_to_import_ok_button().Keys("[Enter]")

  self.wait_until_page_loaded()  
  Delay(12000)
  # get batch name and write back to excel
  batch_name=wcc_home_page.batch_name_textfield().wText
  
  #batch_name=Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).FindChild("AWTComponentAccessibleName","Batch Name:",40).wText
  app.Cells.item[2,2]=VarToStr(batch_name)
  self.log_message_web("Batch Id is " +VarToStr(batch_name)+ "")
  
  date_time=wcc_home_page.batch_date_time_created_textfield().wText
  
  #date_time=Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).FindChild("AWTComponentAccessibleName","Date/Time Created:",40).wText
  #self.refresh()
  wcc_home_page.batch_edit_form().Keys("[Right][Right]")
  self.wait_until_page_loaded()
  wcc_home_page.batch_edit_form().Keys("[Down]")  
  self.wait_until_page_loaded()
  delay(60000)
 
  combo_list=wcc_home_page.combo_list_table()

  #wcc_home_page.department_text().Keys("1057")
 # combo_list[8].SetText("1057")
  Delay(1000) 
  wcc_home_page.invoice_category_field().Keys("SPL")
  Delay(1000)
  wcc_home_page.print_local_field().Keys("Yes")
  Delay(1000)
  wcc_home_page.advance_charge_field().Keys("Yes")
#  self.log_message_web("Department: "+VarToStr(combo_list[8].wText))
  self.log_message_web("PrintLocal: "+VarToStr(combo_list[3].wText))
  self.log_message_web("AdvanceCharge: "+VarToStr(combo_list[2].wText))
  self.log_message_web("BatchType: "+VarToStr(combo_list[1].wText))
  self.log_message_web("LockBatch: "+VarToStr(combo_list[0].wText))
  Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).FindChild("AWTComponentAccessibleName","Release",40).Click()
  Delay(16000)
  self.log_message_web("Click 'Release' button successful")
  delay(2000)
  #self.refresh()
  self.validate_batch_release(app)
  
 def refresh(self):
   delay(1200)
   wcc_home_page.url_bar().Keys("[F5]")
   self.page.wait_until_loaded()
   if wcc_login_page.login_alert_ref().Exists:
      wcc_login_page.login_alert_ref().Button("OK")
   Delay(2000)
   self.wait_until_page_loaded()
   round_panel = wcc_login_page.java_plugin_ok_button()
   if round_panel.Exists:
     Sys.Browser("iexplore").BrowserWindow(0).Keys("[Enter]")
     Delay(2000)
  # Check security warning window exists
   wcc_login_page.security_window_checkbox().Click()
   wcc_login_page.security_window_enter().Keys("[Enter]")
   Delay(2000)
   self.wait_until_page_loaded()
   if round_panel.Exists:
     Sys.Browser("iexplore").BrowserWindow(0).Keys("[Enter]")
     Delay(2000)
   self.page.wait_until_loaded()
   
 def validate_batch_release(self,app):
    
    batch_list = wcc_home_page.batch_edit_form()
    b_id = batch_list.Id
    batch_list.FindID(b_id).click() 
    delay(2000)  
    batch_name = wcc_home_page.batch_name_textfield()
    i = 0
    while batch_name.Exists == None: 
     batch_list.FindID(b_id).click()
     i = i + 1
     if i == 4:
      self.log_error_message("Unable to Validate the Release: Test Failed")
      
    batch_name,date_time,batch_notes = self.get_batch_details()
    if batch_name == VarToStr(app.Cells.item[2,2]):
       self.log_error_message("Unable to Verify the Release for Batch : "+VarToStr(app.Cells.item[2,2])+" Batch Record Still Present - Test Failed")
    web_utils.log_checkpoint("Able to Verify the Release for :"+VarToStr(app.Cells.item[2,2])+" - Batch Record Removed from the Page",500,self.page)

 def get_batch_details(self):
  batch_name = wcc_home_page.batch_name_textfield().wText
#  batch_name=Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).FindChild("AWTComponentAccessibleName","Batch Name:",40).wText
  #self.log_message_web("Batch Name: "+VarToStr(batch_name))
  delay(1000)
#  book.Save()
  date_time = wcc_home_page.batch_date_time_created_textfield().wText
#  date_time=Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).FindChild("AWTComponentAccessibleName","Date/Time Created:",40).wText
 # self.log_message_web("Date Time: "+VarToStr(date_time))
  delay(1000)
  batch_notes = wcc_home_page.batch_notes_textfield().wText
#  pro = ("JavaClassName","AWTComponentAccessibleName")
#  val = ("JTextArea","Batch Notes:")
#
#  batch_notes = Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).FindChild(pro,val,30).wText 
 # self.log_message_web("Batch_Notes: "+VarToStr(batch_notes))
  return batch_name,date_time,batch_notes

def sample(): 
   self.page.FindChildEx("JavaClassName","VetoableComboBox",30,True,60000).Click() 
   Sys.HighlightObject(Sys.Browser("iexplore").FindChildEx("AWTComponentAccessibleName","Capture",30,True,60000)) 
   Sys.Browser("iexplore").FindChildEx("AWTComponentAccessibleName","Capture",30,True,60000).Keys("![Tab]") 
   #Sys.Keys("[Down]") 
   Sys.HighlightObject(Sys.Browser("iexplore").FindChildEx("JavaClassName","VetoableComboBox",30,True,60000)) 
   Sys.Browser("iexplore").FindChildEx("JavaClassName","VetoableComboBox",30,True,60000).Keys("001") 
   Sys.Browser("iexplore", 2).BrowserWindow(0).Window("Frame Tab", "", 1).Tab("WebCenter Capture - Internet Explorer").Window("Shell DocObject View", "", 1).Window("Internet Explorer_Server", "", 1).Window("Java Plug-in Control Window", "", 1).AWTObject("PluginEmbeddedFrame", "").SwingObject("RMCApplet", "", 0).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("FormManagerPanel", "", 0).SwingObject("JPanel", "", 0).SwingObject("BatchEditForm", "", 0).SwingObject("JSplitPane", "", 0).SwingObject("JPanel", "", 0).SwingObject("JSplitPane", "", 0).SwingObject("JPanel", "", 1).SwingObject("JToolBar", "", 0).SwingObject("VetoableComboBox", "", 0) 
   Sys.HighlightObject(Sys.Browser("iexplore", 2)) 
   jFrame=Sys.Process("jp2launcher").WaitSwingObject("JFrame", "Oracle Applications*", -1,1,90000) 
   jBrowser=Sys.Browser("iexplore") 
   file_import_wnd=Sys.Browser("iexplore").WaitSwingObject("FileImportDialog", "Select files to import", -1, 1,10000) 
   jBrowser.SwingObject("FileImportDialog", "Select files to import", -1, 1).Find(["AWTComponentAccessibleName","JavaClassName"],["File name:","SynthFileChooserUIImpl$3"],40).Click() 
   prop_name=["AWTComponentAccessibleName","AWTComponentIndex"] 
   prop_value=["OK",1] 
   jBrowser.SwingObject("FileImportDialog", "Select files to import", -1, 1).Find(["AWTComponentAccessibleName","JavaClassName"],["File name:","SynthFileChooserUIImpl$3"],40).SetText("C:\TC_Logs\SKM_C55817031316340.pdf") 
   Sys.HighlightObject(file_import_wnd.FindChild(prop_name,prop_value,10)) 
   file_import_wnd.Keys("[Enter]") 
   file_import_wnd.FindChild(prop_name,prop_value,10).Click()  
   file_import_wnd.FindChild(prop_name,prop_value,10).Keys("[Enter]") 
    
    
