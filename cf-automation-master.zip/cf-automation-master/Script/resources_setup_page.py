﻿import gvar

### In this method objects for below pages have been captured ###

#RESOURCES > SETUP page

def resources_setup_page_link():
  prop_names = ["contentText","idStr","ObjectType"]
  prop_values = ["Setup","PA_PRJ_RESOURCE_TAB","Link"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def addnl_staffing_info_link():
  classifications = gvar.dataprep['page'].NativeWebObject.Find("contentText","Additional Staffing Information","A")
  return classifications
