﻿
from ebiz import *
from dbhelper import *
import dbhelper
import configparser
import web_utils
import form_utils
import file_system_utils

class GlValaidateWebAdiJnl(Ebiz):
  
  op_log_path="C:\\TC_Logs"
  
  def action(self): 
    properties=configparser.ConfigParser()
    properties.read(Project.Path+'\\obj_repo\\gl_validate_web_adi_journal.ini') 
    Log.Message("Inside action...")           
    self.page.Wait()
    web_utils.clk_link_by_xpath(self.page,properties['GL_ADMIN']['gl_admin_xpath'])       
    self.log_message_web("Click 'GL Administrator' - Successful")        
    self.page.Wait()
    if(self.page.NativeWebObject.Find("contentText", "Launch Journal Wizard", "a").Exists):
      self.log_checkpoint_message_web("Launch Journal Wizard link found")    
    web_utils.clk_link_by_xpath(self.page,properties['GL_ADMIN']['luch_jnl_wzd_xpath'])        
    self.log_message_web("Click 'Launch Journal Wizard' Successful")    
    self.page.wait()    
    self.page.Find(properties['GL_ADMIN']['layout_prop'],properties['GL_ADMIN']['layout_value'],60).ClickItem("Manheim Functional Actuals")
    Delay(1000)
    self.log_message_web("Select 'Manheim Functional Actuals' Successful")    
    self.page.Find(properties['GL_ADMIN']['create_btn_prop'],properties['GL_ADMIN']['create_btn_value'],60).Click()
    self.log_message_web("Click 'Create Document' Successful")    
    Delay(8000)
    self.page.Keys("~s")
    Delay(1000)
    self.log_message_web("Save Excel sheet Successful")    
    self.page.Keys("~o")
    Delay(2000)    
    self.process_webAdi_test_data()
    # Click Home link  
    web_utils.clk_link_by_xpath(self.page,"//a[@class='x15']") 
    Delay(2000)
    self.log_message_web("Click 'Home' link Successful")        
    web_utils.clk_link_by_xpath(self.page,"//a[@id='N82']")
    Delay(3000)
    self.log_message_web("Click 'Run' Successful")    
    self.handle_security_popup()
    form_utils.click_ok_btn()
    Delay(5000)
    jFrame=Sys.Browser("iexplore").WaitSwingObject("JBufferedFrame", "*", -1, 20000)    
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~s")
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Requests","ExtendedFrame"]    
    find_req_form=jFrame.FindChild(prop,val,10)
    find_req_form.Find("AWTComponentAccessibleName","Request ID",10).Click()
    find_req_form.Find("AWTComponentAccessibleName","Request ID",10).SetText(self.req_id)
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000)
    jFrame.Keys("~g")
    Delay(2000)
    log_page=Sys.Browser("iexplore").Page(self.testConfig['ebiz']['url']+"/OA_CGI/FNDWRR.*")
    log_page.Click()
    log_page.TextNode(0).Click()
    Delay(1000)
    log_page.Keys("~f")
    Delay(1000)
    log_page.Keys("a")
    Delay(1000)    
    file_system_utils.create_folder(self.op_log_path)             
    log_path=self.op_log_path+"\\output_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
    Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
    Delay(1000)
    Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
    Delay(1000)
    Log.Enabled=True
    Log.File(log_path, "Log output file attached.")
    Log.Enabled=False        
    Delay(1000)
    jFrame.Click()
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~o")
    Delay(1000)
    self.browser.page("*").Close() 
    Delay(1000)
    self.browser.page("*").Close() 
     
  def process_webAdi_test_data(self):
    vfy_window=Sys.Process("EXCEL").WaitWindow("ThunderDFrame", "Download", 1, 30000)
    while vfy_window.FindChild("ObjectType","TextNode",60).contentText != "Your document has been created.":      
      Delay(2000)
      vfy_window=Sys.Process("EXCEL").WaitWindow("ThunderDFrame", "Download", 1, 20000)
    Delay(2000)
    Sys.Process("EXCEL").Window("ThunderDFrame", "Download", 1).Find("ObjectIdentifier","CANCEL_uixr",60).Click()  
    Delay(8000)
    DDT.ExcelDriver(Project.Path+'DataSheets\\Oracle-GL-Journal\\WebADI.xls',"Sheet1",True)    
    xl_window=Sys.Process("EXCEL").Window("XLMAIN", "Book1 - Excel", 1).Window("XLDESK", "", 1).Window("EXCEL*", "Book1", 1)           
    xl_window.Click(597, 95)      
    xl_window.Keys(DDT.CurrentDriver.Value[0])
    self.log_message_oracle_excel_popup(xl_window,"Category: "+DDT.CurrentDriver.Value[0])
    xl_window.Click(573, 141)
    xl_window.Keys(aqConvert.DateTimeToFormatStr(aqDateTime.Today(),"%m/%d/%Y"))
    self.log_message_oracle_excel_popup(xl_window,"Date "+aqConvert.DateTimeToFormatStr(aqDateTime.Today(),"%m/%d/%Y"))
    xl_window.Keys("[Down]")    
    xl_window.Keys("TestCompleteAuto Test Journals")
    self.log_message_oracle_excel_popup(xl_window,"Journal Name: "+DDT.CurrentDriver.Value[1])
    xl_window.Keys("[Down]")    
    xl_window.Keys("Test Journals")
    self.log_message_oracle_excel_popup(xl_window,"Journal Description: "+DDT.CurrentDriver.Value[2])
    xl_window.Click(53, 240)
    xl_window.Keys("[Tab]")
    while not DDT.CurrentDriver.EOF():
      self.enter_xl_data(xl_window,3,"Acounting Entity: "+DDT.CurrentDriver.Value[3])
      self.enter_xl_data(xl_window,4,"Acount: "+DDT.CurrentDriver.Value[4])       
      self.enter_xl_data(xl_window,5,"Business Category: "+DDT.CurrentDriver.Value[5])       
      self.enter_xl_data(xl_window,6,"Market Segment: "+DDT.CurrentDriver.Value[6]) 
      self.enter_xl_data(xl_window,7,"Cost Center: "+DDT.CurrentDriver.Value[7]) 
      self.enter_xl_data(xl_window,8,"Intercompany: "+DDT.CurrentDriver.Value[8])      
      self.enter_xl_data(xl_window,9,"Future: "+DDT.CurrentDriver.Value[9])      
      self.enter_xl_data(xl_window,10,DDT.CurrentDriver.Value[10])      
      self.enter_xl_data(xl_window,11,DDT.CurrentDriver.Value[11])
      xl_window.Keys("Test Journal line1") 
      xl_window.Keys("[Tab]")
      xl_window.Keys("[Tab]")
      xl_window.Keys("[Tab]")
      DDT.CurrentDriver.Next()
    Delay(1000)
    DDT.CloseDriver(DDT.CurrentDriver.Name)
    excel_obj=Sys.Process("EXCEL").Window("XLMAIN", "Book1 - Excel", 1).FindChild("WndCaption","Ribbon",40)
    OCR.Recognize(excel_obj).BlockByText("Add").Click()
    OCR.Recognize(excel_obj).BlockByText("Oracle").Click()
    Delay(2000)    
    Sys.Process("EXCEL").Window("Net UI Tool Window", "", 1).Window("NetUIHWND", "", 1).Keys("[Down][Down][Down][Enter]")    
    Delay(3000)
    jrnls_upload_wnd=Sys.Process("EXCEL").WaitWindow("ThunderDFrame", "Journals Upload", 1,20000)
    if jrnls_upload_wnd.Exists:
       Sys.Process("EXCEL").Window("ThunderDFrame", "Journals Upload", 1).Find("idStr","M__Ide",40).ClickButton()
       Sys.Process("EXCEL").Window("ThunderDFrame", "Journals Upload", 1).Find("ObjectLabel","Upload",40).Click()
       Delay(8000)
       if jrnls_upload_wnd.Find("ObjectIdentifier","errorl_gif",40).Exists:
         self.log_message_oracle_excel_popup(jrnls_upload_wnd,"Journals Upload Failed!!")
         Log.Error("Journals Upload Failed.") 
         Runner.Stop()                 
       else:
         Log.Message("Journals Upload Passed")
    Delay(2000)     
    conf_msg=jrnls_upload_wnd.Find("idStr","BneAsyncUploadPageConfirmation",40).contentText  
    self.log_message_oracle_excel_popup(jrnls_upload_wnd,"Journals Upload Confirmation")
    self.log_message_oracle_excel_popup(jrnls_upload_wnd,"Message:- "+aqConvert.VarToStr(conf_msg))
    Delay(1000)            
    jrnls_upload_wnd.Find("ObjectLabel","Close",20).Click()      
    pos=conf_msg.find("Request",350,len(conf_msg))+11
    req_id=aqString.Trim(conf_msg[pos:pos+10])
    self.log_message_oracle_excel_popup(jrnls_upload_wnd,"RequestID: "+req_id)
    Log.Message("RequestID : "+req_id)
    self.req_id=req_id
      
  def enter_xl_data(self,xl_wnd,ddt_value,report_msg):
      xl_wnd.Keys(DDT.CurrentDriver.Value[ddt_value])
      self.log_message_oracle_excel_popup(xl_wnd,report_msg)
      xl_wnd.Keys("[Tab]")
    
    

