﻿import gvar
import oracle_login_page
import oracle_home_page
import web_utility
import tc_logs

def oracle_login():
  tc_logs.header_name("EBIZ".center(70,'*'))
#  web_utility.close_all_java_ie()
  web_utility.launch_browser(gvar.config['ebiz']['oci_is_url'])
  oracle_login_page.username_textfield().Keys(gvar.config['ebiz']['oasis_userid'])
  oracle_login_page.password_textfield().Click()
  oracle_login_page.password_textfield().Keys(gvar.config['ebiz']['password'])
  oracle_login_page.login_button().Click()
  gvar.dataprep['page'].Wait()
  
def oracle_logout():
#  web_utility.close_additional_tabs()
  oracle_home_page.logout_link().Click()
  web_utility.clear_cache()
  web_utility.close_browser()
