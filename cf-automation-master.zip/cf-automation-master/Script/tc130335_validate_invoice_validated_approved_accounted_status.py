﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils
import web_utils


class tc130335_validate_invoice_validated_approved_accounted_status(Ebiz):
 global rowno
 rowno = 2

 def login(self):
    self.login_user="rmaran"
    super().login()
 
 op_log_path="C:\\TC_Logs"
 
 def action(self,book): 
    app = book.Sheets.item["Invoice"]
    web_utils.log_checkpoint("Logged in to Oracle Applications Home Page Successfully",500,self.page)
    self.wait_until_page_loaded()  
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" AP INVOICE PROCESSING')]") 
    Delay(1000)  
    self.wait_until_page_loaded()           
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Invoices')]")
    Delay(1000)
    self.wait_until_page_loaded() 
    Delay(1000) 
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Entry')]")
    Delay(1000) 
    self.wait_until_page_loaded()
    self.page.EvaluateXPath("//div[text()='Invoices']")[1].Click()
    delay(10000) 
    web_utils.validate_security_box()
    delay(10000)  
    jFrame = self.initializeJFrame()
    Delay(10000)
    form_utils.click_ok_btn(jFrame)
    p_names = ("JavaClassName","AWTComponentAccessibleName")
    p_values = ("ExtendedFrame","Invoice Workbench (CAI "+self.oper_unit+" AP INVOICE PROCESSING)")
    inv_form=jFrame.FindChildEx(p_names,p_values,60,True,120000)
    Delay(2000)
    jFrame.Keys("~v")
    delay(1000)
    jFrame.Keys("f")
    delay(1000)
    
 #Finding Invoice in the invoice workbench and checking 'Validated','Approved' and 'Accounted' statues
 
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Invoices","ExtendedFrame"]
    par_form=jFrame.FindChildEx(prop,val,60,True,60000)
    par_form.Find("AWTComponentAccessibleName","Invoice: Number",30).Click()
    Delay(5000)
    par_form.Find("AWTComponentAccessibleName","Invoice: Number",30).SetText(app.Cells.Item[rowno,13])
    jFrame.Keys("[Tab]")
    delay(3000)
    val = ["Find alt i","Button"] 
    par_form.FindChild(prop,val,60).Click()
    Delay(4000)    
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Type Required",8]
    inv_type=jFrame.FindChildEx(prop,val,60,True,9000000)
    Log.Enabled=True
    aqObject.CheckProperty(inv_type,"wText",cmpIn,"Standard")
    Log.Enabled=False
    web_utils.log_checkpoint("Invoice found Successfully : "+aqConvert.VarToStr(app.Cells.Item[rowno,13]),500,jFrame)

    prop=["AWTComponentAccessibleName","AWTComponentIndex","JavaClassName"]
    val=["Status",4,"VTextField"]
    status=jFrame.FindChildEx(prop,val,60,True,9000000)
    Log.Enabled=True
    aqObject.CheckProperty(status,"wText",cmpIn,"Validated")
    Log.Enabled=False
    
    prop=["AWTComponentAccessibleName","AWTComponentIndex","JavaClassName"]
    val=["Accounted",5,"VTextField"]
    accounted=jFrame.FindChildEx(prop,val,60,True,9000000)
    Log.Enabled=True
    aqObject.CheckProperty(accounted,"wText",cmpIn,"Yes")
    Log.Enabled=False
    
    prop=["AWTComponentAccessibleName","AWTComponentIndex","JavaClassName"]
    val=["Approval",6,"VTextField"]
    apprvl_status=jFrame.FindChildEx(prop,val,60,True,9000000)
    Log.Enabled=True
    aqObject.CheckProperty(apprvl_status,"wText",cmpIn,"Manually Approved")
    Log.Enabled=False
    web_utils.log_checkpoint("Invoice is 'Validated','Approved' and 'Accounted': "+aqConvert.VarToStr(app.Cells.Item[rowno,13]),500,jFrame)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Invoice Workbench*","ExtendedFrame"]
    inv_wkbnch=jFrame.FindChildEx(prop,val,60,True,60000)
    inv_wkbnch.FindChild("AWTComponentName","FormsTabPanel*",60).ClickTab("2 Lines")
    Delay(9000)   
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Open Folder*","VButton"]
    open_fldr_form=jFrame.FindChildEx(prop,val,30,True,60000)
    open_fldr_form.Click()
    Delay(6000)
    jFrame.Keys("*A")
    delay(5000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Open Folder","FWindow"]
    open_folder=jFrame.FindChildEx(prop,val,50,True,90000)  
    Sys.HighlightObject(open_folder)     
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["OK ALT O","PushButton"]   
    open_folder.FindChild(prop,val,10).Click()
    delay(4000)
    web_utils.log_checkpoint(" Review Invoice: "+aqConvert.VarToStr(app.Cells.Item[rowno,13])+" line level information",500,jFrame)
    inv_wkbnch.FindChild("AWTComponentName","FormsTabPanel*",60).ClickTab("1 General")
    Delay(4000) 
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("o")

    
