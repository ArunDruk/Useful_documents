﻿from dbhelper import *
from ebiz import *
import web_utils
import dbhelper
import file_system_utils 
import form_utils

class tc187628_is_us_asset_creation(Ebiz):
 op_log_path="C:\\Tc_Logs"

 def login(self):
   self.login_user='pkjami'
   super().login()
 
 def goto_url(self,url):
   super().goto_url(self.testConfig['ebiz']['oci_is_url'])
   
 def action(self,book): 
   app = book.Sheets.item["PA-FA"]       
   web_utils.log_checkpoint("Logged in to Oracle Applications Home Page Successfully",500,self.page)
   self.wait_until_page_loaded()   
   self.page.EvaluateXPath("//table[@id='menuContent']//div[contains(text(),'AM Supervisor')]")[0].Click() 
   web_utils.log_checkpoint("Click 'AM Supervisor' - Successful",500,self.page) 
   self.wait_until_page_loaded()
   self.page.Keys("[Down]")
   self.page.Keys("[Down]")
   Delay(2000)
   self.page.NativeWebObject.Find("contentText","Assets","A").Click()
   web_utils.log_checkpoint("Click 'Assets' - Successful",500,self.page) 
   self.wait_until_page_loaded()
   self.page.Keys("[Down]")
   Delay(2000)
   self.page.wait()
   self.page.NativeWebObject.Find("contentText","Asset Workbench","A").Click()
   web_utils.log_checkpoint("Click 'Asset Workbench' - Successful",500,self.page) 
   web_utils.validate_security_box()
   Delay(15000)
   jFrame=self.initializeJFrame()
   form_utils.click_ok_btn(jFrame) 

# Asset Additions

   for rowno in range(2,app.UsedRange.Rows.Count+1):     
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Find Assets","ExtendedFrame"]
     findassets_form=jFrame.FindChildEx(prop,val,60,True,40000)
     if findassets_form.Exists:
      web_utils.log_checkpoint("Navigation Successful : AM Supervisor > Assets > Asset Workbench; 'Find Assets' form launched successfully",500,jFrame)
     else:
      self.log_message_oracle_form(jFrame,"Unable to Launch 'Find Assets' form")
      
     Delay(2000)
     web_utils.log_checkpoint("In 'Find Assets' form: Click on 'Additions' Button next",500,jFrame)
     findassets_form.FindChild("AWTComponentAccessibleName","Additions alt n",10).Click()
     Delay(3000)
     
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Asset Details","ExtendedFrame"]
     assetdetails_form=jFrame.FindChildEx(prop,val,60,True,30000)
     if assetdetails_form.Exists:
      web_utils.log_checkpoint("'Assets Details' form launched successfully",500,jFrame)
     else:
      self.log_message_oracle_form(jFrame,"Unable to Launch 'Assets Details' form")
       
     assetdetails_form.Find("AWTComponentAccessibleName","Description RequiredList of Values",10).Click()
     assetdetails_form.Find("AWTComponentAccessibleName","Description RequiredList of Values",10).keys(app.Cells.item[rowno,3])
     web_utils.log_checkpoint(" In 'Asset Details' form: Description Entered - " + VarToStr(app.Cells.item[rowno,3]),500,jFrame)
     cat_req=assetdetails_form.Find("AWTComponentAccessibleName","Category RequiredList of Values",10)
     cat_req.Click()
     cat_req.keys(app.Cells.item[rowno,4])
     Delay(2000)
     assetdetails_form.Find("AWTComponentAccessibleName","Asset Key RequiredList of Values",10).Click()
     Delay(2000)
     assetdetails_form.Find("AWTComponentAccessibleName","Asset Key RequiredList of Values",10).keys(app.Cells.item[rowno,5])
     web_utils.log_checkpoint(" In 'Asset Details' form: 'Asset Key' Entered - " + VarToStr(app.Cells.item[rowno,5]),500,jFrame)
     Delay(2000)
     web_utils.log_checkpoint(" In 'Asset Details' form: Click 'Continue' Button next",500,jFrame)
     Delay(2000)
     assetdetails_form.Find("AWTComponentAccessibleName","Continue alt n",10).Click()  
     Delay(3000) 
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Books","ExtendedFrame"]
     Books_form=jFrame.FindChildEx(prop,val,20,True,60000)
     Books_form.Find("AWTComponentAccessibleName","Book RequiredList of Values",10).Click()
     Books_form.Find("AWTComponentAccessibleName","Book RequiredList of Values",10).keys(app.Cells.item[rowno,6])
     web_utils.log_checkpoint(" In 'Books' form: Book Entered - "+ VarToStr(app.Cells.item[rowno,6]),500,jFrame)
     Delay(2000)
     Books_form.Find("AWTComponentAccessibleName","Current Cost Required",10).Click()
     Books_form.Find("AWTComponentAccessibleName","Current Cost Required",10).keys(app.Cells.item[rowno,12])
     web_utils.log_checkpoint(" In 'Books' form: Current Cost Entered - "+ VarToStr(app.Cells.item[rowno,12]),500,jFrame)
     Delay(3000)
#     jFrame.Keys("[Tab][Tab][Tab][Tab][Tab][Tab][Tab][Tab][Tab][Tab][Tab][Tab]")
#     Delay(1000)
#     jFrame.Keys("a^[BS]")
#     Delay(1000)
#     jFrame.Keys("CUR MONTH")
#     Delay(1000)
#     jFrame.Keys("[Tab]")
##     prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
##     val=["Prorate Convention RequiredList of Values","VTextField",3]
##     prorate=Books_form.FindChildEx(prop,val,20,True,60000)
##     prorate.Find("AWTComponentAccessibleName","Prorate Convention RequiredList of Values",90).Click()
##     Delay(3000)
##     prorate.Find("AWTComponentAccessibleName","Prorate Convention RequiredList of Values",90).Keys("a^[BS]")
##     Delay(3000)
##     prorate.Find("AWTComponentAccessibleName","Prorate Convention RequiredList of Values",90).SetText("CUR MONTH")
#     web_utils.log_checkpoint(" In 'Books' form: Prorate Convention Entered : 'CUR MONTH'",500,jFrame)
     Delay(2000)
     web_utils.log_checkpoint("Click 'Continue' Button next on 'Books' form",500,jFrame)
     jFrame.keys("~n")
     Delay(2000)

# Adding Unit change, Expense Account & Location Information

     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Assignments","ExtendedFrame"]   
     assingments_form=jFrame.FindChildEx(prop,val,60,True,40000)
     if assingments_form.Exists:
      web_utils.log_checkpoint("'Assets Assignments' form launched successfully",500,jFrame)
     else:
      self.log_message_oracle_form(jFrame,"Unable to Launch 'Assets Assignments' form")
      
     prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
     val=["Unit*","VTextField",16]  
     assingments_form.Find(prop,val,10).Click()  
     assingments_form.Find(prop,val,10).Keys(app.Cells.item[rowno,10])
     web_utils.log_checkpoint(" In 'Assignments' form: 'Unit Change' Entered : "+ VarToStr(app.Cells.item[rowno,10]),500,jFrame)
     Delay(2000)
     prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
     val=["Expense Account RequiredList of Values","VTextField",56]  
     assingments_form.Find(prop,val,10).Click()    
     assingments_form.Find(prop,val,10).Keys(app.Cells.item[rowno,11])
     web_utils.log_checkpoint(" In 'Assignments' form: 'Expense Account' Entered - "+ VarToStr(app.Cells.item[rowno,11]),500,jFrame)
     Delay(2000)
     prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
     val=["Location RequiredList of Values","VTextField",66]    
     assingments_form.Find(prop,val,10).Click()  
     assingments_form.Find(prop,val,10).Keys(app.Cells.item[rowno,7])
     web_utils.log_checkpoint(" In 'Assignments' form: 'Location' Entered - "+ VarToStr(app.Cells.item[rowno,7]),500,jFrame)
     assingments_form.keys("[Tab]")
     Delay(2000)
     web_utils.log_checkpoint("Click 'Done' Button next on 'Assignments' Form",500,jFrame)
     Delay(2000) 
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Done alt D","Button"]    
     assingments_form.FindChild(prop,val,40).Click() 
     Delay(4000)
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Note APP-OFA-48266: Transaction saved for asset number*","ChoiceBox"]   
     conf_msg=jFrame.FindChild(prop,val,40).AWTComponentAccessibleName
     web_utils.log_checkpoint("Asset Transaction Saved Note - " +VarToStr(conf_msg),500,jFrame)
     Delay(2000)
     asset_no=conf_msg.split(".",2)[0][-7:]
     web_utils.log_checkpoint("Asset Number generated - "+VarToStr(asset_no),500,jFrame)
     app.Cells.item[rowno,1]= asset_no 
     jFrame.keys("~o")
     Delay(5000)
     
   jFrame.keys("[F4]")
   Delay(2000)
   jFrame.keys("[F4]")
   Delay(2000)
   jFrame.keys("~o")
   Delay(3000)
   book.save()


   


