﻿import driverchain
import tc93848cai_us_next_day_check_payment
#Author:            Sandeep Kowtha
#TestCaseID:        TC93848
#UserStoryID:       US200743
#Reviewed_By:       Syed Hussain




class driver(Driverchain):
  global classarr

  def __init__(self):  
    global env
#    Project.Variables.AddVariable("test_env","String")
    Project.Variables.test_env="dauti"  
    self.classarr=["next_day_check_payment()"]     
    super().__init__(self.classarr)
    
    
def main():  
  cobj=driver().run()
