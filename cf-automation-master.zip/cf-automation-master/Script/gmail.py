﻿import web_utils
from base import *
import tc_logs
import gmail_login_page
import gmail_home_page
import gvar

class Gmail(Base):
  
  def goto_url(self,url):
   super().goto_url(self.testConfig['gmail']['urlemail'])
   
  #Login to gmail
  def login(self):
    delay(2190)
    web_utils.wait_until_page_loaded(gvar.dataprep['page'])   
    if gmail_login_page.remove_an_account().Exists:
             gmail_login_page.remove_an_account().Click() 
             aqUtils.Delay(4000)
             gmail_login_page.remove_account().Click() 
             aqUtils.Delay(4000)
             gmail_login_page.remove_account_popup().Click() 
             web_utils.wait_until_page_loaded(gvar.dataprep['page'])  
             if gmail_login_page.username_textfield().Exists:
                      gmail_login_page.username_textfield().Keys((self.testConfig['gmail']['userid_email'])+"[Enter]")
                      tc_logs.checkpt_with_picture("Able to Enter Username Successfully",500,gvar.dataprep['page']) 
                      web_utils.wait_until_page_loaded(gvar.dataprep['page'])                  
                      if gmail_login_page.password_textfield().Exists:
                         Indicator.Hide()
                         gmail_login_page.password_textfield().Keys((self.testConfig['gmail']['password'])+"[Enter]")
                         Indicator.Show()
                         tc_logs.checkpt_with_picture("Able to Enter Password Successfully",500,gvar.dataprep['page'])
    elif gmail_login_page.username_textfield().Exists:
              gmail_login_page.username_textfield().Click()
              Delay(5000)
              gmail_login_page.username_textfield().Keys((self.testConfig['gmail']['userid_email'])+"[Enter]")
              tc_logs.checkpt_with_picture("Able to Enter Username Successfully",500,gvar.dataprep['page'])
              web_utils.wait_until_page_loaded(gvar.dataprep['page'])                  
              if gmail_login_page.password_textfield().Exists:
                 Indicator.Hide()
                 gmail_login_page.password_textfield().Keys((self.testConfig['gmail']['password'])+"[Enter]")
                 Indicator.Show()
                 tc_logs.checkpt_with_picture("Able to Enter Password Successfully",500,gvar.dataprep['page']) 

    elif gmail_login_page.choose_an_account_dropdown().Exists:
            tc_logs.checkpt_with_picture("Choose the Existing Account for the user...",500,gvar.dataprep['page'])
            gmail_login_page.user_dropdown().Click() 
            Delay(50000)
            if gmail_login_page.password_textfield().Exists:
               Indicator.Hide()
               gmail_login_page.password_textfield().Keys((self.testConfig['gmail']['password'])+"[Enter]")
               Indicator.Show()
               tc_logs.checkpt_with_picture("Able to Enter Password Successfully",500,gvar.dataprep['page'])
               gvar.dataprep['page'].Keys("[Enter]")  
               web_utils.wait_until_page_loaded(gvar.dataprep['page']) 
               if gmail_login_page.done_button().Exists:
                  tc_logs.msg_with_picture("Account Protection Information Page Available") 
                  gmail_login_page.done_button().Click() 
                  web_utils.wait_until_page_loaded(gvar.dataprep['page'])
               if gmail_login_page.inbox_link().Exists:
                 tc_logs.checkpt_with_picture("Able to Login to email application Successfully",500,gvar.dataprep['page']) 
               else:
                 tc_logs.error_with_picture("Unable to Login to Gmail: Login Page Not Available")    
            elif gmail_login_page.inbox_link().Exists:
                 tc_logs.checkpt_with_picture("Able to Login to email application Successfully",500,gvar.dataprep['page'])     
            else:
                tc_logs.error_with_picture("Unable to select the account: Test Failed")
    Delay(50000)
    web_utils.wait_until_page_loaded(gvar.dataprep['page'])
    web_utils.wait_until_page_loaded(gvar.dataprep['page'])
    if gmail_login_page.done_button().Exists:
       tc_logs.msg_with_picture("Account Protection Information Page Available") 
       gmail_login_page.done_button().Click() 
       web_utils.wait_until_page_loaded(gvar.dataprep['page'])
    if gmail_login_page.inbox_link().Exists:
        tc_logs.checkpt_with_picture("Able to Login to email application Successfully",500,gvar.dataprep['page'])
    else:
        tc_logs.error_with_picture("Unable to Login to Gmail: Login Page Not Available") 

  #logout from gmail       
  def logout(self):
      gvar.dataprep['page'].wait() 
      Delay(20000)  
      web_utils.wait_until_page_loaded(gvar.dataprep['page']) 
      gmail_home_page.google_account_dropdown().Click()    
      aqUtils.Delay(10000)
      gvar.dataprep['page'].Wait() 
      count = 5
      while count <= 0:
        if gmail_home_page.sign_out().Exists:
          gmail_home_page.sign_out().Click()
          web_utils.wait_until_page_loaded(gvar.dataprep['page']) 
          tc_logs.checkpt_with_picture("Successfully Logged out from Gmail Application",500,gvar.dataprep['page'])
          break
        else:
          count = count - 1
          if count == 0:
            tc_logs.error_with_picture("Unable to Find 'Sign out' Option in Gmail Application")
        
      
  @staticmethod    
  def place_file_to_localfolder(file_name,fldr_path,src_path):
        #creating folder
        file_system_utils.create_folder(fldr_path)
        
        #Delete file if it exists in the folder for testing
        file_system_utils.delete_file(fldr_path,file_name)
        
        #copy file to the folder created, to start testing
        file_system_utils.copy_file(src_path,fldr_path,file_name)       
        file_path = fldr_path+"\\"+file_name
        Log.Enabled=True
        Log.File(file_path, "Copied "+file_name+" File Successfully to Local Folder")
        Log.Enabled=False 
        delay(2000)
        return file_path
  
   #Attaching files in gmail  
  @staticmethod   
  def attach_files(file_path,file_name):
    
        gmail_home_page.attach_icon().Click()
        web_utils.wait_until_page_loaded(gvar.dataprep['page'])
        Delay(3000)
        gmail_home_page.upload_button_window().Keys(file_path)
        Delay(3000)
        web_utils.wait_until_page_loaded(gvar.dataprep['page'])
        gmail_home_page.upload_button_window().Keys("[Enter]")
        delay(4000)
        web_utils.wait_until_page_loaded(gvar.dataprep['page'])        
        if gmail_home_page.file_attachment(file_name).Exists:
          tc_logs.checkpt_with_picture("Attached Invoice Successfuly - "+file_name+": Mail Composed and Ready to Send",500,gvar.dataprep['page'])
        else:
          tc_logs.error_with_picture("Unable to Attach Invoice File"+file_path+" to the Email: Test Failed")
  
  #composing email and send to create batch in capture
  @staticmethod        
  def compose_email_wci(files,filepath,to_address,subject): 
      tc_logs.msg_with_picture("Compose New Email to Specified DL with attached invoice")
      if gmail_home_page.compose_email_button().Exists:
        gmail_home_page.compose_email_button().Click()
        if gmail_home_page.new_message().Exists:  
          gmail_home_page.to_textbox().Click()
          delay(2000)
          gmail_home_page.to_textbox().Keys(to_address)
          delay(3000)
          gmail_home_page.subject_textbox().Click()
          delay(3000)
          gmail_home_page.subject_textbox().keys(subject)
          delay(5000)
          tc_logs.checkpt_with_picture("Entered 'To' Address and 'Subject' Details Successfully ",500,gvar.dataprep['page'])   
          #attaching files
          for key in filepath:
            if(filepath[key]!=''):
              Gmail.attach_files(filepath[key],files[key])
          #Validate sent email
          gmail_home_page.send_button().Click()
          tc_logs.checkpt_with_picture("Successfully Sent Email with Attachment",500,gvar.dataprep['page'])
          if gmail_home_page.msg_sent_validation().Exists:
            tc_logs.validation("Successfully Validated 'Mail Sent' Confirmation Message")
          else:
            tc_logs.msg_with_picture("Unable to verify 'Mail Sent' confirmation message: Please check WCC Capture for Corresponding Batch File")
        else:
          tc_logs.error_with_picture("Unable to Find Message Frame Object")
      else:
        tc_logs.error_with_picture("Unable to Find Compose Object")