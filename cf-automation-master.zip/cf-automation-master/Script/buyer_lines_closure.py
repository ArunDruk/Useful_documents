﻿import receivables_lookups_form
import gvar
import tc_logs
import form_utility
import submit_single_request_form
import database_helper
import oracle_menus_form
import keys_utility

def set_manar_buyer_inv_calendar(wait_time = 5000):
  receivables_lookups_form.type_textfield().Keys("[F11]"+"MANAR_BUYER_INV_CALENDAR"+"^[F11]")
  receivables_lookups_form.code_required_textfield()[9].Keys("[F11]" + gvar.dataprep['auction_code'] + "^[F11]")
  receivables_lookups_form.descflexfield_popup()[9].Click()
  get_day_and_time_of_the_week(aqDateTime.Today(),aqDateTime.Time())
  aqUtils.Delay(wait_time)
  gvar.dataprep['jformobject'].Keys("^s")
  tc_logs.checkpt_with_picture("Calendar is saved Successfully"," ",gvar.dataprep['jformobject'])
  gvar.dataprep['jformobject'].Keys("^[F4]") 
   
def get_day_and_time_of_the_week(date,time,wait_time=5000):
  time = aqConvert.DateTimeToFormatStr(aqDateTime.AddMinutes(time,2),"%H:%M" " EST")
  if aqDateTime.GetDayOfWeek(date) == 1:
     receivables_lookups_form.sunday_text_field().Keys(time)
     keys_utility.press_tab_n_times(1)
  elif aqDateTime.GetDayOfWeek(date) == 2:
     receivables_lookups_form.monday_text_field().Keys(time)
     keys_utility.press_tab_n_times(7)
  elif aqDateTime.GetDayOfWeek(date) == 3:
     receivables_lookups_form.tuesday_text_field().Keys(time)
     keys_utility.press_tab_n_times(6)
  elif aqDateTime.GetDayOfWeek(date) == 4:
     receivables_lookups_form.wednesday_text_field().Keys(time)
     receivables_lookups_form.wednesday_text_field().Click()
  elif aqDateTime.GetDayOfWeek(date) == 5:
     receivables_lookups_form.thursday_text_field().Keys(time)
     keys_utility.press_tab_n_times(4)
  elif aqDateTime.GetDayOfWeek(date) == 6:
     receivables_lookups_form.friday_text_field().Keys(time)
     keys_utility.press_tab_n_times(3)
  elif aqDateTime.GetDayOfWeek(date) == 7:
     receivables_lookups_form.saturday_text_field().Keys("time")
     keys_utility.press_tab_n_times(2)
  else:
    tc_logs.error_with_picture("Unspecified day of the week. Please check according to today's date.")
  tc_logs.checkpt_with_picture(f"Time {time} is set for day {aqDateTime.GetDayOfWeek(date)} of the week","",gvar.dataprep['jformobject'])
  gvar.dataprep['jformobject'].Keys("[Tab]")
  aqUtils.Delay(wait_time)
  gvar.dataprep['jformobject'].Keys("~o")
  tc_logs.checkpt_with_picture("Calendar is set to run the MAN: AR Buyer Invoice Creation program Successfully!!"," ",gvar.dataprep['jformobject'])

def submit_buyer_invoice_creation_program(program_name = 'MAN: AR Buyer Invoice Creation Scheduled Program'):
  delay(30000)
#  gvar.dataprep['jformobject'].Keys("~vr"+"~n")
  form_utility.submit_single_request()
  submit_single_request_form.request_name_textfield().Keys(program_name)
  gvar.dataprep['jformobject'].Keys("[Tab]")
  submit_single_request_form.auction_location_textfield().Keys(gvar.dataprep['auction'] + "~o" +"~m")
  if(program_name == 'MAN: AR Buyer Invoice Creation'):#you need to set the calendar for the job
    request_id = str(1+int(form_utility.get_requestid()))#oracle_menus_form.decision_choicebox()
  else:
    request_id = form_utility.get_requestid()#oracle_menus_form.decision_choicebox()
    oracle_menus_form.no_button().Click()
    form_utility.get_specific_request_details(request_id)
  tc_logs.checkpt_with_no_picture(f"The request_id that is triggered for previous_request_id is: {request_id}")
  completed = database_helper.get_requestid_details(request_id,wait_time = 40000)
#  gvar.dataprep['jformobject'].Keys("~n")
#  if completed:
#    closed =  database_helper.verify_buyer_lines_status(gvar.dataprep['buyer_order'])
#    if closed:
#      tc_logs.validation(f"All buyer lines closed for the order: {gvar.dataprep['buyer_order']} Successfully")
  gvar.dataprep['jformobject'].Keys("^[F4]")
  wscript=Sys.OleObject["WScript.Shell"]  
  wscript.Run("taskkill.exe /F /IM jp2launcher.exe /T")
  wscript.Run("taskkill.exe /F /IM iexplore.exe /T") 
