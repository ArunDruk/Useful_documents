﻿from base import *
from driverchain import *
from ebiz import *
import test_utility
import gvar
import tc_logs

  
class Driver(Driverchain):
    global classarr,env
    
    def __init__(self):
      global test_env, sheet_obj, book     
      app = Sys.OleObject["Excel.Application"]
      Delay(1000)
      self.book = app.Workbooks.Open(Project.Path+"\\datasheets\\WCI\\wcc_us_coding_tc4.xls")   
      gvar.dataprep['book'] = self.book       
      app.Visible = "True"    
      self.test_env=BuiltIn.ParamStr(14)
      self.oper_unit=BuiltIn.ParamStr(15)
      self.test_env="oci_dev"
      self.oper_unit="us"
#      self.classarr=["capture_invoice_via_email()","ie_clear_cache()","WCC_Verify_batch_creation_email_V12()","ie_clear_cache()","WFR_Process_Email_Batches_V12()","WCC_Update_Batches_Coding_Form()"]
      self.classarr=["WCC_Update_Batches_Coding_Form()"]
      super().__init__(self.classarr)
      
    def close_excel(self):    
      self.book.save()
      delay(1000)
      self.book.close()
      
      
      
### Added utilities in the main method for Rally TestComplete API Integration (Pushing to GIT in TOGGLE:OFF mode)###
                         	
def main():
  try:
#      gvar.dataprep['env'] = 'oci_dev'
      obj=Driver()
#      test_utility.start_test(__name__.center(70,'*'),'Req2Check - CF','CODING','172804','prabha_wci_regression') 
      cobj = obj.run()
#      print('evoke test_utility')
  except:
      gvar.dataprep['verdict'] = 'Fail'
      tc_logs.header_name('Test Failed - traceback shown below')       
      tc_logs.error_with_no_picture(traceback.format_exc(),'')       
      print('evoke test_utility')
  finally:
      test_utility.end_test()
      obj.close_excel()
