﻿import gvar

### In this method objects for below pages have been captured ###

#PROCUREMENT > SUMMARY PAGE

def procurement_summary_page_link():
  prop_names = ["contentText","idStr","ObjectType"]
  prop_values = ["Summary","PA_PWP_SUBCONTRACTOR","Link"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def srch_supplier_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["SearchSupplierName","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def searchfullypaidinvoice_checkbox():
  prop_names = ["idStr","ObjectType","ObjectLabel"]
  prop_values = ["SearchfullyPaidInvoice","Checkbox","View Suppliers with Fully Paid Invoices"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def srch_supplier_go_button():
  prop_names = ["contentText","ObjectType"]
  prop_values = ["Go","Button"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def srch_supplier_clear_button():
  prop_names = ["contentText","ObjectType"]
  prop_values = ["Clear","Button"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
