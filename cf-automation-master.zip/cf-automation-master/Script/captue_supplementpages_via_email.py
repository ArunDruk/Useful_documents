﻿import web_utils
from ebiz import *


class captue_supplementpages_via_email(Ebiz):
  
  WCI_files="C:\\WCI_files"
  
  def goto_url(self,url):
   super().goto_url(self.testConfig['gmail']['urlemail'])

  def login(self):
    delay(2190)

    self.wait_until_page_loaded()
    
    if self.page.FindChild("contentText","Choose an accou*", 30).Exists:
      web_utils.log_checkpoint("Choose the Existing Account for the user...",500,self.page)
      self.page.FindChild("contentText", "caitestautomation user", 20).Click() 
      if self.page.FindChild("ObjectIdentifier","password",30).Exists:
         Indicator.Hide()
         self.page.FindChild("ObjectIdentifier","password",30).keys(self.testConfig['gmail']['password'])
         Indicator.Show()
         web_utils.log_checkpoint("Able to Enter Password Successfully",500,self.page)
         self.page.Keys("[Tab]")  
         self.page.FindChild("contentText", "Next", 60).Click()  
         self.wait_until_page_loaded() 
         if self.page.FindChild('contentText','Done',30).Exists:
            self.log_message_web("Account Protection Information Page Available") 
            self.page.FindChild('contentText','Done',30).Click() 
            self.wait_until_page_loaded()
         prop=['contentText','ObjectType']
         val = ['Inbox','Link']
         if self.page.FindChild(prop,val,60).Exists:
           web_utils.log_checkpoint("Able to Login to email application Successfully",500,self.page)
#           break 
         else:
           self.log_error_message("Unable to Login to Gmail: Login Page Not Available")          
      else:
         self.log_error_message("Unable to select the account: Test Failed")
    elif self.page.FindChild("idStr","identifierId",30).Exists:
         self.page.FindChild("idStr","identifierId",30).setText(self.testConfig['gmail']['userid_email'])
         web_utils.log_checkpoint("Able to Enter Username Successfully",500,self.page)
         self.page.Keys("[Tab]")  
         self.page.FindChild("contentText", "Next", 60).Click()  
         self.wait_until_page_loaded()                  
         if self.page.FindChild("ObjectIdentifier","password",30).Exists:
            Indicator.Hide()
            self.page.FindChild("ObjectIdentifier","password",30).keys(self.testConfig['gmail']['password'])
            Indicator.Show()
            web_utils.log_checkpoint("Able to Enter Password Successfully",500,self.page)    
    self.page.FindChild("contentText", "Next", 60).Click() 
    self.wait_until_page_loaded()
    if self.page.FindChild('contentText','Done',30).Exists:
       self.log_message_web("Account Protection Information Page Available") 
       self.page.FindChild('contentText','Done',30).Click() 
       self.wait_until_page_loaded()
#    prop=['contentText','ObjectType']
#    val = ['Inbox','Link']
#    if self.page.FindChild(prop,val,60).Exists:
#        web_utils.log_checkpoint("Able to Login to email application Successfully",500,self.page)
#    else:
#        self.log_error_message("Unable to Login to Gmail: Login Page Not Available") 
            
            
  def action(self,book):
    global val
    app = book.Sheets.item["mail_wcc"]   
    subject = "TestEmailBatch : "+aqConvert.DateTimeToFormatStr(aqDateTime.Time(),"%H:%M:%S")
    app.Cells.item[2,1]=VarToStr(subject)
    file_name1 = VarToStr(app.Cells.item[2,4])
    file_path1 = self.file_placement(file_name1)
    file_name2 = VarToStr(app.Cells.item[2,5])
    val = "False"
    if file_name2 != '':
      file_path2 = self.file_placement(file_name2)
      val = "True"    
    self.log_message_web("Compose New Email to Specified DL with attached invoice") 
    if self.page.EvaluateXpath("*//div[@class = 'nH']//div[contains(text(),'Compose')]")[0].Exists:
      self.page.EvaluateXpath("*//div[@class = 'nH']//div[contains(text(),'Compose')]")[0].Click()
      if self.page.EvaluateXpath("*//div[@class = 'M9']//div[@aria-label = 'New Message']")[0].Exists:  
        self.page.EvaluateXpath("*//div[@class = 'M9']//div//textarea[@aria-label = 'To']")[0].Click()
        delay(5000)
        self.page.EvaluateXpath("*//div[@class = 'M9']//div//textarea[@aria-label = 'To']")[0].Keys(app.Cells.item[2,6])
        delay(6000)
        self.page.EvaluateXpath("*//div[@class = 'M9']//div//input[@aria-label = 'Subject']")[0].Click()
        delay(5000)
        self.page.EvaluateXpath("*//div[@class = 'M9']//div//input[@aria-label = 'Subject']")[0].keys(subject)
        delay(5000)
        web_utils.log_checkpoint("Entered 'To' Address and 'Subject' Details Successfully ",500,self.page)
        self.attach_files(file_path1,file_name1)
        if val == "True":
          self.attach_files(file_path2,file_name2)
        self.page.EvaluateXpath("*//div[@class = 'M9']//div[contains(text(),'Send')]")[0].Click()
        web_utils.log_checkpoint("Successfully Sent Email with Attachment",500,self.page)
        if self.page.FindChild("contentText","Message sent*",30).Exists:
          web_utils.log_checkpoint("Successfully Validated 'Mail Sent' Confirmation Message",500,self.page)
        else:
          self.log_message_web("Unable to verify 'Mail Sent' confirmation message: Please check WCC Capture for Corresponding Batch File")
      else:
        self.log_error_message("Unable to Find Message Frame Object")
    else:
      self.log_error_message("Unable to Find Compose Object")
      
    
  def logout(self):
      self.page.wait() 
      Delay(2000)  
      self.wait_until_page_loaded() 
      self.page.EvaluateXPath("*//div//a[starts-with(@aria-label, 'Google Account:')]")[0].Click()    
      aqUtils.Delay(4000)
      self.page.Wait() 
      if self.page.EvaluateXPath("*//div/a[contains(text(),'Sign out')]")[0].Exists:
        self.page.EvaluateXPath("*//div/a[contains(text(),'Sign out')]")[0].Click()
        self.wait_until_page_loaded() 
        web_utils.log_checkpoint("Successfully Logged out from Gmail Applications",500,self.page)
      else:
        self.log_error_message("Unable to Find 'Sign out' Option in Gmail Applicaiton") 


        
        
  def file_placement(self,file_name):
        file_system_utils.create_folder(self.WCI_files)
        file = ("C:\\WCI_files",file_name)
        file_exist=aqFileSystem.FindFiles("C:\\WCI_files",file_name)
        if file_exist != None:
         aqFileSystem.DeleteFile("C:\\WCI_files\\"+file_name)
        aqFileSystem.CopyFile(Project.Path+"DataSheets\\WCI\\"+file_name, "C:\\WCI_files\\"+file_name)
        file_path = ("C:\\WCI_files\\"+file_name)
        Log.Enabled=True
        Log.File(file_path, "Copied "+file_name+" File Successfully to Local Folder")
        Log.Enabled=False 
        delay(2000)
        return file_path
        
  def attach_files(self,file_path,file_name):
        self.page.EvaluateXpath("*//div[@class = 'M9']//div[@aria-label= 'Attach files']")[0].Click()
     
        self.wait_until_page_loaded()
        #    file_system_utils.create_folder(self.op_log_path)             
        #    log_path=self.op_log_path+"\\Format Payment Instructions Program Output Is Attached_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
        Sys.Browser("iexplore").Window("#32770", "Choose File to Upload", 1).Keys(file_path)
        Delay(3000)
        self.wait_until_page_loaded()
        Sys.Browser("iexplore").Window("#32770", "Choose File to Upload", 1).Keys("[Enter]")
        delay(4000)
        self.wait_until_page_loaded()
        if self.page.EvaluateXpath("*//div[starts-with(@aria-label, 'Attachment: "+file_name+"')]")[0].Exists:
          web_utils.log_checkpoint("Attached Invoice Successfuly - "+file_name+": Mail Composed and Ready to Send",500,self.page)
        else:
          self.log_error_message("Unable to Attach Invoice File"+file_path+" to the Email: Test Failed")
    
def test():
        
   page = Sys.Browser("iexplore").page("*")
   page.EvaluateXPath("*//div//a[starts-with(@aria-label, 'Google Account:')]")[0].Click()  
   Log
