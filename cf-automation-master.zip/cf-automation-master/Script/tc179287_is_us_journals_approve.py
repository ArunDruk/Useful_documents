﻿from ebiz import *
import web_utils
import form_utils
import dbhelper
import file_system_utils


class tc179287_is_us_journals_approve(Ebiz):

 op_log_path ="C:\\TC_Logs"

 def login(self):
   self.login_user='ngeorge' #cglmgr Bbristow
   super().login()

 def goto_url(self,url):
   super().goto_url(self.testConfig['ebiz']['oci_is_url'])
   
 def action(self,book): 
    web_utils.log_checkpoint("Logged in to MAN Oracle Ebiz Instance Successfully",500,self.page)
    self.wait_until_page_loaded() 
    if ProjectSuite.Variables.currency =="USD": 
      app = book.Sheets.item["ManualJournal_USD"]
    elif ProjectSuite.Variables.currency=="CAD":
      app = book.Sheets.item["ManualJournal_CAD"]
    else:
      app = book.Sheets.item["Autocopy"]
    self.page.Wait()
    self.page.EvaluateXPath("//button[@id='NtfFullList']")[0].Click()
    self.page.Wait()
    web_utils.log_checkpoint("Click FullList Successful",500,self.page) 
    table_obj=self.page.EvaluateXPath("//table[@id='NtfWorklist:Content']")[0]
    tot_rows=table_obj.RowCount    
    web_utils.log_checkpoint("Total Number Of Open Notifications : " + VarToStr(tot_rows),500,self.page)    
    batch_name=VarToStr(app.Cells.Item[2,9])
    Delay(2000)
   
    for i in range(0,VarToInt(tot_rows)):
      subject=table_obj.FindChild("name","Cell("+aqConvert.VarToStr(i)+",3)",10).contentText
      Delay(2000)
      if batch_name in subject:   
        web_utils.log_checkpoint("Journal Name: "+ subject,500,self.page) 
        self.page.Find("idStr","N*:NtfSubject:"+aqConvert.VarToStr(i),30).Click()
        Delay(3000)
        web_utils.log_checkpoint("Found Journal Batch; Click 'Approve' next",500,self.page)     
        self.page.EvaluateXPath("//button[@title='Approve']")[0].Click()
        self.page.wait()
        break


