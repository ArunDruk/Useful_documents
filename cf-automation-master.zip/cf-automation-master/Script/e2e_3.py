﻿import gvar
import odm_datatype
import database_service
import login_logout_utility
import oracle_responsibility_utility
import form_utility
import tc_logs
import validate_queue_details
import title_change
import Inv_api_response_validation
import adjustments_api 
import traceback 

__ERROR = tc_logs.error_with_no_picture
__FIRE_ADJ_API     = adjustments_api.fire_payload
__CRDIT_MEMO       = adjustments_api.__Validate_Credit_Memo
__CRDIT_MEMO_TEST       = adjustments_api.__Validate_Credit_Memo_Test
__FIRE_INV_API     = Inv_api_response_validation.verify_arb_status
__ADJ_PARAMETERS = (('adjusment_api','seller_call_without_adj','Buyer Withdrew','Seller Buyback'),
                    ('adjusment_api','buyer_call_without_adj','Buyer Withdrew','Seller Buyback'))
def load_test_data():
    tc_logs.header_name("GET Test Data From ODM.")
    gvar.dataprep['env'] = BuiltIn.ParamStr(14)
    gvar.dataprep['auction'] = BuiltIn.ParamStr(15)
    gvar.load_environment_files()
    odm_datatype.load_test_data(odm_datatype.GENERAL_5M_DATA_SF)
    
    
def action():

    load_test_data()
    bw_sbb_without_adj()
  
def bw_sbb_without_adj():
    __FIRE_ADJ_API('adjusment_api','initiate_call')
    __FIRE_INV_API('INITIATED')
    for params in __ADJ_PARAMETERS:
      __FIRE_ADJ_API(*params)
      Delay(300000)
    __FIRE_INV_API('BUYER WITHDREW','SELLER BUYBACK') 
    __CRDIT_MEMO()
    
     
def end_of_test_case():
     odm_datatype.update_status('Comleted')
     
def Main():
 try: 
    tc_logs.test_name("Sample Test")
    action()
    end_of_test_case()
 except:
    odm_datatype.update_status('Failed')
    __ERROR(traceback.format_exc())
 
def test():
   t = [('INITIATED')('BUYER WITHDREW','SELLER BUYBACK')]
   b = t[0]
   Log.Message(b)

def test_credit_memo():
   gvar.dataprep['env'] = 'TRND'
   gvar.dataprep['auction'] = 'QIM5'
   gvar.load_environment_files()
   __CRDIT_MEMO_TEST()
