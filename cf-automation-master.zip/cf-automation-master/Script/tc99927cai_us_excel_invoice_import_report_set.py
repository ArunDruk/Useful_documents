﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils
import winscp_utility
import web_utils

####This testcase is to place the excel import file in the AP inbound directory using WINSCP### 
###and submit cai_excel_invoice_import_report_set, capture logs and output files###

class tc99927cai_us_excel_invoice_import_report_set(Ebiz):
 
 global inv_date,inv_num,rowno
 rowno = 2
 op_log_path="C:\\TC_Logs"
 exl_inv_files="C:\\Excel_Inv_Files"
 
 def login(self):
    self.login_user="ctucker"
    super().login()
 
 def action(self,book): 
    app = book.Sheets.item["Invoice"]
    self.add_invoice_details()
    self.place_inv_file_winscp(app)

# Modifying cai_excel_invoice_import_report_set.csv file 
 def add_invoice_details(self):
   Log.Enabled=True
   Log.Message("Inside add_invoice_details method")
   Log.Enabled=False   
   app1 = Sys.OleObject["Excel.Application"]
   Delay(1000)
   book = app1.Workbooks.Open(Project.Path+"\\DataSheets\\Oracle-AP-Other\\apinv_excel_invoice_import_report_set.csv")
#   app1.Visible = "True"
   app1.DisplayAlerts= 0
   app1 = book.Sheets.item["apinv_excel_invoice_import_repo"]
   rowno = 3
   self.inv_num = "EXCEL_INV"+aqConvert.DateTimeToFormatStr(aqDateTime.Time(),"%H:%M:%S")
   for i in range(0,2):
     app1.Cells.Item[rowno+i,2] = self.inv_num
     i = i+1 
   self.inv_date = aqDateTime.Today()
   app1.Cells.Item[rowno,7] = self.inv_date
   self.exp_date = aqDateTime.Today()
   app1.Cells.Item[rowno+1,26] = self.exp_date
   file_system_utils.create_folder(self.exl_inv_files)
   book.SaveAs("C:\\Excel_Inv_Files\\apinv_excel_invoice_import_report_set.csv")
   book.close()
   log_path = ("C:\\Excel_Inv_Files\\apinv_excel_invoice_import_report_set.csv")
   Log.Enabled=True
   Log.File(log_path, "Excel Invoice Import File Attached")
   Log.Enabled=False 
   

# Placing cai_excel_invoice_import_report_set.csv file in /DAUT2I/incoming/ATG_OU/AP_XLS_INV_UPLOAD folder
 def place_inv_file_winscp(self,app):
#    Stored_session = "opc@stage-fin-iad1-ebsapp1.private.stagefin.oraclevcn.com"
    Stored_session = "cai_oracle_apinvoices@mftstg.manheim.com"
    local_dir = "C:\\Excel_Inv_Files"
    remote_dir =  self.testConfig['winscp']['cai_remote_dir']  
#    remote_dir =  "//Outbox//TAUTRI"   
    upload_file_name = "apinv_excel_invoice_import_report_set.csv"
    winscp_utility.upload_file(Stored_session,local_dir,remote_dir,upload_file_name)
    Log.Enabled=True       
    Log.Message("cai_excel_invoice_import.csv file placed in the directory : "+remote_dir) # '//incoming//ATG_OU//AP_XLS_INV_UPLOAD' directory")           
    Log.Enabled=False

# Submitting the cai_excel_invoice_import_report_set in Oracle   
    self.page.WaitProperty("contentText","CAI US AP INVOICE PROCESSING",6000)
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" AP INVOICE PROCESSING')]") 
    self.log_message_web("Click 'CAI US AP INVOICE PROCESSING' - Successful")    
    self.page.keys("[Down]")
    Delay(1000)
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Invoices')]")
    self.log_message_web("Click 'Invoices' - Successful")
    delay(1000)  
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Entry')]")  
    self.log_message_web("Click 'Entry' - Successful")
    delay(1000)    
    self.page.EvaluateXPath("//div[text()='Invoices']")[1].Click()
    self.log_message_web("Click 'Invoices' - Successful")
    delay(2000) 
    web_utils.validate_security_box()
    delay(2000)
    jFrame=self.initializeJFrame() 
    Delay(2000)
    form_utils.click_ok_btn(jFrame)
    delay(2000)
#    jFrame.Keys("~o")
#    delay(9000)
    jFrame.FindchildEx("AWTComponentAccessibleName","Invoice Workbench (CAI US AP INVOICE PROCESSING)",True,60000).Click()
    delay(2000)
    self.log_message_oracle_form(jFrame,"Invoice Workbench form loaded Successfuly")
    jFrame.Keys("[F4]")
    delay(2000)
    jFrame.Keys("~v")
    delay(2000)
    jFrame.Keys("r")
    delay(2000)
    jFrame.Keys("~u")
    delay(4000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit Request Set","ExtendedFrame"]
    par_form=jFrame.FindChildEx(prop,val,60,True,60000)    
    par_form.Find("AWTComponentAccessibleName","Request Set RequiredList of Values",30).Keys("CAI Excel Invoice Import")
    delay(1000)
    self.log_message_oracle_form(jFrame,"Request Set Name: 'CAI Excel Invoice Import' entered successfully")
    par_form.Find("AWTComponentAccessibleName","Request Set RequiredList of Values",30).Click()
    par_form.Find("AWTComponentAccessibleName","Request Set RequiredList of Values",30).Keys("[Tab]")
    delay(1000)
    jFrame.Keys("[Tab]")
    jFrame.Keys("[Tab]")
    Delay(2000)
    jFrame.Keys("apinv_excel_invoice_import_report_set.csv.gpg")
    jFrame.Keys("~o")
    delay(2000) 
    
    par_form.Find("wText","CAI File Decrypt Program",30).Click()
    jFrame.Keys("[Tab]")
    delay(1000)
    jFrame.Keys("[BS]")
    jFrame.Keys("Y")
    delay(1000)
    jFrame.Keys("~o")
    
    delay(2000)
    par_form.Find("wText","CAI AP Invoices Staging",30).Click()
    jFrame.Keys("[Tab]")
    delay(1000)
    jFrame.Keys("~o")
    
    delay(2000)
    par_form.Find("wText","CAI Payables Invoice Import",30).Click()
    jFrame.Keys("[Tab]")
    delay(1000)
    jFrame.Keys("EXCEL")
    Delay(1000)
    jFrame.Keys("~o")
    delay(2000)
    self.log_message_oracle_form(jFrame,"Parameter Values for 'CAI Excel Invoice Import' entered successfully")
#    jFrame.Keys("~m")
    par_form.FindChild("AWTComponentAccessibleName","Submit alt m",10).Click()
    delay(2000)
    RequestID = aqConvert.VarToInt(''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit()))    
    Log.Message("Request ID Of  " + aqConvert.VarToStr(RequestID))
    self.log_checkpoint_message_web("Request ID Of CAI Excel Invoice Import (Report Set) is " + aqConvert.VarToStr(RequestID))    
    delay(1000)   
    
    jFrame.Keys("~n")
    delay(2000)
    jFrame.Keys("~i")
    delay(2000)
    
    dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
    user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
    pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
    dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,aqConvert.VarToStr(RequestID)) 
    
# Gathering Request ID and Output File for the "CAI Inbound Global File Validation Program"  
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,90000)
    self.req_set_save_log(jFrame,req_form,"CAI Inbound Global File Validation Program",RequestID)
#    jFrame.Click()
#    Delay(2000)
#    jFrame.Keys("[F4]")
#    Delay(1000)
#    jFrame.Keys("~v")
#    Delay(1000)
#    jFrame.Keys("r")
#    Delay(1000)
#    jFrame.Keys("~i")
    Delay(1000)

# Gathering Request ID and Output File for the "CAI AP Invoices Staging Program"  
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,90000)
    self.req_set_save_log(jFrame,req_form,"CAI AP Invoices Staging",RequestID)
#    jFrame.Click()
#    Delay(2000)
#    jFrame.Keys("[F4]")
#    Delay(1000)
#    jFrame.Keys("~v")
#    Delay(1000)
#    jFrame.Keys("r")
#    Delay(1000)
#    jFrame.Keys("~i")
    Delay(1000)

# Gathering Request ID and Output File for the "CAI Payables Invoice Import Program"  
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,90000)
    self.req_set_save_log(jFrame,req_form,"CAI Payables Invoice Import",RequestID)
#    jFrame.Click()
#    Delay(2000)
#    jFrame.Keys("[F4]")
#    Delay(1000)
#    jFrame.Keys("~v")
#    Delay(1000)
#    jFrame.Keys("r")
#    Delay(1000)
#    jFrame.Keys("~i")
    Delay(1000)

# Gathering Request ID and Output File for the "CAI Excel Invoice Import (Report Set) program" 
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,90000)
    self.req_set_save_log(jFrame,req_form,"CAI Excel Invoice Import (Report Set)",RequestID)
    Delay(1000)
    dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
    user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
    pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
    inv_no = dbhelper.verify_excel_invoice_info(dsn,user_id,pwd,self.inv_num)
    app.Cells.Item[rowno,13] = inv_no
    web_utils.close_additional_browsers()
#    Sys.Browser("iexplore").page("https://*ebs.coxautoinc.com/forms/frmservlet*").Close()
    Delay(1000)
    jFrame.Click()
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~o")
    Delay(1000)
#    self.close_forms(jFrame)
#    Delay(4000)
    
##    Sys.Browser("iexplore").page("https://*ebs.coxautoinc.com/forms/frmservlet*").Close()
#    self.page.EvaluateXPath("//div[text()='Invoices']")[1].Click()
#    self.log_message_web("Click 'Invoices' - Successful")
#    delay(20000) 
#    jFrame=self.initializeJFrame() 
#    Delay(10000)
#    form_utils.click_ok_btn(jFrame)
#    Delay(6000)
#    jFrame.Keys("~v")
#    delay(2000)
#    jFrame.Keys("f")
#    delay(2000)
#    
#   #Finding Invoice that needs to be accounted
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Find Invoices","ExtendedFrame"]
#    par_form=jFrame.FindChildEx(prop,val,60,True,60000)
#    par_form.Find("AWTComponentAccessibleName","Invoice: Number",10).Click()
#    delay(3000)
#    par_form.Find("AWTComponentAccessibleName","Invoice: Number",10).Keys(app.Cells.Item[rowno,13])
#    jFrame.Keys("[Tab]")
##    jFrame.Keys("[Tab]")
##    jFrame.Keys("[Tab]")
##    jFrame.Keys("[Tab]")
##    jFrame.Keys("[Tab]")
##    jFrame.Keys("[Tab]")
##    jFrame.Keys("[Tab]")
##    jFrame.Keys("[Tab]")
##    jFrame.Keys("[Tab]")
##    jFrame.Keys(aqConvert.DateTimeToFormatStr(aqDateTime.Today(),"%d-%b-%Y"))
##    jFrame.Keys("[Tab]")
##    jFrame.Keys(aqConvert.DateTimeToFormatStr(aqDateTime.Today(),"%d-%b-%Y"))
#    delay(5000) 
#    jFrame.Keys("~i")
#    Delay(8000)
#    self.log_message_oracle_form(jFrame,"'Invoice Workbench' form launched successfully")
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Invoice Workbench*","ExtendedFrame"]
#    invoice=jFrame.FindChildEx(prop,val,60,True,60000)
#    self.log_message_oracle_form(jFrame,"Click on 'Lines' on 'Invoice Workbench' next")
#    Delay(5000)
#    invoice.FindChild("AWTComponentName","FormsTabPanel*",60).ClickTab("2 Lines")
#    Delay(5000)
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Open Folder*","VButton"]
#    open_fldr_form=jFrame.FindChildEx(prop,val,30,True,60000)
#    open_fldr_form.Click()
#    Delay(6000)
##    jFrame.Keys("s")
#    jFrame.Keys("p")
#    delay(5000)
#    Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications - EBS", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("FWindow", "Open Folder", 0).AWTObject("LWComponent", "", 0).AWTObject("EwtContainer", "", 0).AWTObject("ButtonBar", "", 0).AWTObject("ButtonBar", "", 1).AWTObject("PushButton", "OK ALT O", 0).Click()
#    delay(3000)
#    jFrame.Keys("[F4]")
#    Delay(1000)
#    jFrame.Keys("[F4]")
#    Delay(1000)
#    jFrame.Keys("~o")

    

 def req_set_save_log(self,jFrame,req_form,srch_child_name,Preqid):
    self.log_message_oracle_form(req_form,"Checking for "+aqConvert.VarToStr(srch_child_name)+ " Child Program Status")
    req_form.FindChild("AWTComponentAccessibleName","Refresh Data alt R",20).Click()
    i=20
    for x in range(1,180):     
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Name",i]
        child_name=req_form.Find(prop,val,10).wText 
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Phase",i+20]
        phase=req_form.Find(prop,val,10).wText 
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Request ID",i-10]
        creqid= aqConvert.VarToInt(req_form.Find(prop,val,10).wText)
#        self.log_message_oracle_form(req_form,"Request ID of "+aqConvert.VarToStr(srch_child_name)+" is "+aqConvert.VarToStr(creqid))                                         
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Status",i+30]         
        status =req_form.FindChild(prop,val,60)            
        if (child_name==srch_child_name) and (creqid>=Preqid) and (phase == "Completed"):
            self.log_message_oracle_form(req_form, aqConvert.VarToStr(srch_child_name)+" Phase Completed Successfuly")           
#            self.verify_aqobject_chkproperty(status,"wText",cmpContains,"Normal")        
            status.Keys("[Enter]")
            Delay(1000)
#            jFrame.Keys("~g")  
            req_form.FindChild("AWTComponentAccessibleName","View Log alt K",20).Click()    
            Delay(3000)
            output_page=Sys.Browser("iexplore").Page("https://core*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.*")
            output_page.Click()
            Delay(2000)
            output_page.Keys("~f")
            Delay(2000)
            output_page.Keys("a")
            Delay(5000)
            file_system_utils.create_folder(self.op_log_path)             
            self.log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"File"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"_%d%b%Y_%H%M")+".txt"    
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(self.log_path)
            Delay(1000)
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
            Delay(8000)
            Log.Enabled=True
            Log.File(self.log_path, aqConvert.VarToStr(srch_child_name)+" is Completed And Log file is attached")
            Log.Enabled=False     
            web_utils.close_additional_browsers()         
            Filesaved = 'True'
            return                           
        elif i >=29:
           Delay(15000)           
           req_form.FindChild("AWTComponentAccessibleName","Refresh Data alt R",20).Click()
           Delay(3000)
           i=20
           val=["Name",i]
           child_name=req_form.Find(prop,val,10).wText
        else:  
           Delay(2000)
           i=i+1 
    




