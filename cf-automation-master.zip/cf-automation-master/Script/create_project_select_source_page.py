﻿import gvar

### In this method objects for below pages have been captured ###

#CREATE PROJECT: SELECT SOURCE PAGE

def create_prj_select_source_text():
  prop_names = ["innerHTML","ObjectType"]
  prop_values = ["Create Project: Select Source","TextNode"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def copy_from_dropdown():
  prop_names = ["idStr", "ObjectType"]
  prop_values = ["copyAttachChoice", "Select" ]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def search_operating_unit_textfeild():
  prop_names = ["idStr", "ObjectType"]
  prop_values = ["OperatingUnitName", "Textbox" ]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def search_name_textfeild():
  prop_names = ["idStr", "ObjectType"]
  prop_values = ["TemplateName1", "Textbox" ]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def search_number_textfeild():
  prop_names = ["idStr", "ObjectType"]
  prop_values = ["TemplateNumber", "Textbox" ]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def search_project_type_textfeild():
  prop_names = ["idStr", "ObjectType"]
  prop_values = ["ProjectType", "Textbox" ]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
  

def search_org_textfeild():
  prop_names = ["idStr", "ObjectType"]
  prop_values = ["Organization", "Textbox" ]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def go_button():
  prop_names = ["contentText", "ObjectType"]
  prop_values = ["Go", "Button" ]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

################## Page objects for Project template table ##############################

def select_record_radiobutton():
  prop_names = ["ObjectIdentifier", "ObjectType"]
  prop_values = ["selected", "RadioButton" ]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def clear_button():
  prop_names = ["contentText", "ObjectType"]
  prop_values = ["Clear", "Button" ]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
  

def cancel_button():
  prop_names = ["contentText", "ObjectType"]
  prop_values = ["Cancel", "Button" ]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
  

def continue_button():
  prop_names = ["idStr", "ObjectType"]
  prop_values = ["Continue", "Button" ]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
  

def refresh_table_button():
  prop_names = ["ObjectIdentifier", "ObjectType"]
  prop_values = ["tablerefresh_ena_png", "Image" ]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
  

def reset_table_settings_button():
  prop_names = ["idStr", "ObjectIdentifier"]
  prop_values = ["reset:dis:TemplateListTable", "TemplateListTable" ]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
  

def table_setting_button():
  prop_names = ["ObjectIdentifier", "ObjectType"]
  prop_values = ["action_ena_png", "Image" ]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
  

def column_freeze_button():
  prop_names = ["idStr", "ObjectIdentifier"]
  prop_values = ["freeze:dis:TemplateListTable", "TemplateListTable" ]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
  

def inspect_mds_contents_button():
  prop_names = ["contentText", "ObjectType"]
  prop_values = ["Inspect MDS Contents", "Button" ]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


