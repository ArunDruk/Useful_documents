﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils


class tc159959_cai_us_autocopy_journals(Ebiz): 
 global rowno
 op_log_path="C:\\TC_Logs"
 
 
 def login(self):
   self.login_user='mfallwell'
   super().login()
   
 def action(self,book): 
    app = book.Sheets.item["Autocopy"]
    
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI ALL GL JOURNAL PROCESSING')]")
    Delay(3000)
    self.page.EvaluateXpath("//table[@id='respList']//div[text()='Enter Journals']")[0].Click()
    self.log_message_web("Click 'Enter Journals'- Successful")
    
    web_utils.validate_security_box()
    Delay(20000)
    jFrame=self.initializeJFrame()
    Delay(8000)
    
    form_utils.click_ok_btn(jFrame)
    Delay(5000) 
    
    mon_yr = aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%b-%y")
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Journals","ExtendedFrame"]
    fnd_jrnl=jFrame.FindChildEx(prop,val,60,True,90000)
    
    fnd_jrnl.Find("AWTComponentAccessibleName","SourceList of Values",10).Click()
    fnd_jrnl.Find("AWTComponentAccessibleName","SourceList of Values",10).Keys("Spreadsheet")
    delay(1000) 
    
    fnd_jrnl.Find("AWTComponentAccessibleName","Status: PostingList of Values",10).Click()
    fnd_jrnl.Find("AWTComponentAccessibleName","Status: PostingList of Values",10).Keys("Posted")
    delay(1000) 
    
    fnd_jrnl.Find("AWTComponentAccessibleName","PeriodList of Values",10).Click()
#    fnd_jrnl.Find("AWTComponentAccessibleName","PeriodList of Values",10).Keys(mon_yr)  #MAY-20
    fnd_jrnl.Find("AWTComponentAccessibleName","PeriodList of Values",10).Keys("MAY-20")
    
    self.log_checkpoint_message_web("Parameters entered for selecting journal")
# Find Journal
    jFrame.Keys("~i")
    delay(8000)
    
    dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
    user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
    pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
    appr_amount = dbhelper.get_journal_approval_limit(dsn,user_id,pwd)
    
    prop=["JavaClassName","AWTComponentAccessibleName"]
    val=["ExtendedFrame","Enter Journals (CAI ALL LEDGERS)"]
    ent_jrnl = jFrame.FindChildEx(prop,val,20,True,10000)
    
    for x in range(128,143):
       prop=["JavaClassName","AWTComponentAccessibleName","AWTComponentIndex"]
       val=["VTextField","Journal Debit",x]
       jrnl_debit = jFrame.FindChild(prop,val,20).wText
       
       if (jrnl_debit is not None) and (aqConvert.VarToInt(jrnl_debit) >= aqConvert.VarToInt(appr_amount)):
         break
       ent_jrnl.Keys("[Down]")        
    self.log_checkpoint_message_web("Journal found successfully")

    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["AutoCopy... alt y","Button"]
    jFrame.FindChild(prop,val,60).Click()
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["AutoCopy Batch","ExtendedFrame"]
    autocpy_batch_wnd = jFrame.FindChildEx(prop,val,60,True,10000)
    
    batch_name = "Test_Auto"+ aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"_%d%b%Y_%H%M")
    app.Cells.Item[2,9] = VarToStr(batch_name)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Batch Required","VtextField"]
    autocpy_batch_wnd.FindChild(prop,val,10).Keys(batch_name)
    
    self.log_checkpoint_message_web("Parameters entered for Autocopying journal")
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["OK","Button"]
    autocpy_batch_wnd.FindChild(prop,val,10).Click()
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Note Your concurrent request ID is*","ChoiceBox"]
    note_wnd = jFrame.FindChildEx(prop,val,10,True,10000)
    
    RequestID = aqConvert.VarToInt(''.join(x for x in note_wnd.AWTComponentAccessibleName if x.isdigit()))
    self.log_checkpoint_message_web("Request ID of AutoCopy " + aqConvert.VarToStr(RequestID))
    Delay(2000)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["OK ALT O","FormButton"]
    note_wnd.FindChild(prop,val,10).Click()
    
    dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,VarToStr(RequestID))
    
    form_utils.save_log_singlereq(self,jFrame,self.op_log_path,"Autocopy Journals",RequestID)
    web_utils.close_additional_browsers()
    Delay(2000)
    
    jFrame.Keys("[F4]")
    Delay(2000)
    jFrame.Keys("[F4]")
    Delay(2000)
    
    navigator_form = Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("ExtendedFrame", "Navigator - *", 4).AWTObject("LWComponent", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("FScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("DrawnPanel", "", 0).AWTObject("FormsTabPanel", "", 0).AWTObject("TabPanelSheet", "", 0).AWTObject("FScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("DrawnPanel", "", 0).AWTObject("VTList", "Function List", 0).AWTObject("ScrollBox", "", 0).AWTObject("LWDataSourceList$Content", "", 0)
    OCR.Recognize(navigator_form).BlockByText("Enter Journals").DblClick()
    Delay(1000)
    
#    jFrame.Keys("~o")
#    delay(2000)
       
    self.log_message_oracle_form( jFrame,"Enter Journals")
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Journals","ExtendedFrame"]
    fnd_jrnl=jFrame.FindChildEx(prop,val,60,True,90000)
    
    fnd_jrnl.Find("AWTComponentAccessibleName","BatchList of Values",10).Click()
    fnd_jrnl.Find("AWTComponentAccessibleName","BatchList of Values",10).Keys(batch_name)
    delay(1000) 
    
    fnd_jrnl.Find("AWTComponentAccessibleName","SourceList of Values",10).Click()
    fnd_jrnl.Find("AWTComponentAccessibleName","SourceList of Values",10).Keys("Autocopy")
    delay(1000) 
    
#    fnd_jrnl.Find("AWTComponentAccessibleName","CurrencyList of Values",10).Click()
#    fnd_jrnl.Find("AWTComponentAccessibleName","CurrencyList of Values",10).Keys(ProjectSuite.Variables.currency)
#    delay(1000)
    
#    fnd_jrnl.Find("AWTComponentAccessibleName","PeriodList of Values",10).Click()
##    fnd_jrnl.Find("AWTComponentAccessibleName","PeriodList of Values",10).Keys(mon_yr)
#    fnd_jrnl.Find("AWTComponentAccessibleName","PeriodList of Values",10).Keys("MAY-20")
    
    self.log_checkpoint_message_web("Parameters entered for selecting Autocopied journal")
    jFrame.Keys("~i")
    delay(8000)
    
    prop=["JavaClassName","AWTComponentAccessibleName"]
    val=["ExtendedFrame","Enter Journals (CAI ALL LEDGERS)"]
    ent_jrnl = jFrame.FindChildEx(prop,val,20,True,10000)
    self.log_checkpoint_message_web("Autocopied Journal found successfully")
    
    prop=["JavaClassName","AWTComponentAccessibleName"]
    val=["Button","Approve alt A"]
    ent_jrnl.FindChild(prop,val,20).Click()
    
    prop=["JavaClassName","AWTComponentAccessibleName"]
    val=["ChoiceBox","Note*"]
    note_wndow = jFrame.FindChildEx(prop,val,20,True,10000)
    self.log_checkpoint_message_web("Autocopied Journal sent for approver successfully")
    
    prop=["JavaClassName","AWTComponentAccessibleName"]
    val=["FormButton","OK ALT O"]
    note_wndow.FindChild(prop,val,20).Click()
    
    jFrame.Close()
    delay(1000)
    jFrame.Close()
    delay(1000)
    jFrame.Keys("~o")
    
    
    
    
        
    
    

    
    
    
    
 
    
    

    
