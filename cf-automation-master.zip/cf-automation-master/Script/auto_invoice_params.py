﻿import gvar
import form_utility

def autoinvoice_master_program_pramas_window():
    prop_names = ("AWTComponentAccessibleName","JavaClassName")
    prop_values = ("Parameters","FlexWindow")
    parameters_window = gvar.dataprep['jformobject'].FindChildEx(prop_names,prop_values,20,True,5000)
    return parameters_window
    
def invoice_source_textfield(parameters_window):
    prop_names = ("AWTComponentAccessibleName","JavaClassName")
    prop_values = ("Invoice Source*","FlexTextField")
    return parameters_window.FindChildEx(prop_names,prop_values,20,True,2000)
  
def date_textfield(parameters_window):
    prop_names = ("AWTComponentAccessibleName","JavaClassName")
    prop_values = ("Default Date*","FlexTextField")
    return parameters_window.FindChildEx(prop_names,prop_values,20,True,2000)
  
def order_no_low(parameters_window):
    prop_names = ("AWTComponentAccessibleName","JavaClassName")
    prop_values = ("(Low) Sales Order Number*","FlexTextField")
    return parameters_window.FindChildEx(prop_names,prop_values,20,True,2000)
  
def order_no_high(parameters_window):
    prop_names = ("AWTComponentAccessibleName","JavaClassName")
    prop_values = ("(High) Sales Order Number*","FlexTextField")
    return parameters_window.FindChildEx(prop_names,prop_values,20,True,2000)
    
def ok_button(parameters_window):
    prop_names = ("AWTComponentAccessibleName","JavaClassName")
    prop_values = ("OK ALT O","FormButton")
    return parameters_window.FindChildEx(prop_names,prop_values,20,True,2000)
    


