﻿import gvar

##find requests frame
def find_requests_extended_frame():
  return gvar.dataprep['jformobject'].Find('AWTComponentAccessibleName','Find Requests',5000)
  
def specific_requests_radio_btn():
  return gvar.dataprep['jformobject'].Find('AWTComponentAccessibleName','What type of Requests do you want to find? Specific Requests alt S',5000)
  
def requestid_textfield():
  param_names = ['AWTComponentAccessibleName','AWTComponentIndex']
  param_values = ['Request ID',0]
  return gvar.dataprep['jformobject'].Find(param_names,param_values,5000)

def submit_new_request_button():
  return gvar.dataprep['jformobject'].Find('AWTComponentAccessibleName','Submit a New Request... alt N',5000)

def name_textfield():
  prop_names = ["AWTComponentAccessibleName","AWTComponentIndex","JavaClassName"]
  prop_values = ["Name",1,"VTextField"]
  return gvar.dataprep['jformobject'].FindChild(prop_names,prop_values,5000)
  
def find_button():
  prop_names = ["AWTComponentAccessibleName","AWTComponentIndex","JavaClassName"]
  prop_values = ["Find alt i",3,"Button"]
  return gvar.dataprep['jformobject'].FindChild(prop_names,prop_values,5000)

