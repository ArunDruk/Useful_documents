﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils
import winscp_utility


class tc155635_cai_us_costar_payment_outbound_extract(Ebiz):
 
 op_log_path="C:\\TC_Logs"
 
 def login(self):
    self.login_user="ctucker"
    super().login()
 
 def action(self,book):
    app = book.Sheets.item["Invoice"]
    global inv_num,rowno
    rowno = 2

# Submitting the CAI CoStar Payment Outbound Extract Request in Oracle

    Log.Message("Inside action...") 
    self.page.WaitProperty("contentText","CAI "+self.oper_unit+" AP JOB SCHEDULER",6000)
    cai_ap_invpro_link=self.page.Find("contentText","CAI "+self.oper_unit+" AP JOB SCHEDULER",30)
    self.verify_aqobject_chkproperty(cai_ap_invpro_link,"contentText",cmpIn,"CAI "+self.oper_unit+" AP JOB SCHEDULER")
    cai_ap_invpro_link.Click() 
    self.log_message_web("Click 'CAI "+self.oper_unit+" AP JOB SCHEDULER' - Successful")
    delay(1000)
    self.page.keys("[Down]")
    cai_inv_ent_link=self.page.Find("contentText","Submit Request",30)
    self.verify_aqobject_chkproperty(cai_inv_ent_link,"contentText",cmpIn,"Submit Request")
    cai_inv_ent_link.Click() 
    self.log_message_web("Click 'Submit Request' - Successful") 
    jFrame=self.initializeJFrame() 
    Delay(10000)
    form_utils.click_ok_btn(jFrame) 
    Delay(3000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit a New Request","ExtendedFrame"]
    submit_req_form=jFrame.FindChildEx(prop,val,30,True,60000)
    submit_req_form.FindChild("AWTComponentAccessibleName","OK alt O",10).Click()
    delay(2000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit Request","ExtendedFrame"]
    par_form=jFrame.FindChildEx(prop,val,60,True,60000)
    par_form.Find("AWTComponentAccessibleName","Name RequiredList of Values",30).Keys("CAI CoStar Payment Outbound Extract")
    delay(1000)
    jFrame.Keys("[Tab]")
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Parameters","FlexWindow"]
    par_form=jFrame.FindChildEx(prop,val,60,True,60000)
    icon_button=par_form.Find("JavaClassName","IconButton",30)
    Sys.HighlightObject(icon_button)
    icon_button.Click()
    delay(3000)
#    par_form.Find("AWTComponentAccessibleName","Operating Unit REQUIRED List Values",30).SetText("CAI SHARED SERVICES OU")
#    delay(2000)
#    jFrame.Keys("[Tab]")
    jFrame.Keys("~o")
#    par_form.Find("AWTComponentAccessibleName","Payment From Date",30).Click()
#    par_form.Find("AWTComponentAccessibleName","Payment From Date",30).Keys(aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d-%b-%Y"))
#    delay(2000) 
#    jFrame.Keys("[Tab]")
    delay(2000)
    par_form.Find("AWTComponentAccessibleName","OK ALT O",30).Click()
#    jFrame.Keys("~o")
    delay(2000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit Request","ExtendedFrame"]
    submit_req_form=jFrame.FindChildEx(prop,val,30,True,60000)
    submit_req_form.FindChild("AWTComponentAccessibleName","Submit alt m",10).Click()
#    self.log_message_web("Click Submit Successful") 
    delay(1000)
    self.log_message_oracle_form(jFrame,"'CAI CoStar Payment Outbound Extract' is submitted")   
    RequestID = ''.join(x for x in jFrame.find("AWTComponentAccessibleName","Request submitted*",100).AWTComponentAccessibleName if x.isdigit())
    self.log_message_oracle_form(jFrame,"Request ID Of 'CAI CoStar Payment Outbound Extract' is " + aqConvert.VarToStr(RequestID))
    delay(1000)    
    jFrame.Keys("~n")
    delay(1000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000)    
    
#Checking in the DB for the completion of the concurrent programs
    dsn = self.testConfig['oracle_db']['dsn']
    user_id = self.testConfig['oracle_db']['userid']
    pwd = self.testConfig['oracle_db']['pwd']
    dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,VarToStr(RequestID)) 
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,90000)  
    file_format = "output"
    self.req_set_save_file(jFrame,req_form,"CAI CoStar Payment Outbound Extract",RequestID,file_format)
    Delay(1000)
#    web_utils.close_additional_browsers()
#    Delay(1000)
#    jFrame.Click()
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,90000)
    file_format = "log"
    self.req_set_save_file(jFrame,req_form,"CAI:Transfer files to Sterling (CAI: Transfer files to Sterling)",RequestID,file_format)
    Delay(1000)
    fo=open(self.log_path,"r")
    lines=fo.readlines()
    Log.Enabled=True
    Log.Message("Outbound Extract Information : - "+lines[5][0:64].strip())
    Log.Message(lines[12][0:112].strip())
    Log.Message(lines[13][0:112].strip())
    Log.Message(lines[14][0:62].strip())
    Log.Message(lines[15][0:54].strip())
    Log.Message(lines[16][0:79].strip())
    Log.Message(lines[17][0:60].strip())
    Log.Message(lines[18][0:94].strip())
    Log.Message(lines[19][0:59].strip())
    Log.Message(lines[21][0:72].strip())
    Log.Message(lines[22][0:78].strip())
    Log.Message(lines[24][0:78].strip())
    Log.Message(lines[26][0:234].strip())
    Log.Message(lines[27][0:158].strip())
    Log.Message(lines[28][0:68].strip())
    Log.Message(lines[29][0:72].strip())
    Log.Enabled=False
    Delay(2000)
    jFrame.Click()
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~o")

        
    

 def req_set_save_file(self,jFrame,req_form,srch_child_name,Preqid,file_format):
      self.log_message_oracle_form(req_form,"Checking for "+aqConvert.VarToStr(srch_child_name)+ " Child Program Status")
      req_form.FindChild("AWTComponentAccessibleName","Refresh Data alt R",20).Click()
      i=20
      for x in range(1,180):     
          prop=["AWTComponentAccessibleName","AWTComponentIndex"]
          val=["Name",i]
          child_name=req_form.Find(prop,val,10).wText 
          prop=["AWTComponentAccessibleName","AWTComponentIndex"]
          val=["Phase",i+20]
          phase=req_form.Find(prop,val,10).wText 
          prop=["AWTComponentAccessibleName","AWTComponentIndex"]
          val=["Request ID",i-10]
          creqid= aqConvert.VarToInt(req_form.Find(prop,val,10).wText)
  #        self.log_message_oracle_form(req_form,"Request ID of "+aqConvert.VarToStr(srch_child_name)+" is "+aqConvert.VarToStr(creqid))                                         
          prop=["AWTComponentAccessibleName","AWTComponentIndex"]
          val=["Status",i+30]         
          status =req_form.FindChild(prop,val,60)            
          if (child_name==srch_child_name) and (creqid>=VarToInt(Preqid)) and (phase == "Completed"):
              self.log_message_oracle_form(req_form, aqConvert.VarToStr(srch_child_name)+" Phase Completed Successfuly")             
  #            self.verify_aqobject_chkproperty(status,"wText",cmpContains,"Normal")        
              status.Keys("[Enter]")
              Delay(1000)
  #            jFrame.Keys("~g")  
              if file_format == "log":
                req_form.FindChild("AWTComponentAccessibleName","View Log alt K",20).Click()
              elif file_format == "output":
                req_form.FindChild("AWTComponentAccessibleName","View Output alt p",20).Click()  
              Delay(3000)
              output_page=Sys.Browser("iexplore").Page("https://core*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.*")
              output_page.Click()
              Delay(2000)
              output_page.Keys("~f")
              Delay(2000)
              output_page.Keys("a")
              Delay(5000)
              file_system_utils.create_folder(self.op_log_path)             
              self.log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"File"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"_%d%b%Y_%H%M")+".txt"    
              Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(self.log_path)
              Delay(1000)
              Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
              Delay(2000)
              Log.Enabled=True
              Log.File(self.log_path, aqConvert.VarToStr(srch_child_name)+" Log/Output File Attached")
              Log.Enabled=False     
              Sys.Browser("iexplore").Page("https://core*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.*").Close()
              Filesaved = 'True'
              web_utils.close_additional_browsers()
              Filesaved = 'True'
              return                           
          elif i >=28:
             Delay(20000)
  #           req_form.keys("~r")
             req_form.FindChild("AWTComponentAccessibleName","Refresh Data alt R",20).Click()
             Delay(3000)
             i=20
             val=["Name",i]
             child_name=req_form.Find(prop,val,10).wText
  
          else:  
             Delay(3000)
             i=i+1 

             
