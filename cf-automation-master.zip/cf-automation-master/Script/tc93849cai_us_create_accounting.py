﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils
import web_utils

#This testcase is to submit create accounting and getting journal batch name from the output

class tc93849cai_us_create_accounting(Ebiz):
 global rowno
 rowno = 2

 def login(self):
    self.login_user="rmaran"
    super().login()
 
 op_log_path="C:\\TC_Logs"
 
 def action(self,book): 
    app = book.Sheets.item["Invoice"]
    self.wait_until_page_loaded()
    Log.Message("Inside action...")
     
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" AP INVOICE PROCESSING')]") 
    self.log_message_web("Click 'CAI "+self.oper_unit+" AP INVOICE PROCESSING' - Successful")  
    Delay(1000)  
    self.wait_until_page_loaded()
                  
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Invoices')]")
    Delay(1000)
    self.wait_until_page_loaded()
    self.log_message_web("Click 'Invoices' - Successful")   
    Delay(1000)
       
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Entry')]")
    Delay(1000) 
    self.log_message_web("Click 'Entry' - Successful")
    self.wait_until_page_loaded()
    
    self.page.EvaluateXPath("//div[text()='Invoices']")[1].Click()
    delay(10000) 
    
    web_utils.validate_security_box()
    delay(10000)    

    jFrame = self.initializeJFrame()
    Delay(10000)
    form_utils.click_ok_btn(jFrame)
    p_names = ("JavaClassName","AWTComponentAccessibleName")
    p_values = ("ExtendedFrame","Invoice Workbench (CAI "+self.oper_unit+" AP INVOICE PROCESSING)")
    inv_form=jFrame.FindChildEx(p_names,p_values,60,True,120000)
    Delay(2000)
    jFrame.Keys("~v")
    delay(1000)
    jFrame.Keys("f")
    delay(1000)
    
 #Finding Invoice that needs to be accounted
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Invoices","ExtendedFrame"]
    par_form=jFrame.FindChildEx(prop,val,60,True,60000)
    par_form.Find("AWTComponentAccessibleName","Invoice: Number",30).Click()
    Delay(4000)
    par_form.Find("AWTComponentAccessibleName","Invoice: Number",30).SetText(app.Cells.Item[rowno,13])
    jFrame.Keys("[Tab]")
#    jFrame.Keys("[Tab]")
#    jFrame.Keys("[Tab]")
#    jFrame.Keys("[Tab]")
#    jFrame.Keys("[Tab]")
#    jFrame.Keys("[Tab]")
#    jFrame.Keys("[Tab]")
#    jFrame.Keys("[Tab]")
#    jFrame.Keys("[Tab]")
#    val=["Invoice: Dates: StartList of Values","VTextField"]
#    par_form.FindChild(prop,val,60).SetText(aqConvert.DateTimeToFormatStr(aqDateTime.Today(),"%d-%b-%Y"))
#    jFrame.Keys("[Tab]")
#    val=["Invoice: Dates: EndList of Values","VTextField"]
#    par_form.FindChild(prop,val,60).FindChild(prop,val,60).SetText(aqConvert.DateTimeToFormatStr(aqDateTime.Today(),"%d-%b-%Y"))
    delay(3000)
    val = ["Find alt i","Button"] 
    par_form.FindChild(prop,val,60).Click()
    Delay(4000)    
    
#    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#    val=["Type Required",8]
#    inv_type=jFrame.FindChildEx(prop,val,60,True,900000)
#    Log.Enabled=True
#    aqObject.CheckProperty(inv_type,"wText",cmpIn,"Standard")
#    Log.Enabled=False
    
    self.log_message_oracle_form(jFrame,"Find Invoice Successful")
    
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Status",4]
    inv_val = jFrame.FindChild(prop,val,60)
    inv_status=inv_val.wText
    
    while inv_status != "Validated" and inv_status == "Never Validated":
        delay(1000)
        jFrame.Keys("~c")
        delay(1500)
        jFrame.Keys("~v")
        delay(1000)
        jFrame.Keys("~k")
        delay(10000)
        jFrame.Keys("^s")
        delay(2000)
        inv_status=inv_val.wText
      
    self.log_message_oracle_form(jFrame,"Invoice Status: "+inv_status)   
#    Log.Enabled=True
#    aqObject.CheckProperty(inv_val,"wText",cmpIn,"Validated")
#    Log.Enabled=False
    
    delay(3000)
    jFrame.Keys("~c")
    delay(3000)
    jFrame.Keys("~t")
    delay(3000)
    jFrame.Keys("~o")
    delay(3000)
    jFrame.Keys("~k")
    delay(18000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Note*","ChoiceBox"]
    note_popup=jFrame.FindChildEx(prop,val,30,True,60000)
    Log.Enabled=True
    #aqObject.CheckProperty(note_popup,"AWTComponentAccessibleName",cmpContains,"Accounting has been successfully created for this transaction")
    Log.Enabled=False
    delay(1000)
    jFrame.Keys("~o")
    self.log_message_oracle_form(jFrame,"Create Accounting job submitted")
    delay(3000)
    jFrame.Keys("[F4]")
    delay(3000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(2000)
    jFrame.Keys("~i")
    Delay(1000)
    
#Gathering Request ID for the Create Accounting Parent Program  
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,120000)  
    job_name_parent="false"
    phase_parent="false"
    i=20
    while (job_name_parent!="Create Accounting") or (phase_parent!="Completed") :
     prop=["AWTComponentAccessibleName","AWTComponentIndex"]
     val=["Name",i]
     job_name_parent=req_form.Find(prop,val,10).wText
     prop=["AWTComponentAccessibleName","AWTComponentIndex"]
     val=["Phase",i+20]
     phase_parent=req_form.Find(prop,val,10).wText
     prop=["AWTComponentAccessibleName","AWTComponentIndex"]
     val=["Status",i+30]
     status_parent=req_form.Find(prop,val,10)      
     i+=1     
     if i==29:
       prop=["AWTComponentAccessibleName","JavaClassName"]
       val = ["Refresh Data alt R","Button"]
       req_form.FindChild(prop,val,2000).Click() 
       i=20
    Log.Enabled=True
    aqObject.CheckProperty(status_parent,"wText",cmpIn,"Normal,Warning")
    Log.Enabled=False
    self.log_message_oracle_form(req_form,"Job Name "+aqConvert.VarToStr(job_name_parent))
    self.log_message_oracle_form(req_form,"Phase of Create Accounting "+aqConvert.VarToStr(phase_parent))   
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Request ID",i-11]
    req_id_parent=req_form.Find(prop,val,10).wText
    self.log_message_oracle_form(req_form,"Request ID of Create Accounting "+aqConvert.VarToStr(req_id_parent))
   


#Gathering Request ID for the Journal Import Child Program
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,60000)  
    job_name="false"
    phase="false"
    i=20
    while (job_name!="Journal Import") or (phase!="Completed"):
     prop=["AWTComponentAccessibleName","AWTComponentIndex"]
     val=["Name",i]
     job_name=req_form.Find(prop,val,10).wText
     prop=["AWTComponentAccessibleName","AWTComponentIndex"]
     val=["Phase",i+20]
     phase=req_form.Find(prop,val,10).wText
     prop=["AWTComponentAccessibleName","AWTComponentIndex"]
     val=["Status",i+30]
     status=req_form.Find(prop,val,10)       
     i+=1     
     if i==28:
       prop=["AWTComponentAccessibleName","JavaClassName"]
       val = ["Refresh Data alt R","Button"]
       req_form.FindChild(prop,val,2000).Click() 
       i=20
    Log.Enabled=True
    aqObject.CheckProperty(status,"wText",cmpIn,"Normal,Warning")
    Log.Enabled=False
    self.log_message_oracle_form(req_form,"Job Name "+aqConvert.VarToStr(job_name))
    self.log_message_oracle_form(req_form,"Phase of Journal Import Program "+aqConvert.VarToStr(phase))   
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Request ID",i-11]
    req_id=req_form.Find(prop,val,10).wText
    app.Cells.item[rowno,20] = req_id
    self.log_message_oracle_form(req_form,"Request ID of Journal Import Program "+aqConvert.VarToStr(req_id)) 
#    jFrame.Keys("[F4]")
#    Delay(3000)
#    jFrame.Keys("~v")
#    Delay(1000)
#    jFrame.Keys("r")
#    Delay(2000)
#    jFrame.Keys("~i")
#    Delay(1000) 
#  
##Gathering Request ID for the Create Accounting Parent Program  
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Requests","ExtendedFrame"]
#    req_form=jFrame.FindChildEx(prop,val,30,True,120000)  
#    job_name_parent="false"
#    phase_parent="false"
#    i=20
#    while (job_name_parent!="Create Accounting") or (phase_parent!="Completed") :
#     prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#     val=["Name",i]
#     job_name_parent=req_form.Find(prop,val,10).wText
#     prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#     val=["Phase",i+20]
#     phase_parent=req_form.Find(prop,val,10).wText          
#     i+=1     
#     if i==29:
#       prop=["AWTComponentAccessibleName","JavaClassName"]
#       val = ["Refresh Data alt R","Button"]
#       req_form.FindChild(prop,val,2000).Click() 
#       i=20
#    self.log_message_oracle_form(req_form,"Job Name "+aqConvert.VarToStr(job_name_parent))
#    self.log_message_oracle_form(req_form,"Phase of Create Accounting "+aqConvert.VarToStr(phase_parent))   
#    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#    val=["Request ID",i-11]
#    req_id_parent=req_form.Find(prop,val,10).wText
#    self.log_message_oracle_form(req_form,"Request ID of Create Accounting "+aqConvert.VarToStr(req_id_parent))

#Gathering output for the Journal Import Child Program   
    jFrame.Keys("[F4]")
    Delay(2000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(2000)
    jFrame.Keys("~s")
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Requests","ExtendedFrame"]

    find_req_form=jFrame.FindChildEx(prop,val,10,True,60000)
    find_req_form.Find("AWTComponentAccessibleName","Request ID",10).Click()
    find_req_form.Find("AWTComponentAccessibleName","Request ID",10).SetText(req_id)
    Delay(3000)
    jFrame.Keys("~i")
    Delay(2000)
#    jFrame.Keys("~k")
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,120000)
    req_form.FindChild("AWTComponentAccessibleName","View Output alt p",20).Click()
    Delay(1000)
    log_page=Sys.Browser("iexplore").Page("https://core*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.*")
    log_page.Click()
    log_page.TextNode(0).Click()
    Delay(1000)
    log_page.Keys("~f")
    Delay(1000)
    log_page.Keys("a")
    Delay(4000)  
    file_system_utils.create_folder(self.op_log_path)             
    log_path=self.op_log_path+"\\Journal Import Program Output Is Attached_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
    Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
    Delay(1000)
    Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
    Delay(5000)
    Log.Enabled=True
    Log.File(log_path, "Journal Import Concurrent Program Output File Attached")
    Log.Enabled=False        
    Delay(1000)
    Sys.Browser("iexplore").Page("https://core*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.*").Close()
    Delay(1000)
    web_utils.close_additional_browsers()
    Delay(1000)
#    jFrame.Click()
#    Delay(1000)
#    jFrame.Keys("[F4]")
#    Delay(2000)
##Gathering output for the Create Accounting Program   
#    jFrame.Keys("~v")
#    Delay(1000)
#    jFrame.Keys("r")
#    Delay(2000)
#    jFrame.Keys("~s")
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Find Requests","ExtendedFrame"]
##    jFrame=Sys.Browser("iexplore").SwingObject("JBufferedFrame", "*", -1, 1)
#    find_req_form=jFrame.FindChildEx(prop,val,10,True,120000)
#    find_req_form.Find("AWTComponentAccessibleName","Request ID",10).Click()
#    delay(1000)
#    find_req_form.Find("AWTComponentAccessibleName","Request ID",10).SetText(req_id_parent)
#    Delay(1000)
#    jFrame.Keys("~i")
#    Delay(1000)
##    jFrame.Keys("~k")
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Requests","ExtendedFrame"]
#    req_form=jFrame.FindChildEx(prop,val,30,True,120000)
#    req_form.FindChild("AWTComponentAccessibleName","View Log alt K",20).Click()
#    Delay(2000)
#    
#    log_page=Sys.Browser("iexplore").Page("https://core*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.*")
#    log_page.Click()
#    log_page.TextNode(0).Click()
#    Delay(1000)
#    log_page.Keys("~f")
#    Delay(1000)
#    log_page.Keys("a")
#    Delay(4000)  
#    file_system_utils.create_folder(self.op_log_path)             
#    log_path=self.op_log_path+"\\Creat Accounting Program Logfile Is Attached_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
#    Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
#    Delay(1000)
#    Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
#    Delay(5000)
#    Log.Enabled=True
#    Log.File(log_path, "Create Accounting Concurrent Program Log File Attached")
#    Log.Enabled=False        
#    Delay(1000)
#    Sys.Browser("iexplore").Page("https://core*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.*").Close()
#    Delay(1000)
    web_utils.close_additional_browsers()
    Delay(1000)
    jFrame.Click()
    Delay(1000)
    dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
    user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
    pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
    dbhelper.verify_invoice_accting_posting_status(dsn,user_id,pwd,VarToStr(app.Cells.Item[rowno,13]))    
    #dbhelper.verify_invoice_accting_posting_status(VarToStr(app.Cells.Item[rowno,13]))
    self.close_forms(jFrame)      
    del app,jFrame,log_path,find_req_form,prop,val

