﻿import gvar
import json
import tc_logs
import web_utility
import pdf_utility
import file_utility
import batch_print_utility

def setheaders():
   accept    = gvar.config['docdeliveryapi']['accept']
   version   = gvar.config['docdeliveryapi']['version']
   manheimid = gvar.config['docdeliveryapi']['Manheim-Employee-ID']
   address   = gvar.config['docdeliveryapi']['end_point']
   userid    = gvar.config['docdeliveryapi']['usrid']
   pswd      = gvar.config['docdeliveryapi']['pswd']
   resource  = gvar.config['docdeliveryapi']['resource']
   address = address+resource
   
   aqHttpRequest  = aqHttp.CreatePostRequest(address,userid,pswd)
   Log.Message(aqHttpRequest)
   aqHttpRequest.SetHeader("Content-Type", accept) 
   aqHttpRequest.SetHeader("Version",version )
   aqHttpRequest.SetHeader("Manheim-Employee-ID",manheimid)
   aqHttpRequest.SetHeader('Manheim-Customer-RepNumber', '100280572')
   
   return  aqHttpRequest

def request_body(aqHttpRequest):
   
   requestBody = {
     "documentType" : gvar.dataprep['document_type'],
     "deliveryMethod" : gvar.dataprep['p_del_method'],
     "customerNumber" : gvar.dataprep['p_dealer'],
     "customerRep" : gvar.dataprep['p_rep_id'],
     "groupCode" : gvar.dataprep['p_group_code'],
     "invoiceId" : "",
     "email" : get_email_id(),
     "printer" : "",
     "externalURL" : "false",
     "auctionLocations" : [gvar.dataprep['p_auction_locations']],
     "fromDate" : gvar.dataprep['p_inv_low_date'],
     "todate" : gvar.dataprep['p_inv_high_date'],
     "consignmentID" : "",
     "invoiceNumberLow" : "",
     "invoiceNumberHigh" : "",
     "invoiceSource" : "",
     "invoiceTypes" : [gvar.dataprep['p_invoice_type']],
     "paymentStatus" : gvar.dataprep['p_payment_status'] 
   }
   requestBody = json.dumps(requestBody)
   tc_logs.checkpt_with_no_picture(aqString.Format("DocDelivery API request: %s", requestBody))
   return aqHttpRequest, requestBody
   
def logmessage(aqHttpResponse):

  Log.Message(aqHttpResponse.AllHeaders)
  Log.Message(aqHttpResponse.GetHeader("Content-Type"))
  Log.Message(aqHttpResponse.StatusCode)  
  Log.Message(aqHttpResponse.StatusText) 
  Log.Message(aqHttpResponse.Text) 

def messagecheckpts(aqHttpResponse):
  tc_logs.checkpt_with_no_picture(aqString.Format("Response Header information: %s", VarToStr(aqHttpResponse.AllHeaders) ))
  tc_logs.checkpt_with_no_picture(aqString.Format("Response status code: %s",VarToStr(aqHttpResponse.StatusCode)))
  
def validate_response(aqHttpResponse):
                  # Save a response body to a file
  path = aqFileSystem.IncludeTrailingBackSlash(Project.Path+'DataSheets\\API_Response')+'doc_api.txt'
  aqHttpResponse.SaveToFile(path)
  with open(path) as json_file:
    response = json.load(json_file)
    tc_logs.msg_with_no_picture(aqString.Format('Truncation value: %s', VarToStr(response['truncated'])))
    tc_logs.msg_with_no_picture(aqString.Format('Status: %s',VarToStr(response['status'])))
    tc_logs.checkpt_with_no_picture(aqString.Format('RequestID: %s', VarToStr(response['requestID'])))
    tc_logs.checkpt_with_no_picture(aqString.Format('PDF URL: %s', VarToStr(response['documentUrl'])))
    return VarToStr(response['requestID']),response['documentUrl']
              
def api_request_response():
  tc_logs.header_name('DOC_DELIVERY_API'.center(70,'*'))
  aqHttpRequest , body = request_body(setheaders())
  aqHttpResponse = aqHttpRequest.Send(body) 
  logmessage(aqHttpResponse)  
  messagecheckpts(aqHttpResponse)   
  requestId, pdf_url = validate_response(aqHttpResponse)
  gvar.store('refid_email',requestId)
  if(gvar.dataprep['p_del_method'] is not None and gvar.dataprep['p_del_method'] == "PDF"):
     open_pdf_doc_delivery(pdf_url)
  else:
     batch_print_utility.check_email(gvar.dataprep['refid_email'])
 
def open_pdf_doc_delivery(url):
  launch_browser(url)
#  pdf_utility.download_pdf_output() 
  Delay(100000)
#  pdf_utility.pdf_save_request()
  web_utility.clear_cache()
  web_utility.process_cmd("taskkill.exe /F /IM iexplore.exe /T")

def launch_browser(url):
  tc_logs.header_name("**********OPENPDFURL**********")
  global browser,page
  Browsers.Item[btIExplorer].Run(url)
  Delay(30000)
  browser = Sys.Browser("iexplore")
  browser.BrowserWindow(0).Maximize()
  tc_logs.checkpt_with_no_picture("IE Browser opened Successfully")

def get_email_id():
  email_id = ''
  if(gvar.dataprep['p_del_method'] is not None and gvar.dataprep['p_del_method'] == "EMAIL"):
    email_id = gvar.config['email']['usrid']
  return email_id
  
def open_pdf_bos(url):
  launch_browser(url)
#  pdf_utility.pdf_save_request()
  pdf_utility.download_pdf_output()
#  web_utility.clear_cache()
#  web_utility.process_cmd("taskkill.exe /F /IM iexplore.exe /T")
  
def bos_api_request_response():
  tc_logs.header_name('DOC_DELIVERY_API'.center(70,'*'))
  aqHttpRequest , body = request_body(setheaders())
  aqHttpResponse = aqHttpRequest.Send(body) 
  logmessage(aqHttpResponse)  
  messagecheckpts(aqHttpResponse)   
  requestId, pdf_url = validate_response(aqHttpResponse)
  gvar.store('refid_email',requestId)
  if(gvar.dataprep['p_del_method'] is not None and gvar.dataprep['p_del_method'] == "PDF"):
     open_pdf_bos(pdf_url)
  else:
     batch_print_utility.check_email(gvar.dataprep['refid_email'])
