﻿from dbhelper import *
from ebiz import *
import web_utils
import dbhelper
import file_system_utils 
import form_utils

class tc127762cai_us_asset_creation(Ebiz):
 op_log_path="C:\\Tc_Logs"

 def login(self):
   self.login_user='NAGGARWAL'
   super().login()
   
 def action(self,book): 
   app = book.Sheets.item["PA-FA"]       
   self.page.wait()
   web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" FA ASSET TRANSACTION')]")
   self.log_message_web("Click 'CAI "+self.oper_unit+" FA ASSET TRANSACTION' - Successful")
   Delay(3000)  
   self.page.EvaluateXpath("//table[@id='respList']//div[text()='Assets']")[0].Click()
   self.log_message_web("Click 'Assets' - Successful")
   Delay(2000)
   self.page.wait()
   self.page.EvaluateXpath("//table[@id='respList']//div[text()='Asset Workbench']")[0].Click()
   self.log_message_web("Click 'Asset Workbench' - Successful")
#   Delay(10000)
#   web_utils.validate_security_box()
   Delay(10000)
   jFrame=self.initializeJFrame()
   Delay(5000)
   form_utils.click_ok_btn(jFrame)
   self.log_message_oracle_form(jFrame,"Navigation Successful : CAI "+self.oper_unit+" FA ASSET Transaction > Assets > Asset Workbench; 'Find Assets' form launched successfully")
   Delay(4000)
#   self.log_message_web("Navigation successful: Assets > Asset Workbench>'Find Assets' form launched successfully") 
   for rowno in range(2,app.UsedRange.Rows.Count+1):     
#     self.log_message_oracle_form( jFrame,"'Find Assets' form launched successfully")
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Find Assets","ExtendedFrame"]
     findassets_form=jFrame.FindChildEx(prop,val,60,True,40000)
     Delay(2000)
     self.log_message_oracle_form(jFrame,"In 'Find Assets' form: Click on 'Additions' Button next")
     findassets_form.FindChild("AWTComponentAccessibleName","Additions alt n",10).Click()
#     self.log_message_oracle_form(jFrame,"In 'Find Assets' form: Click on 'Additions' Button")
#     findassets_form.Keys("~n")
     Delay(3000)
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Asset Details","ExtendedFrame"]
     assetdetails_form=jFrame.FindChildEx(prop,val,60,True,30000)
     self.log_message_oracle_form( jFrame,"'Assets Details' form launched successfully")
     assetdetails_form.Find("AWTComponentAccessibleName","Description RequiredList of Values",10).Click()
     assetdetails_form.Find("AWTComponentAccessibleName","Description RequiredList of Values",10).keys(app.Cells.item[rowno,3])
     self.log_message_oracle_form( assetdetails_form," In 'Asset Details' form: Description Entered - " + VarToStr(app.Cells.item[rowno,3]))
     cat_req=assetdetails_form.Find("AWTComponentAccessibleName","Category RequiredList of Values",10)
     cat_req.Click()
     cat_req.keys(app.Cells.item[rowno,4])
     cat_req.keys("[Tab]")
     Delay(2000)
     self.log_message_oracle_form( assetdetails_form," In 'Asset Details' form: Category Entered - " + VarToStr(app.Cells.item[rowno,4]))
     Delay(2000)
     self.log_message_oracle_form( assetdetails_form," In 'Asset Details' form: Review ATG Asset Major Category & ATG Asset Minor Category ")
     Delay(2000)
     assetdetails_form.keys("~o")
     Delay(2000)
     jFrame.keys("~o")
     Delay(2000)
     assetdetails_form.Find("AWTComponentAccessibleName","Asset KeyList of Values",10).Click()
     Delay(2000)
     assetdetails_form.Find("AWTComponentAccessibleName","Asset KeyList of Values",10).keys(app.Cells.item[rowno,5])
     self.log_message_oracle_form( assetdetails_form," In 'Asset Details' form: 'Asset Key' Entered - " + VarToStr(app.Cells.item[rowno,5]))
     Delay(2000)
     self.log_message_oracle_form( assetdetails_form," In 'Asset Details' form: Click 'Continue' Button next")
     Delay(2000) 
     assetdetails_form.Find("AWTComponentAccessibleName","Continue alt n",10).Click()  
#     assetdetails_form.keys("~n")
     Delay(3000) 
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Books","ExtendedFrame"]
     Books_form=jFrame.FindChildEx(prop,val,20,True,60000)
     Books_form.Find("AWTComponentAccessibleName","Book RequiredList of Values",10).Click()
     Books_form.Find("AWTComponentAccessibleName","Book RequiredList of Values",10).keys(app.Cells.item[rowno,6])
     self.log_message_oracle_form(jFrame," In 'Books' form: Book Entered - "+ VarToStr(app.Cells.item[rowno,6]))
     Delay(2000)
     Books_form.Find("AWTComponentAccessibleName","Current Cost Required",10).Click()
     Books_form.Find("AWTComponentAccessibleName","Current Cost Required",10).keys(app.Cells.item[rowno,12])
     self.log_message_oracle_form( Books_form," In 'Books' form: Current Cost Entered - "+ VarToStr(app.Cells.item[rowno,12]))
     Delay(2000)
     self.log_message_oracle_form( Books_form,"Click 'Continue' Button next on 'Books' form")    
     jFrame.keys("~n")
     Delay(2000)
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Assignments","ExtendedFrame"]   
     assingments_form=jFrame.FindChildEx(prop,val,60,True,40000)
     prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
     val=["Unit*","VTextField",16]  
     assingments_form.Find(prop,val,10).Click()  
     assingments_form.Find(prop,val,10).Keys(app.Cells.item[rowno,10])
     self.log_message_oracle_form(jFrame," In 'Assignments' form: 'Unit Change' Entered : "+ VarToStr(app.Cells.item[rowno,10]))
     Delay(2000)
     prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
     val=["Expense Account RequiredList of Values","VTextField",56]  
     assingments_form.Find(prop,val,10).Click()    
     assingments_form.Find(prop,val,10).Keys(app.Cells.item[rowno,11])
     self.log_message_oracle_form(jFrame," In 'Assignments' form: 'Expense Account' Entered - "+ VarToStr(app.Cells.item[rowno,11]))
     Delay(2000)
     prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
     val=["Location RequiredList of Values","VTextField",66]    
     assingments_form.Find(prop,val,10).Click()  
     assingments_form.Find(prop,val,10).Keys(app.Cells.item[rowno,7])
     self.log_message_oracle_form(jFrame," In 'Assignments' form: 'Location' Entered - "+ VarToStr(app.Cells.item[rowno,7]))
     assingments_form.keys("[Tab]")
     Delay(2000)
     self.log_message_oracle_form( jFrame,"Click 'Done' Button next on 'Assignments' Form")
     Delay(2000) 
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Done alt D","Button"]    
     assingments_form.FindChild(prop,val,40).Click() 
     Delay(4000)
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Note APP-OFA-48266: Transaction saved for asset number*","ChoiceBox"]   
     conf_msg=jFrame.FindChild(prop,val,40).AWTComponentAccessibleName
     self.log_message_oracle_form( jFrame, "Asset Transaction Saved Note - " +VarToStr(conf_msg) )
     Delay(2000)
     asset_no=conf_msg.split(".",2)[0][-7:]
     self.log_message_oracle_form(jFrame,"Asset Number generated - "+VarToStr(asset_no))
     Log.Message(conf_msg.split(".",2)[0][-7:]) 
     app.Cells.item[rowno,1]= asset_no 
     jFrame.keys("~o")
     Delay(5000)
     
   jFrame.keys("[F4]")
   Delay(2000)
   jFrame.keys("[F4]")
   Delay(2000)
   jFrame.keys("~o")
   
#   Sys.Browser("iexplore").page("https://core-*.epfinnp.coxautoinc.com/forms/frmservlet*").Close()
   Delay(3000)
   book.save()


