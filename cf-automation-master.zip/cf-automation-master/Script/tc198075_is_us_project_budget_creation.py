﻿from   ebiz import *
import web_utils
import dbhelper
import file_system_utils
import random
from datetime import datetime




class tc198075_is_us_project_budget_creation(Ebiz):


   def login(self):
     self.login_user='pkjami'
     super().login()
   
   def goto_url(self,url):
    super().goto_url(self.testConfig['ebiz']['oci_is_url'])
   
   def action(self,book): 
     app = book.Sheets.item["Project"] 
     app1 = book.Sheets.item["Requisition"]  
     rowno = 2
     web_utils.log_checkpoint("Logged in to Oracle Applications Home Page Successfully",500,self.page)
     self.wait_until_page_loaded()     
     self.page.EvaluateXPath("//table[@id='menuContent']//div[contains(text(),'PC User')]")[0].Click()  
     web_utils.log_checkpoint("Click 'PC User' - Successful",500,self.page) 
     self.page.Keys("[Down]")
     delay(2000)
     self.wait_until_page_loaded()
     self.page.NativeWebObject.Find("contentText","Budgets","A").Click()  
     web_utils.log_checkpoint("Click 'Budgets' - Successful",500,self.page) 
     self.page.wait()  
     delay(10000)  
     web_utils.validate_security_box()
     jFrame = self.initializeJFrame()
     Delay(10000)
     form_utils.click_ok_btn(jFrame)
     
# Create Initial Budget:
     p_names = ("AWTComponentAccessibleName","JavaClassName")
     p_values = ("Budgets","ExtendedFrame")
     budgets_form=jFrame.FindChildEx(p_names,p_values,60,True,120000)
     Sys.HighlightObject(budgets_form)
     obj=jFrame.FindChild(p_names,p_values,50)
     if obj.Exists:
      web_utils.log_checkpoint("Budgets' form launched successfully",500,jFrame) 
     else:
      self.log_message_oracle_form(jFrame,"Unable to Launch 'Budgets' form")    
     Delay(10000)
     
#project number
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Find Budget Project Number RequiredList of Values","VTextField"]
     proj_num = budgets_form.FindChild(prop,val,20)
     Sys.HighlightObject(proj_num)    
     proj_num.Click()
     proj_num.Find(prop, val,30).Keys(app.Cells.Item[rowno,11])
     jFrame.Keys("[Tab]")
     Delay(2000)
     web_utils.log_checkpoint("Entered Project Number : '"+aqConvert.VarToStr(app.Cells.Item[rowno,11])+"' in Budgets form",500,jFrame) 
     
#budget type
     val = ["Find Budget Budget Type RequiredList of Values","VTextField"]
     bud_type = budgets_form.FindChild(prop,val,20)
     bud_type.Keys(app.Cells.Item[rowno,12])
     web_utils.log_checkpoint("Entered Budget Type : '"+aqConvert.VarToStr(app.Cells.Item[rowno,12])+"' in Budgets form",500,jFrame) 
     jFrame.Keys("[Tab]")
     
#draft version name
     val=["Draft Budget Version Name","VTextField"]
     draft_ver = budgets_form.FindChild(prop,val,20)
     Sys.HighlightObject(draft_ver)    
     draft_ver.Click()
     draft_ver.Keys(app.Cells.Item[rowno,18])
     delay(2000)
     web_utils.log_checkpoint("Entered Draft Version Name: '"+aqConvert.VarToStr(app.Cells.Item[rowno,18])+"' in Budgets form",500,jFrame) 
     delay(2000)
     
#draft version description
     val=["Draft Budget Description","VTextField"]
     draft_desc = budgets_form.FindChild(prop,val,20)
     Sys.HighlightObject(draft_desc)    
     draft_desc.Click()
     draft_desc.Keys(app.Cells.Item[rowno,19])
     delay(2000)
     web_utils.log_checkpoint("Entered Draft Version Description: '"+aqConvert.VarToStr(app.Cells.Item[rowno,19])+"' in Budgets form",500,jFrame) 
     delay(2000)
#Enter Budget Entry Method
     val = ["Entry options Entry Method RequiredList of Values","VTextField"]
     entry_method = budgets_form.FindChild(prop,val,20)
     Sys.HighlightObject(entry_method) 
     entry_method.Click()
     delay(500)
     entry_method.Keys("^a[Del]")
     entry_method.Keys(app.Cells.Item[rowno,13])
     jFrame.Keys("[Tab]")
     web_utils.log_checkpoint("Entered Budget Entry Method : '"+aqConvert.VarToStr(app.Cells.Item[rowno,13])+"' in Budgets form",500,jFrame) 
     delay(2000)
     
#validate caution box
     val = ("Caution*","ChoiceBox")
     caution_box = jFrame.FindChild(prop,val,30)
     if caution_box.Exists:
       
        Sys.HighlightObject(caution_box)
     
#Accept caution message
        val = ("OK ALT O","FormButton")
        caution_box.FindChild(prop,val,30).Click()
        delay(2000)
     
#Click Details Button
     val = ["Details alt D","Button"]
     details_button = budgets_form.FindChild(prop,val,30)
     Sys.HighlightObject(details_button)
     details_button.Click()
     delay(2000)
     web_utils.log_checkpoint("Click Open Budget Details form to enter required line details",500,jFrame)
     
#navigate to budget details form
     val = ("Budget Lines*","ExtendedFrame")
     budget_lines=jFrame.FindChildEx(prop,val,60,True,120000)
     Sys.HighlightObject(budget_lines)
     
#Enter Budget Resource
     val = ("Resource\nAliasList of Values","VTextField")
     resource = budget_lines.FindChild(prop,val,20)
     resource.Click()
     resource.Keys(app.Cells.Item[rowno,14])
     web_utils.log_checkpoint("Entered Resource : '"+aqConvert.VarToStr(app.Cells.Item[rowno,14])+"' in Budgets-Lines form",500,jFrame) 
     delay(1000)
     
#Enter Budget from date
     val = ("Effective From DateList of Values","VTextField")
#     f_date = aqConvert.DateTimeToFormatStr(aqDateTime.Today(),'%d-%b-%Y')
     f_date = aqConvert.DateTimeToFormatStr(app.Cells.Item[rowno,15],'%d-%b-%Y')
     from_date = budget_lines.FindChild(prop,val,20)
     from_date.Click()
     from_date.Keys(f_date)
     web_utils.log_checkpoint("Entered FROM_DATE: "+f_date+" in Budgets-Lines form",500,jFrame) 
     delay(1000)
     
#Enter budget to date
     val = ("Effective To DateList of Values","VTextField")
#     n_date = aqDateTime.AddDays(f_date,365)
     t_date = aqConvert.DateTimeToFormatStr(app.Cells.Item[rowno,16],'%d-%b-%Y')
     to_date = budget_lines.FindChild(prop,val,20)
     to_date.Click()
     to_date.Keys(t_date)
     web_utils.log_checkpoint("Entered TO_DATE : "+t_date+" in Budgets-Lines form",500,jFrame) 
     delay(1000)
     
#Enter Budget Raw Cost
     prop = ("AWTComponentAccessibleName","AWTComponentIndex","JavaClassName")
     val = ("Raw Cost",57,"VTextField")
     raw_cost = budget_lines.FindChild(prop,val,20)
     raw_cost.Click()
     raw_cost.Keys(app.Cells.Item[rowno,17])
     web_utils.log_checkpoint("Entered RawCost : '"+aqConvert.VarToStr(app.Cells.Item[rowno,17])+"' in Budgets-Lines form",500,jFrame) 
     delay(1000)
     jFrame.Keys("^s")
     delay(1000)
     budget_lines.Close()
     prop = ("AWTComponentAccessibleName","JavaClassName")
     val = ("Submit alt b","Button")
     submit_button = budgets_form.FindChildEx(prop,val,30,True,6000)
     Sys.HighlightObject(submit_button)
     submit_button.Click()
     delay(5000)
     val = ("Baseline alt b","Button")
     bslne_button = budgets_form.FindChildEx(prop,val,30,True,60000)
     Sys.HighlightObject(bslne_button)
     bslne_button.Click()
     web_utils.log_checkpoint("Submission successfull for entered budget details",500,jFrame) 
     Delay(3000)
     self.close_forms(jFrame)    
     del app,app1
     
     
     
def test():
#  jFrame = Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1)
#  prop=["AWTComponentAccessibleName","JavaClassName"]
#  val = ("Budget Lines*","ExtendedFrame")
#  budget_lines=jFrame.FindChildEx(prop,val,60,True,120000)
#  val = ("Resource\nAliasList of Values","VTextField")
#  resource = budget_lines.FindChild(prop,val,20)
#  Sys.HighlightObject(resource)

  date = aqDateTime.Today()
  f_date = aqConvert.DateTimeToFormatStr(date,'%d-%b-%Y')
  delay(2000)
  n_date = aqDateTime.AddDays(f_date,365)
  n1_date = aqConvert.DateTimeToFormatStr(n_date,'%d-%b-%Y')
  delay(1000)