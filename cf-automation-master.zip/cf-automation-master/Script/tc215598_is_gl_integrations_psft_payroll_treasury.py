﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils
import winscp_utility
import tc_logs
import web_utils
from File_Handler import File_Handler as _TXTOBJ
from text_headers import payroll_txt_file_header as _HEADERS


class tc215598_is_gl_integrations_psft_payroll_treasury(Ebiz):
   
  op_log_path="C:\\TC_Logs"
  is_pay_tsry_files="C:\\IS_Pyrl_Trsy_Files"
  
  def login(self):
      self.login_user="mfallwell"
      super().login()
  
  def goto_url(self,url):
       super().goto_url(self.testConfig['ebiz']['oci_is_url'])
  
           
  def action(self,book):
    self.files = ["PS_401Bill_GL_CAUTO.txt","PS_FBB_GL_CAUTO.txt","PS_CAUTO_Accrual__BW200717.txt","PS_CAUTO_Accrual__WK200724.txt"]
    self.place_files_local()
    self.process_files()
    self.place_files_winscp()
    
## Place Payroll Files in Local Folder:
  def place_files_local(self):   
    for index in range(0,4):
      file_system_utils.create_folder(self.is_pay_tsry_files)
      file_exist=aqFileSystem.FindFiles("C:\\IS_Pyrl_Trsy_Files",self.files[index])
      if file_exist != None:
       aqFileSystem.DeleteFile("C:\\IS_Pyrl_Trsy_Files\\"+self.files[index])
      aqFileSystem.CopyFile(Project.Path+"DataSheets\\Oracle-GL-Journal\\IS\\"+self.files[index], "C:\\IS_Pyrl_Trsy_Files\\"+self.files[index])
      log_path = ("C:\\IS_Pyrl_Trsy_Files\\"+self.files[index])
      Log.Enabled=True
      Log.File(log_path, "Payroll File "+self.files[index]+" Attached")
      Log.Enabled=False 

## Read/Modify/Write Payroll Files:
#  def process_files(self):  
#    def counter(index,**kwargs):
#      import datetime as dt 
#      import random
#      kwargs['REFERENCE21'] = int(dt.datetime.now().strftime("%Y%m%d%H%M%S%f"))+int(index)
#      return kwargs 
#    for number in range(0,4):
#      path = "C:\IS_Pyrl_Trsy_Files\\"+self.files[number]
#      cobj = _TXTOBJ(path,"|")
#      cobj.Write_txt_without_header([counter(index+1,**row) for index, row in enumerate(
#              cobj.Read_txt_with_header(_HEADERS()))]) 

  def process_files(self):
     import re
     from datetime import datetime
     
#     files = ["PS_401Bill_GL_CAUTO.txt","PS_FBB_GL_CAUTO.txt","PS_CAUTO_Accrual__BW191108.txt","PS_CAUTO_Accrual__WK191115.txt"]
     
     str_20_len=datetime.now().strftime("%Y%m%d%H%M%S%f")
     acc_date=datetime.now().strftime("%m/%d/%Y")
     acc_period=datetime.now().strftime("%b-%Y")
     acc_period=str(acc_period).upper()

     
     for number in range(0,4):
         path = "C:\IS_Pyrl_Trsy_Files\\"+self.files[number]
         Read_lines=[]
         Write_lines=[]
         with open(path,'r') as fr:
          Read_lines=fr.readlines()
          for line in Read_lines:
             acc_date_str=re.sub(r'\d{2}/\d{2}/\d{4}',acc_date,line)
             acc_period_str=re.sub(r'[A-Z]{3}-\d{4}',acc_period,acc_date_str)
             if(self.files[number]=="PS_401Bill_GL_CAUTO.txt"):
                str_20_modified=re.sub(r'401\s0720\s\d{1,4}',str_20_len,acc_period_str)
             elif(self.files[number]=="PS_CAUTO_Accrual__BW200717.txt"):
                str_20_modified=re.sub(r'Accrual\sWBW200717\s\d{1,6}',str_20_len,acc_period_str)
             elif(self.files[number]=="PS_CAUTO_Accrual__WK200724.txt"):
                str_20_modified=re.sub(r'Accrual\sWK200724\s\d{1,4}',str_20_len,acc_period_str)
             elif(self.files[number]=="PS_FBB_GL_CAUTO.txt"):
                str_20_modified=re.sub(r'FLX\s0720\s\d{1,4}',str_20_len,acc_period_str)
             str_20_len=str(int(str_20_len)+1)
             Write_lines.append(str_20_modified)
         with open(path,'w') as fw:
            fw.writelines(Write_lines)


## Place Payroll Files in WinScp:
  def place_files_winscp(self):  #self,file1,file2,file3,file4
    for index in range(0,4):
      Stored_session = "cei_peoplesoft@mftstg.manheim.com" 
      local_dir = "C:\\IS_Pyrl_Trsy_Files"
      remote_dir =  self.testConfig['winscp']['remote_dir']+"//Harmony" 
#      remote_dir = "//Outbox//SMNH2I//Harmony"
      upload_file_name = self.files[index]
      winscp_utility.upload_file(Stored_session,local_dir,remote_dir,upload_file_name)
      Log.Enabled=True       
      Log.Message("Payroll File "+self.files[index]+" placed in the "+remote_dir+" directory")           
      Log.Enabled=False

## Login to Oracle EBIZ and select the responsibility
  
#    is_gl_submit_link=self.page.NativeWebObject.Find("contentText","GL SCHEDULER","A")
#    self.verify_aqobject_chkproperty(is_gl_submit_link,"contentText",cmpIn,"GL SCHEDULER")
#    is_gl_submit_link.Click() 
##    self.log_message_web("Click 'GL SCHEDULER' - Successful") 
#    web_utils.log_checkpoint("Click 'GL SCHEDULER' - Successful",500,self.page)
#    Delay(1000)  
    self.page.EvaluateXpath("//table[@id='respList']//div[contains(text(),'GL SCHEDULER')]")[0].scrollIntoView()
    self.page.EvaluateXpath("//table[@id='respList']//div[contains(text(),'GL SCHEDULER')]")[0].Click()
    web_utils.log_checkpoint("Click 'GL SCHEDULER' - Successful",500,self.page)
    delay(1000)
         
    self.page.Wait()
    self.page.NativeWebObject.Find("contentText","Requests","A").Click()
#    self.log_message_web("Click 'Requests' - Successful") 
    web_utils.log_checkpoint("Click 'Requests' - Successful",500,self.page)
  
    self.page.Wait()
    self.page.NativeWebObject.Find("contentText","Run","A").Click()
#    self.log_message_web("Click 'Run' - Successful") 
    web_utils.log_checkpoint("Click 'Run' - Successful",500,self.page)
    
    web_utils.validate_security_box()
    jFrame= self.initializeJFrame()
    Delay(10000)

    form_utils.click_ok_btn(jFrame)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit a New Request","ExtendedFrame"]
    submit_new_req_form=jFrame.FindChildEx(prop,val,60,True,90000)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["What type of request do you want to run? Request Set alt s","ExtendedCheckbox"]  
    submit_new_req_form.FindChild(prop,val,10).Click()       
    Delay(1000)
    submit_new_req_form.FindChild("AWTComponentAccessibleName","OK alt O",10).Click()

    #  Submitting "MAN Oracle GL Inbound JE Interface Request Set - PeopleSoft Harmony" Request Set using 'GL SCHEDULER' responsibility
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit Request Set","ExtendedFrame"]
    par_form=jFrame.FindChild(prop,val,60)
    par_form.Find("AWTComponentAccessibleName","Request Set RequiredList of Values",30).SetText("MAN Oracle GL Inbound JE Interface Request Set - PeopleSoft Harmony")
    delay(1000)
    
    jFrame.Keys("[Tab]")
    delay(1000)
    self.log_message_oracle_form(jFrame,"Entered Request Set 'MAN Oracle GL Inbound JE Interface Request Set - PeopleSoft Harmony'")
    
    par_form=jFrame.FindChild(prop,val,60)
    par_form.Find("AWTComponentAccessibleName","Submit",30).Click()
    form_utils.click_ok_btn(jFrame)    
#    self.log_message_oracle_form(jFrame,"MAN Oracle GL Inbound JE Interface Request Set - PeopleSoft Harmony")   
    delay(3000)
    
    RequestID = aqConvert.VarToInt(''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit()))
    Log.Message("Request ID" + aqConvert.VarToStr(RequestID))
    self.log_checkpoint_message_web("Request ID Of MAN Oracle GL Inbound JE Interface Request Set - PeopleSoft Harmony " + aqConvert.VarToStr(RequestID))
    Delay(2000)
    jFrame.Keys("~n")
    delay(200000)
    
    
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000) 
       
    # Gathering Request ID and Output File for the "MAN Oracle GL Inbound JE Interface Request Set - PeopleSoft Harmony"   
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,90000) 
    
    self.req_set_save_output(jFrame,req_form,"MAN Oracle Generic GL Preprocessor Program",RequestID)
    delay(5000)
    Delay(200000)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val = ["Refresh Data alt R","Button"]
    req_form.FindChild(prop,val,2000).Click()

    for count in range(6):
      Delay(100000)
      req_form.FindChild(prop,val,2000).Click()
      delay(5000)
      req_form.FindChild(prop,val,2000).Click()
      
    dsn = self.testConfig['man_oracle_db']['dsn']
    user_id = self.testConfig['man_oracle_db']['userid']
    pwd = self.testConfig['man_oracle_db']['pwd']
    dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,VarToStr(RequestID))
          
    self.req_set_save_output(jFrame,req_form,"MAN Oracle GL Inbound JE Interface Program",RequestID)
    delay(5000) 
         

    # Gathering Request ID and Output File for the "Journal Import Program"  
    creqid1 = self.req_set_save_output(jFrame,req_form,"Journal Import",RequestID)
    journal_req_ids = []
    journal_req_ids.append(creqid1) 
    Delay(3000)
    creqid2 = self.req_set_save_output(jFrame,req_form,"Journal Import",RequestID,journal_req_ids)
    journal_req_ids.append(creqid2)
    Delay(3000)
    creqid3 = self.req_set_save_output(jFrame,req_form,"Journal Import",RequestID,journal_req_ids)
    journal_req_ids.append(creqid3)
    delay(3000)
    creqid4 = self.req_set_save_output(jFrame,req_form,"Journal Import",RequestID,journal_req_ids)
    journal_req_ids.append(creqid4)
    delay(3000)   
        
#    journal_req_ids=["162812479","162812480","162812481","162812483"]
    
#    Code to check journal_req_ids has empty values

    if any(journal_req_ids) == False:
           web_utils.log_error("Not able to get Journal import batch name")


    # Navigate to journal from frontEnd
#    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'GL Corporate Accounting User')]")
##    self.log_message_web("Click 'GL Corporate Accounting User' - Successful")
#    web_utils.log_checkpoint("Click 'GL Corporate Accounting User' - Successful",500,self.page)
#    Delay(3000)
#    self.page.EvaluateXpath("//table[@id='respList']//div[text()='Journals']")[0].Click()
##    self.log_message_web("Click 'Journals'- Successful")
#    web_utils.log_checkpoint("Click 'Journals' - Successful",500,self.page)
#    Delay(2000)
#    self.page.EvaluateXpath("//table[@id='respList']//div[text()='Enter']")[0].Click()
##    self.log_message_web("Click 'Enter'- Successful")
#    web_utils.log_checkpoint("Click 'Enter' - Successful",500,self.page)
#    
#    web_utils.validate_security_box()
#    delay(2000)
#    jFrame=self.initializeJFrame()
#    delay(2000)
#    form_utils.click_ok_btn(jFrame)
 
# Navigation to GL Corporate Accounting user through Java forms shortcut       
    jFrame.Keys("[F4]")
    Delay(2000) 
    jFrame.Click()
    Delay(2000)
    jFrame.Keys("~f")
    Delay(4000)
    jFrame.Keys("w")
    Delay(4000)

    #Switiching responsibility form identification    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Responsibilities","FWindow"]
    resp_form=jFrame.FindChildEx(prop,val,30,True,60000)
   
    #selecting the responsibility
    resp_form.Find("AWTComponentName","LWTextField*",10).Click() 
    resp_form.Find("AWTComponentName","LWTextField*",10).keys("GL Corporate Accounting User")
   
    val = ["Find ALT F","PushButton"]
    resp_form.FindChild(prop,val,20).Click()
    Delay(2000)
    jFrame.Keys("~o")
    Delay(1000)
    web_utils.log_checkpoint("Navigating to GL Corporate Accounting user",500,jFrame)
    jFrame.Keys("~o")
    Delay(1000)
    
    for x in journal_req_ids:
      
      dsn = self.testConfig['man_oracle_db']['dsn']
      user_id = self.testConfig['man_oracle_db']['userid']
      pwd = self.testConfig['man_oracle_db']['pwd']
      batch_name = dbhelper.return_journal_batch_name(dsn,user_id,pwd,"%"+VarTostr(x))
      res= aqString.Find(batch_name,"Payroll")
      if res != -1:
#      if batch_name.("Payroll"): #("WK" or "BW"):
    
        prop=["AWTComponentAccessibleName","JavaClassName"]
        val=["Find Journals","ExtendedFrame"]
        fnd_jrnl=jFrame.FindChildEx(prop,val,60,True,90000)
        fnd_jrnl.Find("AWTComponentAccessibleName","BatchList of Values",10).Click()
        fnd_jrnl.Find("AWTComponentAccessibleName","BatchList of Values",10).Keys("%"+VarToStr(x)+"%")
        delay(1000) 
        jFrame.Keys("~i")
#        self.log_message_oracle_form(jFrame,VarToStr(x)+" find Journal Successful")
        web_utils.log_checkpoint(VarToStr(x)+" find Journal Successful",500,jFrame)
        delay(8000) 
        jFrame.Keys("~u")
        delay(4000) 
        prop=["AWTComponentAccessibleName","JavaClassName"]
        val=["Journals (MAN GLB ALL)*","ExtendedFrame"]
        jrnls=jFrame.FindChildEx(prop,val,60,True,60000)
        jrnls.FindChild("AWTComponentName","FormsTabPanel*",60).ClickTab("Other Information")
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Status: Approval",2]
        jrnl_appr_val = jFrame.FindChild(prop,val,60)
        jrnl_appr_status=jrnl_appr_val.wText  
#        self.log_message_oracle_form(jFrame,"Journal Approval Status: "+jrnl_appr_status)
        web_utils.log_checkpoint("Journal Approval Status: "+jrnl_appr_status,500,jFrame)   
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Status: Posting",0]
        jrnl_val = jFrame.FindChild(prop,val,60)
        jrnl_status=jrnl_val.wText  
#        self.log_message_oracle_form(jFrame,"Journal Status: "+jrnl_status)   
        Log.Enabled=True
        aqObject.CheckProperty(jrnl_val,"wText",cmpIn,"Unposted")
        Log.Enabled=False
#        self.log_message_oracle_form(jFrame,VarToStr(x)+" Journal is Unposted")
        web_utils.log_checkpoint(VarToStr(x)+" Journal is Unposted",500,jFrame)			 
        delay(4000) 
        jrnls.FindChild("AWTComponentName","FormsTabPanel*",60).ClickTab("Lines")
        delay(4000) 
        web_utils.log_checkpoint("Reviewing the Journal Header and Lines Information in "+VarToStr(x),500,jFrame)
#        prop=["AWTComponentAccessibleName","JavaClassName"]
#        val=["Journals (MAN GLB ALL)*","ExtendedFrame"]
#        jrnls=jFrame.FindChildEx(prop,val,30,True,60000)
#        prop=["JavaClassName","AWTComponentIndex"]
#        val=["LWScrollbar","0"]
#        down_button=jrnls.FindChildEx(prop,val,30,True,60000)
#        for i in range(0,10):
#          prop=["JavaClassName","AWTComponentIndex"]
#          val=["ContinuousButton","0"]
#          down_button.Find(prop,val,20).Click()  
#        self.log_message_oracle_form(jFrame,"Intracompany balancing line added by Posting in "+VarToStr(x))        
        delay(4000) 
        jFrame.Keys("[F4]")
        Delay(1000)
#        jFrame.Keys("[F4]")
#        Delay(1000)
#        jFrame.Keys("[F4]")
#        Delay(1000)
        jFrame.Keys("~o")
        Delay(1000)
        jFrame.Keys("~o")
        Delay(1000)
        
    jFrame.Keys("[F4]")
    Delay(3000)
    
#    self.log_message_oracle_form( jFrame,"Switching Responsibility to 'GL Scheduler'") 
    jFrame.Click()
    Delay(2000)
    jFrame.Keys("~f")
    Delay(4000)
    jFrame.Keys("w")
    Delay(4000)

    #Switiching responsibility form identification    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Responsibilities","FWindow"]
    resp_form=jFrame.FindChildEx(prop,val,30,True,60000)
   
    #selecting the responsibility
    resp_form.Find("AWTComponentName","LWTextField*",10).Click() 
    resp_form.Find("AWTComponentName","LWTextField*",10).keys("GL Scheduler")
   
    val = ["Find ALT F","PushButton"]
    resp_form.FindChild(prop,val,20).Click()
    Delay(2000)
    jFrame.Keys("~o")
    Delay(1000)
    jFrame.Keys("~o")
    Delay(1000)
    jFrame.Keys("~o")
    Delay(2000)
#    Submitting the request "Program - Automatic Posting" to post all the Journals
#    jFrame.keys("~v")
#    delay(2000)
#    jFrame.keys("r") 
#    delay(3000)
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Find Requests","ExtendedFrame"]
#    findreq_form=jFrame.FindChildEx(prop,val,30,True,90000)
#   
#    val=["Submit a New Request alt N","Button"]
#    findreq_form.FindChild(prop,val,30).Click()
   
    #Identifying the submit request window and providing request name 
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit Request","ExtendedFrame"]
    submitrequest_form=jFrame.FindChildEx(prop,val,60,True,60000)
    submitrequest_form.Find("AWTComponentAccessibleName","Name RequiredList of Values",10).Click()
    Delay(1000)
    submitrequest_form.Find("AWTComponentAccessibleName","Name RequiredList of Values",10).SetText("Program - Automatic Posting")
    self.log_message_oracle_form(jFrame,"Submitting 'Program - Automatic Posting'") 
    Delay(5000)
    jFrame.Keys("[Tab]")
    Delay(2000)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Parameters","FlexWindow"]
    parameters_form=jFrame.FindChildEx(prop,val,60,True,60000)
    auto_post_txtfield=parameters_form.FindChild("AWTComponentAccessibleName","AutoPost Criteria Set REQUIRED List Values",10)
    auto_post_txtfield.Click()
    auto_post_txtfield.Keys("payroll")
    Delay(2000)
    jFrame.Keys("~o")
    Delay(1000)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit alt m","Button"]
    submitrequest_form.FindChild(prop,val,60).Click()
    Delay(3000)
   
    val = ["Decision Request submitted*","ChoiceBox"]
    decision_box = jFrame.FindChildEx(prop,val,60,True,12000)
    RequestID = aqConvert.VarToInt(''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit()))
    self.log_message_oracle_form( jFrame,"'Program - Automatic Posting' submitted successfully and Request ID is "+VarToStr(RequestID))
    
    jFrame.Keys("~n")
    Delay(3000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000)
    
    Delay(200000)
#    req_form.FindChild(prop,val,2000).Click()
#    delay(4000)
#    req_form.FindChild(prop,val,2000).Click()
#    delay(100000)
       
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,90000) 
    
    self.req_set_save_output(jFrame,req_form,"Program - Automatic Posting",RequestID)
    delay(5000)

    self.req_set_save_output(jFrame,req_form,"Posting: Single Ledger",RequestID)  
    delay(5000)
    
    jFrame.Keys("[F4]")
    Delay(2000) 
#    self.log_message_oracle_form( jFrame,"Switching Responsibility to 'GL Corporate Accouting User'") 
    jFrame.Click()
    Delay(2000)
    jFrame.Keys("~f")
    Delay(4000)
    jFrame.Keys("w")
    Delay(4000)

    #Switiching responsibility form identification    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Responsibilities","FWindow"]
    resp_form=jFrame.FindChildEx(prop,val,30,True,60000)
   
    #selecting the responsibility
    resp_form.Find("AWTComponentName","LWTextField*",10).Click() 
    resp_form.Find("AWTComponentName","LWTextField*",10).keys("GL Corporate Accounting User")
    #   self.verify_aqobject_chkproperty(resp_form,"AWTComponentAccessibleName",cmpContains,"Responsibilities")   
    #   Delay(2000)
   
    val = ["Find ALT F","PushButton"]
    resp_form.FindChild(prop,val,20).Click()
    Delay(2000)
    jFrame.Keys("~o")
    Delay(1000)
    jFrame.Keys("~o")
    Delay(1000)
    
    for x in journal_req_ids:
          
          dsn = self.testConfig['man_oracle_db']['dsn']
          user_id = self.testConfig['man_oracle_db']['userid']
          pwd = self.testConfig['man_oracle_db']['pwd']
          batch_name = dbhelper.return_journal_batch_name(dsn,user_id,pwd,"%"+VarTostr(x))
          res= aqString.Find(batch_name,"Payroll")
          if res != -1:
    #      if batch_name.("Payroll"): #("WK" or "BW"):
        
            prop=["AWTComponentAccessibleName","JavaClassName"]
            val=["Find Journals","ExtendedFrame"]
            fnd_jrnl=jFrame.FindChildEx(prop,val,60,True,90000)
            fnd_jrnl.Find("AWTComponentAccessibleName","BatchList of Values",10).Click()
            fnd_jrnl.Find("AWTComponentAccessibleName","BatchList of Values",10).Keys("%"+VarToStr(x)+"%")
            delay(1000) 
            jFrame.Keys("~i")
#            self.log_message_oracle_form(jFrame,VarToStr(x)+" find Journal Successful")
            web_utils.log_checkpoint(VarToStr(x)+" find Journal Successful",500,jFrame)
            delay(8000) 
            jFrame.Keys("~u")
            delay(4000) 
            prop=["AWTComponentAccessibleName","JavaClassName"]
            val=["Journals (MAN GLB ALL)*","ExtendedFrame"]
            jrnls=jFrame.FindChildEx(prop,val,60,True,60000)
            jrnls.FindChild("AWTComponentName","FormsTabPanel*",60).ClickTab("Other Information")
            prop=["AWTComponentAccessibleName","AWTComponentIndex"]
            val=["Status: Approval",2]
            jrnl_appr_val = jFrame.FindChild(prop,val,60)
            jrnl_appr_status=jrnl_appr_val.wText  
#            self.log_message_oracle_form(jFrame,"Journal Approval Status: "+jrnl_appr_status) 
            web_utils.log_checkpoint("Journal Approval Status: "+jrnl_appr_status,500,jFrame)  
            prop=["AWTComponentAccessibleName","AWTComponentIndex"]
            val=["Status: Posting",0]
            jrnl_val = jFrame.FindChild(prop,val,60)
            jrnl_status=jrnl_val.wText  
#            self.log_message_oracle_form(jFrame,"Journal Status: "+jrnl_status)
#            web_utils.log_checkpoint("Journal Status: "+jrnl_status,500,jFrame)   
            Log.Enabled=True
            aqObject.CheckProperty(jrnl_val,"wText",cmpIn,"Posted")
            Log.Enabled=False
#            self.log_message_oracle_form(jFrame,VarToStr(x)+" Journal is Posted")
            web_utils.log_checkpoint(VarToStr(x)+" Journal is Posted",500,jFrame)
            delay(4000) 
            jrnls.FindChild("AWTComponentName","FormsTabPanel*",60).ClickTab("Lines")
            delay(4000) 
#            self.log_message_oracle_form(jFrame,"Reviewing Journal Header and Lines Information in "+VarToStr(x))
            web_utils.log_checkpoint("Reviewing the Journal Header and Lines Information in "+VarToStr(x),500,jFrame)
    #        prop=["AWTComponentAccessibleName","JavaClassName"]
    #        val=["Journals (MAN GLB ALL)*","ExtendedFrame"]
    #        jrnls=jFrame.FindChildEx(prop,val,30,True,60000)
    #        prop=["JavaClassName","AWTComponentIndex"]
    #        val=["LWScrollbar","0"]
    #        down_button=jrnls.FindChildEx(prop,val,30,True,60000)
    #        for i in range(0,10):
    #          prop=["JavaClassName","AWTComponentIndex"]
    #          val=["ContinuousButton","0"]
    #          down_button.Find(prop,val,20).Click()  
    #        self.log_message_oracle_form(jFrame,"Intracompany balancing line added by Posting in "+VarToStr(x))        
            delay(4000) 
            jFrame.Keys("[F4]")
            Delay(1000)
    #        jFrame.Keys("[F4]")
    #        Delay(1000)
    #        jFrame.Keys("[F4]")
    #        Delay(1000)
            jFrame.Keys("~o")
            Delay(1000)
            jFrame.Keys("~o")
            Delay(1000)

    
    Delay(1000)
    jFrame.Close()
    Delay(1000)
    jFrame.Close()
    Delay(1000)
    jFrame.Keys("~o")
    Delay(1000)
    
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~o")
    Delay(1000)
    
  def req_set_save_output(self,jFrame,req_form,srch_child_name,Preqid,journal_req_ids=[]):
       
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val = ["Refresh Data alt R","Button"]
     req_form.FindChild(prop,val,2000).Click()
       
     for x in range(20,51):
         
       if x>29:
         jFrame.Keys("[Down]")        
         x=29
                      
       prop=["AWTComponentAccessibleName","AWTComponentIndex"]
       val=["Phase",x+20]
       phase=req_form.Find(prop,val,10).wText 
         
       prop=["AWTComponentAccessibleName","AWTComponentIndex"]
       val=["Request ID",x-10]
       creqid=VarToInt(req_form.Find(prop,val,10).wText)
         
       prop=["AWTComponentAccessibleName","AWTComponentIndex"]
       val=["Name",x]
       child_name=req_form.Find(prop,val,10).wText
       req_form.Find(prop,val,10).Click()
         
       prop=["AWTComponentAccessibleName","AWTComponentIndex"]
       val=["Status",x+30]         
       status =req_form.FindChild(prop,val,60) 
         
       if (child_name==srch_child_name) and (creqid>=Preqid) and (creqid not in journal_req_ids)and (phase == "Completed"): 
           
         self.log_message_oracle_form(req_form,aqConvert.VarToStr(srch_child_name)+" Phase Completed Successfuly")            
         self.verify_aqobject_chkproperty(status,"wText",cmpIn,"Normal,Warning")
         self.log_message_oracle_form(req_form,"Request ID of "+aqConvert.VarToStr(srch_child_name)+" is "+aqConvert.VarToStr(creqid))
         req_form.Find(prop,val,10).Keys("[Enter]")
         Delay(1000)
         prop=["AWTComponentAccessibleName","JavaClassName"]
         val=["View Output alt p","Button"]
         output_button=req_form.FindChild(prop,val,60)
         output_button.Find("AWTComponentAccessibleName","View Output alt p").Click()     
         Delay(3000)
         output_page=Sys.Browser("iexplore").Page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
         output_page.Click()
         Delay(2000)
         output_page.Keys("~f")
         Delay(2000)
         output_page.Keys("a")
         Delay(5000)
         file_system_utils.create_folder(self.op_log_path)             
         log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"Is Attached_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
         Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
         Delay(1000)
         Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
         Delay(6000)
         Log.Enabled=True
         Log.File(log_path, aqConvert.VarToStr(srch_child_name)+" Output File Attached")
         Log.Enabled=False    
         Sys.Browser("iexplore").page("https://core-*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close() 
         web_utils.close_additional_browsers() 
         Delay(2000)   
         jFrame.Click()
         Delay(2000)
         return creqid
           
  def req_set_save_log(self,jFrame,req_form,srch_child_name,Preqid,type=""):
    
      prop=["AWTComponentAccessibleName","JavaClassName"]
      val = ["Refresh Data alt R","Button"]
      req_form.FindChild(prop,val,2000).Click() 
         
      for x in range(20,51):
          
        if x>29:
          jFrame.Keys("[Down]")        
          x=29
                        
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Phase",x+20]
        phase=req_form.Find(prop,val,10).wText
           
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Request ID",x-10]
        creqid=VarToInt(req_form.Find(prop,val,10).wText)
          
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Name",x]
        child_name=req_form.Find(prop,val,10).wText
        req_form.Find(prop,val,10).Click()
            
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Status",x+30]         
        status =req_form.FindChild(prop,val,60)
          
        if (child_name==srch_child_name) and (creqid>=Preqid) and (phase == "Completed"): 
            
          self.log_message_oracle_form(req_form,aqConvert.VarToStr(srch_child_name)+" Phase Completed Successfuly")            
          self.verify_aqobject_chkproperty(status,"wText",cmpIn,"Normal,Warning")
          self.log_message_oracle_form(req_form,"Request ID of "+aqConvert.VarToStr(srch_child_name)+" is "+aqConvert.VarToStr(creqid))
          req_form.Find(prop,val,10).Keys("[Enter]")
          Delay(1000)
            
          prop=["AWTComponentAccessibleName","JavaClassName"]
          val=["View Log alt K","Button"]
          log_button=req_form.FindChild(prop,val,60)
          log_button.Click()     
          Delay(3000)
          output_page=Sys.Browser("iexplore").Page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
          output_page.Click()
          Log.Enabled=True
          wnd = Sys.Desktop.ActiveWindow()
          Log.Picture(wnd, f"WinScp File Location path: {type}", wnd.FullName)                 
          Log.Enabled=False
          Delay(2000)
          output_page.Keys("~f")
          Delay(2000)
          output_page.Keys("a")
          Delay(5000)
          file_system_utils.create_folder(self.op_log_path)             
          log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"Is Attached_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
          Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
          Delay(1000)
          Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
          Delay(6000)
          Log.Enabled=True
          Log.File(log_path, aqConvert.VarToStr(srch_child_name)+" Log File Attached")
          Log.Enabled=False    
          Sys.Browser("iexplore").page("https://core-*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close()  
          web_utils.close_additional_browsers()
          Delay(2000)   
          jFrame.Click()
          Delay(2000)
          return creqid


#def unit_test():
#    import dbhelper
##    journal_req_ids=["165556354","165556353","165556350","165556355"] #162812479","162812480","162812481","162812483"]          
##    for x in journal_req_ids:
#          
##          dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
##          user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
##          pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
##          batch_name = dbhelper.return_journal_import_details(dsn,user_id,pwd,"%"+VarTostr(x))
#    batch_name = dbhelper.return_journal_batch_name("MAN_oci_stage","appsread","oracle123","%"+VarTostr(x))
#    Log.Enabled=True
#    Log.Message("The batch name is "+VarToStr(batch_name))
#    Log.Enabled=False
