﻿from base import *
from driverchain import *
from ebiz import *
import test_utility
import gvar
import tc_logs
                   
                   
                   
class Driver(Driverchain):
 global classarr,env
                     
 def __init__(self):
   global test_env, sheet_obj, book     
   app = Sys.OleObject["Excel.Application"]
   Delay(1000)
   self.book = app.Workbooks.Open(Project.Path+"\\datasheets\\E2E\\IS\\E2E_022_IS.xls")          
   app.Visible = "True"    
   self.test_env="oci_stage" #  BuiltIn.ParamStr(14)
   self.oper_unit="US" #BuiltIn.ParamStr(15) 
   ProjectSuite.Variables.currency="USD" #  BuiltIn.ParamStr(16)
#   self.classarr=["tc173265_is_us_project_creation()","tc169768_is_us_create_non_catalog_req()","tc169775_is_us_requisition_approval_validation()","ie_clear_cache()","tc169773_is_us_create_po()","tc169774_is_us_auto_create_po_approval_validation()","tc170429_is_us_ReceivePoItems()","tc170430_is_us_create_manual_ap_invoice_match()","ie_clear_cache()","ie_clear_cache()","tc201347_us_run_prc_nightly_request_set()","validate_db_nightly_process_completion()","tc202036_us_validate_prc_nightly_request_set()"]    
   self.classarr=["tc206490_is_webadi_adjustments()"] 
   super().__init__(self.classarr)
                           
 def close_excel(self):    
   self.book.save()
   delay(1000)
   self.book.close()
                         

def main():
  obj=Driver()
  cobj=obj.run()
  obj.close_excel()
                      
                         
#def main():
# try:
#   #gvar.dataprep['env'] = 'oci_stage'
#   obj=Driver()
#   test_utility.start_test(__name__.center(70,'*'),'Core Financials - CF','MAN E2E','206496','MAN OCI STAGE Regression') 
#   cobj = obj.run()
#   print('evoke test_utility')
# except:
#   gvar.dataprep['verdict'] = 'Fail'
#   tc_logs.header_name('Test Failed - traceback shown below')       
#   tc_logs.error_with_no_picture(traceback.format_exc(),'')       
#   print('evoke test_utility')
# finally:
#   test_utility.end_test()
#   obj.close_excel()
                   
                   
