﻿from dbhelper import *
from ebiz import *
import web_utils
import dbhelper
import file_system_utils 
import form_utils

class asset_tie_back(Ebiz):
 op_log_path="C:\\Tc_Logs"

 def login(self):
   self.login_user='pkjami'
   super().login()
 
 def goto_url(self,url):
  super().goto_url(self.testConfig['ebiz']['oci_is_url'])
   
 def action(self,book): 
   app = book.Sheets.item["Requisition"]
   rowno = 2
   web_utils.log_checkpoint("Logged in to Oracle Applications Home Page Successfully",500,self.page)
   self.wait_until_page_loaded()       
   self.page.EvaluateXPath("//table[@id='menuContent']//div[contains(text(),'PC User')]")[0].Click() 
   web_utils.log_checkpoint("Click 'PC User' - Successful",500,self.page) 
   self.page.Keys("[Down]")
   self.page.Keys("[Down]")
   self.page.Keys("[Down]")
   self.page.Keys("[Down]")
   self.wait_until_page_loaded()
   self.page.NativeWebObject.Find("contentText","Other","A").Click()
   web_utils.log_checkpoint("Click 'Other' - Successful",500,self.page) 
   self.page.Keys("[Down]")
   self.page.Keys("[Down]")
   self.page.NativeWebObject.Find("contentText","Requests","A").Click()
   web_utils.log_checkpoint("Click 'Requests' - Successful",500,self.page)
   self.page.Keys("[Down]")
   self.page.NativeWebObject.Find("contentText","Run","A").Click()
   web_utils.log_checkpoint("Click 'Run' - Successful",500,self.page)
   web_utils.validate_security_box()
   Delay(15000)
   jFrame=self.initializeJFrame()
   form_utils.click_ok_btn(jFrame)  
   jFrame.keys("~o")
   Delay(4000)
 
# Submitting PRC: Tieback Asset Lines from Oracle Assets
 
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Submit Request","ExtendedFrame"]
   submitrequest_form=jFrame.FindChildEx(prop,val,60,True,90000)
   submitrequest_form.Find("AWTComponentAccessibleName","Name RequiredList of Values",10).SetText("PRC: Tieback Asset Lines from Oracle Assets")
   submitrequest_form.Keys("[Tab]")
   self.verify_aqobject_chkproperty(submitrequest_form,"AWTComponentAccessibleName",cmpContains,"Submit Request")
   Delay(2000)
   prop = ["AWTComponentAccessibleName","JavaClassName"]
   val = ["Submit alt m","Button"]
   submitrequest_form.FindChild(prop,val,1000).Click()
   Delay(2000)
   jFrame.keys("~o")
   Delay(2000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Decision Request submitted*","ChoiceBox"]
   decision_form=jFrame.FindChildEx(prop,val,60,True,40000) 
   RequestID = ''.join(x for x in decision_form.AWTComponentAccessibleName if x.isdigit())
   web_utils.log_checkpoint("PRC: Tieback Asset Lines from Oracle Assets Job is submitted and Request ID is " + aqConvert.VarToStr(RequestID),500,jFrame) 
   Delay(2000)
   jFrame.keys("~o")
   Delay(2000)
   jFrame.keys("~n")
   Delay(2000)
   jFrame.Keys("~v")
   Delay(2000)
   jFrame.Keys("r")
   Delay(2000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Find Requests","ExtendedFrame"]
   find_req_form=jFrame.FindChild(prop,val,30)
   Delay(3000)
   jFrame.Keys("[Right]")
   Delay(2000) 
   jFrame.Keys("[Tab]")
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Request ID","VTextField"]
   find_req_form.FindChild(prop,val,60).Click()
   find_req_form.FindChild(prop,val,60).SetText(RequestID)
   jFrame.Keys("~i")
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Requests","ExtendedFrame"]
   req_form=jFrame.FindChild(prop,val,30)
   self.verify_aqobject_chkproperty(req_form,"AWTComponentAccessibleName",cmpContains,"Requests") 
   dsn = self.testConfig['man_oracle_db']['dsn']
   user_id = self.testConfig['man_oracle_db']['userid']
   pwd = self.testConfig['man_oracle_db']['pwd']
   dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,RequestID)
   Delay(2000) 

# Capturing the output file of PRC: Tieback Asset Lines from Oracle Assets

   prop = ["AWTComponentAccessibleName","JavaClassName"]
   val = ["View Output alt p","Button"]
   req_form.FindChild(prop,val,2000).Click() 
   Delay(15000)
   self.wait_until_page_loaded()
   output_page=Sys.Browser("iexplore").Page("https://manheim-*.epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
   output_page.Click()
   Delay(2000)
   output_page.Keys("~f")
   Delay(3000)
   output_page.Keys("a")
   Delay(5000)
   file_system_utils.create_folder(self.op_log_path)             
   log_path=self.op_log_path+"\\PRC Tieback Asset Lines from Oracle Assets Output Is Attached_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
   Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
   Delay(1000)
   Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Window("DUIViewWndClassName", "", 1).UIAObject("Explorer_Pane").Window("FloatNotifySink", "", 3).Window("ComboBox", "", 1).Click()
   Delay(1000)
   Sys.Browser("iexplore").Window("ComboLBox", "", 1).ClickItem("Text File (*.txt)")
   Delay(1000)
   Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
   Delay(4000)
   Log.Enabled=True
   Log.File(log_path, "PRC: Tieback Asset Lines from Oracle Assets Program is completed and output file is attached")
   Log.Enabled=False     
   Sys.Browser("iexplore").Page("https://manheim-*.epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close()
   Delay(2000)   
   jFrame.Keys("[F4]")
   Delay(2000) 

# Capturing the output file of PRC: Tieback Asset Lines from Oracle Assets

   jFrame.keys("c")
   Delay(1000)
   jFrame.keys("~o")
   Delay(3000)
   project_no =BuiltIn.ParamStr(16)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Find Capital Projects","ExtendedFrame"]
   findcapitalprojects_form=jFrame.FindChild(prop,val,60)
   findcapitalprojects_form.Find("AWTComponentAccessibleName","Project: NumberList of Values",10).Keys(project_no)
   findcapitalprojects_form.Keys("[Tab]")
   findcapitalprojects_form.Keys("[Tab]")
   self.verify_aqobject_chkproperty(findcapitalprojects_form,"AWTComponentAccessibleName",cmpContains,"Find Capital Projects")
   Delay(3000)
   prop = ["AWTComponentAccessibleName","JavaClassName"]
   val = ["Find alt i","Button"]
   findcapitalprojects_form.FindChild(prop,val,60).Click()
   Delay(3000)
   self.verify_aqobject_chkproperty(findcapitalprojects_form,"AWTComponentAccessibleName",cmpContains,"Capital Projects")
   web_utils.log_checkpoint("Project "+VarToStr(project_no)+" found Capital Projects Details screen",500,jFrame)
   jFrame.keys("~a") 
   Delay(1000) 
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=[" Assets*","ExtendedFrame"]
   asset_form=jFrame.FindChildEx(prop,val,60,True,40000)
   asset_form.Find("AWTComponentName","FormsTabPanel*",20).ClickTab("Asset Details")
   web_utils.log_checkpoint("Assets Details Verified",500,jFrame)
   Delay(2000)
   prop=["AWTComponentIndex","JavaClassName","AWTComponentAccessibleName"]
   val=[30,"VTextField","Asset*"]
   Assetnum = jFrame.FindChild(prop,val,60).wText   
   web_utils.log_checkpoint("Asset Number which is Tied Back : "+aqConvert.VarToStr(Assetnum),500,jFrame)
   asset_form.Close()
   Delay(2000)
   findcapitalprojects_form.Close()
   Delay(1000)
   jFrame.Close()
   Delay(1000)
   jFrame.Keys("~o")
   
   del app,prop,val,jFrame,Assetnum,findcapitalprojects_form



