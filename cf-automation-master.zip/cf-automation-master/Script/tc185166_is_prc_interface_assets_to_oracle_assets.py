﻿from dbhelper import *
from ebiz import *
import web_utils
import dbhelper
import file_system_utils

class tc185166_is_prc_interface_assets_to_oracle_assets(Ebiz):

 op_log_path ="C:\\TC_Logs"

 def login(self):
  self.login_user='pkjami'
  super().login()
  
 def goto_url(self,url):
  super().goto_url(self.testConfig['ebiz']['oci_is_url'])
   
 def action(self,book): 
   
   app = book.Sheets.item["Requisition"]
   rowno = 2
   web_utils.log_checkpoint("Logged in to Oracle Applications Home Page Successfully",500,self.page)
   self.wait_until_page_loaded()       
   self.page.EvaluateXPath("//table[@id='menuContent']//div[contains(text(),'PC User')]")[0].Click() 
   web_utils.log_checkpoint("Click 'PC User' - Successful",500,self.page) 
   self.page.Keys("[Down]")
   self.page.Keys("[Down]")
   self.page.Keys("[Down]")
   self.page.Keys("[Down]")
   self.wait_until_page_loaded()
   self.page.NativeWebObject.Find("contentText","Other","A").Click()
   web_utils.log_checkpoint("Click 'Other' - Successful",500,self.page) 
   self.page.Keys("[Down]")
   self.page.Keys("[Down]")
   self.page.NativeWebObject.Find("contentText","Requests","A").Click()
   web_utils.log_checkpoint("Click 'Requests' - Successful",500,self.page)
   self.page.Keys("[Down]")
   self.page.NativeWebObject.Find("contentText","Run","A").Click()
   web_utils.log_checkpoint("Click 'Run' - Successful",500,self.page)
   web_utils.validate_security_box()
   Delay(15000)
   jFrame=self.initializeJFrame()
   form_utils.click_ok_btn(jFrame)  
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Submit a New Request","ExtendedFrame"]
   submit_req_form=jFrame.FindChildEx(prop,val,30,True,60000)
   submit_req_form.FindChild("AWTComponentAccessibleName","OK alt O",10).Click()
   Delay(2000)

  
#Submit PRC: Interface Assets to Oracle Assets 

   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Submit Request","ExtendedFrame"]
   submitrequest_form=jFrame.FindChildEx(prop,val,60,True,90000)
   self.verify_aqobject_chkproperty(submitrequest_form,"AWTComponentAccessibleName",cmpContains,"Submit Request")
   submitrequest_form.Find("AWTComponentAccessibleName","Name RequiredList of Values",30).SetText("PRC: Interface Assets to Oracle Assets")
   web_utils.log_checkpoint("Request Name: 'PRC: Interface Assets to Oracle Assets' - populated Successfully",500,jFrame)
   jFrame.Keys("[Tab]")
   Delay(8000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Parameters","FlexWindow"]
   parameters_form=jFrame.FindChildEx(prop,val,60,True,20000)
   jFrame.Find("AWTComponentAccessibleName","From Project Number REQUIRED",30).Click()  
   jFrame.Find("AWTComponentAccessibleName","From Project Number REQUIRED",30).Keys(app.Cells.Item[rowno,11])
   Delay(3000)
   jFrame.Keys("[Tab]")
   Delay(3000)
   web_utils.log_checkpoint("'PRC: Interface Assets to Oracle Assets' parameters entered successfully",500,jFrame)
   jFrame.keys("~o")
   Delay(2000)
   jFrame.keys("~m")
   Delay(3000)

# Capturing RequestID

   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Decision","LWLabel"]
   parameters_form=jFrame.FindChildEx(prop,val,60,True,60000)
   Delay(2000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Decision Request Submitted*","ChoiceBox"]
   decision_form=jFrame.FindChild(prop,val,60)
   RequestID = ''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit())
   web_utils.log_checkpoint("'PRC: Interface Assets to Oracle Assets' is submitted and Request ID is " + aqConvert.VarToStr(RequestID),500,jFrame)
   Delay(2000)
   Rid =aqConvert.VarToStr(RequestID)
   jFrame.Keys("~n")
   Delay(9900)   
   dsn = self.testConfig['man_oracle_db']['dsn']
   user_id = self.testConfig['man_oracle_db']['userid']
   pwd = self.testConfig['man_oracle_db']['pwd']
   dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,RequestID)
   
#Capturing Outputs for PRC: Interface Assets to Oracle Assets 

   jFrame.Keys("~v")
   Delay(4000)
   jFrame.Keys("r")
   Delay(4000)
   jFrame.Keys("~s")
   prop_names=["JavaClassName","AWTComponentAccessibleName"]
   prop_values=["VTextField","Request ID"]
   temp=jFrame.FindAll(prop_names,prop_values,60)
   jFrame.Find("AWTComponentName",temp[10].AWTComponentName,60).Click()
   jFrame.Find("AWTComponentName",temp[10].AWTComponentName,60).SetText(RequestID)
   Delay(2000)
   web_utils.log_checkpoint("Query for 'PRC: Interface Assets to Oracle Assets' submitted Request ID:" +RequestID,500,jFrame)
   jFrame.Keys("~i")
   Delay(2000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Requests","ExtendedFrame"]
   req_form=jFrame.FindChildEx(prop,val,30,True,60000)
   prop=["AWTComponentAccessibleName","AWTComponentIndex"]
   val=["Phase",40]
   phase=req_form.Find(prop,val,10).wText 
   while phase != "Completed":
     Delay(1000)
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val = ["Refresh Data alt R","Button"]
     req_form.FindChild(prop,val,2000).Click() 
     Delay(4000)
     phase=req_form.Find(prop,val,10).wText 
   web_utils.log_checkpoint("'PRC: Interface Assets to Oracle Assets ' program phase Completed",500,jFrame)
   Delay(1000)
   jFrame.Keys("~k")
   file_type = 'Log'
   self.save_log(file_type)
   delay(4000)
   jFrame.Keys("~p")
   file_type = 'Output'
   self.save_log(file_type)
   Delay(6000)
   jFrame.Keys("[F4]")
   Delay(4000)
   jFrame.Keys("[F4]")
   Delay(2000)
   jFrame.Keys("~o")
   Delay(2000)
   self.page.wait_until_page_loaded()
   
#Finding capital projects
   self.page.Keys("[Up]")
   self.page.Keys("[Up]")
   self.page.NativeWebObject.Find("contentText","Capitalization","A").Click()
   web_utils.log_checkpoint("Click 'CAPITALIZATION' - Successful",500,self.page)
#   self.page.Keys("[Down]") 
   Delay(2000)
   self.wait_until_page_loaded() 
   self.page.NativeWebObject.Find("contentText","Capital Projects","A").Click()
   web_utils.log_checkpoint("Click 'Capital Projects' - Successful",500,self.page)  
   Delay(2000)
   web_utils.validate_security_box()
   Delay(15000)
   jFrame=self.initializeJFrame()
   form_utils.click_ok_btn(jFrame)
   delay(2000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Find Capital Projects","ExtendedFrame"]
   findcapitalprojects_form=jFrame.FindChildEx(prop,val,60,True,90000)
   self.verify_aqobject_chkproperty(findcapitalprojects_form,"AWTComponentAccessibleName",cmpContains,"Find Capital Projects")
   findcapitalprojects_form.Find("AWTComponentAccessibleName","Project: NumberList of Values",10).SetText(app.Cells.item[rowno,11])
   web_utils.log_checkpoint("Project Number Entered in Capital Projects screen is : "+ VarToStr(app.Cells.item[rowno,11]),500,jFrame)
   findcapitalprojects_form.Keys("[Tab]")
   findcapitalprojects_form.Keys("[Tab]")
   Delay(3000)
   findcapitalprojects_form.Find("AWTComponentAccessibleName","Find alt i",10).Click()
   Delay(3000) 
   self.verify_aqobject_chkproperty(findcapitalprojects_form,"AWTComponentAccessibleName",cmpContains,"Capital Projects")
   web_utils.log_checkpoint("Capital Projects Details page launched successfully",500,jFrame)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Capital Projects (Manheim Corporate Services)","ExtendedFrame"]
   capitalprojects_form=jFrame.FindChildEx(prop,val,60,True,90000) 
   capitalprojects_form.Find("AWTComponentAccessibleName","Assets alt A",10).Click()  
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=[" Assets*","ExtendedFrame"]
   asset_form=jFrame.FindChildEx(prop,val,60,True,40000)
   Delay(2000) 
   while not asset_form.Exists:
     Delay(2000)
     asset_form=jFrame.FindChild(prop,val,60)
   web_utils.log_checkpoint("Assets Form launched successfully",500,jFrame)
   Delay(2000) 
   asset_form.Find("AWTComponentAccessibleName","Asset Lines alt i",10).Click() 
   Delay(2000)  
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Asset Lines*","ExtendedFrame"]
   asset_lines=jFrame.FindChildEx(prop,val,30,True,40000)
   self.verify_aqobject_chkproperty(asset_lines,"AWTComponentAccessibleName",cmpStartsWith,"Asset Lines")
   
   prop=["AWTComponentAccessibleName","AWTComponentIndex"]
   val=["Additional Line Information: Transfer Status",43]
   asst_line_status = jFrame.FindChild(prop,val,60)
   Log.Enabled=True
   aqObject.CheckProperty(asst_line_status ,"wText",cmpIn,"Transferred")
   Log.Enabled=False
   web_utils.log_checkpoint("'Asset Lines Information' reviewed successfully",500,jFrame)
   
   asset_lines.Find("AWTComponentAccessibleName","Details alt D",10).Click() 
   delay(2000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Asset Line Details (Manheim Corporate Services)*","ExtendedFrame"]
   asset_line_details=jFrame.FindChildEx(prop,val,60,True,90000)
   prop = ["AWTComponentAccessibleName","AWTComponentIndex","JavaClassName"]
   val = ["CIP Cost","60","VTextField"]
   cip_cost = asset_line_details.FindChild(prop,val,30).wText
   if(VarToFloat(cip_cost) <= 0.00):
     self.log_error_message(f"CIP Cost: {cip_cost}. CIP COST is not positive")
   web_utils.log_checkpoint("'Asset Line Details' reviewed successfully",500,jFrame) 
   delay(1000)
   self.close_forms(jFrame)
   del app,jFrame


   
 def save_log(self,file_type):
   
   Delay(15000)
   self.wait_until_page_loaded()
   log_page=Sys.Browser("iexplore").Page("https://manheim-*.epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
   Delay(1000)
   log_page.Click()
   log_page.TextNode(0).Click()
   Delay(1000)
   Log.Enabled=True     
   screenshot=log_page.PagePicture()
   msg = (file_type+" File Opened Successfully")
   Log.Picture(screenshot,msg)
   Log.Enabled=False
   log_page.Keys("~f")
   Delay(5000)
   log_page.Keys("a")
   Delay(5000) 
   file_system_utils.create_folder(self.op_log_path)             
   log_path=self.op_log_path+"\\prc interface assets to oracle assets "+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
   Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
   Delay(1000)
   Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
   Delay(5000)
   Log.Enabled=True
   Log.File(log_path,"PRC: Interface Assets to Oracle Assets Request "+file_type+" File Attached")
   Log.Enabled=False     
   Sys.Browser("iexplore").Page("https://manheim-*.epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
   web_utils.close_additional_browsers()
   
   
   

