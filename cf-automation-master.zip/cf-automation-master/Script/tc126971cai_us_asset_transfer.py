﻿from dbhelper import *
from ebiz import *
import web_utils
import dbhelper
import file_system_utils 
import form_utils

class tc126971cai_us_asset_transfer(Ebiz):
 op_log_path="C:\\Tc_Logs"

 def login(self):
   self.login_user='rmaran'
   super().login()
   
 def action(self,book): 
   app = book.Sheets.item["PA-FA"] 
   rowno=2
   self.page.wait()
   web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" FA ASSET TRANSACTION')]")
   self.log_message_web("Click 'CAI "+self.oper_unit+" FA ASSET TRANSACTION' - Successful")
   Delay(2000)
   self.page.wait()
   self.page.EvaluateXpath("//table[@id='respList']//div[text()='Assets']")[0].Click()
   self.log_message_web("Click 'Assets' - Successful")
   Delay(2000)
   self.page.wait()
   self.page.EvaluateXpath("//table[@id='respList']//div[text()='Asset Workbench']")[0].Click()
   self.log_message_web("Click 'Asset Workbench' - Successful")
#   Delay(8000) 
#   web_utils.validate_security_box()
   Delay(15000)
   jFrame=self.initializeJFrame()
   Delay(3000)
   form_utils.click_ok_btn(jFrame)
   self.log_message_oracle_form(jFrame,"Navigation Successful : CAI "+self.oper_unit+" FA ASSET Transaction > Assets > Asset Workbench; 'Find Assets' form launched successfully")
   Delay(4000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Find Assets","ExtendedFrame"]
   findassets_form=jFrame.FindChildEx(prop,val,60,True,60000)
   Delay(4000)
   findassets_form.Find("AWTComponentAccessibleName","Asset Number",10).Click()
   findassets_form.Find("AWTComponentAccessibleName","Asset Number",10).Keys(app.Cells.item[rowno,1])
   findassets_form.Keys("[Tab]")
   self.log_message_oracle_form( findassets_form,"In 'Find Asset' form: Enter Asset Number - " + VarToStr(app.Cells.item[rowno,1]))
   Delay(3000)
   self.log_message_oracle_form( findassets_form,"In 'Find Asset' form: Click 'Find' Button Next")
   findassets_form.Find("AWTComponentAccessibleName","Find alt i",10).Click()
   Delay(3000)
   self.log_message_oracle_form( findassets_form,"'Assets' form launched successfully")
#   findassets_form.Keys("~i")
   Delay(3000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Assets","ExtendedFrame"]
   assets_form=jFrame.FindChildEx(prop,val,60,True,40000)
   self.log_message_oracle_form(jFrame,"In 'Find Asset' form: Click on 'Assignments' button")
   assets_form.Find("AWTComponentAccessibleName","Assignments alt g",10).Click()
#   assets_form.keys("~g")
   Delay(2000)
   self.log_message_oracle_form(jFrame,"'Assignments' form launched successfully")
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Assignments","ExtendedFrame"]   
   assingments_form=jFrame.FindChildEx(prop,val,60,True,60000)
   prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
   val=["Unit\nChange","VTextField",16]  
   assingments_form.Find(prop,val,10).Click()    
   assingments_form.Find(prop,val,10).Keys("-1")
   self.log_message_oracle_form( jFrame,"In 'Assignments' form: In the first line update 'Unit' to '-1'")
   Delay(2000)
   assingments_form.Find(prop,val,10).keys("[Down]")
   prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
   val=["Unit\nChange Required","VTextField",17]   
   assingments_form.Find(prop,val,10).Click()   
   assingments_form.Find(prop,val,10).Keys("1")
   self.log_message_oracle_form( jFrame,"In 'Assignments' form: In the second line add 'Unit' to '1'")
   delay(1000)
   prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
   val=["Expense Account RequiredList of Values","VTextField",57]  
   assingments_form.Find(prop,val,10).Click()
   delay(1000)    
   assingments_form.Find(prop,val,10).keys("ETS.0000.76052.0000.0000.0000000.000.0000")
   self.log_message_oracle_form( jFrame,"In 'Assignments' form: New 'Expense Account' given - ETS.0000.76052.0000.0000.0000000.000.0000")
   Delay(2000)
   prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
   val=["Location RequiredList of Values","VTextField",67]   
   assingments_form.Find(prop,val,10).Click()
   delay(1000)   
   assingments_form.Find(prop,val,10).Keys("3400 NEW HYDE PARK RD.FLOOR 1.NEW HYDE PARK.NASSAU.NY.US")
   Delay(9000)
   assingments_form.keys("[Tab]")
   self.log_message_oracle_form( jFrame,"In 'Assignments' form: New 'Location' given - 3400 NEW HYDE PARK RD.FLOOR 1.NEW HYDE PARK.NASSAU.NY.US")
   delay(1000)
   self.log_message_oracle_form( jFrame,"In 'Assignments' form: Click on 'Done' Button")
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Done alt D","Button"]
   assingments_form.Find(prop,val,10).Click()
#   assingments_form.keys("~d") 
   Delay(6000)
   self.log_message_oracle_form( jFrame,"Transactions Complete Note")
   Delay(2000)
   jFrame.keys("~o")
   Delay(2000)
   self.log_message_oracle_form( jFrame,"Click 'F4' to Close form")
   jFrame.Keys("[F4]")
   Delay(2000)
   jFrame.Keys("~f")
   Delay(1000)
   jFrame.Keys("w")
   Delay(3000)
   self.log_message_oracle_form( jFrame,"Switch Responsibility to CAI"+self.oper_unit +"FA INQUIRY by clicking File > Switch Responsibility")       
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Responsibilities","FWindow"]
   resp_form=jFrame.FindChildEx(prop,val,30,True,40000)
   resp_form.Find("AWTComponentName","LWTextField*",10).Click() 
   resp_form.Find("AWTComponentName","LWTextField*",10).keys("CAI "+self.oper_unit+" FA INQUIRY")
#   self.verify_aqobject_chkproperty(resp_form,"AWTComponentAccessibleName",cmpContains,"Responsibilities")   
   Delay(2000)
   jFrame.Keys("~f")
   self.log_message_oracle_form( jFrame,"Reponsiblity Switched to "+"'CAI "+self.oper_unit+" FA INQUIRY'")
   Delay(4000)
   form_utils.Nav_Submit_Single_Request(self,jFrame)       
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Submit Request","ExtendedFrame"]
   submitrequest_form=jFrame.FindChild(prop,val,60)

#   submitrequest_form.Find("AWTComponentAccessibleName","Name RequiredList of Values",10).Keys("Asset Transfers Report")   
   delay(2000)
   jFrame.Keys("Asset Transfers Report")
   

   self.log_message_oracle_form( jFrame,"Submiting 'Asset Transfers Report' concurrent request")
   Delay(2000)
   submitrequest_form.Find("AWTComponentAccessibleName","Parameters",10).Click()
#   submitrequest_form.Keys("[Tab]")
   Delay(2000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Parameters","FlexWindow"]
   parameters_form=jFrame.FindChild(prop,val,60)
   book_txtfield=parameters_form.FindChild("AWTComponentAccessibleName","Book REQUIRED List Values",10)
   book_txtfield.Click()
   book_txtfield.Keys("ATG CORP")
   self.log_message_oracle_form( jFrame,"Asset Transfer Report' Parameters:'BOOK'-'ATG CORP'")
   Delay(1000)
   parameters_form.Keys("[Tab]")
   Delay(1000)
   parameters_form.Keys("[Tab]")
   Delay(1000)
   parameters_form.Keys(aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%b-%y"))
   self.log_message_oracle_form( jFrame,"Asset Transfer Report' Parameters:'Currency' and 'Period' entered successfully")
   Delay(1000)
   self.log_message_oracle_form( jFrame,"Click OK Button Next")
   parameters_form.keys("~o")
   Delay(2000)
   self.log_message_oracle_form( jFrame,"Click Submit Button Next")
   submitrequest_form.Find("AWTComponentAccessibleName","Submit alt m",10).Click()
#   jFrame.Keys("~m")
   Delay(3000)
   form_utils.capture_reqid_and_save_output_singlereq(self,jFrame,self.op_log_path,"AssetTransfersReport")
   Delay(2000)   
   jFrame.Keys("[F4]")
   Delay(3000)
   jFrame.Keys("i")
   Delay(3000)
   jFrame.Keys("t")
   Delay(2000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Find Transactions","ExtendedFrame"]  
   find_transactions=jFrame.FindChildEx(prop,val,60,True,60000)
   find_transactions.Find("AWTComponentAccessibleName","Book RequiredList of Values",10).Click()
   find_transactions.Find("AWTComponentAccessibleName","Book RequiredList of Values",10).Keys("ATG CORP")
   jFrame.Keys("[Tab]")
   Delay(3000)
   find_transactions.Find("AWTComponentAccessibleName","From Asset Number RequiredList of Values",10).Click()
   find_transactions.Find("AWTComponentAccessibleName","From Asset Number RequiredList of Values",10).Keys(app.Cells.item[rowno,1])
   Delay(3000)
   find_transactions.Find("AWTComponentAccessibleName","Transaction TypeList of Values",10).Click()
   find_transactions.Find("AWTComponentAccessibleName","Transaction TypeList of Values",10).Keys("TRANSFER")
   jFrame.Keys("[Tab]")
   Delay(3000)
   self.log_message_oracle_form( jFrame,"Review Search Parameters for 'Transaction History'")	
   Delay(3000)
   find_transactions.Find("AWTComponentAccessibleName","Find alt i",10).Click()
   Delay(6000)
   self.log_message_oracle_form( jFrame,"Review Transaction History Information")
   Delay(1000)
   self.log_message_oracle_form( jFrame,"In Transaction History form: Click on 'Details' next")
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Transaction History","ExtendedFrame"]  
   transaction_history=jFrame.FindChildEx(prop,val,60,True,60000)
   transaction_history.Find("AWTComponentAccessibleName","Details alt D",10).Click()
   Delay(6000)
   self.log_message_oracle_form( jFrame,"Review Transaction History Details")
   Delay(1000)
   self.log_message_oracle_form( jFrame,"In Transaction Detail form: New 'Expense Account' and New 'Location' reviewed successfully")
   Delay(1000)
   jFrame.Keys("[F4]")
   Delay(500)
   jFrame.Keys("[F4]") # close Form ( Close Navigator)
   Delay(3000)
   jFrame.keys("~o")
   Delay(2000)
   book.save()
   Delay(2000)
   Sys.Browser("iexplore", 2).Window("#32770", "View Downloads - Internet Explorer", 1).keys("~c")
#   Sys.Browser("iexplore").page("https://core-*.epfinnp.coxautoinc.com/forms/frmservlet*").Close()
