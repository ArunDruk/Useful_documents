﻿from dbhelper import *
from ebiz import *
import web_utils
import dbhelper
import file_system_utils

class prc_update_project_summary_amounts_single_project(Ebiz):

 op_log_path ="C:\\TC_Logs"

 def login(self):
  self.login_user='pkjami'
  super().login()
  
 def goto_url(self,url):
  super().goto_url(self.testConfig['ebiz']['oci_is_url'])
   
 def action(self,book): 
   global rowno
   app = book.Sheets.item["Requisition"]
   rowno = 2
   app.Cells.item[rowno,11] = BuiltIn.ParamStr(16)
   
   cond_po_created = BuiltIn.ParamStr(18)
   cond_manual_expd_created = BuiltIn.ParamStr(19)
   
   if str(cond_po_created).lower() == 'no' and str(cond_manual_expd_created).lower() == 'no':
     web_utils.log_error("Either Purchase Order OR Manual Expenditure must be present")
   
   self.navigation_flow(app,rowno)
   if str(cond_manual_expd_created).lower() == 'yes':
      self.validating_manual_expd(app,rowno)

   if str(cond_po_created).lower() == 'yes':
     self.validating_project_commitment(app,rowno)
   self.closing_forms()
   
   
 def navigation_flow(self,app,rowno):
     web_utils.log_checkpoint("Logged in to Oracle Applications Home Page Successfully",500,self.page)
     self.wait_until_page_loaded()       
     self.page.EvaluateXPath("//table[@id='menuContent']//div[contains(text(),'PC User')]")[0].Click() 
     web_utils.log_checkpoint("Click 'PC User' - Successful",500,self.page) 
     self.page.Keys("[Down]")
     self.page.Keys("[Down]")
     self.page.Keys("[Down]")
     self.page.Keys("[Down]")
     self.wait_until_page_loaded()
     self.page.NativeWebObject.Find("contentText","Other","A").Click()
     web_utils.log_checkpoint("Click 'Other' - Successful",500,self.page) 
     self.page.Keys("[Down]")
     self.page.Keys("[Down]")
     self.page.NativeWebObject.Find("contentText","Requests","A").Click()
     web_utils.log_checkpoint("Click 'Requests' - Successful",500,self.page)
     self.page.Keys("[Down]")
     self.page.NativeWebObject.Find("contentText","Run","A").Click()
     web_utils.log_checkpoint("Click 'Run' - Successful",500,self.page)
     web_utils.validate_security_box()
     Delay(15000)
     jFrame=self.initializeJFrame()
     form_utils.click_ok_btn(jFrame)  
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Submit a New Request","ExtendedFrame"]
     submit_req_form=jFrame.FindChildEx(prop,val,30,True,60000)
     submit_req_form.FindChild("AWTComponentAccessibleName","OK alt O",10).Click()
     Delay(2000)

  
  #Submit PRC: Update Project Summary Amounts for a Single Project

     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Submit Request","ExtendedFrame"]
     submitrequest_form=jFrame.FindChildEx(prop,val,60,True,90000)
     self.verify_aqobject_chkproperty(submitrequest_form,"AWTComponentAccessibleName",cmpContains,"Submit Request")
     submitrequest_form.Find("AWTComponentAccessibleName","Name RequiredList of Values",30).SetText("PRC: Update Project Summary Amounts for a Single Project")
     web_utils.log_checkpoint("Request Name: 'PRC: Update Project Summary Amounts for a Single Project' - populated Successfully",500,jFrame)
     jFrame.Keys("[Tab]")
     Delay(8000)
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Parameters","FlexWindow"]
     parameters_form=jFrame.FindChildEx(prop,val,60,True,20000)
     jFrame.Find("AWTComponentAccessibleName","Project Number REQUIRED List Values",30).Click()  
     jFrame.Find("AWTComponentAccessibleName","Project Number REQUIRED List Values",30).Keys(app.Cells.Item[rowno,11])
     Delay(3000)
     jFrame.Keys("[Tab]")
     Delay(3000)
     web_utils.log_checkpoint("'PRC: Update Project Summary Amounts for a Single Project' parameters entered successfully",500,jFrame)
     jFrame.keys("~o")
     Delay(2000)
     jFrame.keys("~m")
     Delay(3000)

  # Capturing RequestID

     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Decision","LWLabel"]
     parameters_form=jFrame.FindChildEx(prop,val,60,True,60000)
     Delay(2000)
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Decision Request Submitted*","ChoiceBox"]
     decision_form=jFrame.FindChild(prop,val,60)
     RequestID = ''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit())
     web_utils.log_checkpoint("'PRC: Update Project Summary Amounts for a Single Project' is submitted and Request ID is " + aqConvert.VarToStr(RequestID),500,jFrame)
     Delay(2000)
     Rid =aqConvert.VarToStr(RequestID)
     jFrame.Keys("~n")
     Delay(9900)   
     dsn = self.testConfig['man_oracle_db']['dsn']
     user_id = self.testConfig['man_oracle_db']['userid']
     pwd = self.testConfig['man_oracle_db']['pwd']
     dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,RequestID)
   
  #Capturing Outputs for PRC: Interface Assets to Oracle Assets 

     jFrame.Keys("~v")
     Delay(4000)
     jFrame.Keys("r")
     Delay(4000)
     jFrame.Keys("~s")
     prop_names=["JavaClassName","AWTComponentAccessibleName"]
     prop_values=["VTextField","Request ID"]
     temp=jFrame.FindAll(prop_names,prop_values,60)
     jFrame.Find("AWTComponentName",temp[10].AWTComponentName,60).Click()
     jFrame.Find("AWTComponentName",temp[10].AWTComponentName,60).SetText(RequestID)
     Delay(2000)
     web_utils.log_checkpoint("Query for 'PRC: Update Project Summary Amounts for a Single Project' submitted Request ID:" +RequestID,500,jFrame)
     jFrame.Keys("~i")
     Delay(2000)
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Requests","ExtendedFrame"]
     req_form=jFrame.FindChildEx(prop,val,30,True,60000)
     prop=["AWTComponentAccessibleName","AWTComponentIndex"]
     val=["Phase",40]
     phase=req_form.Find(prop,val,10).wText 
     while phase != "Completed":
       Delay(1000)
       prop=["AWTComponentAccessibleName","JavaClassName"]
       val = ["Refresh Data alt R","Button"]
       req_form.FindChild(prop,val,2000).Click() 
       Delay(4000)
       phase=req_form.Find(prop,val,10).wText 
     web_utils.log_checkpoint("'PRC: Update Project Summary Amounts for a Single Project' program phase Completed",500,jFrame)
     Delay(1000)
     jFrame.Keys("~k")
     file_type = 'Log'
     program_name="PRC Update Project Summary Amounts for a Single Project"
#     self.save_log(file_type)
     self.save_log(file_type,program_name)
     delay(4000)
     jFrame.Keys("~p")
     file_type = 'Output'
#     self.save_log(file_type)
     self.save_log(file_type,program_name) 
     Delay(6000)
     jFrame.Keys("[F4]")
     Delay(4000)
#   jFrame.Keys("[F4]")
#   Delay(2000)
#   jFrame.Keys("~o")
#   Delay(2000) 

 def validating_manual_expd(self,app,rowno):
#      import web_utils     
      jFrame=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1)
      delay(2000)
      jFrame.Keys("~v")
      delay(1000)
      jFrame.Keys("r")
      delay(3000)
      jFrame.Keys("~n")
      delay(3000)
      jFrame.Keys("PRC: Distribute Usage and Miscellaneous Costs")
      delay(1000)
      web_utils.log_checkpoint("Entered the request 'PRC: Distribute Usage and Miscellaneous Costs'",500,jFrame)
      delay(3000)
      jFrame.Keys("[Tab]")
      delay(2000)
      jFrame.Keys("[Tab]")
      delay(2000)
      jFrame.Keys(app.Cells.Item[rowno,11])
      delay(1000)
      web_utils.log_checkpoint("Entered the parameters for 'PRC: Distribute Usage and Miscellaneous Costs'",500,jFrame)
      delay(2000)
      jFrame.Keys("~o")
      delay(2000)     
      jFrame.Keys("~m")
      delay(1000)
      web_utils.log_checkpoint("Submitting the request 'PRC: Distribute Usage and Miscellaneous Costs'",500,jFrame)
      delay(2000)
      prop=["AWTComponentAccessibleName","JavaClassName"]
      val=["Decision Request submitted*","ChoiceBox"]
      decision_form=jFrame.FindChildEx(prop,val,60,True,40000)
      self.verify_aqobject_chkproperty(decision_form,"AWTComponentAccessibleName",cmpContains,"Request submitted") 
      RequestID = ''.join(x for x in decision_form.AWTComponentAccessibleName if x.isdigit())
      jFrame.Keys("~n")
      delay(2000) 
      
      jFrame.Keys("~v")
      Delay(2000)
      jFrame.Keys("r")
      Delay(2000)    
      jFrame.Keys("~s")
      Delay(2000)
      jFrame.Keys("[Tab]")
      delay(1000)
      jFrame.Keys(RequestID)
      delay(1000)
      jFrame.Keys("~q")
      delay(1000)
      jFrame.Keys("~i")
      Delay(2000) 
      web_utils.log_checkpoint("Launched Find Requests Form Succeessfully",500,jFrame)
      delay(2000)
      program_name="PRC Distribute Usage and Miscellaneous Costs"
      jFrame.Keys("~p")
      file_type = 'Output'
      self.save_log(file_type,program_name)
      delay(2000)
      jFrame.Keys("[F4]")
      delay(3000)
                       
 def validating_project_commitment(self,app,rowno):
#      import web_utils
      jFrame=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1)
      delay(2000)
      jFrame.Keys("~f")
      delay(1000)
      jFrame.Keys("w")
      delay(3000)
#Switiching responsibility form identification    
      prop=["AWTComponentAccessibleName","JavaClassName"]
      val=["Responsibilities","FWindow"]
      resp_form=jFrame.FindChildEx(prop,val,30,True,60000)
   
      #selecting the responsibility
      resp_form.Find("AWTComponentName","LWTextField*",10).Click() 
      resp_form.Find("AWTComponentName","LWTextField*",10).keys("PC Inquiry")
      val = ["Find ALT F","PushButton"]
      resp_form.FindChild(prop,val,20).Click()
      delay(2000)
      jFrame.Keys("[Down]")
      delay(2000)
      jFrame.Keys("[Down][Down][Down]")
      delay(2000)
      jFrame.Keys("~o")
      delay(1000)
      web_utils.log_checkpoint(" Navigating to 'PC Inquiry' -> 'Project Status' -> 'Project Status Inquiry' successful",500,jFrame) 
      delay(2000)
      jFrame.Keys("~o")
      delay(3000)
#      Navigate to 'Find Project Status' Form:
      prop=["AWTComponentAccessibleName","JavaClassName"]
      val=["Find Project Status (Manheim Corporate Services)","ExtendedFrame"]
      proj_status = jFrame.FindChildEx(prop,val,40,True,90000)
      Sys.HighlightObject(proj_status)
      Delay(2000)
      web_utils.log_checkpoint("Navigation to  'Find Project Status Form' - Successful",500,jFrame)   
     
      # Enter project Number:         
      val=["Project: NumberList of Values","VTextField"]
      proj_no=proj_status.FindChildEx(prop,val,60,True,40000)
      proj_no.Click()
      proj_no.Keys(app.Cells.item[rowno,11])
      delay(1000)
      web_utils.log_checkpoint("Entering Project Number :"+VarToStr(app.Cells.item[rowno,11])+" to validate commitment details",500,jFrame)        
      # Click Find Button:    
      val=["Find alt i","Button"]
      find_btn=proj_status.FindChild(prop,val,60)
      find_btn.Click()
      delay(2000)
      # Validate 'Project Status' Form:
      val=["Project Status *","ExtendedFrame"]
      proj_sts_form=jFrame.FindChild(prop,val,60)
      Sys.HighlightObject(proj_sts_form)
      web_utils.log_checkpoint("Navigation to Project Status Form Successfull",500,jFrame) 
      delay(1000)
      # Click 'Commitments' button:
      val=["Commitments alt C","Button"]
      find_btn=proj_sts_form.FindChild(prop,val,60)
      find_btn.Click()
      delay(2000)
      # Validate Commitments Form:
      val=["Find Commitments *","ExtendedFrame"]
      commit_form=jFrame.FindChild(prop,val,60)
      Sys.HighlightObject(commit_form)
      web_utils.log_checkpoint("Navigation to Commitments Form Successfull",500,jFrame) 
      delay(1000)
      # Click Find Button in Commitments Form:
      val=["Find alt i","Button"]
      c_find_btn=commit_form.FindChild(prop,val,60)
      c_find_btn.Click()
      delay(2000)
      # Validate Commitment Details Form:
      val=["Commitment Details (Manheim Corporate Services)*","ExtendedFrame"]
      com_det_frm=jFrame.FindChild(prop,val,60)
      Sys.HighlightObject(com_det_frm)
      delay(1000)
      web_utils.log_checkpoint("Navigation to Commitment Details Form Successfull",500,jFrame) 
      tool_bar = Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("ExtendedFrame", "Commitment Details (Manheim Corporate Services)*", 23).AWTObject("TitleBar", "", 0).AWTObject("LWComponent", "", 0).AWTObject("TitleBar$CaptionComp", "", 0)
      Sys.HighlightObject(tool_bar)
      tool_bar.DblClick()
      # Validate Commitment Cost:
      prop1=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
      val1=["Project Raw Cost","VTextField",70]
      proj_raw_cost=com_det_frm.FindChild(prop1,val1,60)
      Sys.HighlightObject(proj_raw_cost)
      project_raw_cost_val = "%.2f" %(VarToFloat(proj_raw_cost.wText))
      web_utils.log_checkpoint("Project Raw Cost Value - $"+VarToStr(project_raw_cost_val),500,jFrame)  
      delay(3000) 
      jFrame.Keys("[F4]")
      delay(2000)
      
 def save_log(self,file_type,program_name):
   
     Delay(15000)
     self.wait_until_page_loaded()
     log_page=Sys.Browser("iexplore").Page("https://manheim-*.epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
     Delay(1000)
     log_page.Click()
     log_page.TextNode(0).Click()
     Delay(1000)
     Log.Enabled=True     
     screenshot=log_page.PagePicture()
     msg = file_type+" File Opened Successfully"
     Log.Picture(screenshot,msg)
     Log.Enabled=False
     log_page.Keys("~f")
     Delay(5000)
     log_page.Keys("a")
     Delay(5000) 
     file_system_utils.create_folder(self.op_log_path)             
   #  log_path=self.op_log_path+"\\prc update project summary amount "+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt" 
     log_path=self.op_log_path+"\\"+program_name+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"   
     Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
     Delay(1000)
     Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
     Delay(5000)
     Log.Enabled=True
#     Log.File(log_path,"PRC: Update Project Summary Amounts for a Single Project "+file_type+" file Attached")
     Log.File(log_path,program_name+" "+file_type+" file Attached") 
     Log.Enabled=False     
     Sys.Browser("iexplore").Page("https://manheim-*.epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
     web_utils.close_additional_browsers()

 def closing_forms(self):
     jFrame=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1)
     delay(2000)
     jFrame.Keys("[F4]")
     delay(2000)
     jFrame.Keys("[F4]")
     delay(2000)
     jFrame.Keys("~o")
     delay(2000)      
   
   

