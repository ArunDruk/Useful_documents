﻿import gvar

### In this method objects for below pages have been captured ###

#CREATE PROJECT: DETAILS PAGE

def prj_name_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["ProjectName","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def prj_owning_org_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["CarryingOutOrgName","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def prj_work_type_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["ClassCode","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def portfolio_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["ClassCode2","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def program_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["ClassCode3","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def funding_category_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["ClassCode4","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
  

def funding_sub_category_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["ClassCode5","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def prj_mgr_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["KeyMemberName","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
  

def business_owner_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["KeyMemberName2","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def fin_owner_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["KeyMemberName3","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
################## Page objects for Create Project Details > Project Information ##################

def copy_team_members_checkbox():
  prop_names = ["ObjectIdentifier", "ObjectType"]
  prop_values = ["PrTeamMembersCB", "Checkbox" ]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def copy_prj_attachments_checkbox():
  prop_names = ["ObjectIdentifier", "ObjectType"]
  prop_values = ["PrAttachmentsCB", "Checkbox" ]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def copy_item_associations_checkbox():
  prop_names = ["ObjectIdentifier", "ObjectType"]
  prop_values = ["PrItemAssocCB", "Checkbox" ]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
  
  
def copy_prj_info_dff_checkbox():
  prop_names = ["ObjectIdentifier", "ObjectType"]
  prop_values = ["PrDffCB", "Checkbox" ]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def copy_user_defined_attributes_checkbox():
  prop_names = ["ObjectIdentifier", "ObjectType"]
  prop_values = ["PrUserDefnAttCB", "Checkbox" ]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

################## Page objects for Create Project Details > Financial Structure ##################

def copy_fin_tasks_checkbox():
  prop_names = ["ObjectIdentifier", "ObjectType"]
  prop_values = ["FnFinTasksCB", "Checkbox" ]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def copy_attachments_checkbox():
  prop_names = ["ObjectIdentifier", "ObjectType"]
  prop_values = ["FnAttachmentsCB", "Checkbox" ]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def copy_fin_structure_dff_checkbox():
  prop_names = ["ObjectIdentifier", "ObjectType"]
  prop_values = ["FnDffCB", "Checkbox" ]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


################## Page objects for Create Project Details > Other Financial Information ###########

def copy_trx_controls_checkbox():
  prop_names = ["ObjectIdentifier", "ObjectType"]
  prop_values = ["FnTranCtrlsCB", "Checkbox" ]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def copy_cost_bill_override_checkbox():
  prop_names = ["ObjectIdentifier", "ObjectType"]
  prop_values = ["FnCBOverridesCB", "Checkbox" ]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
  

def copy_assets_checkbox():
  prop_names = ["ObjectIdentifier", "ObjectType"]
  prop_values = ["FnAssetsCB", "Checkbox" ]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def copy_asset_assgmnts_checkbox():
  prop_names = ["ObjectIdentifier", "ObjectType"]
  prop_values = ["FnAssetAssignCB", "Checkbox" ]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def cancel_button():
  prop_names = ["contentText", "ObjectType"]
  prop_values = ["Cancel", "Button" ]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
  

def finish_button():
  finish_button = gvar.dataprep['page'].EvaluateXpath("//table[@id='ContinueCancel']//button[@title='Finish']")[0]
  return finish_button 
  

