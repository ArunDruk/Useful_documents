﻿from ebiz import *
import web_utils
import form_utils
import dbhelper
import file_system_utils


class tc84515_cai_us_gl_reversing_journa_ete_18(Ebiz):

 op_log_path ="C:\\TC_Logs"

 def login(self):
   self.login_user='mfallwell'
   super().login()
   
 def action(self,book): 
    app = book.Sheets.item["JournalWebAdi"]
    
    #Switch the responsibility to CAI ALL GL SETUP
    cai_gl_setup_link=self.page.Find("contentText","CAI ALL GL SETUP",30)
    self.verify_aqobject_chkproperty(cai_gl_setup_link,"contentText",cmpIn,"CAI ALL GL SETUP")
    cai_gl_setup_link.Click() 
    self.page.wait()
    self.log_message_web("Click 'CAI ALL GL SETUP' - Successful") 
    self.page.Keys("[Down]") 
    self.page.Keys("[Down]")  
    delay(2000)
     
    
    cai_journal_link=self.page.NativeWebObject.Find("contentText","Journals","A")
    self.verify_aqobject_chkproperty(cai_journal_link,"contentText",cmpIn,"Journals")
    cai_journal_link.Click() 
    self.log_message_web("Click Journals - Successful") 
    delay(2000)
    
    self.page.Keys("[Down]")
    self.page.Keys("[Down]")
    self.page.Find("namePropStr","RF.jsp?function_id=616&resp_id=50678&resp_appl_id=101&security_group_id=0&lang_code=US')",30).Click()
    self.log_message_web("Click Enter Journals - Successful")
    Delay(5000)
    
    jFrame=self. initializeJFrame()
    Delay(6000)
#    form_utils.click_ok_btn(jFrame)    
    jFrame.Keys("~o")
    delay(12000)      

# Finding Journal which was imported and post the Journal
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Journals","ExtendedFrame"]
    
    j_req_id = app.Cells.Item[2,14]
    fnd_jrnl=jFrame.FindChildEx(prop,val,60,True,90000)
    fnd_jrnl.Find("AWTComponentAccessibleName","BatchList of Values",10).Click()
    fnd_jrnl.Find("AWTComponentAccessibleName","BatchList of Values",10).Keys("%"+VarToStr(j_req_id)+"%")
    delay(1000) 
    jFrame.Keys("~i")
    self.log_message_oracle_form(jFrame,"Find Journal Successful")
    delay(2000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Enter Journals (CAI ALL LEDGERS)","ExtendedFrame"]
    Enter_Journals_Form=jFrame.FindChildEx(prop,val,60,True,90000)
     
    Enter_Journals_Form.Keys("~r")
    self.log_message_oracle_form(jFrame,"Reverse Journal Successful")
    delay(3000) 
    jFrame.Find("AWTComponentAccessibleName","Find",10).Click()
    jFrame.Find("AWTComponentAccessibleName","Find",10).Keys(aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%b-%y").upper())
    jFrame.Find("AWTComponentAccessibleName","Find",10).Keys("[Enter]")
    delay(3000)
        
    

    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Note*","ChoiceBox"]
    note_choicebox=jFrame.FindChildEx(prop,val,60,True,90000)
    self.verify_aqobject_chkproperty(note_choicebox,"AWTComponentAccessibleName",cmpContains,"Note Your concurrent request(s) have been submitted.")
    
    jFrame.Keys("~o") 
    Delay(3000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~o")   
    Delay(1000)    
    Sys.Browser("iexplore").page("https://*ebs.coxautoinc.com/forms/frmservlet*").Close()
