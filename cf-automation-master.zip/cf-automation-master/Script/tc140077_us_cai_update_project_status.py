﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils
import winscp_utility


###This testcase is to place the CAI_US_PROJ_STATUS.txt file in the PA inbound directory using WINSCP### 
###and submit CAI Project Status Update Interface Request Set and capture Output and validate Project Status in CAI EBIZ###

class tc140077_us_cai_update_project_status(Ebiz):

 op_log_path="C:\\TC_Logs"
 CAI_US_PROJ_STATUS="C:\\CAI_US_PROJ_STATUS"

 def login(self):
    self.login_user="pkjami"
    super().login()

 def action(self,book):
    global jrnl_imp_pro 
    self.modify_CAI_US_PROJ_STATUS()
    self.query_prj_status()
    self.place_CAI_US_PROJ_STATUS_winscp()
    
### Modifying CAI_US_PROJ_STATUS.csv file 
 def modify_CAI_US_PROJ_STATUS(self):
    file_name= Project.Path+"DataSheets\\Oracle-PA-Additions\\CAI_US_PROJ_STATUS.csv"
    file_system_utils.create_folder(self.CAI_US_PROJ_STATUS)
    file_exist=aqFileSystem.FindFiles("C:\\CAI_US_PROJ_STATUS","CAI_US_PROJ_STATUS.csv")    
    if file_exist != None:
     aqFileSystem.DeleteFile("C:\\CAI_US_PROJ_STATUS\\CAI_US_PROJ_STATUS.csv")
    aqFileSystem.CopyFile(Project.Path+"DataSheets\\Oracle-PA-Additions\\CAI_US_PROJ_STATUS.csv", "C:\\CAI_US_PROJ_STATUS\\CAI_US_PROJ_STATUS.csv")    
    log_path = ("C:\\CAI_US_PROJ_STATUS\\CAI_US_PROJ_STATUS.csv")
    Log.Enabled=True
    Log.File(log_path, "'CAI_US_PROJ_STATUS' Inbound file attached")
    Log.Enabled=False 
    
# Placing CAI_US_PROJ_STATUS.csv file in /DAUT2I/incoming/ATG_OU/PA_PRJ_STATUS
 def place_CAI_US_PROJ_STATUS_winscp(self):
#    Stored_session = "opc@stage-fin-iad1-ebsapp1.private.stagefin.oraclevcn.com"
    Stored_session = "cai_snow@mftstg.manheim.com"
    local_dir = "C:\\CAI_US_PROJ_STATUS"
#    remote_dir = self.winscpConfig[self.testConfig['ebiz']['env']]['remote_dir']+"incoming//ATG_OU//PA_PRJ_STATUS"
    remote_dir =  self.testConfig['winscp']['project_status_remote_dir'] 
    upload_file_name = "CAI_US_PROJ_STATUS.csv"
    winscp_utility.upload_file(Stored_session,local_dir,remote_dir,upload_file_name)
    Log.Enabled=True       
    Log.Message("CAI_US_PROJ_STATUS.txt file placed in the incoming//ATG_OU//PA_PRJ_STATUS directory")           
    Log.Enabled=False

# Login to Oracle EBIZ and select the responsibility        
    self.page.WaitProperty("contentText","CAI US PA JOB SCHEDULER",6000)
    cai_gl_submit_link=self.page.Find("contentText","CAI US PA JOB SCHEDULER",30)
    cai_gl_submit_link.scrollIntoView()
    self.verify_aqobject_chkproperty(cai_gl_submit_link,"contentText",cmpIn,"CAI US PA JOB SCHEDULER")
    cai_gl_submit_link.Click() 
    self.log_message_web("Click 'CAI US PA JOB SCHEDULER' - Successful")        
    self.page.Wait()
    self.page.NativeWebObject.Find("contentText","Submit Request","A").Click()
    self.log_message_web("Click 'Submit Request' - Successful") 
    web_utils.validate_security_box()
    jFrame=self.initializeJFrame()
    Delay(2000)
    form_utils.click_ok_btn(jFrame)
    Delay(4000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit a New Request","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,50,True,90000)  
    Sys.HighlightObject(req_form)     
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["What type of request do you want to run? Request Set alt s","ExtendedCheckbox"]   
    req_form.FindChild(prop,val,10).Click()
    Delay(1000)
    req_form.FindChild("AWTComponentAccessibleName","OK alt O",10).Click()
    
# Submitting "CAI Project Status Update Interface Request Set" Request Set using CAI US PA JOB SCHEDULER' responsibility
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit Request Set","ExtendedFrame"]
    par_form=jFrame.FindChildEx(prop,val,60,90000)
    par_form.Find("AWTComponentAccessibleName","Request Set RequiredList of Values",30).Click()
    delay(1000)
    par_form.Find("AWTComponentAccessibleName","Request Set RequiredList of Values",30).SetText("CAI Project Status Update Interface Request Set")
    delay(1000)
    jFrame.Keys("[Tab]")
    delay(1000)
    jFrame.Keys("[Tab]")
    delay(1000)
    jFrame.Keys("[Tab]")
    delay(1000)
    jFrame.Keys("~o")
    delay(1000)
    jFrame.Keys("[Down]")
    delay(3000)
    jFrame.Keys("!"+"[Tab]")
    delay(1000)
    jFrame.Keys("Y")
    delay(1000)
    jFrame.Keys("~o")
    delay(1000)
    par_form.FindChild("AWTComponentAccessibleName","Submit",10).Click()
    Delay(1000)
    jFrame.Keys("~o")
    self.log_message_oracle_form(jFrame,"'CAI Project Status Update Interface' Request Set Submitted")   
    RequestID = aqConvert.VarToInt(''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit()))
    Log.Message("Request ID Of  " + aqConvert.VarToStr(RequestID))
    self.log_checkpoint_message_web("Request ID Of 'CAI Project Status Update Interface' Request Set" + aqConvert.VarToStr(RequestID))
    Delay(2000)
    jFrame.Keys("~n")
    Delay(4000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000) 

# Gathering Request ID and Output File for the "CAI Global Data Loader"  
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChild(prop,val,30)
    form_utils.req_set_save_log(self,jFrame,req_form,"CAI Global Data Loader",RequestID)
    Delay(2000)
    jFrame.Click()
    Delay(2000)
    jFrame.Keys("~w")
    Delay(2000)
    jFrame.Keys("2")
    Delay(2000)
    jFrame.Keys("[F4]")
    Delay(2000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000)
    
# Gathering Request ID and Output File for the "CAI PA Project Status Update Interface Program"  
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChild(prop,val,30)
    self.req_set_save_output(jFrame,req_form,"CAI PA Project Status Update Interface Program",RequestID)
    Delay(2000)
    jFrame.Click()
    fo=open(self.log_path,"r")
    lines=fo.readlines()
    project_number=lines[10][0:8].strip()
    Log.Enabled=True
    Log.Message(lines[5][0:148].strip())
    Log.Message(lines[6][0:81].strip())
    Log.Message(lines[7][0:148].strip())
    Log.Message(lines[8][0:34].strip())
    Log.Message(lines[9][0:34].strip())
    Log.Message(lines[10][0:75].strip())
    Log.Message(lines[11][0:75].strip())
    Log.Message(lines[12][0:75].strip())
    Log.Message(lines[13][0:75].strip())
    Log.Message(lines[14][0:75].strip())
    
    failed_records=lines[20][80:81].strip()

    if failed_records != "0":
     Log.Error("TOTAL Records Failed to Process since is not zero")
     
    Log.Enabled=False  
    Delay(2000)
    jFrame.Keys("~w")
    Delay(2000)
    jFrame.Keys("2")
    Delay(2000)    
    jFrame.Click()
    Delay(2000)
    jFrame.Keys("~w")
    Delay(2000)
    jFrame.Keys("2")
    Delay(2000)
    jFrame.Keys("[F4]")
    Delay(2000)
    jFrame.Keys("~f")
    Delay(1000)
    jFrame.Keys("w")
    Delay(2000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Responsibilities","FWindow"]
    resp_form=jFrame.FindChildEx(prop,val,30,True,40000)
    resp_form.Find("AWTComponentName","LWTextField*",10).Click()
    Delay(1000)
    resp_form.Find("AWTComponentName","LWTextField*",10).Keys("[BS]")
    Delay(1000)
    resp_form.Find("AWTComponentName","LWTextField*",10).keys("CAI "+self.oper_unit+" PA PROJECT CONTROLS")
    Delay(1000)
    self.log_message_oracle_form(jFrame," Responsibility changed to 'CAI "+self.oper_unit+" PA PROJECT CONTROLS' successfully")
    Delay(2000)
    resp_form.Find("AWTComponentName","LWTextField*",10).Click() 
    self.verify_aqobject_chkproperty(resp_form,"AWTComponentAccessibleName",cmpContains,"Responsibilities")   
    Delay(5000)
    jFrame.Keys("~f")
    Delay(3000)
    jFrame.Keys("[Enter]")
    Delay(3000)
    self.log_message_oracle_form(jFrame,"'Find Projects' form launched successfully")  
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Projects","ExtendedFrame"]
    find_proj_form=jFrame.FindChildEx(prop,val,40,True,90000)
    pro_num=find_proj_form.FindChild("AWTComponentAccessibleName","Project NumberList of Values",20)
    pro_num.Click()
    pro_num.SetText(VarToStr(project_number))
    Delay(1000)        
    self.log_message_oracle_form(jFrame,"In 'Find Projects'form Project Number Entered successfully")
    jFrame.Keys("~i")
    find_proj_form.FindChild("AWTComponentAccessibleName","Find alt i",20).Click()
    Delay(5000)
    self.log_message_oracle_form(jFrame,"'Project, Templates Summary' form launched successfully")
    Delay(1000) 
    self.log_message_oracle_form(jFrame," In 'Project, Templates Summary' form click on 'Open' next")
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Projects, Templates Summary","ExtendedFrame"]
    proj_temp_summary=jFrame.FindChildEx(prop,val,40,True,90000)
    proj_temp_summary.FindChild("AWTComponentAccessibleName","Open alt O",20).Click()
    Delay(5000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Projects, Templates","ExtendedFrame"]
    proj_summary=jFrame.FindChildEx(prop,val,40,True,90000)
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Status",8]
    status=proj_summary.FindChild(prop,val,30)
    Delay(5000)
    self.verify_aqobject_chkproperty(status,"wSelection",cmpContains,"Pending Close")        
    self.log_message_oracle_form(jFrame," In 'Projects, Templates' form 'Project Status' reviewed successfully")
    Delay(5000)
    jFrame.Keys("[F4]")
    Delay(3000)
    jFrame.Keys("[F4]")
    Delay(3000)
    jFrame.Keys("[F4]")
    Delay(3000)
    jFrame.Keys("~o")
    Delay(3000) 
    jFrame.Keys("[F4]")
    Delay(3000)
    jFrame.Keys("[F4]")
    Delay(3000)
    jFrame.Keys("~o")
    Delay(3000)   
    

    

 def req_set_save_output(self,jFrame,req_form,srch_child_name,Preqid):
    self.log_message_oracle_form(req_form,"Checking for "+aqConvert.VarToStr(srch_child_name)+ " Child Program Status")
    req_form.FindChild("AWTComponentAccessibleName","Refresh Data alt R",20).Click()
    i=20
    for x in range(1,180):     
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Name",i]
        child_name=req_form.Find(prop,val,10).wText 
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Phase",i+20]
        phase=req_form.Find(prop,val,10).wText 
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Request ID",i-10]
        creqid=VarToInt(req_form.Find(prop,val,10).wText)
                                             
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Status",i+30]         
        status =req_form.FindChild(prop,val,60)            
        if (child_name==srch_child_name) and (creqid>=Preqid) and (phase == "Completed"):
            self.log_message_oracle_form(req_form,aqConvert.VarToStr(srch_child_name)+" Phase Completed Successfuly")                              
            status.Keys("[Enter]")
            Delay(1000)
            req_form.FindChild("AWTComponentAccessibleName","View Output alt p",20).Click()
            Delay(3000)
            output_page=Sys.Browser("iexplore").Page("https://core*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.*")
            output_page.Click()
            Delay(2000)
            output_page.Keys("~f")
            Delay(2000)
            output_page.Keys("a")
            Delay(2000)
            file_system_utils.create_folder(self.op_log_path)             
            log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"File"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"_%d%b%Y_%H%M")+".txt"    
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
            Delay(1000)
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
            Delay(1000)
            Log.Enabled=True
            Log.File(log_path, aqConvert.VarToStr(srch_child_name)+" is Completed and Output file is attached")
            Log.Enabled=False      
            web_utils.close_additional_browsers()  
            if status.wText == "Error":
               self.log_message_oracle_form(req_form,srch_child_name+" failed with error status")   
               self.log_error_message("Failed with error status.")
            Filesaved = 'True'
            self.log_path=log_path
            return creqid                      
        elif i >=28:
           Delay(20000)
           req_form.FindChild("AWTComponentAccessibleName","Refresh Data alt R",20).Click()
           Delay(3000)
           i=20
           val=["Name",i]
           child_name=req_form.Find(prop,val,10).wText

        else:  
           Delay(3000)
           i=i+1 
           req_form.Keys("[Down]")
           

 def query_prj_status(self):
  import database_service
  path = "C:\\CAI_US_PROJ_STATUS\\CAI_US_PROJ_STATUS.csv"
  query = "select SEGMENT1 as FINTASKNUMBER1, 'Complete' as SS_STATUS from PA_PROJECTS_ALL  where project_status_code = 'APPROVED' and org_id = 82 order by LAST_UPDATE_DATE desc fetch first 5 rows only"  
  dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
  user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
  pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
    
  toCsv = database_service.query_oracle(dsn,user_id,pwd,query)
  if len(toCsv) > 0 :
     self.db_rows_to_csv(path,toCsv)

 def db_rows_to_csv(self,path,rows):
    import csv
    keys = rows[0].keys()
    csv.register_dialect('csv', delimiter=',', quoting=csv.QUOTE_ALL)
    with open(path, 'w') as output_file:
        dict_writer = csv.DictWriter(output_file, fieldnames=keys,dialect='csv',extrasaction='ignore')
        dict_writer.writeheader()
        dict_writer.writerows(rows)

