﻿from dbhelper import *
from ebiz import *
import web_utils

class OCI_WCI_Coding_Smoke_Test(Ebiz):
  
 def login(self):
    prop=["idStr","ObjectType"]
    val=["userid","TextBox"]
    self.page.FindChild(prop,val,30).setText(self.testConfig['ebiz']['wfr_prod_logid']) 

#    self.log_message_web("Set User ID:  "+self.login_user+" Successful")
    self.page.Keys("[Tab]")
    prop=["idStr","ObjectType"]
    val=["password","PasswordBox"]
    self.page.FindChild(prop,val,30).SetText(self.testConfig['ebiz']['password']) 
    self.page.wait_until_loaded()
    prop=["ObjectIdentifier","ObjectType"]
    val=["Log In","SubmitButton"]
    self.page.FindChild(prop,val,30).Click() 
    
    self.wait_until_page_loaded()    
    
 def goto_url(self,url):
   super().goto_url(self.testConfig['ebiz']['webCentCodUrl'])
   
 def logout(self):
   self.page.wait()
   self.page.FindChild("idStr","pt1:cl6",20).Click()
   web_utils.log_checkpoint("Completed WCI Coding Application Validation Successfully: Logging out from Applications",500,self.page)
   Sys.Browser("iexplore").Page("https://*.manheim.com/axf-solutionWorkspace/faces/solutionworkspace?*").Close()
   
 def wait_until_page_loaded(self):
   Delay(5000)  
   
 def action(self,book):
  app = book.Sheets.item["Smoke_Test"]   
  Delay(6000)
  if Sys.Browser("iexplore").Page("https://*.manheim.com/axf/faces/command/CommandExecutor.jspx?*").Alert.Exists:
    Sys.Browser("iexplore").Page("https://*.manheim.com/axf/faces/command/CommandExecutor.jspx?*").Alert.Button("OK").Click()
    Delay(3000)
  self.wait_until_page_loaded()
  if Sys.Browser("iexplore").WaitPage("https://*.manheim.com/axf-solutionWorkspace/faces/solutionworkspace?_*",60000).Alert.Exists:
    Sys.Browser("iexplore").WaitPage("https:/*.manheim.com/axf-solutionWorkspace/faces/solutionworkspace?_*",60000).Alert.Button("OK").Click()
    Delay(2000)
  self.wait_until_page_loaded()
  # Check security warning window exists
  security_wnd=Sys.Browser("iexplore").WaitSwingObject("JDialog", "Security Warning", -1, 1,5000)  
  if security_wnd.Exists:
    Sys.Browser("iexplore").SwingObject("JDialog", "Security Warning", -1, 1).FindChild("AWTComponentAccessibleName","I accept the risk and want to run this application.",30).Click()
    Sys.Browser("iexplore").SwingObject("JDialog", "Security Warning", -1, 1).Keys("[Enter]")
    
  welcome_msg=self.page.FindChildEx("contentText","WebCenter*",30,True,40000) 
  count =  0
  
  while not welcome_msg.Exists:
    Delay(2000)
    welcome_msg=self.page.Find("contentText","WebCenter*",30) 
    count = count + 1 
    if count == 10:
      self.log_error_message("Unable to Login to WCI Coding Application")    
  web_utils.log_checkpoint("Logged in to Web Center Coding Applications Successfully",500,self.page)
  
  views = Sys.Browser("iexplore").Page("https://*.manheim.com/axf-solutionWorkspace/faces/solutionworkspace?*")
  delay(2000)
  inbox = views.FindChild("contentText","My Tasks",40)
  if inbox.Exists:
    Sys.HighlightObject(inbox)
    web_utils.log_checkpoint("Verified 'Views' Section Successfully in WCI Coding Application",500,self.page)
#    app.Cells.item[2,1] = "SUCCESS"
  else:
    self.log_error_message("Unable to Verify Object: 'Inbox' in WCI - Coding Application")
#    app.Cells.item[2,1] = "FAILED"

  self.page.wait_until_loaded()
  task = Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).FindAllChildren("idStr","pt1:r1:0:r1:0:vldc:j_id__ctru1pc4",50)
  task_str = task[0].contentText
  find = "("
  find2 = "CAI Account Distribution"
  if aqString.Contains(task_str,find):
      pos1=task_str.index('(')
      pos2=task_str.index(')')
      val = aqString.SubString(task_str,pos1,pos2)
      self.log_message_web("Available Assigned Tasks for View - CAI Account Distribution: "+val)
      self.page.wait_until_load()
      web_utils.log_checkpoint("Able to verify Objects in WCI Coding Application: Test Passed",500,self.page)
      app.Cells.item[2,1] = val
      app.Cells.item[2,2] = "SUCCESS"
      delay(2000)
  elif aqString.Contains(task_str,find2):
    self.log_message_web("No Assigned Tasks Available for View - CAI Account Distribution")
    web_utils.log_checkpoint("Able to verify Objects in WCI Coding Application: Test Passed",500,self.page)
    app.Cells.item[2,2] = "SUCCESS"
      
  else:
      self.log_error_message("Unable to Verify View - CAI Account Distribution: Test Failed")
      app.Cells.item[2,2] = "FAILED"


      
def test():
  
# page = Sys.Browser("iexplore").page("*")
# task = page.FindChild("contentText","My Tasks",30)
 task = Sys.Browser("iexplore").Page("https://*.manheim.com/axf-solutionWorkspace/faces/solutionworkspace?*")
 delay(2000)
 mytask = task.FindChild("contentText","My Tasks",40)
 if mytask.Exists:
  Sys.HighlightObject(mytask)
  
 
# task_str = page[0].contentText
# find = "("
## test = task_str.contentText
## if task_str.Exists:
##    self.page.wait_until_load()
##    delay(2000)
# if aqString.Contains(task_str,find):
#      pos1=task_str.index('(')
#      pos2=task_str.index(')')
#      val = aqString.SubString(task_str,pos1,pos2)
#      val2 = ""
# else:
#   Log.Message("false")