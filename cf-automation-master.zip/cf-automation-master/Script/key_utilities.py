﻿            
def press_alt_r_key(object):
  object.keys('~r')
            
def press_alt_s_key(object):
  object.keys('~s')

def press_alt_m_key(object):
  object.keys('~m')

def press_alt_n_key(object):
  object.keys('~n')
  
def press_alt_i_key(object):
  object.keys('~i')

def press_alt_o_key(object):
  object.keys('~o')

def press_alt_x_key(object):
  object.keys('~x')

def press_alt_f4_key(object):
  object.keys('~[F4]')
  
def press_tab_key(object):  
  object.keys('[Tab]')
  
def press_f11_key(object):
  object.keys('[F11]')
  
def press_ctrl_f11_key(object):
  object.keys('^[F11]')
  
def press_f4_key(object):
  object.keys('[F4]')
  
def press_tab_ntimes(object,n):
  while(n>0):
    object.keys('[Tab]')
    n-=1
    
def press_alt_vr_key(object):
  object.keys('~vr')
  
def bold_text(mytext):
  attr = Log.CreateNewAttributes()
  attr.Bold = True
  Log.Checkpoint(mytext,"", pmNormal, attr)
  
def press_alt_o(key_object):
  key_object.Keys("~o")
  
def press_alt_f(key_object):
  key_object.Keys("~f")
  
def press_x(key_object):
  key_object.Keys("x")
  
def press_alt_c(key_object):
  key_object.Keys("~c")
  
def press_c(key_object):
  key_object.Keys("c")
  
def press_alt_v(key_object):
  key_object.Keys("~v")
  
def press_r(key_object):
  key_object.Keys("r")

def press_alt_n(key_object):
  key_object.Keys("~n")
  
def press_alt_r(key_object):
  key_object.Keys("~r")
  
def press_alt_s(key_object):
  key_object.Keys("~s")

def f11_key(key_object):
  key_object.Keys("[F11]")
  
def ctrl_f11(key_object):
  key_object.Keys("^[F11]")

def press_f(key_object):
  key_object.Keys("f")

def press_enter(key_object):
  key_object.Keys("[Enter]")
  
def click_tab_n_times(key_object,n):
  while n > 0:
    key_object.Keys("[Tab]")
    n -=1
 
def press_alt_t(key_object):
  key_object.Keys("~t")
  
def press_w(key_object):
  key_object.Keys("w")
  
def press_alt_i(key_object):
  key_object.Keys("~i")

def press_alt_b(key_object):
  key_object.Keys("~b")

  
def exit_oracle_applications(key_object):
  key_object.Keys("~f")
  key_object.Keys("x")
  key_object.Keys("~o")
  
def close_oracle_forms(key_object):
  key_object.Keys("~f")
  key_object.Keys("c")
  
def click_down_arrow(key_object):
  key_object.Keys("[Down]")

def click_up_arrow(key_object):
  key_object.Keys("[Up]")
  
def click_down_arrow_n_times(key_object,n):
  while n > 0:
    key_object.Keys("[Down]")
    n -= 1
  
def click_enter_n_times(key_object,n):
  while n > 0:
    key_object.Keys("[Enter]")
    n -= 1

def click_ctrl_w(key_object):
  key_object.Keys("^w")

def press_down_arrow_n_times(key_object,n):
  while n > 0:
    key_object.Keys("[Down]")  
    n -= 1

def click_open_folder():
  gvar.dataprep['jformobject'].Keys("~l")
  gvar.dataprep['jformobject'].Keys("o")
  gvar.dataprep['jformobject'].Keys("~o")
