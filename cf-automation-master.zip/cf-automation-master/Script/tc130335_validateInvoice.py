﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils
import web_utils

#This testcase is to submit create accounting and getting journal batch name from the output

class tc130335_validateInvoice(Ebiz):
  global rowno
  rowno = 2

  def login(self):
      self.login_user="rmaran"
      super().login()


  def action(self,book): 
      app = book.Sheets.item["Invoice"]
#      self.wait_until_page_loaded()
      self.page.wait()
#      self.wait_until_page_loaded()
      web_utils.log_checkpoint("Logged in to Oracle Applications Home Page Successfully",500,self.page)
#      self.wait_until_page_loaded()    
      temp=web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" AP INVOICE PROCESSING')]")         
#      self.wait_until_page_loaded()     
      delay(3000) 
      web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Invoices')]")            
      Delay(3000)
      temp=web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Entry')]")       
      Delay(3000)
      self.page.EvaluateXPath("//div[text()='Invoices']")[1].Click()
      delay(10000)   
      web_utils.validate_security_box()
#      delay(10000)       
      jFrame=self.initializeJFrame()
      Delay(5000)
      form_utils.click_ok_btn(jFrame)
      Delay(4000)
#      jFrame=self.initializeJFrame()
#      Delay(8000)
#      form_utils.click_ok_btn(jFrame)
      Delay(6000)
      jFrame.Keys("~v")
      delay(1000)
      jFrame.Keys("f")
      delay(1000)
      
    
   #Finding Invoice that needs to be accounted
      prop=["AWTComponentAccessibleName","JavaClassName"]
      val=["Find Invoices","ExtendedFrame"]
      par_form=jFrame.FindChildEx(prop,val,60,True,60000)
      par_form.Find("AWTComponentAccessibleName","Invoice: Number",10).Click()
      par_form.Find("AWTComponentAccessibleName","Invoice: Number",10).Keys(app.Cells.Item[rowno,13])
#      jFrame.Keys("[Tab]")
#      jFrame.Keys("[Tab]")
#      jFrame.Keys("[Tab]")
#      jFrame.Keys("[Tab]")
#      jFrame.Keys("[Tab]")
#      jFrame.Keys("[Tab]")
#      jFrame.Keys("[Tab]")
#      jFrame.Keys("[Tab]")
#      jFrame.Keys("[Tab]")
#      jFrame.Keys(aqConvert.DateTimeToFormatStr(aqDateTime.Today(),"%d-%b-%Y"))
#      jFrame.Keys("[Tab]")
#      jFrame.Keys(aqConvert.DateTimeToFormatStr(aqDateTime.Today(),"%d-%b-%Y"))
      delay(1000) 
      jFrame.Keys("~i")
      Delay(5000)
      prop=["AWTComponentAccessibleName","JavaClassName"]
      val=["Invoice Workbench*","ExtendedFrame"]
      inv_wrk_bench_frm=jFrame.FindChildEx(prop,val,60,True,90000)        
      prop=["AWTComponentAccessibleName","AWTComponentIndex"]
      val=["Type Required",8]
      inv_type=inv_wrk_bench_frm.FindChildEx(prop,val,60,True,90000)
      Log.Enabled=True
      aqObject.CheckProperty(inv_type,"wText",cmpIn,"Standard")
      Log.Enabled=False
      self.log_message_oracle_form(jFrame,"Invoice found Successfully")
      self.ap_inv_val(jFrame)
      
      
  def ap_inv_val(self,jFrame):    
      jFrame.FindChild("AWTComponentName","FormsTabPanel1",30).ClickTab("1 General")
      
      #Michael Bennett Change - Enter Payment Terms
      prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
      val=["Invoice Num Required","VTextField","32"]
      inv_box=jFrame.FindChildEx(prop,val,30,True,90000)
      
      inv_box.Click()
      
      for x in range(0,15):
        jFrame.Keys("[Tab]")
        Delay(300)
      Sys.Keys("Immediate")
      self.log_message_oracle_form(jFrame,"Payment Terms changed to  \"Immediate\" Successfully")
      
      delay(3000)
      jFrame.Keys("~c")
      delay(1500)
      jFrame.Keys("~v")
      delay(1000)
      jFrame.Keys("~f")
      delay(1000)
      jFrame.Keys("~k")
      delay(5000)
      jFrame.Keys("~o")
      delay(7000)
      jFrame.Keys("^s")
      delay(2000)        
      p_names = ("JavaClassName","AWTComponentAccessibleName")
      p_values = ("VTextField","Status")
      obj=jFrame.FindChildEx(p_names,p_values,50,True,60000)
      if obj.wText == "Validated":
        self.log_checkpoint_message_web("Invoice is Validated and Approved Successfully")
      else:
        self.log_message_oracle_form(jFrame,"Check for Invoice Holds & Re-Validate")
      # Close Forms
      delay(2000)
      jFrame.Keys("[F4]")
      Delay(2000)
      jFrame.Keys("[F4]")
      Delay(2000)
      jFrame.Keys("~o")
      Delay(2000)
#      self.close_forms(jFrame)
#      delay(5000)




