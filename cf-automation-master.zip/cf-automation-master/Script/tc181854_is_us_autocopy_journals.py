﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils


class tc181854_is_us_autocopy_journals(Ebiz): 
 global rowno
 op_log_path="C:\\TC_Logs"
 
 
 def login(self):
   self.login_user='mfallwell'
   super().login()
 
 def goto_url(self,url):
   super().goto_url(self.testConfig['ebiz']['oci_is_url'])
   
 def action(self,book): 
    app = book.Sheets.item["Autocopy"]
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='menuContent']//div[contains(text(),'GL Corporate Accounting User')]") 
    self.wait_until_page_loaded()
    self.page.NativeWebObject.Find("contentText","Journals","A").Click()
    web_utils.log_checkpoint("Click 'Journals' - Successful",500,self.page)
    delay(2000)
    self.page.NativeWebObject.Find("contentText","Enter","A").Click()
    web_utils.log_checkpoint("Click 'Enter' - Successful",500,self.page)
    web_utils.validate_security_box()
    Delay(20000)
    jFrame=self.initializeJFrame()
    form_utils.click_ok_btn(jFrame)
    Delay(5000) 
    web_utils.log_checkpoint("Finding the exisiting Journal where Journal amount greater than Threshold value",500,jFrame)
    mon_yr = aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%b-%Y").upper()

#Finding the exisiting Journal where Journal amount greater than Threshold value

    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Journals","ExtendedFrame"]
    fnd_jrnl=jFrame.FindChildEx(prop,val,60,True,90000)
    fnd_jrnl.Find("AWTComponentAccessibleName","SourceList of Values",10).Click()
    fnd_jrnl.Find("AWTComponentAccessibleName","SourceList of Values",10).Keys("Spreadsheet")
    web_utils.log_checkpoint("In 'Find Journals' form, 'Journal Source' entered successfully",500,jFrame)
    delay(1000) 
    fnd_jrnl.Find("AWTComponentAccessibleName","PeriodList of Values",10).Click()
    fnd_jrnl.Find("AWTComponentAccessibleName","PeriodList of Values",10).Keys(mon_yr)
    web_utils.log_checkpoint("In 'Find Journals' form, 'Journal Period' entered successfully",500,jFrame)
    web_utils.log_checkpoint("In 'Find Journals' form, Click 'Find' next",500,jFrame)
    jFrame.Keys("~i")
    delay(8000)

#Validating Thershold value from the database

    dsn = self.testConfig['man_oracle_db']['dsn']
    user_id = self.testConfig['man_oracle_db']['userid']
    pwd = self.testConfig['man_oracle_db']['pwd']
    appr_amount = dbhelper.get_man_journal_approval_limit(dsn,user_id,pwd)
    
    prop=["JavaClassName","AWTComponentAccessibleName"]
    val=["ExtendedFrame","Enter Journals (MAN GLB ALL)"]
    ent_jrnl = jFrame.FindChildEx(prop,val,20,True,10000)
    for x in range(128,143):
       prop=["JavaClassName","AWTComponentAccessibleName","AWTComponentIndex"]
       val=["VTextField","Journal Debit",x]
       jrnl_debit = jFrame.FindChild(prop,val,20).wText
       if jrnl_debit is not None and VarToInt(jrnl_debit) >= VarToInt(appr_amount):
         break
       ent_jrnl.Keys("[Down]")

    web_utils.log_checkpoint("Journal Found Successfully and 'Autocopy' Journal Next",500,jFrame)

#Autocopy the Journal and save the AutoCopy Journal Request log

    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["AutoCopy... alt y","Button"]
    jFrame.FindChild(prop,val,60).Click()
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["AutoCopy Batch","ExtendedFrame"]
    autocpy_batch_wnd = jFrame.FindChildEx(prop,val,60,True,10000)
    batch_name = "Test_Auto"+ aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"_%d%b%Y_%H%M")
    app.Cells.Item[2,9] = VarToStr(batch_name)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Batch Required","VtextField"]
    autocpy_batch_wnd.FindChild(prop,val,10).Keys(batch_name)
    web_utils.log_checkpoint("Parameters entered for Autocopying Journal",500,jFrame)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["OK","Button"]
    autocpy_batch_wnd.FindChild(prop,val,10).Click()
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Note Your concurrent request ID is*","ChoiceBox"]
    note_wnd = jFrame.FindChildEx(prop,val,10,True,10000)
    RequestID = aqConvert.VarToInt(''.join(x for x in note_wnd.AWTComponentAccessibleName if x.isdigit()))
    web_utils.log_checkpoint("Request ID of AutoCopy Journal Request " + aqConvert.VarToStr(RequestID),500,jFrame)
    Delay(2000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["OK ALT O","FormButton"]
    note_wnd.FindChild(prop,val,10).Click()
    dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,VarToStr(RequestID))
    form_utils.save_log_singlereq(self,jFrame,self.op_log_path,"Autocopy Journals",RequestID)
    web_utils.close_additional_browsers()
    Delay(2000)
    jFrame.Keys("[F4]")
    Delay(2000)
    jFrame.Keys("[F4]")
    Delay(2000)
    jFrame.Keys("~o")
    self.close_forms(jFrame)
    self.wait_until_page_loaded()

#Reviewing the Auto Copied Journal and send it for Approval

    self.page.NativeWebObject.Find("contentText","Enter","A").Click()
    web_utils.validate_security_box()
    jFrame=self.initializeJFrame()
    Delay(10000)
    form_utils.click_ok_btn(jFrame) 
    Delay(1000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Journals","ExtendedFrame"]
    fnd_jrnl=jFrame.FindChildEx(prop,val,60,True,90000)
    fnd_jrnl.Find("AWTComponentAccessibleName","BatchList of Values",10).Click()
    fnd_jrnl.Find("AWTComponentAccessibleName","BatchList of Values",10).Keys(batch_name)
    delay(1000) 
    fnd_jrnl.Find("AWTComponentAccessibleName","SourceList of Values",10).Click()
    fnd_jrnl.Find("AWTComponentAccessibleName","SourceList of Values",10).Keys("Autocopy")
    delay(1000) 
    fnd_jrnl.Find("AWTComponentAccessibleName","PeriodList of Values",10).Click()
    fnd_jrnl.Find("AWTComponentAccessibleName","PeriodList of Values",10).Keys(mon_yr)
    web_utils.log_checkpoint("Parameters entered for selecting Autocopied Journal",500,jFrame)
    web_utils.log_checkpoint("On 'Find Journals' form, click on 'Find' button next ",500,jFrame)
    jFrame.Keys("~i")
    delay(8000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Enter Journals (MAN GLB ALL)*","ExtendedFrame"]
    Enter_Journals_Frame=jFrame.FindChildEx(prop,val,60,True,40000)
    web_utils.log_checkpoint("Click Review on Enter Journals Form",500,jFrame)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Review Journal alt u","Button"]
    Enter_Journals_Frame.FindChild(prop,val,60).Click()
    Delay(3000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Journals (MAN GLB ALL)*","ExtendedFrame"]
    Journals_Frame=jFrame.FindChildEx(prop,val,60,True,40000)
    web_utils.log_checkpoint("Review Journal Information",500,jFrame)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Approve alt A","Button"]
    web_utils.log_checkpoint("Click Approve Button on Journals Form",500,jFrame)
    Journals_Frame.FindChild(prop,val,60).Click()
    Delay(3000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Note Your journal batch*","ChoiceBox"]
    Note_Form=jFrame.FindChildEx(prop,val,60,True,40000)
    web_utils.log_checkpoint("Your journal batch was forwarded to an approver.",500,jFrame)
    Delay(3000)
    Note_Form.Find("AWTComponentAccessibleName","OK ALT O").Click()  
    Delay(2000)
    jFrame.Keys("[F4]")
    Delay(4000)
    jFrame.Keys("[F4]")
    Delay(2000)
    jFrame.Keys("~o")
    Delay(2000)
    self.close_forms(jFrame)


    
    

    
