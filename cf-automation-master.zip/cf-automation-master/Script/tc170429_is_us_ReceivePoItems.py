﻿from ebiz import *
import web_utils
import form_utils
import file_system_utils
import ebiz


class tc170429_is_us_ReceivePoItems(Ebiz):
  global rowno
  rowno = 2
  
  def login(self):
    self.login_user="rmaran"
    super().login()
  
  def goto_url(self,url):
   super().goto_url(self.testConfig['ebiz']['oci_is_url'])
  
  def action(self,book):
    app = book.Sheets.item["Invoice"]    
    rowno = 2
    self.wait_until_page_loaded()
    web_utils.log_checkpoint("Logged in to Oracle Applications Home Page Successfully",500,self.page)
    self.page.EvaluateXPath("//table[@id='menuContent']//div[contains(text(),'iProcurement')]")[0].Click() 
    web_utils.log_checkpoint("Click 'iProcurement' - Successful",500,self.page)
    self.wait_until_page_loaded() 
    
    self.page.NativeWebObject.Find("contentText","iProcurement Home Page","A").Click()
    web_utils.log_checkpoint("Click 'iProcurement Home Page' - Successful",500,self.page) 
    self.page.wait_until_page_loaded()
    
    self.page.EvaluateXPath("//a[@id='ICXPOR_RECEIVING_HOME']")[0].Click() 
    web_utils.log_checkpoint("On 'iProcurement Home Page' click 'Receiving' Tab successful",500,self.page) 
    self.page.wait_until_page_loaded()
    
    self.page.EvaluateXPath("//a[@id='ReceiveItemsLink1']")[0].Click() 
    web_utils.log_checkpoint("On 'Receiving' page click 'Receive Items Link'successful",500,self.page) 
    self.page.wait_until_page_loaded()
    
    web_utils.set_text(self.page,"//input[@id='Requester']","")
    web_utils.set_text(self.page,"//input[@id='OrderNumber']",app.cells.Item[rowno,14])
    
    self.page.EvaluateXpath("//table[@id='SearchMessageComponentLayout']//select[@id='ItemsDueSelect']")[0].ClickItem("Any Time")
     
    prop=["contentText","ObjectIdentifier","ObjectType"]
    val=["Go","0","Button"]  
    go_button=self.page.FindChildEx(prop,val,30,True,3000)
    go_button.Click()
    web_utils.log_checkpoint("On 'Receiving' page click 'GO'button successful",500,self.page) 
    self.wait_until_page_loaded()
    web_utils.slct_chkbox_by_xpath(self.page,"//span[@id='ResultsTableRN']//input[@name='N3:selected:0']")
    qty=self.page.EvaluateXPath("//span[@id='ResultsTableRN']//input[@id='N3:ReceiptQuantity:0']")[0].Text
    web_utils.log_checkpoint("Receipt Quantity/Amount : "+aqConvert.VarToStr(qty),500,self.page) 
    ordered=web_utils.get_content_text_by_xpath(self.page,"//span[@id='ResultsTableRN']//span[@id='N3:QuantityOrdered:0']")
    web_utils.log_checkpoint("Ordered Quantity: "+aqConvert.VarToStr(ordered),500,self.page)  
    self.page.Keys("~x")
    web_utils.log_checkpoint("On Receiving page Click 'Next' button successful",500,self.page)  
    self.wait_until_page_loaded()
    self.page.Keys("~x")
    self.wait_until_page_loaded()
    self.page.Keys("~x")
    self.wait_until_page_loaded()    
    self.page.Keys("~m")
    web_utils.log_checkpoint("On 'Review and Submit' page Click 'Submit' button successful",500,self.page) 
    self.wait_until_page_loaded()
    receipt_no=self.page.EvaluateXPath("//table[@class='x1h']//b")[0].innerText.split(" ")[2]
    receipt_no = aqConvert.VarToStr(receipt_no)
    web_utils.log_checkpoint("Receipt Number : "+receipt_no,500,self.page) 
    app.cells.Item[rowno,18] = receipt_no    
    book.save()
    del app,qty,ordered,rowno

    
