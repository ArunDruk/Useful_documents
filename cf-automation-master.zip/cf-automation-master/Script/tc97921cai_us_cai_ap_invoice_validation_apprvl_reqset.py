﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils
import web_utils
#This testcase is to submit CAI AP Invoice Validation & Approval Request Set and getting journal batch name from the output files

class tc97921cai_us_cai_ap_invoice_validation_apprvl_reqset(Ebiz):

 def login(self):
    self.login_user="rmaran"
    self.op_log_path="C:\\TC_Logs"
    super().login()
    
 
 def action(self,book): 
 
    Log.Message("Inside action...") 
    self.page.WaitProperty("contentText","CAI US AP INVOICE PROCESSING",6000)
    cai_ap_invpro_link=self.page.Find("contentText","CAI US AP INVOICE PROCESSING",30)
    self.verify_aqobject_chkproperty(cai_ap_invpro_link,"contentText",cmpIn,"CAI US AP INVOICE PROCESSING")
    cai_ap_invpro_link.Click() 
    self.log_message_web("Click 'CAI US AP INVOICE PROCESSING' - Successful")
    delay(1000)
    self.page.keys("[Down]")
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Invoices')]")
#    cai_inv_ent_link=self.page.Find("contentText","Invoices",30)
#    self.verify_aqobject_chkproperty(cai_inv_ent_link,"contentText",cmpIn,"Invoices")
#    cai_inv_ent_link.Click() 
    self.log_message_web("Click 'Invoices' - Successful")
    delay(2000)  
    self.page.Find("contentText","Entry",30).Click()
    self.log_message_web("Click 'Entry' - Successful")
    delay(1000)
    self.page.EvaluateXPath("//div[text()='Invoices']")[1].Click()
    self.log_message_web("Click 'Invoices' - Successful")
#    self.page.Find("namePropStr","RF.jsp?function_id=1026&resp_id=50816&resp_appl_id=200&security_group_id=0&lang_code=US')",30).Click()
    delay(20000) 
    jFrame=self.initializeJFrame() 
    Delay(9000)
    form_utils.click_ok_btn(jFrame)
    delay(9000)
    jFrame.FindchildEx("AWTComponentAccessibleName","Invoice Workbench (CAI US AP INVOICE PROCESSING)",True,60000).Click()
    delay(4000)
    jFrame.Keys("[F4]")
    delay(4000)
    jFrame.Keys("~v")
    delay(4000)
    jFrame.Keys("r")
    delay(4000)
    jFrame.Keys("~u")
    delay(4000)
#    jFrame.Keys("~s")
#    delay(4000)
#    jFrame.Keys("~o")
#    delay(4000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit Request Set","ExtendedFrame"]
    par_form=jFrame.FindChildEx(prop,val,60,True,60000)
    par_form.Find("AWTComponentAccessibleName","Request Set RequiredList of Values",30).SetText("CAI AP Invoice Validation & Approval Request Set")
    delay(2000)
    jFrame.Keys("[Tab]")
    par=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Parameters","16"]
    par_form=jFrame.FindChild(par,val,60)
    par_form.Find("AWTComponentIndex","16",10).Click()
    delay(1000)
    jFrame.Keys("[Tab]")
    delay(1000)
    jFrame.Keys("[Tab]")
    delay(1000)
#    jFrame.Keys(aqConvert.DateTimeToFormatStr(aqDateTime.Today(),"%b/%d/%Y"))
    jFrame.Keys(aqConvert.DateTimeToFormatStr(aqDateTime.Today(),"%d-%b-%Y"))
    delay(1000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Parameters","FlexWindow"]
    parameters_form=jFrame.FindChild(prop,val,60)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["OK ALT O","FormButton"]
    ok_button=parameters_form.FindChild(prop,val,60)
    ok_button.Find("AWTComponentAccessibleName","OK ALT O",30).Click()
#    jFrame.Keys("~o")
    delay(3000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit Request Set","ExtendedFrame"]
    submitrequest_form=jFrame.FindChild(prop,val,60)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit alt m","Button"]
    submit_button=submitrequest_form.FindChild(prop,val,60)
    submit_button.Find("AWTComponentAccessibleName","Submit alt m",10).Click()
#    par_form.Find("AWTComponentAccessibleName","Submit",10).Click()
    delay(2000)
    self.log_message_oracle_form(jFrame,"CAI AP Invoice Validation & Approval Request Set Submitted")         
    RequestID = aqConvert.VarToInt(''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit()))
#    self.log_message_oracle_form(jFrame,"CAI AP Invoice Validation & Approval Request ID is " + aqConvert.VarToStr(RequestID)) 
    web_utils.log_checkpoint("'CAI AP: Invoice Validation and Approval' is submitted and Request ID is " + aqConvert.VarToStr(RequestID),500,jFrame)
    
    dsn = self.testConfig['oracle_db']['dsn']
    user_id = self.testConfig['oracle_db']['userid']
    pwd = self.testConfig['oracle_db']['pwd']
    dbhelper.verify_oracle_concurrent_job_status(dsn,user_id,pwd,aqConvert.VarToStr(RequestID))
    delay(2000)
    jFrame.Keys("~n")
    delay(2000)
    jFrame.Keys("[F4]")
    delay(1000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Requests","ExtendedFrame"]
    FindRequests_form=jFrame.FindChild(prop,val,60)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find alt i","Button"]
    find_button=FindRequests_form.FindChild(prop,val,60)
    find_button.Find("AWTComponentAccessibleName","Find alt i",30).Click()
    Delay(1000)
    
# Gathering Request ID and Output File for the "Invoice Validation Program" 
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,90000)
    self.req_set_save_output(jFrame,req_form,"Invoice Validation",RequestID) 
    Delay(1000)
    jFrame.Click()
    Delay(2000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Requests","ExtendedFrame"]
    FindRequests_form=jFrame.FindChild(prop,val,60)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find alt i","Button"]
    find_button=FindRequests_form.FindChild(prop,val,60)
    find_button.Find("AWTComponentAccessibleName","Find alt i",30).Click()
    Delay(1000)

# Gathering Request ID and Output File for the "Invoice Approval Workflow Program"
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,90000)  
    self.req_set_save_output(jFrame,req_form,"Invoice Approval Workflow",RequestID)
    Delay(1000)
    jFrame.Click()
    Delay(2000)
    jFrame.Keys("[F4]")
    Delay(2000)
    self.close_forms(jFrame)
    delay(5000)
#    jFrame.Keys("~v")
#    Delay(1000)
#    jFrame.Keys("r")
#    Delay(1000)
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Find Requests","ExtendedFrame"]
#    FindRequests_form=jFrame.FindChild(prop,val,60)
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Find alt i","Button"]
#    find_button=FindRequests_form.FindChild(prop,val,60)
#    find_button.Find("AWTComponentAccessibleName","Find alt i",30).Click()
#    Delay(1000)
#
## Gathering Request ID and Output File for the "Posting: Single Ledger program"  
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Requests","ExtendedFrame"]
#    req_form=jFrame.FindChildEx(prop,val,30,True,90000) 
#    self.req_set_save_output(jFrame,req_form,"Posting: Single Ledger",RequestID)
#    Delay(1000)
#    dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
#    user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
#    pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
#    dbhelper.verify_oracle_concurrent_job_status(dsn,user_id,pwd,RequestID)  
##    self.browser.page("*").Close()
#    Delay(1000)
#    jFrame.Click()
#    Delay(1000)
#    jFrame.Keys("[F4]")
#    Delay(1000)
#    jFrame.Keys("[F4]")
#    Delay(1000)
#    jFrame.Keys("~o")
#    Delay(1000)
##    Sys.Browser("iexplore").page("https://*ebs.coxautoinc.com/forms/frmservlet*").Close()
##    self.browser.page("*").Close() 
#
#    
# def req_set_save_output(self,jFrame,req_form,srch_child_name,Preqid):
#    self.log_message_oracle_form(req_form,"Checking for Child Program")
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Requests","ExtendedFrame"]
#    req_form=jFrame.FindChild(prop,val,60)
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Refresh Data alt R","Button"]
#    refresh_button=req_form.FindChild(prop,val,60)
#    refresh_button.Find("AWTComponentAccessibleName","Refresh Data alt R").Click()
#    i=20
#    for x in range(1,180):     
#        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#        val=["Name",i]
#        child_name=req_form.Find(prop,val,10).wText 
#        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#        val=["Phase",i+20]
#        phase=req_form.Find(prop,val,10).wText 
#        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#        val=["Request ID",i-10]
#        creqid=VarToStr(req_form.Find(prop,val,10).wText) 
#                                                
#        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#        val=["Status",i+30]
##        index =i+30         
#        status =req_form.FindChild(prop,val,60)            
#        if (child_name==srch_child_name) and (VarToInt(creqid)>Preqid) and (phase == "Completed"):
#            self.log_message_oracle_form(req_form,"phase Completed Successfuly")            
#            status.Keys("[Enter]")    
#            status.Click()        
#            Delay(1000)
#            prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#            val=["View Output alt p","11"]
#            log_button=req_form.FindChild(prop,val,60)
#            log_button.Find("AWTComponentAccessibleName","View Output alt p").Click()      
#            Delay(3000)
#            output_page=Sys.Browser("iexplore").Page("https://core*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.*")
#            output_page.Click()
#            Delay(2000)
#            output_page.Keys("~f")
#            Delay(2000)
#            output_page.Keys("a")
#            Delay(5000)
#            file_system_utils.create_folder(self.op_log_path)             
#            log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"File"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"_%d%b%Y_%H%M")+".txt"    
#            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
#            Delay(1000)
#            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
#            Delay(5000)
#            Log.Enabled=True
#            Log.File(log_path, aqConvert.VarToStr(srch_child_name)+" Output File Attached")
#            Log.Enabled=False     
#            Sys.Browser("iexplore").Page("https://core*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.*").Close()
#            Sys.Browser("iexplore").Page("https://core*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.*").Close()
#            Filesaved = 'True'
#            return                           
#        elif i >=27:
#           Delay(20000)
#           refresh_button.Find("AWTComponentAccessibleName","Refresh Data alt R").Click()
##           jFrame.keys("~r")
##           prop=["AWTComponentAccessibleName","JavaClassName"]
##           val=["Refresh Data alt R","Button"]
##           req_form.FindChild(prop,val,10).click()           
#           Delay(3000)
#           i=20
#           val=["Name",i]
#           child_name=req_form.Find(prop,val,10).wText
#
#        else:  
#           Delay(3000)
#           i=i+1 

 def req_set_save_output(self,jFrame,req_form,srch_child_name,Preqid):
    web_utils.log_checkpoint("Checking for "+aqConvert.VarToStr(srch_child_name)+ " Child Program Status",500,jFrame)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChild(prop,val,60)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Refresh Data alt R","Button"]
    refresh_button=req_form.FindChild(prop,val,60)
    refresh_button.Find("AWTComponentAccessibleName","Refresh Data alt R").Click()
    i=20
    for x in range(1,180):     
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Name",i]
        child_name=req_form.Find(prop,val,10).wText 
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Phase",i+20]
        phase=req_form.Find(prop,val,10).wText 
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Request ID",i-10]
        creqid=VarToStr(req_form.Find(prop,val,10).wText) 
                                                
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Status",i+30]
#        index =i+30         
        status =req_form.FindChild(prop,val,60)            
        if (child_name==srch_child_name) and (VarToInt(creqid)>=VarToInt(Preqid)) and (phase == "Completed"):

            web_utils.log_checkpoint(aqConvert.VarToStr(srch_child_name)+" Phase Completed Successfuly",500,jFrame)            
            status.Keys("[Enter]")    
            status.Click()        
            Delay(1000)
            prop=["AWTComponentAccessibleName","AWTComponentIndex"]
            val=["View Output alt p","11"]
            log_button=req_form.FindChild(prop,val,60)
            log_button.Find("AWTComponentAccessibleName","View Output alt p").Click()      
            Delay(3000)
            output_page=Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
            output_page.Click()
            Delay(2000)
            output_page.Keys("~f")
            Delay(2000)
            output_page.Keys("a")
            Delay(5000)
            file_system_utils.create_folder(self.op_log_path)             
            log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"File"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"_%d%b%Y_%H%M")+".txt"    
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
            Delay(1000)
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
            Delay(5000)
            Log.Enabled=True
            Log.File(log_path, aqConvert.VarToStr(srch_child_name)+" Output File Attached")
            Log.Enabled=False     
            web_utils.close_additional_browsers() 
            Filesaved = 'True'
            return                           
        elif i >=27:
           Delay(20000)
           refresh_button.Find("AWTComponentAccessibleName","Refresh Data alt R").Click()        
           Delay(3000)
           i=20
           val=["Name",i]
           child_name=req_form.Find(prop,val,10).wText

        else:  
           Delay(3000)
           i=i+1 



