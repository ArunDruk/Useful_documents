﻿import key_utilities
import keys_utility
import web_utility
import oracle_responsibility_utility
import oracle_menus_form
import gvar
import re
import financial_information_find_assets_form
import book_controls_form
import asset_workbench_find_assets_form
import retirements_form
import oracle_menus_form
import tc_logs
import database_helper
import find_requests_form
  
  


# This method is used to GET the parent hierarchy for the EBS Java Form, then SET it to 
def get_java_parent_form():  
    delay(5000)
    #web_utility.validate_ebs_security_box()
    web_utility.validate_ebs_security_box_new()
    delay(10000)
    try:  
        frame = Aliases.jp2launcher.Frame
        frame.Click(358, 22)
        frame.Click(517, 18)
        delay(5000)
        if Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).WaitProperty("Exists",True,60000):
            gvar.dataprep['jformobject']=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1)  
    except:
        if Sys.Process("java").SwingObject("JBufferedFrame", "*", -1, 1).Exists:
            gvar.dataprep['jformobject']=Sys.Process("java").SwingObject("JBufferedFrame", "Oracle Applications*", -1, 1)
    
    #tc_logs.checkpt_with_picture("Forms opened Successfully","",gvar.dataprep['jformobject'])
    close_notification_object() 
    tc_logs.checkpt_with_picture("Forms opened Successfully",pmHigher,gvar.dataprep['jformobject'])

     
def exit_apps_and_close_add_tabs():
  key_utilities.exit_oracle_applications(gvar.dataprep['jformobject'])
  #web_utility.close_additional_tabs()
  Delay(2000)   
       
def close_notification_object():
#   gvar.dataprep['jformobject'].Keys("~o")
#   oracle_menus_form.ok_button_notification_window().Click()
  if oracle_menus_form.note_window().Exists:
     oracle_menus_form.ok_button_notification_window().Click()
     Delay(10000)
  
     
def submit_single_request():
    #oracle_menus_form.single_request_radio_btn().Click()
    gvar.dataprep['jformobject'].Keys("~o")

def submit_request_set():
    oracle_menus_form.request_set_radio_btn().Click()
    gvar.dataprep['jformobject'].Keys("~o")
##Please use get_request_id instead of get_requestid
#def get_requestid(object):
#    RequestID = ''.join(x for x in object.AWTComponentAccessibleName if x.isdigit())
#    tc_logs.checkpt_with_picture(f"Job Submitted Successfully with the RequestId: {RequestID}","",oracle_menus_form.decision_choicebox())
#    return RequestID
def get_requestid():
  requestid = ''.join(x for x in oracle_menus_form.decision_choicebox().AWTComponentAccessibleName if x.isdigit())
  tc_logs.checkpt_with_picture("Job Submitted Successfully with the RequestId: "+requestid,pmHigher,oracle_menus_form.decision_choicebox())
  return requestid 
    
    
def validate_specific_request():
  try:
    RequestID = get_request_id()
    gvar.dataprep['jformobject'].Keys('~n')
    get_specific_request_details(RequestID)
    tc_logs.validation("***VALIDATION FOR SUCCESSFUL COMPLETION OF CONCURRENT JOB***")
   #job_completed = database_helper.get_requestid_details(RequestID,50000)
    job_completed = database_helper.check_request_id_status(RequestID,10000)
    if job_completed:
       Delay(100000)
       gvar.dataprep['jformobject'].Keys('~r')
       Delay(20000)
       gvar.dataprep['jformobject'].Keys('~p')
       tc_logs.checkpt_with_picture("Concurrent Job Completed Successfully",pmHigher,Sys.Browser("iexplore").BrowserWindow(0))
    else: 
       gvar.dataprep["jformobject"].Keys("~g")
       aqUtils.Delay(1000)
       tc_logs.error_with_picture("Job Failed for RequestID: "+RequestID+" Please check the error and try again"+traceback.format_exc(),"",gvar.dataprep['jformobject'])
  except Exception as e:
   Log.Message(VarToStr(e))
   
def get_request_id():
   requestid = ''.join(x for x in oracle_menus_form.decision_choicebox().AWTComponentAccessibleName if x.isdigit())
   tc_logs.checkpt_with_picture("Job Submitted Successfully with the RequestId: "+requestid,pmHigher,oracle_menus_form.decision_choicebox())
   return requestid 

def get_specific_request_details(RequestID):
    oracle_menus_form.view_tab().Keys("~vr")
    find_requests_form.specific_requests_radio_btn().Click()
    find_requests_form.requestid_textfield().SetText(RequestID)
    keys_utility.press_tab()
    find_requests_form.find_button().Click()

def close_form(wait_time = 2000):
    gvar.dataprep['jformobject'].Keys("~fx")
    aqUtils.Delay(wait_time)
    gvar.dataprep['jformobject'].Keys("~o")
    aqUtils.Delay(wait_time)
    tc_logs.checkpt_with_picture("Successfully closed all forms",pmHigher,Sys.Browser("iexplore").BrowserWindow(0))
        
def get_wtext_by_AWTComponentAccessibleName(jbframe,prop_value):
  if jbframe.Find("AWTComponentAccessibleName",prop_value,60).Exists:
    value = jbframe.Find("AWTComponentAccessibleName",prop_value,60).wText
    return value

def click_by_AWTComponentAccessibleName(jbframe,description):
  jbframe.Find("AWTComponentAccessibleName",description,60).Click()
  
def send_keys_by_AWTComponentAccessibleName(jbframe,description,text):
  if jbframe.Find("AWTComponentAccessibleName",description,60).Exists:
    jbframe.Find("AWTComponentAccessibleName",description,60).Keys(text)
  
def send_keys_by_properties(jbframe,prop_value1,prop_value2,asset_number):
  prop_names = ["AWTComponentAccessibleName","AWTComponentName","AWTComponentIndex"]
  prop_values = [prop_value1,prop_value2,0]
  jbframe.Find(prop_names,prop_values,60).Keys(asset_number)

def validate_asset_number_status(db_asset_number):

#  prop_value = "VTextField199"
#  send_asset_number_into_asset_workbench(db_asset_number,prop_value)
  send_asset_number_into_asset_workbench(db_asset_number)
  form_asset_status = capture_status_and_retire_date()
  compare_asset_status(form_asset_status)
  
def send_asset_number_into_asset_workbench(db_asset_number):
  find_asset_wdw = asset_workbench_find_assets_form.find_assets_window()
  asset_workbench_find_assets_form.asset_number_textfield(find_asset_wdw).Keys(db_asset_number)
#  send_keys_by_properties(gvar.dataprep['jformobject'],"Asset Number",prop_value,db_asset_number)
  gvar.dataprep['jformobject'].Keys("~i")
#  key_utilities.press_alt_i(gvar.dataprep['jformobject'])
  aqUtils.Delay(5000)
  gvar.dataprep['jformobject'].Keys("~r")
  aqUtils.Delay(5000)
#  key_utilities.press_alt_r(gvar.dataprep['jformobject'])
  gvar.dataprep['jformobject'].Keys("^[F11]")
#  key_utilities.ctrl_f11(gvar.dataprep['jformobject'])
  
def capture_status_and_retire_date():
  rtr_wdw = retirements_form.retirements_window()
  form_asset_status = retirements_form.status_textfield(rtr_wdw).wText
#  form_asset_status = get_wtext_by_AWTComponentAccessibleName(jbframe,'Status Required')
  tc_logs.checkpt_with_picture(f"The asset retirement status found in the retirments form is '{form_asset_status}'","",gvar.dataprep['jformobject'])
  if form_asset_status == 'PROCESSED':
    retire_date = retirements_form.retire_date_textfield(rtr_wdw).wText
#    retire_date = get_wtext_by_AWTComponentAccessibleName(jbframe,'Retire Date Required')
    tc_logs.checkpt_with_picture(f"Asset Retired date: '{retire_date}'","",gvar.dataprep['jformobject'])
#    Log.Checkpoint("Asset Retired date: " +retire_date,"",pmHighest,"",jbframe)
  return form_asset_status

def compare_asset_status(form_asset_status):
  if form_asset_status == 'PROCESSED':
    tc_logs.checkpt_with_no_picture("Asset number retired successfully")
#    Log.Checkpoint("Asset number retired successfully")
  else:
    tc_logs.checkpt_with_no_picture("Asset resold successfully, but not retired.")
#    Log.Checkpoint("Asset resold successfully, but not retired.")
  key_utilities.exit_oracle_applications(gvar.dataprep['jformobject'])
  aqUtils.Delay(3000)
  
  
def validate_pending_asset_number(jbframe):
  key_utilities.click_down_arrow(jbframe)
  key_utilities.click_enter_n_times(jbframe,2)
  asset_number,vin = database_helper.get_fa_asset_number('PENDING')
  database_helper.validate_new_order_creation_for_fa_vin(vin)
  prop_value = "VTextField448"
  jbframe = send_asset_number_into_asset_workbench(asset_number,prop_value)
  actual_status = capture_status_and_retire_date(jbframe)
  compare_asset_status(jbframe,actual_status)
  key_utilities.exit_oracle_applications(jbframe)

  
def run_depreciation_via_fixed_assest(page):
  oracle_responsibility.click_fixed_assets_manager(page,"Run Depreciation")
  jbframe = gvar.dataprep['jformobject']
  jbframe.Find("AWTComponentAccessibleName","Book RequiredList of Values",60).Keys("MAN USPOLI BOOK" + "[Tab]")
  click_by_AWTComponentAccessibleName(jbframe,"Close Period alt C")
  key_utilities.press_alt_r(jbframe)
  key_utilities.press_alt_f(jbframe)
  key_utilities.press_x(jbframe)
  return jbframe
  
def run_depreciation_via_fixed_assests():
  oracle_menus_form.run_depreciation_book_textfield().Keys("MAN USPOLI BOOK" + "[Tab]")
  oracle_menus_form.close_period_checkbox().Click()
  key_utilities.press_alt_r(gvar.dataprep['jformobject'])
  aqUtils.Delay(3000)
  key_utilities.press_alt_o(gvar.dataprep['jformobject'])
  

def get_current_period_from_forms(page,jbframe):
  oracle_responsibility.click_book_controls(page)
  key_utilities.f11_key(jbframe)
  send_keys_by_AWTComponentAccessibleName(jbframe,"Book Required","MAN USPOLI BOOK")
  key_utilities.ctrl_f11(jbframe)
  current_period = form_utility.get_wtext_by_AWTComponentAccessibleName(jbframe,"Current Period Required")
  Log.Checkpoint(current_period)

def get_requestid_by_contenttext(object):
  tc_logs.checkpt_with_no_picture("----- Get Request ID Details -----")
  request_id = ''.join(x for x in object.contentText[35:44] if x.isdigit())
  tc_logs.checkpt_with_picture(f"Job submitted successfully with RequestId: '{request_id}'","",gvar.dataprep['page'])
  return request_id



def extract_digits_awtcomponentaccessiblename(object):
    value = ''.join(x for x in object.AWTComponentAccessibleName if x.isdigit())
    return value



def find_object_by_awtcomponentaccessiblename(value,wait_time=60000):
#    return gvar.dataprep['jformobject'].FindChildEx('AWTComponentAccessibleName', value, 60, True, wait_time)
    return gvar.dataprep['jformobject'].Find('AWTComponentAccessibleName', value, 60)
    
def find_object_by_awtcomponentname(value,wait_time=60000):
#    return gvar.dataprep['jformobject'].FindChildEx('AWTComponentName', value, 60, True, wait_time)
    return gvar.dataprep['jformobject'].Find('AWTComponentName', value, 60)
    
def find_object_by_list_props(propnames, propvalues, wait_time=60000):
#    return gvar.dataprep['jformobject'].FindChildEx(propnames, propvalues, 20, True, wait_time)
    return gvar.dataprep['jformobject'].Find(propnames, propvalues, 60)
    
    
def set_text_by_awtcomponentaccessiblename(jformobject,property_value,textvalue):
    if jformobject.Find("AWTComponentAccessibleName",property_value,60).Exists:
       jformobject.Find("AWTComponentAccessibleName",property_value,1000).Keys(textvalue)
    else:
      Log.Error("jformobject not found/operation not possible with this object")
      
def convert_str_int(amount):
   return float(re.sub('[?|!@#$!,^a-zA-Z]', '', amount))
   
def set_concurrent_process_name(processname): 
    form_utility.set_text_by_awtcomponentaccessiblename("","Name RequiredList of Values",processname+"[Tab]")  
    tc_logs.checkpt_with_picture("Concurrent process name: "+processname,"",gvar.dataprep['jformobject'])   
    

def validate_invoice_request(jformobject):
  try:
    RequestID = get_requestid()
    keys_utility.press_alt_n()
    get_specific_request_details(RequestID)
  #    get_specificrequest_details(RequestID)
    tc_logs.validation("***VALIDATION FOR SUCCESSFUL COMPLETION OF CONCURRENT JOB***")
    job_completed = database_helper.get_requestid_details(RequestID ,50000)
    if job_completed:
       Delay(100000)
       keys_utility.press_alt_r()
       tc_logs.checkpt_with_picture("Auto Invoice Program Completed Successfully",pmHigher,gvar.dataprep['jformobject'])
       keys_utility.close_form()
       aqUtils.delay(1000)
       keys_utility.close_form()
       aqUtils.delay(1000)
       keys_utility.press_alt_o()
       
    else: 
       gvar.dataprep["jformobject"].Keys("~g")
       aqUtils.Delay(1000)
       tc_logs.error_with_picture("Job Failed for RequestID: "+RequestID+" Please check the error and try again"+traceback.format_exc(),"",jformobject)
  except Exception as e:
   Log.Message(VarToStr(e))
   
   

