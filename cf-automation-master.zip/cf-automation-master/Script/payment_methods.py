﻿import tc_logs
from gvar import dataprep as DATAPREP
import gvar 
import api_utility
import payment_method_api_payloads as PAY_METH_PAYLOADS
import odm_datatype 

__print = tc_logs.checkpt_with_no_picture
__Error = tc_logs.error_with_no_picture
__API_POST  = api_utility.post_or_put
__API_PUT   = api_utility.put
__API_GET   = api_utility.get
__ORDER_BUYER_POST = PAY_METH_PAYLOADS.post_payment_method_payload
__LOAD_ENV = gvar.load_environment_files

def __validate_post_response(response):
    if response['paymentMethodDetails'] is not None:
      __print("Payload post was successfull")
      METHODS = response['paymentMethodDetails']['customerPaymentMethods']
      for METHOD in METHODS:
        if METHOD['paymentMethodType'] == 'ACH':
          for key, item in METHOD.items():
            DATAPREP[key]=item
    else:
      __Error(f"Failed Status: Payment Methods")
      
      
    
def paym_method_api_post(api_name):
#def paym_method_api_post():
#   api_name = 'payment_method_api'                                  
#   DATAPREP['env'] = 'TRND'
#   DATAPREP['auction'] = 'QIM5'
#   __LOAD_ENV() 
#   odm_datatype.load_test_data(odm_datatype.GENERAL_5M_DATA_SF)   
   __validate_post_response(__API_POST(api_name,__ORDER_BUYER_POST())) 
      
