﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils
import web_utils
import form_utils

# Code updated by Uday for various changes - 10/24 Completed

#Michael Bennett
#8-14-2019
#This Component is used to access the attachment for an invoices

class tc99928cai_us_view_invoice_attachment(Ebiz):
  global rowno
  rowno = 2
  
  def login(self):
    self.login_user = "rmaran"
    super().login()
    
  def action(self,book): 
    app = book.Sheets.item["Invoice"]
    self.wait_until_page_loaded()
    self.page.wait()
    Log.Message("Inside action...") 
    temp=web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" AP INVOICE PROCESSING')]")       
    self.verify_aqobject_chkproperty(temp[0],"contentText",cmpIn,"CAI "+self.oper_unit+" AP INVOICE PROCESSING")
    self.log_message_web("Click 'CAI "+self.oper_unit+" AP INVOICE PROCESSING' - Successful")      
    self.wait_until_page_loaded()      
    
    web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Invoices')]")       
    self.log_message_web("Click 'Invoices' - Successful")       
    Delay(3000)
    
    temp=web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Inquiry')]")       
    self.log_message_web("Click 'Inquiry' - Successful")
    Delay(3000)
    
    self.page.EvaluateXPath("//div[text()='Invoices']")[2].Click()
    self.log_message_web("Click 'Invoices' - Successful")
    Delay(3000)
    
    #Allow page to load and Initialize JFrame
    delay(10000)     
    jFrame=self.initializeJFrame()
    Delay(8000)
    form_utils.click_ok_btn(jFrame)
    Delay(8000)
    
    #Finding Invoice that needs to be accessed for attachment
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Invoices","ExtendedFrame"]
    par_form=jFrame.FindChildEx(prop,val,20,True,60000)
    # Updated by Uday as it was failing
    val2=["Invoice: Number","VTextField"]
    par_form.Find(prop,val2,10).Click()
    par_form.Find(prop,val2,10).Keys(app.Cells.Item[rowno,13])

    
    #____Michael Bennett Update 9/19/2019____#
    Delay(2000)
    prop=["AWTComponentAccessibleName", "AWTComponentIndex", "AWTComponentName"]
    val=["Invoice: Dates: StartList of Values", "12", "VTextField958"]
    jFrame.FindChild(prop,val,20).SetText(aqConvert.DateTimeToFormatStr(aqDateTime.Today(),"%d-%b-%Y"))
    Delay(2000) 
    prop=["AWTComponentAccessibleName", "AWTComponentIndex", "AWTComponentName"]
    val=["Invoice: Dates: EndList of Values", "13", "VTextField959"]
    jFrame.FindChild(prop,val,20).SetText(aqConvert.DateTimeToFormatStr(aqDateTime.Today(),"%d-%b-%Y"))
    Delay(2000)


    delay(6000) 
    jFrame.Keys("~i")
    Delay(5000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Invoice Workbench*","ExtendedFrame"]
    inv_wrk_bench_frm=jFrame.FindChildEx(prop,val,60,True,90000)
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Type Required",8]
    inv_type=inv_wrk_bench_frm.FindChildEx(prop,val,60,True,90000)
    Log.Enabled=True
    aqObject.CheckProperty(inv_type,"wText",cmpIn,"Standard")
    Log.Enabled=False
    self.log_message_oracle_form(jFrame,"Invoice found Successfully")
    
    #Access Attachments in Oracle Forms Workbench
    jFrame.Keys("~v")
    Delay(3000)
    jFrame.Keys("a")
    Delay(3000)
    self.log_message_web("Attachment found Successfully")
    jFrame.Keys("~d")
    Log.Enabled=True
    Log.Enabled=False
    
    # Added by Uday as SSO is not enabled yet
    
    super().logout()
    delay(4000)
    Sys.Browser("iexplore").page("https://*epfinnp.coxautoinc.com*").Close()
    
    
    # The below 2 lines are added as SSO is not yet enabled for WCI - Uday
    self.login_user = "pburugupal"
   
    Sys.Browser("iexplore").page("https://securelogin.qa.coxautoinc.com*").FindChild("idStr","userid",20).SetText(self.login_user) 
    self.page.Keys("[Tab]") 
    Sys.Browser("iexplore").page("https://securelogin.qa.coxautoinc.com*").FindChild("idStr","password",20).SetText("oracle123")
    
    delay(3000)
    
    Sys.Browser("iexplore").page("https://securelogin.qa.coxautoinc.com*").FindChild("Name","SubmitButton*",20).Click()
    
    #Click Ok for alerts for attachment display
    if Sys.Browser("iexplore").Page("*").Alert.Exists:
      Sys.Browser("iexplore").Page("*").Alert.Button("OK").Click()
    Delay(3000)
      
    if Sys.Browser("iexplore").Page("*").Alert.Exists:
      Sys.Browser("iexplore").Page("*").Alert.Button("OK").Click()
    Delay(3000)

    if Sys.Browser("iexplore").Page(self.testConfig['ebiz']['webCenCapUrl']+"*").Alert.Exists:
      Sys.Browser("iexplore").Page(self.testConfig['ebiz']['webCenCapUrl']+"*").Alert.Button("OK").Click()
    Delay(2000)
    
    jbox=Sys.Process("java").SwingObject("JDialog", "Security Warning", -1, 1).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("DialogTemplate$16", "", 0).SwingObject("JPanel", "", 0)
    for i in range(1,5):
       if jbox.Exists:
         Sys.HighlightObject(jbox)  
         jbox.Keys("[Tab]")
         jbox.Keys("[Tab]")
         jbox.Keys(" ")
         Delay(1000)
         jbox.Keys("[Enter]")
         Delay(1000)

    
    #Wait for page to load and display attachment
    Sys.Browser("iexplore").BrowserWindow(0).Wait()
    self.log_message_web("Attachment shown")
    Delay(6000)
    
    #Close Browser
    Sys.Browser("iexplore").Page("https://*manheim.com/imaging/faces/Pages/CommonUserMessage.jspx*").Close()
    # added below - Uday
    super().close_forms(jFrame)
    
    # Uncomment below once the SSO is enabled
#    jFrame.Click()
#    jFrame.Keys("[F4]")
#    Delay(1000)
#    jFrame.Keys("[F4]")
#    Delay(1000)
#    jFrame.Keys("~o")
#    Delay(1000)
    # Uncomment after the SSO is enabled - Uday
    #Sys.Browser("iexplore").page("https://*ebs.coxautoinc.com/forms/frmservlet*").Close() 
    
    
def sample():
   jbox=Sys.Process("java").SwingObject("JDialog", "Security Warning", -1, 1).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("DialogTemplate$16", "", 0).SwingObject("JPanel", "", 0)
   for i in range(1,5):
     if jbox.Exists:
       Sys.HighlightObject(jbox)  
       jbox.Keys("[Tab]")
       jbox.Keys("[Tab]")
       jbox.Keys(" ")
       Delay(1000)
       jbox.Keys("[Enter]")
       Delay(1000)

    
#   jFrame=Sys.Process("jp2launcher").WaitSwingObject("JFrame", "Oracle Applications*", -1,1,90000)
#    
#    prop=["AWTComponentAccessibleName", "AWTComponentIndex", "AWTComponentName"]
#    val=["Invoice: Dates: StartList of Values", "12", "VTextField958"]
#    jFrame.FindChild(prop,val,20).SetText(aqConvert.DateTimeToFormatStr(aqDateTime.Today(),"%d-%b-%Y"))
#    Delay(2000) 
#    prop=["AWTComponentAccessibleName", "AWTComponentIndex", "AWTComponentName"]
#    val=["Invoice: Dates: EndList of Values", "13", "VTextField959"]
#    jFrame.FindChild(prop,val,20).SetText(aqConvert.DateTimeToFormatStr(aqDateTime.Today(),"%d-%b-%Y"))
#    Delay(2000)
#    
    
    
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Find Invoices","ExtendedFrame"]
#    par_form=jFrame.FindChildEx(prop,val,20,True,60000)
#    val2=["Invoice: Number","VTextField"]
#    par_form.Find(prop,val2,10).Click()
#    par_form.Find(prop,val2,10).Keys("INV")
#  
