﻿from ebiz import *
import web_utils
import form_utils
import dbhelper
import file_system_utils


class tc84514_cai_us_gl_enter_and_post_webadi_journal_ete18(Ebiz):

 op_log_path ="C:\\TC_Logs"

 def login(self):
   self.login_user='mfallwell'
   super().login()
   
 def action(self,book):
   Log.Enabled=True
   Log.Message("Currency Selected for WebADI Journal entry:  "+ProjectSuite.Variables.currency)
   Log.Enabled=False
   if ProjectSuite.Variables.currency =="USD": 
    app = book.Sheets.item["JournalWebAdi_USD"]
   elif ProjectSuite.Variables.currency=="CAD":
    app = book.Sheets.item["JournalWebAdi_CAD"]
    
   # Navigation to Oracle Home Page
   prop_names = ("innerHTML")
   prop_values = ("Oracle Applications Home Page")
   obj =  Sys.Browser("iexplore").Page("*").FindChild(prop_names,prop_values,30)
   self.log_message_web("Navigation to Oracle Home page Successful")
   Delay(2000)
   web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI ALL WEBADI USER')]")
   self.log_message_web("Click 'CAI ALL WEBADI USER' - Successful")
   Delay(3000)
   
   #Navigating to CAI ALL WEBADI USER & Launching WebADI template
   if ProjectSuite.Variables.currency=="USD":
     self.page.Find("idStr","LayoutList",30).ClickItem("1.1 US - CAI Non-Reversing Journals")  
     self.log_message_web("Selecting WebADI template '1.1 US - CAI Non-Reversing Journals' - Successful")
   elif ProjectSuite.Variables.currency=="CAD":
     self.page.Find("idStr","LayoutList",30).ClickItem("1.3 US - CAI Foreign Actuals Multiple Ledgers")
     self.log_message_web("Selecting WebADI template '1.3 US - CAI Foreign Actuals Multiple Ledgers' - Successful")    
   Delay(2000)
   
   self.page.Find("idStr","CreateDocumentSubmitButton",30).Click()
   self.wait_until_page_loaded()
   web_utils.clk_link_by_xpath(self.page,"//div[@id='p_SwanPageLayout']//button[@id='createDocument']")
   Delay(15000)   
   Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Notification Bar", "", 1).UIAObject("Notification").UIAObject("Open").Click()
   delay(8000)
   
    ### Below code is used to close the sign-in window of Excel sheet   

   web_utils.close_excel_sign_in_window()
   delay(2000)

#   vfy_window=Sys.Process("EXCEL",2).WaitWindow("ThunderDFrame", "Download", 1, 90000)
#   while vfy_window.FindChild("ObjectType","TextNode",60).contentText != "Your document has been created.":      
#      Delay(4000)
#      vfy_window=Sys.Process("EXCEL",2).WaitWindow("ThunderDFrame", "Download", 1, 20000)
#   Delay(4000)
#   vfy_window.Keys("~c")
#   Delay(10000)
#   Sys.Process("EXCEL").Window("XLMAIN", "General Ledger - Journals  -  Read-Only - Excel", 1).Window("XLDESK", "", 1).Window("EXCEL7", "General Ledger - Journals  -  Read-Only", 1)          
   
   xl_window=Sys.Process("EXCEL", 2).Window("XLMAIN", "General Ledger - Journals*", 1).Window("XLDESK", "", 1).Window("EXCEL7", "General Ledger*", 1)
   Delay(5000)
   if ProjectSuite.Variables.currency=="USD":
    self.usd_template_values(xl_window,app)
   elif ProjectSuite.Variables.currency=="CAD":
    self.cad_template_values(xl_window,app)
   
   Log.Enabled=True
   wnd = Sys.Desktop.ActiveWindow()
   Log.Picture(wnd, "WebADI has been launched and Ledger,Category,Source,Currency,Accounting Date,Accounting Information,Amounts have been entered in WebADI successfully", wnd.FullName)                  
   Log.Enabled=False  
   excel_obj=Sys.Process("EXCEL", 2).Window("XLMAIN", "General Ledger - Journals*", 1).Window("EXCEL2", "", 2).Window("MsoCommandBar", "Ribbon", 1).Window("MsoWorkPane", "Ribbon", 1).Window("NUIPane", "", 1).Window("NetUIHWND", "", 1)
   Delay(1000)
   OCR.Recognize(excel_obj).BlockByText("Oracle").Click()
   Delay(1000)
   OCR.Recognize(excel_obj).BlockByText("Upload").Click()
   Delay(4000) 

   
   
   #Uploading the Journal
   upload_wnd=Sys.Process("EXCEL",2).WaitWindow("ThunderDFrame", "Journals Upload", 1,20000)
   if upload_wnd.Exists:
       Sys.Process("EXCEL",2).Window("ThunderDFrame", "Journals Upload", 1).Find("contentText","Import With Validation",40).Click()
       Sys.Process("EXCEL",2).Window("ThunderDFrame", "Journals Upload", 1).Find("ObjectLabel","Upload",40).Click()
       Delay(23000)
       if upload_wnd.Find("ObjectIdentifier","errorl_gif",40).Exists:
         self.log_message_oracle_excel_popup(upload_wnd,"Journal Upload Failed!!")
         Log.Error("Journal WebADI Upload Failed.") 
         Runner.Stop()                 
       else:
         Log.Enabled=True
         wnd = Sys.Desktop.ActiveWindow()
         Log.Picture(wnd, "Journal WebADI Upload Passed",wnd.FullName)
         Log.Enabled=False
         
   conf_msg=upload_wnd.Find("idStr","BneAsyncUploadPageConfirmation",40).contentText 
   self.log_message_oracle_excel_popup(upload_wnd,"Journal WebADI Upload Confirmation Screen Attached")
   self.log_message_oracle_excel_popup(upload_wnd,"Confirmation Message:- "+aqConvert.VarToStr(conf_msg))
   Delay(4000)            
   upload_wnd.Find("ObjectLabel","Close",20).Click() 
   req_id=conf_msg.split("Request ID",4)[1][1:9]
   app.Cells.Item[2,14] =VarToStr(req_id)
   Delay(4000)
#   xl_window.Keys("[F12]")
#   Delay(4000)
#   file_system_utils.create_folder(self.op_log_path)             
#   log_path=self.op_log_path+"\\"+"webaditemplate_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".xlsx"    
#   Sys.Process("EXCEL", 2).Window("#32770", "Save As", 1).Keys(log_path)
#   Delay(2000)
#   Sys.Process("EXCEL", 2).Window("#32770", "Save As", 1).Keys("[Enter]")
#   Delay(4000)
#   Sys.Process("EXCEL", 2).Window("#32770", "Microsoft Excel", 1).Window("Button", "&Yes", 1).Click()
#   Delay(10000)
#   Log.Enabled=True
#   Log.File(log_path, "WebADI template which is used for this test is attached")
#   Log.Enabled=False
   Delay(4000) 
   xl_window.Keys("~[F4]")
   Delay(7000)
   xl_window.Keys("~n")
   self.page.EvaluateXPath("//img[@title='Home']")[0].Click()
   self.page.wait_until_page_loaded()
   Delay(5000)  
   
   #Navigating to CAI ALL GL JOURNAL PROCESSING & Checking Web ADI - Journal Import (Journal Import) process
   web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI ALL GL JOURNAL PROCESSING')]")
   self.log_message_web("Click 'CAI ALL GL JOURNAL PROCESSING' - Successful")
   Delay(5000)
   web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Enter Journals')]")
   self.log_message_web("Click 'Enter Journals' link - Successful")
   Delay(2000)
   web_utils.validate_security_box()
   jFrame=self.initializeJFrame()
   Delay(5000)
   
   form_utils.click_ok_btn(jFrame) 
   Delay(5000)
   jFrame.Keys("[F4]")
   Delay(3000)
   form_utils.save_output_singlereq(self,jFrame,self.op_log_path,"Web ADI - Journal Import (Journal Import)",req_id)
#   jFrame.Click()
#   Delay(3000)
#   jFrame.Keys("[F4]")
   delay(3000) 
   web_utils.log_checkpoint("Closed the Request form ",500,jFrame)
   Delay(3000)
   
   navigator_form = Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("ExtendedFrame", "Navigator - CAI ALL GL JOURNAL PROCESSING", 4)
   Sys.HighlightObject(navigator_form)
#  OCR.Recognize(navigator_form).BlockByText("Enter Journals").DblClick()
   OCR.Recognize(navigator_form).BlockByText("Open").Click()
   
   #Review Imported Journals and Send for Approval
#   Delay(3000)
#   jFrame.Keys("[F4]")
#   Delay(3000)
#   Sys.HighlightObject(jFrame)
#   delay(1000)
#   jFrame.Click()
#   Delay(2000) 
#   jFrame.Keys("[Enter]")
#   jFrame.Keys("~o")
#   jFrame.Keys("e")
   Delay(5000)
#   web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Enter Journals')]")
#   self.log_message_web("Click 'Enter Journals' link - Successful")
#   
#   web_utils.validate_security_box()
#   jFrame=self.initializeJFrame()
#   Delay(4000)
#   form_utils.click_ok_btn(jFrame) 
   
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Find Journals","ExtendedFrame"]
   Find_Journals_Frame=jFrame.FindChildEx(prop,val,60,True,40000)
   self.log_message_oracle_form(jFrame,"Navigation Successful from navigator: Journals > Enter ")
   Delay(3000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["BatchList of Values","VTextField"]
   Find_Journals_Frame.FindChild(prop,val,60).Click()
   Find_Journals_Frame.FindChild(prop,val,60).Keys("%"+req_id+"%")
   Delay(3000)
   
#   self.log_message_oracle_form(Find_Journals_Frame,"Enter Journal Import RequestID: "+req_id+" in Find Journals Screen and Click Find Next")
   web_utils.log_checkpoint("Enter Journal Import Request ID: "+VarToStr(req_id),500,jFrame)
    
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Find alt i","Button"] 
   fnd_button=Find_Journals_Frame.FindChild(prop,val,60)
   fnd_button.Find("AWTComponentAccessibleName","Find alt i",10).Click()
   Delay(5000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Enter Journals (CAI ALL LEDGERS)","ExtendedFrame"]
   Enter_Journals_Frame=jFrame.FindChildEx(prop,val,60,True,40000)
   self.log_message_oracle_form(Enter_Journals_Frame,"Click Review on Enter Journals Form")
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Review Journal alt u","Button"]
   Enter_Journals_Frame.FindChild(prop,val,60).Click()
   Delay(3000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Journals (CAI ALL LEDGERS)*","ExtendedFrame"]
   Journals_Frame=jFrame.FindChildEx(prop,val,60,True,40000)
   self.log_message_oracle_form(Journals_Frame,"Review Journal Information")
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Approve alt A","Button"]
   self.log_message_oracle_form(Journals_Frame,"Click Approve Button on Journals Form")
   Journals_Frame.FindChild(prop,val,60).Click()
   Delay(3000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Note Your journal batch*","ChoiceBox"]
   Note_Form=jFrame.FindChildEx(prop,val,60,True,40000)
   self.log_message_oracle_form(Note_Form,"Your journal batch was forwarded to an approver.")
   Delay(3000)
   Note_Form.Find("AWTComponentAccessibleName","OK ALT O").Click()  
   Delay(2000)
   dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
   user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
   pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
   if self.testConfig['ebiz']['env'] != "preprod":
    dbhelper.verify_cai_journal_status(dsn,user_id,pwd,"%"+VarTostr(req_id))
   jFrame.Keys("[F4]")
   Delay(4000)
   jFrame.Keys("[F4]")
   Delay(2000)
   jFrame.Keys("~o")
   Delay(2000)
   jFrame.Keys("[F4]")
   Delay(4000)
   jFrame.Keys("[F4]")
   Delay(2000)
   jFrame.Keys("~o")
   
   
   
#Entering values in WebADI template for US currency
 def usd_template_values(self,xl_window,app):  
   xl_window.Click()
   Delay(2000)
   xl_window.keys("^g")
   Delay(2000)
   goTo_wnd=Sys.Process("EXCEL", 2).Window("bosa_sdm_XL9", "Go To", 1).Window("EDTBX", "", 1)
   goTo_wnd.Click()
   goTo_wnd.Keys("E10")   
   Delay(1000)
   goTo_wnd.keys("[Enter]")
   Delay(1000)
   xl_window.Keys((aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%b-%y")).upper())
   Delay(1000)
   xl_window.Keys("[Tab]")
   xl_window.Keys(aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d-%b-%Y"))
   Delay(1000)
   xl_window.Click()
   xl_window.keys("^g")
   Delay(2000)
   goTo_wnd=Sys.Process("EXCEL", 2).Window("bosa_sdm_XL9", "Go To", 1).Window("EDTBX", "", 1)
   goTo_wnd.Click()
   goTo_wnd.Keys("[BS]")
   goTo_wnd.Keys("[BS]")
   goTo_wnd.Keys("[BS]")
   Delay(1000)
   goTo_wnd.Keys("C19")   
   Delay(1000)
   goTo_wnd.keys("[Enter]")
   Delay(1000)
   rowno=2
   row_no=10 #12
   
   while rowno<row_no:
    xl_window.Keys(app.Cells.Item[rowno,1])
    xl_window.Keys("[Tab]")
    xl_window.Keys(app.Cells.Item[rowno,2])
    xl_window.Keys("[Tab]")
    xl_window.Keys(app.Cells.Item[rowno,3])
    xl_window.Keys("[Tab]")
    xl_window.Keys(app.Cells.Item[rowno,4])
    xl_window.Keys("[Tab]")
    xl_window.Keys(app.Cells.Item[rowno,5])
    xl_window.Keys("[Tab]")
    xl_window.Keys(app.Cells.Item[rowno,6])
    xl_window.Keys("[Tab]")
    xl_window.Keys(app.Cells.Item[rowno,7])
    xl_window.Keys("[Tab]")
    xl_window.Keys(app.Cells.Item[rowno,8])
    xl_window.Keys("[Tab]")
    xl_window.Keys(app.Cells.Item[rowno,9])
    xl_window.Keys("[Tab]")
    xl_window.Keys(app.Cells.Item[rowno,10])
    xl_window.Keys("[Tab]")
    xl_window.Keys("Test Line Description_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%M%S"))
    xl_window.Keys("[Tab]")
    xl_window.Keys("[Tab]")
    xl_window.Keys("[Tab]")
    xl_window.Keys("[Tab]")
    rowno=rowno+1

#Entering values in WebADI template for CAD currency
 def cad_template_values(self,xl_window,app):
#   xl_window.Click()
#   xl_window.keys("^g")
#   Delay(2000)
#   goTo_wnd=Sys.Process("EXCEL", 2).Window("bosa_sdm_XL9", "Go To", 1).Window("EDTBX", "", 1)
#   goTo_wnd.Click()
#   goTo_wnd.Keys("E7")   
#   Delay(1000)
#   goTo_wnd.keys("[Enter]")
#   Delay(1000)
#   xl_window.Keys(app.Cells.Item[2,12])
#   Delay(3000)
   xl_window.Click()
   Delay(2000)
   xl_window.keys("^g")
   Delay(2000)
   goTo_wnd=Sys.Process("EXCEL", 2).Window("bosa_sdm_XL9", "Go To", 1).Window("EDTBX", "", 1)
   goTo_wnd.Click()
   goTo_wnd.Keys("[BS]")
   goTo_wnd.Keys("[BS]")
   goTo_wnd.Keys("[BS]")
   Delay(1000)
   goTo_wnd.Keys("C17")   
   Delay(1000)
   goTo_wnd.keys("[Enter]")
   Delay(1000)
   rowno=2
   row_no=12
   while rowno<row_no:
    xl_window.Keys(app.Cells.Item[rowno,11])
    xl_window.Keys("[Tab]")
    xl_window.Keys(app.Cells.Item[rowno,13])
    xl_window.Keys("[Tab]")
    xl_window.Keys(app.Cells.Item[rowno,15])
    xl_window.Keys("[Tab]")
    xl_window.Keys(app.Cells.Item[rowno,16])
    xl_window.Keys("[Tab]")
    xl_window.Keys(app.Cells.Item[rowno,17])
    xl_window.Keys("[Tab]")
    xl_window.Keys(aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%m/%d/%Y"))
    xl_window.Keys("[Tab]")
    xl_window.Keys(app.Cells.Item[rowno,1])
    xl_window.Keys("[Tab]")
    xl_window.Keys(app.Cells.Item[rowno,2])
    xl_window.Keys("[Tab]")
    xl_window.Keys(app.Cells.Item[rowno,3])
    xl_window.Keys("[Tab]")
    xl_window.Keys(app.Cells.Item[rowno,4])
    xl_window.Keys("[Tab]")
    xl_window.Keys(app.Cells.Item[rowno,5])
    xl_window.Keys("[Tab]")
    xl_window.Keys(app.Cells.Item[rowno,6])
    xl_window.Keys("[Tab]")
    xl_window.Keys(app.Cells.Item[rowno,7])
    xl_window.Keys("[Tab]")
    xl_window.Keys(app.Cells.Item[rowno,8])
    xl_window.Keys("[Tab]")
    xl_window.Keys(app.Cells.Item[rowno,9])
    xl_window.Keys("[Tab]")
    xl_window.Keys(app.Cells.Item[rowno,10])
    xl_window.Keys("[Tab]")
    xl_window.Keys("Test Line Description_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%M%S"))
    xl_window.Keys("[Tab]")
    xl_window.Keys("[Tab]")
    xl_window.Keys("[Tab]")
    xl_window.Keys("[Tab]")
    rowno=rowno+1






