﻿import dbhelper
from ebiz import *
import web_utils
import dbhelper
import file_system_utils 
import form_utils


#This testcase is to submit MAN: Invoice Validation and Approval Set and getting journal batch name from the output files

class tc191253_is_us_ap_invoice_validation_apprvl_reqset(Ebiz):

 op_log_path="C:\\TC_Logs"

 def login(self):
    self.login_user="mfallwell"
    super().login()

 def goto_url(self,url):
    super().goto_url(self.testConfig['ebiz']['oci_is_url'])
    
 
 def action(self,book): 
 
    web_utils.log_checkpoint("Logged in to Oracle Applications Home Page Successfully",500,self.page)
    self.wait_until_page_loaded()     
    self.page.EvaluateXPath("//table[@id='menuContent']//div[contains(text(),'AP Home Office Super User')]")[0].Click()
    web_utils.log_checkpoint("Click 'AP Home Office Super User' - Successful",500,self.page)
    self.page.Keys("[Down]")
    self.wait_until_page_loaded()
    self.page.NativeWebObject.Find("contentText","Invoices","A").Click()
    web_utils.log_checkpoint("Click 'Invoices' - Successful",500,self.page)
    self.page.Keys("[Down]")
    self.wait_until_page_loaded()
    self.page.NativeWebObject.Find("contentText","Entry","A").Click()
    web_utils.log_checkpoint("Click 'Entry' - Successful",500,self.page)
    self.page.Keys("[Down]")
    self.wait_until_page_loaded()
    self.page.EvaluateXpath("//table[@id='respList']//div[contains(text(),'Invoices')]")[1].Click()
    web_utils.log_checkpoint("Click 'Invoices' - Successful",500,self.page)
    web_utils.validate_security_box()  
    self.jFrame = self.initializeJFrame()
    Delay(9000)
    form_utils.click_ok_btn(self.jFrame)
    delay(9000)
    self.jFrame.FindchildEx("AWTComponentAccessibleName","Invoice Workbench (AP Home Office Super User)",True,60000).Click()
    delay(4000)
    self.jFrame.Keys("[F4]")
    delay(4000)
    self.jFrame.Keys("~v")
    delay(4000)
    self.jFrame.Keys("r")
    delay(4000)
    self.jFrame.Keys("~u")
    delay(4000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit Request Set","ExtendedFrame"]
    par_form=self.jFrame.FindChildEx(prop,val,60,True,60000)
    par_form.Find("AWTComponentAccessibleName","Request Set RequiredList of Values",30).SetText("MAN: Invoice Validation and Approval")
    delay(2000)
    self.jFrame.Keys("[Tab]")
    par=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Parameters","15"]
    par_form=self.jFrame.FindChild(par,val,60)
    par_form.Find("AWTComponentIndex","15",10).Click()
    delay(1000)
    par=["AWTComponentAccessibleName","AWTComponentName"]
    val=["Parameters","FlexWindow*"]
    par_form=self.jFrame.FindChild(par,val,60)
    par_form.Find("AWTComponentAccessibleName","Option REQUIRED List Values",30).SetText("New")
    delay(2000)
    self.jFrame.Keys("[Tab]")
    delay(1000)
    self.jFrame.Keys("~o")
    delay(3000)
    par=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Parameters","16"]
    par_form=self.jFrame.FindChild(par,val,60)
    par_form.Find("AWTComponentIndex","16",10).Click()
    delay(1000)
    par=["AWTComponentAccessibleName","AWTComponentName"]
    val=["Parameters","FlexWindow*"]
    par_form=self.jFrame.FindChild(par,val,60)
    par_form.Find("AWTComponentAccessibleName","Option REQUIRED List Values",30).SetText("New")
    delay(2000)
    self.jFrame.Keys("[Tab]")
    delay(1000)
    web_utils.log_checkpoint("'MAN: Invoice Validation and Approval' parameters entered successfully",500,self.jFrame)
    self.jFrame.Keys("~o")
    delay(3000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit Request Set","ExtendedFrame"]
    submitrequest_form=self.jFrame.FindChild(prop,val,60)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit alt m","Button"]
    submit_button=submitrequest_form.FindChild(prop,val,60)
    submit_button.Find("AWTComponentAccessibleName","Submit alt m",10).Click()
    delay(2000)    
    RequestID = ''.join(x for x in self.jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit())
    web_utils.log_checkpoint("'MAN: Invoice Validation and Approval' is submitted and Request ID is " + aqConvert.VarToStr(RequestID),500,self.jFrame)
    dsn = self.testConfig['man_oracle_db']['dsn']
    user_id = self.testConfig['man_oracle_db']['userid']
    pwd = self.testConfig['man_oracle_db']['pwd']
    dbhelper.verify_oracle_concurrent_job_status(dsn,user_id,pwd,RequestID)  
    delay(2000)       
    self.jFrame.Keys("~n")
    delay(2000)
    self.jFrame.Keys("[F4]")
    delay(1000)
    self.jFrame.Keys("~v")
    Delay(1000)
    self.jFrame.Keys("r")
    Delay(1000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Requests","ExtendedFrame"]
    FindRequests_form=self.jFrame.FindChild(prop,val,60)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find alt i","Button"]
    find_button=FindRequests_form.FindChild(prop,val,60)
    find_button.Find("AWTComponentAccessibleName","Find alt i",30).Click()
    Delay(1000)
    
# Gathering Request ID and Output File for the "Invoice Validation Program" 

    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=self.jFrame.FindChildEx(prop,val,30,True,90000)
    self.req_set_save_output(self.jFrame,req_form,"Invoice Validation",RequestID) 
    Delay(1000)
    self.jFrame.Click()
    Delay(2000)
    self.jFrame.Keys("[F4]")
    Delay(1000)
    self.jFrame.Keys("~v")
    Delay(1000)
    self.jFrame.Keys("r")
    Delay(1000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Requests","ExtendedFrame"]
    FindRequests_form=self.jFrame.FindChild(prop,val,60)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find alt i","Button"]
    find_button=FindRequests_form.FindChild(prop,val,60)
    find_button.Find("AWTComponentAccessibleName","Find alt i",30).Click()
    Delay(1000)

# Gathering Request ID and Output File for the "Invoice Approval Workflow Program"

    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=self.jFrame.FindChildEx(prop,val,30,True,90000)  
    self.req_set_save_output(self.jFrame,req_form,"Invoice Approval Workflow",RequestID)
    Delay(1000)
    self.jFrame.Click()
    Delay(1000)
    self.jFrame.Keys("[F4]")
    Delay(1000)
    self.jFrame.Keys("[F4]")
    Delay(1000)
    self.jFrame.Keys("~o")
    Delay(1000)


    
 def req_set_save_output(self,jFrame,req_form,srch_child_name,Preqid):
    web_utils.log_checkpoint("Checking for "+aqConvert.VarToStr(srch_child_name)+ " Child Program Status",500,self.jFrame)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=self.jFrame.FindChild(prop,val,60)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Refresh Data alt R","Button"]
    refresh_button=req_form.FindChild(prop,val,60)
    refresh_button.Find("AWTComponentAccessibleName","Refresh Data alt R").Click()
    i=20
    for x in range(1,180):     
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Name",i]
        child_name=req_form.Find(prop,val,10).wText 
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Phase",i+20]
        phase=req_form.Find(prop,val,10).wText 
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Request ID",i-10]
        creqid=VarToStr(req_form.Find(prop,val,10).wText) 
                                                
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Status",i+30]
#        index =i+30         
        status =req_form.FindChild(prop,val,60)            
        if (child_name==srch_child_name) and (creqid>=Preqid) and (phase == "Completed"):

            web_utils.log_checkpoint(aqConvert.VarToStr(srch_child_name)+" Phase Completed Successfuly",500,jFrame)            
            status.Keys("[Enter]")    
            status.Click()        
            Delay(1000)
            prop=["AWTComponentAccessibleName","AWTComponentIndex"]
            val=["View Output alt p","11"]
            log_button=req_form.FindChild(prop,val,60)
            log_button.Find("AWTComponentAccessibleName","View Output alt p").Click()      
            Delay(3000)
            output_page=Sys.Browser("iexplore").Page("https://manheim*.epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
            output_page.Click()
            Delay(2000)
            output_page.Keys("~f")
            Delay(2000)
            output_page.Keys("a")
            Delay(5000)
            file_system_utils.create_folder(self.op_log_path)             
            log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"File"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"_%d%b%Y_%H%M")+".txt"    
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
            Delay(1000)
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
            Delay(5000)
            Log.Enabled=True
            Log.File(log_path, aqConvert.VarToStr(srch_child_name)+" Output File Attached")
            Log.Enabled=False     
            web_utils.close_additional_browsers() 
            Filesaved = 'True'
            return                           
        elif i >=27:
           Delay(20000)
           refresh_button.Find("AWTComponentAccessibleName","Refresh Data alt R").Click()        
           Delay(3000)
           i=20
           val=["Name",i]
           child_name=req_form.Find(prop,val,10).wText

        else:  
           Delay(3000)
           i=i+1 
