﻿import configparser 
import database_service 
config = configparser.ConfigParser()
dataprep = {}
excel = {}
keys = []


    
def db_store(rows):
                                                
    global dataprep
    for key,value in rows.items():  
          dataprep[key] = value 

  
def store(key, value):
 global dataprep 
 dataprep[key] = value 
  
#def db_store(db_results):
#  global dataprep
#  if len(db_results) == 1:
#    for key,value in db_results[0].items():
#      dataprep[key] = value   
  
def GetRelativePath(folderPath, fileName):
  sRelPath = aqFileSystem.GetRelativePath(folderPath, fileName)
  return sRelPath
  
def str_to_class(class_name):
        module = __import__(class_name)
        class_ = getattr(module, class_name)()
        class_.execute()
       
def process_class(components):
   if len(components) >= 1:
     for index,component in enumerate(components): 
         Log.Checkpoint(aqString.Format("**** Executing %s operation component ********",VarToStr(component)))
         str_to_class(module_name,component)
  
def load_test_data(testtype):
    load_env_data()
    load_dataprep_data(testtype)
  
def load_dataprep_data(testtype):
   if testtype == 'order_api_get':
    database_helper.get_order_api_testtype_data(testtype = 'order_api_get') 
       
def update_dataprep_data():
    global dataprep
    sql = aqString.Format("update Global set test_result = '%s' where id=%s", dataprep['spec_name'],dataprep['id'])
    database_service.update_delete_mysql(sql)    
   
def load_env_data():
  #get_jenkins_env_variable()
  load_environment_files()
  
def load_environment_files():
  global config
  global dataprep
  
  if dataprep.get('env') is None:
    Log.Enabled = True
    Log.Message(BuiltIn.ParamStr(14))
    dataprep['env'] = BuiltIn.ParamStr(14)
  if dataprep.get('browser') is None:
    Log.Enabled = True
    Log.Message(BuiltIn.ParamStr(16))
    if BuiltIn.ParamStr(16) == '':
      dataprep['browser'] = "ie"
    else:
      dataprep['browser'] = BuiltIn.ParamStr(16)
#    dataprep['env'] = "oci_stage"
    
  path = aqFileSystem.IncludeTrailingBackSlash(Project.Path+'test_configs')
#  capt_wdw = Sys.Process("capture").WaitWindow("SunAwtFrame", "Oracle WebCenter Enterprise Capture - Connected to https://core-capture-dev.epfinnp.coxautoinc.com", 1,10000)
#  path = Project.Path+"DataSheets\\Configs\\"
  
  if (dataprep['env'] == 'oci_stage'):
     config.read(path+'testconfig_oci_stage.ini')
  elif (dataprep['env'] == 'oci_test'):
     config.read(path+'testconfig_oci_test.ini')
  elif (dataprep['env'] == 'oci_dev'):
     config.read(path+'oci_dev_config.ini')

  dataprep['auction'] = BuiltIn.ParamStr(15)
#  dataprep['auction'] = "PSM1"
#def get_jenkins_env_variable():
#    global dataprep
#    for i in range(BuiltIn.ParamCount()):
#      arg_name, arg_value = ProcessCommandLineArgument(BuiltIn.ParamStr(i))
#      if ( arg_name and arg_value ):
#        dataprep[arg_name] = arg_value
#    else:
#      try:
#        dataprep['env']
#      except:
#        dataprep['env'] = 'TSTI'    
#          
#def ProcessJenkinsArgument(arg):
#  
#  items = arg.split("=")
#  if items.length != 2 :
#    return None, None
#  if aqString.ToLower(aqString.Trim(items[0])):
#     Log.Message( aqString.Format("Jenkins %s argument is found! The value is: %s",aqString.Trim(items[0]), aqString.Trim(items[1])))
#     return aqString.Trim(items[0]),aqString.Trim(items[1])

#def store_excel_to_dict(sheet_name):
#    global excel
#    worksheet_data = {}
#    worksheet = dataprep['book'].Sheets.item[sheet_name]
#    
#      #Get number of columns used
#    column_count = worksheet.UsedRange.Columns.Count
# 
#  #For each column, store key->value into worksheet_data
#    for column_num in range(1, column_count + 1):
#        if VarToStr(worksheet.Cells.Item[1,column_num]) != '':
#            header = VarToString(worksheet.Cells.Item[1, column_num])
#            value = VarToString(worksheet.Cells.Item[2, column_num])
##            if value.find(',') != -1:
##                worksheet_data[header] = value.split(',')
##            else:
#            worksheet_data[header] = value
# 
#  #Store worksheet_data dictionary into the excel dictionary
#    excel[sheet_name] = worksheet_data
    
import tc_logs
def store_excel_to_dict1(sheet_name,row_num =1):
    global excel
    worksheet_data = {}
    worksheet = dataprep['book'].Sheets.item[sheet_name]
    
      #Get number of columns used
    column_count = worksheet.UsedRange.Columns.Count
    
  #For each column, store key->value into worksheet_data
    for column_num in range(row_num, column_count + 1):
        if VarToStr(worksheet.Cells.Item[1,column_num]) != '':
            header = VarToString(worksheet.Cells.Item[1, column_num])
            value = VarToString(worksheet.Cells.Item[row_num+1, column_num])

            worksheet_data[header] = value
            
  #Store worksheet_data dictionary into the excel dictionary
    excel[sheet_name] = worksheet_data
    
def write_dict_data_to_excel(sheet_name,header,value,row_num =1):
  
    worksheet = dataprep['book'].Sheets.item[sheet_name]
    column_count = worksheet.UsedRange.Columns.Count
    for column_num in range(row_num, column_count + 1):
        header_sheet = VarToStr(worksheet.Cells.Item[row_num,column_num])
        if aqString.Compare(header_sheet,VartoStr(header),True )==0:
#        if  aqstring.header_sheet == VartoStr(header):
            worksheet.Cells.Item[row_num+1, column_num] = VartoStr(value)
            break

    
  