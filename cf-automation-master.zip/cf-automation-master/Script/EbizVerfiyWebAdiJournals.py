﻿from ebiz import *
from dbhelper import *
import dbhelper
import configparser
import web_utils
#import form_utils
import file_system_utils
import ebiz
import importlib
import form_utils

class EbizVerfiyWebAdiJournals(Ebiz):
  
  def action(self):
    self.page.Wait()
    self.log_checkpoint_message_web("Login Successful")
    web_utils.clk_link_by_xpath(self.page,"//a[@id='AppsNavLink' and contains(text(),'GL Administrator')]")       
    self.log_message_web("Click 'GL Administrator' - Successful")  
    self.page.Wait()
    if(self.page.NativeWebObject.Find("contentText", "Launch Journal Wizard", "a").Exists):
      self.log_checkpoint_message_web("Launch Journal Wizard link found")
    web_utils.clk_link_by_xpath(self.page,"//a[@id='N56']")       
    self.log_message_web("Click 'GL Administrator' - Successful")        
    Delay(3000)
    self.handle_security_popup()
    form_utils.click_ok_btn()
    Delay(3000)        
    jFrame=Sys.Browser("iexplore").WaitSwingObject("JBufferedFrame", "*", -1, 20000) 
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Journals","ExtendedFrame"]    
    find_jnl_form=jFrame.FindChild(prop,val,10) 
    if find_jnl_form.Exists:
       self.log_checkpoint_message_web("Find Journals form found")       
    else:
       self.log_error_message("Find Journals form not found")            
    find_jnl_form.Find("AWTComponentAccessibleName","JournalList of Values",10).Keys("TestCompleteAuto Test Journals AX Payables USD")
    self.log_message_oracle_form(find_jnl_form,"Journal Name: 'TestComplete Test Journals AX Payables USD'")
    find_jnl_form.Find("AWTComponentAccessibleName","SourceList of Values",20).Keys("SpreadSheet")
    self.log_message_oracle_form(find_jnl_form,"SourceList: 'SpreadSheet'")
    find_jnl_form.Find("AWTComponentAccessibleName","PeriodList of Values",20).Keys("FEB-2019") #(aqString.ToUpper(Convert.DateTimeToFormatStr(aqDateTime.Today(),"%b-%Y")))
    jFrame.Keys("~i")
    Delay(3000)
    jFrame.Keys("~u")
    Delay(4000)
    self.log_message_oracle_form(jFrame,"Click Review Journal Successful")
    jFrame.Keys("~p")
    Delay(2000)
    self.log_message_oracle_form(jFrame,"Click Post Journal Successful")
    prop=["AWTComponentName","JavaClassName"]
    val=["ChoiceBox*","ChoiceBox"] 
    req_id= jFrame.FindChild(prop,val,10).AWTComponentAccessibleName 
    self.log_message_oracle_form(jFrame,"Request ID: "+aqConvert.VarToStr(req_id))
    jFrame.Keys("~o")  
    Delay(2000)
    jFrame.Keys("[F4]")          
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~O")    
    Delay(1000)
    self.browser.page("*").Close() 
    Delay(1000)
    
     
def sample():
    try:
        mod = importlib.import_module('form_utils')
        form_utils.sample()
        
        Log.Message("it works")
    except ImportError:
        Log.Message("Failed to load {module}".format(module='ebiz_verfiy_web_adi_journals'),file=sys.stderr)    
         
