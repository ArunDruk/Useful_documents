﻿from ebiz import *
import configparser
import file_system_utils

class capture_singlepage_po_invoice_scan_us(Ebiz):
  
 def login(self):
    self.login_user="pburugupal"
    self.page.Find("idStr","userid",60).setText(self.login_user) 
    self.log_message_web("Set User ID:  "+self.login_user+" Successful")
    self.page.Find("idStr","password",60).setText(self.testConfig['ebiz']['password'])
    self.log_message_web("Set Password:  'oracle123' Successful") 
    self.page.Find("Name","SubmitButton*",60).Click() 

    
 def goto_url(self,url):
   self.testConfig=configparser.ConfigParser()
   self.testConfig.read(Project.Path+"test_configs\\testconfig_oci_stage.ini")    
   super().goto_url(self.testConfig['ebiz']['webCenCapUrl'])
   
 def logout(self):
   self.page.wait()
   self.page.FindChild("idStr","pt1:pt_np1:linkLogout",20).Click()
  # self.log_message_web("Logout Successful")
   
 def action(self,book):
#  p = Sys.Process("EXCEL")
#  app = Sys.OleObject["Excel.Application"]
  Delay(1000)
#  app.Visible = "True"
#  book = app.Workbooks.Open(Project.Path+"\\datasheets\\Oracle-AP-Invoicing\\wci_capture_multiline_dev3_cai.xls")
 # app = book.Sheets.item["wci_capture"]  
  
 
  Delay(3000)
  file_system_utils.create_folder("C:\\TC_Logs")
  app = book.Sheets.item["wci_capture"]   
  if Sys.Browser("iexplore").Page(self.testConfig['ebiz']['webCenCapUrl']+"*").Alert.Exists:
    Sys.Browser("iexplore").Page(self.testConfig['ebiz']['webCenCapUrl']+"*").Alert.Button("OK").Click()
    Delay(2000)
  self.wait_until_page_loaded()
  
  if Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).Tab("WebCenter Capture - Internet Explorer").Window("Shell DocObject View", "", 1).Window("Internet Explorer_Server", "", 1).Window("Java Plug-in Control Window", "", 1).AWTObject("PluginEmbeddedFrame", "").SwingObject("RMCApplet", "", 0).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("FormManagerPanel", "", 0).SwingObject("JPanel", "", 0).SwingObject("ExistingSessionPanel", "", 0).SwingObject("RoundedCornerPanel", "", 0).Exists:
    Sys.Browser("iexplore").BrowserWindow(0).Keys("[Enter]")
    Delay(2000)
  # Check security warning window exists
  security_wnd=Sys.Browser("iexplore").WaitSwingObject("JDialog", "Security Warning", -1, 1,20000)  
  if security_wnd.Exists:
    Sys.Browser("iexplore").SwingObject("JDialog", "Security Warning", -1, 1).FindChild("AWTComponentAccessibleName","I accept the risk and want to run this application.",30).Click()
    Sys.Browser("iexplore").SwingObject("JDialog", "Security Warning", -1, 1).Keys("[Enter]")
  sign_out_link=self.page.FindChildEx("JavaClassName","BatchEditForm$30",30,True,90000)
  
  delay(20000)
  
  # Set the location to ATC 
  Sys.HighlightObject(Sys.Browser("iexplore").FindChildEx("JavaClassName","VetoableComboBox",30,True,60000))
  Sys.Browser("iexplore").FindChildEx("JavaClassName","VetoableComboBox",30,True,60000).Keys("ATC")    
  
  capture_link=self.page.FindChildEx("AWTComponentAccessibleName","Capture",30,True,60000) 
  
  
#  while not sign_out_link.Exists:
#    Delay(2000)
#    sign_out_link=self.page.Find("JavaClassName","BatchEditForm$30",30)      
  #self.log_message_web("Login Successful")
  capture_link=self.page.FindChildEx("AWTComponentAccessibleName","Capture",30,True,60000)
  capture_link.Click()
  Delay(3000)
  #self.log_message_web("Click Capture Successful")
  jProcess=Sys.Process("java")
  imp_dlg_wnd=jProcess.WaitSwingObject("ImportOptionDialog", "Import", -1, 1,3000)      
  imp_dlg_wnd.FindChild("AWTComponentAccessibleName","OK",20).Click()
  Delay(3000)
  jBrowser=Sys.Browser("iexplore")

#  prop_name=["AWTComponentAccessibleName","AWTComponentIndex"]
#  prop_value=["OK",1]
  jBrowser.SwingObject("FileImportDialog", "Select files to import", -1, 1).Find(["AWTComponentAccessibleName","JavaClassName"],["File name:","SynthFileChooserUIImpl$3"],40).SetText("C:\TC_Logs\ATC - Single Page Invoice.pdf")

  file_import_wnd=jBrowser.WaitSwingObject("FileImportDialog", "Select files to import", -1, 1,10000)
  
  jBrowser.SwingObject("FileImportDialog", "Select files to import", -1, 1).Find(["AWTComponentAccessibleName","JavaClassName"],["File name:","SynthFileChooserUIImpl$3"],40).SetText("C:\TC_Logs\ATC - Single Page Invoice.pdf")
  Delay(1000)
  jBrowser.SwingObject("FileImportDialog", "Select files to import", -1, 1).Find(["AWTComponentAccessibleName","JavaClassName"],["File name:","SynthFileChooserUIImpl$3"],40).Click()
  file_import_wnd.Keys("[Enter]")
  self.wait_until_page_loaded()  
  Delay(12000)
  # get batch name and write back to excel
  batch_name=Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).FindChild("AWTComponentAccessibleName","Batch Name:",40).wText
  app.Cells.item[2,2]=VarToStr(batch_name)
  self.log_message_web("Batch Id is " +VarToStr(batch_name)+ "")
  date_time=Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).FindChild("AWTComponentAccessibleName","Date/Time Created:",40).wText
  Sys.Browser("iexplore").Page(self.testConfig['ebiz']['webCenCapUrl']+"*").Find("JavaClassName","BatchEditForm$30",30).Keys("[Right][Right]")
  Sys.Browser("iexplore").Page(self.testConfig['ebiz']['webCenCapUrl']+"*").Find("JavaClassName","BatchEditForm$30",30).Keys("[Down]")
  delay(200000)
  cnt=Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).FindAllChildren("JavaClassName","JSplitPane",60)
  combo_list=cnt[1].FindAllChildren("AWTComponentName","ComboBox.textField",40)
  
  combo_list[4].SetText("SPL")
  delay(1000)
  combo_list[3].SetText("No")
  delay(1000)
  combo_list[2].SetText("Yes")
  self.log_message_web("PrintLocal: "+VarToStr(combo_list[3].wText))
  self.log_message_web("AdvanceCharge: "+VarToStr(combo_list[2].wText))
  self.log_message_web("BatchType: "+VarToStr(combo_list[1].wText))
  self.log_message_web("LockBatch: "+VarToStr(combo_list[0].wText))
  Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).FindChild("AWTComponentAccessibleName","Release",40).Click()
  Delay(16000)
  self.log_message_web("Click 'Release' button successful")






#from dbhelper import * 
#from ebiz import * 
#import configparser 
#import file_system_utils 
# 
#class capture_singlepage_po_invoice_scan_us(Ebiz): 
#  def login(self): 
#     self.login_user="pburugupal" 
#     self.page.Find(self.config['login']['propname'],self.config['login']['propval'],60).setText(self.login_user)  
#     self.log_message_web("Set User ID:  "+self.login_user+" Successful") 
#     self.page.Keys("[Tab]")                 
#     self.page.Find(self.config['password']['propname'],self.config['password']['propval'],60).setText(self.testConfig['ebiz']['password'])  
#     self.log_message_web("Set Password:  'oracle123' Successful")        
#     self.page.Find(self.config['login_btn']['propname'],self.config['login_btn']['propval'],60).Click()  
#  def goto_url(self,url): 
#     self.testConfig=configparser.ConfigParser() 
#     self.testConfig.read(Project.Path+"test_configs\\testconfig_oci_stage.ini")     
#     super().goto_url(self.testConfig['ebiz']['webCenCapUrl']) 
#     self.login_user="pburugupal" 
#     self.page.Find(self.config['login']['propname'],self.config['login']['propval'],60).setText(self.login_user)  
#     self.log_message_web("Set User ID:  "+self.login_user+" Successful") 
#     self.page.Keys("[Tab]")                 
#     self.page.Find(self.config['password']['propname'],self.config['password']['propval'],60).setText(self.testConfig['ebiz']['password'])  
#     self.log_message_web("Set Password:  'oracle123' Successful")        
#     self.page.Find(self.config['login_btn']['propname'],self.config['login_btn']['propval'],60).Click()  
#  def logout(self): 
#    self.page.wait() 
#    self.page.FindChild("idStr","pt1:pt_np1:linkLogout",20).Click() 
#  def action(self,book): 
#   app = book.Sheets.item["wci_capture"]   
#   Delay(3000) 
#   file_system_utils.create_folder("C:\\TC_Logs") 
#   if Sys.Browser("iexplore").Page(self.testConfig['ebiz']['webCenCapUrl']+"*").Alert.Exists: 
#     Sys.Browser("iexplore").Page(self.testConfig['ebiz']['webCenCapUrl']+"*").Alert.Button("OK").Click() 
#     Delay(2000) 
#   self.wait_until_page_loaded() 
#   if Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).Tab("WebCenter Capture - Internet Explorer").Window("Shell DocObject View", "", 1).Window("Internet Explorer_Server", "", 1).Window("Java Plug-in Control Window", "", 1).AWTObject("PluginEmbeddedFrame", "").SwingObject("RMCApplet", "", 0).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("FormManagerPanel", "", 0).SwingObject("JPanel", "", 0).SwingObject("ExistingSessionPanel", "", 0).SwingObject("RoundedCornerPanel", "", 0).Exists: 
#     Sys.Browser("iexplore").BrowserWindow(0).Keys("[Enter]") 
#     Delay(2000) 
#    Check security warning window exists 
#   security_wnd=Sys.Browser("iexplore").WaitSwingObject("JDialog", "Security Warning", -1, 1,20000)   
#   if security_wnd.Exists: 
#     Sys.Browser("iexplore").SwingObject("JDialog", "Security Warning", -1, 1).FindChild("AWTComponentAccessibleName","I accept the risk and want to run this application.",30).Click() 
#     Sys.Browser("iexplore").SwingObject("JDialog", "Security Warning", -1, 1).Keys("[Enter]") 
#   sign_out_link=self.page.FindChildEx("JavaClassName","BatchEditForm$30",30,True,90000) 
#   while not sign_out_link.Exists: 
#     Delay(2000) 
#     sign_out_link=self.page.Find("JavaClassName","BatchEditForm$30",30)    
#   Set the location to ATC 
#   Sys.HighlightObject(Sys.Browser("iexplore").FindChildEx("JavaClassName","VetoableComboBox",30,True,60000)) 
#   Sys.Browser("iexplore").FindChildEx("JavaClassName","VetoableComboBox",30,True,60000).Keys("ATC")    
#   capture_link=self.page.FindChildEx("AWTComponentAccessibleName","Capture",30,True,60000) 
#   capture_link.Click() 
#   Delay(3000) 
#   self.log_message_web("Click Capture Successful") 
#   jProcess=Sys.Process("java") 
#   imp_dlg_wnd=jProcess.WaitSwingObject("ImportOptionDialog", "Import", -1, 1,3000)       
#   imp_dlg_wnd.FindChild("AWTComponentAccessibleName","OK",20).Click() 
#   Delay(3000) 
#   file_import_wnd=jBrowser.WaitSwingObject("FileImportDialog", "Select files to import", -1, 1,10000) 
#    Updated the below and replaced with different properties - Uday 
#   jBrowser.SwingObject("FileImportDialog", "Select files to import", -1, 1).Find("AWTComponentAccessibleName","Look In:",40).ClickItem("This PC") 
#   Delay(1000) 
#   jBrowser.SwingObject("FileImportDialog", "Select files to import", -1, 1).Find("AWTComponentAccessibleName","Files List",40).DblClickItemXY("*(C:)", 1, 1) 
#   Delay(1000)   
#   jBrowser.SwingObject("FileImportDialog", "Select files to import", -1, 1).Find("AWTComponentAccessibleName","Files List",40).DblClickItemXY("TC_Logs", 1, 1) 
#   Delay(1000) 
# #  po_filename=app.Cells.item[rowno,11] 
#   jBrowser.SwingObject("FileImportDialog", "Select files to import", -1, 1).Find("AWTComponentAccessibleName","Files List",40).ClickItemXY("SKM_C55817031316340.pdf", 1, 1) 
#   jBrowser.SwingObject("FileImportDialog", "Select files to import", -1, 1).Find(["AWTComponentAccessibleName","JavaClassName"],["File name:","SynthFileChooserUIImpl$3"],40).SetText("C:\TC_Logs\SKM_C55817031316340.pdf") 
#   Delay(1000) 
#   jBrowser.SwingObject("FileImportDialog", "Select files to import", -1, 1).Find(["AWTComponentAccessibleName","JavaClassName"],["File name:","SynthFileChooserUIImpl$3"],40).Click() 
#   file_import_wnd.Keys("[Enter]") 
#   self.wait_until_page_loaded()   
#   Delay(12000) 
#    get batch name and write back to excel 
#   batch_name=Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).FindChild("AWTComponentAccessibleName","Batch Name:",40).wText
#   app.Cells.item[2,2]=VarToStr(batch_name) 
#   date_time=Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).FindChild("AWTComponentAccessibleName","Date/Time Created:",40).wText 
#   Sys.Browser("iexplore").Page(self.testConfig['ebiz']['webCenCapUrl']+"*").Find("JavaClassName","BatchEditForm$30",30).Keys("[Right][Right]") 
#   Sys.Browser("iexplore").Page(self.testConfig['ebiz']['webCenCapUrl']+"*").Find("JavaClassName","BatchEditForm$30",30).Keys("[Down]") 
#   cnt=Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).FindAllChildren("JavaClassName","JSplitPane",60) 
#   self.log_message_web("PrintLocal: "+VarToStr(combo_list[3].wText)) 
#   self.log_message_web("AdvanceCharge: "+VarToStr(combo_list[2].wText)) 
#   self.log_message_web("BatchType: "+VarToStr(combo_list[1].wText)) 
#   self.log_message_web("LockBatch: "+VarToStr(combo_list[0].wText)) 
#   Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Tab", "", 1).FindChild("AWTComponentAccessibleName","Release",40).Click() 
#   Delay(16000) 
#   self.log_message_web("Click 'Release' button successful") 
#   
def sample(): 
   self.page.FindChildEx("JavaClassName","VetoableComboBox",30,True,60000).Click() 
   Sys.HighlightObject(Sys.Browser("iexplore").FindChildEx("AWTComponentAccessibleName","Capture",30,True,60000)) 
   Sys.Browser("iexplore").FindChildEx("AWTComponentAccessibleName","Capture",30,True,60000).Keys("![Tab]") 
   #Sys.Keys("[Down]") 
   Sys.HighlightObject(Sys.Browser("iexplore").FindChildEx("JavaClassName","VetoableComboBox",30,True,60000)) 
   Sys.Browser("iexplore").FindChildEx("JavaClassName","VetoableComboBox",30,True,60000).Keys("001") 
   Sys.Browser("iexplore", 2).BrowserWindow(0).Window("Frame Tab", "", 1).Tab("WebCenter Capture - Internet Explorer").Window("Shell DocObject View", "", 1).Window("Internet Explorer_Server", "", 1).Window("Java Plug-in Control Window", "", 1).AWTObject("PluginEmbeddedFrame", "").SwingObject("RMCApplet", "", 0).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("FormManagerPanel", "", 0).SwingObject("JPanel", "", 0).SwingObject("BatchEditForm", "", 0).SwingObject("JSplitPane", "", 0).SwingObject("JPanel", "", 0).SwingObject("JSplitPane", "", 0).SwingObject("JPanel", "", 1).SwingObject("JToolBar", "", 0).SwingObject("VetoableComboBox", "", 0) 
   Sys.HighlightObject(Sys.Browser("iexplore", 2)) 
   jFrame=Sys.Process("jp2launcher").WaitSwingObject("JFrame", "Oracle Applications*", -1,1,90000) 
   jBrowser=Sys.Browser("iexplore") 
   file_import_wnd=Sys.Browser("iexplore").WaitSwingObject("FileImportDialog", "Select files to import", -1, 1,10000) 
   jBrowser.SwingObject("FileImportDialog", "Select files to import", -1, 1).Find(["AWTComponentAccessibleName","JavaClassName"],["File name:","SynthFileChooserUIImpl$3"],40).Click() 
   prop_name=["AWTComponentAccessibleName","AWTComponentIndex"] 
   prop_value=["OK",1] 
   jBrowser.SwingObject("FileImportDialog", "Select files to import", -1, 1).Find(["AWTComponentAccessibleName","JavaClassName"],["File name:","SynthFileChooserUIImpl$3"],40).SetText("C:\TC_Logs\SKM_C55817031316340.pdf") 
   Sys.HighlightObject(file_import_wnd.FindChild(prop_name,prop_value,10)) 
   file_import_wnd.Keys("[Enter]") 
   file_import_wnd.FindChild(prop_name,prop_value,10).Click()  
   file_import_wnd.FindChild(prop_name,prop_value,10).Keys("[Enter]") 
    
    
