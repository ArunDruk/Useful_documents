﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils

#This testcase is to submit CAI AP Invoice Validation & Approval Request Set and getting journal batch name from the output files

class tc97921cai_ap_invoice_validation_apprvl_reqset(Ebiz):

 def login(self):
    self.login_user="ctucker"
    super().login()
 
 op_log_path="C:\\TC_Logs"
 
 def action(self,book): 
 
    Log.Message("Inside action...") 
    self.page.WaitProperty("contentText","CAI "+self.oper_unit+" AP INVOICE PROCESSING",6000)
#    cai_ap_invpro_link=self.page.Find("contentText","CAI "+self.oper_unit+" AP INVOICE PROCESSING",30)
#    self.verify_aqobject_chkproperty(cai_ap_invpro_link,"contentText",cmpIn,"CAI "+self.oper_unit+" AP INVOICE PROCESSING")
#    cai_ap_invpro_link.Click() 
    web_utils.clk_fldr_link_by_xpath(self.page,"//a[text()='CAI "+self.oper_unit+" AP INVOICE PROCESSING']")
    self.log_message_web("Click 'CAI "+self.oper_unit+" AP INVOICE PROCESSING' - Successful")
    delay(1000)
    cai_inv_ent_link=self.page.Find("contentText","Invoices",30)
    self.verify_aqobject_chkproperty(cai_inv_ent_link,"contentText",cmpIn,"Invoices")
    cai_inv_ent_link.Click() 
    self.log_message_web("Click 'Invoices' - Successful")
    delay(1000)  
    self.page.Find("contentText","Entry",30).Click()
    self.log_message_web("Click 'Entry' - Successful")
    delay(1000)
    self.page.Find("namePropStr","RF.jsp?function_id=1026&resp_id=50816&resp_appl_id=200&security_group_id=0&lang_code=US')",30).Click()
    delay(5000) 
    jFrame=self.initializeJFrame()
    delay(3000)
#    jFrame.Keys("~o")
#    delay(2000)
    jFrame.Keys("[F4]")
    delay(3000)
    jFrame.Keys("~v")
    delay(1000)
    jFrame.Keys("r")
    delay(1000)
    jFrame.Keys("~n")
    delay(1000)
    jFrame.Keys("~s")
    delay(1000)
    jFrame.Keys("~o")
    delay(1000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit Request Set","ExtendedFrame"]
    par_form=jFrame.FindChild(prop,val,60)
    par_form.Find("AWTComponentAccessibleName","Request Set RequiredList of Values",30).Keys("CAI AP Invoice Validation & Approval Request Set")
    delay(1000)
    jFrame.Keys("[Tab]")
    
    par=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Parameters","16"]
    par_form=jFrame.FindChild(par,val,60)
    par_form.Find("AWTComponentIndex","16",10).Click()
    delay(1000)
    jFrame.Keys("[Tab]")
    delay(1000)
    jFrame.Keys("[Tab]")
    delay(1000)
    jFrame.Keys(aqConvert.DateTimeToFormatStr(aqDateTime.Today(),"%b/%d/%Y"))
    delay(1000)
    jFrame.Keys("~o")
    delay(2000)
    jFrame.Keys("~m")
    delay(2000)
    self.log_message_oracle_form(jFrame,"CAI AP Invoice Validation & Approval Request Set Submitted")         
    RequestID = ''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit())
    Log.Message("Request ID " + aqConvert.VarToStr(RequestID))
    jFrame.Keys("~n")
    delay(2000)
    jFrame.Keys("[F4]")
    delay(1000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000)
    
# Gathering Request ID and Output File for the "Invoice Validation Program"   
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChild(prop,val,30)  
    job_name="false"
    phase="false"
    i=20
    while (job_name!="Invoice Validation") or (phase!="Completed") :
     prop=["AWTComponentAccessibleName","AWTComponentIndex"]
     val=["Name",i]
     job_name=req_form.Find(prop,val,10).wText
     prop=["AWTComponentAccessibleName","AWTComponentIndex"]
     val=["Phase",i+20]
     phase=req_form.Find(prop,val,10).wText          
     i+=1     
     if i==29:
       req_form.keys("~r") 
       i=20
    self.log_message_oracle_form(req_form,"Job Name "+aqConvert.VarToStr(job_name)+" submitted")
    self.log_message_oracle_form(req_form,"Phase Code of Invoice Validation Program is "+aqConvert.VarToStr(phase))   
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Request ID",i-11]
    ppf_req_id=req_form.Find(prop,val,10).wText
    self.log_message_oracle_form(req_form,"Request ID of Invoice Validation Program is  "+aqConvert.VarToStr(ppf_req_id)) 
    jFrame.Keys("[F4]")  
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~s")
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Requests","ExtendedFrame"]
    find_req_form=jFrame.FindChild(prop,val,10)
    find_req_form.Find("AWTComponentAccessibleName","Request ID",10).Click()
    Delay(1000)
    find_req_form.Find("AWTComponentAccessibleName","Request ID",10).Keys(ppf_req_id)
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000)
    jFrame.Keys("~p")
    Delay(2000)
    log_page=Sys.Browser("iexplore").Page(self.testConfig['ebiz']['url']+"/OA_CGI/FNDWRR.*")
    log_page.Click()
    log_page.TextNode(0).Click()
    Delay(1000)
    log_page.Keys("~f")
    Delay(1000)
    log_page.Keys("a")
    Delay(1000)  
    file_system_utils.create_folder(self.op_log_path)             
    log_path=self.op_log_path+"\\Invoice Validation Program Output Is Attached_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
    Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
    Delay(1000)
    Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
    Delay(1000)
    Log.Enabled=True
    Log.File(log_path, "Invoice Validation Program Output File Attached")
    Log.Enabled=False        
    Delay(1000)
    self.browser.page("*").Close()
    Delay(1000)
    
    jFrame.Click()
    Delay(2000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000)

# Gathering Request ID and Output File for the "Create Accounting Program"  
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=Sys.Browser("iexplore").SwingObject("JBufferedFrame", "Oracle Applications*", -1).FindChild(prop,val,30)  
    job_name_parent="false"
    phase_parent="false"
    i=20
    while (job_name_parent!="Create Accounting") or (phase_parent!="Completed") :
     prop=["AWTComponentAccessibleName","AWTComponentIndex"]
     val=["Name",i]
     job_name_parent=req_form.Find(prop,val,10).wText
     prop=["AWTComponentAccessibleName","AWTComponentIndex"]
     val=["Phase",i+20]
     phase_parent=req_form.Find(prop,val,10).wText          
     i+=1     
     if i==28:
       req_form.keys("~r") 
       i=20
    self.log_message_oracle_form(req_form,"Job Name "+aqConvert.VarToStr(job_name_parent)+" submitted")
    self.log_message_oracle_form(req_form,"Phase code of Create Accounting Program is "+aqConvert.VarToStr(phase_parent))   
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Request ID",i-11]
    req_id_parent=req_form.Find(prop,val,10).wText
    self.log_message_oracle_form(req_form,"Request ID of Create Accounting Program is "+aqConvert.VarToStr(req_id_parent))
    jFrame.Keys("[F4]")
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~s")
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Requests","ExtendedFrame"]
    jFrame=Sys.Browser("iexplore").SwingObject("JBufferedFrame", "*", -1, 1)
    find_req_form=jFrame.FindChild(prop,val,10)
    find_req_form.Find("AWTComponentAccessibleName","Request ID",10).Click()
    Delay(1000)
    find_req_form.Find("AWTComponentAccessibleName","Request ID",10).Keys(req_id_parent)
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000)
    jFrame.Keys("~g")
    Delay(2000)
    log_page=Sys.Browser("iexplore").Page(self.testConfig['ebiz']['url']+"/OA_CGI/FNDWRR.*")
    log_page.Click()
    log_page.TextNode(0).Click()
    Delay(1000)
    log_page.Keys("~f")
    Delay(1000)
    log_page.Keys("a")
    Delay(1000)  
    file_system_utils.create_folder(self.op_log_path)             
    log_path=self.op_log_path+"\\Create Accounting Program Log File Is Attached_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
    Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
    Delay(1000)
    Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
    Delay(1000)
    Log.Enabled=True
    Log.File(log_path, "Create Accounting Program Log File Attached")
    Log.Enabled=False        
    Delay(1000)
    self.browser.page("*").Close()
    Delay(1000)
    
    jFrame.Click()
    Delay(2000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000)

# Gathering Request ID and Output File for the "Invoice Approval Workflow Program"  
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=Sys.Browser("iexplore").SwingObject("JBufferedFrame", "Oracle Applications*", -1).FindChild(prop,val,30)  
    job_name_parent="false"
    phase_parent="false"
    i=20
    while (job_name_parent!="Invoice Approval Workflow") or (phase_parent!="Completed") :
     prop=["AWTComponentAccessibleName","AWTComponentIndex"]
     val=["Name",i]
     job_name_parent=req_form.Find(prop,val,10).wText
     prop=["AWTComponentAccessibleName","AWTComponentIndex"]
     val=["Phase",i+20]
     phase_parent=req_form.Find(prop,val,10).wText          
     i+=1     
     if i==24:
       req_form.keys("~r") 
       i=20
    self.log_message_oracle_form(req_form,"Job Name "+aqConvert.VarToStr(job_name_parent)+" submitted")
    self.log_message_oracle_form(req_form,"Phase code of Invoice Approval Workflow Program is "+aqConvert.VarToStr(phase_parent))   
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Request ID",i-11]
    req_id_invapprv=req_form.Find(prop,val,10).wText
    self.log_message_oracle_form(req_form,"Request ID of Invoice Approval Workflow Program is "+aqConvert.VarToStr(req_id_invapprv))
    jFrame.Keys("[F4]")
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~s")
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Requests","ExtendedFrame"]
    jFrame=Sys.Browser("iexplore").SwingObject("JBufferedFrame", "*", -1, 1)
    find_req_form=jFrame.FindChild(prop,val,10)
    find_req_form.Find("AWTComponentAccessibleName","Request ID",10).Click()
    Delay(1000)
    find_req_form.Find("AWTComponentAccessibleName","Request ID",10).Keys(req_id_invapprv)
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000)
    jFrame.Keys("~p")
    Delay(2000)
    log_page=Sys.Browser("iexplore").Page(self.testConfig['ebiz']['url']+"/OA_CGI/FNDWRR.*")
    log_page.Click()
    log_page.TextNode(0).Click()
    Delay(1000)
    log_page.Keys("~f")
    Delay(1000)
    log_page.Keys("a")
    Delay(1000)  
    file_system_utils.create_folder(self.op_log_path)             
    log_path=self.op_log_path+"\\Invoice Approval Workflow Program Output Is Attached_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
    Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
    Delay(1000)
    Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
    Delay(1000)
    Log.Enabled=True
    Log.File(log_path, "Invoice Approval Workflow Program Output File Attached")
    Log.Enabled=False        
    Delay(1000)
    self.browser.page("*").Close()
    Delay(1000)
    
    jFrame.Click()
    Delay(2000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000)

# Gathering Request ID and Output File for the "Posting: Single Ledger program"  
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=Sys.Browser("iexplore").SwingObject("JBufferedFrame", "Oracle Applications*", -1).FindChild(prop,val,30)  
    job_name_parent="false"
    phase_parent="false"
    i=20
    while (job_name_parent!="Posting: Single Ledger") or (phase_parent!="Completed") :
     prop=["AWTComponentAccessibleName","AWTComponentIndex"]
     val=["Name",i]
     job_name_parent=req_form.Find(prop,val,10).wText
     prop=["AWTComponentAccessibleName","AWTComponentIndex"]
     val=["Phase",i+20]
     phase_parent=req_form.Find(prop,val,10).wText          
     i+=1     
     if i==27:
       req_form.keys("~r") 
       i=20
    self.log_message_oracle_form(req_form,"Job Name "+aqConvert.VarToStr(job_name_parent)+" submitted")
    self.log_message_oracle_form(req_form,"Phase code of Posting: Single Ledger program is "+aqConvert.VarToStr(phase_parent))   
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Request ID",i-11]
    req_id_psl=req_form.Find(prop,val,10).wText
    self.log_message_oracle_form(req_form,"Request ID of Posting: Single Ledger program is "+aqConvert.VarToStr(req_id_psl))
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~s")
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Requests","ExtendedFrame"]
    jFrame=Sys.Browser("iexplore").SwingObject("JBufferedFrame", "*", -1, 1)
    find_req_form=jFrame.FindChild(prop,val,10)
    find_req_form.Find("AWTComponentAccessibleName","Request ID",10).Click()
    Delay(2000)
    find_req_form.Find("AWTComponentAccessibleName","Request ID",10).Keys(req_id_psl)
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000)
    jFrame.Keys("~p")
    Delay(4000)
    log_page=Sys.Browser("iexplore").Page(self.testConfig['ebiz']['url']+"/OA_CGI/FNDWRR.*")
    log_page.Click()
    log_page.TextNode(0).Click()
    Delay(1000)
    log_page.Keys("~f")
    Delay(1000)
    log_page.Keys("a")
    Delay(1000)  
    file_system_utils.create_folder(self.op_log_path)             
    log_path=self.op_log_path+"\\Posting_Single Ledger program Log File Is Attached_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
    Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
    Delay(1000)
    Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
    Delay(1000)
    Log.Enabled=True
    Log.File(log_path, "Posting:Single Ledger Program Log File Attached")
    Log.Enabled=False        
    Delay(1000)
    dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
    user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
    pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
    dbhelper.verify_oracle_concurrent_job_status(dsn,user_id,pwd,RequestID)
#    dbhelper.verify_oracle_concurrent_job_status(RequestID) 
    self.browser.page("*").Close()
    Delay(1000)
    jFrame.Click()
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~o")
    Delay(1000)
    self.browser.page("*").Close() 

    
