﻿import gvar

### In this method objects for below pages have been captured ###

#PROJECT > HOME page

def prj_home_page_tab():
  prop_names = ["innerHTML","ObjectType"]
  prop_values = ["Home: *","TextNode"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
  

def printable_page_button():
  printable_page_button = gvar.dataprep['page'].EvaluateXpath("//div[@id='p_SwanPageLayout']//button[@title='Printable Page']")[0]
  return printable_page_button
  

def go_button():
  go_button = gvar.dataprep['page'].EvaluateXpath("//table[@id='ShortcutDropListTable']//button[@title='Go']")[0]
  return go_button


def cost_inspect_mds_contents_button():
  cost_inspect_mds_contents_button = gvar.dataprep['page'].EvaluateXpath("//table[@id='_oracle_apps_pa_project_webui_PjiConfigCostDefSingleColumn1']//button[@id='inspectSavedSearchImage_PjiConfigCostTable']")
  return cost_inspect_mds_contents_button 


def worklist_inspect_mds_contents_button():
  worklist_inspect_mds_contents_button  = gvar.dataprep['page'].EvaluateXpath("//table[@id='_oracle_apps_pa_progress_webui_WorklistRN2']//button[@id='inspectSavedSearchImage_WorklistQuery']")
  return worklist_inspect_mds_contents_button 


def notifications_inspect_mds_contents_button():
  notifications_inspect_mds_contents_button = gvar.dataprep['page'].EvaluateXpath("//table[@id='_oracle_apps_pa_workflow_webui_NotificationHeaderRN5']//button[@id='inspectSavedSearchImage_NotificationTable']")
  return notifications_inspect_mds_contents_button


def worklist_full_list_button():
  worklist_full_list_button = gvar.dataprep['page'].EvaluateXpath("//table[@id='ButtonLayout']//button[@id='FullList']")
  return worklist_full_list_button

  
def open_notifications_full_list_button():
  open_notifications_full_list_button = gvar.dataprep['page'].EvaluateXpath("//table[@id='_oracle_apps_pa_workflow_webui_NotificationHeaderRN5']//button[@title='Full List']")
  return open_notifications_full_list_button
