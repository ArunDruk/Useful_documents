﻿from gvar import dataprep as DATAPREP 

def post_payment_method_payload():
   
   payload = {
         "customerDetails" : {
         "soldToCustomerNumber" : DATAPREP['buyer'],
         "billToCustomerNumber" : "",
         "includeBasicFloorplans" : "FALSE",
         "vehicleAttributes" : [ {
         "vehicleReferenceId" : "7037088",
         "vehicleYear" : "2018",
         "maxOdometerReading" : "120",
         "asIsIndicator" : "FALSE",
         "totalVehicleDebitAmount" : "1000",
         "salvageUnitIndicator" : "FALSE",
         "salesChannel" : "RMS",
         "vehicleType" : "V",
         "saleType" : "O",
         "hondaFloorplanThresholdFlag" : "TRUE",
         "sellerAccount" : ""
         }
         ]
         }
   }

   Log.Message(payload['customerDetails']['soldToCustomerNumber'])      
   return payload 

     
def __get_current_time_stampe_with_timezone():
     from datetime import datetime
     return datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%f")

def __get_current_date():
     from datetime import datetime   
     return datetime.now().strftime("%Y-%m-%d")
     
def __get_current_year():
   import datetime
   return (datetime.datetime.now().year)
   
def __get_current_week():
     import datetime 
     return (str(datetime.date.today().isocalendar()[1]))
