﻿from ebiz import *
import web_utils
import dbhelper
import file_system_utils


class tc97777_pacostcollection_employeeandexpense_webadi_ete23(Ebiz):

 op_log_path ="C:\\TC_Logs"

 def login(self):
   self.login_user='naggarwal'
   super().login()
   
 def action(self,book): 
   app = book.Sheets.item["pacostcollection"]
   
   #Login to Oracle
   prop_names = ("innerHTML")
   prop_values = ("Oracle Applications Home Page")
   obj =  Sys.Browser("iexplore").Page("*").FindChild(prop_names,prop_values,30)
   self.log_message_web("Navigation to Oracle Home page Successful")
   
   web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" PA PROJECT CONTROLS')]")
   self.log_message_web("Click 'CAI "+self.oper_unit+" PA PROJECT CONTROLS' - Successful")
   
   Delay(3000)
   self.page.Find("contentText","ADI",30).Click()
   self.log_message_web("Click 'ADI' - Successful")
   
   Delay(2000)
   web_utils.clk_link_by_xpath(self.page,"//div[contains(text(),'Adjustments')]")
   self.log_message_web("Click 'Adjustments' - Successful")
   
   self.wait_until_page_loaded()
   web_utils.clk_link_by_xpath(self.page,"//div[@id='p_SwanPageLayout']//button[@id='createDocument']")

   Log.Enabled=True
   Log.Message("Navigation Successful: CAI "+self.oper_unit+" PA PROJECT CONTROLS >ADI >ADI – Adjustments")
   Log.Enabled=False
   Delay(8000)
   self.page.Keys("~o")    
   Delay(8000)   

   ### Below code is used to close the sign-in window of Excel sheet   

   web_utils.close_excel_sign_in_window()
   delay(2000)
   
#   sign_in_excel_obj=Sys.Process("EXCEL",2).Window("NUIDialog", "Sign in to set up Office", 1)
#   delay(2000)  
#   if (Sys.Process("EXCEL",2).Window("NUIDialog", "Sign in to set up Office", 1).Exists):
#    delay(2000)
#    Sys.HighlightObject(sign_in_excel_obj)
#    Log.Enabled=True
#    wnd = Sys.Desktop.ActiveWindow()
#    Log.Picture(wnd, "'Excel Sign-in Window'",wnd.FullName)
#    Sys.Process("EXCEL",2).Window("NUIDialog", "Sign in to set up Office", 1).Close()    
#    Log.Message("Successfully Closed the Microsoft Excel Sign-in Window")
#    Log.Enabled=False
   
   xl_window=Sys.Process("EXCEL",2).Window("XLMAIN", "Projects - Transaction Import*", 1).Window("XLDESK", "", 1).Window("EXCEL*", "Projects - Transaction Import*", 1)           
   if aqDateTime.GetDayOfWeek(aqDateTime.Today())<=6:
    FridayDate = aqDateTime.AddDays(aqDateTime.Today(), -aqDateTime.GetDayOfWeek(aqDateTime.Today())+6)
   elif aqDateTime.GetDayOfWeek(aqDateTime.Today())==7:
    FridayDate = aqDateTime.AddDays(aqDateTime.Today(), -aqDateTime.GetDayOfWeek(aqDateTime.Today())+13)
    
   Delay(2000)
   xl_window.Keys("^g")
   goto_window = Sys.Process("EXCEL", 2).Window("bosa_sdm_XL9", "Go To", 1)
   reference = Sys.Process("EXCEL", 2).Window("bosa_sdm_XL9", "Go To", 1).Window("EDTBX", "", 1)
   reference.Click()
   Delay(2000)
   reference.Keys("[BS]")
   Delay(2000)
   reference.Keys("E9")
   Delay(2000)
   reference.Keys("[Enter]")
   
   vvalue="COST"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d%b%H%M")
   xl_window.Keys(vvalue)
   Delay(2000)
   xl_window.Keys("[Tab]")
   Delay(1000)
   xl_window.Keys("[Tab]")
   
   xl_window.Keys(aqConvert.DateTimeToFormatStr(aqDateTime.Today(),"%d-%b-%Y"))
   Delay(1000)
   xl_window.Keys("[Tab]")
   
   xl_window.Keys(aqConvert.DateTimeToFormatStr(aqDateTime.Today(),"%d-%b-%Y"))
   Delay(1000)
   xl_window.Keys("[Tab]")
      
   xl_window.Keys(aqConvert.DateTimeToFormatStr(FridayDate,"%d-%b-%Y"))
   Delay(1000)
   xl_window.Keys("[Tab]")
   
   if (aqConvert.VarToStr(app.Cells.Item[2,9]) == "oci_stage"):
    xl_window.Keys(VarToStr(app.Cells.Item[2,1]))
   elif (aqConvert.VarToStr(app.Cells.Item[2,9]) == "oci_test"):
    xl_window.Keys(VarToStr(app.Cells.Item[2,10]))
    
   Delay(1000)
   xl_window.Keys("[Tab]")
   
   xl_window.Keys("1.0")
   Delay(1000)
   xl_window.Keys("[Tab]")
   
   xl_window.Keys(app.Cells.Item[2,3])
   Delay(1000)
   xl_window.Keys("[Tab]")
   
   xl_window.Keys(app.Cells.Item[2,4])
   Delay(1000)
   xl_window.Keys("[Tab]")
   
   xl_window.Keys(VarToStr(app.Cells.Item[2,5]))
   Delay(1000)
   xl_window.Keys("[Tab]")
   
   xl_window.Keys(VarToStr(app.Cells.Item[2,6]))
   Delay(1000)
   xl_window.Keys("[Tab]")
   
   xl_window.Keys(VarToStr(app.Cells.Item[2,7]))
   Delay(1000)
   xl_window.Keys("[Tab][Tab][Tab]")
   
   #Original Trans Ref
   xl_window.Keys(VarToStr(app.Cells.Item[2,8]))
   Delay(1000)
   xl_window.Keys("[Tab]")
   
   Log.Enabled=True
   wnd = Sys.Desktop.ActiveWindow()
   Log.Picture(wnd, "'PA Cost Upload' template attached",wnd.FullName)
   Log.Enabled=False

   excel_toolbar = Sys.Process("EXCEL", 2).Window("XLMAIN", "Projects - Transaction Import*", 1).Window("EXCEL2", "", 2).Window("MsoCommandBar", "Ribbon", 1).Window("MsoWorkPane", "Ribbon", 1).Window("NUIPane", "", 1).Window("NetUIHWND", "", 1)
   OCR.Recognize(excel_toolbar).BlockByText("Oracle").Click()
   Delay(5000)
   OCR.Recognize(excel_toolbar).BlockByText("Upload").Click()
   Delay(5000)
  
   upload_form = Sys.Process("EXCEL", 2).WaitWindow("ThunderDFrame", "Upload Parameters", 1,20000)
   props = ["ObjectLabel", "ObjectType"]
   val = ["Upload", "Button"]
   upload_button = upload_form.FindChild(props,val,20)
   self.log_message_oracle_excel_popup(upload_form,"PA Cost Upload Parameters")
   upload_button.Click()
   Delay(30000)
   
   if upload_form.Exists:
     if upload_form.Find("ObjectIdentifier","errorl_gif",40).Exists:
       self.log_message_oracle_excel_popup(upload_form,"PA Cost Upload Failed!!")
       Log.Error("PA Cost Upload Failed.") 
       Runner.Stop()                 
     else:
       Log.Enabled=True
       wnd = Sys.Desktop.ActiveWindow()
       Log.Picture(wnd, "'PA Cost Upload Passed'",wnd.FullName)
       Log.Enabled=False
   
   props = ["idStr","ObjectIdentifier","ObjectType"]
   val = ["BneAsyncUploadPageConfirmation","BneAsyncUploadPageConfirmation","Form"]
   text_window = upload_form.FindChild(props,val,20)
   conf_msg = text_window.contentText
   self.log_message_oracle_excel_popup(upload_form,"PA Cost Collection Upload Confirmation")
   self.log_message_oracle_excel_popup(upload_form,"'PA Cost Upload' Confirmation Message:- "+aqConvert.VarToStr(conf_msg))
   Delay(1000) 
   
   RequestId = ''.join(x for x in (conf_msg.strip().split('\n'))[1] if x.isdigit())
   Log.Enabled=True
   Log.Message("Data Entered in Web ADI and uploaded Successfully; RequestID generated: "+RequestId)
   Log.Enabled=False
   self.req_id=RequestId
   
   props = ["idStr","ObjectIdentifier","ObjectType"]
   val = ["BNE:CANCEL","CANCEL","Button"]
   cancel_button = upload_form.FindChild(props,val,20)
   cancel_button.Click()
   
   Delay(4000)
   xl_window.Keys("~[F4]")
   Delay(7000)
   xl_window.Keys("~n")
   Delay(2000)   
   
   self.page.Find("contentText","Projects",30).Click()
   Delay(3000)
   jFrame=self.initializeJFrame() 
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Find Projects","ExtendedFrame"]
   FindProjects_Frame=jFrame.FindChildEx(prop,val,60,True,40000)
   FindProjects_Frame.click() 
   Delay(3000)  
   
   menu_bar=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWMenuBar", "", 0)
   OCR.Recognize(menu_bar).BlockByText("View").Click()
   Delay(1000)

   view_menu=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("LWPopupMenu", "", 0)
   OCR.Recognize(view_menu).BlockByText("Requests").Click()
   
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Find Requests","ExtendedFrame"]
   find_req_form=jFrame.FindChild(prop,val,30)
   Delay(3000)

   jFrame.Keys("[Right]")
   Delay(2000) 
   jFrame.Keys("[Tab]")

   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Request ID","VTextField"]
   find_req_form.FindChild(prop,val,60).Click()
   find_req_form.FindChild(prop,val,60).SetText(RequestId)
   self.log_message_oracle_form(jFrame,"Finding 'PA Cost Upload' RequestID in Find Request form ")
   
   
   jFrame.Keys("~i")
   Delay(2000)
   
   #find request form identification
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Requests","ExtendedFrame"]
   req_form=jFrame.FindChildEx(prop,val,30,True,90000)   
   
   #verifying for request completion
   dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
   user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
   pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
   dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,RequestId)
   
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val = ["Refresh Data alt R","Button"]
   req_form.FindChild(prop,val,2000).Click()
   
   #Click on output button  
   prop = ["AWTComponentAccessibleName","JavaClassName"]
   val = ["View Output alt p","Button"]
   req_form.FindChild(prop,val,2000).Click()
   Delay(3000)
   
   output_page=Sys.Browser("iexplore").Page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
   output_page.Click()
   Delay(3000)
   
   #Save the output file and close the window
   output_page.Keys("~f")
   output_page.Keys("a")
   Delay(3000)

   file_system_utils.create_folder(self.op_log_path)             
   log_path=self.op_log_path+"\\Transaction Import_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
   Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
   Delay(1000)
   Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
   Delay(1000)
   Log.Enabled=True
   Log.File(log_path, "'PRC Transaction Import' Output File Attached")
   Log.Enabled=False     
   Sys.Browser("iexplore").Page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close() 
   Delay(2000)
   
   Delay(1000)
   req_form.Close()
   Delay(1000)
   FindProjects_Frame.Close()
   Delay(1000)

   navigator_form = Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("ExtendedFrame", "Navigator*", 4).AWTObject("LWComponent", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("FScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("DrawnPanel", "", 0).AWTObject("FormsTabPanel", "", 0).AWTObject("TabPanelSheet", "", 0).AWTObject("FScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("DrawnPanel", "", 0).AWTObject("VTList", "Function List", 0).AWTObject("ScrollBox", "", 0).AWTObject("LWDataSourceList$Content", "", 0)
   OCR.Recognize(navigator_form).BlockByText("Expenditures").DblClick()
   Delay(1000)
   OCR.Recognize(navigator_form).BlockByText("Expenditure Inquiry").DblClick()   
   Delay(2000)
   OCR.Recognize(navigator_form).BlockByText("Project",spSmallest).DblClick()   
   Delay(2000)
   self.log_message_oracle_form(jFrame,"Navigation Successful: Expenditures > Expenditure Inquiry > Project")
   
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Find Project Expenditure Items","ExtendedFrame"]
   Find_ProjExpItems_Frame=jFrame.FindChildEx(prop,val,60,True,40000)
  
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Project NumberList of Values","VTextField"]
   Find_ProjExpItems_Frame.FindChild(prop,val,60).Click()
   delay(1000)
   
   if (aqConvert.VarToStr(app.Cells.Item[2,9]) == "oci_stage"):
     Find_ProjExpItems_Frame.FindChild(prop,val,60).SetText(VarToStr(app.Cells.Item[2,1]))
   elif (aqConvert.VarToStr(app.Cells.Item[2,9]) == "oci_test"):
      Find_ProjExpItems_Frame.FindChild(prop,val,60).SetText(VarToStr(app.Cells.Item[2,10]))
   
   delay(2000)        
   prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
   val=["Expenditure*","VTextField","3"]
   Find_ProjExpItems_Frame.FindChild(prop,val,60).Click()
   Find_ProjExpItems_Frame.FindChild(prop,val,60).SetText(vvalue)
   
   delay(3000)
   self.log_message_oracle_form(Find_ProjExpItems_Frame,"In 'Find Projext Expenditure items' form Search Criteria entered")
   self.log_message_oracle_form(Find_ProjExpItems_Frame,"In 'Find Projext Expenditure items' form Click 'Find' button next")
   props = ["AWTComponentAccessibleName","JavaClassName"]
   vals = ["Find alt i","Button"]
   Find_ProjExpItems_Frame.FindChild(props,vals,20).Click()
   Delay(1000)
   
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Project Expenditure Items","ExtendedFrame"]
   ProjExpItems_Frame=jFrame.FindChildEx(prop,val,60,True,20000)
   self.log_message_oracle_form(Find_ProjExpItems_Frame,"In 'Projext Expenditure items' form Click 'Run Request' button next")
   Delay(1000)
   
   props = ["AWTComponentAccessibleName","JavaClassName"]
   vals = ["Run Request... alt u","Button"]
   ProjExpItems_Frame.FindChild(props,vals,20).Click()
   Delay(1000)
   
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Run Project Streamline Requests","ExtendedFrame"]
   RunProjSteamlineRequest_Frame=jFrame.FindChildEx(prop,val,60,True,20000)
   Delay(1000)
   
   props = ["AWTComponentAccessibleName","JavaClassName"]
   vals = ["Distribute Labor Costs alt D","LWCheckbox"]
   RunProjSteamlineRequest_Frame.FindChild(props,vals,20).Click()
   Delay(1000)
   
   props = ["AWTComponentAccessibleName","JavaClassName"]
   vals = ["Distribute Usage and Miscellaneous Costs alt u","LWCheckbox"]
   RunProjSteamlineRequest_Frame.FindChild(props,vals,20).Click()
   Delay(1000)
   
   props = ["AWTComponentAccessibleName","JavaClassName"]
   vals = ["Interface Vendor Invoices from AP alt S","LWCheckbox"]
   RunProjSteamlineRequest_Frame.FindChild(props,vals,20).Click()
   Delay(1000)
   
   props = ["AWTComponentAccessibleName","JavaClassName"]
   vals = ["Distribute Vendor Invoice Adjustment Costs alt A","LWCheckbox"]
   RunProjSteamlineRequest_Frame.FindChild(props,vals,20).Click()
   Delay(1000)
   
   self.log_message_oracle_form(RunProjSteamlineRequest_Frame,"In 'Run Project Streamline Requests' form Project Number,Name & Streamline Processes entered")
   props = ["AWTComponentAccessibleName","JavaClassName"]
   vals = ["OK alt O","Button"]
   RunProjSteamlineRequest_Frame.FindChild(props,vals,20).Click()
   Delay(3000)
   
   menu_bar=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWMenuBar", "", 0)
   OCR.Recognize(menu_bar).BlockByText("View").Click()
   Delay(1000)

   view_menu=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("LWPopupMenu", "", 0)
   OCR.Recognize(view_menu).BlockByText("Requests").Click()
   
   jFrame.Keys("~i")
   Delay(2000) 
   
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Requests","ExtendedFrame"]
   req_form=jFrame.FindChild(prop,val,30)
   self.log_message_oracle_form(req_form,"Navigation Successful : View > Requests; Requests Window Opened")
   
   #Find Request Id of Parent
   srch_Parent_name = 'PRC: Submit Project Streamline Processes'
   for x in range(20,30):
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Name",x]
        Parent_name=req_form.Find(prop,val,10).wText     
        if (Parent_name==srch_Parent_name):
          prop=["AWTComponentAccessibleName","AWTComponentIndex"]
          val=["Request ID",x-10]
          Preqid=StrToInt(req_form.Find(prop,val,10).wText)
          if (Preqid > StrToInt(RequestId)):
            self.log_message_oracle_form(req_form,"'PRC: Submit Project Streamline Processes' Request ID" + VarToStr(Preqid))
            Delay(10000)
            props = ["AWTComponentAccessibleName","JavaClassName"]
            vals = ["Refresh Data alt R","Button"]
            req_form.FindChild(props,vals,20).Click() 
            form_utils.req_set_save_output(self,jFrame,req_form,"PRC: Distribute Usage and Miscellaneous Costs",Preqid)
            Sys.Browser("iexplore").Page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close() 
            break

   jFrame.Keys("[F4]")
   Delay(4000)
   jFrame.Keys("[F4]") 
   self.log_message_oracle_form( jFrame,"Switching Responsibility to 'CAI US PA JOB SCHEDULER' next")    
     
   #Switching Responsibility
   menu_bar=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWMenuBar", "", 0)
   OCR.Recognize(menu_bar).BlockByText("File").Click()
   Delay(1000)
   jFrame.Keys("w")
   Delay(2000)

   #Switiching responsibility form identification    
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Responsibilities","FWindow"]
   resp_form=jFrame.FindChildEx(prop,val,30,True,60000)
   
   #selecting the responsibility
   resp_form.Find("AWTComponentName","LWTextField*",10).Click() 
   resp_form.Find("AWTComponentName","LWTextField*",10).keys("CAI US PA JOB SCHEDULER")
   self.verify_aqobject_chkproperty(resp_form,"AWTComponentAccessibleName",cmpContains,"Responsibilities")   
   Delay(2000)
   
   val = ["Find ALT F","PushButton"]
   resp_form.FindChild(prop,val,20).Click()
   Delay(2000) 
   
   #Navigating to submit request
   jFrame.Keys("~o")
   self.log_message_oracle_form(jFrame,"'CAI US PA JOB SCHEDULER' launched successfully and Submit New Request next")
   Delay(2000)
   jFrame.Keys("~o")
   
   #Submitting Create Accounting Program
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Submit Request","ExtendedFrame"]
   submitrequest_form=jFrame.FindChildEx(prop,val,60,True,60000)
   name = submitrequest_form.Find("AWTComponentAccessibleName","Name RequiredList of Values",20)
   name.Click()
   name.SetText("PRC: Generate Cost Accounting Events")
   Delay(5000)
   jFrame.Keys("[Tab]")
   Delay(2000)
   self.log_message_oracle_form(jFrame,"Submitting 'PRC: Generate Cost Accounting Events' Program")
   
   #Entering Parameters
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Parameters","FlexWindow"]
   parameters_form=jFrame.FindChildEx(prop,val,60,True,60000)
   Delay(1000)
#   self.log_message_oracle_form(jFrame,"'PRC: Generate Cost Accounting Events' Program Parameters entered successfully")
   val = ["OK ALT O","FormButton"]
   parameters_form.FindChild(prop,val,60).Click()
   Delay(2000)
   Delay(1000)
   
   #submit
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Submit alt m","Button"]
   submitrequest_form.FindChild(prop,val,60).Click()
   self.log_message_oracle_form(jFrame,"'PRC: Generate Cost Accounting Events' job submitted")
   Delay(2000)
   
   val = ["Decision Request submitted*","ChoiceBox"]
   decision_box = jFrame.FindChildEx(prop,val,60,True,12000)
   RequestID = aqConvert.VarToStr(''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit()))
   self.log_message_oracle_form( jFrame,"'PRC: Generate Cost Accounting Events' program submitted successfully and Request ID is "+VarToStr(RequestID))
   
   jFrame.Keys("~n")
   Delay(2000)
   
   #Find requests
   OCR.Recognize(menu_bar).BlockByText("View").Click()
   Delay(1000)
   view_menu=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("LWPopupMenu", "", 0)
   OCR.Recognize(view_menu).BlockByText("Requests").Click()
   Delay(2000)
   jFrame.Keys("~i")
   Delay(2000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Requests","ExtendedFrame"]
   req_form=jFrame.FindChildEx(prop,val,30,True,90000)
   self.req_set_save_output(jFrame,req_form,"PRC: Generate Cost Accounting Events",RequestID)
   web_utils.close_additional_browsers()
   Delay(4000)
   jFrame.Keys("~w")
   Delay(2000)
   jFrame.Keys("2")
   Delay(2000)   
   Sys.HighlightObject(req_form)  
   Delay(2000)
   jFrame.Keys("[F4]")
   Delay(4000)
   jFrame.Keys("~o")
   Delay(4000)
   jFrame.Keys("~o")
   
   #Submitting Create Accounting Program
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Submit Request","ExtendedFrame"]
   submitrequest_form=jFrame.FindChildEx(prop,val,60,True,60000)
   Sys.HighlightObject(submitrequest_form) 
   name = submitrequest_form.Find("AWTComponentAccessibleName","Name RequiredList of Values",20)
   name.Click()
   name.SetText("PRC: Create Accounting")
   Delay(5000)
   jFrame.Keys("[Tab]")
   Delay(2000)
   self.log_message_oracle_form(jFrame,"Submitting 'PRC: Create Accounting' Program")
   
   #Entering Parameters
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Parameters","FlexWindow"]
   parameters_form=jFrame.FindChildEx(prop,val,60,True,60000)
   Sys.HighlightObject(parameters_form) 
   Delay(1000)
#   self.log_message_oracle_form(jFrame,"'PRC: Generate Cost Accounting Events' Program Parameters entered successfully")
   val = ["OK ALT O","FormButton"]
   parameters_form.FindChild(prop,val,60).Click()
   Delay(2000)
   Delay(1000)
   
   #submit
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Submit alt m","Button"]
   submitrequest_form.FindChild(prop,val,60).Click()
   self.log_message_oracle_form(jFrame,"'PRC: Create Accounting' job submitted")
   Delay(2000)
   
   val = ["Decision Request submitted*","ChoiceBox"]
   decision_box = jFrame.FindChildEx(prop,val,60,True,12000)
   RequestID = aqConvert.VarToStr(''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit()))
   self.log_message_oracle_form( jFrame,"'PRC: Create Accounting' program submitted successfully and Request ID is "+VarToStr(RequestID))
   
   jFrame.Keys("~n")
   Delay(2000)
   
   #Find requests
   OCR.Recognize(menu_bar).BlockByText("View").Click()
   Delay(1000)
   view_menu=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("LWPopupMenu", "", 0)
   OCR.Recognize(view_menu).BlockByText("Requests").Click()
   Delay(2000)
   jFrame.Keys("~i")
   Delay(2000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Requests","ExtendedFrame"]
   req_form=jFrame.FindChildEx(prop,val,30,True,90000)
   self.req_set_save_output(jFrame,req_form,"Journal Import",RequestID)
   web_utils.close_additional_browsers()
   Delay(4000)
   jFrame.Keys("~w")
   Delay(2000)
   jFrame.Keys("2")
   Delay(2000)   
   Sys.HighlightObject(req_form) 
   Delay(2000) 
   jFrame.Keys("[F4]")
   self.log_message_oracle_form( jFrame,"Switching Responsibility to 'CAI "+self.oper_unit+" PA PROJECT CONTROLS' next")    
   #Switching Responsibility
   menu_bar=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWMenuBar", "", 0)
   OCR.Recognize(menu_bar).BlockByText("File").Click()
   Delay(1000)
   jFrame.Keys("w")
   Delay(2000)

   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Responsibilities","FWindow"]
   resp_form=jFrame.FindChildEx(prop,val,30,True,60000)
   
   
   #selecting the responsibility
   resp_form.Find("AWTComponentName","LWTextField*",10).Click() 
   resp_form.Find("AWTComponentName","LWTextField*",10).keys("CAI "+self.oper_unit+" PA PROJECT CONTROLS")
   Delay(4000)
   val = ["Find ALT F","PushButton"]
   resp_form.FindChild(prop,val,20).Click()
   Delay(4000) 
   jFrame.keys("e")
   Delay(1000)
   jFrame.keys("e")
   Delay(1000)
   jFrame.keys("a")
   Delay(3000)
   self.log_message_oracle_form(jFrame,"'Find Expenditure Items' form launched successfully")  
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Find Expenditure Items","ExtendedFrame"]
   exp_batch_form=jFrame.FindChildEx(prop,val,30,True,40000)
   exp_batch_form.FindChild("AWTComponentAccessibleName","Expenditure BatchList of Values",10).Click()
   Delay(1000)        
   exp_batch_form.FindChild("AWTComponentAccessibleName","Expenditure tab page Expenditure BatchList of Values",10).SetText(vvalue)
   Delay(1000)
   self.log_message_oracle_form(jFrame,"In 'Find Expenditure Items' form Expenditure Batch entered successfully")
   Delay(1000)
   self.log_message_oracle_form(jFrame,"In 'Find Expenditure Items' form click 'Find' button next")
   exp_batch_form.FindChild("AWTComponentAccessibleName","Find alt i",10).Click()
#    jFrame.Keys("~i")
   Delay(10000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Expenditure Items","ExtendedFrame"]
   exp_items_form=jFrame.FindChildEx(prop,val,30,True,40000)
   Delay(1000)
   self.log_message_oracle_form(jFrame,"On 'Expenditure Items' form click on 'Item Details' next")
   exp_items_form.FindChild("AWTComponentAccessibleName","Item Details alt D",10).Click()
   Delay(8000)
   self.log_message_oracle_form(jFrame,"On 'Item Details' form click on 'OK' button next")
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Item Details","ExtendedFrame"]
   item_details_form=jFrame.FindChildEx(prop,val,30,True,40000)
   item_details_form.FindChild("AWTComponentAccessibleName","OK alt O",10).Click()
   Delay(8000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Cost Distribution Lines","ExtendedFrame"]
   cost_dist_form=jFrame.FindChildEx(prop,val,30,True,40000) 
   prop=["AWTComponentAccessibleName","AWTComponentIndex"]
   val=["Distribution Line Status",44]
   status=cost_dist_form.FindChild(prop,val,30)
   Delay(5000)   
   self.log_message_oracle_form(cost_dist_form,"'Cost Distribution Lines' reviewed successfully") 
   
   self.verify_aqobject_chkproperty(status,"wSelection",cmpContains,"Accepted")     
   
   Delay(4000)
   jFrame.Keys("[F4]")
   Delay(2000) 
   jFrame.keys("[F4]")
   Delay(2000)
   jFrame.keys("~o")



 def req_set_save_output(self,jFrame,req_form,srch_child_name,Preqid):
  self.log_message_oracle_form(req_form,"Checking for "+aqConvert.VarToStr(srch_child_name)+ " Child Program Status")
  req_form.FindChild("AWTComponentAccessibleName","Refresh Data alt R",20).Click()
  i=20
  for x in range(1,180):     
   prop=["AWTComponentAccessibleName","AWTComponentIndex"]
   val=["Name",i]
   child_name=req_form.Find(prop,val,10).wText 
   prop=["AWTComponentAccessibleName","AWTComponentIndex"]
   val=["Phase",i+20]
   phase=req_form.Find(prop,val,10).wText 
   prop=["AWTComponentAccessibleName","AWTComponentIndex"]
   val=["Request ID",i-10]
   creqid= aqConvert.VarToInt(req_form.Find(prop,val,10).wText)                                        
   prop=["AWTComponentAccessibleName","AWTComponentIndex"]
   val=["Status",i+30]         
   status =req_form.FindChild(prop,val,60)            
   if (child_name==srch_child_name) and (aqConvert.VarToInt(creqid)>= aqConvert.VarToInt(Preqid)) and (phase == "Completed"):
     self.log_message_oracle_form(req_form, aqConvert.VarToStr(srch_child_name)+" Phase Completed Successfuly")                              
     status.Keys("[Enter]")
     Delay(1000)
     req_form.FindChild("AWTComponentAccessibleName","View Output alt p",20).Click()  
     Delay(4000)
     output_page=Sys.Browser("iexplore").Page("https://core*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.*")
     output_page.Click()
     Delay(2000)
     output_page.Keys("~f")
     Delay(2000)
     output_page.Keys("a")
     Delay(5000)
     file_system_utils.create_folder(self.op_log_path)             
     self.log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"File"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"_%d%b%Y_%H%M")+".txt"    
     Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(self.log_path)
     Delay(1000)
     Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
     Delay(8000)
     Log.Enabled=True
     Log.File(self.log_path, aqConvert.VarToStr(srch_child_name)+" is Completed And Output file is attached")
     Log.Enabled=False     
     web_utils.close_additional_browsers()         
     Filesaved = 'True'
     return                           
   elif i >=29:
     Delay(15000)           
     req_form.FindChild("AWTComponentAccessibleName","Refresh Data alt R",20).Click()
     Delay(3000)
     i=20
     val=["Name",i]
     child_name=req_form.Find(prop,val,10).wText
   else:  
     Delay(2000)
     i=i+1 
     jFrame.Keys("[Down]")

