﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils


class tc179286_is_us_manual_journals_enter(Ebiz): 
 global rowno
 op_log_path="C:\\TC_Logs"
 
 
 def login(self):
   self.login_user= 'mfallwell' #CGLUSER
   super().login()

 def goto_url(self,url):
   super().goto_url(self.testConfig['ebiz']['oci_is_url'])
   
 def action(self,book): 
     web_utils.log_checkpoint("Logged in to MAN Oracle Ebiz Instance Successfully",500,self.page)
     self.wait_until_page_loaded() 
     web_utils.log_checkpoint("Currency Selected for manual journal entry: "+ProjectSuite.Variables.currency,500,self.page) 
     if ProjectSuite.Variables.currency =="USD": 
      app = book.Sheets.item["ManualJournal_USD"]
     elif ProjectSuite.Variables.currency=="CAD":
      app = book.Sheets.item["ManualJournal_CAD"]
     Log.Message("Inside action") 
     Delay(3000)
     web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='menuContent']//div[contains(text(),'GL Corporate Accounting User')]") 
     self.wait_until_page_loaded()
     self.page.NativeWebObject.Find("contentText","Journals","A").Click()
     web_utils.log_checkpoint("Click 'Journals' - Successful",500,self.page)
     delay(2000)
     self.page.NativeWebObject.Find("contentText","Enter","A").Click()
     web_utils.log_checkpoint("Click 'Enter' - Successful",500,self.page)
     web_utils.validate_security_box()
     Delay(20000)
     jFrame=self.initializeJFrame()
     form_utils.click_ok_btn(jFrame)
     Delay(3000) 
     jFrame.Keys("~j")
    
#Entering Journal Header Information for USD Currency
     if ProjectSuite.Variables.currency =="USD": 
        prop=["AWTComponentAccessibleName","JavaClassName"]
        val=["Journals (MAN GLB ALL)*","ExtendedFrame"]
        jrnl_form=jFrame.FindChildEx(prop,val,60,True,60000)
        jrnl_name = VarToStr("TEST_MANUAL_JL: "+aqConvert.DateTimeToFormatStr(aqDateTime.Time(),"%H:%M:%S"))
        jrnl_form.Find("AWTComponentAccessibleName","Journal Required",10).SetText(jrnl_name)
        (app.Cells.Item[2,1]) = jrnl_name
        web_utils.log_checkpoint("Enter 'Journal Name' - Successful",500,jFrame)
        jrnl_form.Find("AWTComponentAccessibleName","Category RequiredList of Values",10).SetText(VarToStr(app.Cells.Item[2,2]))
        web_utils.log_checkpoint("Enter 'Journal Category' - Successful",500,jFrame)
  #Entering Journal Line Level information for USD Currency
        i=2
        j=0
        while j<2:
          pro_names=["AWTComponentAccessibleName","AWTComponentIndex"]
          pro_values=["Line*",j] #pro_values=["Line Required",0]
          jrnl_form.Find(pro_names,pro_values,30).click()
          jrnl_form.Find(pro_names,pro_values,30).SetText(VarToStr(app.Cells.Item[i,3]))

             
          aqUtils.Delay(2000)
          pro_names=["AWTComponentAccessibleName","AWTComponentIndex"]
          pro_values=["*Account*",7+j+1] #pro_values=["Account RequiredList of Values",8]
          jrnl_form.Find(pro_names,pro_values,15).click()
          jrnl_form.Find(pro_names,pro_values,15).SetText(VarToStr(app.Cells.Item[i,4]))

        
          aqUtils.Delay(2000)
          pro_names=["AWTComponentAccessibleName","AWTComponentIndex"]
          pro_values=["*Debit*",0+j] #pro_values=["Lines tab page Entered: Debit Required",0]
          jrnl_form.Find(pro_names,pro_values,15).Click()
          jrnl_form.Find(pro_names,pro_values,15).Keys(VarToStr(app.Cells.Item[i,5])) 
#          jrnl_form.Find(pro_names,pro_values,15).Keys("[Tab]")   
       
          aqUtils.Delay(5000)
          pro_names=["AWTComponentAccessibleName","AWTComponentIndex"]
          pro_values=["*Credit*",8+j] 
          jrnl_form.Find(pro_names,pro_values,15).Click()
          jrnl_form.Find(pro_names,pro_values,15).Keys(VarToStr(app.Cells.Item[i,6]))
          jrnl_form.Find(pro_names,pro_values,15).Keys("[Tab]")   
           
#          pro_names=["AWTComponentAccessibleName","AWTComponentIndex"]
#          pro_values=["Line Required",j+1]
#          x=0
#          while x<3:
#            jrnl_form.FindChild(pro_names,pro_values,30).click()
#            x=x+1
#            delay(1000)     
          j=j+1
          i+=1
        
#Entering Journal Header Information for CAD Currency
     elif ProjectSuite.Variables.currency=="CAD": 
        prop=["AWTComponentAccessibleName","JavaClassName"]
        val=["Journals (MAN GLB ALL)*","ExtendedFrame"]
        jrnl_form=jFrame.FindChildEx(prop,val,60,True,60000)
        jrnl_form.Find("AWTComponentAccessibleName","Journal Required",10).SetText(VarToStr(app.Cells.Item[2,1]))
        web_utils.log_checkpoint("Enter 'Journal Name' - Successful",500,jFrame)
        delay(1000) 
        jrnl_form.Find("AWTComponentAccessibleName","Category RequiredList of Values",10).SetText(VarToStr(app.Cells.Item[2,2]))
        web_utils.log_checkpoint("Enter 'Journal Category' - Successful",500,jFrame)
        delay(1000) 
        jrnl_form.Find("AWTComponentAccessibleName","Conversion: Currency RequiredList of Values",10).Click()
        jrnl_form.Find("AWTComponentAccessibleName","Conversion: Currency RequiredList of Values",10).Keys("[BS][BS][BS]")
        jrnl_form.Find("AWTComponentAccessibleName","Conversion: Currency RequiredList of Values",10).SetText("CAD")
        web_utils.log_checkpoint("Enter 'Currency' - Successful",500,jFrame)
        jFrame.Keys("[Tab]")
        delay(3000) 
        pro_names=["AWTComponentAccessibleName","AWTComponentIndex"]
        pro_values=["Conversion: Date RequiredList of Values",12]
        jrnl_form.Find(pro_names,pro_values,30).Click()
        jrnl_form.Find(pro_names,pro_values,30).Keys("[BS][BS][BS][BS][BS][BS][BS][BS][BS][BS]")
        jrnl_form.Find(pro_names,pro_values,30).SetText("21-JAN-2020")
        web_utils.log_checkpoint("Enter 'Conversion: Date' - Successful",500,jFrame)
        jFrame.Keys("[Tab]")
        delay(3000) 
        pro_names=["AWTComponentAccessibleName","AWTComponentIndex"]
        pro_values=["Conversion: Type RequiredList of Values",13]
        jrnl_form.Find(pro_names,pro_values,30).Click()
        jrnl_form.Find(pro_names,pro_values,30).SetText("Spot")
        web_utils.log_checkpoint("Enter 'Conversion Type' - Successful",500,jFrame)
        jFrame.Keys("[Tab]")
        delay(3000) 
      
  #Entering Journal Line Level information for CAD Currency
        i=2
        j=0
        while j<8:
          pro_names=["AWTComponentAccessibleName","AWTComponentIndex"]
          pro_values=["Line*",j] #pro_values=["Line Required",0]
          jrnl_form.Find(pro_names,pro_values,30).click()
          jrnl_form.Find(pro_names,pro_values,30).SetText(VarToStr(app.Cells.Item[i,3]))
          jrnl_form.Find(pro_names,pro_values,15).Keys("[Tab]") 
             
          aqUtils.Delay(2000)
          pro_names=["AWTComponentAccessibleName","AWTComponentIndex"]
          pro_values=["*Account*",7+j+1] #pro_values=["Account RequiredList of Values",8]
          jrnl_form.Find(pro_names,pro_values,15).click()
          jrnl_form.Find(pro_names,pro_values,15).SetText(VarToStr(app.Cells.Item[i,4]))
          jrnl_form.Find(pro_names,pro_values,15).Keys("[Tab]") 
        
          aqUtils.Delay(2000)
          pro_names=["AWTComponentAccessibleName","AWTComponentIndex"]
          pro_values=["*Debit*",0+j] #pro_values=["Lines tab page Entered: Debit Required",0]
          jrnl_form.Find(pro_names,pro_values,15).SetText(VarToStr(app.Cells.Item[i,5])) 
          jrnl_form.Find(pro_names,pro_values,15).Keys("[Tab]")   
       
          aqUtils.Delay(5000)
          pro_names=["AWTComponentAccessibleName","AWTComponentIndex"]
          pro_values=["*Credit*",8+j] 
          jrnl_form.Find(pro_names,pro_values,15).SetText(VarToStr(app.Cells.Item[i,6]))
          jrnl_form.Find(pro_names,pro_values,15).Keys("[Tab]")   
           
          pro_names=["AWTComponentAccessibleName","AWTComponentIndex"]
          pro_values=["Line Required",j+1]
          x=0
          while x<9:
            jrnl_form.FindChild(pro_names,pro_values,30).click()
            x=x+1
            delay(1000)     
          j=j+1
          i+=1

        
     jFrame.Keys("^s")
     Delay(5000) 
     web_utils.log_checkpoint("Entered Journal Header and Journal Line Information Successfully",500,jFrame)
     web_utils.log_checkpoint("On 'Enter Journals Form' Click 'Approve' Button Next",500,jFrame)
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Journals (MAN GLB ALL)*","ExtendedFrame"]
     Journals_Frame=jFrame.FindChild(prop,val,60)
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Approve alt A","Button"]
     Journals_Frame.Find(prop,val,60).Click()
     Delay(4000)
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Note Your journal batch was forwarded to an approver.","ChoiceBox"]
     Note_Form=jFrame.FindChildEx(prop,val,60,True,40000)
     web_utils.log_checkpoint("Click OK Button Next on 'Note Form' with message - Note Your journal batch was forwarded to an approver.",500,jFrame)
     jFrame.Keys("~o")   
     Delay(3000)
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Journals (MAN GLB ALL)*","ExtendedFrame"]
     batch_name=(jFrame.FindChildEx(prop,val,60,True,40000).AWTComponentAccessibleName)[25:]
     app.Cells.Item[2,9]=VarToStr(batch_name)
     web_utils.log_checkpoint("Journal Batch Name: "+VarToStr(batch_name),500,jFrame)
#     self.close_forms(jFrame)
#     Sys.Keys("[F4]") 
#     Delay(4000)
#     Sys.Keys("[F4]") 
#     Delay(2000)
#     Sys.Keys("[F4]")
#     Delay(2000)
#     Sys.Keys("~o")
#     Delay(2000)  
     jFrame.Keys("[F4]") 
     Delay(2000)
     jFrame.Keys("[F4]") 
     Delay(2000)
     jFrame.Keys("~o")   


