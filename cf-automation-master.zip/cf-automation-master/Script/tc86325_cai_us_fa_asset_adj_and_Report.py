﻿from ebiz import *
import web_utils
import dbhelper
import file_system_utils

class tc86325_cai_us_fa_asset_adj_and_Report(Ebiz):  
 global rowno, app, jFrame

 op_log_path ="C:\\TC_Logs"

 def login(self):
   self.login_user='naggarwal'
   super().login()

 def action(self,book):
  
  app = book.Sheets.item["PA-FA"]
  RowCount = book.ActiveSheet.UsedRange.Rows.Count
  rowno = 2 
  self.page.wait()
  web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" FA ASSET TRANSACTION')]")
  self.log_message_web("Click 'CAI "+self.oper_unit+" FA ASSET TRANSACTION' - Successful")
  Delay(2000)
  self.page.wait()
  self.page.EvaluateXpath("//table[@id='respList']//div[text()='Assets']")[0].Click()
  self.log_message_web("Click 'Assets' - Successful")
  Delay(2000)
  self.page.wait()
  self.page.EvaluateXpath("//table[@id='respList']//div[text()='Asset Workbench']")[0].Click()
  self.log_message_web("Click 'Asset Workbench' - Successful")
#  Delay(8000) 
#  web_utils.validate_security_box()
  Delay(15000)
  jFrame=self.initializeJFrame()
  self.page.Keys("~o") 
  Delay(8000)   
  while rowno<(RowCount+1):
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Find Assets","ExtendedFrame"]
   find_asset_form=jFrame.FindChildEx(prop,val,60,True,90000)
   find_asset_form.Find("AWTComponentAccessibleName","Asset Number",10).Click() 
   find_asset_form.Find("AWTComponentAccessibleName","Asset Number",10).SetText(app.Cells.Item[rowno,1])
   self.log_message_oracle_form(find_asset_form,"In 'Find Assets' Form: Enter Asset Number"+VarToStr(app.Cells.Item[rowno,1]))
   self.log_message_oracle_form(find_asset_form,"In 'Find Assets' Form: Click 'Find' button next")
   #click Find on Find Assets Window
   jFrame.Keys("~i") 
   Delay(1000)
   
   #click Books button on Assets Window  
   prop_names=["AWTComponentAccessibleName","JavaClassName"]
   prop_values=["Assets","ExtendedFrame"]
   Assets_obj = jFrame.FindChildEx(prop_names,prop_values,30,True,60000)
   self.log_message_oracle_form(jFrame,"In 'Assets' form : Click 'Books' button next")  
   jFrame.keys("~b")
   Delay(5000)
 
   #Books window 
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Books","ExtendedFrame"]
   books_form=jFrame.FindChildEx(prop,val,60,True,60000) 
   books_form.Find("AWTComponentAccessibleName","Book RequiredList of Values",30).Click()
   Delay(2000)
   books_form.Find("AWTComponentAccessibleName","Book RequiredList of Values",30).Keys(app.Cells.Item[rowno,6]) 
   self.log_message_oracle_form(jFrame,"In 'Find Assets Form': Click 'Find' button next")   
   books_form.Find("AWTComponentAccessibleName","Current Cost Required",30).Click() 
   Delay(2000)
   cost =books_form.Find("AWTComponentAccessibleName","Current Cost Required",30).wText
   self.log_message_oracle_form(jFrame,"In 'Books' form: Enter Current Cost - "+ VarToStr(cost))
   adjamt=aqConvert.DateTimeToFormatStr(aqDateTime.Time(),"%H%M")
   costadj=VarToInt(cost)+ VarToInt(adjamt)
   app.Cells.Item[rowno,13]= costadj
   books_form.Find("AWTComponentAccessibleName","Current Cost Required",30).Keys(VarToStr(costadj))
   self.log_message_oracle_form(jFrame,"In 'Books' form: Enter Adjustment Cost - "+ VarToStr(costadj))
   
   #click done Button
   self.log_message_oracle_form(books_form,"Asset Cost updated and Click 'Done' Button Next")
   books_form.FindChild("AWTComponentAccessibleName","Done alt D",10).Click()
#   books_form.Keys("~d")
   self.log_message_oracle_form(books_form,"Transaction Complete Confimation displayed; Click 'OK' Button Next")
   #Click Ok
   prop_names = ("AWTComponentAccessibleName","JavaClassName")
   prop_values = ("Forms*","FWindow")
   ok_obj = jFrame.FindChildEx(prop_names,prop_values,30,True,20000)
   self.verify_aqobject_chkproperty(ok_obj,"Name",cmpContains,"Transaction complete")
   prop_names = ("AWTComponentAccessibleName","JavaClassName")
   prop_values = ("OK ALT O","PushButton")
   ok_obj.FindChild(prop_names,prop_values,60).Click()
   Delay(3000)
   self.log_message_oracle_form(jFrame,"In 'Assets' form : Click 'Financial Inquiry' button next")
   prop_names=["AWTComponentAccessibleName","JavaClassName"]
   prop_values=["Assets","ExtendedFrame"]
   Assets_obj = jFrame.FindChildEx(prop_names,prop_values,30,True,60000)
   Assets_obj.FindChild("AWTComponentAccessibleName","Financial Inquiry alt i",10).Click()
   Delay(4000)
   self.log_message_oracle_form(jFrame,"In 'View Financial Information' form : Review Financial Information of an Asset")
   Delay(1000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["View Financial Information*","ExtendedFrame"]
   view_fin_form=jFrame.FindChildEx(prop,val,60,True,90000) 
   self.log_message_oracle_form( jFrame,"View Financial Information form launched successfully")  
   self.log_message_oracle_form( jFrame,"In 'View Financial Information' form click on 'Cost History' Tab next") 
   #Navigate to cost history and close the form   
   view_fin_form.FindChild("AWTComponentName","FormsTabPane*",20).ClickTab("Cost History")   
   self.log_message_oracle_form( jFrame,"Review Retirement Information on 'Cost History' Tab")              
   Delay(2000) 
   jFrame.Keys("[F4]")
   Delay(1000)
   #Navigate to View > Find 
   jFrame.Keys("~v")
   Delay(1000)
   jFrame.Keys("f")
#   self.log_message_oracle_form(jFrame,"Iteration rowno#: Navigation Successful View > Find ")
   rowno=rowno+1
  jFrame.Keys("[F4]") # Close Form ( Find Assets)
  Delay(1000)
  jFrame.Keys("~f")
  Delay(1000)
  jFrame.Keys("w")
  Delay(3000)
  self.log_message_oracle_form( jFrame,"Swith Responsibility to 'CAI" +self.oper_unit +" FA INQUIRY' by clicking File > Switch Responsibility")       
  prop=["AWTComponentAccessibleName","JavaClassName"]
  val=["Responsibilities","FWindow"]
  resp_form=jFrame.FindChildEx(prop,val,30,True,40000)
  resp_form.Find("AWTComponentName","LWTextField*",10).Click() 
  resp_form.Find("AWTComponentName","LWTextField*",10).keys("CAI "+self.oper_unit+" FA INQUIRY")
#  self.verify_aqobject_chkproperty(resp_form,"AWTComponentAccessibleName",cmpContains,"Responsibilities")   
  Delay(2000)
  #resp_form.Keys("~f")
  jFrame.Keys("~f")
  Delay(2000)
  self.log_message_oracle_form( jFrame,"Reponsiblity Switched to "+"'CAI "+self.oper_unit+" FA INQUIRY'")
  Delay(4000)
  form_utils.Nav_Submit_Single_Request(self,jFrame) 
  
  #Submit Request 
  prop=["AWTComponentAccessibleName","JavaClassName"]
  val=["Submit Request","ExtendedFrame"]
  submitrequest_form=jFrame.FindChildEx(prop,val,60,True,20000)
#  self.log_message_oracle_form(submitrequest_form,"Submit Request Window Opened") 
  Delay(5000)

  prop=["AWTComponentAccessibleName","JavaClassName"]
  val=["Name RequiredList of Values","VTextField"]
  submitrequest_form.FindChildEx(prop,val,60,True,60000).Click()
  submitrequest_form.FindChild(prop,val,60).Keys("CAI Cost Adjustments Report")
  self.log_message_oracle_form( jFrame,"'CAI Cost Adjustments Report' program name entered")
  submitrequest_form.FindChild(prop,val,60).Keys("[Tab]")
  Delay(2000)
     
  prop=["AWTComponentAccessibleName","JavaClassName"]
  val=["Parameters","FlexWindow"]
  parameters_form=jFrame.FindChildEx(prop,val,60,True,20000)
  prop=["AWTComponentAccessibleName","JavaClassName"]
  val=["Book REQUIRED List Values","FlexTextField"]
  parameters_form.FindChild(prop,val,60).Click()
  parameters_form.FindChild(prop,val,60).Keys(VarToStr(app.Cells.item[2,6])) 
  Delay(1000) 
  parameters_form.FindChild(prop,val,60).Keys("[Tab]")
  parameters_form.Keys("[Tab]")
  prop=["AWTComponentAccessibleName","JavaClassName"]
  val=["From Period REQUIRED List Values","FlexTextField"]
  parameters_form.FindChild(prop,val,60).Click()  
  Lastmonth = aqDateTime.AddMonths(aqDateTime.Now(),-1)
  parameters_form.FindChild(prop,val,60).Keys(aqConvert.DateTimeToFormatStr(Lastmonth,"%b-%y"))
  prop=["AWTComponentAccessibleName","JavaClassName"]
  val=["To Period REQUIRED List Values","FlexTextField"]
  parameters_form.FindChild(prop,val,60).Click() 
  parameters_form.FindChild(prop,val,60).Keys(aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%b-%y"))
  self.log_message_oracle_form(jFrame,"Parameters Values 'Book', 'Set of Books Currency', 'From Period', 'To Period' entered successfully")
  #click Ok Button 
  parameters_form.keys("~o")
  Delay(1000)
  #click Submit Button 
  self.log_message_oracle_form(jFrame,"Click 'OK' Button on Parameters window Successful; Click Submit Button next") 
  jFrame.keys("~m")
  Delay(3000)
  # Request Id generated
  RequestID=form_utils.capture_reqid_and_save_Excel_output_singlereq(self,jFrame,self.op_log_path,"CAI COST Adjustment Report")
  
  dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
  user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
  pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
  dbhelper.verify_oracle_concurrent_job_status(dsn,user_id,pwd,RequestID)
  Delay(4000)       
  jFrame.Keys("[F4]")
  Delay(1000)
  self.log_message_oracle_form( jFrame,"Switching Responsibility to 'CAI US FA JOB SCHEDULER' next")    
     
 #Switching Responsibility
  menu_bar=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWMenuBar", "", 0)
  OCR.Recognize(menu_bar).BlockByText("File").Click()
  Delay(1000)
  jFrame.Keys("w")
  Delay(2000)

 #Switiching responsibility form identification
  prop=["AWTComponentAccessibleName","JavaClassName"]
  val=["Responsibilities","FWindow"]
  resp_form=jFrame.FindChildEx(prop,val,30,True,60000)
   
 #selecting the responsibility
  resp_form.Find("AWTComponentName","LWTextField*",10).Click() 
  resp_form.Find("AWTComponentName","LWTextField*",10).keys("CAI US FA JOB SCHEDULER")
  self.verify_aqobject_chkproperty(resp_form,"AWTComponentAccessibleName",cmpContains,"Responsibilities")   
  Delay(2000)
   
  val = ["Find ALT F","PushButton"]
  resp_form.FindChild(prop,val,20).Click()
  Delay(2000) 
   
 #Navigating to submit request
  jFrame.Keys("~o")
  self.log_message_oracle_form(jFrame,"'CAI US FA JOB SCHEDULER' launched successfully and Submit New Request next")
  Delay(2000)
  jFrame.Keys("~o")
   
 #Submitting Create Accounting - Assets Program
  prop=["AWTComponentAccessibleName","JavaClassName"]
  val=["Submit Request","ExtendedFrame"]
  submitrequest_form=jFrame.FindChildEx(prop,val,60,True,60000)
  self.log_message_oracle_form(jFrame,"Submitting 'Create Accounting' Program")
  name = submitrequest_form.Find("AWTComponentAccessibleName","Name RequiredList of Values",20)
  name.Click()
  name.SetText("Create Accounting - Assets")
  Delay(5000)
  jFrame.Keys("[Tab]")
  Delay(2000)
   
 #Entering Parameters
  prop=["AWTComponentAccessibleName","JavaClassName"]
  val=["Parameters","FlexWindow"]
  parameters_form=jFrame.FindChildEx(prop,val,60,True,60000)
#  book_txtfield=parameters_form.FindChild("AWTComponentAccessibleName","Ledger REQUIRED List Values",10)
#  book_txtfield.Click()
#  book_txtfield.Keys("CAI US LEDGER")
  book_txtfield=parameters_form.FindChild("AWTComponentAccessibleName","Book Type Code REQUIRED List Values",10)
  book_txtfield.Click()
  delay(2000)
  book_txtfield.Keys("ATG CORP")
  
  Delay(1000)
  parameters_form.Keys("[Tab]")
  Delay(1000)
#  parameters_form.Keys("[Tab]")
#  Delay(1000)
#  jFrame.Keys(aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d-%b-%Y"))
#  Delay(1000)
#  parameters_form.Keys("[Tab]")
#  Delay(1000)
  self.log_message_oracle_form(jFrame,"'Create Accounting - Assets' Program Parameters entered successfully")
  val = ["OK ALT O","FormButton"]
  parameters_form.FindChild(prop,val,60).Click()
  Delay(2000)
  Delay(1000)
   
 #submit
  prop=["AWTComponentAccessibleName","JavaClassName"]
  val=["Submit alt m","Button"]
  submitrequest_form.FindChild(prop,val,60).Click()
  Delay(2000)
   
  val = ["Decision Request submitted*","ChoiceBox"]
  decision_box = jFrame.FindChildEx(prop,val,60,True,12000)
#   RequestID = ''.join(x for x in decision_box.AWTComponentAccessibleName if x.isdigit())
  RequestID = aqConvert.VarToStr(''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit()))
  self.log_message_oracle_form( jFrame,"'Create Accounting - Assets' program submitted successfully and Request ID is "+VarToStr(RequestID))
   
  jFrame.Keys("~n")
  Delay(2000)
   
 #Find requests
  OCR.Recognize(menu_bar).BlockByText("View").Click()
  Delay(1000)

  view_menu=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("LWPopupMenu", "", 0)
  OCR.Recognize(view_menu).BlockByText("Requests").Click()

  Delay(2000)
  jFrame.Keys("~i")
  Delay(2000)
  
 # Checking in the DB for the concurrent programs completion
  dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
  user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
  pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
  dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd, aqConvert.VarToStr(RequestID))
    
 #Verify job completion
 #output file view, save and close the output window
  prop=["AWTComponentAccessibleName","JavaClassName"]
  val=["Requests","ExtendedFrame"]
  req_form=jFrame.FindChildEx(prop,val,30,True,90000)
  creq_id,log_path = form_utils.req_set_save_output(self,jFrame,req_form,"Journal Import",RequestID)
  web_utils.close_additional_browsers()
   
 #read the output file and save in excel
  fo=open(log_path,"r") 
  lines=fo.readlines()
  self.log_message_web("Journal Imported Batch Name is : - "+lines[17][8:33].strip())
  app.Cells.Item[rowno,1] = lines[17][8:33].strip()   
   
 #Close form
  jFrame.Keys("~w")
  Delay(2000)
  jFrame.Keys("2")
  Delay(2000)    
  jFrame.Click()
  Delay(2000)
  jFrame.Keys("~w")
  Delay(2000)
  jFrame.Keys("2")
  Delay(2000)
  jFrame.keys("[F4]")
  Delay(2000)
  jFrame.keys("[F4]")
  Delay(2000)
  jFrame.keys("~o")
  Delay(2000)
#  jFrame.Keys("[F4]")
#  Delay(3000)
#  jFrame.Keys("[F4]")
#  Delay(3000)
#  jFrame.Keys("~o")
#  Delay(3000)   
  Sys.Browser("iexplore", 2).Window("#32770", "View Downloads - Internet Explorer", 1).keys("~c")
 #save book and close addition tabs in IE
#  book.save()
#   Sys.Browser("iexplore").page("https://*epfinnp.coxautoinc.com/forms/frmservlet*").Close()
#  self.close_forms(self,jFrame)

     
 
  
  
  
  
  
  
