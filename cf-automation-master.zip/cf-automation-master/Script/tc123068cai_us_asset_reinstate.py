﻿from dbhelper import *
from ebiz import *
import web_utils
import dbhelper
import file_system_utils 
import form_utils

class tc123068cai_us_asset_reinstate(Ebiz):
 op_log_path="C:\\TC_Logs"

 def login(self):
   self.login_user='rmaran'
   super().login()
   
 def action(self,Book): 
   app = Book.Sheets.item["Assets"] 
   rowno=2
   prop_names = ("innerHTML")
   prop_values = ("Oracle Applications Home Page")
   obj =  Sys.Browser("iexplore").Page("*").FindChild(prop_names,prop_values,30)
   self.verify_aqobject_chkproperty(obj,"contentText",cmpContains,"Oracle Applications Home Page")
   Delay(10000)
   web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//li/a[contains(text(),'CAI "+self.oper_unit+" FA ASSET TRANSACTION')]")
   Delay(3000)
   self.page.Find("contentText","Assets",30).Click()
   self.page.Find("contentText","Asset Workbench",30).Click()
#   Sys.Browser("iexplore").Page("*").NativeWebObject.Find("contentText","Assets","A").Click()
   Delay(20000)
   jFrame= self.initializeJFrame()
   form_utils.click_ok_btn(jFrame)
   self.log_message_oracle_form( jFrame,"Find Assets")
   Delay(4000)
   start_date = (aqConvert.DateTimeToFormatStr(aqDateTime.Today().date().replace(month=1, day=1),"%d-%b-%Y")) 
   end_date = (aqConvert.DateTimeToFormatStr(aqDateTime.Today().date().replace(month=12, day=31),"%d-%b-%Y"))
     
   dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
   user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
   pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
   asset_id = dbhelper.asset_ret(dsn,user_id,pwd)
   #asset_id = dbhelper.asset_ret(dsn,user_id,pwd)
   Log.Enabled = True
   Log.Message(asset_id)
   Log.Enabled = False
   
   
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Find Assets","ExtendedFrame"]
   findassets_form=jFrame.FindChild(prop,val,60)
   findassets_form.Find("AWTComponentAccessibleName","Asset Number",10).SetText(VarToInt(asset_id))
   findassets_form.Keys("[Tab]")
   self.verify_aqobject_chkproperty(findassets_form,"AWTComponentAccessibleName",cmpContains,"Find Assets")
   Delay(3000)
   findassets_form.Keys("~i")
   Delay(3000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Assets","ExtendedFrame"]
   assets_form=jFrame.FindChild(prop,val,60)
   self.log_message_oracle_form( jFrame,"Assets Form Found")
   self.verify_aqobject_chkproperty(assets_form,"AWTComponentAccessibleName",cmpContains,"Assets")
   jFrame.keys("~r")
   self.log_message_oracle_form( jFrame,"Assets Form Retirement button clicked")
   Delay(2000)
   self.log_message_oracle_form( jFrame,"Assets Retirements Form Found")
   jFrame.keys("^[F11]")
   self.log_message_oracle_form( jFrame,"Queried Assets Retirement Form")
   Delay(2000)
   jFrame.keys("~r")
   Delay(2000)
   jFrame.keys("~o")
   Delay(2000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["retirements","ExtendedFrame"]   
   retirements_form=jFrame.FindChild(prop,val,60)
   Delay(2000)
   prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
   val=["Book RequiredList of Values","VTextField",2]      
   retirements_form.Find(prop,val,10).Keys("ATG CORP")
   self.log_message_oracle_form( jFrame,"Assets Book Entered")
   Delay(2000)
   retirements_form.Find(prop,val,10).keys("[Tab]")
   prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
   val=["Cost Retired Required","VTextField",10]    
   Delay(2000)  
   retirements_form.Find(prop,val,10).Keys("200")
   self.log_message_oracle_form( jFrame,"Assets Partial Retirement Amount Entered")
   Delay(2000)
   retirements_form.Keys("~d")
   Delay(2000)
   jFrame.keys("~o")
   Delay(2000)
   jFrame.Keys("[F4]")
   Delay(2000)
   jFrame.Keys("o")
   Delay(2000)
   jFrame.Keys("r")
   Delay(5000)
   jFrame.Keys("~o")
   Delay(2000) 
   jFrame.Keys("~o")
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Submit Request","ExtendedFrame"]
   submitrequest_form=jFrame.FindChild(prop,val,60)
   submitrequest_form.Find("AWTComponentAccessibleName","Name RequiredList of Values",10).Keys("Calculate Gains and Losses")
   submitrequest_form.Keys("[Tab]")
   Delay(2000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Parameters","FlexWindow"]
   parameters_form=jFrame.FindChild(prop,val,60)
   book_txtfield=parameters_form.FindChild("AWTComponentAccessibleName","Book REQUIRED List Values",10)
   book_txtfield.Click()
   book_txtfield.Keys("ATG CORP")
   Delay(1000)
   book_txtfield.Keys("~o")
   Delay(2000)
   jFrame.Keys("~m")
   Delay(3000)
   gain_loss_requestid = aqConvert.VarToInt(''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit()))
   Log.Enabled = True
   Log.Message("Request ID of Calculate Gains and Losses program is " + aqConvert.VarToStr(gain_loss_requestid))
   Log.Enabled = False
   Delay(3000)
   jFrame.Keys("~n")
   Delay(2000)
   jFrame.Keys("~v")
   Delay(2000)
   jFrame.Keys("r")
   Delay(2000)
   jFrame.Keys("~i")
   Delay(2000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Requests","ExtendedFrame"]
   req_form=jFrame.FindChild(prop,val,30)   
   self.req_set_save_output(jFrame,req_form,"Calculate Gains and Losses",gain_loss_requestid)
   Delay(2000) 
   jFrame.Click()
   Delay(2000) 
   jFrame.Keys("[F4]")
   Delay(2000)
   jFrame.Keys("~v")
   Delay(2000)
   jFrame.Keys("r")
   Delay(2000)
   jFrame.Keys("~n")
   Delay(2000)  
   jFrame.Keys("~o")
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Submit Request","ExtendedFrame"]
   submitrequest_form=jFrame.FindChild(prop,val,60)
   submitrequest_form.Find("AWTComponentAccessibleName","Name RequiredList of Values",10).Keys("Asset Retirements Report")
   submitrequest_form.Keys("[Tab]")
   Delay(2000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Parameters","FlexWindow"]
   parameters_form=jFrame.FindChild(prop,val,60)
   book_txtfield=parameters_form.FindChild("AWTComponentAccessibleName","Book REQUIRED List Values",10)
   book_txtfield.Click()
   book_txtfield.Keys("ATG CORP")
   Delay(1000)
   parameters_form.Keys("[Tab]")
   Delay(1000)
   parameters_form.Keys("[Tab]")
   Delay(1000)
   mon_yr=(aqConvert.DateTimeToFormatStr(aqDateTime.Today(),"%B-%y"))
#   parameters_form.Keys("APR-19")
   parameters_form.Keys(mon_yr.upper())
   Delay(1000)
   parameters_form.Keys("[Tab]")
   Delay(1000)
#   parameters_form.Keys("APR-19")
   parameters_form.Keys(mon_yr.upper())
   Delay(1000)
   book_txtfield.Keys("~o")
   Delay(2000)
   jFrame.Keys("~m")
   Delay(3000)
   asset_retire_reqid = aqConvert.VarToInt(''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit()))
   Log.Enabled = True
   Log.Message("Request ID of Asset Retirements Report program is " + aqConvert.VarToStr(asset_retire_reqid))
   Log.Enabled = False
   Delay(2000)
   jFrame.Keys("~n")
   Delay(2000)
   jFrame.Keys("[F4]")
   Delay(2000)
   jFrame.Keys("~v")
   Delay(2000)
   jFrame.Keys("r")
   Delay(2000)
   jFrame.Keys("~i")
   Delay(2000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Requests","ExtendedFrame"]
   req_form=jFrame.FindChild(prop,val,30)   
   self.req_set_save_output(jFrame,req_form,"Asset Retirements Report",gain_loss_requestid)
   Delay(1000)
   jFrame.Click()
   Delay(1000)
   jFrame.Keys("[F4]")
   Delay(1000)
   jFrame.Keys("[F4]")
   Delay(1000)
   jFrame.Keys("~o")
   Delay(1000)
   self.browser.page("*").Close() 
   
   

 def req_set_save_output(self,jFrame,req_form,srch_child_name,Preqid):
    self.log_message_oracle_form(req_form,"Checking for Child Program")
    req_form.keys("~r")
    i=20
    for x in range(1,180):     
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Name",i]
        child_name=req_form.Find(prop,val,10).wText 
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Phase",i+20]
        phase=req_form.Find(prop,val,10).wText 
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Request ID",i-10]
        creqid=VarToInt(req_form.Find(prop,val,10).wText)                                         
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Status",i+30]         
        status =req_form.FindChild(prop,val,60)            
        if (child_name==srch_child_name) and (creqid>=Preqid) and (phase == "Completed"):
            self.log_message_oracle_form(req_form,"phase Completed Successfuly")            
            self.verify_aqobject_chkproperty(status,"wText",cmpContains,"Normal")        
            status.Keys("[Enter]")
            Delay(1000)
            jFrame.Keys("~p")    
            Delay(3000)
            output_page=Sys.Browser("iexplore").Page(self.testConfig['ebiz']['url']+"/OA_CGI/FNDWRR.exe?*")
            output_page.Click()
            Delay(2000)
            output_page.Keys("~f")
            Delay(2000)
            output_page.Keys("a")
            Delay(2000)
            file_system_utils.create_folder(self.op_log_path)             
            log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"File"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"_%d%b%Y_%H%M")+".txt"    
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
            Delay(1000)
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
            Delay(1000)
            Log.Enabled=True
            Log.File(log_path, aqConvert.VarToStr(srch_child_name)+" Output File Attached")
            Log.Enabled=False     
            self.browser.page("*").Close()
            Filesaved = 'True'
            return                           
        elif i >=25:
           Delay(20000)
           req_form.keys("~r")

           Delay(3000)
           i=20
           val=["Name",i]
           child_name=req_form.Find(prop,val,10).wText

        else:  
           Delay(3000)
           i=i+1 


