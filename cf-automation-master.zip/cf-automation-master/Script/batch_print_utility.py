﻿import bos_print_report_params
import database_helper
import email_home_page
import email_login_page
import form_utility
import gvar
import inv_print_report_params
import keys_utility
import login_logout_utility
import oracle_responsibility_utility
import pdf_db_validation
import pdf_utility
import random
import oracle_menus_form
import submit_request_delivery_to_form
import submit_single_request_form
import tc_logs
import traceback

def load_parameters(tc_name):
    if gvar.dataprep['document_type'] == 'BOS':
        var_list = ['p_vin','p_auction_locations','p_dealer','p_dealer_name','p_group_code','p_consign_id','p_invoice_type','p_payment_status',
                   'p_localtimezone','p_rep_id','p_inv_low_date','p_inv_high_date','pdf_path','p_del_method','document_type']
    elif gvar.dataprep['document_type'] == 'INV' or gvar.dataprep['document_type'] == 'INVOICE':
        var_list = ['p_trx_src','p_vin','p_consign_id','p_inv_num_low','p_inv_num_high','p_cust_trx_low','p_cust_trx_high',
                   'p_auction_locations','p_inv_low_date','p_inv_high_date','p_dealer','p_dealer_name','p_group_code',
                   'p_invoice_type','p_payment_status','p_rep_id','pdf_path','p_del_method','document_type']
                 
    if(gvar.dataprep['p_del_method'] == 'EMAIL'):
        gvar.store('email_cnt','1') 
                   
    for idx,param in enumerate(var_list):
        if(param == 'pdf_path'):
            gvar.store(param,'Z:\\G2G\\TC_results\\'+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y")+"\\"+gvar.dataprep['env']+"\\"+tc_name+"\\pdf")
        elif(param != 'document_type' and param != 'p_del_method'):
            gvar.store(param,'')
    return var_list  

def print_parameters(var_list):
    for idx,param in enumerate(var_list):
        if(gvar.dataprep[param] != ''):
            message = param + ' : '+ gvar.dataprep[param]
            tc_logs.test_data(message)
                       
def get_dealer_name():
    results = database_helper.get_customer_details(gvar.dataprep['p_dealer'])
    gvar.dataprep['p_dealer_name'] = results[0]['ACCOUNT_NAME'] 
  
def run_batchprint_pgm_and_validate():
    refid_email = batch_print_utility.submit_man_ar_print_report()
    if(gvar.dataprep['p_del_method'] is not None and gvar.dataprep['p_del_method'] == "EMAIL"):
        check_email(refid_email)
    pdf_db_validation.count_validation()

def submit_man_ar_print_report():  
    login_logout_utility.oracle_login()
    oracle_responsibility_utility.ar_home_office_super_user('Run')
    form_utility.get_java_parent_form()
    form_utility.close_notification_object()
    form_utility.submit_single_request()
    if(gvar.dataprep['document_type'] == 'BOS'):
        submit_job_bos()
    elif(gvar.dataprep['document_type'] == 'INV' or gvar.dataprep['document_type'] == 'INVOICE'):
        submit_job_inv()
    keys_utility.press_ok_button()
    refid_email = set_delivery_opt_email()
    keys_utility.press_alt_m()
    validate_specific_request()
    form_utility.close_form()
    login_logout_utility.oracle_logout()
    return refid_email

def submit_job_inv():
    submit_single_request_form.request_name_textfield().Keys('MAN: AR Invoice Print Report')
    keys_utility.press_tab()
    inv_parameters()
                                                  
def submit_job_bos():
    submit_single_request_form.request_name_textfield().Keys('MAN: AR Bill of Sales Print Report')
    keys_utility.press_tab()
    bos_parameters()

def bos_parameters():
    parameters_values = [{bos_print_report_params.vin_text_field():gvar.dataprep['p_vin']},
                        {bos_print_report_params.sales_order_low_text_field():''},
                        {bos_print_report_params.sales_order_high_text_field():''},
                        {bos_print_report_params.auction_codes_text_field():gvar.dataprep['p_auction_locations']},
                        {bos_print_report_params.ordered_date_low_text_field():''},
                        {bos_print_report_params.ordered_date_high_text_field():''},
                        {bos_print_report_params.customer_name_text_field():gvar.dataprep['p_dealer_name']},
                        {bos_print_report_params.group_code_text_field():gvar.dataprep['p_group_code']},
                        {bos_print_report_params.consignment_id_text_field():gvar.dataprep['p_consign_id']},
                        {bos_print_report_params.invoice_type_text_field():gvar.dataprep['p_invoice_type']},
                        {bos_print_report_params.payment_status_text_field():gvar.dataprep['p_payment_status']},
                        {bos_print_report_params.local_time_zone_text_field():gvar.dataprep['p_localtimezone']},
                        {bos_print_report_params.buyer_rep_id_text_field():gvar.dataprep['p_rep_id']},
                        {bos_print_report_params.sales_from_date_low_text_field():gvar.dataprep['p_inv_low_date']},
                        {bos_print_report_params.sales_to_date_high_text_field():gvar.dataprep['p_inv_high_date']}]
                      
    for idx,param in enumerate(parameters_values):
        for key,value in param.items():
            if not value:
                keys_utility.press_tab()
            else:
                if key.Exists:
                    key.Keys(value)
                    keys_utility.press_tab()
                    tc_logs.checkpt_with_no_picture(key.AWTComponentAccessibleName+" : "+value)
                    if key.AWTComponentAccessibleName == bos_print_report_params.customer_name_text_field().AWTComponentAccessibleName:
                        set_customer_names()
                   
##customername
def set_customer_names():
    if bos_print_report_params.customer_name_window().Exists and bos_print_report_params.customer_name_window().Visible:
        keys_utility.press_tab_n_times(4)
        text = "%"+VarToStr(gvar.dataprep['p_dealer_name'])+"%"+VarToStr(gvar.dataprep['p_dealer'])+"%"
        bos_print_report_params.find_text_field().Click()
        bos_print_report_params.find_text_field().Keys(text)
        keys_utility.press_alt_f()
#       bos_print_report_params.find_button().Click()
        keys_utility.press_ok_button()


def inv_parameters():
    parameters_values = [{inv_print_report_params.transaction_src_text_field():gvar.dataprep['p_trx_src']},
                        {inv_print_report_params.vins_text_field():gvar.dataprep['p_vin']},
                        {inv_print_report_params.consignmentid_text_field(): gvar.dataprep['p_consign_id']},
                        {inv_print_report_params.inv_or_order_low_text_field():gvar.dataprep['p_inv_num_low']},
                        {inv_print_report_params.inv_or_order_high_text_field():gvar.dataprep['p_inv_num_high']},
                        {inv_print_report_params.cust_trx_or_order_head_low_text_field():gvar.dataprep['p_cust_trx_low']},
                        {inv_print_report_params.cust_trx_or_order_head_high_text_field():gvar.dataprep['p_cust_trx_high']},
                        {inv_print_report_params.auction_codes_text_field():gvar.dataprep['p_auction_locations']},
                        {inv_print_report_params.invoice_date_from_text_field():gvar.dataprep['p_inv_low_date']},
                        {inv_print_report_params.invoice_date_to_text_field():gvar.dataprep['p_inv_high_date']},
                        {inv_print_report_params.customer_number_text_field():gvar.dataprep['p_dealer']},
                        {inv_print_report_params.group_code_text_field():gvar.dataprep['p_group_code']},
                        {inv_print_report_params.inv_types_text_field():gvar.dataprep['p_invoice_type']},
                        {inv_print_report_params.pay_status_text_field():gvar.dataprep['p_payment_status']},
                        {inv_print_report_params.buyer_repid_text_field():gvar.dataprep['p_rep_id']}]
    
    for idx,param in enumerate(parameters_values):
        for key,value in param.items():
            if not value:
                keys_utility.press_tab()
            else:
                if key.Exists:
                    key.Keys(value)
                    keys_utility.press_tab()
                    tc_logs.checkpt_with_no_picture(key.AWTComponentAccessibleName+" : "+value)

def set_delivery_opt_email():
    refid_email = VarToStr(random.randint(1,100000))
    if(gvar.dataprep['p_del_method'] and gvar.dataprep['p_del_method'] == "EMAIL"):    
        gvar.dataprep['jformobject'].Keys("~y")
        keys_utility.press_alt_m()
        submit_request_delivery_to_form.email_tab_from_textfield().Click()
        tc_logs.checkpt_with_no_picture("Reference number to check in gmail: "+refid_email)
        keys_utility.press_tab()
        if(gvar.dataprep['document_type'] == 'BOS'):
            text = 'MAN: AR Bill of Sales Print Report : - '+refid_email
        elif(gvar.dataprep['document_type'] == 'INV' or gvar.dataprep['document_type'] == 'INVOICE'):
            text = 'MAN: AR Invoice Print Report : - '+refid_email
        submit_request_delivery_to_form.email_tab_subject_textfield().Keys(text)
        keys_utility.press_tab()
        submit_request_delivery_to_form.email_tab_to_textfield().Keys(gvar.config['email']['usrid'])
        if(gvar.dataprep['email_cnt'] is not None and aqConvert.StrToInt(gvar.dataprep['email_cnt'])>1):
            keys_utility.press_tab_n_times(2)
            submit_request_delivery_to_form.email_tab_to_textfield().Keys(gvar.config['email']['usrid1'])
        keys_utility.press_ok_button()
    return refid_email
 
def validate_specific_request():
    Request_id = form_utility.extract_digits_awtcomponentaccessiblename(oracle_menus_form.decision_choicebox())
    tc_logs.checkpt_with_picture(f"Job Submitted Successfully with the RequestId: {Request_id}","",oracle_menus_form.decision_choicebox())
    keys_utility.press_no_button()
    form_utility.get_specific_request_details(Request_id)
    tc_logs.validation("***VALIDATION FOR SUCCESSFUL COMPLETION OF CONCURRENT JOB***")
    job_completed = database_helper.get_requestid_details(Request_id)
    if job_completed:
        keys_utility.press_alt_r()
        keys_utility.press_alt_p()
        aqUtils.Delay(1000)
        tc_logs.checkpt_with_picture("PDF output generated Successfully","",Sys.Browser("iexplore").BrowserWindow(0))
        if(gvar.dataprep['p_del_method'] != "EMAIL"):
            pdf_utility.download_pdf_output()
    else: 
        keys_utility.press_alt_g()
        aqUtils.Delay(1000)
        tc_logs.error_with_picture("Job Failed for RequestID: "+Request_id+" Please check the error and try again"+traceback.format_exc(),"",Sys.Browser("iexplore").BrowserWindow(0))

def check_email(refid_email):
    login_logout_utility.email_login()
    aqUtils.Delay(5000)
    email_home_page.search_textbox().Keys(refid_email)
    keys_utility.press_enter(gvar.dataprep['page'])
    aqUtils.Delay(2000)
    email_home_page.searched_email()[0].Click()
    aqUtils.Delay(2000)
    email_home_page.pdf_attachment_image()[0].Click()
    email_home_page.download_attachments()[0].Click()
    aqUtils.Delay(2000)
    Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Notification Bar", "", 1).UIAObject("Notification").UIAObject("Save").UIAObject(1).Click()
    Sys.Keys("[Down][Enter]")
    pdf_utility.download_pdf_output()
    aqUtils.Delay(1000)
    email_home_page.navigate_back_to_home()[0].Click()
    aqUtils.Delay(1000)
    login_logout_utility.email_logout() 

