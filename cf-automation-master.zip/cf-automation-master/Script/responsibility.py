﻿import web_utility
#import config 
import tc_logs
import oracle_home_page
import responsibility


def set_xpath( id, textvalue):
  return "//a[@id='"+VarToStr(id)+"' and contains(text(),'"+textvalue.strip()+"')]".strip()

def click_transactions(page):
 xpath_value = 'Transactions'
 xpath_value ="//a[@id='N86' and contains(text(),'"+xpath_value.strip()+"')]"
 web_utility.click_link_by_xpath( page, xpath_value)
 aqUtils.Delay(50000)
 Log.Message("Click 'AR Home Office Super User' - successfull")

def click_run(page):
 aqUtils.Delay(1000)
# xpath_value = 'Run'
# xpath_value ="//a[@id='N1784' and contains(text(),'"+xpath_value.strip()+"')]"
# web_utility.click_link_by_xpath( page, xpath_value)
 web_utility.click_link_by_contenttext(page,"Run")
 page.wait()
 aqUtils.Delay(15000)
 Log.Checkpoint("Click action successfully performed on 'Run request' - link")

def click_eligibility_details(page):
 xpath_value = 'Eligibility Details'
 xpath_value ="//a[@id='N62' and contains(text(),'"+xpath_value.strip()+"')]"
 web_utility.click_link_by_xpath( page, xpath_value)
 aqUtils.Delay(15000)
 Log.Checkpoint(("Click action successfully performed on 'Eligibility Details' - link"),"",pmNormal,"",page)
 
def click_sales_orders(page):
 xpath_value = 'Sales Orders'
 xpath_value ="//a[@id='N98' and contains(text(),'"+xpath_value.strip()+"')]"
 web_utility.click_link_by_xpath( page, xpath_value)
 aqUtils.Delay(15000)
# Log.Checkpoint("Click action successfully performed on 'Sales Orders' - link","",pmNormal,"",page)
  
def click_ar_home_office_super_user(page,sub_child_action):
  xpath_value = 'AR Home Office Super User'
  xpath_value = "//a[@id='AppsNavLink' and contains(text(),'"+xpath_value.strip()+"')]"
  web_utility.click_link_by_xpath( page, xpath_value)
  Log.Checkpoint(("Click action successfully performed on 'AR Home Office Super User' -link"),"",pmNormal,"",page)
  if sub_child_action == 'Run':
    click_run(page)
  elif sub_child_action == 'Transactions':
    click_transactions(page)
    
def click_ar_floorplan_setup(page,sub_child_action):
  xpath_value = 'AR Floorplan Setup'           
  xpath_value = "//a[@id='AppsNavLink' and contains(text(),'"+xpath_value.strip()+"')]"
  web_utility.click_link_by_xpath( page, xpath_value)
  Log.Checkpoint(("Click action successfully performed on 'AR Floorplan Setup' - link"),"",pmNormal,"",page)
  if sub_child_action == 'Eligibility Details':
    click_eligibility_details(page)

def click_receivables_manager(page,sub_child_action):
  xpath_value = 'Receivables Manager'           
  xpath_value = "//a[@id='AppsNavLink' and contains(text(),'"+xpath_value.strip()+"')]"
  web_utility.click_link_by_xpath( page, xpath_value)
  page.wait()
  Log.Checkpoint("Click action successfully performed on 'Receivables Manager' - link")
  if sub_child_action == 'Credit Availability':
    click_credit_availability(page)

def click_credit_availability(page):
 xpath_value = 'Credit Availability'
 xpath_value ="//a[@id='N2001' and contains(text(),'"+xpath_value.strip()+"')]"
 web_utility.click_link_by_xpath( page, xpath_value)
 aqUtils.Delay(15000)
 Log.Checkpoint("Click action successfully performed on 'Credit Availability' - link")
    
def close_java_web_page():
  Sys.Browser().Page(config.TRND_EBIZ_URL['javaUrl']).Close();

def click_home(page):
  web_utility.click_link_by_contenttext(page,'Home')
  page.wait()
  Log.Checkpoint(("Click action sucessfully performed on 'Home' - link"),"",pmNormal,"",page)

def click_status_monitor(page):
  web_utility.click_link_by_xpath( page, set_xpath('N67','Status Monitor'))
  page.wait()
  Log.Checkpoint("Click action sucessfully performed on 'status monitor' - link")
  
def click_notifications(page):
  web_utility.click_link_by_xpath( page, set_xpath('N73','Notifications'))
  page.wait()
  Log.Checkpoint("Click action sucessfully performed on 'Notifications' - link")

def click_administration(page):
  web_utility.click_link_by_xpath( page, set_xpath('N79','Administration'))
  page.wait()
  Log.Checkpoint("Click action sucessfully performed on 'Administration' - link")

def click_business_events(page):
  web_utility.click_link_by_xpath( page, set_xpath('N61','Business Events'))
  page.wait()
  Log.Checkpoint("Click action sucessfully performed on 'Business Events' - link")

 
def click_developer_studio(page):
  web_utility.click_link_by_xpath( page,set_xpath('N55','Developer Studio'))
  page.wait()
  Log.Checkpoint("Click action sucessfully performed on 'Home' - link")
  

def click_workflow_administrator_web_new(page,sub_child_action):
  
  xpath_value = set_xpath('AppsNavLink','Workflow Administrator Web (New)') 
  web_utility.click_link_by_xpath( page, xpath_value)
  Log.Checkpoint("Click action sucessfully performed on 'Workflow Administrator Web (New)' - link")
  
  if (sub_child_action == 'Status Monitor'):
             click_status_monitor(page)
  elif(sub_child_action == 'Notifications'):    
             click_notifications(page)
  elif(sub_child_action == 'Administration'):    
             click_administration(page)
  elif(sub_child_action == 'click_business_events'):
             click_business_events(page)
  elif(sub_child_action == 'Home'):
             click_home(page)
  elif(sub_child_action == 'Developer Studio'):     
             click_developer_studio(page)

def click_om_super_user(page,sub_child_action):
  xpath_value = 'Order Management Super User'
  xpath_value = "//a[@id='AppsNavLink' and contains(text(),'"+xpath_value.strip()+"')]"
  web_utility.click_link_by_xpath( page, xpath_value)
  Log.Checkpoint(("Click action successfully performed on 'Order Management Super User' -link"),"",pmNormal,"",page)
  if sub_child_action == 'Sales Orders':
    click_sales_orders(page)

def click_consignment_manager(page):
  #web_utility.find_link_by_contenttext('Consignment Manager').click()
  #web_utility.find_by_contenttext('Consignment Manager').scrollIntoView()
#  web_utility.find_by_contenttext('Consignment Manager').click()
#  page.wait()
#  tc_logs.checkpt_with_no_picture("Click action successfully performed on 'Consignment Manager' - link")
   oracle_home_page.consignment_manager_link().scrollIntoView()
   aqUtils.Delay(1000)
   oracle_home_page.consignment_manager_link().Click()
   

def ar_home_office_super_user(sub_child_action):
    oracle_home_page.ar_home_office_super_user_link().Click()
    aqUtils.Delay(5000)
    tc_logs.checkpt_with_no_picture("Navigate to AR Home Office Super User Responsibility")
    if sub_child_action == 'Run':
       oracle_home_page.control_requests_run_link().Click()
       aqUtils.Delay(20000)
       tc_logs.checkpt_with_no_picture("Click 'Control: Requests Run' - Successful")
    elif sub_child_action == 'Transactions':
         oracle_home_page.transactions_link()[1].Click()
         aqUtils.Delay(20000)
         tc_logs.checkpt_with_no_picture("Opened Transactions Form")
