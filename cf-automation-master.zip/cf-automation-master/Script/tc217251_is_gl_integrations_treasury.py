﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils
import winscp_utility
import tc_logs
from File_Handler import File_Handler as _TXTOBJ
from text_headers import payroll_txt_file_header as _HEADERS


class tc217251_is_gl_integrations_treasury(Ebiz):
    
  op_log_path="C:\\TC_Logs"
  is_pay_tsry_files="C:\\IS_Trsy_Files"
  
  def login(self):
      self.login_user="mfallwell"
      super().login()
  
  def goto_url(self,url):
         super().goto_url(self.testConfig['ebiz']['oci_is_url'])

  def action(self,book):
    self.files = ["CTMUS_0_A_MAY-2020_05.DAT"]
    self.place_files_local()
    self.process_files()
    self.place_files_winscp()
    self.validate_journal_ebiz()
    
## Place Payroll Files in Local Folder:
  def place_files_local(self):   
      file_system_utils.create_folder(self.is_pay_tsry_files)
      file_exist=aqFileSystem.FindFiles("C:\\IS_Trsy_Files","CTMUS_0_A_MAY-2020_05.DAT")
      if file_exist != None:
       aqFileSystem.DeleteFile("C:\\IS_Trsy_Files\\CTMUS_0_A_MAY-2020_05.DAT")
      aqFileSystem.CopyFile(Project.Path+"DataSheets\\Oracle-GL-Journal\\CTMUS_0_A_MAY-2020_05.DAT", "C:\\IS_Trsy_Files\\CTMUS_0_A_MAY-2020_05.DAT")
      log_path = ("C:\\IS_Trsy_Files\\CTMUS_0_A_MAY-2020_05.DAT")
      Log.Enabled=True
      Log.File(log_path, "Treasury File CTMUS_0_A_MAY-2020_05.DAT Attached")
      Log.Enabled=False 

## Read/Modify/Write Payroll Files:
#  def process_files(self):  
#    def counter(index,**kwargs):
#      import datetime as dt 
#      import random
#      kwargs['REFERENCE21'] = int(dt.datetime.now().strftime("%Y%m%d%H%M%S%f"))+int(index)
#      return kwargs 
#    path = "C:\IS_Trsy_Files\\CTMUS_TEST.DAT"
#    cobj = _TXTOBJ(path,"|")
#    cobj.Write_txt_without_header([counter(index+1,**row) for index, row in enumerate(
#            cobj.Read_txt_with_header(_HEADERS()))]) 

  def process_files(self):
    import re
    from datetime import datetime
    path = "C:\IS_Trsy_Files\\CTMUS_0_A_MAY-2020_05.DAT"
    acc_date=datetime.now().strftime("%m/%d/%Y")
    acc_month_date=datetime.now().strftime("%b/%d/%Y")
    acc_period=str(datetime.now().strftime("%b-%Y"))
    acc_period=acc_period.upper()
    str_20_len=datetime.now().strftime("%Y%m%d%H%M%S%f")
    
    Read_lines=[]
    Write_lines=[]
    with open(path,'r') as fr:
        Read_lines=fr.readlines()
        for line in Read_lines:
            date_modified_str=re.sub(r'\d{2}/\d{2}/\d{4}',acc_date,line)
            period_modified_str=re.sub(r'[A-Za-z]{3}-\d{2,4}',acc_period,date_modified_str)
            month_modified_str=re.sub(r'[A-Za-z]{3}/\d{2}/\d{2,4}',acc_month_date,period_modified_str)
            str_20_modified=re.sub(r'26071.{1,4}',str_20_len,month_modified_str)
            str_20_len=str(int(str_20_len)+1) # The 20 digit number at the end in each record should have a unique number, so incrementing 1 for each record
            Write_lines.append(str_20_modified)
    
    with open(path,'w') as fw:
        fw.writelines(Write_lines)


## Place Payroll Files in WinScp:
  def place_files_winscp(self):
      Stored_session = "cei_oracle@mftstg.manheim.com" 
      local_dir = "C:\\IS_Trsy_Files"
      remote_dir =  self.testConfig['winscp']['remote_dir'] 
#      remote_dir = "//Outbox//SMNH2I"
      upload_file_name = "C:\\IS_Trsy_Files\\CTMUS_0_A_MAY-2020_05.DAT"
      winscp_utility.upload_file(Stored_session,local_dir,remote_dir,upload_file_name)
      Log.Enabled=True       
      Log.Message("Treasury File CTMUS_0_A_MAY-2020_05.DAT placed in the " +remote_dir+ " directory")           
      Log.Enabled=False

## Login to Oracle EBIZ and select the responsibility
  def validate_journal_ebiz(self):
#    is_gl_submit_link=self.page.NativeWebObject.Find("contentText","GL SCHEDULER","A")
#    self.verify_aqobject_chkproperty(is_gl_submit_link,"contentText",cmpIn,"GL SCHEDULER")
#    is_gl_submit_link.Click() 
#    web_utils.log_checkpoint("Click 'GL SCHEDULER' - Successful",500,self.page) 
#    Delay(1000)  
    self.page.EvaluateXpath("//table[@id='respList']//div[contains(text(),'GL SCHEDULER')]")[0].scrollIntoView()
    self.page.EvaluateXpath("//table[@id='respList']//div[contains(text(),'GL SCHEDULER')]")[0].Click()
    web_utils.log_checkpoint("Click 'GL SCHEDULER' - Successful",500,self.page)
    delay(1000)    
     
    self.page.Wait()
    self.page.NativeWebObject.Find("contentText","Requests","A").Click()
    web_utils.log_checkpoint("Click 'Requests' - Successful",500,self.page) 
  
    self.page.Wait()
    self.page.NativeWebObject.Find("contentText","Run","A").Click()
    web_utils.log_checkpoint("Click 'Run' - Successful",500,self.page) 
    
    web_utils.validate_security_box()
    jFrame= self.initializeJFrame()
    Delay(5000)

    form_utils.click_ok_btn(jFrame)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit a New Request","ExtendedFrame"]
    submit_new_req_form=jFrame.FindChildEx(prop,val,60,True,90000)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["What type of request do you want to run? Request Set alt s","ExtendedCheckbox"]  
    submit_new_req_form.FindChild(prop,val,10).Click()       
    Delay(1000)
    submit_new_req_form.FindChild("AWTComponentAccessibleName","OK alt O",10).Click()

    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit Request Set","ExtendedFrame"]
    par_form=jFrame.FindChild(prop,val,60)
    par_form.Find("AWTComponentAccessibleName","Request Set RequiredList of Values",30).SetText("MAN Oracle GL Inbound JE Interface Request Set - CT")
    delay(1000)
    
    jFrame.Keys("[Tab]")
    delay(1000)
    self.log_message_oracle_form(jFrame,"Entered Request Set 'MAN Oracle GL Inbound JE Interface Request Set - CT'") 
    
    par_form=jFrame.FindChild(prop,val,60)
    par_form.Find("AWTComponentAccessibleName","Submit",30).Click()
    form_utils.click_ok_btn(jFrame)    
#    self.log_message_oracle_form(jFrame,"MAN Oracle GL Inbound JE Interface Request Set - CT")   
    delay(3000)
    
    RequestID = aqConvert.VarToInt(''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit()))
    Log.Message("Request ID" + aqConvert.VarToStr(RequestID))
    self.log_checkpoint_message_web("Request ID Of MAN Oracle GL Inbound JE Interface Request Set - CT " + aqConvert.VarToStr(RequestID))
    Delay(2000)
    jFrame.Keys("~n")
    delay(20000)
    
    dsn = self.testConfig['man_oracle_db']['dsn']
    user_id = self.testConfig['man_oracle_db']['userid']
    pwd = self.testConfig['man_oracle_db']['pwd']
    dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,VarToStr(RequestID))
    
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000) 
    
#    delay(160000)   
  # Gathering Request ID and Output File for the "MAN Oracle GL Inbound JE Interface Request Set - PeopleSoft Harmony"   
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,90000) 
    
    self.req_set_save_output(jFrame,req_form,"MAN Oracle Generic GL Preprocessor Program",RequestID)
#    delay(5000)
    delay(2000)
    self.req_set_save_output(jFrame,req_form,"MAN Oracle GL Inbound JE Interface Program",RequestID) 
    delay(2000)
    
  # Gathering Request ID and Output File for the "GL Child Program"
#    self.req_set_save_output(jFrame,req_form,"####",RequestID)

  # Gathering Request ID and Output File for the "Journal Import Program"  
    creqid1 = self.req_set_save_output(jFrame,req_form,"Journal Import",RequestID)
    journal_req_ids = []
    journal_req_ids.append(creqid1)    
    
# Code to check journal_req_ids has empty values

    if any(journal_req_ids) == False:
           web_utils.log_error("Not able to get Journal import batch name")
      
  # Gathering Request ID and Output File for the "Posting: Single Ledger" 
#    self.req_set_save_output(jFrame,req_form,"Posting: Single Ledger",RequestID)  
  
   
    Delay(1000)
    jFrame.Close()
    Delay(1000)
    jFrame.Close()
    Delay(1000)
    jFrame.Keys("~o")
    Delay(1000) 
    
    # Navigate to journal from frontEnd
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'GL Corporate Accounting User')]")
    web_utils.log_checkpoint("Click 'GL Corporate Accounting User' - Successful",500,self.page)
    Delay(3000)
    self.page.EvaluateXpath("//table[@id='respList']//div[text()='Journals']")[0].Click()
    web_utils.log_checkpoint("Click 'Journals' - Successful",500,self.page)
    Delay(2000)
    self.page.EvaluateXpath("//table[@id='respList']//div[text()='Enter']")[0].Click()
    web_utils.log_checkpoint("Click 'Enter' - Successful",500,self.page)
    
    web_utils.validate_security_box()
    delay(2000)
    jFrame=self.initializeJFrame()
    delay(2000)
    form_utils.click_ok_btn(jFrame)
    
    for x in journal_req_ids:
              
      dsn = self.testConfig['man_oracle_db']['dsn']
      user_id = self.testConfig['man_oracle_db']['userid']
      pwd = self.testConfig['man_oracle_db']['pwd']
      batch_name = dbhelper.return_journal_batch_name(dsn,user_id,pwd,"%"+VarTostr(x))
      res= aqString.Find(batch_name,"CTM")
      if res != -1:            
        prop=["AWTComponentAccessibleName","JavaClassName"]
        val=["Find Journals","ExtendedFrame"]
        fnd_jrnl=jFrame.FindChildEx(prop,val,60,True,90000)
        fnd_jrnl.Find("AWTComponentAccessibleName","BatchList of Values",10).Click()
        fnd_jrnl.Find("AWTComponentAccessibleName","BatchList of Values",10).Keys("%"+VarToStr(x)+"%")
        delay(1000) 
        jFrame.Keys("~i")
        web_utils.log_checkpoint(VarToStr(x)+" find Journal Successful",500,jFrame)
        delay(8000) 
        jFrame.Keys("~u")
        delay(4000) 
        prop=["AWTComponentAccessibleName","JavaClassName"]
        val=["Journals (MAN GLB ALL)*","ExtendedFrame"]
        jrnls=jFrame.FindChildEx(prop,val,60,True,60000)
        jrnls.FindChild("AWTComponentName","FormsTabPanel*",60).ClickTab("Other Information")
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Status: Approval",2]
        jrnl_appr_val = jFrame.FindChild(prop,val,60)
        jrnl_appr_status=jrnl_appr_val.wText  
        web_utils.log_checkpoint("Journal Approval Status: "+jrnl_appr_status,500,jFrame)  
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Status: Posting",0]
        jrnl_val = jFrame.FindChild(prop,val,60)
        jrnl_status=jrnl_val.wText  
#            self.log_message_oracle_form(jFrame,"Journal Status: "+jrnl_status)
#            web_utils.log_checkpoint("Journal Status: "+jrnl_status,500,jFrame)   
        Log.Enabled=True
        aqObject.CheckProperty(jrnl_val,"wText",cmpIn,"Unposted")
        Log.Enabled=False
#            self.log_message_oracle_form(jFrame,VarToStr(x)+" Journal is Posted")
        web_utils.log_checkpoint(VarToStr(x)+" Journal is Unposted",500,jFrame)
        delay(4000) 
        jrnls.FindChild("AWTComponentName","FormsTabPanel*",60).ClickTab("Lines")
        delay(4000) 
#            self.log_message_oracle_form(jFrame,"Reviewing Journal Header and Lines Information in "+VarToStr(x))
        web_utils.log_checkpoint("Reviewing the Journal Header and Lines Information in "+VarToStr(x),500,jFrame)
#        prop=["AWTComponentAccessibleName","JavaClassName"]
#        val=["Journals (MAN GLB ALL)*","ExtendedFrame"]
#        jrnls=jFrame.FindChildEx(prop,val,30,True,60000)
#        prop=["JavaClassName","AWTComponentIndex"]
#        val=["LWScrollbar","0"]
#        down_button=jrnls.FindChildEx(prop,val,30,True,60000)
#        for i in range(0,10):
#          prop=["JavaClassName","AWTComponentIndex"]
#          val=["ContinuousButton","0"]
#          down_button.Find(prop,val,20).Click()  
#        self.log_message_oracle_form(jFrame,"Intracompany balancing line added by Posting in "+VarToStr(x))        
        delay(4000) 
    
    web_utils.log_checkpoint("Post the Journal next",500,jFrame)
    jFrame.Keys("~p")
    delay(10000)
    RequestID = aqConvert.VarToInt(''.join(x for x in jFrame.find("AWTComponentAccessibleName","Your concurrent request ID*",100).AWTComponentAccessibleName if x.isdigit()))
    web_utils.log_checkpoint("'Posting: Single Ledger' is submitted and Request ID is " + aqConvert.VarToStr(RequestID),500,jFrame)
    Delay(2000)
    Rid =aqConvert.VarToStr(RequestID)
    jFrame.Keys("~o")
    Delay(20000)  
    dsn = self.testConfig['man_oracle_db']['dsn']
    user_id = self.testConfig['man_oracle_db']['userid']
    pwd = self.testConfig['man_oracle_db']['pwd']
    dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,RequestID)
    delay(1000) 
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,90000)
    delay(3000)
    self.req_set_save_output(jFrame,req_form,"Posting: Single Ledger",RequestID)
    Delay(3000)
    jFrame.Click()
    Delay(2000)
    jFrame.Keys("[F4]")
    Delay(2000)

# Review the Journal back and validating it got posted
    
    jFrame.Keys("j")
    delay(2000) 
    jFrame.Keys("e")
    delay(2000)
    
    for x in journal_req_ids:
                  
          dsn = self.testConfig['man_oracle_db']['dsn']
          user_id = self.testConfig['man_oracle_db']['userid']
          pwd = self.testConfig['man_oracle_db']['pwd']
          batch_name = dbhelper.return_journal_batch_name(dsn,user_id,pwd,"%"+VarTostr(x))
          res= aqString.Find(batch_name,"CTM")
          if res != -1:            
            prop=["AWTComponentAccessibleName","JavaClassName"]
            val=["Find Journals","ExtendedFrame"]
            fnd_jrnl=jFrame.FindChildEx(prop,val,60,True,90000)
            fnd_jrnl.Find("AWTComponentAccessibleName","BatchList of Values",10).Click()
            fnd_jrnl.Find("AWTComponentAccessibleName","BatchList of Values",10).Keys("%"+VarToStr(x)+"%")
            delay(1000) 
            jFrame.Keys("~i")
            web_utils.log_checkpoint(VarToStr(x)+" find Journal Successful",500,jFrame)
            delay(8000) 
            jFrame.Keys("~u")
            delay(4000) 
            prop=["AWTComponentAccessibleName","JavaClassName"]
            val=["Journals (MAN GLB ALL)*","ExtendedFrame"]
            jrnls=jFrame.FindChildEx(prop,val,60,True,60000)
            jrnls.FindChild("AWTComponentName","FormsTabPanel*",60).ClickTab("Other Information")
            prop=["AWTComponentAccessibleName","AWTComponentIndex"]
            val=["Status: Approval",2]
            jrnl_appr_val = jFrame.FindChild(prop,val,60)
            jrnl_appr_status=jrnl_appr_val.wText  
            web_utils.log_checkpoint("Journal Approval Status: "+jrnl_appr_status,500,jFrame)  
            prop=["AWTComponentAccessibleName","AWTComponentIndex"]
            val=["Status: Posting",0]
            jrnl_val = jFrame.FindChild(prop,val,60)
            jrnl_status=jrnl_val.wText  
    #            self.log_message_oracle_form(jFrame,"Journal Status: "+jrnl_status)
    #            web_utils.log_checkpoint("Journal Status: "+jrnl_status,500,jFrame)   
            Log.Enabled=True
            aqObject.CheckProperty(jrnl_val,"wText",cmpIn,"Posted")
            Log.Enabled=False
    #            self.log_message_oracle_form(jFrame,VarToStr(x)+" Journal is Posted")
            web_utils.log_checkpoint(VarToStr(x)+" Journal is Posted",500,jFrame)
            delay(4000) 
            jrnls.FindChild("AWTComponentName","FormsTabPanel*",60).ClickTab("Lines")
            delay(4000) 
    #            self.log_message_oracle_form(jFrame,"Reviewing Journal Header and Lines Information in "+VarToStr(x))
            web_utils.log_checkpoint("Reviewing the Journal Header and Lines Information in "+VarToStr(x),500,jFrame)
            delay(2000)
    
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~o")
    Delay(1000)
    
  def req_set_save_output(self,jFrame,req_form,srch_child_name,Preqid,journal_req_ids=[]):
       
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val = ["Refresh Data alt R","Button"]
     req_form.FindChild(prop,val,2000).Click()
       
     for x in range(20,51):
         
       if x>29:
         jFrame.Keys("[Down]")        
         x=29
                      
       prop=["AWTComponentAccessibleName","AWTComponentIndex"]
       val=["Phase",x+20]
       phase=req_form.Find(prop,val,10).wText 
         
       prop=["AWTComponentAccessibleName","AWTComponentIndex"]
       val=["Request ID",x-10]
       creqid=VarToInt(req_form.Find(prop,val,10).wText)
         
       prop=["AWTComponentAccessibleName","AWTComponentIndex"]
       val=["Name",x]
       child_name=req_form.Find(prop,val,10).wText
       req_form.Find(prop,val,10).Click()
         
       prop=["AWTComponentAccessibleName","AWTComponentIndex"]
       val=["Status",x+30]         
       status =req_form.FindChild(prop,val,60) 
         
       if (child_name==srch_child_name) and (creqid>=Preqid) and (creqid not in journal_req_ids)and (phase == "Completed"): 
           
         self.log_message_oracle_form(req_form,aqConvert.VarToStr(srch_child_name)+" Phase Completed Successfuly")            
         self.verify_aqobject_chkproperty(status,"wText",cmpIn,"Normal,Warning")
         self.log_message_oracle_form(req_form,"Request ID of "+aqConvert.VarToStr(srch_child_name)+" is "+aqConvert.VarToStr(creqid))
         req_form.Find(prop,val,10).Keys("[Enter]")
         Delay(1000)
         prop=["AWTComponentAccessibleName","JavaClassName"]
         val=["View Output alt p","Button"]
         output_button=req_form.FindChild(prop,val,60)
         output_button.Find("AWTComponentAccessibleName","View Output alt p").Click()     
         Delay(3000)
         output_page=Sys.Browser("iexplore").Page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
         output_page.Click()
         Delay(2000)
         output_page.Keys("~f")
         Delay(2000)
         output_page.Keys("a")
         Delay(5000)
         file_system_utils.create_folder(self.op_log_path)             
         log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"Is Attached_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
         Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
         Delay(1000)
         Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
         Delay(6000)
         Log.Enabled=True
         Log.File(log_path, aqConvert.VarToStr(srch_child_name)+" Output File Attached")
         Log.Enabled=False    
         Sys.Browser("iexplore").page("https://core-*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close() 
         web_utils.close_additional_browsers() 
         Delay(2000)   
         jFrame.Click()
         Delay(2000)
         return creqid
           
  def req_set_save_log(self,jFrame,req_form,srch_child_name,Preqid,type=""):
    
      prop=["AWTComponentAccessibleName","JavaClassName"]
      val = ["Refresh Data alt R","Button"]
      req_form.FindChild(prop,val,2000).Click() 
         
      for x in range(20,51):
          
        if x>29:
          jFrame.Keys("[Down]")        
          x=29
                        
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Phase",x+20]
        phase=req_form.Find(prop,val,10).wText
           
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Request ID",x-10]
        creqid=VarToInt(req_form.Find(prop,val,10).wText)
          
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Name",x]
        child_name=req_form.Find(prop,val,10).wText
        req_form.Find(prop,val,10).Click()
            
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Status",x+30]         
        status =req_form.FindChild(prop,val,60)
          
        if (child_name==srch_child_name) and (creqid>=Preqid) and (phase == "Completed"): 
            
          self.log_message_oracle_form(req_form,aqConvert.VarToStr(srch_child_name)+" Phase Completed Successfuly")            
          self.verify_aqobject_chkproperty(status,"wText",cmpIn,"Normal,Warning")
          self.log_message_oracle_form(req_form,"Request ID of "+aqConvert.VarToStr(srch_child_name)+" is "+aqConvert.VarToStr(creqid))
          req_form.Find(prop,val,10).Keys("[Enter]")
          Delay(1000)
            
          prop=["AWTComponentAccessibleName","JavaClassName"]
          val=["View Log alt K","Button"]
          log_button=req_form.FindChild(prop,val,60)
          log_button.Click()     
          Delay(3000)
          output_page=Sys.Browser("iexplore").Page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
          output_page.Click()
          Log.Enabled=True
          wnd = Sys.Desktop.ActiveWindow()
          Log.Picture(wnd, f"WinScp File Location path: {type}", wnd.FullName)                 
          Log.Enabled=False
          Delay(2000)
          output_page.Keys("~f")
          Delay(2000)
          output_page.Keys("a")
          Delay(5000)
          file_system_utils.create_folder(self.op_log_path)             
          log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"Is Attached_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
          Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
          Delay(1000)
          Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
          Delay(6000)
          Log.Enabled=True
          Log.File(log_path, aqConvert.VarToStr(srch_child_name)+" Log File Attached")
          Log.Enabled=False    
          Sys.Browser("iexplore").page("https://core-*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close()  
          web_utils.close_additional_browsers()
          Delay(2000)   
          jFrame.Click()
          Delay(2000)
          return creqid


            
