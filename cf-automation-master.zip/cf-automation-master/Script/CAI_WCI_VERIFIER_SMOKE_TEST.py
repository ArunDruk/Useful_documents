﻿from base import *
from driverchain import *
from ebiz import *


class Driver(Driverchain):
  global classarr,env
  
  def __init__(self):
    global test_env, sheet_obj, book     
    app = Sys.OleObject["Excel.Application"]
    Delay(1000)
    self.book = app.Workbooks.Open(Project.Path+"\\datasheets\\E2E\\CAI__WCI_Verifier_Smoke_Test.xls")          
    app.Visible = "True"    
    self.test_env=BuiltIn.ParamStr(14)
    self.oper_unit=BuiltIn.ParamStr(15)
#    
    self.test_env="oci_dev"
    self.oper_unit="US"
    
    self.classarr=["OCI_WCI_Verifier_Smoke_Test()"]
    super().__init__(self.classarr)
        
  def close_excel(self):    
    self.book.save()
    delay(1000)
    self.book.close()
	
def main():  
  gvar.dataprep['env'] = 'oci_dev'
  obj=Driver()
  cobj = obj.run()
  obj.close_excel()
