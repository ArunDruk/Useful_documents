﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils
import web_utils
import form_utils


class tc130335_check_invoice_attachments(Ebiz):
 global rowno
 rowno = 2

 def login(self):
    self.login_user="rmaran"
    super().login()
 
 op_log_path="C:\\TC_Logs"
 
 def action(self,book): 
    app = book.Sheets.item["Invoice"]
    web_utils.log_checkpoint("Logged in to Oracle Applications Home Page Successfully",500,self.page)
    self.wait_until_page_loaded()  
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" AP INVOICE PROCESSING')]") 
    Delay(1000)  
    self.wait_until_page_loaded()           
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Invoices')]")
    Delay(1000)
    self.wait_until_page_loaded() 
    Delay(1000) 
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Entry')]")
    Delay(1000) 
    self.wait_until_page_loaded()
    self.page.EvaluateXPath("//div[text()='Invoices']")[1].Click()
    delay(10000) 
    web_utils.validate_security_box()
    delay(10000)     
    jFrame = self.initializeJFrame()
    Delay(10000)
    form_utils.click_ok_btn(jFrame)
    p_names = ("JavaClassName","AWTComponentAccessibleName")
    p_values = ("ExtendedFrame","Invoice Workbench (CAI "+self.oper_unit+" AP INVOICE PROCESSING)")
    inv_form=jFrame.FindChildEx(p_names,p_values,60,True,120000)
    Delay(2000)
    jFrame.Keys("~v")
    delay(1000)
    jFrame.Keys("f")
    delay(1000)
    
 #Finding Invoice in the invoice workbench
 
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Invoices","ExtendedFrame"]
    par_form=jFrame.FindChildEx(prop,val,60,True,60000)
    par_form.Find("AWTComponentAccessibleName","Invoice: Number",30).Click()
    Delay(4000)
    par_form.Find("AWTComponentAccessibleName","Invoice: Number",30).SetText(app.Cells.Item[rowno,13])
    jFrame.Keys("[Tab]")
    delay(3000)
    val = ["Find alt i","Button"] 
    par_form.FindChild(prop,val,60).Click()
    Delay(4000)    
    
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Type Required",8]
    inv_type=jFrame.FindChildEx(prop,val,60,True,9000000)
    Log.Enabled=True
    aqObject.CheckProperty(inv_type,"wText",cmpIn,"Standard")
    Log.Enabled=False
    self.log_message_oracle_form(jFrame,"Find Invoice Successful: "+aqConvert.VarToStr(app.Cells.Item[rowno,13]))
    Delay(4000)   
    jFrame.Keys("~v")
    Delay(2000)
    jFrame.Keys("a")
    Delay(2000)
    self.log_message_oracle_form(jFrame,"In Workbench Attachments Section : Invoice Image attached successfully")
    Delay(4000)
    jFrame.Keys("~d")
    Delay(10000)
    
    self.wait_until_page_loaded()
 # Logging into Oracle:Webcenter Imaging to view the invoice image
 
#    #Michael Bennett Changes
#    #imaging_web_page = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/imaging/faces/Authentication/Login.jspx").Panel("doc").Panel("ps_l1").Panel("c").Panel("pslForm").Panel("c").Panel("pglForm")
#    imaging_web_page = Sys.Browser("iexplore").Page("https://idcs-2937151217e14faea101528528f3a570.identity.oraclecloud.com/ui/v1/signin")
#    web_utils.log_checkpoint("Log in to 'Oracle:Webcenter Imaging next to view the image",500,imaging_web_page)
#    self.wait_until_page_loaded()
#
#    username_bx=self.page.Find("idStr","idcs-signin-basic-signin-form-username",30)
#    username_bx.Click()
#    Delay(1000)
#    username_bx.Click()
##    self.page.Find("idStr","idcs-signin-basic-signin-form-username",30).Click()
##    Sys.Keys("maha.kumar@coxautoinc.com[Tab]Oracle12345$[Enter]")
##    Sys.Keys("michael.bennett@coxautoinc.com[Tab]")
#    Sys.Keys("maha.kumar@coxautoinc.com[Tab]")
##    Sys.Keys("[Tab]")
#    Delay(400)
##    Sys.Keys("[Oracle12345$]")
##    pswd_bx=self.page.Find("idStr","idcs-signin-basic-signin-form-password|input",30)
#    pswd_bx=Sys.Browser("iexplore").Page("https://idcs*.identity.oraclecloud.com/ui/v1/signin").Panel(0).Panel("idcs_app_shell_signin_background").Panel(0).Panel(1).Panel(1).Panel(0).Panel(0).Panel(0).Panel(0).Panel(0).Panel(0).Panel(1).PasswordBox("idcs_signin_basic_signin_form_password_input")
#    pswd_bx.Click()
#    pswd_bx.Keys("password123")
#    Delay(1000)
#    pswd_bx.Keys("[Tab][Enter]")
##    login_btn=self.page.Find("idStr","ui-id-3",30)
##    login_btn.Click()
##    login_btn.Click()
#     
##    Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/imaging/faces/Authentication/Login.jspx").Panel("doc").Panel("ps_l1").Panel("c").Panel("pslForm").Panel("c").Panel("pglForm").Panel(0).Panel("formBox").Panel(0).Panel("content").Panel("pflForm").Table(0).Cell(0, 0).Table(0).Cell(1, 0).Table("usernameLabel").Cell(1, 0).Textbox("username").Click()
##    Delay(4000)
##    Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/imaging/faces/Authentication/Login.jspx").Panel("doc").Panel("ps_l1").Panel("c").Panel("pslForm").Panel("c").Panel("pglForm").Panel(0).Panel("formBox").Panel(0).Panel("content").Panel("pflForm").Table(0).Cell(0, 0).Table(0).Cell(1, 0).Table("usernameLabel").Cell(1, 0).Textbox("username").SetText('mkumar')
##    web_utils.log_checkpoint("On 'Oracle:Webcenter Imaging page: 'UserID' entered successfully",500,imaging_web_page)
##    Delay(2000)
##    Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/imaging/faces/Authentication/Login.jspx").Panel("doc").Panel("ps_l1").Panel("c").Panel("pslForm").Panel("c").Panel("pglForm").Panel(0).Panel("formBox").Panel(0).Panel("content").Panel("pflForm").Table(0).Cell(0, 0).Table(0).Cell(2, 0).Table("passwordLabel").Cell(1, 0).PasswordBox("password").Click()
##    Delay(2000)
##    Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/imaging/faces/Authentication/Login.jspx").Panel("doc").Panel("ps_l1").Panel("c").Panel("pslForm").Panel("c").Panel("pglForm").Panel(0).Panel("formBox").Panel(0).Panel("content").Panel("pflForm").Table(0).Cell(0, 0).Table(0).Cell(2, 0).Table("passwordLabel").Cell(1, 0).PasswordBox("password").SetText('oracle123')
##    web_utils.log_checkpoint("On 'Oracle:Webcenter Imaging page: 'Password' entered successfully",500,imaging_web_page)
##    Delay(2000)
##    Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/imaging/faces/Authentication/Login.jspx").Panel("doc").Panel("ps_l1").Panel("c").Panel("pslForm").Panel("c").Panel("pglForm").Panel(0).Panel("formBox").Panel(0).Panel("content").Panel("pflForm").Table(0).Cell(0, 0).Table(0).Cell(4, 0).Table("submitButton").Cell(1, 0).SubmitButton("btnSubmit").Click()
    
    self.page.Find("idStr","idcs-signin-basic-signin-form-username",30).Click()
    self.page.Find("idStr","idcs-signin-basic-signin-form-username",30).Click()
    Sys.Keys(Sys.Keys(self.testConfig['wccodingV12']['userid']))
    Sys.Keys("[Tab]")
    Delay(2000)
    self.page.Find("idStr","idcs-signin-basic-signin-form-password|input",30).Click()
    Delay(2000)
    Sys.Keys((self.testConfig['wccodingV12']['password']))
    Sys.Keys("[Tab]"+"[Enter]")
    Delay(3000)
    #self.page.Find("contentText","Sign In",30).Click()
    
    self.wait_until_page_loaded()
    Delay(2000)


    Delay(4000)
    self.wait_until_page_loaded()
#    imaging_page = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/imaging/faces/Pages/Viewer*").Panel("ptd1").Form("mnFrm").Panel(0).Panel("s").Panel("cpyRgt").Panel("f").Panel("imgNvPn").Table(0).Cell(0, 1).Panel("mnpsl").Panel("c").Panel("CntRgn").Panel(0).Panel("c").Panel("panelSplitterTopAndBottom").Panel("f").Panel("panelSplitterTopLeftAndRight").Panel("s").Panel("boxWrap").Panel("c")
    
#    imaging_page = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/imaging/faces/Pages/Viewer.jspx?documentId*")
#    web_utils.log_checkpoint("Oracle:Webcenter Imaging 'Sign in' successful",500,imaging_page)
#    Delay(35000) 
#    count = 0
#    while not Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/imaging/faces/Pages/Viewer*").Panel("ptd1").Form("mnFrm").Panel(0).Panel("s").Panel("cpyRgt").Panel("f").Panel("imgNvPn").Table(0).Cell(0, 1).Panel("mnpsl").Panel("c").Panel("CntRgn").Panel(0).Panel("c").Panel("panelSplitterTopAndBottom").Panel("f").Panel("panelSplitterTopLeftAndRight").Panel("s").Panel("boxWrap").Panel("c").Panel(0).Panel("panelStretchLayoutApplet").Panel(0).Panel(0).Panel("c").Object("oraImgVwr").AWTObject("PluginEmbeddedFrame", "").SwingObject("Viewer", "", 0).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("ImageView", "", 0).SwingObject("JViewport", "", 0).Exists:  
#      delay(5000) 
#      if count == 5:
#        self.log_error_message("Unable to retrieve the Invoice Image")  
#      count=count+1
#    image_view = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/imaging/faces/Pages/Viewer*").Panel("ptd1").Form("mnFrm").Panel(0).Panel("s").Panel("cpyRgt").Panel("f").Panel("imgNvPn").Table(0).Cell(0, 1).Panel("mnpsl").Panel("c").Panel("CntRgn").Panel(0).Panel("c").Panel("panelSplitterTopAndBottom").Panel("f").Panel("panelSplitterTopLeftAndRight").Panel("s").Panel("boxWrap").Panel("c").Panel(0).Panel("panelStretchLayoutApplet").Panel(0).Panel(0).Panel("c").Object("oraImgVwr").AWTObject("PluginEmbeddedFrame", "").SwingObject("Viewer", "", 0).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("ImageView", "", 0).SwingObject("JViewport", "", 0)
#    Sys.HighlightObject(image_view)
#    web_utils.log_checkpoint("Invoice Image exists for the invoice :"+aqConvert.VarToStr(app.Cells.Item[rowno,13]),500,image_view)
#    delay(2000)
#    Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/imaging/faces/Pages/Viewer*").Close()
#    delay(8000)

    imaging_page = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/imaging/faces/Pages/Viewer*").Panel("ptd1").Form("mnFrm").Panel(0).Panel("s").Panel("cpyRgt").Panel("f").Panel("imgNvPn").Table(0).Cell(0, 1).Panel("mnpsl").Panel("c").Panel("CntRgn").Panel(0).Panel("c").Panel("panelSplitterTopAndBottom").Panel("f").Panel("panelSplitterTopLeftAndRight").Panel("s").Panel("boxWrap").Panel("c")
    web_utils.log_checkpoint("Oracle:Webcenter Imaging IDCS 'Sign in' successful",500,imaging_page)
    Delay(35000) 
    count = 0
    while not Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/imaging/faces/Pages/Viewer*").Panel("ptd1").Form("mnFrm").Panel(0).Panel("s").Panel("cpyRgt").Panel("f").Panel("imgNvPn").Table(0).Cell(0, 1).Panel("mnpsl").Panel("c").Panel("CntRgn").Panel(0).Panel("c").Panel("panelSplitterTopAndBottom").Panel("f").Panel("panelSplitterTopLeftAndRight").Panel("s").Panel("boxWrap").Panel("c").Panel(0).Panel("panelStretchLayoutApplet").Panel(0).Panel(0).Panel("c").Object("oraImgVwr").AWTObject("PluginEmbeddedFrame", "").SwingObject("Viewer", "", 0).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("ImageView", "", 0).SwingObject("JViewport", "", 0).Exists:
      delay(5000) 
      if count == 5:
        self.log_error_message("Unable to retrieve the Invoice Image")  
      count=count+1
    image_view = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/imaging/faces/Pages/Viewer*").Panel("ptd1").Form("mnFrm").Panel(0).Panel("s").Panel("cpyRgt").Panel("f").Panel("imgNvPn").Table(0).Cell(0, 1).Panel("mnpsl").Panel("c").Panel("CntRgn").Panel(0).Panel("c").Panel("panelSplitterTopAndBottom").Panel("f").Panel("panelSplitterTopLeftAndRight").Panel("s").Panel("boxWrap").Panel("c").Panel(0).Panel("panelStretchLayoutApplet").Panel(0).Panel(0).Panel("c").Object("oraImgVwr").AWTObject("PluginEmbeddedFrame", "").SwingObject("Viewer", "", 0).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("ImageView", "", 0).SwingObject("JViewport", "", 0)
    Sys.HighlightObject(image_view)
    web_utils.log_checkpoint("Invoice Image exists for the invoice :"+aqConvert.VarToStr(app.Cells.Item[rowno,13]),500,image_view)
    delay(2000)
    Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/imaging/faces/Pages/Viewer*").Close()
    delay(10000)
#    jFrame.Click()
#    delay(4000)
#    jFrame.Keys("[F4]")
#    Delay(1000)
#    jFrame.Keys("[F4]")
#    Delay(1000)
#    jFrame.Keys("o")
#    self.close_forms(jFrame)
    
    
# Submitting CAI AP WCI Attach Invoice Supplemental Documents Concurrent Program
 
    jFrame.Click()
    delay(4000)
    jFrame.Keys("[F4]")
    Delay(3000)
    jFrame.Keys("[F4]")
    Delay(3000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~n")
    Delay(2000)
    web_utils.log_checkpoint("Submitting 'CAI AP WCI Attach Invoice Supplemental Documents' next",500,jFrame)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit Request","ExtendedFrame"]
    submitrequest_form=jFrame.FindChildEx(prop,val,60,True,90000)
    self.verify_aqobject_chkproperty(submitrequest_form,"AWTComponentAccessibleName",cmpContains,"Submit Request")
    submitrequest_form.Find("AWTComponentAccessibleName","Name RequiredList of Values",30).SetText("CAI AP WCI Attach Invoice Supplemental Documents")
    web_utils.log_checkpoint("Request Name: 'CAI AP WCI Attach Invoice Supplemental Documents' - populated Successfully",500,jFrame)
    jFrame.Keys("[Tab]")
    Delay(3000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit alt m","Button"]
    submit_button=submitrequest_form.FindChild(prop,val,60)
    submit_button.Find("AWTComponentAccessibleName","Submit alt m").Click()
    Delay(3000)
    jFrame.Keys("~o")
    Delay(2000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Decision Request Submitted*","ChoiceBox"]
    decision_form=jFrame.FindChildEx(prop,val,60,True,40000)  

# Capturing the Request ID for  CAI AP WCI Attach Invoice Supplemental Documents Concurrent Program

    RequestID = aqConvert.VarToInt(''.join(x for x in jFrame.find("AWTComponentAccessibleName","Request submitted*",100).AWTComponentAccessibleName if x.isdigit()))
    web_utils.log_checkpoint("'CAI AP WCI Attach Invoice Supplemental Documents' is submitted and Request ID is " + aqConvert.VarToStr(RequestID),500,jFrame)
    Delay(10000)
    jFrame.Keys("~n")
#    dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
#    user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
#    pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
#    dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,VarToStr(RequestID)) 
    Delay(4000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,90000)
    self.req_set_save_output(jFrame,req_form,"CAI AP WCI Attach Invoice Supplemental Documents",RequestID)
    Delay(6000)
    jFrame.Keys("[F4]")
    Delay(4000)
    jFrame.Keys("[F4]")
    Delay(2000)
    jFrame.Keys("~o")
    Delay(2000)

# Requeing the invoice to check the supplemental pages attachment

    self.page.wait_until_page_loaded()
    self.page.EvaluateXPath("//div[text()='Invoices']")[1].Click()
    delay(10000) 
    web_utils.validate_security_box()
    delay(10000)  
    jFrame = self.initializeJFrame()
    Delay(10000)
    form_utils.click_ok_btn(jFrame)
    p_names = ("JavaClassName","AWTComponentAccessibleName")
    p_values = ("ExtendedFrame","Invoice Workbench (CAI "+self.oper_unit+" AP INVOICE PROCESSING)")
    inv_form=jFrame.FindChildEx(p_names,p_values,60,True,120000)
    Delay(2000)
    jFrame.Keys("~v")
    delay(1000)
    jFrame.Keys("f")
    delay(1000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Invoices","ExtendedFrame"]
    par_form=jFrame.FindChildEx(prop,val,60,True,60000)
    par_form.Find("AWTComponentAccessibleName","Invoice: Number",30).Click()
    Delay(4000)
    par_form.Find("AWTComponentAccessibleName","Invoice: Number",30).SetText(app.Cells.Item[rowno,13])
    jFrame.Keys("[Tab]")
    delay(3000)
    val = ["Find alt i","Button"] 
    par_form.FindChild(prop,val,60).Click()
    Delay(4000)    
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Type Required",8]
    inv_type=jFrame.FindChildEx(prop,val,60,True,9000000)
    Log.Enabled=True
    aqObject.CheckProperty(inv_type,"wText",cmpIn,"Standard")
    Log.Enabled=False
    self.log_message_oracle_form(jFrame," Re-querying the Invoice Successful")
    Delay(4000)   
    jFrame.Keys("~v")
    Delay(2000)
    jFrame.Keys("a")
    Delay(2000) 
    jFrame.Keys("[Down]")
    self.log_message_oracle_form(jFrame,"In Workbench Attachments Section : Supplemental Pages Image attached successfully")
    Delay(4000)
#    jFrame.Keys("~d")
#    Delay(15000)
#
## Logging into Oracle:Webcenter Imaging to view the Supplemental Pages image
#
#    imaging_web_page = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/imaging/faces/Authentication/Login.jspx").Panel("doc").Panel("ps_l1").Panel("c").Panel("pslForm").Panel("c").Panel("pglForm")
#    web_utils.log_checkpoint("Log in to 'Oracle:Webcenter Imaging Next",500,imaging_web_page)
#    self.wait_until_page_loaded()
#    Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/imaging/faces/Authentication/Login.jspx").Panel("doc").Panel("ps_l1").Panel("c").Panel("pslForm").Panel("c").Panel("pglForm").Panel(0).Panel("formBox").Panel(0).Panel("content").Panel("pflForm").Table(0).Cell(0, 0).Table(0).Cell(1, 0).Table("usernameLabel").Cell(1, 0).Textbox("username").Click()
#    Delay(4000)
#    Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/imaging/faces/Authentication/Login.jspx").Panel("doc").Panel("ps_l1").Panel("c").Panel("pslForm").Panel("c").Panel("pglForm").Panel(0).Panel("formBox").Panel(0).Panel("content").Panel("pflForm").Table(0).Cell(0, 0).Table(0).Cell(1, 0).Table("usernameLabel").Cell(1, 0).Textbox("username").SetText('mkumar')
#    web_utils.log_checkpoint("On 'Oracle:Webcenter Imaging page: 'UserID' entered successfully",500,imaging_web_page)
#    Delay(2000)
#    Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/imaging/faces/Authentication/Login.jspx").Panel("doc").Panel("ps_l1").Panel("c").Panel("pslForm").Panel("c").Panel("pglForm").Panel(0).Panel("formBox").Panel(0).Panel("content").Panel("pflForm").Table(0).Cell(0, 0).Table(0).Cell(2, 0).Table("passwordLabel").Cell(1, 0).PasswordBox("password").Click()
#    Delay(2000)
#    Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/imaging/faces/Authentication/Login.jspx").Panel("doc").Panel("ps_l1").Panel("c").Panel("pslForm").Panel("c").Panel("pglForm").Panel(0).Panel("formBox").Panel(0).Panel("content").Panel("pflForm").Table(0).Cell(0, 0).Table(0).Cell(2, 0).Table("passwordLabel").Cell(1, 0).PasswordBox("password").SetText('oracle123')
#    web_utils.log_checkpoint("On 'Oracle:Webcenter Imaging page: 'Password' entered successfully",500,imaging_web_page)
#    Delay(2000)
#    Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/imaging/faces/Authentication/Login.jspx").Panel("doc").Panel("ps_l1").Panel("c").Panel("pslForm").Panel("c").Panel("pglForm").Panel(0).Panel("formBox").Panel(0).Panel("content").Panel("pflForm").Table(0).Cell(0, 0).Table(0).Cell(4, 0).Table("submitButton").Cell(1, 0).SubmitButton("btnSubmit").Click()
#    Delay(4000)
#    self.wait_until_page_loaded()
#    imaging_page = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/imaging/faces/Pages/Viewer*").Panel("ptd1").Form("mnFrm").Panel(0).Panel("s").Panel("cpyRgt").Panel("f").Panel("imgNvPn").Table(0).Cell(0, 1).Panel("mnpsl").Panel("c").Panel("CntRgn").Panel(0).Panel("c").Panel("panelSplitterTopAndBottom").Panel("f").Panel("panelSplitterTopLeftAndRight").Panel("s").Panel("boxWrap").Panel("c")
#    web_utils.log_checkpoint("Oracle:Webcenter Imaging 'Sign in' successful",500,imaging_page)
#    Delay(100000) 
#    count = 0
#    while not Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/imaging/faces/Pages/Viewer*").Panel("ptd1").Form("mnFrm").Panel(0).Panel("s").Panel("cpyRgt").Panel("f").Panel("imgNvPn").Table(0).Cell(0, 1).Panel("mnpsl").Panel("c").Panel("CntRgn").Panel(0).Panel("c").Panel("panelSplitterTopAndBottom").Panel("f").Panel("panelSplitterTopLeftAndRight").Panel("s").Panel("boxWrap").Panel("c").Panel(0).Panel("panelStretchLayoutApplet").Panel(0).Panel(0).Panel("c").Object("oraImgVwr").AWTObject("PluginEmbeddedFrame", "").SwingObject("Viewer", "", 0).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("ImageView", "", 0).SwingObject("JViewport", "", 0).Exists:
#      delay(5000) 
#      if count == 5:
#        self.log_error_message("Unable to retrieve the Supplemental pages Image")  
#      count=count+1
#    image_view = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/imaging/faces/Pages/Viewer*").Panel("ptd1").Form("mnFrm").Panel(0).Panel("s").Panel("cpyRgt").Panel("f").Panel("imgNvPn").Table(0).Cell(0, 1).Panel("mnpsl").Panel("c").Panel("CntRgn").Panel(0).Panel("c").Panel("panelSplitterTopAndBottom").Panel("f").Panel("panelSplitterTopLeftAndRight").Panel("s").Panel("boxWrap").Panel("c").Panel(0).Panel("panelStretchLayoutApplet").Panel(0).Panel(0).Panel("c").Object("oraImgVwr").AWTObject("PluginEmbeddedFrame", "").SwingObject("Viewer", "", 0).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("ImageView", "", 0).SwingObject("JViewport", "", 0)
#    Sys.HighlightObject(image_view)
#    web_utils.log_checkpoint("Supplemental Pages exists for the invoice :"+aqConvert.VarToStr(app.Cells.Item[rowno,13]),500,image_view)
#    delay(2000)
#    Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/imaging/faces/Pages/Viewer*").Close()
#    delay(8000)
#    jFrame.Click()
    delay(4000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("o")
    self.close_forms(jFrame)
    web_utils.close_additional_browsers()
    

 def req_set_save_output(self,jFrame,req_form,srch_child_name,Preqid):
    web_utils.log_checkpoint("Checking for "+aqConvert.VarToStr(srch_child_name)+ " Child Program Status",500,jFrame)
    req_form.FindChild("AWTComponentAccessibleName","Refresh Data alt R",20).Click()
    i=20
    for x in range(1,180):     
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Name",i]
        child_name=req_form.Find(prop,val,10).wText 
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Phase",i+20]
        phase=req_form.Find(prop,val,10).wText 
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Request ID",i-10]
        creqid=VarToInt(req_form.Find(prop,val,10).wText)                                        
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Status",i+30]         
        status =req_form.FindChild(prop,val,60)            
        if (child_name==srch_child_name) and (creqid>=Preqid) and (phase == "Completed"):
            web_utils.log_checkpoint(aqConvert.VarToStr(srch_child_name)+" Phase Completed Successfuly",500,jFrame)                             
            status.Keys("[Enter]")
            Delay(1000)
            req_form.FindChild("AWTComponentAccessibleName","View Output alt p",20).Click()  
            Delay(4000)
            output_page=Sys.Browser("iexplore").Page("https://core-*.epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
            output_page.Click()
            Delay(2000)
            output_page.Keys("~f")
            Delay(2000)
            output_page.Keys("a")
            Delay(5000)
            file_system_utils.create_folder(self.op_log_path)             
            self.log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"File"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"_%d%b%Y_%H%M")+".txt"    
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(self.log_path)
            Delay(1000)
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
            Delay(8000)
            Log.Enabled=True
            Log.File(self.log_path, aqConvert.VarToStr(srch_child_name)+" is Completed And Output file is attached")
            Log.Enabled=False     
            web_utils.close_additional_browsers()         
            Filesaved = 'True'
            return                           
        elif i >=29:
           Delay(15000)           
           req_form.FindChild("AWTComponentAccessibleName","Refresh Data alt R",20).Click()
           Delay(3000)
           i=20
           val=["Name",i]
           child_name=req_form.Find(prop,val,10).wText
        else:  
           Delay(2000)
           i=i+1 
