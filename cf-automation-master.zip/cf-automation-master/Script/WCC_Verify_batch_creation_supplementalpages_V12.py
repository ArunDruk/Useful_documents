﻿from dbhelper import *
from webcentercapture_V12 import *
import web_utils
import wcc_login_page
import wcc_home_page
import os

class WCC_Verify_batch_creation_supplementalpages_V12(Webcentercapture_V12):
        
 def goto_url(self,url):
    gvar.dataprep['browser'] = 'ie'
    pass
         
 def action(self,book):
  
  app = book.Sheets.item["mail_wcc"] 
  
#  #*Michael Bennett Change --- Email Invoice Not Working ---
#  file_system_utils.create_folder("C:\\TC_Logs")
#  src_folder=Project.Path+"DataSheets\\WCI\\"
#  file_path=src_folder+VarToStr(app.Cells.item[2,4])
  
  #close all open sessions and make current session active  
  Webcentercapture_V12.use_current_session()
  
  #Get location and set the key for searching the batches
#  location = VarToStr(app.Cells.item[2,3]).split("-")[1]
  location = VarToStr(app.Cells.item[2,3])[2:]
  ocr_key = aqString.SubString(location,0,2)
  Webcentercapture_V12.set_entity_based_on_location(location)
  Delay(3000)
  
  #verify whether the batch_list frame exists
  Webcentercapture_V12.verify_batch_list_frame()
  Delay(5000)
   
#  #*Michael Bennett Change --- Email Invoice Not Working ---
#  #Scanning Invoice
#  Webcentercapture_V12.capture_inv_create_batch(file_path,app)
#  Delay(5000)
#  #Drag the scroll bar up 
#  gvar.dataprep['capt_wdw'].Keys("[PageUp]")
  
  #select the first batch
  Webcentercapture_V12.select_first_batch(ocr_key)
  Delay(3000)
  
#  #*Michael Bennett Change --- Email Invoice Not Working ---
#  #Verify whether batch created and the batch details 
#  Webcentercapture_V12.verify_batch_by_batch_name(ocr_key,app)

  # Verify whether batch created and the batch details 
  Webcentercapture_V12.verify_batch_by_email_subject(ocr_key,app) 
  
  # Verify and Update Document Profile and Release the Batch to WFR Form for Verification:       
  WCC_Verify_batch_creation_supplementalpages_V12.verify_update_document_profile_details(app)
  Delay(1000)
  
  # select batch header and release the selected batch:
  Webcentercapture_V12.select_batch_for_release(ocr_key,app) 
  
  # validate batch release
  Webcentercapture_V12.validate_batch_release(app,ocr_key)
  
  #overriden below methods for supplemental scenarios
  
 def verify_update_document_profile_details(app):
     gvar.dataprep['batch_list_frame'].Keys("[Right][Right]")
     Delay(10000)
     image_viewer = wcc_home_page_v12.image_viewer() 
     value = image_viewer.VisibleOnScreen
     document_no = 1

     if value == False and VarToStr(app.Cells.item[2,12]) == "Yes":
         cnt=0
         while value == False:
            Delay(5000)
            Indicator.Show()
            Indicator.PushText("Waiting to load Image...")                                          
            if cnt==20:
              tc_logs.error_with_picture("Image load timed out!!")
              break
            else:
              cnt+=1
              value = image_viewer.VisibleOnScreen  
         Indicator.Clear()
     if value == True:
             Delay(5000)
             Webcentercapture_V12.validate_doc_panel(document_no,app)
             WCC_Verify_batch_creation_supplementalpages_V12.create_new_document_supplemental(document_no)
             delay(2000)
             value = image_viewer.VisibleOnScreen
       
     tc_logs.checkpt_with_picture("Verified and Updated the Document Profile Details Successfully: Ready to Release",500,gvar.dataprep['capt_wdw'])
        
     #creating the new document and selecting the doc_type as CAIAP Supplemental
 def create_new_document_supplemental(document_no):
    Sys.HighlightObject(wcc_home_page_v12.second_img())
    wcc_home_page_v12.second_img().Click()
    Sys.HighlightObject(wcc_home_page_v12.image_viewer())
    Sys.HighlightObject(wcc_home_page_v12.create_doc_icon())
    wcc_home_page_v12.create_doc_icon().Click()
    Delay(5000)
    tc_logs.checkpt_with_picture("Created new document successfully",500,gvar.dataprep['capt_wdw'])
    wcc_home_page_v12.doc_type_dropdown().Keys("CAIAP Supplemental Docs")
    Delay(3000)
    wcc_home_page_v12.doc_type_dropdown().Keys("[Enter]")
    tc_logs.checkpt_with_picture("Selected CAIAP Supplemental Docs for new document successfully",500,gvar.dataprep['capt_wdw'])
    tc_logs.checkpt_with_picture("Verified the Document Profile Details Successfully for document no - "+IntToStr(document_no+1)+": Ready to Release",500,gvar.dataprep['capt_wdw'])
 

  
    
