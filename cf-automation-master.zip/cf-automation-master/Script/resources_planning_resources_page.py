﻿import gvar

### In this method objects for below pages have been captured ###

#RESOURCES > PLANNING RESOURCES page

def planning_resources_page_link():
  prop_names = ["contentText","ObjectIdentifier","ObjectType"]
  prop_values = ["Planning Resources","PA_PAXPREPR_OPT_PLANRL_V","Link"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def maximize_button():
  prop_names = ["idStr","namePropStr","ObjectIdentifier"]
  prop_values = ["ResListTable:detachIcon","maximize_ena.png","detachIcon"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def refresh_button():
  prop_names = ["namePropStr","ObjectType"]
  prop_values = ["tablerefresh_ena.png","Image"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def settings_button():
  prop_names = ["namePropStr","ObjectType"]
  prop_values = ["action_ena.png","Image"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def freeze_button():
  prop_names = ["namePropStr","ObjectIdentifier"]
  prop_values = ["freeze:dis:ResListTable","ResListTable"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
