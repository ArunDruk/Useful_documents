﻿import database_service
import gvar
import file_utility
import tc_logs


# Given a testset_category, the testset id is returned based on the gvar.dataprep['env'] value setup. 
def get_testset_id(testset_category):
  rs = database_service.query_mysql(f"select * from testset_category where category = '{testset_category}' and environment = '{gvar.dataprep['env']}'")
#  tc_logs.msg_with_no_picture(f"Uploading results to Testset Cateogry: '{testset_category}' - TS_ID: {rs[0]['ts_id']}")  
  return rs[0]['ts_id']

# Given the folder name, log file name, and log date, this method will create the full log path which can be used for subsequent methods
def get_ruby_log_path(folder_name,log_file_name,log_date):
   #ruby_log_path = f"//msc-qc-01/f/G2G/testcomplete_results/{folder_name}/{log_date}/{log_file_name}"
   ruby_log_path = f"/qa-datafiles/testcomplete_results/{folder_name}/{log_date}/{log_file_name}"
   return ruby_log_path

# Given a folder name, log file name and log date, this saves the testcomplete log in the msc-qc-01 sharedrive
def save_testcomplete_log(folder_name,log_file_name, log_date):
  #python_log_path = f'Z:\\G2G\\testcomplete_results\\{folder_name}\\{log_date}'
#  python_log_path = f'Z:\\testcomplete_results\\{folder_name}\\{log_date}'
  python_log_path = f'X:\\testcomplete_results\\{folder_name}\\{log_date}'
  create_log_folder(python_log_path)
  Log.SaveResultsAs(python_log_path + '\\' + log_file_name, lsMHT)
   
# Given the full path where the log file will be saved, this method creates the log folder in the msc-qc-01 share drive (if it does not exist)
def create_log_folder(log_path):
#  file_utility.disconnect_from_network_drive("Z:")
  file_utility.disconnect_from_network_drive("X:")
 # file_utility.connect_to_network_drive('Z:','\\\\msc-qc-01\\f')
#  file_utility.connect_to_network_drive('Z:','\\\\prod-tools-iad1-mt.private1.prodtools.oraclevcn.com\\qa-datafiles')
  file_utility.connect_to_network_drive('X:','\\\\prod-tools-iad1-mt\\qa-datafiles')
  file_utility.create_folder(log_path)

#This takes the testcase name and parses out the tc# and incorporates the proper format ie. "tc1000_results-HH-MM-SS"
def get_log_file_name():
  testcase_num = 'tc' + gvar.dataprep['tc_id']
  log_time = aqConvert.DateTimeToFormatStr(aqDateTime.Time(), "%H-%M-%S")
  log_file_name = testcase_num + '_Results-' + str(log_time)
  return log_file_name

  
#This method is used to set all of the necessary data points for the Rally API
def set_rally_result_input(testcase_name, project_name, test_folder, tc_id, ts_id):
  aqPerformance.Start()
  gvar.dataprep['testcase_name'] = testcase_name
  gvar.dataprep['tc_id'] = tc_id
  gvar.dataprep['ts_id'] = ts_id
  gvar.dataprep['project_name'] = project_name
  gvar.dataprep['test_folder'] = test_folder
  gvar.dataprep['verdict'] = 'Pass'


#Sends results to Automation DB, where the data will be processed by the Rally API in Ruby
def send_results_to_db(verdict):
  tc_logs.header_name('*****Send Results to Rally*****')
  
  #Define initial variables
  log_date = aqConvert.DateTimeToFormatStr(aqDateTime.Today(), "%m-%d-%Y")
  log_file_name = get_log_file_name()
  mhtml_log_file_name = log_file_name + '.mhtml'
  mht_log_file_name = log_file_name + '.mht'
  folder_name = 'tc' + gvar.dataprep['tc_id']
  

  
  #Data points which are used for Rally API integration
  project_name = gvar.dataprep['project_name']
  test_folder = gvar.dataprep['test_folder']
  tc_id = gvar.dataprep['tc_id']
  ts_id = gvar.dataprep['ts_id']
  duration = aqConvert.VarToInt(aqPerformance.__getprop__("Value")/1000)
  duration = aqConvert.VarToInt(duration/60)
  build = 'TestComplete Automation ' + str(aqDateTime.Now())
  ruby_log_path = get_ruby_log_path(folder_name,mht_log_file_name, log_date)
  
  #Insert results into Automation DB
  database_service.update_delete_mysql(f"insert into testcomplete_to_rally (log_path, testcase_name, project_name, test_folder, tc_id, ts_id, verdict, duration, build) VALUES ('{ruby_log_path}', '{mhtml_log_file_name}', '{project_name}', '{test_folder}', '{tc_id}', '{ts_id}', '{verdict}', '{duration}', '{build}')")
  Log.Enabled ='True'
  tc_logs.checkpt_with_no_picture(f"TestComplete Results have been sent to Rally: TC_ID - {tc_id},TSID - {ts_id},Verdict - {verdict}")
  Log.Enabled ='False'
  
  #save log to msc-qc-01 sharedrive
  save_testcomplete_log(folder_name,mht_log_file_name,log_date)
