﻿import gvar

### In this method objects for below pages have been captured ###

#PROJECT > DIRECTORY page

def prj_directory_page_search_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["Search","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def prj_directory_page_go_button():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["Go","Button"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def prj_directory_advsrch_button():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["AdvancedSearch","Button"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def prj_directory_advsrch_name_textfeild():
  prop_names = ["ObjectLabel","ObjectType"]
  prop_values = ["Name","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
  

def prj_directory_advsrch_role_textfeild():
  prop_names = ["ObjectLabel","ObjectType"]
  prop_values = ["Role","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
  
  
def prj_directory_advsrch_org_textfeild():
  prop_names = ["ObjectLabel","ObjectType"]
  prop_values = ["Organization","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
  
  
def prj_directory_advsrch_phone_textfeild():
  prop_names = ["ObjectLabel","ObjectType"]
  prop_values = ["Phone","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def prj_directory_advsrch_matchall_radiobutton():
  prop_names = ["ObjectLabel","ObjectType","idStr"]
  prop_values = ["All","RadioButton","M__Id"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def prj_directory_advsrch_matchany_radiobutton():
  prop_names = ["ObjectLabel","ObjectType","idStr"]
  prop_values = ["Any","RadioButton","M__Ida"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def prj_directory_advsrch_go_button():
  prop_names = ["ObjectLabel","ObjectType"]
  prop_values = ["Go","Button"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
  

def prj_directory_advsrch_clear_button():
  prop_names = ["ObjectLabel","ObjectType"]
  prop_values = ["Clear","Button"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
  

def prj_directory_advsrch_addanother_dropdown():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["N106","Select"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def prj_directory_advsrch_simplesrch_button():
  prop_names = ["contentText","ObjectType"]
  prop_values = ["Simple Search","Button"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

