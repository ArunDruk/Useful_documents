﻿import tc_logs
import traceback
import gvar

def log_exception(ex):  
  Log.Error(aqString.Format('Exception:%s', VarToStr(ex.args[0])))



def query_oracle(dsn,user_id,pwd,sql):
 try:  
    Log.Checkpoint("Connecting to oracle stage Database")
    adoCon=ADO.CreateADOConnection()
    adoCon.ConnectionString="Provider=MSDASQL.1;Password="+pwd+";Persist Security Info=True;User ID="+user_id+";Data Source="+dsn+""
    adoCon.LoginPrompt=False
    adoCon.Open()
    Log.Enabled
    Log.Checkpoint(aqString.Format('Query: %s ',sql))
    aRecSet = adoCon.Execute_(sql)
    aRecSet.MoveFirst()
    row = dict()
    details = []
    counter = 0
    while not aRecSet.EOF:
       row.clear()  
       counter = 0
       for i in range (0, aRecSet.Fields.Count):
         row[ VarToStr(aRecSet.Fields.Item[i].Name)] =  VarToStr(aRecSet.Fields.Item[i].Value)
         counter = 1
       aRecSet.MoveNext()
       if (counter == 1): 
         details.append(dict(row))    
    aRecSet.Close()
    adoCon.Close()
    return details 
 except:    
  adoCon.Close()

def query_oracle_devt_db(sql):
 try: 
    Log.Checkpoint("Connecting to oracle stage Database")
    adoCon=ADO.CreateADOConnection()
    adoCon.ConnectionString="Provider=MSDASQL.1;Password=W3zRH8pg;Persist Security Info=True;User ID=rac_accnt;Data Source=DMNH1I"
    adoCon.LoginPrompt=False
    adoCon.Open()
  
    Log.Checkpoint(aqString.Format('Query: %s ',sql))
    aRecSet = adoCon.Execute_(sql)
    aRecSet.MoveFirst()
    row = dict()
    details = []
    counter = 0
    while not aRecSet.EOF:
       row.clear()  
       counter = 0
       for i in range (0, aRecSet.Fields.Count):
         row[ VarToStr(aRecSet.Fields.Item[i].Name)] =  VarToStr(aRecSet.Fields.Item[i].Value)
         counter = 1
       aRecSet.MoveNext()
       if (counter == 1): 
         details.append(dict(row))    
    aRecSet.Close()
    adoCon.Close()
    return details 
 except:    
  adoCon.Close()
  
  
def query_oracle_trnd_db(sql):
 try: 
  Log.Checkpoint("Connecting to oracle silo5 Database")
  adoCon=ADO.CreateADOConnection()
  adoCon.ConnectionString="Provider=MSDASQL.1;Password=oracle123;Persist Security Info=True;User ID=appsqauser;Data Source=TMNH2I"
  adoCon.LoginPrompt=False
  adoCon.Open()
  
  Log.Checkpoint(aqString.Format('Query: %s ',sql))
  aRecSet = adoCon.Execute_(sql)
  aRecSet.MoveFirst()
  row = dict()
  rows = []
  counter = 0
  while not aRecSet.EOF:
     row.clear()  
     counter = 0
     for i in range (0, aRecSet.Fields.Count):
       row[ VarToStr(aRecSet.Fields.Item[i].Name)] =  VarToStr(aRecSet.Fields.Item[i].Value)
       counter = 1
     aRecSet.MoveNext()
     if (counter == 1): 
       rows.append(dict(row)) 
  aRecSet.Close()
  adoCon.Close()
  return rows 
 except:    
  adoCon.Close()

def query_mysql(sql):
    try: 
        tc_logs.msg_with_no_picture("Connecting to My Sql Driver")
        aCon = ADO.CreateConnection()
        aCon.ConnectionString = "Provider=MSDASQL.1;Password=oci;Persist Security Info=True;User ID=oci;Data Source=oci_mysql"
        aCon.Open()
        aCmd = ADO.CreateCommand()
        aCmd.ActiveConnection = aCon # Connection
        aCmd.CommandType = adCmdText # Command type
  
        tc_logs.msg_with_no_picture(aqString.Format('Query: %s ',sql))
        aCmd.CommandText = VarToStr(sql)
        aRecSet = aCmd.Execute()
        if aRecSet.RecordCount == 0:
          tc_logs.error_with_no_picture('SQL failed to return data - expand log messages for SQL query details', 'SQL Query Returned No Data')
         
        aRecSet.MoveFirst()

        row = dict()
        details = []
        counter = 0
        while not aRecSet.EOF:
            row.clear()  
            counter = 0
            for i in range (0, aRecSet.Fields.Count):
                row[ VarToStr(aRecSet.Fields.Item[i].Name)] =  VarToStr(aRecSet.Fields.Item[i].Value)
                counter = 1
            aRecSet.MoveNext()
            if (counter == 1): 
                details.append(dict(row))    
        aRecSet.Close()
        aCon.Close()
        return details 
    except:    
       aCon.Close()
       raise Exception('Custom Exception: SQL failed to return data')
  
def update_delete_mysql(sql):
    try:
        tc_logs.msg_with_no_picture("Connecting to My Sql Driver")
        aCon = ADO.CreateConnection()
        aCon.ConnectionString = "Provider=MSDASQL.1;Password=oci;Persist Security Info=True;User ID=oci;Data Source=oci_mysql"
        aCon.Open()
        aCmd = ADO.CreateCommand()
        aCmd.ActiveConnection = aCon # Connection
        aCmd.CommandType = adCmdText # Command type
        aCmd.CommandText = VarToStr(sql)
  
        tc_logs.msg_with_no_picture(aqString.Format('Query: %s ',sql))
        aCmd.Execute()
        aCon.Close()
    except:
        aCon.Close()
        raise Exception('Custom Exception: SQL failed to return data')

def main():
  try:
    sql = "SELECT * FROM ra_customer_trx_all WHERE 1 = 1 AND attribute_category = 'US BUYER' AND attribute4 like '%" + VarToStr(gvar.vin) + "';"
    rows = database_service.query_oracle_trnd_db(sql)
    if (GetVarType(rows)== VarToInt(9)):
     for row in rows:
      Log.Checkpoint(aqString.Format("TRX_NUMBER : %s",row['TRX_NUMBER']))
      Log.Checkpoint(aqString.Format("CUSTOMER_TRX_ID : %s",row['CUSTOMER_TRX_ID']))
      Log.Checkpoint(aqString.Format("CONSIGNMENT_ID : %s",row['ATTRIBUTE2']))
      gvar.trx_num = row['TRX_NUMBER']
      gvar.inv_id = row['CUSTOMER_TRX_ID']
      gvar.consign_id = row['ATTRIBUTE2']
    else:
       Log.Error('No Records Found, Please check the Query')
  except Exception as e:
      Log.Message(traceback.format_exc())

      
def query_oracle_db(sql):
    try: 
        tc_logs.msg_with_no_picture(f"Connecting to oracle {gvar.config['man_oracle_db']['dsn']} Database")
        adoCon=ADO.CreateADOConnection()
        adoCon.ConnectionString=f"Provider=MSDASQL.1;Persist Security Info=True;User ID={gvar.config['man_oracle_db']['userid']};Password={gvar.config['man_oracle_db']['pwd']};Data Source={gvar.config['man_oracle_db']['dsn']}"
        adoCon.LoginPrompt=False
        adoCon.Open()
    
        tc_logs.msg_with_no_picture(aqString.Format('Query: %s ',sql))
        aRecSet = adoCon.Execute_(sql)
        if aRecSet.RecordCount == 0:
          tc_logs.error_with_no_picture('SQL failed to return data - expand log messages for SQL query details', 'SQL Query Returned No Data')
          
        aRecSet.MoveFirst()
        
        row = dict()
        rows = []
        counter = 0
        while not aRecSet.EOF:
            row.clear()  
            counter = 0
            for i in range (0, aRecSet.Fields.Count):
                row[ VarToStr(aRecSet.Fields.Item[i].Name)] =  VarToStr(aRecSet.Fields.Item[i].Value)
                counter = 1
            aRecSet.MoveNext()
            if (counter == 1): 
                rows.append(dict(row)) 
        aRecSet.Close()
        adoCon.Close()
        return rows   
    except:    
        adoCon.Close()
        Log.Message(traceback.format_exc())
        raise Exception('Custom Exception: SQL failed to return data')
        
        
def query_oracle_db_odm(sql):
    try: 
        tc_logs.msg_with_no_picture(f"Connecting to oracle {gvar.config['oracledb']['data_source']} Database",'')
        adoCon=ADO.CreateADOConnection()
        adoCon.ConnectionString=f"Provider=MSDASQL.1;Persist Security Info=True;User ID={gvar.config['oracledb']['usrid']};Password={gvar.config['oracledb']['pswd']};Data Source={gvar.config['oracledb']['data_source']}"
        adoCon.LoginPrompt=False
        adoCon.Open()
    
        tc_logs.msg_with_no_picture(aqString.Format('Query: %s ',sql),'')
        aRecSet = adoCon.Execute_(sql)
        if aRecSet.RecordCount == 0:
               return None        
          
        aRecSet.MoveFirst()
        
        row = dict()
        rows = []
        counter = 0
        while not aRecSet.EOF:
            row.clear()  
            counter = 0
            for i in range (0, aRecSet.Fields.Count):
                row[ VarToStr(aRecSet.Fields.Item[i].Name)] =  VarToStr(aRecSet.Fields.Item[i].Value)
                counter = 1
            aRecSet.MoveNext()
            if (counter == 1): 
                rows.append(dict(row)) 
        aRecSet.Close()
        adoCon.Close()
        return rows   
    except:    
        adoCon.Close()
        raise Exception('Custom Exception: SQL failed to return data')
        
def validate_wrkflw_adj_buyer():
    try: 
        tc_logs.msg_with_no_picture(f"Connecting to oracle {gvar.config['man_oracle_db']['dsn']} Database")
        adoCon=ADO.CreateADOConnection()
        adoCon.ConnectionString=f"Provider=MSDASQL.1;Persist Security Info=True;User ID={gvar.config['man_oracle_db']['userid']};Password={gvar.config['man_oracle_db']['pwd']};Data Source={gvar.config['man_oracle_db']['dsn']}"
        adoCon.LoginPrompt=False
        adoCon.Open()
        sqlQuery =  "select arbitration_buyer_complete from manar.man_om_consignments where consignment_id = '"+gvar.dataprep['consignment_id']+"'"      
        Log.Message(sqlQuery)
        for x in range(0,60):
          rec_set=adoCon.Execute_(sqlQuery)
          rec_set.MoveFirst()
          while (not rec_set.EOF):        
            Log.Message("Arbitration Buyer Complete Flag :  "+rec_set.Fields.Item["arbitration_buyer_complete"].Value)         
            Found=True
            Buyer_arb_flag = aqConvert.VartoStr(rec_set.Fields.Item["arbitration_buyer_complete"].Value)
            rec_set.MoveNext()
          Delay(10000)
          if Found==True:
            return Buyer_arb_flag
            break        
    except Exception as e:
      Log.Error("Error : - " + str(e))   
    finally:    
      adoCon.Close()
      
def validate_ar_interface(order_type):
    try: 
        tc_logs.msg_with_no_picture(f"Connecting to oracle {gvar.config['man_oracle_db']['dsn']} Database")
        adoCon=ADO.CreateADOConnection()
        adoCon.ConnectionString=f"Provider=MSDASQL.1;Persist Security Info=True;User ID={gvar.config['man_oracle_db']['userid']};Password={gvar.config['man_oracle_db']['pwd']};Data Source={gvar.config['man_oracle_db']['dsn']}"
        adoCon.LoginPrompt=False
        adoCon.Open()
        sqlQuery = "select header_attribute8 from ra_interface_lines_all where sales_order = '"+order_type+"' order by document_creation_date FETCH NEXT 1 ROWS ONLY"    
        Log.Message(sqlQuery)
        for x in range(0,10):
          rec_set=adoCon.Execute_(sqlQuery)
          rec_set.MoveFirst()
          while (not rec_set.EOF):        
            Log.Message("Order No: "+order_type+" Exists in RA_INTERFACE")         
            Found=True
            header_attribute8 = aqConvert.VartoStr(rec_set.Fields.Item["header_attribute8"].Value)
            rec_set.MoveNext()
          Delay(10000)
          if Found==True:
            return header_attribute8
            break        
    except Exception as e:
      Log.Error("Error : - " + str(e))   
    finally:    
      adoCon.Close()

      
def return_asset_no_for_vin(vin):
    try: 
        tc_logs.msg_with_no_picture(f"Connecting to oracle {gvar.config['man_oracle_db']['dsn']} Database")
        adoCon=ADO.CreateADOConnection()
        adoCon.ConnectionString=f"Provider=MSDASQL.1;Persist Security Info=True;User ID={gvar.config['man_oracle_db']['userid']};Password={gvar.config['man_oracle_db']['pwd']};Data Source={gvar.config['man_oracle_db']['dsn']}"
        adoCon.LoginPrompt=False
        adoCon.Open()
        sqlQuery =  "select asset_number,description from fa_additions where serial_number = '"+VarToStr(vin)+"'"
        Log.Message(sqlQuery)
        for x in range(0,60):
          rec_set=adoCon.Execute_(sqlQuery)
          rec_set.MoveFirst()
          while (not rec_set.EOF):        
            Log.Message("Asset Number :  "+rec_set.Fields.Item["ASSET_NUMBER"].Value)         
            Found=True
            Asset_Number = aqConvert.VartoStr(rec_set.Fields.Item["ASSET_NUMBER"].Value)
            Description = aqConvert.VartoStr(rec_set.Fields.Item["DESCRIPTION"].Value)
            rec_set.MoveNext()
          Delay(10000)
          if Found==True:
            return Asset_Number, Description
            break        
    except Exception as e:
      Log.Error("Error : - " + str(e))   
    finally:    
      adoCon.Close()
