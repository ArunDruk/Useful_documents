﻿import gvar

def type_textfield():
  return gvar.dataprep['jformobject'].Find("AWTComponentAccessibleName","Type Required",1000)
  
def code_required_textfield():
  prop_name = ["AWTComponentAccessibleName","AWTComponentIndex"]
  prop_value = ["Code Required","regexp:^.*"]
  return gvar.dataprep['jformobject'].FindAll(prop_name,prop_value,1000)
  
def description_textfield():
  return gvar.dataprep['jformobject'].Find("AWTComponentAccessibleName","Lookup Code Description",1000)

def descflexfield_popup():
  prop_name = ["AWTComponentAccessibleName","AWTComponentIndex"]
  prop_value = ["[  ]","regexp:^.*"]
  return gvar.dataprep['jformobject'].FindAll(prop_name,prop_value,1000)
  
##parameters form 
def monday_text_field():
  prop_name = ["AWTComponentAccessibleName","AWTComponentIndex"]
  prop_value = ["regexp:^Monday:.*","0"]
  return gvar.dataprep['jformobject'].Find(prop_name,prop_value,1000)
  
def tuesday_text_field():
  prop_name = ["AWTComponentAccessibleName","AWTComponentIndex"]
  prop_value = ["regexp:^Tuesday:.*","0"]
  return gvar.dataprep['jformobject'].Find(prop_name,prop_value,1000)

def wednesday_text_field():
  prop_name = ["AWTComponentAccessibleName","AWTComponentIndex"]
  prop_value = ["regexp:^Wednesday:.*","0"]
  return gvar.dataprep['jformobject'].Find(prop_name,prop_value,1000)

def thursday_text_field():
  prop_name = ["AWTComponentAccessibleName","AWTComponentIndex"]
  prop_value = ["regexp:^Thursday:.*","0"]
  return gvar.dataprep['jformobject'].Find(prop_name,prop_value,1000)

def friday_text_field():
  prop_name = ["AWTComponentAccessibleName","AWTComponentIndex"]
  prop_value = ["regexp:^Friday:.*","0"]
  return gvar.dataprep['jformobject'].Find(prop_name,prop_value,1000)

def saturday_text_field():
  prop_name = ["AWTComponentAccessibleName","AWTComponentIndex"]
  prop_value = ["regexp:^Saturday:.*","0"]
  return gvar.dataprep['jformobject'].Find(prop_name,prop_value,1000)

def sunday_text_field():
  prop_name = ["AWTComponentAccessibleName","AWTComponentIndex"]
  prop_value = ["regexp:^Sunday:.*","0"]
  return gvar.dataprep['jformobject'].Find(prop_name,prop_value,1000)
