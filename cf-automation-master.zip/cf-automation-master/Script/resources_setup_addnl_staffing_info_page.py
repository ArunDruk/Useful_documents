﻿import gvar

### In this method objects for below pages have been captured ###

#RESOURCES > SETUP > Additional Staffing Information page

def role_list_dropdown():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["RoleList","Select"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def addnl_staffing_info_link():
  classifications = gvar.dataprep['page'].NativeWebObject.Find("contentText","Additional Staffing Information","A")
  return classifications


def cancel_button():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["Cancel","Button"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def apply_button():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["Apply","Button"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
