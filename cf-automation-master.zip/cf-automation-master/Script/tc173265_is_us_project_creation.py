﻿from   ebiz import *
import web_utils
import dbhelper
import file_system_utils
import random


class tc173265_is_us_project_creation(Ebiz):


   def login(self):
     self.login_user='pkjami'
     super().login()
   
   def goto_url(self,url):
    super().goto_url(self.testConfig['ebiz']['oci_is_url'])
   
   def action(self,book): 
     app = book.Sheets.item["Project"] 
     app1 = book.Sheets.item["Requisition"]  
     rowno = 2
     web_utils.log_checkpoint("Logged in to Oracle Applications Home Page Successfully",500,self.page)
     self.wait_until_page_loaded()     
     self.page.EvaluateXPath("//table[@id='menuContent']//div[contains(text(),'PC User')]")[0].Click()  
     web_utils.log_checkpoint("Click 'PC User' - Successful",500,self.page) 
     self.page.Keys("[Down]")
     delay(2000)
     self.wait_until_page_loaded()
     self.page.NativeWebObject.Find("contentText","Projects","A").Click()  
     web_utils.log_checkpoint("Click 'Projects' - Successful",500,self.page) 
     self.page.wait()  
     delay(5000)  
     web_utils.validate_security_box()
     jFrame = self.initializeJFrame()
     Delay(5000)
     form_utils.click_ok_btn(jFrame)
     
# Finding the existing project

     p_names = ("AWTComponentAccessibleName","JavaClassName")
     p_values = ("Find Projects","ExtendedFrame")
     find_projects_form=jFrame.FindChildEx(p_names,p_values,60,True,60000)
     Sys.HighlightObject(find_projects_form)
     obj=jFrame.FindChild(p_names,p_values,50)
     if obj.Exists:
      web_utils.log_checkpoint("'Find Projects' form launched successfully",500,jFrame) 
     else:
      self.log_message_oracle_form(jFrame,"Unable to Launch 'Find Projects' form")
     
     Delay(5000)
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Project NumberList of Values","VTextField"]
     proj_num = find_projects_form.FindChild(prop,val,20)
     Sys.HighlightObject(proj_num)    
     proj_num.Click()
     proj_num.Find(prop, val,30).Keys(app.Cells.Item[rowno,1])
     jFrame.Keys("[Tab]")
     Delay(2000)
     web_utils.log_checkpoint(" On 'Find Projects' form Project Template : "+aqConvert.VarToStr(app.Cells.Item[rowno,1])+" entered successfully",500,jFrame) 
     prop=["AWTComponentAccessibleName","AWTComponentIndex","JavaClassName"]
     val=["Find alt i","1","Button"]
     find_bttn = find_projects_form.FindChild(prop,val,20)
     Sys.HighlightObject(find_bttn)    
     find_bttn.Click()
     web_utils.log_checkpoint(" On 'Find Projects' form click 'Find' button successful",500,jFrame) 
     Delay(5000)
     
     p_names = ("AWTComponentAccessibleName","AWTComponentIndex","JavaClassName")
     p_values = ("Projects, Templates Summary","20","ExtendedFrame")
     prj_template_form=jFrame.FindChildEx(p_names,p_values,60,True,60000)
     Sys.HighlightObject(prj_template_form)
     obj=jFrame.FindChild(p_names,p_values,50)
     if obj.Exists:
      web_utils.log_checkpoint(" 'Projects, Templates Summary' form launched successfully",500,jFrame) 
     else:
      self.log_message_oracle_form(jFrame,"Unable to Launch 'Projects, Templates Summary' form")
     
     
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Copy To... alt C","Button"]
     copy_to = prj_template_form.FindChild(prop,val,20)
     Sys.HighlightObject(copy_to)    
     copy_to.Click()
     web_utils.log_checkpoint(" On 'Projects, Templates Summary' form click on 'Copy To' successful",500,jFrame) 
     Delay(3000)

# Entering Project details

     p_names = ("AWTComponentAccessibleName","AWTComponentIndex","JavaClassName")
     p_values = ("Project Quick Entry","0","ExtendedFrame")
     prj_quick_entry=jFrame.FindChildEx(p_names,p_values,60,True,60000)
     Sys.HighlightObject(prj_quick_entry)
     jFrame.Keys(VarToStr(app.Cells.Item[rowno,2])+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d%b%Y_%H%M%S"))
     web_utils.log_checkpoint(" On 'Projects Quick Entry' form 'Project Name' entered successfully : "+(VarToStr(app.Cells.Item[rowno,2])+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d%b%Y_%H%M%S")),500,jFrame)
     Delay(3000)
     
     jFrame.Keys("[Tab]")
     jFrame.Keys(app.Cells.Item[rowno,3])
     web_utils.log_checkpoint(" On 'Projects Quick Entry' form 'Organization' entered successfully : "+(VarToStr(app.Cells.Item[rowno,3])),500,jFrame)
     Delay(3000)
     
     jFrame.Keys("[Tab]")
     jFrame.Keys(VarToStr(app.Cells.Item[rowno,4])+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d%b%Y_%H%M%S"))
     web_utils.log_checkpoint(" On 'Projects Quick Entry' form 'Project Description' entered successfully :"+(VarToStr(app.Cells.Item[rowno,4])+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d%b%Y_%H%M%S")),500,jFrame)
     Delay(3000)
     
     jFrame.Keys("[Tab]")
     start_date = VarToStr("01-"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),'%b-%Y'))
     jFrame.Keys(start_date)
     
     web_utils.log_checkpoint(" On 'Projects Quick Entry' form 'Project Start Date' entered successfully :"+start_date,500,jFrame)
     Delay(3000)
     
     jFrame.Keys("[Tab][Tab][Tab][Tab][Tab][Tab]")
     jFrame.Keys(app.Cells.Item[rowno,7])
     web_utils.log_checkpoint(" On 'Projects Quick Entry' form 'Excecutive Owner' entered successfully :"+(VarToStr(app.Cells.Item[rowno,7])),500,jFrame)
     
     Delay(3000)
     jFrame.Keys("[Tab]")
     jFrame.Keys(app.Cells.Item[rowno,8])
     web_utils.log_checkpoint(" On 'Projects Quick Entry' form 'Business Owner' entered successfully :"+(VarToStr(app.Cells.Item[rowno,8])),500,jFrame)
     Delay(3000)
     
     jFrame.Keys("[Tab][Tab]")
     jFrame.Keys(app.Cells.Item[rowno,10])
     web_utils.log_checkpoint(" On 'Projects Quick Entry' form 'Project Manager' entered successfully :"+(VarToStr(app.Cells.Item[rowno,10])),500,jFrame)
     Delay(3000)
     
     jFrame.Keys("[Tab][Tab][Tab]")
     bc_value = VarToStr(app.Cells.Item[rowno,5])[2:]
     jFrame.Keys(bc_value)
     web_utils.log_checkpoint(" On 'Projects Quick Entry' form 'Business Category' entered successfully :"+bc_value,500,jFrame)
     Delay(3000)
     
     jFrame.Keys("[Tab][Tab][Tab][Tab]")
     jFrame.Keys(app.Cells.Item[rowno,6])
     web_utils.log_checkpoint(" On 'Projects Quick Entry' form 'Funding Category' entered successfully :"+(VarToStr(app.Cells.Item[rowno,6])),500,jFrame)

     Delay(3000)
     jFrame.Keys("~o")
     Delay(3000)
     jFrame.Keys("~o")
     Delay(3000)

# Changing the project status

     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Projects, Templates","ExtendedFrame"]
     prj_templates = jFrame.FindChildEx(prop,val,60,True,120000)
     obj=jFrame.FindChild(prop,val,50)
     if obj.Exists:
      web_utils.log_checkpoint("'Projects, Templates' form launched successfully",500,jFrame) 
     else:
      self.log_message_oracle_form(jFrame,"Unable to Launch 'Projects, Templates' form")
     prj_templates.FindChildEx("AWTComponentAccessibleName","Change Status alt C",60,True,60000).Click()
     web_utils.log_checkpoint("Project Status has been changed to 'Approved'",500,jFrame)
     Delay(3000)
     jFrame.Keys("~o")
     Delay(3000)
     prop=["AWTComponentIndex","JavaClassName","AWTComponentAccessibleName"]
     val=[1,"VTextField","Project Number"]
     prj_num = prj_templates.FindChild(prop,val,60).wText 
     app1.Cells.Item[rowno,11] = aqConvert.VarToStr(prj_num)
     app.Cells.Item[rowno,11] = aqConvert.VarToStr(prj_num)
     prop=["AWTComponentAccessibleName","AWTComponentIndex","JavaClassName"]
     val=["Status",8,"VTextField"]
     prj_status = prj_templates.FindChild(prop,val,60)
     Log.Enabled=True
     aqObject.CheckProperty(prj_status,"wText",cmpIn,"Approved")
     Log.Enabled=False
     Delay(3000)
     self.close_forms(jFrame)    
     del app,app1

