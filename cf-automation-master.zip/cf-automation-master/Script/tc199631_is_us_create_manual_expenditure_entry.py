﻿from   ebiz import *
import web_utils
import dbhelper
import file_system_utils
import random
from datetime import datetime




class tc199631_is_us_create_manual_expenditure_entry(Ebiz):


   def login(self):
     self.login_user='pkjami'
     super().login()
   
   def goto_url(self,url):
    super().goto_url(self.testConfig['ebiz']['oci_is_url'])
   
   def action(self,book): 
     app = book.Sheets.item["Project"] 
     app1 = book.Sheets.item["Requisition"]  
     rowno = 2
     web_utils.log_checkpoint("Logged in to Oracle Applications Home Page Successfully",500,self.page)
     self.wait_until_page_loaded()     
     self.page.EvaluateXPath("//table[@id='menuContent']//div[contains(text(),'PC User')]")[0].Click()  
     web_utils.log_checkpoint("Click 'PC User' - Successful",500,self.page) 
     self.page.Keys("[Down]")
     delay(2000)
     self.wait_until_page_loaded()
     self.page.NativeWebObject.Find("contentText","Expenditures","A").Click()  
     web_utils.log_checkpoint("Click 'Expenditures' - Successful",500,self.page) 
     self.page.wait()  
     self.wait_until_page_loaded()
     self.page.NativeWebObject.Find("contentText","Pre Approved Batches","A").Click()  
     web_utils.log_checkpoint("Click 'Pre Approved Batches' - Successful",500,self.page) 
     delay(2000)
     self.page.wait() 
     self.page.NativeWebObject.Find("contentText","Enter","A").Click()  
     web_utils.log_checkpoint("Click 'Enter' - Successful",500,self.page) 
     self.page.wait() 
     delay(10000)  
     web_utils.validate_security_box()
     jFrame = self.initializeJFrame()
     Delay(10000)
     form_utils.click_ok_btn(jFrame)
     
# Enter Batch Details:
     p_names = ("AWTComponentAccessibleName","JavaClassName")
     p_values = ("Expenditure Batches","ExtendedFrame")
     batch_form=jFrame.FindChildEx(p_names,p_values,60,True,120000)
     Sys.HighlightObject(batch_form)
     obj=jFrame.FindChild(p_names,p_values,50)
     if obj.Exists:
      web_utils.log_checkpoint("Expenditure Batches' form launched successfully",500,jFrame) 
     else:
      self.log_message_oracle_form(jFrame,"Unable to Launch 'Expenditure Batches' form")    
     Delay(10000)
     
  # Batch Description:
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Batch Required","VTextField"]
     batch_name = batch_form.FindChild(prop,val,20)
     Sys.HighlightObject(batch_name)    
     batch_name.Click()
     batch_desc = "SQA_Test_Misc_Batch_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),'%b%y%M%S')
     batch_name.Find(prop, val,30).Keys(batch_desc)
     jFrame.Keys("[Tab]")
     Delay(2000)
     web_utils.log_checkpoint("Entered Batch Name : "+batch_desc+ " in Expenditure Batches form",500,jFrame) 
     
  # Ending Date:
     val = ["Ending Date RequiredList of Values","VTextField"]
     end_date = batch_form.FindChild(prop,val,20)
     e_date = "15-"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),'%b-%Y')
     end_date.Keys(e_date)
     jFrame.Keys("[Tab]")
     disp_date = VarToStr(end_date.wText)
     web_utils.log_checkpoint("Entered Ending Date : "+disp_date+" in Expenditure Batches form",500,jFrame) 

     
  #Expense Class:
     val=["Class","VPopList"]
     exp_class = batch_form.FindChild(prop,val,20)
     Sys.HighlightObject(exp_class)   
     exp_class.ClickItem("Miscellaneous Transaction")
     web_utils.log_checkpoint("Selected Expenditure Class : Miscellaneous Transaction in Expenditure Batches form",500,jFrame) 
     delay(2000)
     
  #Open Expenditures Form:
     val=["Expenditures alt x","Button"]
     exp_btn = batch_form.FindChild(prop,val,20)
     Sys.HighlightObject(exp_btn)    
     exp_btn.Click()
     val =["Expenditures - *","ExtendedFrame"]
     exp_form = jFrame.FindChild(prop,val,20)
     Sys.HighlightObject(exp_form)
     web_utils.log_checkpoint("Expenditures Form for Batch: "+batch_desc+" opened Successfully",500,jFrame) 
     delay(2000)
  #Enter Organization:
     val = ["Organization RequiredList of Values","VTextField"]
     org = exp_form.FindChild(prop,val,20)
     Sys.HighlightObject(org) 
     org.Click()
     delay(500)
     org.Keys(app.Cells.Item[rowno,20])
     jFrame.Keys("[Tab]")
     web_utils.log_checkpoint("Entered Expenditure Organization",500,jFrame) 
     delay(2000)
     
  #validate Expenditure Item Details:
     rows = 2
     for i in range (0,rows):
       prop1=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
       val1 = ("Expnd Item Date RequiredList of Values","VTextField",i)
       exp_item_date = exp_form.FindChild(prop1,val1,30)
       exp_item_date.Click()
       exp_item_date.Keys(e_date)
       web_utils.log_checkpoint("Entered Expenditure Item Date for Expenditure Item Line#"+VarToStr(i+1)+" :"+e_date,500,jFrame) 
       delay(2000)
       val1 = ("Project Number RequiredList of Values","VTextField",7+i)
       project = exp_form.FindChild(prop1,val1,30)
       project.Click()
       project.Keys(app1.Cells.Item[rowno,11])
       web_utils.log_checkpoint("Project for Expenditure Item Line#"+VarToStr(i+1)+" :"+VarToStr(app1.Cells.Item[rowno,11]),500,jFrame) 
       delay(2000)
       val1 = ("Task Number RequiredList of Values","VTextField",14+i)
       task = exp_form.FindChild(prop1,val1,30)
       task.Click()
       t_val = VarToStr(app1.Cells.Item[rowno+i,12])[2:]
#       task_val = "%.1f" %(VarToFloat(t_val))
       task.Keys(t_val)
       web_utils.log_checkpoint("Task for Expenditure Item Line#"+VartoStr(i+1)+" :"+VarToStr(t_val),500,jFrame) 
       delay(2000)
       val1 = ("Expnd Type RequiredList of Values","VTextField",21+i)
       e_type = exp_form.FindChild(prop1,val1,30)
       e_type.Click()
       e_type.Keys(app1.Cells.Item[rowno+i,13])
       jFrame.Keys("[Tab]")
       web_utils.log_checkpoint("Expenditure Type for Expenditure Item Line#"+VarToStr(i+1)+" :"+VarToStr(app1.Cells.Item[rowno+i,13]),500,jFrame) 
       delay(2000)

       val1 = ("Quantity Required","VTextField",35+i)
       qty = exp_form.FindChild(prop1,val1,30)
       qty.Click()
       qty.Keys(app.Cells.Item[rowno+i,21])
       web_utils.log_checkpoint("Expenditure Quantity for Expenditure Item Line#"+VartoStr(i+1)+" :"+VarToStr(app.Cells.Item[rowno+i,21]),500,jFrame) 
       delay(2000)
    #Select Project Asset Type:
       val1 = ["[ ]","VTextField",49+i]
       at_dff = exp_form.FindChild(prop1,val1,30)
       Sys.HighlightObject(at_dff)
       at_dff.Click()
       delay(2000)
  #     web_utils.log_checkpoint("Click DFF to Enter Project Asset Type for Expenditure Item",500,jFrame)
       val = ["Expenditure Items","FlexWindow"]
       if jFrame.FindChild(prop,val,30).Exists:
         a_type_box = jFrame.FindChild(prop,val,30)
         Sys.HighlightObject(a_type_box)
       else:
         web_utils.log_error("unable to find flexwindow to enter 'project asset type'")
       val = ["Project Asset Type REQUIRED List Values: Expenses, Cost and CIP","FlexTextField"]
       asset_type = a_type_box.FindChild(prop,val,30)
       delay(500)
       a_type_box.Keys("^a[Del]")
       delay(1000)
       asset_type.Keys(app.Cells.Item[rowno,22])
  #     web_utils.log_checkpoint("Selected Project Asset Type :"+VarToStr(app.Cells.Item[rowno,22]),500,jFrame)
       a_type_box.Keys("~o")
       if a_type_box.Exists:
         val = ["OK ALT O","FormButton"]
         a_type_box.FindChild(prop,val,30).Click()
         delay(2000)
     exp_form.Keys("^s")
     delay(1000)
     val1 = ["Running Total","VTextField","15"]
     exp_form_rt = exp_form.FindChild(prop1,val1,30)
     Sys.HighlightObject(exp_form_rt)
     rt_val = exp_form_rt.wText
     web_utils.log_checkpoint("Running Total available in Expenditures Form (Header) :"+rt_val,500,jFrame)
     delay(1000)
     exp_form.Close()
     
  #Validate Current Cost and Expenditure Batch Status:
     val = ["Amounts Running Totals","VTextField"]
     running_total = batch_form.FindChild(prop,val,30).wText
     web_utils.log_checkpoint("Running Total available in Expenditures Batches Form :"+running_total,500,jFrame)
     if VarToInt(running_total)==VarToInt(rt_val):
       pass
     else:
       web_utils.log_error("Expenditures Form Running total Differs from Expenditure Batch Running Total")
     val1 = ["Status Required","VTextField","5"]
     status = batch_form.FindChild(prop1,val1,30)
     batch_status = status.wText
     web_utils.log_checkpoint("Batch Status :"+batch_status,500,jFrame)
#     #Control total:
#     val = ["Amounts: Control Totals","VTextField"]
#     control_total = batch_form.FindChild(prop,val,30)
#     control_total.Click()
#     control_total.Keys(VarToInt(running_total))
#     web_utils.log_checkpoint("Entered ControlTotal :"+running_total,500,jFrame)
#     #Control Count:
#     val = ["Amounts: Control Count","VTextField"]
#     control_count = batch_form.FindChild(prop,val,30)
#     control_count.Click()
#     control_count.Keys("1")
#     web_utils.log_checkpoint("Entered ControlCount :1",500,jFrame)
   #Submit:
     web_utils.log_checkpoint("Click Submit Button",500,jFrame)
     val = ["Submit alt i","Button"]
     batch_form.FindChild(prop,val,30).Click()
     delay(2000)
     web_utils.log_checkpoint("Batch Submitted Successfully",500,jFrame)
     batch_status = status.wText
     web_utils.log_checkpoint("Batch Status :"+batch_status,500,jFrame)
     if batch_status != 'Submitted':
       web_utils.log_error("Incorrect Batch Status After Batch Submission")
    
  # Release:
     web_utils.log_checkpoint("Click Release Button",500,jFrame)
     val = ["Release alt a","Button"]
     batch_form.FindChild(prop,val,30).Click()
     delay(2000)
     web_utils.log_checkpoint("Batch Released Successfully",500,jFrame)
     batch_status = status.wText
     web_utils.log_checkpoint("Batch Status :"+batch_status,500,jFrame)
     if batch_status != 'Released':
       web_utils.log_error("Incorrect Batch Status After Batch Release")
     Delay(3000)
     
  # Update:
     web_utils.log_checkpoint("Click Update Button",500,jFrame) 
     val = ["Expenditures alt U","Button"]
     batch_form.FindChild(prop,val,30).Click()
     delay(5000)
     if exp_form.Exists:
      Sys.HighlightObject(exp_form)
      web_utils.log_checkpoint("Expenditures Form for Batch: "+batch_desc+" opened Successfully for Update",500,jFrame) 
     else:
       web_utils.log_error("Unable to launch Expenditures Form for Batch: "+batch_desc+" for updates") 
     delay(1000)
     val1 = ("Quantity Required","VTextField",35)
     qty = exp_form.FindChild(prop1,val1,30)
     update_qty = (VarToInt(app.Cells.Item[rowno+i,21])+100)
     qty.Click()
     qty.Keys(update_qty)
     batch_form.Keys("[Tab]")
     web_utils.log_checkpoint("Expenditure Quantity updated for Expenditure Item Line#1 :"+VarToStr(update_qty),500,jFrame) 
     delay(1500)
     exp_form.Keys("^s")
     delay(1000)
     val1 = ["Running Total","VTextField","15"]
     exp_form_rt = exp_form.FindChild(prop1,val1,30)
     Sys.HighlightObject(exp_form_rt)
     rt_val = exp_form_rt.wText
     web_utils.log_checkpoint("Updated Running Total available in Expenditures Form (Header) :"+rt_val,500,jFrame)
     delay(1000)
     exp_form.Close()
     
  #update and release again:
     delay(1500)
     batch_status = status.wText
     web_utils.log_checkpoint("Updated Batch Status :"+batch_status,500,jFrame)
     #Submit:
     
     web_utils.log_checkpoint("Click Submit Button",500,jFrame)
     val = ["Submit alt i","Button"]
     batch_form.FindChild(prop,val,30).Click()
     delay(2000)
     web_utils.log_checkpoint("Batch Submitted Successfully",500,jFrame)
     batch_status = status.wText
     web_utils.log_checkpoint("Batch Status :"+batch_status,500,jFrame)
     if batch_status != 'Submitted':
       web_utils.log_error("Incorrect Batch Status After Batch Submission")
    
     #Release:
     web_utils.log_checkpoint("Click Release Button",500,jFrame)
     val = ["Release alt a","Button"]
     batch_form.FindChild(prop,val,30).Click()
     delay(2000)
     web_utils.log_checkpoint("Batch Released Successfully",500,jFrame)
     batch_status = status.wText
     web_utils.log_checkpoint("Batch Status :"+batch_status,500,jFrame)
     if batch_status != 'Released':
       web_utils.log_error("Incorrect Batch Status After Batch Release")
     Delay(3000)
   
     batch_form.Close()

     delay(1000)

  # Navigate to Expenditure Enquiry:

     prop2=["AWTComponentName","JavaClassName"]
     val2 = ["LWDataSourceList$Content222","LWDataSourceList$Content"]
     navigator = jFrame.FindChild(prop2,val2,30)
     Sys.HighlightObject(navigator)
     OCR.Recognize(navigator).BlockByText("Expenditures").DblClick()
     delay(1000)
     OCR.Recognize(navigator).BlockByText("Expenditure Inquiry").DblClick()  
     delay(1000)
     OCR.Recognize(navigator).BlockByText("All").DblClick()
     web_utils.log_checkpoint("Closing Expenditure Batches Form & Navigating to Expenditures > Expenditure Inquiry > All",500,jFrame)
  # Validate Expenditure Batch Details:
     val =["Find Expenditure Items","ExtendedFrame"]
     find_exp_items = jFrame.FindChild(prop,val,30)
     Sys.HighlightObject(find_exp_items)
     web_utils.log_checkpoint("Launched Find Expenditure Items Form Successfully",500,jFrame)
     val = ["Expenditure BatchList of Values","VTextField"]
     Enter_batch = find_exp_items.FindChild(prop,val,30)
     Enter_batch.Click()
     Enter_batch.Keys(batch_desc)
     delay(500)
     web_utils.log_checkpoint("Entered Expenditure Batch Name" +batch_desc+ " for Querying Details",500,jFrame)
     jFrame.Keys("[Tab]")
     Delay(500)
     val = ["Find alt i","Button"]
     find_exp_items.FindChild(prop,val,30).Click()
     delay(100000)
  # Validate Expenditure Items:
     count = 0
     val = ["Expenditure Items","ExtendedFrame"]
     while not jFrame.FindChildEx(prop,val,30,True,1000000).Exists:
       delay(5000)
       count = count+1
       if count == 5:
          web_utils.log_error("Unable to Launch Expenditure Items Form")      
     exp_items = jFrame.FindChildEx(prop,val,30,True,100000) 
     Sys.HighlightObject(exp_items)
     delay(4000)
     val2 = ["TitleBar$CaptionComp*","TitleBar$CaptionComp"]
     tool_bar = exp_items.FindChild(prop2,val2,30)
     Sys.HighlightObject(tool_bar)
     tool_bar.HoverMouse()
     delay(1500)
     tool_bar.DblClick()
     delay(4000)
     total_quantity = 0
     for j in range(0,rows):
      val1 = ["Quantity","VTextField",60+j]
      quantity = VarToInt(exp_items.FindChild(prop1,val1,30).wText)
      total_quantity = total_quantity+quantity
  # Validate Quantity:
     if VartoInt(rt_val)==VarToInt(total_quantity):
        web_utils.log_checkpoint("Quantity Available in Expenditure Items Form: "+VarToStr(total_quantity),500,jFrame)
        web_utils.log_checkpoint("Expenditure Item Details available for batch: "+batch_desc,500,jFrame)
     else:
#        web_utils.log_checkpoint("Quantity Available in Expenditure Items Form: "+VarToStr(quantity),500,jFrame)
        web_utils.log_error("Expenditure Details Not Available for the Batch")
     delay(1000)
     self.close_forms(jFrame)    
     del app,app1  
     
 
     
     
     
def test():
#  jFrame = Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1)
#  prop=["AWTComponentAccessibleName","JavaClassName"]
#  val = ["Expenditure Items","ExtendedFrame"]
#  exp_items = jFrame.FindChildEx(prop,val,30,True,10000) 
#  Sys.HighlightObject(exp_items)
##  Maximize(exp_items)
#  delay(1000)
#  prop = ["AWTComponentName","JavaClassName"]
#  val = ["TitleBar$CaptionComp409","TitleBar$CaptionComp"]
#  exp_items.FindChild(prop,val,30).DblClick()
#  delay(1000)
#  prop=["AWTComponentAccessibleName","JavaClassName"]
#  val = ["Quantity","VTextField"]
#  quantity = exp_items.FindChild(prop,val,30).wText
#  
#  
#  
#  val = ["LWDataSourceList$Content47","LWDataSourceList$Content"]
#  navigator = jFrame.FindChild(prop,val,30)
#  Sys.HighlightObject(navigator)
#  OCR.Recognize(navigator).BlockByText("Expenditures").DblClick()
#  delay(1000)
#  OCR.Recognize(navigator).BlockByText("Expenditure Inquiry").DblClick()  
#  delay(1000)
#  OCR.Recognize(navigator).BlockByText("All").DblClick()
  
#  prop=["AWTComponentAccessibleName","JavaClassName"]
#  val = ("Budget Lines*","ExtendedFrame")
#  budget_lines=jFrame.FindChildEx(prop,val,60,True,120000)
#  val = ("Resource\nAliasList of Values","VTextField")
#  resource = budget_lines.FindChild(prop,val,20)
#  Sys.HighlightObject(resource)


     
#  # Batch Description:
#     jFrame = Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1)
#     prop=["AWTComponentAccessibleName","JavaClassName"]
#     val = ("Expenditure Batches","ExtendedFrame")
#     batch_form=jFrame.FindChildEx(prop,val,60,True,120000)
#
#  #Expense Class:
#     val=["Class","VPopList"]
#     exp_class = batch_form.FindChild(prop,val,20)
#     Sys.HighlightObject(exp_class)   
#     exp_class.ClickItem("Miscellaneous Transaction")
  task = VarToStr("A-9")[2:]
  task_val = "%.1f" %(VarToFloat(task))
  date = aqDateTime.Now()
#  n_date = aqDateTime.SetDateElements(%Y, 1, 1)
  f_date = "15-"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),'%b-%Y')
  delay(2000)
  n_date = aqDateTime.AddDays(f_date,365)
  n1_date = aqConvert.DateTimeToFormatStr(n_date,'%d-%b-%Y')
  delay(1000)


def Test1():
     today = aqConvert.DateTimeToFormatStr(aqDateTime.Now(),'%d-%b-%Y')
     if aqString.SubString(today,3,3)== 'MAR' or 'MaY':
         pass
