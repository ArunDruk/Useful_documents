﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils
import web_utils
import form_utils



class tc194049_run_payable_open_interface_import_process(Ebiz):
  global rowno
  rowno = 2
  op_log_path ="C:\\TC_Logs"
  
  def login(self):
    self.login_user = "rmaran"
    super().login()
    
  def action(self,book): 
    app = book.Sheets.item["Invoice"]
    app1 = book.Sheets.item["mail_wcc"]
    self.wait_until_page_loaded()
    web_utils.log_checkpoint("Logged in to Oracle Applications Home Page Successfully",500,self.page)
    self.wait_until_page_loaded()    
    temp=web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" AP INVOICE PROCESSING')]")       
    self.verify_aqobject_chkproperty(temp[0],"contentText",cmpIn,"CAI "+self.oper_unit+" AP INVOICE PROCESSING")    
    self.wait_until_page_loaded()      
    web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Invoices')]")            
    Delay(3000)
    temp=web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Inquiry')]")       
    Delay(3000)
    self.page.EvaluateXPath("//div[text()='Invoices']")[2].Click()
    self.wait_until_page_loaded() 
    Delay(2000)
    web_utils.validate_security_box()
    delay(4000)     
    jFrame=self.initializeJFrame()
    Delay(5000)
    form_utils.click_ok_btn(jFrame)
    Delay(3000)
    
#Submitting Payables Open Interface Import Concurrent Job
    jFrame.Keys("[F4]")
    Delay(4000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~n")
    Delay(5000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit a New Request","ExtendedFrame"]
    submit_req_form=jFrame.FindChildEx(prop,val,30,True,60000)
    submit_req_form.FindChild("AWTComponentAccessibleName","OK alt O",10).Click()
    Delay(5000)
    jFrame.Keys("Payables Open Interface Import")
    delay(3000)
    jFrame.Keys("[Tab]")
    Delay(4000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Parameters","FlexWindow"]
    parameters_form=jFrame.FindChild(prop,val,60)
    Delay(3000) 
    parameters_form.Find("AWTComponentAccessibleName","Source REQUIRED List Values",30).Click()    
    jFrame.Find("AWTComponentAccessibleName","Source REQUIRED List Values",30).Keys('WCI_INVOICE')
    delay(3000)

    jFrame.Keys("[Tab]")
#    jFrame.Find("AWTComponentAccessibleName","Batch Name REQUIRED*",30).Click()  
#    jFrame.Find("AWTComponentAccessibleName","Batch Name REQUIRED*",30).Keys("^a[BS]")
#    delay(3000)
#    jFrame.Find("AWTComponentAccessibleName","Batch Name REQUIRED*",30).Keys(app1.Cells.Item[rowno,2])
    web_utils.log_checkpoint("'Payables Open Interface Import' program parameters entered successfully",500,jFrame)
    jFrame.keys("~o")
    Delay(15000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit Request","ExtendedFrame"]
    submitrequest_form=jFrame.FindChildEx(prop,val,60,True,90000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit alt m","Button"]
    submit_button=submitrequest_form.FindChild(prop,val,60)
    submit_button.Find("AWTComponentAccessibleName","Submit alt m").Click()
    Delay(3000)
   
# Capturing RequestID

    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Decision","LWLabel"]
    parameters_form=jFrame.FindChildEx(prop,val,60,True,60000)
    Delay(2000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Decision Request Submitted*","ChoiceBox"]
    decision_form=jFrame.FindChildEx(prop,val,60,True,40000)  
    RequestID = ''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit())
    web_utils.log_checkpoint("'Payables Open Interface Import' is submitted and Request ID is " + aqConvert.VarToStr(RequestID),500,jFrame)
    Delay(2000)
    Rid =aqConvert.VarToStr(RequestID)
    jFrame.Keys("~n")
    Delay(9900)  
    dsn = self.testConfig['oracle_db']['dsn']
    user_id = self.testConfig['oracle_db']['userid']
    pwd = self.testConfig['oracle_db']['pwd']
    dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,RequestID)
    
#Capturing Output and Log for Payables Open Interface Import

    jFrame.Keys("~v")
    Delay(4000)
    jFrame.Keys("r")
    Delay(4000)
    jFrame.Keys("~s")
    Delay(3000)
    prop_names=["JavaClassName","AWTComponentAccessibleName"]
    prop_values=["VTextField","Request ID"]
    temp=jFrame.FindAll(prop_names,prop_values,60)
    jFrame.Find("AWTComponentName",temp[10].AWTComponentName,60).Click()
    jFrame.Find("AWTComponentName",temp[10].AWTComponentName,60).SetText(RequestID)
    Delay(2000)
    self.log_message_oracle_form(jFrame ,"Query for Submitted Request ID:" +RequestID)
    jFrame.Keys("~i")
    Delay(2000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,60000)
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Phase",40]
    phase=req_form.Find(prop,val,10).wText 
    while phase != 'Completed':
     Delay(1000)
     req_form.keys("~r")
     Delay(4000)
    web_utils.log_checkpoint("'Payables Open Interface Import' program phase Completed",500,jFrame)
    jFrame.Keys("~k")
    file_type = 'Log'
    self.save_log(file_type)
    delay(4000)
    jFrame.Keys("~p")
    file_type = 'Output'
    self.save_log(file_type)
    Delay(6000)
    jFrame.Keys("[F4]")
    Delay(4000)
    jFrame.Keys("[F4]")
    Delay(2000)
    jFrame.Keys("~o")
    Delay(2000)
    self.page.wait_until_page_loaded()
    

  def save_log(self,file_type):
   
   Delay(15000)
   self.wait_until_page_loaded()
   log_page=Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
   Delay(1000)
   log_page.Click()
   log_page.TextNode(0).Click()
   Delay(1000)
   Log.Enabled=True     
   screenshot=log_page.PagePicture()
   msg = (file_type+" File Opened Successfully")
   Log.Picture(screenshot,msg)
   Log.Enabled=False
   log_page.Keys("~f")
   Delay(5000)
   log_page.Keys("a")
   Delay(5000) 
   file_system_utils.create_folder(self.op_log_path)             
   log_path=self.op_log_path+"\\Payables Open Interface Import "+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
   Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
   Delay(3000)
   Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
   Delay(5000)
   Log.Enabled=True
   Log.File(log_path,"Payables Open Interface Import "+file_type+" file Attached")
   Log.Enabled=False     
   Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close()
   web_utils.close_additional_browsers()

