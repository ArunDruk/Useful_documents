﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils


class tc84513_cai_us_manual_journals_enter(Ebiz): 
 global rowno
 op_log_path="C:\\TC_Logs"
 
 
 def login(self):
   self.login_user='mfallwell'
   super().login()
   
 def action(self,book): 
     Log.Enabled=True
     Log.Message("Currency Selected for manual journal entry: "+ProjectSuite.Variables.currency)
     Log.Enabled=False
     if ProjectSuite.Variables.currency =="USD": 
      app = book.Sheets.item["ManualJournal_USD"]
     elif ProjectSuite.Variables.currency=="CAD":
      app = book.Sheets.item["ManualJournal_CAD"]
     Log.Message("Inside action") 
     Delay(3000)
     web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI ALL GL JOURNAL PROCESSING')]")
     self.log_message_web("Click 'CAI ALL GL JOURNAL PROCESSING' - Successful")
     Delay(3000)
     self.page.EvaluateXpath("//table[@id='respList']//div[text()='Enter Journals']")[0].Click()
     self.log_message_web("Click 'Enter Journals'- Successful")
     web_utils.validate_security_box()
     Delay(20000)
     jFrame=self.initializeJFrame()
     Delay(8000)
     form_utils.click_ok_btn(jFrame)
     Delay(5000) 
     jFrame.Keys("~j")
    
#Entering Journal Header Information for USD Currency
     if ProjectSuite.Variables.currency =="USD": 
        prop=["AWTComponentAccessibleName","JavaClassName"]
        val=["Journals (CAI ALL LEDGERS)*","ExtendedFrame"]
        jrnl_form=jFrame.FindChildEx(prop,val,60,True,60000)
        jrnl_form.Find("AWTComponentAccessibleName","Journal Required",10).SetText(VarToStr(app.Cells.Item[2,1]))
        jrnl_form.Find("AWTComponentAccessibleName","Category RequiredList of Values",10).SetText(VarToStr(app.Cells.Item[2,2]))
      
  #Entering Journal Line Level information for USD Currency
        i=2
        j=0
        while j<8:
          pro_names=["AWTComponentAccessibleName","AWTComponentIndex"]
          pro_values=["Line*",j] #pro_values=["Line Required",0]
          jrnl_form.Find(pro_names,pro_values,30).click()
          jrnl_form.Find(pro_names,pro_values,30).SetText(VarToStr(app.Cells.Item[i,3]))

             
          aqUtils.Delay(2000)
          pro_names=["AWTComponentAccessibleName","AWTComponentIndex"]
          pro_values=["*Account*",7+j+1] #pro_values=["Account RequiredList of Values",8]
          jrnl_form.Find(pro_names,pro_values,15).click()
          jrnl_form.Find(pro_names,pro_values,15).SetText(VarToStr(app.Cells.Item[i,4]))

        
          aqUtils.Delay(2000)
          pro_names=["AWTComponentAccessibleName","AWTComponentIndex"]
          pro_values=["*Debit*",0+j] #pro_values=["Lines tab page Entered: Debit Required",0]
          jrnl_form.Find(pro_names,pro_values,15).SetText(VarToStr(app.Cells.Item[i,5])) 
          jrnl_form.Find(pro_names,pro_values,15).Keys("[Tab]")   
       
          aqUtils.Delay(5000)
          pro_names=["AWTComponentAccessibleName","AWTComponentIndex"]
          pro_values=["*Credit*",8+j] 
          jrnl_form.Find(pro_names,pro_values,15).SetText(VarToStr(app.Cells.Item[i,6]))
          jrnl_form.Find(pro_names,pro_values,15).Keys("[Tab]")   
           
          pro_names=["AWTComponentAccessibleName","AWTComponentIndex"]
          pro_values=["Line Required",j+1]
          x=0
          while x<9:
            jrnl_form.FindChild(pro_names,pro_values,30).click()
            x=x+1
            delay(1000)     
          j=j+1
          i+=1
        
#Entering Journal Header Information for CAD Currency
     elif ProjectSuite.Variables.currency=="CAD": 
        prop=["AWTComponentAccessibleName","JavaClassName"]
        val=["Journals (CAI ALL LEDGERS)*","ExtendedFrame"]
        jrnl_form=jFrame.FindChildEx(prop,val,60,True,60000)
        jrnl_form.Find("AWTComponentAccessibleName","Journal Required",10).SetText(VarToStr(app.Cells.Item[2,1]))
        delay(1000) 
        jrnl_form.Find("AWTComponentAccessibleName","Category RequiredList of Values",10).SetText(VarToStr(app.Cells.Item[2,2]))
        delay(1000) 
        jrnl_form.Find("AWTComponentAccessibleName","Conversion: Currency RequiredList of Values",10).Click()
        jrnl_form.Find("AWTComponentAccessibleName","Conversion: Currency RequiredList of Values",10).Keys("[BS][BS][BS]")
        jrnl_form.Find("AWTComponentAccessibleName","Conversion: Currency RequiredList of Values",10).SetText("CAD")
        jFrame.Keys("[Tab]")
        delay(3000) 
        pro_names=["AWTComponentAccessibleName","AWTComponentIndex"]
        pro_values=["Conversion: Date RequiredList of Values",12]
        jrnl_form.Find(pro_names,pro_values,30).Click()
        jrnl_form.Find(pro_names,pro_values,30).Keys("[BS][BS][BS][BS][BS][BS][BS][BS][BS][BS]")
        jrnl_form.Find(pro_names,pro_values,30).SetText("27-AUG-2019")
        jFrame.Keys("[Tab]")
        delay(3000) 
        pro_names=["AWTComponentAccessibleName","AWTComponentIndex"]
        pro_values=["Conversion: Type RequiredList of Values",13]
        jrnl_form.Find(pro_names,pro_values,30).Click()
        jrnl_form.Find(pro_names,pro_values,30).SetText("Corporate")
        jFrame.Keys("[Tab]")
        delay(3000) 
      
  #Entering Journal Line Level information for CAD Currency
        i=2
        j=0
        while j<8:
          pro_names=["AWTComponentAccessibleName","AWTComponentIndex"]
          pro_values=["Line*",j] #pro_values=["Line Required",0]
          jrnl_form.Find(pro_names,pro_values,30).click()
          jrnl_form.Find(pro_names,pro_values,30).SetText(VarToStr(app.Cells.Item[i,3]))
          jrnl_form.Find(pro_names,pro_values,15).Keys("[Tab]") 
             
          aqUtils.Delay(2000)
          pro_names=["AWTComponentAccessibleName","AWTComponentIndex"]
          pro_values=["*Account*",7+j+1] #pro_values=["Account RequiredList of Values",8]
          jrnl_form.Find(pro_names,pro_values,15).click()
          jrnl_form.Find(pro_names,pro_values,15).SetText(VarToStr(app.Cells.Item[i,4]))
          jrnl_form.Find(pro_names,pro_values,15).Keys("[Tab]") 
        
          aqUtils.Delay(2000)
          pro_names=["AWTComponentAccessibleName","AWTComponentIndex"]
          pro_values=["*Debit*",0+j] #pro_values=["Lines tab page Entered: Debit Required",0]
          jrnl_form.Find(pro_names,pro_values,15).SetText(VarToStr(app.Cells.Item[i,5])) 
          jrnl_form.Find(pro_names,pro_values,15).Keys("[Tab]")   
       
          aqUtils.Delay(5000)
          pro_names=["AWTComponentAccessibleName","AWTComponentIndex"]
          pro_values=["*Credit*",8+j] 
          jrnl_form.Find(pro_names,pro_values,15).SetText(VarToStr(app.Cells.Item[i,6]))
          jrnl_form.Find(pro_names,pro_values,15).Keys("[Tab]")   
           
          pro_names=["AWTComponentAccessibleName","AWTComponentIndex"]
          pro_values=["Line Required",j+1]
          x=0
          while x<9:
            jrnl_form.FindChild(pro_names,pro_values,30).click()
            x=x+1
            delay(1000)     
          j=j+1
          i+=1

        
     jFrame.Keys("^s")
     Delay(5000) 
     self.log_message_oracle_form(jFrame,"Entered Journal Header and Journal Line Information Successfully")
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Journals (CAI ALL LEDGERS)*","ExtendedFrame"]
     Journals_Frame=jFrame.FindChild(prop,val,60)
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Approve alt A","Button"]
     Journals_Frame.Find(prop,val,60).Click()
     self.log_message_oracle_form(Journals_Frame,"Click Approve Button Next on Journals Form")
     Delay(4000)
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Note Your journal batch was forwarded to an approver.","ChoiceBox"]
     Note_Form=jFrame.FindChildEx(prop,val,60,True,40000)
     self.log_message_oracle_form(Note_Form," Click OK Button Next on Note Form with message -Note Your journal batch was forwarded to an approver.")
     Note_Form.Keys("~o")   
     Delay(3000)
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Journals (CAI ALL LEDGERS)*","ExtendedFrame"]
     batch_name=(jFrame.FindChildEx(prop,val,60,True,40000).AWTComponentAccessibleName)[29:]
     app.Cells.Item[2,9]=VarToStr(batch_name)
     self.log_message_oracle_form(jFrame,"Batch Name: "+VarToStr(batch_name))
     Sys.Keys("[F4]") 
     Delay(4000)
     Sys.Keys("[F4]") 
     Delay(2000)
     Sys.Keys("[F4]")
     Delay(2000)
     Sys.Keys("~o")
     Delay(2000)  
     Sys.Keys("[F4]") 
     Delay(2000)
     Sys.Keys("[F4]") 
     Delay(2000)
     Sys.Keys("~o")   



