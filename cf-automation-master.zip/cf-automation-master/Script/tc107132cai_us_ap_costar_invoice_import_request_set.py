﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils
import winscp_utility

####This testcase is to place the CoStar import file in the AP inbound directory using WINSCP### 
###and submit CAI US AP CoStar Invoice Import Request Set, capture logs and output files###

class tc107132cai_us_ap_costar_invoice_import_request_set(Ebiz):
 
 op_log_path="C:\\TC_Logs"
 costar_inv_files="C:\\CoStar_Inv_Files"
 
 def login(self):
    self.login_user="ctucker"
    super().login()
 
 def action(self,book):
    app = book.Sheets.item["Invoice"]
    global inv_num,rowno
    rowno = 2
    self.add_costar_invoice_details()
    self.place_inv_file_winscp(app)

### Modifying CoStar_INV_CAI_US_2019.txt file 

 def add_costar_invoice_details(self):
    file_name= Project.Path+"DataSheets\\Oracle-AP-Other\\CoStar_INV_CAI_US_2019.txt"
    self.inv_num = "CSINV_"+aqConvert.DateTimeToFormatStr(aqDateTime.Time(),"%H:%M:%S")
    inv_date = aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%m/%d/%Y")
    fo=open(file_name,"r+")
    lines=fo.readlines()
    old_inv_num=lines[1][16:31].strip() 
    old_inv_date=lines[1][34:42].strip()          
    fo.close()
    fo=open(file_name,"r+")
    data=fo.read()
    fo.seek(654,0)
    fo.write(self.inv_num) 
    fo.seek(671,0)
    fo.write (aqConvert.VartoStr(inv_date))   
    fo.close()
    file_system_utils.create_folder(self.costar_inv_files)
    file_exist=aqFileSystem.FindFiles("C:\\CoStar_Inv_Files\\","CoStar_INV_CAI_US_2019.txt")
    if file_exist != None:
     aqFileSystem.DeleteFile("C:\\CoStar_Inv_Files\\CoStar_INV_CAI_US_2019.txt")
    aqFileSystem.CopyFile(Project.Path+"DataSheets\\Oracle-AP-Other\\CoStar_INV_CAI_US_2019.txt", "C:\\CoStar_Inv_Files\\CoStar_INV_CAI_US_2019.txt")
    log_path = ("C:\\CoStar_Inv_Files\\CoStar_INV_CAI_US_2019.txt")
    Log.Enabled=True
    Log.File(log_path, "CoStar Invoice Import File Attached")
    Log.Enabled=False 

# Placing cai_excel_invoice_import_report_set.csv file in //TAUT1I//incoming//ATG_OU//AP_INV_IMP_COSTAR folder

 def place_inv_file_winscp(self,app):
#    Stored_session = "opc@stage-fin-iad1-ebsapp1.private.stagefin.oraclevcn.com"
    Stored_session = "costar@mftstg.manheim.com"
    local_dir = "C:\\CoStar_Inv_Files"
    remote_dir =  self.testConfig['winscp']['cai_remote_dir']  
#    remote_dir =  "//Outbox//TAUTRI"
    upload_file_name = "CoStar_INV_CAI_US_2019.txt"
    winscp_utility.upload_file(Stored_session,local_dir,remote_dir,upload_file_name)
    Log.Enabled=True       
    Log.Message("CoStar_INV_CAI_US_2019.txt file placed in the AP_INV_IMP_COSTAR directory")           
    Log.Enabled=False

# Submitting the CAI US AP CoStar Invoice Import Request Set in Oracle

    Log.Message("Inside action...") 
    self.page.WaitProperty("contentText","CAI "+self.oper_unit+" AP JOB SCHEDULER",6000)
    cai_ap_invpro_link=self.page.Find("contentText","CAI "+self.oper_unit+" AP JOB SCHEDULER",30)
    self.verify_aqobject_chkproperty(cai_ap_invpro_link,"contentText",cmpIn,"CAI "+self.oper_unit+" AP JOB SCHEDULER")
    cai_ap_invpro_link.Click() 
    self.log_message_web("Click 'CAI "+self.oper_unit+" AP JOB SCHEDULER' - Successful")
    delay(1000)
    self.page.keys("[Down]")
    cai_inv_ent_link=self.page.Find("contentText","Submit Request",30)
    self.verify_aqobject_chkproperty(cai_inv_ent_link,"contentText",cmpIn,"Submit Request")
    cai_inv_ent_link.Click() 
    self.log_message_web("Click 'Submit Request' - Successful") 
    delay(4000) 
    web_utils.validate_security_box()
    jFrame=self.initializeJFrame() 
    delay(5000)
    
    form_utils.click_ok_btn(jFrame)
    
    
#    jFrame = Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1)
#    delay(4000)
#    jFrame.Keys("~o")
#    delay(4000)
#    jFrame.Keys("~s")
#    delay(2000)
#    jFrame.Keys("~o")
#    delay(2000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit a New Request","ExtendedFrame"]
    submit_new_req_form=jFrame.FindChildEx(prop,val,60,True,90000)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["What type of request do you want to run? Request Set alt s","ExtendedCheckbox"]  
    submit_new_req_form.FindChild(prop,val,10).Click()       
    Delay(1000)
    submit_new_req_form.FindChild("AWTComponentAccessibleName","OK alt O",10).Click()
     
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit Request Set","ExtendedFrame"]
#    par_form=jFrame.FindChildEx(prop,val,60,True,60000)
    par_form=jFrame.FindChild(prop,val,60)
    delay(2000)
    
    par_form.Find("AWTComponentAccessibleName","Request Set RequiredList of Values",30).SetText("CAI "+self.oper_unit+" AP CoStar Invoice Import Request Set")
    delay(1000)
    jFrame.Keys("[Tab]")
    par_form.Find("wText","CAI Inbound Global File Validation Program",30).Click()
    delay(1000)
    jFrame.Keys("[Tab]")
    delay(1000)
    jFrame.Keys("~o")
    delay(1000) 
    
    par_form.Find("wText","CAI File Decrypt Program",30).Click()
    jFrame.Keys("[Tab]")
    delay(1000)
    jFrame.Keys("[BS]")
    jFrame.Keys("Y")
    delay(1000)
    jFrame.Keys("~o")
    
    delay(1000)
    par_form.Find("wText","CAI Global Data Loader",30).Click()
    jFrame.Keys("[Tab]")
    delay(1000)
    jFrame.Keys("~o")
    
    delay(1000)
    par_form.Find("wText","CAI CoStar Invoice Validation and Import Program",30).Click()
    jFrame.Keys("[Tab]")
    delay(1000)
    jFrame.Keys("~o")
    delay(1000)
    val = ["Submit","Button"]
    par_form.FindChild(prop,val,30).Click()
    delay(1000)
    RequestID = ''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit())
    Log.Message("Request ID Of 'CAI CoStar Invoice Validation and Import Program' is  " + aqConvert.VarToStr(RequestID))
    self.log_checkpoint_message_web("Request ID Of CAI "+self.oper_unit+" AP CoStar Invoice Import Request Set (Report Set) is " + aqConvert.VarToStr(RequestID))    
    delay(1000)    
    jFrame.Keys("~n")
    delay(1000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000)    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,90000)
    
# Checking in the DB for the completion of the concurrent programs
    dsn = self.testConfig['oracle_db']['dsn']
    user_id = self.testConfig['oracle_db']['userid']
    pwd = self.testConfig['oracle_db']['pwd']
    dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,VarToStr(RequestID)) 
    
    file_format = "log"
    self.req_set_save_file(jFrame,req_form,"CAI CoStar Invoice Validation and Import Program",RequestID,file_format)
#    jFrame.Click()
#    Delay(2000)
#    jFrame.Keys("[F4]")
#    Delay(1000)
#    jFrame.Keys("~v")
#    Delay(1000)
#    jFrame.Keys("r")
#    Delay(1000)
#    jFrame.Keys("~i")
#    Delay(1000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,90000)
    
    file_format = "output"
    self.req_set_save_file(jFrame,req_form,"Payables Open Interface Import - COSTAR (Payables Open Interface Import)",RequestID,file_format)
#    jFrame.Click()
#    Delay(2000)
#    jFrame.Keys("[F4]")
#    Delay(1000)
#    jFrame.Keys("~v")
#    Delay(1000)
#    jFrame.Keys("r")
#    Delay(1000)
#    jFrame.Keys("~i")
    Delay(3000)
    dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
    user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
    pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
    dbhelper.verify_costar_invoice_info(dsn,user_id,pwd,self.inv_num)    
    app.Cells.Item[rowno,13] = self.inv_num
    Delay(1000)
    web_utils.close_additional_browsers()
    Delay(1000)
    jFrame.Click()
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~o")
    Delay(3000)    
    
#   Validating the Invoice in the Front end and checking Headerlevel DFF and Linelevel DFF
    self.page.WaitProperty("contentText","CAI US AP INVOICE PROCESSING",6000)
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" AP INVOICE PROCESSING')]") 
    self.log_message_web("Click 'CAI US AP INVOICE PROCESSING' - Successful")    
    self.page.keys("[Down]")
    Delay(1000)
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Invoices')]")
    self.log_message_web("Click 'Invoices' - Successful")
    delay(1000)  
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Entry')]")  
    self.log_message_web("Click 'Entry' - Successful")
    delay(1000)    
    self.page.EvaluateXPath("//div[text()='Invoices']")[1].Click()
    self.log_message_web("Click 'Invoices' - Successful")
    delay(20000) 
    jFrame=self.initializeJFrame() 
    Delay(10000)
    form_utils.click_ok_btn(jFrame)
    Delay(6000)
    jFrame.Keys("~v")
    delay(6000)
    jFrame.Keys("f")
    delay(6000)
    
#   Finding Invoice
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Invoices","ExtendedFrame"]
    par_form=jFrame.FindChildEx(prop,val,60,True,60000)
    par_form.Find("AWTComponentAccessibleName","Invoice: Number",10).Click()
    par_form.Find("AWTComponentAccessibleName","Invoice: Number",10).Keys(app.Cells.Item[rowno,13])
#    jFrame.Keys("[Tab]")
#    jFrame.Keys("[Tab]")
#    jFrame.Keys("[Tab]")
#    jFrame.Keys("[Tab]")
#    jFrame.Keys("[Tab]")
#    jFrame.Keys("[Tab]")
#    jFrame.Keys("[Tab]")
#    jFrame.Keys("[Tab]")
#    jFrame.Keys("[Tab]")
#    jFrame.Keys(aqConvert.DateTimeToFormatStr(aqDateTime.Today(),"%d-%b-%Y"))
#    delay(3000)
#    jFrame.Keys("[Tab]")
#    jFrame.Keys(aqConvert.DateTimeToFormatStr(aqDateTime.Today(),"%d-%b-%Y"))
    delay(5000) 
    jFrame.Keys("~i")
    Delay(10000)
    self.log_message_oracle_form(jFrame,"'Invoice Workbench' form launched successfully")
    menu_bar=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWMenuBar", "", 0)
    OCR.Recognize(menu_bar).BlockByText("Folder").Click()
    Delay(1000)
    jFrame.Keys("o")
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Invoice Workbench*","ExtendedFrame"]
#    invoice=jFrame.FindChildEx(prop,val,60,True,60000)
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Open Folder*","VButton"]
#    open_fldr_form=invoice.FindChildEx(prop,val,30,True,60000)
#    open_fldr_form.Click()
    Delay(4000)
    jFrame.Keys("d")
    delay(5000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Open Folder","FWindow"]
    open_folder=jFrame.FindChildEx(prop,val,50,True,90000)  
    Sys.HighlightObject(open_folder)     
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["OK ALT O","PushButton"]   
    open_folder.FindChild(prop,val,10).Click()
    
#    Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications - EBS", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("FWindow", "Open Folder", 0).AWTObject("LWComponent", "", 0).AWTObject("EwtContainer", "", 0).AWTObject("ButtonBar", "", 0).AWTObject("ButtonBar", "", 1).AWTObject("PushButton", "OK ALT O", 0).Click()
    delay(4000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Invoice Workbench*","ExtendedFrame"]
    invoice=jFrame.FindChildEx(prop,val,60,True,60000)
    prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
    val=["[ ]","VTextField","196"]
    hdr_level_dff=invoice.FindChildEx(prop,val,30,True,60000)
    hdr_level_dff.Click()
    delay(4000)
    self.log_message_oracle_form(jFrame,"'CoStar' Invoice Header Level DFF values reviewed successfully")
    delay(4000)
    jFrame.Keys("[F4]")
    delay(4000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Invoice Workbench*","ExtendedFrame"]
    invoice=jFrame.FindChildEx(prop,val,60,True,60000)
    self.log_message_oracle_form(jFrame,"Click on 'Lines' on 'Invoice Workbench' next")
    Delay(5000)
    invoice.FindChild("AWTComponentName","FormsTabPanel*",60).ClickTab("2 Lines")
    Delay(5000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Open Folder*","VButton"]
    open_fldr_form=jFrame.FindChildEx(prop,val,30,True,60000)
    open_fldr_form.Click()
    Delay(6000)
    jFrame.Keys("s")
    delay(5000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Open Folder","FWindow"]
    open_folder=jFrame.FindChildEx(prop,val,50,True,90000)  
    Sys.HighlightObject(open_folder)     
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["OK ALT O","PushButton"]   
    open_folder.FindChild(prop,val,10).Click()
#    Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications - EBS", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("FWindow", "Open Folder", 0).AWTObject("LWComponent", "", 0).AWTObject("EwtContainer", "", 0).AWTObject("ButtonBar", "", 0).AWTObject("ButtonBar", "", 1).AWTObject("PushButton", "OK ALT O", 0).Click()
    delay(4000)
    prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
    val=["[ ]","VTextField","405"]
    line_level_dff=jFrame.FindChildEx(prop,val,30,True,60000)
    line_level_dff.Click()
    delay(4000)
    self.log_message_oracle_form(jFrame,"'CoStar' Invoice Line Level DFF values reviewed successfully")
    delay(4000)
    jFrame.Keys("[F4]")
    delay(6000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~o")
    Delay(3000) 
    
    
    
    
    
    
    

 def req_set_save_file(self,jFrame,req_form,srch_child_name,Preqid,file_format):
      self.log_message_oracle_form(req_form,"Checking for "+aqConvert.VarToStr(srch_child_name)+ " Child Program Status")
      req_form.FindChild("AWTComponentAccessibleName","Refresh Data alt R",20).Click()
      i=20
      for x in range(1,180):     
          prop=["AWTComponentAccessibleName","AWTComponentIndex"]
          val=["Name",i]
          child_name=req_form.Find(prop,val,10).wText 
          prop=["AWTComponentAccessibleName","AWTComponentIndex"]
          val=["Phase",i+20]
          phase=req_form.Find(prop,val,10).wText 
          prop=["AWTComponentAccessibleName","AWTComponentIndex"]
          val=["Request ID",i-10]
          creqid= req_form.Find(prop,val,10).wText
  #        self.log_message_oracle_form(req_form,"Request ID of "+aqConvert.VarToStr(srch_child_name)+" is "+aqConvert.VarToStr(creqid))                                         
          prop=["AWTComponentAccessibleName","AWTComponentIndex"]
          val=["Status",i+30]         
          status =req_form.FindChild(prop,val,60)            
          if (child_name==srch_child_name) and (VarToInt(creqid)>=VarToInt(Preqid)) and (phase == "Completed"):
              self.log_message_oracle_form(req_form, aqConvert.VarToStr(srch_child_name)+" Phase Completed Successfuly")             
  #            self.verify_aqobject_chkproperty(status,"wText",cmpContains,"Normal")        
              status.Keys("[Enter]")
              Delay(1000)
  #            jFrame.Keys("~g")  
              if file_format == "log":
                req_form.FindChild("AWTComponentAccessibleName","View Log alt K",20).Click()
              elif file_format == "output":
                req_form.FindChild("AWTComponentAccessibleName","View Output alt p",20).Click()  
              Delay(3000)
              output_page=Sys.Browser("iexplore").Page("https://core*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.*")
              output_page.Click()
              Delay(2000)
              output_page.Keys("~f")
              Delay(2000)
              output_page.Keys("a")
              Delay(5000)
              file_system_utils.create_folder(self.op_log_path)             
              log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"File"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"_%d%b%Y_%H%M")+".txt"    
              Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
              Delay(1000)
              Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
              Delay(2000)
              Log.Enabled=True
              Log.File(log_path, aqConvert.VarToStr(srch_child_name)+" Log/Output File Attached")
              Log.Enabled=False     
              Sys.Browser("iexplore").Page("https://core*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.*").Close()
              Filesaved = 'True'
              web_utils.close_additional_browsers()
              Filesaved = 'True'
              return                           
          elif i >=28:
             Delay(20000)
  #           req_form.keys("~r")
             req_form.FindChild("AWTComponentAccessibleName","Refresh Data alt R",20).Click()
             Delay(3000)
             i=20
             val=["Name",i]
             child_name=req_form.Find(prop,val,10).wText
  
          else:  
             Delay(3000)
             i=i+1 

             
#def main():
#    import dbhelper
##    dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
##    user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
##    pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
#    dsn = "OCI_STAGE"
#    user_id = "RAC_ACCNT"
#    pwd = "Y4bLC5sb"
#    inv_num = "CSINV_10:53:43"
#    output = dbhelper.verify_costar_invoice_info(dsn,user_id,pwd,inv_num) #self.inv_num)  
#    Log.Message("The output is : " + VarToStr(output))
    
    
    