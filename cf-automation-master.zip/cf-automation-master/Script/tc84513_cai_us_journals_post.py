﻿from ebiz import *
import web_utils
import form_utils
import dbhelper
import file_system_utils


class tc84513_cai_us_journals_post(Ebiz):

 op_log_path ="C:\\TC_Logs"

 def login(self):
   self.login_user='mfallwell'
   super().login()
   
 def action(self,book): 
    if ProjectSuite.Variables.currency =="USD": 
      app = book.Sheets.item["ManualJournal_USD"]
    elif ProjectSuite.Variables.currency=="CAD":
      app = book.Sheets.item["ManualJournal_CAD"]
    else:
      app = book.Sheets.item["Autocopy"]
    self.page.wait()
    Log.Message("Inside action...")   
    self.page.WaitProperty("contentText","CAI ALL GL JOB SCHEDULER",6000)
    cai_gl_job_scheduler=self.page.Find("contentText","CAI ALL GL JOB SCHEDULER",30)
    self.verify_aqobject_chkproperty(cai_gl_job_scheduler,"contentText",cmpIn,"CAI ALL GL JOB SCHEDULER")
    cai_gl_job_scheduler.Click() 
    self.log_message_web("Click 'CAI ALL GL JOB SCHEDULER' - Successful")        
    self.page.Wait()
    cai_gl_submit_link=self.page.NativeWebObject.Find("contentText","Submit Request","A")
    self.verify_aqobject_chkproperty(cai_gl_submit_link,"contentText",cmpIn,"Submit Request")
    cai_gl_submit_link.Click() 
    self.log_message_web("Click 'Submit Request'-Successful") 
    Delay(2000)
    jFrame=self.initializeJFrame() 
    Delay(10000)
    form_utils.click_ok_btn(jFrame)    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit a New Request","ExtendedFrame"]
    submit_new_req_form=jFrame.FindChildEx(prop,val,50,True,90000) 
    Sys.HighlightObject(submit_new_req_form)
    submit_new_req_form.FindChild("AWTComponentAccessibleName","OK alt O",10).Click()
    
# Submitting "Program - Automatic Posting" Request using CAI ALL GL JOB SCHEDULER' responsibility

    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit Request","ExtendedFrame"]
    par_form=jFrame.FindChildEx(prop,val,60,True,90000)
    delay(1000)
    par_form.FindChild("AWTComponentAccessibleName","Name RequiredList of Values",30).SetText("Program - Automatic Posting")
    delay(2000)
    jFrame.Keys("[Tab]")
    delay(2000)
    jFrame.Keys("ATG GL JEs AUTO-POST")
    delay(1000)
    jFrame.Keys("~o")
    delay(2000)
    par_form.FindChild("AWTComponentAccessibleName","Submit alt m",10).Click()
    Delay(1000)
    self.log_message_oracle_form(jFrame,"Program - Automatic Posting is Submitted")   
    RequestID = aqConvert.VarToInt(''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit()))
    Log.Message("Request ID Of  " + aqConvert.VarToStr(RequestID))
    self.log_checkpoint_message_web("Request ID Of Program - Automatic Posting is " + aqConvert.VarToStr(RequestID))
    Delay(2000)
    jFrame.Keys("~n")
    Delay(35000)
    jFrame.Keys("~v")
    Delay(4000)
    jFrame.Keys("r")
    Delay(4000)
    jFrame.Keys("~s")
    Delay(5000)
    prop_names=["JavaClassName","AWTComponentAccessibleName"]
    prop_values=["VTextField","Request ID"]
    temp=jFrame.FindAll(prop_names,prop_values,60)
    jFrame.Find("AWTComponentName",temp[10].AWTComponentName,60).Click()
    jFrame.Find("AWTComponentName",temp[10].AWTComponentName,60).SetText(RequestID)
    Delay(2000)
    
#Click Find 
    jFrame.Keys("~i")
    Delay(2000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,60000)
   
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Phase",40]
    phase=req_form.Find(prop,val,10).wText 
   
    while phase != "Completed":
     Delay(1000)
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Requests","ExtendedFrame"]
     req_form=jFrame.FindChild(prop,val,60)
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Refresh Data alt R","Button"]
     refresh_button=req_form.FindChild(prop,val,60)
     refresh_button.Find("AWTComponentAccessibleName","Refresh Data alt R").Click()
#     req_form.keys("~r")
     Delay(4000)
     phase=req_form.Find(prop,val,10).wText 
    self.log_message_oracle_form(req_form,"Program - Automatic Posting phase is completed")
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Status",50]
    request_form=jFrame.FindChild(prop,val,30)
    self.verify_aqobject_chkproperty(request_form,"wSelection",cmpContains,"Normal")
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChild(prop,val,60)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["View Output alt p","Button"]
    output_button=req_form.FindChild(prop,val,60)
    output_button.Find("AWTComponentAccessibleName","View Output alt p").Click()   
#    jFrame.Keys("~p")
    Delay(4000)
    log_page=Sys.Browser("iexplore").Page("https://core-*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
    log_page.Click()
    log_page.TextNode(0).Click()
    Delay(3000)
    log_page.Keys("~f")
    Delay(3000)
    log_page.Keys("a")
    Delay(3000)  
    file_system_utils.create_folder(self.op_log_path)             
    log_path=self.op_log_path+"\\Posting_Single Ledger Output File Is Attached_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
    Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
    Delay(1000)
    Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
    Delay(3000)
    Log.Enabled=True
    Log.File(log_path, "Automatic Posting Output File Is Attached")
    Log.Enabled=False        
    Delay(1000)
    Sys.Browser("iexplore").Page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close()
    Delay(1000)
    jFrame.Click()
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~o")
    Delay(1000)      
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI ALL GL JOURNAL PROCESSING')]")
    self.log_message_web("Click 'CAI ALL GL JOURNAL PROCESSING' - Successful")
#     web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//li/a[contains(text(),'CAI ALL GL JOURNAL PROCESSING')]")
    Delay(3000)
    self.page.EvaluateXpath("//table[@id='respList']//div[text()='Enter Journals']")[0].Click()
    self.log_message_web("Click 'Enter Journals'- Successful")
#     web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//li/a[contains(text(),'Enter Journals')]")
    web_utils.validate_security_box()
    Delay(20000)
    jFrame=self.initializeJFrame()
    Delay(8000)
#     jFrame.Keys("~o")
    form_utils.click_ok_btn(jFrame)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Journals","ExtendedFrame"]
    j_req_id = app.Cells.Item[2,9]
    fnd_jrnl=jFrame.FindChildEx(prop,val,60,True,90000)
    fnd_jrnl.Find("AWTComponentAccessibleName","BatchList of Values",10).Click()
    fnd_jrnl.Find("AWTComponentAccessibleName","BatchList of Values",10).Keys("%"+VarToStr(j_req_id)+"%")
    delay(1000) 
    jFrame.Keys("~i")
    self.log_message_oracle_form(jFrame,VarToStr(j_req_id)+" find Journal Successful")
    delay(8000) 
    jFrame.Keys("~u")
    delay(4000) 
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Journals (CAI ALL LEDGERS)*","ExtendedFrame"]
    jrnls=jFrame.FindChildEx(prop,val,60,True,60000)
    jrnls.FindChild("AWTComponentName","FormsTabPanel*",60).ClickTab("Other Information")
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Status: Approval",2]
    jrnl_appr_val = jFrame.FindChild(prop,val,60)
    jrnl_appr_status=jrnl_appr_val.wText  
    self.log_message_oracle_form(jFrame,"Journal Approval Status: "+jrnl_appr_status)   
    Log.Enabled=True
    aqObject.CheckProperty(jrnl_appr_val,"wText",cmpIn,"Approved")
    Log.Enabled=False
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Status: Posting",0]
    jrnl_val = jFrame.FindChild(prop,val,60)
    jrnl_status=jrnl_val.wText  
    self.log_message_oracle_form(jFrame,"Journal Status: "+jrnl_status)   
    Log.Enabled=True
    aqObject.CheckProperty(jrnl_val,"wText",cmpIn,"Posted")
    Log.Enabled=False
    self.log_message_oracle_form(jFrame,VarToStr(j_req_id)+" Journal is Approved and Posted")
    delay(4000) 
    jrnls.FindChild("AWTComponentName","FormsTabPanel*",60).ClickTab("Lines")
    delay(4000) 
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Journals (CAI ALL LEDGERS)*","ExtendedFrame"]
    jrnls=jFrame.FindChildEx(prop,val,30,True,60000)
    prop=["JavaClassName","AWTComponentIndex"]
    val=["LWScrollbar","0"]
    down_button=jrnls.FindChildEx(prop,val,30,True,60000)
    for i in range(0,10):
      prop=["JavaClassName","AWTComponentIndex"]
      val=["ContinuousButton","0"]
      down_button.Find(prop,val,20).Click()  
    self.log_message_oracle_form(jFrame,"Intracompany balancing line added by Posting in "+VarToStr(j_req_id))
    delay(4000) 
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~o")
    Delay(1000)    
    

#def sample():
#    jFrame=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1)
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Journals (CAI ALL LEDGERS)*","ExtendedFrame"]
#    jrnls=jFrame.FindChildEx(prop,val,30,True,60000)
#    prop=["JavaClassName","AWTComponentIndex"]
#    val=["LWScrollbar","0"]
#    down_button=jrnls.FindChildEx(prop,val,30,True,60000)
#    for i in range(0,10):
#      prop=["JavaClassName","AWTComponentIndex"]
#      val=["ContinuousButton","0"]
#      down_button.Find(prop,val,20).Click() 
