﻿from dbhelper import *
from ebiz import *
import web_utils
import dbhelper
import file_system_utils

class tc93485cai_us_prc_interface_assets_to_oracle_assets(Ebiz):

 op_log_path ="C:\\TC_Logs"

 def login(self):
  self.login_user='naggarwal'
  super().login()
   
 def action(self,book): 
   
   app = book.Sheets.item["Requisition"]
   rowno = 2
   
   ## Navigation to Request set
#   prop_names = ("innerHTML")
#   prop_values = ("Oracle Applications Home Page")
#   obj =  Sys.Browser("iexplore").Page("*").FindChild(prop_names,prop_values,30)
#   self.verify_aqobject_chkproperty(obj,"contentText",cmpContains,"Oracle Applications Home Page")

   self.wait_until_page_loaded()    
   self.log_checkpoint_message_web("Login Successful")
   

   web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" PA PROJECT CAPITALIZATION')]")
   Delay(2000)
   self.wait_until_page_loaded()
   Delay(2000)
   
   self.wait_until_page_loaded()
   self.page.EvaluateXpath("//table[@id='respList']//div[text()='Other']")[0].Click()
   self.log_message_web("Click 'Other' - Successful")
   self.wait_until_page_loaded()
   Delay(2000)
   
   self.page.wait()
   self.page.EvaluateXpath("//table[@id='respList']//div[text()='Requests']")[0].Click()
   self.log_message_web("Click 'Requests' - Successful")
   Delay(2000)
   
   self.page.wait()
   self.wait_until_page_loaded()
   self.page.EvaluateXpath("//table[@id='respList']//div[text()='Run']")[0].Click()
   self.log_message_web("Click 'Run' - Successful") 
   Delay(10000) 
  
   ## Navigate to Submit a New Request Window
   web_utils.validate_security_box() 
   jFrame= self.initializeJFrame()   
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Submit a New Request","ExtendedFrame"]
   Delay(8000)
   newrequest_form=jFrame.FindChildEx(prop,val,20,True,90000)
   self.verify_aqobject_chkproperty(newrequest_form,"AWTComponentAccessibleName",cmpContains,"Submit a New Request")
   
   # Updated code for click - Full name instead of Keys  - Uday
   prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
   val=["OK alt O","Button",0]
   # Ok Button click
  
   Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("ExtendedFrame", "Submit a New Request", 0).FindChild(prop,val,10).Click()
#    Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications - EBS", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("ExtendedFrame", "Submit a New Request", 0).AWTObject("LWComponent", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("FScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("DrawnPanel", "", 0).AWTObject("FScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("DrawnPanel", "", 0).AWTObject("Button13").Click()
#newrequest_form.keys("~o")
   Delay(2000)
   ##Submit Request 
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Submit Request","ExtendedFrame"]
   submitrequest_form=jFrame.FindChildEx(prop,val,60,True,40000)
   self.verify_aqobject_chkproperty(submitrequest_form,"AWTComponentAccessibleName",cmpContains,"Submit Request")
   
   jFrame.Find("AWTComponentAccessibleName","Name RequiredList of Values",30).SetText("PRC: Interface Assets to Oracle Assets")
   self.log_message_oracle_form( jFrame,"Entered Request Name: PRC: Interface Assets to Oracle Assets")
   jFrame.Keys("[Tab]")
   Delay(8000)
   
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Parameters","FlexWindow"]
   parameters_form=jFrame.FindChildEx(prop,val,60,True,20000)
#   self.verify_aqobject_chkproperty(parameters_form,"AWTComponentAccessibleName",cmpContains,"Parameters")
   
#   app = Sys.OleObject["Excel.Application"]
   Delay(1000)
#   book = app.Workbooks.Open(Project.Path+"\\Datasheets\\Oracle-PA-Integrations\Projects.xls") 
   jFrame.Find("AWTComponentAccessibleName","From Project Number REQUIRED",30).Click()  
   jFrame.Find("AWTComponentAccessibleName","From Project Number REQUIRED",30).Keys(app.Cells.Item[rowno,11])
   Delay(3000)
#   book.close()
   jFrame.Keys("[Tab]")
   Delay(3000)
   self.log_message_oracle_form(jFrame,"Parameters Entered")
   #click Ok Button 
   jFrame.keys("~o")
   Delay(2000)
   #click Submit Button 
#   self.log_message_oracle_form(jFrame,"Click Submit Button next") 
   jFrame.keys("~m")
   Delay(3000)
#   self.log_message_oracle_form(jFrame,"Submitted the Request Successfully") 
  # Request Id generated
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Decision","LWLabel"]
   parameters_form=jFrame.FindChildEx(prop,val,60,True,60000)
#   self.verify_aqobject_chkproperty(parameters_form,"AWTComponentAccessibleName",cmpContains,"Decision")
   Delay(2000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Decision Request Submitted*","ChoiceBox"]
   decision_form=jFrame.FindChild(prop,val,60)
         
   RequestID = ''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit())
   Log.Message("Request ID " + aqConvert.VarToStr(RequestID))
   Delay(2000)
   
   #Click No 
   Rid =aqConvert.VarToStr(RequestID)
   self.log_message_oracle_form(jFrame,"Request Submitted Succesfully -"+ Rid )
   jFrame.Keys("~n")
   Delay(9900)   
    
   dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
   user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
   pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
   dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,RequestID)
      
#   dbhelper.verify_oracle_concurrent_job_status(RequestID) 
   #click View > Requests
   jFrame.Keys("~v")
   Delay(4000)
   jFrame.Keys("r")
   Delay(4000)
   jFrame.Keys("~s")
   
   prop_names=["JavaClassName","AWTComponentAccessibleName"]
   prop_values=["VTextField","Request ID"]
   temp=jFrame.FindAll(prop_names,prop_values,60)
   jFrame.Find("AWTComponentName",temp[10].AWTComponentName,60).Click()
   jFrame.Find("AWTComponentName",temp[10].AWTComponentName,60).SetText(RequestID)
   Delay(2000)
   #Click Find 
   self.log_message_oracle_form(jFrame ,"Query for Submitted Request ID:" +RequestID)
   jFrame.Keys("~i")
   Delay(2000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Requests","ExtendedFrame"]
   req_form=jFrame.FindChildEx(prop,val,30,True,60000)
   
   prop=["AWTComponentAccessibleName","AWTComponentIndex"]
   val=["Phase",40]
   phase=req_form.Find(prop,val,10).wText 
   
   while phase != "Completed":
     Delay(1000)
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val = ["Refresh Data alt R","Button"]
     req_form.FindChild(prop,val,2000).Click() 
     Delay(4000)
     phase=req_form.Find(prop,val,10).wText 

   self.log_message_oracle_form(req_form,"Phase - 'Completed' for RequestID: "+RequestID)
   
   Delay(1000)
#   jFrame.Keys("~k")
   jFrame.Keys("~k")
   file_type = 'Log'
   self.save_log(file_type)
   delay(4000)
   jFrame.Keys("~p")
   file_type = 'Output'
   self.save_log(file_type)
   Delay(6000)
   
   

#Close Windows and Browsers
#  self.close_forms()
   jFrame.Keys("[F4]")
   Delay(4000)
   jFrame.Keys("[F4]")
   Delay(2000)
   jFrame.Keys("~o")
#   Sys.Browser("iexplore").page("https://*epfinnp.coxautoinc.com/forms/frmservlet*").Close()
   Delay(2000)
   self.page.wait_until_page_loaded()
   
   
   self.page.NativeWebObject.Find("contentText","Capitalization","DIV").Click()   
   delay(2000)
   self.page.wait_until_page_loaded()   
   self.page.NativeWebObject.Find("contentText","Capital Projects","DIV").Click()
   delay(2000)   
   web_utils.validate_security_box() 
   jFrame= self.initializeJFrame()  
   delay(2000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Find Capital Projects","ExtendedFrame"]
   findcapitalprojects_form=jFrame.FindChildEx(prop,val,60,True,90000)
   self.verify_aqobject_chkproperty(findcapitalprojects_form,"AWTComponentAccessibleName",cmpContains,"Find Capital Projects")
     
   findcapitalprojects_form.Find("AWTComponentAccessibleName","Project: NumberList of Values",10).SetText(app.Cells.item[rowno,11])
   self.log_message_oracle_form(jFrame,"Project Number Entered in Capital Projects screen is : "+ VarToStr(app.Cells.item[rowno,11]))
   findcapitalprojects_form.Keys("[Tab]")
   findcapitalprojects_form.Keys("[Tab]")
   Delay(3000)
   findcapitalprojects_form.Find("AWTComponentAccessibleName","Find alt i",10).Click()
   Delay(3000)
     
   self.verify_aqobject_chkproperty(findcapitalprojects_form,"AWTComponentAccessibleName",cmpContains,"Capital Projects")
   self.log_message_oracle_form(jFrame,"Capital Projects Details page launched successfully")
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Capital Projects (CAI SHARED SERVICES OU)","ExtendedFrame"]
   capitalprojects_form=jFrame.FindChildEx(prop,val,60,True,90000) 
   
   capitalprojects_form.Find("AWTComponentAccessibleName","Assets alt A",10).Click()  
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=[" Assets*","ExtendedFrame"]
   asset_form=jFrame.FindChildEx(prop,val,60,True,40000)
   Delay(2000) 
   while not asset_form.Exists:
     Delay(2000)
     asset_form=jFrame.FindChild(prop,val,60)
   self.log_message_oracle_form(jFrame,"Assets Form launched successfully") 
         
   Delay(2000) 
   asset_form.Find("AWTComponentAccessibleName","Asset Lines alt i",10).Click() 
   Delay(2000)  
#   self.log_message_oracle_form(jFrame,"Asset Lines Form launched successfully")
#   Delay(1000)
   
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Asset Lines*","ExtendedFrame"]
   asset_lines=jFrame.FindChildEx(prop,val,30,True,40000)
   self.verify_aqobject_chkproperty(asset_lines,"AWTComponentAccessibleName",cmpStartsWith,"Asset Lines")
   self.log_message_oracle_form(jFrame,"Asset Lines Form launched successfully")
   asset_lines.Find("AWTComponentAccessibleName","Details alt D",10).Click() 
   delay(2000)
   
#   val=["Asset Line Details (CAI*","ExtendedFrame"]
#   asset_line_details=jFrame.FindChild(prop,val)
   asset_line_details = Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("ExtendedFrame", "Asset Line Details (CAI SHARED SERVICES OU) - ALL*", 19)
   self.verify_aqobject_chkproperty(asset_line_details,"AWTComponentAccessibleName",cmpContains,"Asset Line Details")
   self.log_message_oracle_form(jFrame,"Asset Line Details Form launched successfully")
   delay(1000)
   self.close_forms(jFrame)
   
   del app,jFrame


 def save_log(self,file_type):
   
   log_page=Sys.Browser("iexplore").Page("https://core-*.epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
   Delay(1000)
   log_page.Click()
   log_page.TextNode(0).Click()
   Delay(1000)
   Log.Enabled=True     
   screenshot=log_page.PagePicture()
   msg = file_type+" File Opened Successfully"
   Log.Picture(screenshot,msg)
   Log.Enabled=False
#   self.log_message_web(file_type+" File Opened Successfully")
   log_page.Keys("~f")
   Delay(2000)
   log_page.Keys("a")
   Delay(3000) 
    
   file_system_utils.create_folder(self.op_log_path)             
   log_path=self.op_log_path+"\\prc interface assets to oracle assets "+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
   Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
   Delay(1000)
   #self.log_message_web("Save File")
   Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
   Delay(5000)
   Log.Enabled=True
   Log.File(log_path,"PRC: Interface Assets to Oracle Assets Request "+file_type+" File Attached")
   Log.Enabled=False     
   Sys.Browser("iexplore").Page("https://core-*.epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close()
   web_utils.close_additional_browsers()
   
   
   
#def test():
#   log_page=Sys.Browser("iexplore").Page("https://core-*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
#   Delay(1000)
#   log_page.Click()
#   log_page.TextNode(0).Click()
#   Delay(1000)
#   Log.Enabled=True     
#   screenshot=log_page.PagePicture()
#   msg = (" File Opened Successfully")
#   Log.Picture(screenshot,msg)
#   Log.Enabled=False