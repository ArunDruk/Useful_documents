﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils
import web_utils


class tc170976_is_us_validate_subledger_accounting(Ebiz):
 global rowno, app
 
 rowno = 2
 op_log_path="C:\\TC_Logs"
 def login(self):
    self.login_user="rmaran"
    super().login()
 
 def goto_url(self,url):
  super().goto_url(self.testConfig['ebiz']['oci_is_url'])
 
 def action(self,book):
   
    app = book.Sheets.item["Invoice"]
    self.wait_until_page_loaded()
    web_utils.log_checkpoint("Logged in to Oracle Applications Home Page Successfully",500,self.page)      
    self.page.EvaluateXPath("//table[@id='menuContent']//div[contains(text(),'AP Home Office Super User')]")[0].Click() 
    web_utils.log_checkpoint("Click 'AP Home Office Super User' - Successful",500,self.page) 
    self.page.Keys("[Down]")
    self.wait_until_page_loaded()
    self.page.NativeWebObject.Find("contentText","Invoices","A").Click()
    web_utils.log_checkpoint("Click 'Invoices' - Successful",500,self.page) 
    self.page.Keys("[Down]")
    self.wait_until_page_loaded()
    self.page.NativeWebObject.Find("contentText","Entry","A").Click()
    web_utils.log_checkpoint("Click 'Entry' - Successful",500,self.page) 
    self.page.Keys("[Down]")
    self.wait_until_page_loaded()
    self.page.EvaluateXpath("//table[@id='respList']//div[contains(text(),'Invoices')]")[1].Click() 
    web_utils.log_checkpoint("Click 'Invoices' - Successful",500,self.page)
    web_utils.validate_security_box()  
    jFrame = self.initializeJFrame()
    Delay(5000)
    form_utils.click_ok_btn(jFrame)
    p_names = ("JavaClassName","AWTComponentAccessibleName")
    p_values = ("ExtendedFrame","Invoice Workbench (AP Home Office Super User)")
    inv_form=jFrame.FindChildEx(p_names,p_values,60,True,120000)
    Delay(2000)
    jFrame.Keys("~v")
    delay(1000)
    jFrame.Keys("f")
    delay(1000)
    
    
    web_utils.log_checkpoint("'Navigate to 'Find Invoices' Form",500,jFrame) 
    p_names = ("JavaClassName","AWTComponentAccessibleName")
    p_values = ("ExtendedFrame","Find Invoices")
    find_inv_form=jFrame.FindChildEx(p_names,p_values,40,True,7000)      
    if find_inv_form.Exists:
      web_utils.log_checkpoint("'Find Invoices' Form Launched Successfully",500,jFrame) 
    else:
      self.log_message_oracle_form(jFrame,"Unable to Launch Find Invoices Form") 
    Delay(1000)    
   
       
    pro = ("AWTComponentIndex","AWTComponentAccessibleName")
    values = (6,"Invoice: Number") 
    Delay(1000)      
    find_inv_form.FindChild(pro,values,20).Click()
    delay(1000)
    find_inv_form.FindChild(pro,values,20).SetText(app.Cells.Item[rowno,13])
    Delay(1000)
    values = (3,"Find alt i")
    Delay(1000)
    find_inv_form.FindChild(pro,values,20).Click()
    Delay(8000)  
    p_names = ("JavaClassName","AWTComponentAccessibleName")
    p_values = ("ExtendedFrame","Invoice Workbench (AP Home Office Super User)")
    inv_wb_form=jFrame.FindChildEx(p_names,p_values,40,True,80000)    
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Accounted",5]
    acc_status=inv_wb_form.FindChild(prop,val,60)
    Log.Enabled=True
    aqObject.CheckProperty(acc_status,"wText",cmpIn,"Yes")
    Log.Enabled=False
    web_utils.log_checkpoint("Invoice is successfully 'Accounted'",500,jFrame)    
    delay(1000)
    web_utils.log_checkpoint("Query DataBase to Retrieve the SLA Details for the Invoice:",500,jFrame) 
    Delay(1000)
    dsn = self.testConfig['man_oracle_db']['dsn']
    user_id = self.testConfig['man_oracle_db']['userid']
    pwd = self.testConfig['man_oracle_db']['pwd']
    inv_num = VarToStr(app.Cells.Item[rowno,13])
    dbhelper.verify_subledger_accting_information(dsn,user_id,pwd,inv_num)
    jFrame.Click()
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~o")
    Delay(1000)
    del app,jFrame,prop,val,dsn,user_id,inv_num

    


