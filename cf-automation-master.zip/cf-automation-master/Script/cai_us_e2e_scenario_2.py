﻿from base import *
from driverchain import *
from ebiz import *
import test_utility
import gvar
import tc_logs



class Driver(Driverchain):
  global classarr,env
  
  def __init__(self):
    global test_env, sheet_obj, book     
    app = Sys.OleObject["Excel.Application"]
    Delay(1000)
    self.book = app.Workbooks.Open(Project.Path+"\\datasheets\\E2E\\E2E_002.xls")          
#    app.Visible = "True"    
    self.test_env=BuiltIn.ParamStr(14)
    self.oper_unit=BuiltIn.ParamStr(15)
#    self.test_env = "oci_stage"
#    self.oper_unit = "US"
#    self.classarr=["ie_clear_cache()","tc85181cai_us_project_creation()","tc93546cai_us_create_non_catalog_req()","ie_clear_cache()","test_approve_requisition()","ie_clear_cache()","tc93548cai_us_CreatePO()","tc98611cai_us_auto_create_po_validation_1()","tc16319cai_us_ReceivePoItems()","ie_clear_cache()","tc98612cai_us_CorrectReceipt()","ie_clear_cache()","tc84510cai_us_create_manual_ap_invoice_match()","tc93849cai_us_create_accounting()","ie_clear_cache()","tc98616cai_us_ap_invoices_initiate_approval()","ie_clear_cache()","tc95047cai_us_validate_subledger_accounting()","tc93848cai_us_next_day_check_payment()","ie_clear_cache()","tc93850cai_us_journal_validation()","ie_clear_cache()","tc97359cai_us_cai_pa_nightly_request_set()","tc97750cai_us_create_project_asset()","tc93484cai_us_prc_generate_asset_lines_for_a_single_project()","ie_clear_cache()","tc93485cai_us_prc_interface_assets_to_oracle_assets()","tc93507cai_us_post_mass_additions()","tc99685cai_us_asset_inquiry()","tc97761cai_us_asset_tieback()"]    
    
    self.classarr=["ie_clear_cache()","tc85181cai_us_project_creation()","tc93546cai_us_create_non_catalog_req()","ie_clear_cache()","test_approve_requisition()","ie_clear_cache()","tc93548cai_us_CreatePO()","tc98611cai_us_auto_create_po_validation_1()","tc16319cai_us_ReceivePoItems()","ie_clear_cache()","tc84510cai_us_create_manual_ap_invoice_match()","tc93849cai_us_create_accounting()","ie_clear_cache()","tc98616cai_us_ap_invoices_initiate_approval()","ie_clear_cache()","tc95047cai_us_validate_subledger_accounting()","tc93848cai_us_next_day_check_payment()","ie_clear_cache()","tc93850cai_us_journal_validation()","ie_clear_cache()","tc97359cai_us_cai_pa_nightly_request_set()","tc97750cai_us_create_project_asset()","tc93484cai_us_prc_generate_asset_lines_for_a_single_project()","ie_clear_cache()","tc93485cai_us_prc_interface_assets_to_oracle_assets()","tc93507cai_us_post_mass_additions()","tc99685cai_us_asset_inquiry()","tc97761cai_us_asset_tieback()"]    
#    self.classarr=["tc93484cai_us_prc_generate_asset_lines_for_a_single_project()"]
    super().__init__(self.classarr)
        
  def close_excel(self):    
    self.book.save()
    delay(1000)
    self.book.close()

#def main():
#  gvar.dataprep['browser']='ie'
#  obj=Driver()
#  cobj=obj.run()
#  obj.close_excel()

### Added utilities in the main method for Rally TestComplete API Integration (Pushing to GIT in TOGGLE:OFF mode)###
    	
def main():
  try:
    gvar.dataprep['env']=BuiltIn.ParamStr(14)
    obj=Driver()
#    test_utility.start_test(__name__.center(70,'*'),'Core Financials - CF','CAI E2E','123053','Automation Stability Test Set') 
    if obj.test_env.lower()=="oci_stage":
      test_utility.start_test(__name__.center(70,'*'),'Core Financials - CF','CAI E2E','123053','CAI E2E - OCI Stage')
    elif obj.test_env.lower()=="oci_test":
      test_utility.start_test(__name__.center(70,'*'),'Core Financials - CF','CAI E2E','123053','CAI E2E - OCI Test')  
     
    cobj = obj.run()
    print('evoke test_utility')
  except:
    gvar.dataprep['verdict'] = 'Fail'
    tc_logs.header_name('Test Failed - traceback shown below')       
    tc_logs.error_with_no_picture(traceback.format_exc(),'')       
    print('evoke test_utility')
  finally:
    test_utility.end_test()
    obj.close_excel()

