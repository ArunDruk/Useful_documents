﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils
import winscp_utility
import tc_logs
from File_Handler import File_Handler as _TXTOBJ
from text_headers import payroll_txt_file_header as _HEADERS


class tc213273_is_gl_man_blkn_inbound_interface(Ebiz):
   
  op_log_path="C:\\TC_Logs"
  is_blkn_inbound_files="C:\\IS_Blkn_Inbound_Files"
  
  def login(self):
      self.login_user="mfallwell"
      super().login()
  
  def goto_url(self,url):
       super().goto_url(self.testConfig['ebiz']['oci_is_url'])

  def action(self,book):
    global rowno, bl_str
    app = book.Sheets.item["Blkn_inbound"] 
    rowno = 2
    self.files = "MANGL_BLKLN_JE_EXTRACT.tsv"
    self.place_files_local()
    bl_str=self.process_files()
    self.place_files_winscp(app)
    
    
  def place_files_local(self):   
      Log.Message("Entering into function 'place_files_local'")
  #    for index in range(0,1):
      file_system_utils.create_folder(self.is_blkn_inbound_files)
      file_exist=aqFileSystem.FindFiles("C:\\IS_Blkn_Inbound_Files",self.files)
      if file_exist != None:
       aqFileSystem.DeleteFile("C:\\IS_Blkn_Inbound_Files\\"+self.files)
      aqFileSystem.CopyFile(Project.Path+"DataSheets\\Oracle-GL-Journal\\IS\\"+self.files, "C:\\IS_Blkn_Inbound_Files\\"+self.files)
      log_path = ("C:\\IS_Blkn_Inbound_Files\\"+self.files)
      Log.Enabled=True
      Log.File(log_path, "Blackline Inbound File Attached")
      Log.Enabled=False 
      
## Read/Modify/Write Payroll Files:
#  def process_files(self):  
#    def counter(index,**kwargs):
#      import datetime as dt 
#      import random
#      kwargs['REFERENCE21'] = int(dt.datetime.now().strftime("%Y%m%d%H%M%S%f"))+int(index)
#      return kwargs 
#    for number in range(0,4):
#      path = "C:\IS_Pyrl_Trsy_Files\\"+self.file
#      cobj = _TXTOBJ(path,"|")
#      cobj.Write_txt_without_header([counter(index+1,**row) for index, row in enumerate(
#              cobj.Read_txt_with_header(_HEADERS()))]) 
  
  def process_files(self):  
    import re
    from datetime import datetime
    read_Lines=[]
    write_Lines=[]
    path = "C:\IS_Blkn_Inbound_Files\\"+self.files
    with open(path,'r') as fr:
        read_Lines=fr.readlines()
        # write_Lines=fw.writelines(read_Lines)
        for line in read_Lines:
            cur_date = datetime.now().strftime("%m/%d/%Y")
            min_sec=datetime.now().strftime("%S%M")
            bl_str="BL_"+str(min_sec)
            new_string=re.sub(r'(0|1)[1-9]/[0-9]{2}/[0-9]{4}',cur_date,line)
            modified_string=re.sub(r'^BL_\d{4}',bl_str,new_string)
            write_Lines.append(modified_string)
    
    with open(path,'w') as fw:
        fw.writelines(write_Lines)
    return bl_str

## Place Payroll Files in WinScp:
  def place_files_winscp(self,app):  #self,file1,file2,file3,file4
#    for index in range(0,4):
    Stored_session = "blackline3@mftstg.manheim.com" 
    local_dir = "C:\IS_Blkn_Inbound_Files"
    remote_dir =  self.testConfig['winscp']['gl_blkn_dir'] 
#    remote_dir = "//Outbox//IS//SMNH2I"
    upload_file_name = self.files
    winscp_utility.upload_file(Stored_session,local_dir,remote_dir,upload_file_name)
    Log.Enabled=True       
    Log.Message("Blackline Inbound File "+self.files+" placed in the "+ remote_dir)
#    Log.Message("The value of bl_str= "+VarToStr(bl_str))           
    Log.Enabled=False

## Login to Oracle EBIZ and select the responsibility
  
#    is_gl_submit_link=self.page.NativeWebObject.Find("contentText","GL SCHEDULER","A")
#    self.verify_aqobject_chkproperty(is_gl_submit_link,"contentText",cmpIn,"GL SCHEDULER")
#    is_gl_submit_link.Click() 
##    self.log_message_web("Click 'GL SCHEDULER' - Successful") 
#    web_utils.log_checkpoint("Click 'GL SCHEDULER' - Successful",500,self.page)
#    Delay(1000)  
    self.page.EvaluateXpath("//table[@id='respList']//div[contains(text(),'GL SCHEDULER')]")[0].scrollIntoView()
    self.page.EvaluateXpath("//table[@id='respList']//div[contains(text(),'GL SCHEDULER')]")[0].Click()
    web_utils.log_checkpoint("Click 'GL SCHEDULER' - Successful",500,self.page)
    delay(1000)
         
    self.page.Wait()
    self.page.NativeWebObject.Find("contentText","Requests","A").Click()
#    self.log_message_web("Click 'Requests' - Successful") 
    web_utils.log_checkpoint("Click 'Requests' - Successful",500,self.page)
  
    self.page.Wait()
    self.page.NativeWebObject.Find("contentText","Run","A").Click()
#    self.log_message_web("Click 'Run' - Successful") 
    web_utils.log_checkpoint("Click 'Run' - Successful",500,self.page)
    
    web_utils.validate_security_box()
    jFrame= self.initializeJFrame()
    Delay(10000)

    form_utils.click_ok_btn(jFrame)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit a New Request","ExtendedFrame"]
    submit_new_req_form=jFrame.FindChildEx(prop,val,60,True,90000)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["What type of request do you want to run? Request Set alt s","ExtendedCheckbox"]  
    submit_new_req_form.FindChild(prop,val,10).Click()       
    Delay(1000)
    submit_new_req_form.FindChild("AWTComponentAccessibleName","OK alt O",10).Click()

    #  Submitting "MAN Oracle GL Inbound JE Interface Request Set - PeopleSoft Harmony" Request Set using 'GL SCHEDULER' responsibility
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit Request Set","ExtendedFrame"]
    par_form=jFrame.FindChild(prop,val,60)
    Delay(3000)
    par_form.Find("AWTComponentAccessibleName","Request Set RequiredList of Values",30).Keys("MAN Oracle GL Inbound JE Interface Request Set - BL")
    delay(1000)
    
    jFrame.Keys("[Tab]")
    delay(1000)
    self.log_message_oracle_form(jFrame,"Entered Request set 'MAN Oracle GL Inbound JE Interface Request Set - BL'")
    par_form=jFrame.FindChild(prop,val,60)
    par_form.Find("AWTComponentAccessibleName","Submit",30).Click()
     
    form_utils.click_ok_btn(jFrame)    
#    self.log_message_oracle_form(jFrame,"MAN Oracle GL Inbound JE Interface Request Set - BL")   
    delay(3000)
    
    RequestID = aqConvert.VarToInt(''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit()))
    Log.Message("Request ID" + aqConvert.VarToStr(RequestID))
    self.log_checkpoint_message_web("Request ID Of 'MAN Oracle GL Inbound JE Interface Request Set - BL' " + aqConvert.VarToStr(RequestID))
    Delay(2000)
    jFrame.Keys("~n")
    delay(100000)
    
    dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
    user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
    pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
    dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,VarToStr(RequestID))
    
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000) 
       
    # Gathering Request ID and Output File for the "MAN Oracle GL Inbound JE Interface Request Set - PeopleSoft Harmony"   
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,90000) 
    
    self.req_set_save_output(jFrame,req_form,"MAN Oracle Generic GL Preprocessor Program",RequestID)
    delay(10000)
    
    self.req_set_save_output(jFrame,req_form,"MAN Oracle GL Inbound JE Interface Program",RequestID) 
    
    # Gathering Request ID and Output File for the "GL Child Program"
#    self.req_set_save_output(jFrame,req_form,"####",RequestID)

    # Gathering Request ID and Output File for the "Journal Import Program"  
    creqid1,log_path = self.req_set_save_output(jFrame,req_form,"Journal Import",RequestID)
    delay(10000)
    
    fo=open(log_path,"r") 
    lines=fo.readlines()
    self.log_message_web("Journal Imported Batch Name is : - "+lines[17][8:39].strip())
    app.Cells.Item[rowno,1] = lines[17][8:39].strip()  
    
#    journal_req_ids = []
#    journal_req_ids.append(creqid1) 
#    
#    creqid2 = self.req_set_save_output(jFrame,req_form,"Journal Import",RequestID,journal_req_ids)
#    journal_req_ids.append(creqid2)
#    
#    creqid3 = self.req_set_save_output(jFrame,req_form,"Journal Import",RequestID,journal_req_ids)
#    journal_req_ids.append(creqid3)
#  
#    creqid4 = self.req_set_save_output(jFrame,req_form,"Journal Import",RequestID,journal_req_ids)
#    journal_req_ids.append(creqid4)
   
    
    # Gathering Request ID and Output File for the "Posting: Single Ledger" 
    self.req_set_save_output(jFrame,req_form,"Posting: Single Ledger",RequestID)  
    delay(10000)
    
    self.req_set_save_output(jFrame,req_form,"MAN Oracle Journal Status Extract Program",RequestID)
    delay(10000)
    
    self.req_set_save_log(jFrame,req_form,"MAN: Blackline Transfer Transaction file to Sterling (MAN:Transfer files to Sterling)",RequestID)
    delay(10000)
    
    
   
    Delay(1000)
    jFrame.Close()
    Delay(1000)
    jFrame.Close()
    Delay(1000)
    jFrame.Keys("~o")
    Delay(1000) 
    
    # Navigate to journal from frontEnd
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'GL Corporate Accounting User')]")
#    self.log_message_web("Click 'GL Corporate Accounting User' - Successful")
    web_utils.log_checkpoint("Click 'GL Corporate Accounting User' - Successful",500,self.page)
    Delay(3000)
    self.page.EvaluateXpath("//table[@id='respList']//div[text()='Journals']")[0].Click()
#    self.log_message_web("Click 'Journals'- Successful")
    web_utils.log_checkpoint("Click 'Journals'- Successful",500,self.page)
    Delay(2000)
    self.page.EvaluateXpath("//table[@id='respList']//div[text()='Enter']")[0].Click()
#    self.log_message_web("Click 'Enter'- Successful")
    web_utils.log_checkpoint("Click 'Enter'- Successful",500,self.page)
    
    web_utils.validate_security_box()
    Delay(20000)
    jFrame=self.initializeJFrame()
    Delay(8000)
    form_utils.click_ok_btn(jFrame)
    
#    for x in journal_req_ids:
#      
#      dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
#      user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
#      pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
#      batch_name = dbhelper.return_journal_import_details(dsn,user_id,pwd,"%"+VarTostr(x))
#      if batch_name.contains("WK" or "BW"):
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Journals","ExtendedFrame"]
    fnd_jrnl=jFrame.FindChildEx(prop,val,60,True,90000)
    fnd_jrnl.Find("AWTComponentAccessibleName","BatchList of Values",10).Click()
    fnd_jrnl.Find("AWTComponentAccessibleName","BatchList of Values",10).Keys(app.Cells.Item[rowno,1]) #("%"+VarToStr(x)+"%")
    delay(1000) 
    jFrame.Keys("~i")
    delay(2000)
    web_utils.log_checkpoint("Find Journal - Successful",500,jFrame)
#    self.log_message_oracle_form(jFrame,VarToStr(x)+" find Journal Successful")
    delay(8000) 
    jFrame.Keys("~u")
    delay(2000)
    web_utils.log_checkpoint("Displaying the Lines Information in Review Journal",500,jFrame)
    delay(4000) 
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Journals (MAN GLB ALL)*","ExtendedFrame"]
    jrnls=jFrame.FindChildEx(prop,val,60,True,60000)
    jrnls.FindChild("AWTComponentName","FormsTabPanel*",60).ClickTab("Other Information")
    delay(2000)
    web_utils.log_checkpoint("Displaying the Other Information in Review Journal",500,jFrame)
    delay(4000)
    
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Reference",4]
#    jrnls.FindChild(prop,val,20).Click()
#    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#    val=["Other Information tab page Reference",4]
    reference_bl_str = jrnls.FindChild(prop,val,20).wText
#    Log.Enabled=True
#    Log.Message("The value of reference_bl_str= "+VarToStr(reference_bl_str))
#    Log.Message("The value of bl_str= "+VarToStr(bl_str))
#    Log.Enabled=False
    if(VarToStr(reference_bl_str) == VarToStr(bl_str)):
      web_utils.log_checkpoint("Validated the BL String value in the Reference header",500,jFrame) 
    else:
      web_utils.log_error("Validation failed in the Reference header for the BL String")

    
#    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#    val=["Status: Approval",2]
#    jrnl_appr_val = jFrame.FindChild(prop,val,60)
#    jrnl_appr_status=jrnl_appr_val.wText  
#    self.log_message_oracle_form(jFrame,"Journal Approval Status: "+jrnl_appr_status)   
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Status: Posting",0]
    jrnl_val = jFrame.FindChild(prop,val,60)
    jrnl_status=jrnl_val.wText  
    self.log_message_oracle_form(jFrame,"Journal Status: "+jrnl_status)   
    Log.Enabled=True
    aqObject.CheckProperty(jrnl_val,"wText",cmpIn,"Posted")
    Log.Enabled=False
    web_utils.log_checkpoint("Journal is posted",500,jFrame)
#    self.log_message_oracle_form(jFrame,VarToStr(x)+" Journal is Posted")
    delay(4000) 
#    jrnls.FindChild("AWTComponentName","FormsTabPanel*",60).ClickTab("Lines")
#    delay(4000) 
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Journals (CAI ALL LEDGERS)*","ExtendedFrame"]
#    jrnls=jFrame.FindChildEx(prop,val,30,True,60000)
#    prop=["JavaClassName","AWTComponentIndex"]
#    val=["LWScrollbar","0"]
#    down_button=jrnls.FindChildEx(prop,val,30,True,60000)
#    for i in range(0,10):
#      prop=["JavaClassName","AWTComponentIndex"]
#      val=["ContinuousButton","0"]
#      down_button.Find(prop,val,20).Click()  
#    self.log_message_oracle_form(jFrame,"Intracompany balancing line added by Posting in "+VarToStr(x))        
#    delay(4000) 
#    jFrame.Keys("[F4]")
#    Delay(2000)
#    jFrame.Keys("[F4]")
#    Delay(3000)
#    jFrame.Keys("[F4]")
#    Delay(1000)
#    jFrame.Keys("~o")
#    Delay(1000)
        
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~o")
    Delay(1000)
    
  def req_set_save_output(self,jFrame,req_form,srch_child_name,Preqid): #,journal_req_ids=[]
       
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val = ["Refresh Data alt R","Button"]
     req_form.FindChild(prop,val,2000).Click()
       
     for x in range(20,51):
         
       if x>29:
         jFrame.Keys("[Down]")        
         x=29
                      
       prop=["AWTComponentAccessibleName","AWTComponentIndex"]
       val=["Phase",x+20]
       phase=req_form.Find(prop,val,10).wText 
         
       prop=["AWTComponentAccessibleName","AWTComponentIndex"]
       val=["Request ID",x-10]
       creqid=VarToInt(req_form.Find(prop,val,10).wText)
         
       prop=["AWTComponentAccessibleName","AWTComponentIndex"]
       val=["Name",x]
       child_name=req_form.Find(prop,val,10).wText
       req_form.Find(prop,val,10).Click()
         
       prop=["AWTComponentAccessibleName","AWTComponentIndex"]
       val=["Status",x+30]         
       status =req_form.FindChild(prop,val,60) 
         
       if (child_name==srch_child_name) and (creqid>=Preqid) and (phase == "Completed"):  #(creqid not in journal_req_ids)and
           
         self.log_message_oracle_form(req_form,aqConvert.VarToStr(srch_child_name)+" Phase Completed Successfuly")            
         self.verify_aqobject_chkproperty(status,"wText",cmpIn,"Normal,Warning")
         self.log_message_oracle_form(req_form,"Request ID of "+aqConvert.VarToStr(srch_child_name)+" is "+aqConvert.VarToStr(creqid))
         req_form.Find(prop,val,10).Keys("[Enter]")
         Delay(1000)
         prop=["AWTComponentAccessibleName","JavaClassName"]
         val=["View Output alt p","Button"]
         output_button=req_form.FindChild(prop,val,60)
         output_button.Find("AWTComponentAccessibleName","View Output alt p").Click()     
         Delay(3000)
         output_page=Sys.Browser("iexplore").Page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
         output_page.Click()
         Delay(2000)
         output_page.Keys("~f")
         Delay(2000)
         output_page.Keys("a")
         Delay(5000)
         file_system_utils.create_folder(self.op_log_path)             
         log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+" Is Attached_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
         Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
         Delay(1000)
         Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
         Delay(6000)
         Log.Enabled=True
         Log.File(log_path, aqConvert.VarToStr(srch_child_name)+" Output File Attached")
         Log.Enabled=False    
         Sys.Browser("iexplore").page("https://core-*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close() 
         web_utils.close_additional_browsers() 
         Delay(2000)   
         jFrame.Click()
         Delay(2000)
         return creqid,log_path
           
  def req_set_save_log(self,jFrame,req_form,srch_child_name,Preqid):  #type=""
    
      prop=["AWTComponentAccessibleName","JavaClassName"]
      val = ["Refresh Data alt R","Button"]
      req_form.FindChild(prop,val,2000).Click() 
         
      for x in range(20,51):
          
        if x>29:
          jFrame.Keys("[Down]")        
          x=29
                        
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Phase",x+20]
        phase=req_form.Find(prop,val,10).wText
           
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Request ID",x-10]
        creqid=VarToInt(req_form.Find(prop,val,10).wText)
          
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Name",x]
        child_name=req_form.Find(prop,val,10).wText
        req_form.Find(prop,val,10).Click()
            
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Status",x+30]         
        status =req_form.FindChild(prop,val,60)
          
        if (child_name==srch_child_name) and (creqid>=Preqid) and (phase == "Completed"): 
            
          self.log_message_oracle_form(req_form,aqConvert.VarToStr(srch_child_name)+" Phase Completed Successfuly")            
          self.verify_aqobject_chkproperty(status,"wText",cmpIn,"Normal,Warning")
          self.log_message_oracle_form(req_form,"Request ID of "+aqConvert.VarToStr(srch_child_name)+" is "+aqConvert.VarToStr(creqid))
          req_form.Find(prop,val,10).Keys("[Enter]")
          Delay(1000)
            
          prop=["AWTComponentAccessibleName","JavaClassName"]
          val=["View Log alt K","Button"]
          log_button=req_form.FindChild(prop,val,60)
          log_button.Click()     
          Delay(3000)
          output_page=Sys.Browser("iexplore").Page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
          output_page.Click()
          Log.Enabled=True
          wnd = Sys.Desktop.ActiveWindow()
          Log.Picture(wnd, f"WinScp File Location path: {type}", wnd.FullName)                 
          Log.Enabled=False
          Delay(2000)
          output_page.Keys("~f")
          Delay(2000)
          output_page.Keys("a")
          Delay(5000)
          file_system_utils.create_folder(self.op_log_path)             
          log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"Is Attached_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
          Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
          Delay(1000)
          Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
          Delay(6000)
          Log.Enabled=True
          Log.File(log_path, aqConvert.VarToStr(srch_child_name)+" Log File Attached")
          Log.Enabled=False    
          Sys.Browser("iexplore").page("https://core-*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close()  
          web_utils.close_additional_browsers()
          Delay(2000)   
          jFrame.Click()
          Delay(2000)
          return creqid


            
