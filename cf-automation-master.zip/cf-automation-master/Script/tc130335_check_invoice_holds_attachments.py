﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils
import web_utils


class tc130335_check_invoice_holds_attachments(Ebiz):
 global rowno
 rowno = 2

 def login(self):
    self.login_user="mkumar"
    super().login()
 
 op_log_path="C:\\TC_Logs"
 
 def action(self,book): 
    app = book.Sheets.item["Invoice"]
    web_utils.log_checkpoint("Logged in to Oracle Applications Home Page Successfully",500,self.page)
    self.wait_until_page_loaded()  
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" AP INVOICE PROCESSING')]") 
    Delay(1000)  
    self.wait_until_page_loaded()           
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Invoices')]")
    Delay(1000)
    self.wait_until_page_loaded() 
    Delay(1000) 
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Entry')]")
    Delay(1000) 
    self.wait_until_page_loaded()
    self.page.EvaluateXPath("//div[text()='Invoices']")[1].Click()
    delay(10000)   
    web_utils.validate_security_box()
    delay(10000)       
    jFrame=self.initializeJFrame()
    Delay(8000)
    form_utils.click_ok_btn(jFrame)
#    Delay(8000)
#    jFrame=self.initializeJFrame()
#    Delay(8000)
#    form_utils.click_ok_btn(jFrame)
    Delay(6000)
    p_names = ("JavaClassName","AWTComponentAccessibleName")
    p_values = ("ExtendedFrame","Invoice Workbench (CAI "+self.oper_unit+" AP INVOICE PROCESSING)")
    inv_form=jFrame.FindChildEx(p_names,p_values,60,True,120000)
    Delay(2000)
    jFrame.Keys("~v")
    delay(1000)
    jFrame.Keys("f")
    delay(1000)
    
 #Finding Invoice in the invoice workbench
 
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Invoices","ExtendedFrame"]
    par_form=jFrame.FindChildEx(prop,val,60,True,60000)
    par_form.Find("AWTComponentAccessibleName","Invoice: Number",30).Click()
    Delay(5000)
    par_form.Find("AWTComponentAccessibleName","Invoice: Number",30).SetText(app.Cells.Item[rowno,13])
    jFrame.Keys("[Tab]")
    delay(3000)
    val = ["Find alt i","Button"] 
    par_form.FindChild(prop,val,60).Click()
    Delay(4000)    
    
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Type Required",8]
    inv_type=jFrame.FindChildEx(prop,val,60,True,9000000)
    Log.Enabled=True
    aqObject.CheckProperty(inv_type,"wText",cmpIn,"Standard")
    Log.Enabled=False
    self.log_message_oracle_form(jFrame,"Find Invoice Successful: "+aqConvert.VarToStr(app.Cells.Item[rowno,13]))
    Delay(4000) 
      
    prop=["AWTComponentAccessibleName","AWTComponentIndex","JavaClassName"]
    val=["Holds",8,"VTextField"]
    hold=jFrame.FindChildEx(prop,val,60,True,9000000)
    Log.Enabled=True
    aqObject.CheckProperty(hold,"wText",cmpIn,"1")
    Log.Enabled=False
 
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Invoice Workbench*","ExtendedFrame"]
    inv_wkbnch=jFrame.FindChildEx(prop,val,60,True,60000)
    inv_wkbnch.FindChild("AWTComponentName","FormsTabPanel*",60).ClickTab("3 Holds")
    Delay(9000)   
    web_utils.log_checkpoint("Invoice: "+aqConvert.VarToStr(app.Cells.Item[rowno,13])+" is on 'IPM_INVALID_SUPPLIER_HOLD'",500,jFrame)
    inv_wkbnch.FindChild("AWTComponentName","FormsTabPanel*",60).ClickTab("1 General")
    Delay(4000)
    jFrame.Keys("~v")
    Delay(2000)
    jFrame.Keys("a")
    Delay(2000)
    self.log_message_oracle_form(jFrame,"In Workbench Attachments Section : Invoice Image attached successfully")
    Delay(4000)
    jFrame.Keys("~d")
    Delay(15000)
    
 # Logging into Oracle:Webcenter Imaging to view the invoice image
 
     #********** IDCS Login added by Lakshmi Seelam************
    self.wait_until_page_loaded()
    Delay(5000)
    
    self.page.Find("idStr","idcs-signin-basic-signin-form-username",30).Click()
    self.page.Find("idStr","idcs-signin-basic-signin-form-username",30).Click()
    Sys.Keys(Sys.Keys(self.testConfig['wccodingV12']['userid']))
    Sys.Keys("[Tab]")
    Delay(2000)
    self.page.Find("idStr","idcs-signin-basic-signin-form-password|input",30).Click()
    Delay(2000)
    Sys.Keys((self.testConfig['wccodingV12']['password']))
    Sys.Keys("[Tab]"+"[Enter]")
    Delay(3000)
    #self.page.Find("contentText","Sign In",30).Click()
    
    self.wait_until_page_loaded()
    Delay(2000)
    #********** IDCS Login added by Lakshmi Seelam************
#imaging_web_page = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/imaging/faces/Authentication/Login.jspx").Panel("doc").Panel("ps_l1").Panel("c").Panel("pslForm").Panel("c").Panel("pglForm") 
   
#    web_utils.log_checkpoint("Log in to 'Oracle:Webcenter Imaging next to view the image",500,imaging_web_page)
#    self.wait_until_page_loaded()
#    Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/imaging/faces/Authentication/Login.jspx").Panel("doc").Panel("ps_l1").Panel("c").Panel("pslForm").Panel("c").Panel("pglForm").Panel(0).Panel("formBox").Panel(0).Panel("content").Panel("pflForm").Table(0).Cell(0, 0).Table(0).Cell(1, 0).Table("usernameLabel").Cell(1, 0).Textbox("username").Click()
#    Delay(4000)
#    Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/imaging/faces/Authentication/Login.jspx").Panel("doc").Panel("ps_l1").Panel("c").Panel("pslForm").Panel("c").Panel("pglForm").Panel(0).Panel("formBox").Panel(0).Panel("content").Panel("pflForm").Table(0).Cell(0, 0).Table(0).Cell(1, 0).Table("usernameLabel").Cell(1, 0).Textbox("username").SetText('mkumar')
#    web_utils.log_checkpoint("On 'Oracle:Webcenter Imaging page: 'UserID' entered successfully",500,imaging_web_page)
#    Delay(2000)
#    Sys.Browser("iexplore").Page("https://*.coxautoinc.com/imaging/faces/Authentication/Login.jspx").Panel("doc").Panel("ps_l1").Panel("c").Panel("pslForm").Panel("c").Panel("pglForm").Panel(0).Panel("formBox").Panel(0).Panel("content").Panel("pflForm").Table(0).Cell(0, 0).Table(0).Cell(2, 0).Table("passwordLabel").Cell(1, 0).PasswordBox("password").Click()
#    Delay(2000)
#    Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/imaging/faces/Authentication/Login.jspx").Panel("doc").Panel("ps_l1").Panel("c").Panel("pslForm").Panel("c").Panel("pglForm").Panel(0).Panel("formBox").Panel(0).Panel("content").Panel("pflForm").Table(0).Cell(0, 0).Table(0).Cell(2, 0).Table("passwordLabel").Cell(1, 0).PasswordBox("password").SetText('oracle123')
#    web_utils.log_checkpoint("On 'Oracle:Webcenter Imaging page: 'Password' entered successfully",500,imaging_web_page)
#    Delay(2000)
#    Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/imaging/faces/Authentication/Login.jspx").Panel("doc").Panel("ps_l1").Panel("c").Panel("pslForm").Panel("c").Panel("pglForm").Panel(0).Panel("formBox").Panel(0).Panel("content").Panel("pflForm").Table(0).Cell(0, 0).Table(0).Cell(4, 0).Table("submitButton").Cell(1, 0).SubmitButton("btnSubmit").Click()
#    Delay(4000)
#    self.wait_until_page_loaded()
    imaging_page = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/imaging/faces/Pages/Viewer*").Panel("ptd1").Form("mnFrm").Panel(0).Panel("s").Panel("cpyRgt").Panel("f").Panel("imgNvPn").Table(0).Cell(0, 1).Panel("mnpsl").Panel("c").Panel("CntRgn").Panel(0).Panel("c").Panel("panelSplitterTopAndBottom").Panel("f").Panel("panelSplitterTopLeftAndRight").Panel("s").Panel("boxWrap").Panel("c")
    web_utils.log_checkpoint("Oracle:Webcenter Imaging IDCS 'Sign in' successful",500,imaging_page)
    Delay(35000) 
    count = 0
    while not Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/imaging/faces/Pages/Viewer*").Panel("ptd1").Form("mnFrm").Panel(0).Panel("s").Panel("cpyRgt").Panel("f").Panel("imgNvPn").Table(0).Cell(0, 1).Panel("mnpsl").Panel("c").Panel("CntRgn").Panel(0).Panel("c").Panel("panelSplitterTopAndBottom").Panel("f").Panel("panelSplitterTopLeftAndRight").Panel("s").Panel("boxWrap").Panel("c").Panel(0).Panel("panelStretchLayoutApplet").Panel(0).Panel(0).Panel("c").Object("oraImgVwr").AWTObject("PluginEmbeddedFrame", "").SwingObject("Viewer", "", 0).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("ImageView", "", 0).SwingObject("JViewport", "", 0).Exists:
      delay(5000) 
      if count == 5:
        self.log_error_message("Unable to retrieve the Invoice Image")  
      count=count+1
    image_view = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/imaging/faces/Pages/Viewer*").Panel("ptd1").Form("mnFrm").Panel(0).Panel("s").Panel("cpyRgt").Panel("f").Panel("imgNvPn").Table(0).Cell(0, 1).Panel("mnpsl").Panel("c").Panel("CntRgn").Panel(0).Panel("c").Panel("panelSplitterTopAndBottom").Panel("f").Panel("panelSplitterTopLeftAndRight").Panel("s").Panel("boxWrap").Panel("c").Panel(0).Panel("panelStretchLayoutApplet").Panel(0).Panel(0).Panel("c").Object("oraImgVwr").AWTObject("PluginEmbeddedFrame", "").SwingObject("Viewer", "", 0).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("ImageView", "", 0).SwingObject("JViewport", "", 0)
    Sys.HighlightObject(image_view)
    web_utils.log_checkpoint("Invoice Image exists for the invoice :"+aqConvert.VarToStr(app.Cells.Item[rowno,13]),500,image_view)
    delay(2000)
    Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/imaging/faces/Pages/Viewer*").Close()
    delay(10000)
    jFrame.Click()
    delay(4000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("o")
    self.close_forms(jFrame)
    
