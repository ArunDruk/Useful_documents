﻿from ebiz import *
import form_utils
import web_utils

#Author:            Prabhakaran Rajendran
#TestCaseID:        TC98633
#UserStoryID:       US126964
#Reviewed_By:       
#######################################################################################


class tc98633cai_us_validate_taxes_ap_invoice(Ebiz):
  
  global login_user
  
  def login(self):
    self.login_user="amalappan"
    super().login()
    
  def action(self,book):
      global rowno, app, p_names, jFrame
      rowno=2   
      app = book.Sheets.item["Invoice"]
      RowCount = app.UsedRange.Rows.Count
      p_names = ("JavaClassName","AWTComponentAccessibleName")      
      while (rowno<RowCount+1):          
        if rowno == 2:
          self.nav_ap1(p_names)
        else:
          self.multi_inv()
        self.ap_inv_hdr(p_names)
        self.ap_inv_lns(p_names)
        self.ap_inv_tax_lns()
        self.ap_inv_val(p_names) 
        self.val_tax() 
        rowno = rowno + 1       
      delay(1000)
      book.save()
      del app,RowCount,p_names
     
  
  def nav_ap1(self,p_names): 

      self.log_message_web("Logged in to Oracle Applications Home Page")  
      
#      self.page.NativeWebObject.Find("contentText","CAI "+self.oper_unit+" AP INVOICE PROCESSING","A").Click()
      web_utils.clk_fldr_link_by_xpath(self.page,"//a[text()='CAI "+self.oper_unit+" AP INVOICE PROCESSING']")
      delay(2000)
      self.page.wait()
      self.page.NativeWebObject.Find("contentText","Invoices","A").Click()
      delay(2000)
      self.page.wait()
      self.page.NativeWebObject.Find("contentText","Entry","A").Click()
      delay(2000)  
      self.page.wait()
      self.page.EvaluateXPath("//a[text()='Invoices']")[1].Click()
#      self.page.Find("namePropStr","RF.jsp?function_id=1026&resp_id=50816&resp_appl_id=200&security_group_id=0&lang_code=US')",30).Click()
      delay(5000)
      self.jFrame = self.initializeJFrame()

      p_names = ("JavaClassName","AWTComponentAccessibleName")
      p_values = ("ExtendedFrame","Invoice Workbench (CAI "+self.oper_unit+" AP INVOICE PROCESSING)")

      obj=self.jFrame.FindChildEx(p_names,p_values,50,True,60000)
      if obj.Exists:
        self.log_checkpoint_message_web("AP Invoice Page Launched Successfully")
      else:
        self.log_message_oracle_form(self.jFrame,"Unable to Launch AP Invoice Form")
        
  def multi_inv(self):
    
        self.jFrame.Keys("[F4]")
        delay(3000)
        self.jFrame.Find("AWTComponentAccessibleName","Open alt O",30).Click()
        Delay(3000)
        self.jFrame.Find("AWTComponentAccessibleName","Open alt O",30).Click()
        Delay(1000)  
        self.jFrame.Keys("[Down]")
        Delay(1000)
        self.jFrame.Keys("[Enter]")
        delay(10000)
        p_names = ("JavaClassName","AWTComponentAccessibleName")
        p_values = ("ExtendedFrame","Invoice Workbench (CAI "+self.oper_unit+" AP INVOICE PROCESSING)")
        obj=self.jFrame.FindChildEx(p_names,p_values,50,True,60000)
        if obj.Exists:
          self.log_checkpoint_message_web("AP Invoice Page Launched Successfully")
        else:
          self.log_message_oracle_form(self.jFrame,"Unable to Launch AP Invoice Form")    
           
  def ap_inv_hdr(self,p_names):   
    
      delay(1500)
      self.jFrame.Keys("~l")
      Delay(1000)
      self.jFrame.Keys("o")
      delay(3000)
      prop=["AWTComponentAccessibleName","JavaClassName"]
      val=["Open Folder","FWindow"]
      open_fldr_form=self.jFrame.FindChildEx(prop,val,60,True,60000)
      delay(1000)
      prop=["JavaClassName","AWTComponentIndex"]
      val=["LWTextField",0]
      open_fldr_form.FindChildEx(prop,val,30,True,60000).click()
      open_fldr_form.FindChildEx(prop,val,30,True,60000).Keys("[Left]")
      Delay(1000)
      open_fldr_form.FindChildEx(prop,val,30,True,60000).Keys("*A")    
      delay(1000)
      open_fldr_form.Find("AWTComponentAccessibleName","OK ALT O",60).Click()
      prop=["AWTComponentAccessibleName","JavaClassName"]
      val=["Invoice Workbench*","ExtendedFrame"]
      inv_wb_form=self.jFrame.FindChild(prop,val,60)
      p_values = ("VTextField","Trading Partner/Supplier Name RequiredList of Values")
      obj=inv_wb_form.Find(p_names,p_values,50)
      if obj.Exists:
        self.log_checkpoint_message_web("AP Invoice Header template selected successfully")
      else:
        self.log_message_oracle_form(self.jFrame,"Unable to Launch Required Header Template for Creating Invoice")
      
      p_values = ("VTextField","PO NumberList of Values")
      inv_wb_form.Find(p_names,p_values,30).Click()
      inv_wb_form.Find(p_names,p_values,30).Keys(app.Cells.Item[rowno,14])
      delay(2000)
      p_values = ("VTextField","RequesterList of Values")
      self.jFrame.Find(p_names,p_values,30).Click()
      inv_wb_form.Find(p_names,p_values,30).Keys(app.Cells.Item[rowno,2])
      delay(5000)      
      p_values = ("VTextField","Invoice Date RequiredList of Values")
      inv_wb_form.Find(p_names,p_values,30).Click()
      delay(2000)
      inv_wb_form.Keys("[TAB]")
      delay(2000)
      inv_wb_form.Find("AWTComponentAccessibleName", "Invoice Num Required",30).Keys("TST_INV: "+aqConvert.DateTimeToFormatStr(aqDateTime.Time(),"%H:%M:%S"))
      delay(1000)
      inv_wb_form.Keys("[TAB]")
      delay(1000)      
      p_values = ("VTextField","Invoice Amount Required")
      inv_wb_form.Find(p_names,p_values,30).Click()
      delay(1000)
      inv_wb_form.Find(p_names,p_values,30).Keys(app.Cells.Item[rowno,15])
      delay(1000)
      inv_wb_form.Keys("[TAB]")
      self.log_message_oracle_form(self.jFrame,"Invoice Header Details Entered Successfully")
      
  def ap_inv_lns(self,p_names):
      delay(1000)
      self.jFrame.Keys("~m")      
      delay(2000)
      self.jFrame.Keys("~i") 
      delay(2000)
      p_values = ("ExtendedFrame","Match to Purchase Orders*")
      obj=self.jFrame.FindChildEx(p_names,p_values,50,True,10000)      
      if obj.Exists:
        self.log_checkpoint_message_web("PO Match Form Launched Successfully")
      else:
        self.log_message_oracle_form(self.jFrame,"Unable to Launch PO Match Form to match Invoice")       
      delay(1000)

      lines = aqConvert.StrToInt((app.Cells.Item[rowno,16]).Text)
      temp = 0
      index = 0 
      var = VarToStr(app.Cells.item[rowno,19])
      var1 = var.split(',')
      for x in range(0,lines):
        self.jFrame.Keys(" ")
        delay(2000)
        p1_names = ("AWTComponentIndex","AWTComponentAccessibleName")
        p_values = (index,"Qty Invoiced Required")
        obj.FindChild(p1_names,p_values,30).Keys(var1[index])
        delay(1000)
        self.jFrame.Keys("[TAB]")
        delay(1000)
        self.log_message_oracle_form(self.jFrame,"Selected PO Line no: "+aqConvert.IntToStr(index+1))
        p_values = (20+index,"Match Amount Required")
        obj.FindChild(p1_names,p_values,30).Click()
        amount = obj.Find(p1_names,p_values,30).wText
        temp = temp + aqConvert.StrToInt(amount)
        delay(1000)
        self.jFrame.Keys("[Down]")
        index = index+1
      delay(2000)
      self.jFrame.Keys("~m")      
      delay(5000)
      p_values = ("VTextField","Total")    
#      self.log_checkpoint_message_web("matched value:"+IntToStr(temp))
      obj = self.jFrame.FindChild(p_names,p_values,50)
#      self.log_checkpoint_message_web("invvalue:"+obj.wText)
      if aqConvert.StrToInt(obj.wText) == temp:
        self.log_checkpoint_message_web("PO Matched to AP Invoice Successfully")
      else:
        self.log_message_oracle_form(self.jFrame,"Unable to Match PO to the Invoice")
        
        
  def ap_inv_tax_lns(self):
      tval = (VarToInt(app.Cells.Item[rowno,15])*(0.07))      
      delay(1000)
      self.jFrame.FindChild("AWTComponentName","FormsTabPanel1",30).ClickTab("2 Lines")
      delay(3000)
      pro = ("AWTComponentAccessibleName","JavaClassName","AWTComponentIndex")
      val = ("Num Required","VTextField",1)
      self.jFrame.Find(pro,val,60).Click()
      Delay(1000)
      pro = ("AWTComponentAccessibleName","JavaClassName")
      val = ("Type Required","VTextField")
      self.jFrame.Find(pro,val,60).Click()
      Delay(1000)
      self.jFrame.Find(pro,val,60).Keys("Tax")
      Delay(1000)
      self.jFrame.Keys("[Tab]")
      val = ("Amount Required","VTextField")
      self.jFrame.Find(pro,val,60).Click()
      Delay(1000)
      self.jFrame.Find(pro,val,60).Keys(tval)
      Delay(1000)
        
  def ap_inv_val(self,p_names):

        self.jFrame.FindChild("AWTComponentName","FormsTabPanel*",30).ClickTab("1 General")
        delay(1000)
        self.jFrame.Keys("~c")
        delay(1500)
        self.jFrame.Keys("~v")
        delay(1000)
        self.jFrame.Keys("~k")
        delay(10000)
        self.jFrame.Keys("^s")
        delay(2000)
        pro=("AWTComponentAccessibleName","AWTComponentIndex")
        values=("Invoice Num Required",32)
        inv = self.jFrame.FindChild(pro,values,30).wText
        self.log_message_oracle_form(self.jFrame,"AP Invoice created SuccessFully :"+inv)
        delay(1000)        
        app.Cells.Item[rowno,13] = inv      
        p_names = ("JavaClassName","AWTComponentAccessibleName")
        p_values = ("VTextField","Status")
        obj=self.jFrame.FindChild(p_names,p_values,50)
        if obj.wText == "Validated":
          self.log_checkpoint_message_web("Invoice Validated Successfully")
        else:
          self.log_message_oracle_form(self.jFrame,"Check for Invoice Holds & Re-Validate")
          
 
  def val_tax(self):
      delay(1000)
      self.jFrame.FindChild("AWTComponentName","FormsTabPanel1",30).ClickTab("2 Lines")
      pro = ("AWTComponentAccessibleName","JavaClassName","AWTComponentIndex")
      val = ("Open Folder..*","VButton",0)
      self.jFrame.Find(pro,val,60).click()
      
      prop=["AWTComponentAccessibleName","JavaClassName"]
      val=["Open Folder","FWindow"]
      open_fldr_form=self.jFrame.FindChildEx(prop,val,60,True,60000)
      delay(1000)
      prop=["JavaClassName","AWTComponentIndex"]
      val=["LWTextField",0]
      open_fldr_form.FindChildEx(prop,val,30,True,60000).click()
      open_fldr_form.FindChildEx(prop,val,30,True,60000).Keys("[Left]")
      Delay(1000)
      open_fldr_form.FindChildEx(prop,val,30,True,60000).Keys("DEFAULT FOLDER")    
      delay(1000)
      open_fldr_form.Find("AWTComponentAccessibleName","OK ALT O",60).Click()
      delay(1000)
      self.log_message_oracle_form(self.jFrame,"Item and Tax - Line Level Details")      
      desc = 'FALSE'     
      x = 0
      while desc!='VERTEX_US_REGIME - VERTEX TAX':
        pro = ("AWTComponentAccessibleName","JavaClassName","AWTComponentIndex")
        val = ("Account  Segment","VTextField",80+x)
        self.jFrame.Find(pro,val,60).click()
        desc = self.jFrame.Find(pro,val,60).wText
        if x==3:
          self.log_error_message("VERTEX - TAX is not calculated: Check Vertex Engine")
          break
        x=x+1 
      val = ("Ship To LocationList of Values","VTextField",255)
      self.jFrame.Find(pro,val,60).click()      
      ship_to = self.jFrame.Find(pro,val,60).wText
      self.log_message_oracle_form(self.jFrame,"Ship-to Value :"+ship_to)
      delay(1000)
      val = ("Purchasing Category","VTextField",420)
      self.jFrame.Find(pro,val,60).click()     
      purc_cat = self.jFrame.Find(pro,val,60).wText
      self.log_message_oracle_form(self.jFrame,"Purchasing Category Value :"+purc_cat)      
      delay(1000)
      self.jFrame.FindChild("AWTComponentName","FormsTabPanel1",30).ClickTab("1 General")
      val = ("Tax","VTextField",15)
      self.jFrame.Find(pro,val,60).Click()
      tax_line = self.jFrame.Find(pro,val,60).wText
      if StrToInt(tax_line) != 0.00:
        self.log_checkpoint_message_web("Vertex Tax Line is generated for amount: $"+tax_line)
      else:
        self.log_message_oracle_form(self.jFrame,"Tax value not posted by Supplier")        
      pro = ("AWTComponentAccessibleName","JavaClassName","AWTComponentIndex")
      val = ("Self-Assessed Tax Amount","VTextField","152")
      self.jFrame.Find(pro,val,60).Click()
      tax = self.jFrame.Find(pro,val,60).wText
      if tax != '':
        self.log_checkpoint_message_web("Self-Assessed Tax is generated for amount: $"+tax)
      else:
        self.log_error_message("Unable to calculate self-assessed tax")      

      self.jFrame.Keys("[F4]")
      Delay(2000)
      self.jFrame.Keys("[F4]")
      Delay(2000)
      self.jFrame.Keys("~o")
      Delay(2000)
      Sys.Browser("iexplore").page("https://*ebs.coxautoinc.com/forms/frmservlet*").Close() 
      
      
