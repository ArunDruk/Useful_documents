﻿from gvar import dataprep as DATAPREP 

def random_mega_dealer_qry():
   query = """Select * FROM (Select HEAD.*, CHILD.REP_NAME, CHILD.REP FROM
( SELECT  A.BILL_TO_NAME BILL_TO_NAME ,A.BILL_TO  BILL_TO,A.SOLD_TO_NAME  SOLD_TO_NAME, A.SOLD_TO SOLD_TO 
FROM (SELECT  parentAcc.account_name   BILL_TO_NAME,    parentAcc.account_number BILL_TO, 
childAcc.account_name SOLD_TO_NAME, childAcc.account_number  SOLD_TO 
FROM  hz_parties parent, hz_parties child, hz_relationships rs, hz_cust_accounts parentAcc, hz_cust_accounts childAcc 
where parent.party_id = rs.subject_id and child.party_id = rs.object_id 
and parent.party_id = parentAcc.party_id and child.party_id = childAcc.party_id and rs.end_date > sysdate - 1 
AND childAcc.status = 'A' AND parentAcc.status = 'A'  AND rs.relationship_type in ('MAN PAYER') 
AND rs.relationship_code = 'MAN PAYER PARENT' ORDER BY DBMS_RANDOM.VALUE ) A WHERE rownum = 1 ) HEAD
,( SELECT hca.account_name DEALER_NAME,hca.account_number DEALER, hp.party_name REP_NAME ,hp.attribute20 REP
FROM   hz_cust_account_roles HCAR, hz_parties HP,hz_relationships HR,hz_org_contacts HOC,hz_parties HP1,hz_cust_accounts HCA
WHERE  HCAR.party_id = HR.party_id AND    HCAR.role_type = 'CONTACT' 
AND HCAR.status = 'A' AND HP.status = 'A' AND HR.status = 'A' AND HP1.status = 'A' AND HCA.status = 'A' 
AND HOC.party_relationship_id = HR.relationship_id AND HR.subject_id = HP.party_id     
AND HR.party_id = HP1.party_id AND HR.subject_table_name = 'HZ_PARTIES'AND HR.object_table_name = 'HZ_PARTIES' 	
AND HCAR.cust_account_id = HCA.cust_account_id AND HCA.party_id = HR.object_id ) CHILD 
WHERE HEAD.SOLD_TO = CHILD.DEALER AND CHILD.REP is not null   ORDER BY DBMS_RANDOM.VALUE ) main 		
WHERE rownum = 1"""

def random_5M_seller_qry():
  return """SELECT * from ( SELECT account_name DEALER_NAME,account_number DEALER  FROM apps.hz_cust_accounts 
 WHERE status = 'A' AND account_number BETWEEN '500000' AND '5999999' AND LENGTH(account_number) = '7' ORDER BY dbms_random.VALUE) A 
 WHERE rownum = 1"""
 
def random_5M_buyer_qry():
  return f""" WITH X AS (
SELECT
       hca.cust_account_id,
       hca.account_number DEALER,
       hca.account_name DEALER_NAME
FROM
       hz_cust_accounts_all hca,
       hz_cust_acct_sites_all hcasa,
       hz_cust_site_uses_all hcsua,
       hz_parties hp,
       iby_ext_bank_accounts account,
       iby_external_payers_all ext_payer,
       iby_pmt_instr_uses_all acc_instr
WHERE
       hca.status = 'A'
       AND hcasa.status = 'A'
       AND hcsua.status = 'A'
       AND hcsua.site_use_code = 'BILL_TO'
       AND hcsua.primary_flag = 'Y'
       AND hcasa.org_id = 101
       AND hca.cust_account_id = hcasa.cust_account_id
       AND hcasa.cust_acct_site_id = hcsua.cust_acct_site_id
       AND hp.party_id = hca.party_id
       AND hcsua.attribute7 = 'N'
       AND hcsua.attribute5 IS NULL
       AND hcsua.attribute6 IS NULL
       AND account.ext_bank_account_id = acc_instr.instrument_id
       AND hcsua.attribute16 = 'One payment per customer'
       AND hcsua.attribute8 = 'Electronic'
       AND hcsua.attribute9 = 'CUSTOMER REFUND'
       AND acc_instr.ext_pmt_party_id = ext_payer.ext_payer_id
       AND ext_payer.cust_account_id = hca.cust_account_id
       AND acc_instr.attribute_category = 'AP Payment Preferences'
       AND acc_instr.attribute1 = 'Y' ) SELECT
       DISTINCT x.*,
       --hca.account_number "Customer Number",
    per.attribute20 REP,
       per.party_name REP_NAME
FROM
       hz_parties p,
       hz_parties per,
       HZ_PERSON_PROFILES HPP,
       hz_relationships HZR,
       hz_org_contacts hoc,
       hz_cust_account_roles CAR,
       hz_cust_accounts_all hca,
       X
WHERE
       1 = 1
       AND CAR.party_id = HZR.party_id(+)
       AND CAR.cust_account_id = hca.cust_account_id(+)
       AND hoc.party_relationship_id(+) = HZR.relationship_id
       AND hzr.subject_id = p.party_id(+)
       AND hca.party_id = p.party_id
       AND p.party_id = HZR.subject_id
       AND HZr.object_id = per.party_id
       AND per.party_id = hpp.party_id (+)
       AND x.cust_account_id = hca.cust_account_id
       AND TRUNC ( SYSDATE ) BETWEEN TRUNC ( HPP.EFFECTIVE_START_DATE ) AND TRUNC ( NVL ( HPP.EFFECTIVE_END_DATE,
       SYSDATE + 1 ))
       AND rownum = 1   """   
 
def ach_pref_5M_buyer_qry():
  return f""" SELECT * FROM ( SELECT 
     hca.account_number DEALER ,
     hp.party_name     DEALER_NAME,
     per.attribute20  REP,
     per.party_name   REP_NAME
         
FROM
    hz_cust_accounts_all hca,
       hz_parties   p,
    hz_parties             per,
    HZ_PERSON_PROFILES     HPP,
    hz_relationships       HZR,
    hz_org_contacts        hoc,
    hz_cust_account_roles  CAR,
    hz_parties hp,
    hz_cust_accounts_all hca2,
    iby_external_payers_all ext_payer,
    iby_pmt_instr_uses_all acc_instr,
    apps.ra_cust_receipt_methods rcrm,
    ar_receipt_methods arm,
    iby_ext_bank_accounts ieba
WHERE
    hca.status = 'A'
    AND ieba.ext_bank_account_id = acc_instr.instrument_id
    AND ieba.attribute8 = 'APPROVED'
    AND ieba.end_date IS NULL
    AND hca.account_number LIKE '5%'
    AND rcrm.primary_flag = 'Y'
    AND hp.party_id = hca.party_id
    AND acc_instr.instrument_type = 'BANKACCOUNT'
    AND acc_instr.payment_function = 'CUSTOMER_PAYMENT'
    AND acc_instr.payment_flow = 'FUNDS_CAPTURE'
    AND acc_instr.ext_pmt_party_id = ext_payer.ext_payer_id
    AND ext_payer.cust_account_id = hca.cust_account_id
    AND hca.customer_class_code = 'DEALER'
    AND hca.cust_account_id = rcrm.customer_id
    AND rcrm.receipt_method_id = arm.receipt_method_id
    AND arm.name = 'ACH Bank Transfer'
    AND CAR.party_id = HZR.party_id(+)
    AND CAR.cust_account_id = hca.cust_account_id(+)
    AND hoc.party_relationship_id(+) = HZR.relationship_id
    AND hzr.subject_id = p.party_id(+)
    AND hca2.party_id  = p.party_id
   and p.party_id = HZR.subject_id
   and HZr.object_id= per.party_id
   and per.party_id= hpp.party_id (+)
   AND  hca.cust_account_id = hca2.cust_account_id
   AND TRUNC(SYSDATE) BETWEEN TRUNC(HPP.EFFECTIVE_START_DATE) AND NVL(HPP.EFFECTIVE_END_DATE, SYSDATE + 1)
   ORDER BY  dbms_random.value ) A
   WHERE   rownum = 1"""
