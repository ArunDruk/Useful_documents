﻿

def create_folder(fldr_path):
  if not aqFileSystem.Exists(fldr_path):
     aqFileSystem.CreateFolder(fldr_path)
     
def delete_file(fldr_path,file_name):
  file_exists = aqFileSystem.FindFiles(fldr_path,file_name)
  if file_exists != None:
           aqFileSystem.DeleteFile(fldr_path+"\\"+file_name)
           
def copy_file(src_path,destination_path,file_name):
  file_exists = aqFileSystem.FindFiles(src_path,file_name)
  if file_exists != None:
    aqFileSystem.CopyFile(src_path+"\\"+file_name, destination_path+"\\"+file_name)

