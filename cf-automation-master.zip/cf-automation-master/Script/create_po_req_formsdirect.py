﻿from ebiz import *
import web_utils
import form_utils
import file_system_utils
import ebiz

class create_po_req_formsdirect(Ebiz):
  global rowno
  
  rowno = 2
  def login(self):
    self.login_user="rmaran"
    super().login()
  
  def goto_url(self,url):
   super().goto_url(self.testConfig['ebiz']['oci_is_url'])
  
  def action(self,book):
    app = book.Sheets.item["Requisition"]
    app1 = book.Sheets.item["Invoice"]
    self.wait_until_page_loaded()  
    web_utils.log_checkpoint("Login to Oracle Applications Successful",500,self.page)   
    
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='menuContent']//div[contains(text(),'PO Supervisor')]")  
    self.wait_until_page_loaded()  
    self.page.Keys("[Down]")
    
    self.page.Find("contentText","Buyer Work Center",30).Click()  
    web_utils.log_checkpoint("Click 'Buyer Work Center' - Successful",500,self.page)       
    self.wait_until_page_loaded()  
    self.page.Keys("[Down]")
    
    web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Requisitions')]")
    self.wait_until_page_loaded() 
    
    self.page.EvaluateXPath("//table[@id='TableLayout']//button[@title='Search']")[0].Click() 
    web_utils.log_checkpoint("On Requisitons Demand Workbench Page : Click 'Search' button - Successful",500,self.page)
    self.wait_until_page_loaded()
    
    self.page.EvaluateXPath("//span[@id='Value_0__xc_1']//input[@id='Value_0']")[0].Click() 
    Delay(4000)
    self.page.EvaluateXPath("//span[@id='Value_0__xc_1']//input[@id='Value_0']")[0].Keys("^a[BS]")
    Delay(4000)
    temp=web_utils.slct_drpdwn_by_xpath(self.page,"//select[@name='addMorePickList']",'Unassigned')
    temp=web_utils.clk_btn_by_xpath(self.page,"//button[contains(text(),'Add')]")
    web_utils.log_checkpoint("Added 'Unassigned Requisitions' field to search category - Successful",500,self.page)
    self.wait_until_page_loaded()
    temp=web_utils.slct_drpdwn_by_xpath(self.page,"//select[@title='Search Value: Unassigned']",'Yes')
    search_req_no =VarToInt(app.cells.Item[2,15])
    temp=web_utils.set_text(self.page,"//input[@title='Search Value: Requisition']",VarToStr(BuiltIn.ParamStr(16)))
#    temp=web_utils.set_text(self.page,"//input[@title='Search Value: Requisition']","2460825")

    obj=web_utils.get_btn_obj_by_xpath(self.page,"//button[contains(text(),'Go')]")     
    self.verify_aqobject_chkproperty(obj[0],"contentText",cmpIn,"Go")
    Delay(5000)
    obj[0].Click()  
    web_utils.log_checkpoint("Click 'Go': Query Requisition Number Successful",500,self.page)  
    self.wait_until_page_loaded()
    
    temp=web_utils.slct_checkbox_by_xpath(self.page,"//input[@title='Select']")   
    obj=web_utils.get_btn_obj_by_xpath(self.page,"//button[@id='AddToDocumentBuilder']")  
    self.verify_aqobject_chkproperty(obj[0],"contentText",cmpIn,"Add")
    obj[0].Click()    
    self.wait_until_page_loaded()
    
    web_utils.log_checkpoint("Click 'Add' - Successful: Requisition added to Document Builder to create new purchase order",500,self.page)
    total_amt=(Sys.Browser("iexplore").page("*").EvaluateXPath("//span[@id='BuilderTotalAmount']")[0].contentText)[:-3]
    web_utils.log_checkpoint("Total Document Amount: "+aqConvert.VarToStr(total_amt),500,self.page)
    app1.Cells.item[rowno,15] = total_amt
    obj=web_utils.get_btn_obj_by_xpath(self.page,"//button[@id='Create']")       
    if obj[0].isDisabled == False:
      obj[0].Click()  
    else:
      self.log_error_message("Create Button in Document Builder Section is not enabled")     
    web_utils.log_checkpoint("On Demanad Workbench: Click 'Create Document' successful",500,self.page)
    self.wait_until_page_loaded()   
    delay(2000)
    pro = ("ObjectType","contentText") 
    val = ("TextNode","Update Standard Purchase Order *")
    apprPage = self.page.Find(pro,val,30)
    self.verify_aqobject_chkproperty(apprPage,"contentText",cmpStartsWith,"Update Standard Purchase Order")
    web_utils.log_checkpoint("Navigate to 'Update Standard PO Page'  - successful",500,self.page)
    web_utils.clk_link_by_xpath(self.page,"//table[@id = 'PageActionButtonsRN']//button[@id='SubmitButton']")
    self.wait_until_page_loaded()      
    
    po_ord=self.page.NativeWebObject.Find("contentText", "Standard Purchase Order*", "div").ContentText  
    app1.Cells.Item[rowno,14]=''.join(x for x in po_ord if x.isdigit())
    web_utils.log_checkpoint("Purchase Order Confirmation Message: "+aqConvert.VarToStr(po_ord),500,self.page)
    self.wait_until_page_loaded()   
    self.page.EvaluateXpath("//table[@id = 'globalHeaderID']//a/div/img[@title = 'Home']")[0].Click()
    self.wait_until_page_loaded()
    del app,app1,obj,po_ord,temp
    

