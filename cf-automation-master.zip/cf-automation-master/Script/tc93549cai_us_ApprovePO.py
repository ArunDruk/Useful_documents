﻿from ebiz import *
import web_utils
import form_utils
import file_system_utils
import ebiz


class tc93549cai_us_ApprovePO(Ebiz):
  global rowno, val
  rowno = 2
  
  
  def login(self):
    self.login_user="rmaran"
    super().login()
  
  def action(self,book):
    app = book.Sheets.item["Invoice"]    
    val1 = VarToStr(app.cells.Item[rowno,14])
    self.wait_until_page_loaded()    
    self.log_checkpoint_message_web("Login Successful")  
    
    temp=web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" PO PROCESS PURCHASE ORDERS')]")       
    self.verify_aqobject_chkproperty(temp[0],"contentText",cmpIn,"CAI "+self.oper_unit+" PO PROCESS PURCHASE ORDERS")
    self.log_message_web("Click 'CAI "+self.oper_unit+" PO PROCESS PURCHASE ORDERS' - Successful")      
    self.wait_until_page_loaded()      
    
    web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Purchase Orders')]")       
    self.log_message_web("Click 'Purchase Orders' - Successful")       
    Delay(5000)
        
    jFrame = self.initializeJFrame()
    Delay(3000)
    form_utils.click_ok_btn(jFrame)
    Delay(3000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Purchase Orders*","ExtendedFrame"]
    po_form=jFrame.FindChildEx(prop,val,60,True,120000)
    self.verify_aqobject_chkproperty(po_form,"AWTComponentAccessibleName",cmpContains,"Purchase Orders - [New]")
    
#    po_form.Keys("[F11]")
#    Delay(2000)
#    po_form.Find("AWTComponentAccessibleName","Purchase Order Number",60).Click()
#    Delay(1000)
#    po_form.Find("AWTComponentAccessibleName","Purchase Order Number",60).SetText(val1)
#    self.log_message_oracle_form(po_form,"PO Number: "+val1)
#    jFrame.Keys("^[F11]")
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["View mnemonic V","LWMenu"]
    jFrame.FindChild(prop,val,60).Click()
    jFrame.Keys("f")
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Purchase Orders","FWindow"]
    findpo = jFrame.FindChildEx(prop,val,60,True,120000)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Enter a partial value to limit the list*","LWTextField"]
    findpo.FindChild(prop,val,60).Click()
    findpo.FindChild(prop,val,60).Keys(val1)
    self.log_message_oracle_form(po_form,"PO Number: "+val1)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find ALT F","PushButton"]
    findpo.FindChild(prop,val,60).Click()
    Delay(2000)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["OK ALT O","PushButton"]
    findpo.FindChild(prop,val,60).Click()
    Delay(5000)
    
    
    # wait until results are retrieved.
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Terms alt m","Button"]
    po_form.FindChildEx(prop,val,60,True,120000).Click()
#    po_form.Keys("~m")
    Delay(2000)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Terms and Conditions*","ExtendedFrame"]
    terms_form = jFrame.FindChildEx(prop,val,60,True,120000)
    Delay(2000)
    
    terms_form.Find("AWTComponentAccessibleName","Terms tab page PaymentList of Values",50).Click()
    terms_form.Find("AWTComponentAccessibleName","Terms tab page PaymentList of Values",50).Keys("[BS]")
    Delay(1000)
    terms_form.Find("AWTComponentAccessibleName","Terms tab page PaymentList of Values",50).SetText("Immediate")
    Delay(1000)
    jFrame.Keys("~w")
    Delay(1000)  
    jFrame.Keys("2")   
    Delay(2000)
    prop_name=["AWTComponentAccessibleName","AWTComponentIndex"]
    prop_value=["Supplier*",5]
    while aqString.Compare(po_form.Find(prop_name,prop_value,10).wText,VarToStr(app.Cells.Item[rowno,3]), False) != 0 :
      Delay(2000)
    Delay(1000)  
#    po_form.Keys("~a")
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Approve... alt A","Button"]
    po_form.FindChild(prop,val,60).Click()
    
    self.log_message_oracle_form(po_form,"Successfully clicked on Approve button")       
    Delay(4000)    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Approve Document*","ExtendedFrame"] 
    approve_doc_form=jFrame.FindChildEx(prop,val,60,True,120000) 
    Delay(2000)
    self.verify_aqobject_chkproperty(approve_doc_form,"AWTComponentAccessibleName",cmpContains,"Approve Document - "+val1)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["OK alt K","Button"]
    approve_doc_form.FindChild(prop,val,60).Click()  
#    approve_doc_form.Keys("~k")    
    Delay(4000) 
    self.log_message_oracle_form(po_form,"Successfilly clicked on Approve Document 'OK' button")   
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(2000)
    jFrame.Keys("~o")
    Delay(4000)
#    Sys.Browser("iexplore").page("https://*epfinnp.coxautoinc.com/forms/frmservlet*").Close()
    book.save()
    del app,po_form,approve_doc_form,val1,jFrame
     


