﻿from webCenterVerifier import *
from web_utils import *

class OCI_WCI_Verifier_Smoke_Test(webCenterVerifier):
  
 def login(self):
    self.login_user="CAIPRODAUTOMATION"
    super().login()
        
 def goto_url(self,url):
   super().goto_url(self.testConfig['ebiz']['WebCentVerUrl'])
      
 def action(self,book): 
  app = book.Sheets.item["Smoke_Test"]
  obj_options = self.page.FindChild("contentText","Options",40)
  if obj_options.Exists:
    web_utils.log_checkpoint("Logged in to WebCenter Verifier Applications Successfully",500,self.page)
  else:
    self.log_error_message("Unable to Login to WebCenter Verifier Applications")
    
  obj_options.Click()
  self.wait_until_page_loaded()
  self.log_message_web("Selecting Filtering Options to view the Batch Details")
  
  filter = self.page.FindChild("idStr","item_custom_filter-itemEl",40)
  if filter.Exists: 
   self.page.FindChild("idStr","item_custom_filter-itemEl",40).Click()   
  else:
    self.log_error_message("Unable to Find 'Filtering' menu in the Form")
  Delay(1000)
  self.wait_until_processing()
  filter_box = self.page.FindChild("idStr","bfdFilter",40)
  if filter_box.Exists:
    self.log_message_web("Successfully Navigated to Options > Filtering > Batch Filtering Conditions")
  else:
    self.log_error_message("Unable to Open 'Batch Filtering Conditions' box")
    
  web_utils.log_checkpoint("Set Filter Condition: [State - '550']",500,self.page)
  self.page.FindChild("idStr","bfdFilter",40).Keys("^a[Del]")
  delay(1000)
  self.page.FindChild("idStr","bfdFilter",40).SetText("[State] ='550'")
  
  web_utils.log_checkpoint("Successfully Selected Filter Condition 'State' = 550",500,self.page)
  Delay(2000)
  self.page.FindChild("contentText","Apply",40).Click()
  Delay(1000)
  self.wait_until_processing()
  # Refresh page until expected batch found
  if Sys.Browser("iexplore").Page("*").EvaluateXPath("//table[@class='x-grid-table x-grid-table-resizer']//span")==None:    
    web_utils.log_checkpoint("No Batches Available in Status '550' for the user; Validation Successful",500,self.page)
    app.Cells.item[2,2] = "SUCCESS"
#    app.Cells.item[2,1] = VarToStr(batch_id)
  elif Sys.Browser("iexplore").Page("*").EvaluateXPath("//table[@class='x-grid-table x-grid-table-resizer']//span")!=None:
    web_utils.log_checkpoint("Able to Validate Batch List Successfully in WCI Verifier Form: Test Passed",500,self.page)
    app.Cells.item[2,2] = "SUCCESS"
#    app.Cells.item[2,1] = VarToStr(batch_id)
  else:
    self.log_error_message("Batch ID "+batch_id+" Validation Failed")
    app.Cells.item[2,2] = "FAILED"

    
 
