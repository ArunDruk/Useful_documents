﻿import responsibility
import web_utility
import gvar
import tc_logs 
from datetime import datetime

def click_consignment_manager(page):
  responsibility.click_consignment_manager(page)
  page.Refresh()
  Delay(10000)

def update_title_receipt_date():
    current_timestamp = datetime.now().strftime("%d-%m-%Y %H:%M:%S")
    web_utility.find_link_by_idStr('receivedDate').keys('^a[BS]')
    web_utility.find_link_by_idStr('receivedDate').keys(aqString.Concat(current_timestamp,'[Tab]'))
    tc_logs.checkpt_with_no_picture(f"Title received Date field updated with Today Date ")
    web_utility.find_link_by_idStr('applyButton').Click()
    Delay(30000)
    tc_logs.checkpt_with_no_picture(f"Title received Date '{current_timestamp}' Applied sucessfully")

def update_title_validate_date():
    current_timestamp = datetime.now().strftime("%d-%m-%Y %H:%M:%S")
    web_utility.find_link_by_idStr('validatedDate').keys('^a[BS]')
    web_utility.find_link_by_idStr('validatedDate').keys(aqString.Concat(current_timestamp,'[Tab]'))
    tc_logs.checkpt_with_no_picture(f"Title validated date field updated with Today Date ")
    web_utility.find_link_by_idStr('applyButton').Click()
    Delay(30000)
    tc_logs.checkpt_with_no_picture(f"Title Validate Date '{current_timestamp}' Applied sucessfully")

def search_by_vin(page,vin_basic_plus):
    web_utility.find_link_by_idStr('vin').keys(vin_basic_plus) 
    web_utility.find_link_by_idStr('Go').Click()
    Delay(10000)
    web_utility.find_img(["ObjectIdentifier","tabIndex"],["detailsicon_enabled_gif","0"]).Click()
    Delay(10000)

def update_psi_status_pass(page):
    web_utility.set_text_value_by_idstr_after_clear(page,'psiStatus',aqString.Concat('PASSED','[Tab]'))
    web_utility.click_button_by_idstr(page,'applyButton')
    tc_logs.checkpt_with_no_picture("Title status validated sucessfully") 
    Delay(30000)

    
def update_psi_status(page):
    web_utility.set_text_value_by_idstr_after_clear(page,'psiStatus',aqString.Concat('CANCELLED','[Tab]'))
    web_utility.click_button_by_idstr(page,'applyButton')
    tc_logs.checkpt_with_no_picture("PSI Cancelled status validated sucessfully") 
    Delay(30000)

def update_title_status(status):
    web_utility.find_link_by_idStr('titleStatus').keys('^a[BS]')
    web_utility.find_link_by_idStr('titleStatus').keys(aqString.Concat(status,'[Tab]'))
    tc_logs.checkpt_with_no_picture(f"Title status field updated as '{status}' ")
    if status.lower() == "matched":
          update_title_receipt_date()
    else:       
          Delay(30000)
          update_title_validate_date()
          
    web_utility.find_link_by_idStr('applyButton').Click()
    Delay(30000)
    tc_logs.checkpt_with_no_picture(f"Title status '{status}' Applied sucessfully")
    
def search_by_vin_consignment_id():
   tc_logs.checkpt_with_no_picture(f"Searching consignment with vin: {gvar.dataprep['vin']} and consignment id : {gvar.dataprep['consignment_id']} ")
   click_consignment_manager(gvar.dataprep['page'])
   web_utility.find_link_by_idStr('vin').keys(gvar.dataprep['vin']) 
   web_utility.find_link_by_idStr('consignmentId').keys(gvar.dataprep['consignment_id']) 
   web_utility.find_by_contenttext('Go').Click()
   Delay(10000)
   web_utility.find_img(["ObjectIdentifier","tabIndex"],["detailsicon_enabled_gif","0"]).Click()
   Delay(10000)                                                                                           
   tc_logs.checkpt_with_no_picture(f" Consignment:{gvar.dataprep['consignment_id']} Detail page displayed accuretly ")
   

def update_psi_status_e2e(status):
   web_utility.find_link_by_idStr('psiStatus').keys('^a[BS]')
   web_utility.find_link_by_idStr('psiStatus').keys(aqString.Concat(status,'[Tab]'))
   tc_logs.checkpt_with_no_picture(f"PSI status field updated as '{status}' ")
   #web_utility.find_link_by_idStr('applyButton').Click()
#   web_utility.click_button_by_idstr(page,'applyButton')
   Sys.Browser("iexplore").page("*").EvaluateXPath("//table[@id = 'pageButtonRN']//button[@id='applyButton']")[0].Click()
   Delay(30000)
   tc_logs.checkpt_with_no_picture(f"PSI status '{status}' Applied sucessfully")


