﻿from dbhelper import *
from ebiz import *
import web_utils
import dbhelper
import file_system_utils 
import form_utils

#This testcase is to reclassify asset and capture outputs for Mass Reclassification Preview

class tc97764cai_us_asset_reclassification(Ebiz):
 op_log_path="C:\\Tc_Logs"

 def login(self):
   self.login_user='naggarwal'
   super().login()
   
 def action(self,book): 
   # Navigate to CAI US FA ASSET TRANSACTIONS > MASS TRANSACTIONS> RECLASSIFCATIONS
   app = book.Sheets.item["Assets"]
   app1 = book.Sheets.Item["PA-FA"] 
   rowno=2
   self.page.wait()
   web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" FA ASSET TRANSACTION')]")
   self.log_message_web("Click 'CAI "+self.oper_unit+" FA ASSET TRANSACTION' - Successful")
   Delay(3000)
   self.page.wait()
   self.page.EvaluateXpath("//table[@id='respList']//div[text()='Mass Transactions']")[0].Click()
   self.log_message_web("Click 'Mass Transactions'- Successful")
   self.page.EvaluateXpath("//table[@id='respList']//div[text()='Reclassifications']")[0].Click()
   self.log_message_web("Click 'Reclassifications' - Successful")
   
   jFrame=self.initializeJFrame()
   Delay(4000)    
   form_utils.click_ok_btn(jFrame)

   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Mass Reclassifications","ExtendedFrame"]
   massreclassifications_form=jFrame.FindChildEx(prop,val,60,True,12000)
   self.verify_aqobject_chkproperty(massreclassifications_form,"AWTComponentAccessibleName",cmpContains,"Mass Reclassifications")
  
#----  Enter Asset Book,  Asset Category, Asset New Category, To and From Dates and submit Mass Reclassification Preview program ----
   
   massreclassifications_form.Find("AWTComponentAccessibleName","Book RequiredList of Values",60).Keys(VarToStr(app.Cells.Item[rowno,1]))
   self.log_message_oracle_form(massreclassifications_form,"Asset Book value entered")
   jFrame.Keys("[Tab]")
   Delay(2000)
   
   #Enter Assett Category
   prop = ["AWTComponentAccessibleName","JavaClassName"]
   val = ["CategoryList of Values","VTextField"]
   massreclassifications_form.FindChild(prop,val,2000).Click()
   Delay(2000)
   massreclassifications_form.FindChild(prop,val,2000).SetText(VarToStr(app.Cells.Item[rowno,5]))
   self.log_message_oracle_form(massreclassifications_form,"Assets Category Entered")
   Delay(2000)
   jFrame.Keys("[Tab]")
   Delay(2000)
   jFrame.keys("~o")
   Delay(2000)
   
   #Enter Service Dates
   prop = ["AWTComponentAccessibleName","JavaClassName"]
   val = ["From Date Placed In ServiceList of Values","VTextField"]
   massreclassifications_form.FindChild(prop,val,2000).Click()
   Delay(2000)
   massreclassifications_form.FindChild(prop,val,2000).SetText(VarToStr(app.Cells.Item[rowno,4]))
   self.log_message_oracle_form(massreclassifications_form,"From Service Date Entered")
   Delay(2000)
   jFrame.Keys("[Tab]")
   Delay(2000)
   
   prop = ["AWTComponentAccessibleName","JavaClassName"]
   val = ["To Date Placed In ServiceList of Values","VTextField"]
   massreclassifications_form.FindChild(prop,val,2000).Click()
   Delay(2000)
   massreclassifications_form.FindChild(prop,val,2000).SetText (DateTimeToFormatStr(aqDateTime.Now(),"%d-%b-%Y"))
   self.log_message_oracle_form(massreclassifications_form,"To Service Date Entered")
   Delay(2000)
   jFrame.Keys("[Tab]")
   Delay(2000)
   
   #Enter New Asset Category
   prop = ["AWTComponentAccessibleName","JavaClassName"]
   val = ["New Category RequiredList of Values","VTextField"]
   massreclassifications_form.FindChild(prop,val,2000).Click()
   Delay(2000)
   massreclassifications_form.FindChild(prop,val,2000).SetText(VarToStr(app.Cells.Item[rowno,3]))
   self.log_message_oracle_form(massreclassifications_form,"Assets New Category Entered")
   Delay(2000)
   jFrame.Keys("[Tab]")
   Delay(2000)
   jFrame.keys("~o")
   Delay(2000)
   
   #Check the Copy Category Descriptive Flexfield to New Category checkbox
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Copy Category Descriptive Flexfield to New Category alt C","LWCheckbox"]
   massreclassifications_form.FindChild(prop,val,60).Click()
   self.log_message_oracle_form( jFrame,"Enabled Copy Category Descriptive Flexfield to New Category")
   Delay(2000)
   
   #Check the Inherit Depreciation Rules to New Category checkbox
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Inherit Depreciation Rules of New Category alt I","LWCheckbox"]
   massreclassifications_form.FindChild(prop,val,60).Click()
   self.log_message_oracle_form( jFrame,"Enabled Inherit Depreciation Rules to New Category")
   Delay(2000)
   
   #Click thed Preview button
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Preview alt P","Button"]
   massreclassifications_form.FindChild(prop,val,60).Click()
   self.log_message_oracle_form(jFrame,"Reclassification Preview Submitted")
   Delay(2000)
   
   #Get the Request ID
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Note APP-OFA-*","ChoiceBox"]
   note_form=jFrame.FindChildEx(prop,val,60,True,40000) 
   RequestID = ''.join(x for x in (note_form.AWTComponentAccessibleName.strip().split(':'))[1].strip().split(',')[1] if x.isdigit())

   jFrame.keys("~o")
   Delay(2000)
   jFrame.keys("~o")
   Delay(2000)
   jFrame.keys("~v")
   Delay(2000)
   jFrame.keys("r")
   self.log_message_oracle_form( jFrame,"Find Requests form found")
   Delay(4000)
   
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Find Requests","ExtendedFrame"]
   find_req_form=jFrame.FindChild(prop,val,30)
   Delay(3000)

   jFrame.Keys("[Right]")
   Delay(2000) 
   jFrame.Keys("[Tab]")

   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Request ID","VTextField"]
   find_req_form.FindChild(prop,val,60).Click()
   find_req_form.FindChild(prop,val,60).SetText(RequestID)

   find_req_form.Find("AWTComponentAccessibleName","Find alt i",60).Click()
   Delay(2000)
   
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Requests","ExtendedFrame"]
   req_form=jFrame.FindChild(prop,val,1000)
   self.verify_aqobject_chkproperty(req_form,"AWTComponentAccessibleName",cmpContains,"Requests") 
   self.log_message_oracle_form(jFrame,"Requests Form Found")  

   # output file for Mass Reclassification Preview Report program
   dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
   user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
   pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
   dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,RequestID)
   
   #wait for View Output button to be Enabled
   vo_prop = ["AWTComponentAccessibleName","JavaClassName"]
   vo_val = ["View Output alt p","Button"]
   while not req_form.FindChild(vo_prop,vo_val,2000).Enabled:
     Delay(10000)
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val = ["Refresh Data alt R","Button"]
     req_form.FindChild(prop,val,2000).Click()
   
   #Click the View Output button
   Delay(2000) 
   prop = ["AWTComponentAccessibleName","JavaClassName"]
   val = ["View Output alt p","Button"]
   req_form.FindChild(prop,val,2000).Click()
   self.log_message_oracle_form(jFrame,"View Output button clicked") 
   
   Delay(3000)
   output_page=Sys.Browser("iexplore").page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
   output_page.Click()
   
   #Save Output
   Delay(2000)
   output_page.Keys("~f")
   output_page.Keys("a")
   Delay(2000)
   
   file_system_utils.create_folder(self.op_log_path)             
   log_path=self.op_log_path+"\\Mass Reclassification Preview Report_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
   Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
   Delay(1000)
   Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
   Delay(1000)
   
   #Verify the log for output
   fo=open(log_path,"r")
   lines=fo.readlines()
   Log.Enabled=True
   asset_num=lines[20][0:7].strip()
  
   if asset_num == "":
     Log.Error("No Asset Numbers in report output")
     
   Log.File(log_path, "Mass Reclassification Preview Report Output File Attached")
   Log.Enabled=False     
   Sys.Browser("iexplore").Page("https://core-*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close() 
   Delay(2000)   
   jFrame.Keys("[F4]")
   self.log_message_oracle_form( jFrame,"Requests form closed")
   Delay(3000)
   
   self.verify_aqobject_chkproperty(massreclassifications_form,"AWTComponentAccessibleName",cmpContains,"Mass Reclassifications")
   
   #Close Application
   Delay(2000)   
   jFrame.Keys("[F4]")
   Delay(3000)
   jFrame.Close()
   Delay(1000)
   jFrame.keys("~o")
   Delay(1000)
   web_utils.close_additional_browsers() 