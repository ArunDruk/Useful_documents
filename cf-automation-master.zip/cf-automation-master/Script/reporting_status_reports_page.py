﻿import gvar

### In this method objects for below pages have been captured ###

#REPORTING > STATUS REPORTS PAGE

def status_reports_page_link():
  prop_names = ["contentText","idStr","ObjectType"]
  prop_values = ["Status Reports","PA_PROGRESS_REPORT_SUBTAB","Link"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
