﻿import tc_logs
import gvar
import api_utility
import adjustment_api_payloads as adj_payload
from adjustment_queries import verify_arb_amount as _ADJ_QRY
from adjustment_queries import verify_arb_amount_test as _ADJ_QRY_TEST
from database_service import query_oracle_db as _ORACLE_DB
from gvar import dataprep as DATAPREP 

__print = tc_logs.checkpt_with_no_picture
__Error = tc_logs.error_with_no_picture
__api  = api_utility.post_or_put
__payload = {
  'initiate_call' : adj_payload.arb_initiate_call,
  'seller_call_without_adj'   : adj_payload.arb_seller_call_without_adjustments,
  'buyer_call_without_adj'    : adj_payload.arb_buyer_call_without_adjustments,
  'buyer_call_with_adj'       : adj_payload.arb_buyer_call_with_adjustments ,
  'seller_call_with_adj'      : adj_payload.arb_seller_call_with_adjustments
}
  
def fire_payload(api,payload,case_status = None,disposition = None):
  
      __validate_parameters(payload,case_status,disposition)
      response = __api(api,__payload[payload](case_status,disposition))   
      __validate_response(response)  

def __validate_parameters(payload,case_status,disposition):
        if ( (not payload == 'initiate_call') and 
             (( case_status is None and disposition is None ) or 
              ((case_status == "" ) and (disposition == "")))):
          __Error("Please provide case status or disposition on Seller call or Buyer call method ", "") 
                                      

def __validate_response(response):
    if response['status'] == '202' and response['message'] == 'SUCCESS':
      __print("Payload post was successfull") 
    else:
      __Error(f"Failed Status:  {response['status']} ")
      __Error(f"Failed Message: {response['message']} ")
      

def __Validate_Credit_Memo():
   
   rows = _ORACLE_DB(_ADJ_QRY())
   if (GetVarType(rows)!= VarToInt(9)and len(rows)> 0):
     if abs(int(rows[0]['TOT_AMT']))  == abs(int(DATAPREP['amount_due_remaining'])):
        __print(f" Adjument API : CM Generated with due amount {DATAPREP['amount_due_remaining']} ")
     else:
         __Error("Adjustment API - CM didn't generated - Check payload and Workfow")    

def __Validate_Credit_Memo_Test():
   
   rows = _ORACLE_DB(_ADJ_QRY_TEST())
   if (GetVarType(rows)== VarToInt(9)and len(rows)> 0):
     if rows[0]['TOT_AMT']  == -4490:
        __print(f" Adjument API : CM Generated with due amount 4490")
     else:
         __Error("Adjustment API - CM didn't generated - Check payload and Workfow")  

   
def test():
  rows = [{'TOT_AMT': -4586}]
  DATAPREP = [{'amount_due_remaining': 4586}]
  if abs(int(rows[0]['TOT_AMT']))  == abs(int(DATAPREP[0]['amount_due_remaining'])):
    Log.Message('sucess')
