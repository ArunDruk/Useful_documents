﻿

from ebiz import *
import web_utils
import form_utils
import dbhelper
import file_system_utils


class tc179291_is_webadijournal_workflow_approval(Ebiz):

 op_log_path ="C:\\TC_Logs"

 def login(self):
   self.login_user='Bbristow'
   super().login()

 def goto_url(self,url):
   super().goto_url(self.testConfig['ebiz']['oci_is_url'])
   
 def action(self,book): 
    web_utils.log_checkpoint("Login to Oracle Applications Successful",500,self.page) 
    if ProjectSuite.Variables.currency =="USD": 
      app = book.Sheets.item["JournalWebAdi_USD"]
    elif ProjectSuite.Variables.currency=="CAD":
      app = book.Sheets.item["JournalWebAdi_CAD"]
    self.page.Wait()
    self.page.EvaluateXPath("//button[@id='NtfFullList']")[0].Click()
    self.page.wait()
    web_utils.log_checkpoint("Click FullList Successful",500,self.page) 
    Delay(5000)
    table_obj=self.page.EvaluateXPath("//table[@id='NtfWorklist:Content']")[0]    
    tot_rows=table_obj.RowCount
    web_utils.log_checkpoint("Total Number Of Open Notifications : " + VarToStr(tot_rows),500,self.page) 
    req_id=app.Cells.Item[2,14]
    Delay(3000)
   
    for i in range(0,VarToInt(tot_rows)-1):
      subject=subject=table_obj.FindChild("name","Cell("+aqConvert.VarToStr(i)+",3)",10).contentText
      Delay(3000)
      Subject_message=subject.split(" ",7)[2][0:11]
      Subject_req_id=subject.split(" ",7)[5][0:9]
      if (Subject_message=='Spreadsheet') and (VarToInt(Subject_req_id) == req_id):
        web_utils.log_checkpoint("Journal Name: "+ subject,500,self.page) 
        self.page.Find("idStr","N*:NtfSubject:"+aqConvert.VarToStr(i),30).Click()
        Delay(3000)
        web_utils.log_checkpoint("Found Journal Batch; Click Approve Next",500,self.page) 
        Delay(3000)
        self.page.EvaluateXPath("//button[@title='Approve']")[0].Click()
        self.page.wait()
        break





 
