﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils
import winscp_utility
import tc_logs
from File_Handler import File_Handler as _TXTOBJ
from text_headers import payroll_txt_file_header as _HEADERS
import web_utils
import form_utils
import datetime as dt

class tc215849_is_cai_intercompany_trx_outbound_interface_d(Ebiz):
  
  op_log_path="C:\\TC_Logs"
  
  def login(self):
      self.login_user="mfallwell"
      super().login()

 
  def action(self,book):
    web_utils.log_checkpoint("Logged into CAI Oracle Ebiz Instance Successfully",500,self.page)
    self.wait_until_page_loaded() 
    self.page.WaitProperty("contentText","CAI ALL GL JOB SCHEDULER",6000)
    cai_gl_submit_link=self.page.NativeWebObject.Find("contentText","CAI ALL GL JOB SCHEDULER","A")
    self.verify_aqobject_chkproperty(cai_gl_submit_link,"contentText",cmpIn,"CAI ALL GL JOB SCHEDULER")
    cai_gl_submit_link.Click() 
    web_utils.log_checkpoint("Click 'CAI ALL GL JOB SCHEDULER' - Successful",500,self.page)
    Delay(1000)    
    self.page.Wait()
    self.page.NativeWebObject.Find("contentText","Submit Request","A").Click()
    web_utils.log_checkpoint("Click 'Submit Request' - Successful",500,self.page)
    jFrame= self.initializeJFrame()
    Delay(10000)
    form_utils.click_ok_btn(jFrame)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit a New Request","ExtendedFrame"]
    submit_new_req_form=jFrame.FindChildEx(prop,val,60,True,90000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["What type of request do you want to run? Request Set alt s","ExtendedCheckbox"]  
    submit_new_req_form.FindChild(prop,val,10).Click()       
    Delay(1000)
    submit_new_req_form.FindChild("AWTComponentAccessibleName","OK alt O",10).Click()
    
    
    
# Submitting "CAI Oracle GL Inbound JE Interface Request Set - IS" Request Set using CAI ALL GL JOB SCHEDULER' responsibility

    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit Request Set","ExtendedFrame"]
    par_form=jFrame.FindChild(prop,val,60)
    par_form.Find("AWTComponentAccessibleName","Request Set RequiredList of Values",30).SetText("CAI Oracle GL Inbound JE Interface Request Set - IS")
    web_utils.log_checkpoint("Request Set Name: 'CAI Oracle GL Inbound JE Interface Request Set - IS' - populated Successfully",500,jFrame)
    delay(1000)
    jFrame.Keys("[Tab]")
    delay(1000)
    par_form=jFrame.FindChild(prop,val,60)
    par_form.Find("AWTComponentAccessibleName","Submit",30).Click()
    form_utils.click_ok_btn(jFrame)    
    web_utils.log_checkpoint("Request Set Name: 'CAI Oracle GL Inbound JE Interface Request Set - IS' parameters - submitted Successfully",500,jFrame)
    delay(3000)
    RequestID = ''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit()) 
    web_utils.log_checkpoint("Request ID Of 'CAI Oracle GL Inbound JE Interface Request Set - IS'" + aqConvert.VarToStr(RequestID),500,jFrame)
    Delay(2000)
    jFrame.Keys("~n")
    dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
    user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
    pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
    dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,RequestID)
    
    Delay(4000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000) 
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,90000)
    self.req_set_save_log(jFrame,req_form,"CAI Oracle GL Inbound JE Interface Request Set - IS (Request Set CAI Oracle GL Inbound JE Interface Request Set - IS)",RequestID,type = "Inbound")
    Delay(1000)
    jFrame.Click()
    Delay(2000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000)
    
# Gathering Request ID and Output File for the "IS: CAI Intercompany Transactions Outbound Interface" 
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,90000)
    self.req_set_save_log(jFrame,req_form,"CAI Inbound Global File Validation Program",RequestID,type = "Inbound")
    self.req_set_save_log(jFrame,req_form,"CAI Global Data Loader",RequestID)
    jFrame.Click()
    Delay(2000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000)

# Gathering Request ID and Log File for the "IS: Transfer Intercompany Transactions file to Sterling (MAN:Transfer files to Sterling)" 
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,90000)
    self.req_set_save_output(jFrame,req_form,"CAI Oracle IS GL Preprocessor Program",RequestID)
    jFrame.Click()
    Delay(2000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000)
    

# Gathering Request ID and Log File for the "Journal Import" 
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,90000)
    creqid = self.req_set_save_output(jFrame,req_form,"Journal Import",RequestID)
    jFrame.Click()
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~n")
    Delay(1000)  

    
# Submitting "Program - Automatic Posting" Request Set using CAI ALL GL JOB SCHEDULER' responsibility
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit Request","ExtendedFrame"]
    par_form=jFrame.FindChildEx(prop,val,60,True,90000)
    par_form.Find("AWTComponentAccessibleName","Name RequiredList of Values",30).SetText("Program - Automatic Posting")
    delay(1000)
    jFrame.Keys("[Tab]")
    delay(2000)
    jFrame.Keys("CAUTO GL JEs AUTO-POST")
    delay(1000)
    jFrame.Keys("~o")
    delay(2000)
    par_form.FindChild("AWTComponentAccessibleName","Submit alt m",10).Click()
    Delay(1000)
    self.log_message_oracle_form(jFrame,"Program - Automatic Posting is Submitted")  
    RequestID = ''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit()) 
    web_utils.log_checkpoint("Request ID Of 'Program - Automatic Posting'" + aqConvert.VarToStr(RequestID),500,jFrame)
    Delay(2000)
    jFrame.Keys("~n")
    dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
    user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
    pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
    dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,RequestID)
    Delay(5000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000) 
    
# Gathering Request ID and Output File for the "CAI Oracle GL Inbound JE Interface Program"   

    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,90000)  
    self.req_set_save_output(jFrame,req_form,"Program - Automatic Posting",RequestID) 
    jFrame.Click()
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~o")
    Delay(1000)    
    
    
# Post from CAI CAI ALL GL JOURNAL PROCESSING Responsibility

    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI ALL GL JOURNAL PROCESSING')]")
    Delay(3000)
    self.page.EvaluateXpath("//table[@id='respList']//div[text()='Enter Journals']")[0].Click()
    web_utils.log_checkpoint("Click 'Enter Journals'- Successful",500,self.page)
    web_utils.validate_security_box()
    Delay(20000)
    jFrame=self.initializeJFrame()
    Delay(8000)
    form_utils.click_ok_btn(jFrame)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Journals","ExtendedFrame"]
    fnd_jrnl=jFrame.FindChildEx(prop,val,60,True,90000)
    fnd_jrnl.Find("AWTComponentAccessibleName","BatchList of Values",10).Click()
    delay(3000) 
    fnd_jrnl.Find("AWTComponentAccessibleName","BatchList of Values",10).Keys("%"+VarToStr(creqid)+"%")
    web_utils.log_checkpoint("Finding the Journal next",500,jFrame)
    delay(3000) 
    jFrame.Keys("~i")
    delay(15000)  
    jFrame.Keys("~u")
    delay(4000) 
    web_utils.log_checkpoint("Review Journal Header level and Line level information succesfully",500,jFrame)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Journals (CAI ALL LEDGERS)*","ExtendedFrame"]
    jrnls=jFrame.FindChildEx(prop,val,60,True,60000)
    jrnls.FindChild("AWTComponentName","FormsTabPanel*",60).ClickTab("Other Information")
    
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Status: Posting",0]
    jrnl_val = jFrame.FindChild(prop,val,60)
    jrnl_status=jrnl_val.wText    
    Log.Enabled=True
    aqObject.CheckProperty(jrnl_val,"wText",cmpIn,"Posted")
    Log.Enabled=False
    web_utils.log_checkpoint("Journal Status: "+jrnl_status,500,jFrame) 
    
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Source",3]
    jrnl_source = jFrame.FindChild(prop,val,60)
    jrnl_source_status=jrnl_source.wText  
    Log.Enabled=True
    aqObject.CheckProperty(jrnl_source,"wText",cmpIn,"CAUTO")
    Log.Enabled=False
    web_utils.log_checkpoint("Journal Source: "+jrnl_source_status,500,jFrame) 
    
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Status: Approval",2]
    jrnl_appr_val = jFrame.FindChild(prop,val,60)
    jrnl_appr_status=jrnl_appr_val.wText  
    Log.Enabled=True
    aqObject.CheckProperty(jrnl_appr_val,"wText",cmpIn,"N/A")
    Log.Enabled=False
    web_utils.log_checkpoint("Journal Approval Status: "+jrnl_appr_status,500,jFrame)     
    web_utils.log_checkpoint("Reviewed Journal Status, Journal Source and Journal  Approval Status successfully",500,jFrame) 
    
    delay(4000) 
    jrnls.FindChild("AWTComponentName","FormsTabPanel*",60).ClickTab("Lines")
    delay(4000) 
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Journals (CAI ALL LEDGERS)*","ExtendedFrame"]
    jrnls=jFrame.FindChildEx(prop,val,30,True,60000)
    prop=["JavaClassName","AWTComponentIndex"]
    val=["LWScrollbar","0"]
    down_button=jrnls.FindChildEx(prop,val,30,True,60000)
    for i in range(0,10):
     prop=["JavaClassName","AWTComponentIndex"]
     val=["ContinuousButton","0"]
     down_button.Find(prop,val,20).Click()
    delay(4000)
    jrnls.Close()
    delay(4000)
    jFrame.Close()
    Delay(1000)
    jFrame.Keys("~o")
    Delay(1000)
    
    
    
  def req_set_save_output(self,jFrame,req_form,srch_child_name,Preqid):
    web_utils.log_checkpoint("Checking for "+aqConvert.VarToStr(srch_child_name)+ " Child Program Status",500,jFrame)
    req_form.FindChild("AWTComponentAccessibleName","Refresh Data alt R",20).Click()
    i=20
    for x in range(1,180):     
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Name",i]
        child_name=req_form.Find(prop,val,10).wText 
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Phase",i+20]
        phase=req_form.Find(prop,val,10).wText 
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Request ID",i-10]
        creqid=VarToInt(req_form.Find(prop,val,10).wText)                                        
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Status",i+30]         
        status =req_form.FindChild(prop,val,60)            
        if (child_name==srch_child_name) and (aqConvert.VarToInt(creqid)>=aqConvert.VarToInt(Preqid)) and (phase == "Completed"):
            web_utils.log_checkpoint(aqConvert.VarToStr(srch_child_name)+" Phase Completed Successfuly",500,jFrame)      
            self.verify_aqobject_chkproperty(status,"wText",cmpIn,"Normal,Warning,Error")
            self.log_message_oracle_form(req_form,"Request ID of "+aqConvert.VarToStr(srch_child_name)+" is "+aqConvert.VarToStr(creqid))                       
            status.Keys("[Enter]")
            Delay(1000)
            req_form.FindChild("AWTComponentAccessibleName","View Output alt p",20).Click()  
            Delay(4000)
            output_page=Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
            output_page.Click()
            Delay(2000)
            output_page.Keys("~f")
            Delay(2000)
            output_page.Keys("a")
            Delay(5000)
            file_system_utils.create_folder(self.op_log_path)             
            self.log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"File"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"_%d%b%Y_%H%M")+".txt"    
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(self.log_path)
            Delay(1000)
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
            Delay(8000)
            Log.Enabled=True
            Log.File(self.log_path, aqConvert.VarToStr(srch_child_name)+" is Completed And Output file is attached")
            Log.Enabled=False     
            web_utils.close_additional_browsers()         
            Filesaved = 'True'
            return creqid                          
        elif i >=29:
           Delay(15000)           
           req_form.FindChild("AWTComponentAccessibleName","Refresh Data alt R",20).Click()
           Delay(3000)
           i=20
           val=["Name",i]
           child_name=req_form.Find(prop,val,10).wText
        else:  
           Delay(2000)
           i=i+1 
           
 
  def req_set_save_log(self,jFrame,req_form,srch_child_name,Preqid,type=""):
    
        prop=["AWTComponentAccessibleName","JavaClassName"]
        val = ["Refresh Data alt R","Button"]
        req_form.FindChild(prop,val,2000).Click() 
         
        for x in range(20,51):
          
          if x>29:
            jFrame.Keys("[Down]")        
            x=29
                        
          prop=["AWTComponentAccessibleName","AWTComponentIndex"]
          val=["Phase",x+20]
          phase=req_form.Find(prop,val,10).wText
           
          prop=["AWTComponentAccessibleName","AWTComponentIndex"]
          val=["Request ID",x-10]
          creqid=VarToInt(req_form.Find(prop,val,10).wText)
          
          prop=["AWTComponentAccessibleName","AWTComponentIndex"]
          val=["Name",x]
          child_name=req_form.Find(prop,val,10).wText
          req_form.Find(prop,val,10).Click()
            
          prop=["AWTComponentAccessibleName","AWTComponentIndex"]
          val=["Status",x+30]         
          status =req_form.FindChild(prop,val,60)
          
          if (child_name==srch_child_name) and (aqConvert.VarToInt(creqid)>=aqConvert.VarToInt(Preqid)) and (phase == "Completed"): 
            self.log_message_oracle_form(req_form,aqConvert.VarToStr(srch_child_name)+" Phase Completed Successfuly")            
            self.verify_aqobject_chkproperty(status,"wText",cmpIn,"Normal,Warning,Error")
            self.log_message_oracle_form(req_form,"Request ID of "+aqConvert.VarToStr(srch_child_name)+" is "+aqConvert.VarToStr(creqid))
            req_form.Find(prop,val,10).Keys("[Enter]")
            Delay(1000)
            
            prop=["AWTComponentAccessibleName","JavaClassName"]
            val=["View Log alt K","Button"]
            log_button=req_form.FindChild(prop,val,60)
            log_button.Click()     
            Delay(3000)
            output_page=Sys.Browser("iexplore").Page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
            output_page.Click()
            Log.Enabled=True
            wnd = Sys.Desktop.ActiveWindow()
            Log.Picture(wnd, f"WinScp File Location path: {type}", wnd.FullName)                 
            Log.Enabled=False
            Delay(2000)
            output_page.Keys("~f")
            Delay(2000)
            output_page.Keys("a")
            Delay(5000)
            file_system_utils.create_folder(self.op_log_path)             
            log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"Is Attached_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
            Delay(1000)
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
            Delay(6000)
            Log.Enabled=True
            Log.File(log_path, aqConvert.VarToStr(srch_child_name)+" Log File Attached")
            Log.Enabled=False    
            Sys.Browser("iexplore").page("https://core-*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close()  
            web_utils.close_additional_browsers()
            Delay(2000)   
            jFrame.Click()
            Delay(2000)
            return creqid

