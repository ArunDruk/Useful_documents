﻿from ebiz import *
import dbhelper 
import web_utils
#Author:            Prabhakaran Rajendran
#TestCaseID:        TC21431
#UserStoryID:       US126473
#Reviewed_By:       Syed,Husain && Seelam, Lakshmi



class tc98616cai_us_ap_invoices_initiate_approval(Ebiz):
  #declare variables to be used in the methods
  global rowno, app, book, val

  def login(self):
    self.login_user="amalappan"
    super().login()
    
  #action method to call all sub functions(methods)
  def action(self,book):
      global rowno, app
      rowno=2
      app = book.Sheets.item["Invoice"]
      RowCount = app.UsedRange.Rows.Count
      
#      while rowno<(RowCount+1):
#        val = VarToString(app.cells.Item[rowno,13])
#        if rowno == 2:
#          self.nav_appr()
#        else: 
#          self.multi_inv()
#        self.init_appr(val,app)  
#        self.apr_val(app,rowno)
#        rowno = rowno+1
#        delay(1000)
      
      val = VarToString(app.cells.Item[rowno,13]) 
      self.nav_appr()
      self.init_appr(val,app)  
      self.apr_val(app,rowno)
       
      book.save()
      Delay(1000)
#      Sys.Browser().page("https://*ebs.coxautoinc.com/forms/frmservlet*").Close()
      del app,rowno,val
  
      
  def nav_appr(self):      
      self.page.wait()
      Log.Message("Inside action...")
      web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" AP INVOICE PROCESSING')]")
      self.log_message_web("Click 'CAI "+self.oper_unit+" AP INVOICE PROCESSING' - Successful")
      Delay(1000)
      self.wait_until_page_loaded() 
      web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Invoices')]")
      self.log_message_web("Click 'Invoices' - Successful") 
      Delay(1000)
      self.wait_until_page_loaded()
      Delay(1000)  
      web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Entry')]")
      self.log_message_web("Click 'Entry' - Successful") 
      Delay(1000)
      self.wait_until_page_loaded()
      self.page.EvaluateXPath("//div[text()='Invoices']")[1].Click()
      self.log_message_web("Click 'Invoices' - Successful")
      delay(10000)
      self.jFrame = self.initializeJFrame()
      Delay(2000)
      form_utils.click_ok_btn(self.jFrame)

        
  def init_appr(self,val,app):
      delay(3000) 
      #Landing Page Validation - AP Invoice Processing  
      p_names =  ["JavaClassName","AWTComponentAccessibleName"]       
      p_values = ("ExtendedFrame","Invoice Workbench (CAI "+self.oper_unit+" AP INVOICE PROCESSING)")
      obj=self.jFrame.Find(p_names,p_values,50)
      if obj.Exists:
        self.log_checkpoint_message_web("AP Invoice Page Launched Successfully")
      else:
        self.log_message_oracle_form(self.jFrame,"Unable to Launch AP Invoice Form") 
      
      inv_wb_form = self.jFrame.Find(p_names,p_values,20)
      Delay(1000)
      
      #Navigate to Find Invoices Form

      tool_bar_v = Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWMenuBar", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWMenu", "View mnemonic V", 2)
      tool_bar_v.Click()
      Delay(1000)
      tool_bar_v.Keys("f") 
      self.log_message_oracle_form(self.jFrame,"Navigate to Find Invoices Form")
      p_names = ("JavaClassName","AWTComponentAccessibleName")
      p_values = ("ExtendedFrame","Find Invoices")
      find_inv_form=self.jFrame.FindChildEx(p_names,p_values,40,True,7000)      
      if find_inv_form.Exists:
        self.log_checkpoint_message_web("Find Invoices Form Launched Successfully")
      else:
        self.log_message_oracle_form(self.jFrame,"Unable to Launch Find Invoices Form") 
      Delay(1000)    
      
      pro = ("AWTComponentIndex","AWTComponentAccessibleName")
      values = (6,"Invoice: Number") 
      Delay(1000)      
      find_inv_form.FindChild(pro,values,20).Click()
      delay(1000)
      find_inv_form.FindChild(pro,values,20).SetText(val)
      Delay(1000)
      values = (3,"Find alt i")
      Delay(1000)
      find_inv_form.FindChild(pro,values,20).Click()
      Delay(4000)  
      
      #query back to AP Invoice Form
      p_values = ("ExtendedFrame","Invoice Workbench (CAI "+self.oper_unit+" AP INVOICE PROCESSING)")
      obj=self.jFrame.Find(p_names,p_values,50)
      if obj.Exists:
        self.log_checkpoint_message_web("AP Invoice Page with Invoice Details available")
      else:
        self.log_message_oracle_form(self.jFrame,"Unable to Query Entered Invoice Details") 
        
      #Validation & Action to Initiate Approval  
      pro = ("AWTComponentIndex","AWTComponentAccessibleName")
      values = (5,"Accounted")
      account_status = inv_wb_form.FindChildEx(pro,values,40,20000).wText
      if(account_status == 'Yes'):
        self.jFrame.Keys("~c")
        delay(2000)
        p_values = ("ExtendedFrame","Invoice Actions")
        fnd_actions = self.jFrame.FindChild(p_names,p_values,20)
        if fnd_actions.Exists:  
          self.log_message_oracle_form(self.jFrame,"Find Actions Form is available")
        else:
          self.log_message_oracle_form(self.jFrame,"Unable to open Find Actions Form")
          self.log_error_message("Unable to open Find Actions Form")

        Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("ExtendedFrame", "Invoice Actions", 0).AWTObject("LWComponent", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("FScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("DrawnPanel", "", 0).AWTObject("FScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("DrawnPanel", "", 0).AWTObject("CheckBox49").Click()
        delay(2000)
        p_values = ("Button","OK alt K")
        fnd_actions.FindChild(p_names,p_values,20).Click()
        Delay(10000)
        tool_bar_f = Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWMenuBar", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWMenu", "File mnemonic F", 0)
        tool_bar_f.Click()
        Delay(1000)
        tool_bar_f.Keys("s")
        delay(2000)
        self.log_message_oracle_form(self.jFrame,"Invoice is Accounted: Initiated Approval")
      else:
        self.log_message_oracle_form(self.jFrame,"Invoice is not Accounted: Cannot Initiate Approval")
        self.log_error_message("Invoice not Accounted")
        
        
  def apr_val(self,app,rowno):        

        pro=("AWTComponentAccessibleName","AWTComponentIndex")
        values=("Invoice Num Required",32)
        inv = self.jFrame.FindChildEx(pro,values,30,True,120000).wText
        delay(1000)        
        p_values = ("Approval",6)
        obj=self.jFrame.FindChildEx(pro,p_values,50,True,120000)
        
        if obj.wText == "Initiated" or obj.wText == "Not Required":
          self.log_checkpoint_message_web("Approval Initiated for AP Invoice: "+inv)
        else:
          self.log_message_oracle_form(self.jFrame,"Current Approval Status: "+obj.wText)
          self.log_error_message("Approval Initiation Failed")
          delay(2000)

        dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
        user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
        pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd'] 
        inv_id = dbhelper.get_invoice_id(dsn,user_id,pwd,inv)
                    
#        inv_id = dbhelper.get_invoice_id(inv)
#        self.log_message_oracle_form(self.jFrame,"Invoice_id :"+inv_id)
        
        delay(1000)
        app.Cells.Item[rowno,17] = inv_id
        self.close_forms(self.jFrame)
#        self.jFrame.Keys("[F4]")
#        Delay(1000)
#        self.jFrame.Keys("[F4]")
#        Delay(2000)
#        self.jFrame.Keys("~o")
#        Delay(4000)
#        Sys.Browser("iexplore").page("https://core-*.epfinnp.coxautoinc.com/forms/frmservlet*").Close()        
        Delay(2000)  
        
  def multi_inv(self):

        self.wait_until_page_loaded()
        self.jFrame.Keys("[F4]")
  #      delay(2000)
  #      self.jFrame.Find("AWTComponentAccessibleName","Yes ALT Y").Click()
        delay(3000)
        self.jFrame.FindChild("AWTComponentAccessibleName","Open alt O",30).Click()
        Delay(3000)
        self.jFrame.FindChild("AWTComponentAccessibleName","Open alt O",30).Click()
        Delay(1000)  
        self.jFrame.Keys("[Down]")
        Delay(1000)
        self.jFrame.Keys("[Enter]")
        delay(10000)
        p_names = ("JavaClassName","AWTComponentAccessibleName")
        p_values = ("ExtendedFrame","Invoice Workbench (CAI "+self.oper_unit+" AP INVOICE PROCESSING)")
        obj=self.jFrame.FindChild(p_names,p_values,50)
        if obj.Exists:
          self.log_checkpoint_message_web("AP Invoice Page Launched Successfully")
        else:
          self.log_message_oracle_form(self.jFrame,"Unable to Launch AP Invoice Form")  


def Test1():
#  OCR.Recognize(Aliases.jp2launcher.Frame2.FndFormsEngine0.MDIContainer8.LWComponent6.ToolBar1289).BlockByText("Eile Edit View Folder Tools Reports Actions Window Help").Click()
#  Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications - Stage", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWMenuBar", "", 0).Keys("~v")
  tool_bar = Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications - Stage", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWMenuBar", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWMenu", "View mnemonic V", 2)
  tool_bar.Click()
  tool_bar.Keys("f")
