﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils
import winscp_utility
import web_utils
import random

class tc99130_cai_us_gl_daily_rates_file_import_from_wellsfargo_ete26b(Ebiz):
 
 global inv_date,inv_num, obj
 op_log_path="C:\\TC_Logs"
 daily_rate_files="C:\\Daily_Rate_Files"
 
 def login(self):
    self.login_user="mfallwell"
    super().login()
 
 def action(self,book):
    
    app = book.Sheets.item["Daily_Rates"] 

#Log in to Oracle Applications and Submit Daily Rates Import Program:

    Log.Message("Login to Oracle and Submit Request to import Daily Rates File...") 
    delay(4000)
    self.page.WaitProperty("contentText","CAI ALL GL JOB SCHEDULER",6000)
    #cai_ap_invpro_link=self.page.Find("contentText","CAI ALL GL JOB SCHEDULER",30)
    cai_GL_Scheduler_link=self.page.Find("contentText","CAI ALL GL JOB SCHEDULER",30)
    self.verify_aqobject_chkproperty(cai_GL_Scheduler_link,"contentText",cmpIn,"CAI ALL GL JOB SCHEDULER")
    #cai_ap_invpro_link.Click() 
    cai_GL_Scheduler_link.Click()
    self.log_message_web("Click 'CAI ALL GL JOB SCHEDULER' - Successful; Click Submit Request Next-")
    delay(2000)   
    self.page.Find("contentText","Submit Request",30).Click()

    delay(3000) 
    jFrame=self. initializeJFrame()
    form_utils.click_ok_btn(jFrame)
    delay(1000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit a New Request","ExtendedFrame"]
    par_form=jFrame.FindChildEx(prop,val,60,True,40000)
    jFrame.Keys("~r")
    delay(2000)
    self.log_message_oracle_form( jFrame,"Select Request and Click Ok Button in Submit new Request Window")
    jFrame.Keys("~o")
    delay(2000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit Request","ExtendedFrame"]
    Submit_req_set_form=jFrame.FindChild(prop,val,60)
    Submit_req_set_form.FindChild("AWTComponentAccessibleName","Name RequiredList of Values",30).Keys("CAI GL I33A Daily Exchange Rates Import Process")
    self.log_message_oracle_form( jFrame," Enter Request Name: CAI I33A GL Daily Rates Import Process Request")
    delay(2000)
    jFrame.Keys("[Tab]")
    prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
    val=["Parameters","VTextField","15"]
    Submit_req_set_form.FindChild(prop,val,60).Click()
    Delay(2000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Parameters","FlexWindow"]
    Parameters_win=jFrame.FindChild(prop,val,60)
    
#####    val_date = aqDateTime.Today()
#####    chk_date = aqDateTime.GetDayOfWeek(val_date)
#####    if chk_date == 1 or chk_date == 7:
#####      req_date = (aqConvert.DateTimeToFormatStr(val_date,"%d-%b-%Y"))
#####      if chk_date == 1:
#####        fri_date = aqDateTime.AddDays(val_date, -2)
#####        comp_date = (aqConvert.DateTimeToFormatStr(fri_date,"%d-%b-%Y"))
#####      elif chk_date == 7:
#####          fri_date = aqDateTime.AddDays(val_date, -1)
#####          comp_date = (aqConvert.DateTimeToFormatStr(fri_date,"%d-%b-%Y"))
#####    else:
#####      self.log_error_message("CAI I33A GL Daily Rates Program can be run only on weekend")
    req_date = ("05-OCT-2019")
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Exchange Rates Date*","FlexTextField"]
    Parameters_win.FindChild(prop,val,60).Click()
    Parameters_win.FindChild(prop,val,60).Keys(req_date)
    self.log_message_oracle_form( jFrame," Click Parameter and Enter today's date for Exchange Rates Date")
    delay(2000)
    Parameters_win.Keys("~o")
    delay(2000)    
    self.log_message_oracle_form( jFrame," Click Submit Button ")
    #___________________________________#

#    jFrame.Keys("[Tab]")
#    jFrame.Keys("[Enter]")
    prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
    val=["Submit alt m","Button","7"]
    Submit_req_set_form.FindChild(prop,val,15).Click()
        
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Submit","Button"]
#    sub_button=jFrame.FindChild(prop, val, 60)
#    sub_button.FindChild(prop,val,60).Click()
#    Delay(3000)
##    par_form.Keys("~m")
    
#    par_form.Find("AWTComponentAccessibleName","Request Set RequiredList of Values",30).Keys("[Enter]")
#    delay(2000)
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Sets","FWindow"]
#    set_form=jFrame.FindChild(prop,val,60)
#    set_form.Keys("[Down]")
#    set_form.Keys("[Enter]")
    delay(2000) 
      
    RequestID = ''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit())
    
    self.log_message_oracle_form( jFrame,"Request ID Generated: "+ aqConvert.VarToStr(RequestID))
    #self.log_checkpoint_message_web("Request ID for CAI US Daily Rates File Import from WellsFargo is " + aqConvert.VarToStr(RequestID))    
    delay(1000)    
    jFrame.Keys("~n")
    delay(1000)
#    jFrame.Keys("~i")
#    delay(5000)
    
    jFrame.Keys("~v")
    Delay(2000)
    jFrame.Keys("r")
    Delay(2000)
#    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#    val=["Find alt i",3]
#    find_button=jFrame.FindChild(prop,val,20)
#    find_button.FindChild(prop,val,20).Click()
    jFrame.Find("AWTComponentAccessibleName","Find alt i",30).Click()
#    jFrame.Keys("~i")
    Delay(2000) 
    self.log_message_oracle_form( jFrame,"Navigation Successul: View > Request; Click Find")
       

    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,40000)
    self.log_message_oracle_form(req_form,"Requests Window Opened;Click Refresh next")
    req_form.keys("~r")
#    form_utils.req_set_save_log(self,jFrame,req_form,"CAI Inbound Global File Validation Program",RequestID)
    Delay(2000)
    form_utils.req_set_save_log(self,jFrame,req_form,"CAI GL I33A Daily Exchange Rates Import Process",RequestID)
#    self.req_set_save_Log(jFrame,req_form,"CAI Inbound Global File Validation Program",RequestID)
#    Delay(2000)
#    self.req_set_save_Log(jFrame,req_form,"CAI GL I33A Daily Exchange Rates Import Process",RequestID)
#    #jFrame.Click()
    Delay(1000)
    jFrame.Keys("[F4]")
    
#    Delay(4000)
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Navigator*","ExtendedFrame"]
#    Nav_Wind=jFrame.FindChildEx(prop,val,30,True,40000)
    #Nav_Wind.Click()
    #Delay(2000)
    
   
    delay(1000)
    comp_date = ("04-OCT-2019") # Friday
    chk_date = ("05-OCT-2019") # Saturday
    day = "fri"
    rate_fri = self.verify_daily_rate(comp_date,day)
    day = "wknd"
    rate_wknd = self.verify_daily_rate(chk_date,day)
    if rate_fri == rate_wknd:
      Log.Enabled = True
      Log.Message("Daily Rate Validation for Currencies:USD to CAD successful")   
      Log.Message("Friday Rate: "+FloatToStr(rate_fri))
      Log.Message("Weekend Rate: "+FloatToStr(rate_wknd))
      Log.Enabled = False
    else:
      self.log_error_message("Daily Rate Validation for Currencies: USD to CAD Failed")
      Log.Enabled = True
      Log.Message("Friday Rate for USD > CAD: "+FloatToStr(rate_fri))
      Log.Message("Weekend Rate for USD > CAD: "+FloatToStr(rate_wknd)) 
      Log.Enabled = False
#    file_close=jFrame.FindChild(prop,val,30)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~o")
    Delay(1000)
#    self.browser.page("*").Close()   
    web_utils.close_additional_browsers()     
# Navigate to CAI GL ALL SETUP > Currencies > Rates > Daily
 def verify_daily_rate(self,date,day):
    jFrame = Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1)
    if day == "wknd":
#      self.close_forms(jFrame)
      self.wait_until_page_loaded()
      self.page.WaitProperty("contentText","CAI ALL GL SETUP",6000)
      self.page.Find("contentText","CAI ALL GL SETUP",60).click()
      self.wait_until_page_loaded()
      self.page.Find("contentText","Setup",60).click()
      self.wait_until_page_loaded()    
      currencies = self.page.EvaluateXpath("//table[@id='respList']//div[contains(text(),'Currencies')]")[0].scrollIntoView(True)
      delay(1000)
      self.page.EvaluateXpath("//table[@id='respList']//div[contains(text(),'Currencies')]")[0].click()
      self.wait_until_page_loaded()
      self.page.Find("contentText","Rates",30).Click()
      self.wait_until_page_loaded()
      self.page.Find("contentText","Daily",60).click()
      
      
      delay(5000) 
      jFrame=self. initializeJFrame()
      form_utils.click_ok_btn(jFrame)
      delay(1000)
      self.log_message_oracle_form( jFrame,"Navigate again to DL Rates and Validate the Weekend Rate")
    elif day == "fri":
      jFrame.Keys("~f")
      Delay(1000)
      jFrame.Keys("w")
      Delay(3000)
      self.log_message_oracle_form( jFrame,"Switch Responsibility to 'CAI ALL GL SETUP' ") 
      delay(1000)
      prop=["AWTComponentAccessibleName","JavaClassName"]
      val=["Responsibilities","FWindow"]
      resp_form=jFrame.FindChildEx(prop,val,30,True,40000)
      resp_form.Find("AWTComponentName","LWTextField*",10).Click() 
      resp_form.Find("AWTComponentName","LWTextField*",10).keys("CAI ALL GL SETUP")
      self.verify_aqobject_chkproperty(resp_form,"AWTComponentAccessibleName",cmpContains,"Responsibilities")   

    #   resp_form.Keys("~f")
      jFrame.Keys("~f")
      self.log_message_oracle_form( jFrame,"Navigate to GL > SETUP> CURRENCIES> DAILY> RATES")
      jFrame.Keys("s")
      Delay(2000)
      jFrame.Keys("c")
      Delay(2000)
      jFrame.Keys("r")

      Delay(4000)

  #    self.log_message_oracle_form(jFrame,"Navigation Successful : Setup> Currencies > Rates; Click Enter on Daily")

      jFrame.Keys("[Enter]")
    Delay(2000)
    
        
    jFrame.Keys("~v")
    Delay(2000)
    jFrame.Keys("f")
    Delay(2000)
    #____Michael Bennett Update 9/18/2019____#
    self.log_message_oracle_form(jFrame,"Navigation Successful : View > Find")    
    #________________________________________#
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Daily Rates","ExtendedFrame"]
    Find_daily_rates_form=jFrame.FindChildEx(prop,val,30,True,30000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Currency: FromList of Values","VTextField"]
    Find_daily_rates_form.FindChild(prop,val,30).Click()
    Find_daily_rates_form.FindChild(prop,val,30).Keys("USD")
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Currency: ToList of Values","VTextField"]
    Find_daily_rates_form.FindChild(prop,val,30).Click()
    Find_daily_rates_form.FindChild(prop,val,30).Keys("CAD")
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Conversion: From DateList of Values","VTextField"]
    Find_daily_rates_form.FindChild(prop,val,30).Click()
    Find_daily_rates_form.FindChild(prop,val,30).Keys(date)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Conversion: To DateList of Values","VTextField"]
    Find_daily_rates_form.FindChild(prop,val,30).Click()
    Find_daily_rates_form.FindChild(prop,val,30).Keys(date)
#    Find_daily_rates_form.FindChild(prop,val,30).Keys("[Tab]")
    Delay(3000)
    
    #__________________________________#
    #Michael Bennett Changes 8/30/2019
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find alt i","Button"]
    Find_daily_rates_form.FindChild(prop,val,30).Click()
    #_____________________________________________________#
    Delay(3000)
    self.log_message_oracle_form(jFrame,"Daily Rates Details for currency USD > CAD; for date: "+date)  
    prop=["log_message_oracle_form(jFrameAWTComponentAccessibleName","JavaClassName"]
    val=["Daily Rates","ExtendedFrame"]
    daily_rates_form=jFrame.FindChildEx(prop,val,30,True,30000)
    
    prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
    val=["Conversion Rate","VTextField","32"]  
    conv_rates=jFrame.FindChild(prop,val,30)
    conv_rates_num=aqConvert.StrToFloat(conv_rates.wText)
#    rate=VarToFloat(app.Cells.Item[2,4])

    Log.Enabled = True
#    Log.Message("Conversion rate obtained from inbound file for USD to CAD: "+FloatToStr(rate))
    Log.Message("Converison rate for USD to CAD on Date "+date+" is "+FloatToStr(conv_rates_num))
    delay(1000)
    Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications - *", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("ExtendedFrame", "Daily Rates").Close()
#    jFrame.Keys("[F4]")
    self.close_forms(jFrame)
    delay(2000)
    return conv_rates_num

    

    
     
# def req_set_save_Log(self,jFrame,req_form,srch_child_name,Preqid):  
#   
#        #____Michael Bennett Update 9/18/2019____#
##        self.log_message_oracle_form(req_form,"Checking for Child Program")
#        self.log_message_oracle_form(req_form,"Checking for " + srch_child_name)
#        #________________________________________#
#        req_form.keys("~r")
#        i=20
#        for x in range(1,180):     
#            prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#            val=["Name",i]
#            child_name=req_form.Find(prop,val,10).wText 
#            prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#            val=["Phase",i+20]
#            phase=req_form.Find(prop,val,10).wText 
#            prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#            val=["Request ID",i-10]
#            creqid=StrToInt(req_form.Find(prop,val,10).wText)                                         
#            prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#            val=["Status",i+30]
#            index =i+30         
#            status =req_form.FindChild(prop,val,60)            
#            if (child_name==srch_child_name) and (VarToInt(creqid) > VarToInt(Preqid)) and (phase == "Completed"):
#                self.log_message_oracle_form(req_form,"phase Completed Successfuly")            
#                #self.log_message_oracle_form(req_form,"Status"+status+"Status Index" +VarToStr(index)) 
#                self.verify_aqobject_chkproperty(status,"wText",cmpIn,"Normal,Warning")        
#                status.Keys("[Enter]")
#                Delay(6000)
#                prop=["AWTComponentAccessibleName","AWTComponentIndex", "AWTComponentName"]
#                val=["View Log alt K",15,"Button43"]
#                req_form.FindChild(prop,val,10).Click()
##                jFrame.Keys("~g")    
##                jFrame.Keys("~k")
#                Delay(5000)
#                output_page=Sys.Browser("iexplore").Page("https://core-*.epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
#                output_page.Click()
#                screenshot=output_page.PagePicture()
#                if (srch_child_name== "CAI Inbound Global File Validation Program"):
#                  Log.Enabled=True
##                  Log.Message("File Location for Daily Rates File is displayed under 'Program Variable values'")
#                  Log.Picture(screenshot,"File Location for Daily Rates File is displayed under 'Program Variable values'")
#                  Log.Enabled=False
#                  
#                Delay(4000)
#                output_page.Keys("~f")
#                Delay(4000)
#                output_page.Keys("a")
#                Delay(4000)
#                file_system_utils.create_folder(self.op_log_path)             
#                log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"File"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"_%d%b%Y_%H%M")+".txt"    
#                Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
#                Delay(1000)
#                Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
#                Delay(1000)
#                Log.Enabled=True
#                Log.File(log_path, aqConvert.VarToStr(srch_child_name)+" Log File Attached")
#                Log.Enabled=False     
#                Sys.Browser("iexplore").Page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close()
#                Sys.Browser("iexplore").Page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close()
#                Filesaved = 'True'
#                return                           
#            elif i >=25:
#               Delay(20000)
#               #___________________#
#               #Michael Bennett changes 8/30/2019
#               req_form.Click()
#               prop=["AWTComponentAccessibleName","AWTComponentName"]
#               val=["Refresh Data alt R","Button28"]
#               req_form.FindChild(prop,val,60).Click()
#    
#               Delay(3000)
#               i=20
#               val=["Name",i]
#               child_name=req_form.Find(prop,val,10).wText
#    
#            else:  
#               Delay(3000)
#               i=i+1 
#         
#
#                              
##def test():
##  
##    file_system_utils.create_folder(self.exl_inv_files)
##  
##    Stored_session = "opc@stage-fin-iad1-ebsapp1.private.stagefin.oraclevcn.com"
##    local_dir = "C:\\Daily_Import_Files"    
##    remote_dir =  self.winscpConfig[self.testConfig['ebiz']['env']]['remote_dir']+"incoming//ATG_OU//I33"
##    file_name = "FX_EOD_20190830034253.csv"
###prabha________________________________________________Add winscp methods to sort/download prod file
##    winscp.utility.download_file(stored_session,local_dir,remote_dir,file_name)
##    winscp_utility.upload_file(Stored_session,local_dir,remote_dir,upload_file_name)
##    Log.Enabled=True       
##    Log.Message("FX_EOD_"+savetime+".csv file placed WINSCP at //U024//fin_datafiles//incoming//ATG_OU//I33 directory")           
##    Log.Enabled=False  
#    
#def test1():
#    file_exist=aqFileSystem.FindFiles("C:\\Users\\answin\\Documents\\","logfile.log")
#    if file_exist != None:
#     aqFileSystem.DeleteFile("C:\\Users\\answin\\Documents\\logfile.log")
#    log_path = ("C:\\Users\\answin\\Documents\\logfile.log")  





def ISODayOfWeek():
 from datetime import datetime
 from datetime import timedelta
 my_date = datetime.today().weekday()
 friday = datetime.today()-timedelta(days=1)
 page =  Sys.Browser("iexplore").page("*")
