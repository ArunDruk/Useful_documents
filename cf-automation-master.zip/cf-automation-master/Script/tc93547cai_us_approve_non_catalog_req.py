﻿from ebiz import *
import web_utils
#Author:            Prabhakaran Rajendran
#TestCaseID:        TC80901
#UserStoryID:       US188373
#Reviewed_By:       Syed,Husain



class tc93547cai_us_approve_non_catalog_req(Ebiz):
  #declare variables to be used in the methods
  global v, va1, val

  def login(self):
    self.login_user="rmaran"
    super().login()
  #action method to call all sub functions(methods)
  def action(self,book):    
      rowno=2
      sheet_obj = book.Sheets.item["Requisition"]
      RowCount = sheet_obj.UsedRange.Rows.Count
      while rowno<(RowCount+1):
#        val =VarToString(app.cells.Item[rowno,15])
        val =VarToString(sheet_obj.cells.Item[rowno,15])
        if rowno == 2:
          self.nav_appr()
        self.key_data(val)
        self.appr_req(val)
        self.key_data(val)
        self.apprv_val()
#        val = aqConvert.StrToInt(val)+1
        rowno = rowno+1
        delay(1000)
        self.page.EvaluateXpath("//table[@id='AdvancedSearchRegion']//button[@id='ClearButton']")[0].Click()
      delay(2000) 
      self.page.wait_until_page_loaded()
#      self.page.EvaluateXPath("//a[text()='Home']")[0].Click()
      self.page.EvaluateXpath("//table[@id = 'globalHeaderID']//a/div/img[@title = 'Home']")[0].Click()
      self.page.wait()  
      book.save()
#      delay(1000)
#      book.close() 
  
  #method to navigate to 'Status Monitor' to pick requisition pending for approval
  def nav_appr(self):        
      self.page.Find("contentText","Workflow Administrator Web Applications",30).Click()      
      self.page.wait_until_page_loaded()
      self.page.Find("contentText","Administrator Workflow",30).Click()      
      self.page.wait_until_page_loaded()
      self.page.Keys("[Down]")
      delay(2000)
      web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Status Monitor')]")
#      self.page.EvaluateXPath("//table[@id='respList']//li/a[contains(text(),'Status Monitor')]")[0].Click()
      self.page.wait()
      
  #method to query for specific requistion for approval        
  def key_data(self,val):
      self.page.wait_until_page_loaded()
      obj=self.page.EvaluateXpath("//table[@id='AdvancedSearchRegion']//input[@id='WfItemTypeName2']")[0]
      if obj.Exists:
        self.log_checkpoint_message_web("Workflow Status Monitor Page Launched Successfully")
      else:
        self.log_message_web("Unable to Launch Workflow Approval Form")
      
      self.page.EvaluateXpath("//table[@id='AdvancedSearchRegion']//input[@id='WfItemTypeName2']")[0].Click()
      delay(1000)
      self.page.EvaluateXpath("//table[@id='AdvancedSearchRegion']//input[@id='WfItemTypeName2']")[0].Keys("REQAPPRV")
      delay(2000)
      self.page.EvaluateXpath("//table[@id='AdvancedSearchRegion']//input[@id='WfProcessUserKey']")[0].SetText(val)
      delay(2000)
#      self.page.EvaluateXpath("//table[@id='AdvancedSearchRegion']//select[@id='WfProcessStartList']")[0].Click()
#      delay(1000)
      self.page.EvaluateXpath("//table[@id='AdvancedSearchRegion']//select[@id='WfProcessStartList']")[0].ClickItem("Last 2 Weeks")
      delay(2000)
      self.page.EvaluateXpath("//table[@id='AdvancedSearchRegion']//button[@id='GoButton']")[0].Click()      
      self.page.wait_until_page_loaded()
      
  #method to open the workflow activity and to approve the requisition        
  def appr_req(self,val):
      self.page.EvaluateXpath("//table[@id='ResultsRegion']//button[@id = 'WfMonActivitiesCtrl']")[0].Click()
#      self.page.FindChildEx("contentText","Activity History",30,True,50000).Click()
      delay(1000)
      self.page.wait_until_page_loaded()
      self.log_message_web("Reviewing Activity status of the Requisition Workflow") 
      found=False                  
      while found==False:
         self.page.Find("idStr","GoButton",40).Click()
         self.page.wait()
         self.page.Keys("[PageDown]")
         Delay(1000)
         table_obj=self.page.FindChild("idStr","contentDiv:MainRegion.ResultsTable",30)
         i=-1
         while i<10:
            notification_stat=table_obj.Find("Name","Cell("+aqConvert.VarToStr(i+1)+", 5)",30).innerText
            Delay(1000)
            if (notification_stat == 'Open'):
              self.page.Find("idStr","N*:NoticeActivity:"+aqConvert.VarToStr(i+1),30).Click()
              Delay(3000)
              self.page.wait()
              self.page.EvaluateXpath("//table[@id='pgBtnBarTbl']//button[@title='Approve']")[0].Click()      
              self.page.wait()          
              found=True
              break
            elif(notification_stat == 'Closed'): 
              found=True
              break 
            elif i==9:
              self.page.EvaluateXPath("//span[@id='MainRegion.ResultsTable']//table[1]//a[text()='Next 10']")[1].Click()
              self.page.wait()   
              table_obj=self.page.FindChild("idStr","MainRegion.ResultsTable_p13n",30)
              Delay(1000)
              i=0
            else:
              i+=1               
      delay(1000)
      self.page.EvaluateXpath("//form[@id='DefaultFormName']//a[@id='WF_STATUS_MONITOR']")[0].Click()
      delay(1000)
      self.page.wait_until_page_loaded()
      
  def apprv_val(self):    
      var1 = 'Active'
      while var1 != 'Complete':
        self.log_message_web("Workflow in Progress...")
        delay(6000)
        self.page.EvaluateXpath("//table[@id='AdvancedSearchRegion']//button[@id='GoButton']")[0].Click()
        delay(1000)
        self.page.wait()
        var1 = self.page.EvaluateXpath("//div[@id='contentDiv:ResultsTable']//span[@id='N19:WfStatusNoterrText:0']")[0].contentText
      self.log_message_web("Requisition Approval Validated Successfully")


        
