﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils
import winscp_utility


###This testcase is to place the DT_TEST.txt file in the GL inbound directory using WINSCP### 
###and submit CAI Oracle GL Inbound JE Interface Request Set - DT and capture logs and post the journal which got imported into CAI EBIZ###

class tc82962_gl_inbound_je_interface_dt(Ebiz):

 op_log_path="C:\\TC_Logs"
 dt_gl_jrnl_files="C:\\DT_JRNL_Files"
 
 def login(self):
    self.login_user="mfallwell"
    super().login()
 
 
 def action(self,book):
    global jrnl_imp_pro 
    self.modify_dt_journal_details()
    self.place_dt_jrnl_file_winscp()

### Modifying DT_2019.csv file 
 def modify_dt_journal_details(self):
   app = Sys.OleObject["Excel.Application"]
   Delay(1000)
   book = app.Workbooks.Open(Project.Path+"\\DataSheets\\Oracle-GL-Journal\\DT_2019.csv")
   app.Visible = "True"
   app.DisplayAlerts= 0
   app1 = book.Sheets.item["DT_2019"]
   rowno = 2
   self.ref_id = aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%H%M%S")
   self.gl_date = aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%Y%m%d")
   for i in range(0,2):
     app1.Cells.Item[rowno+i,2] = self.ref_id
     i = i+1 
   for j in range(0,2):
     app1.Cells.Item[rowno+j,4] = self.gl_date
     j = j+1 
   file_system_utils.create_folder(self.dt_gl_jrnl_files)
   book.SaveAs("C:\\DT_JRNL_Files\\DT_2019.csv")
   book.close()
   log_path = ("C:\\DT_JRNL_Files\\DT_2019.csv")
   Log.Enabled=True
   Log.File(log_path, "CAI DT Journal Import File Attached")
   Log.Enabled=False 



# Placing DT_2019.csv file in //DAUT2I//incoming//ATG_OU//GL_JE_BALANCES_INTF
 
 def place_dt_jrnl_file_winscp(self):
    Stored_session = "dt_oracle_gl@mftstg.manheim.com"
#    Stored_session = "opc@stage-fin-iad1-ebsapp1.private.stagefin.oraclevcn.com" #"j_autr@ftpnonprodautr.oracleoutsourcing.com"
    local_dir = "C:\\DT_JRNL_Files"   
    remote_dir =  self.testConfig['winscp']['remote_dir']  
#    remote_dir =  self.winscpConfig[self.testConfig['ebiz']['env']]['remote_dir']+"incoming//ATG_OU//GL_JE_BALANCES_INTF"
    upload_file_name = "DT_2019.csv"
    winscp_utility.upload_file(Stored_session,local_dir,remote_dir,upload_file_name)
    Log.Enabled=True       
    Log.Message("DT_2019.csv file placed in the GL_JE_BALANCES_INTF directory")           
    Log.Enabled=False

# Login to Oracle EBIZ and select the responsibility
  
    Log.Message("Inside action...")   
    self.page.WaitProperty("contentText","CAI ALL GL JOB SCHEDULER",6000)
    cai_gl_submit_link=self.page.Find("contentText","CAI ALL GL JOB SCHEDULER",30)
    self.verify_aqobject_chkproperty(cai_gl_submit_link,"contentText",cmpIn,"CAI ALL GL JOB SCHEDULER")
    cai_gl_submit_link.Click() 
    self.log_message_web("Click 'CAI ALL GL JOB SCHEDULER' - Successful")        
    self.page.Wait()    
    cai_gl_submit_link=self.page.NativeWebObject.Find("contentText","Submit Request","A")
    cai_gl_submit_link.Click() 
    self.page.Wait() 
    self.log_message_web("Click 'Submit Request' - Successful") 
    self.page.Wait() 
    jFrame=self.initializeJFrame()
    delay(3000)
    form_utils.click_ok_btn(jFrame)
    Delay(20000)
    jFrame.Keys("~s")
    Delay(3000)
    jFrame.Keys("~o")
    
#   uncomment later 
# Submitting "CAI Oracle GL Inbound JE Interface Request Set - DT" Request Set using CAI ALL GL JOB SCHEDULER' responsibility
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit Request Set","ExtendedFrame"]
    par_form=jFrame.FindChild(prop,val,60)
    par_form.Find("AWTComponentAccessibleName","Request Set RequiredList of Values",30).SetText("CAI Oracle GL Inbound JE Interface Request Set - DT")
    delay(1000)

    par_form=jFrame.FindChild(prop,val,60)
    par_form.Find("AWTComponentAccessibleName","Submit",30).Click()
    form_utils.click_ok_btn(jFrame)    
    self.log_message_oracle_form(jFrame,"CAI Oracle GL Inbound JE Interface Request Set - DT Submitted")   
    RequestID = aqConvert.VarToInt(''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit()))
    Log.Message("Request ID Of  " + aqConvert.VarToStr(RequestID))
    self.log_checkpoint_message_web("Request ID Of CAI Oracle GL Inbound JE Interface Request Set - DT: " + aqConvert.VarToStr(RequestID))
    Delay(2000)
    jFrame.Keys("~n")
    dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
    user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
    pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
    dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,VarToStr(RequestID)) 
    Delay(4000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000)
    
    
# uncomment later
## Gathering Request ID and Output File for the "CAI Oracle GL Inbound JE Interface Program" 
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Requests","ExtendedFrame"]
#    req_form=jFrame.FindChild(prop,val,30)
#    self.req_set_save_output1(jFrame,req_form,"CAI Oracle GL Inbound JE Interface Program",RequestID)
#    jFrame.Click()
#    Delay(2000)
#    
## Gathering Request ID and Output File for the "CAI Oracle Generic GL Preprocessor Program" 
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Requests","ExtendedFrame"]
#    req_form=jFrame.FindChild(prop,val,30)
#    self.req_set_save_output1(jFrame,req_form,"CAI Oracle Generic GL Preprocessor Program",RequestID)
#    jFrame.Click()
#    Delay(2000)
#    
## Gathering Request ID and Log File for the "CAI Global Data Loader" 
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Requests","ExtendedFrame"]
#    req_form=jFrame.FindChild(prop,val,30)
#    self.req_set_save_log1(jFrame,req_form,"CAI Global Data Loader",RequestID)
#    jFrame.Click()
#    Delay(2000)
#    
## Gathering Request ID and Log File for the "CAI File Decrypt Program" 
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Requests","ExtendedFrame"]
#    req_form=jFrame.FindChild(prop,val,30)
#    self.req_set_save_log1(jFrame,req_form,"CAI File Decrypt Program",RequestID)
#    jFrame.Click()
#    Delay(2000)
 
    
# Gathering Request ID and Log File for the "CAI Inbound Global File Validation Program" 
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChild(prop,val,30)
    log_path=self.req_set_save_log1(jFrame,req_form,"CAI Inbound Global File Validation Program",RequestID)
    jFrame.Click()
    Delay(2000)
    
    fo=open(log_path,"r")
    lines=fo.readlines()
    self.log_message_web("The location where the file is copied : - "+lines[26][31:105].strip())
    
    
# Gathering Request ID and Output File for the "CAI Load FDM Mappings Program" 
# uncomment later
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChild(prop,val,30)
    RequestID="27628636" # uncomment later
    self.req_set_save_output1(jFrame,req_form,"CAI Load FDM Mappings Program",RequestID)
    jFrame.Click()
    Delay(2000)
    
    
# CAI Load FDM Mappings Program - O/p
# CAI File Decrypt Program - Log
# CAI Global Data Loader - Log
# CAI Oracle Generic GL Preprocessor Program - o/p


     
## Gathering Request ID and Output File for the "Journal Import Program"  

# uncomment later

    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChild(prop,val,30)
    #logpath_reqid=aqConvert.VarTostr(self.req_set_save_output1(jFrame,req_form,"Journal Import",RequestID)) #req_id_parent=aqConvert.VarTostr(self.req_set_save_output1(jFrame,req_form,"Journal Import",RequestID))
    
    log_path,req_id_parent=self.req_set_save_output1(jFrame,req_form,"Journal Import",RequestID)
    
#    log_path=logpath_reqid[0]
#    req_id_parent=logpath_reqid[1]
    
#    jFrame.Click()
#    Delay(2000)
#    jFrame.Keys("[F4]")
#    Delay(1000)
#    jFrame.Keys("[F4]")
#    Delay(1000)
#    jFrame.Keys("~o")
#    Delay(1000)    

    web_utils.close_additional_browsers() #Sys.Browser("iexplore").page("https://*ebs.coxautoinc.com/forms/frmservlet*").Close() 
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit a New Request alt m","Button"]
    output_button=req_form.FindChild(prop,val,60)
    output_button.Click()
       
    
    # Submitting "Program - Automatic Posting" Request 

    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit Request","ExtendedFrame"]
    par_form=jFrame.FindChildEx(prop,val,60,True,90000)
    delay(1000)
    par_form.FindChild("AWTComponentAccessibleName","Name RequiredList of Values",30).SetText("Program - Automatic Posting")
    delay(2000)
    jFrame.Keys("[Tab]")
    delay(2000)
    jFrame.Keys("ATG GL JEs AUTO-POST")
    delay(1000)
    jFrame.Keys("~o")
    delay(2000)
    par_form.FindChild("AWTComponentAccessibleName","Submit alt m",10).Click()
    Delay(1000)
    self.log_message_oracle_form(jFrame,"Program - Automatic Posting is Submitted")   
    RequestID = aqConvert.VarToInt(''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit()))
    Log.Message("Request ID Of  " + aqConvert.VarToStr(RequestID))
    self.log_checkpoint_message_web("Request ID Of Program - Automatic Posting is " + aqConvert.VarToStr(RequestID))
    Delay(2000)
    jFrame.Keys("~n")
    Delay(35000)
    jFrame.Keys("~v")
    Delay(4000)
    jFrame.Keys("r")
    Delay(4000)
    jFrame.Keys("~i")
    Delay(5000)
    
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Find Requests","ExtendedFrame"]
#    FindRequests_form=jFrame.FindChildEx(prop,val,60,True,20000) 
#    self.log_message_oracle_form(FindRequests_form,"Navigation Successful : View > Request; Clicked Specific request;Find Request Window Opened") 
#                      
#    prop=["JavaClassName","AWTComponentAccessibleName"]
#    val=["VTextField","Request ID"]
#    FindRequests_form.FindChild(prop,val,60).Click()
#    FindRequests_form.FindChild(prop,val,60).Keys(RequestID)
    Delay(2000)

    
#Click Find 
#    jFrame.Keys("~i")
#    Delay(2000)
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Requests","ExtendedFrame"]
#    req_form=jFrame.FindChildEx(prop,val,30,True,60000)
#   
#    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#    val=["Phase",40]
#    phase=req_form.Find(prop,val,10).wText 
#   
#    while phase != "Completed":
#       Delay(1000)
#       req_form.keys("~r")
#       Delay(4000)
#       phase=req_form.Find(prop,val,10).wText 
#    
#    self.log_message_oracle_form(req_form,"Phase Completed Successfuly")
#    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#    val=["Status",50]
#    request_form=jFrame.FindChild(prop,val,30)
#    self.verify_aqobject_chkproperty(request_form,"wSelection",cmpContains,"Normal")
    
    
    dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
    user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
    pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
    dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,VarToStr(RequestID)) 
    self.log_message_oracle_form(par_form," Program - Automatic Posting phase is completed and Status is 'Normal': Click Ouput Button") 
    
    #self.log_message_oracle_form(req_form,"Program - Automatic Posting phase is completed")
#    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#    val=["Status",50]
#    request_form=jFrame.FindChild(prop,val,30)
#    self.verify_aqobject_chkproperty(request_form,"wSelection",cmpContains,"Normal")

#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Requests","ExtendedFrame"]
#    req_form=jFrame.FindChild(prop,val,60)
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["View Output alt p","Button"]
#    output_button=req_form.FindChild(prop,val,60)
#    output_button.Find("AWTComponentAccessibleName","View Output alt p").Click() 
    
#    jFrame.Keys("~p")
#    Delay(4000)
#    log_page=Sys.Browser("iexplore").Page("https://core-*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
#    log_page.Click()
#    log_page.TextNode(0).Click()
#    Delay(3000)
#    log_page.Keys("~f")
#    Delay(3000)
#    log_page.Keys("a")
#    Delay(3000)  
#    file_system_utils.create_folder(self.op_log_path)             
#    log_path=self.op_log_path+"\\Posting_Single Ledger Output File Is Attached_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
#    Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
#    Delay(1000)
#    Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
#    Delay(3000)
#    Log.Enabled=True
#    Log.File(log_path, "Automatic Posting Output File Is Attached")
#    Log.Enabled=False        
#    Delay(1000)
#    web_utils.close_additional_browsers()

    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChild(prop,val,30)
    
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Request ID",40]
    RequestId1=req_form.Find(prop,val,10).wText
    
    dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
    user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
    pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
    dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,VarToStr(RequestId1)) 
    
    # Uncomment below later
    #self.req_set_save_output1(jFrame,req_form,"Program - Automatic Posting",RequestID)
    #jFrame.Click()
    
    # Finding a Journal posted and getting the screenshot of the same
    fo=open(log_path,"r")
    lines=fo.readlines()
    self.log_message_web("Journal Imported Batch Name is : - "+lines[17][8:33].strip())
    batch_name = lines[17][8:33].strip()
    
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~o")
    Delay(1000)      
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI ALL GL JOURNAL PROCESSING')]")
    self.log_message_web("Click 'CAI ALL GL JOURNAL PROCESSING' - Successful")
#     web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//li/a[contains(text(),'CAI ALL GL JOURNAL PROCESSING')]")
    Delay(3000)
    self.page.EvaluateXpath("//table[@id='respList']//div[text()='Enter Journals']")[0].Click()
    self.log_message_web("Click 'Enter Journals'- Successful")
#     web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//li/a[contains(text(),'Enter Journals')]")
    web_utils.validate_security_box()
    Delay(20000)
    jFrame=self.initializeJFrame()
    Delay(8000)
#     jFrame.Keys("~o")
    form_utils.click_ok_btn(jFrame)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Journals","ExtendedFrame"]
    #j_req_id = app.Cells.Item[2,14]
    fnd_jrnl=jFrame.FindChildEx(prop,val,60,True,90000)
    fnd_jrnl.Find("AWTComponentAccessibleName","BatchList of Values",10).Click()
    fnd_jrnl.Find("AWTComponentAccessibleName","BatchList of Values",10).Keys("%"+VarToStr(req_id_parent)+"%")
    delay(1000) 
    jFrame.Keys("~i")
    self.log_message_oracle_form(jFrame,VarToStr(req_id_parent)+"- find Journal Successful")
    delay(8000) 
    jFrame.Keys("~u")
    delay(4000) 
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Journals (CAI ALL LEDGERS)*","ExtendedFrame"]
    jrnls=jFrame.FindChildEx(prop,val,60,True,60000)
    jrnls.FindChild("AWTComponentName","FormsTabPanel*",60).ClickTab("Other Information")

    Log.Enabled=False
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Status: Posting",0]
    jrnl_val = jFrame.FindChild(prop,val,60)
    jrnl_status=jrnl_val.wText  
    self.log_message_oracle_form(jFrame,"Journal Status: "+jrnl_status)   
    Log.Enabled=True
    aqObject.CheckProperty(jrnl_val,"wText",cmpIn,"Posted")
    Log.Enabled=False
    self.log_message_oracle_form(jFrame,VarToStr(req_id_parent)+" Journal is Posted")
    delay(4000) 
    jrnls.FindChild("AWTComponentName","FormsTabPanel*",60).ClickTab("Lines")
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Journals (CAI ALL LEDGERS)*","ExtendedFrame"]
    jrnls=jFrame.FindChildEx(prop,val,30,True,60000)
    prop=["JavaClassName","AWTComponentIndex"]
    val=["LWScrollbar","0"]
    down_button=jrnls.FindChildEx(prop,val,30,True,60000)
    for i in range(0,10):
      prop=["JavaClassName","AWTComponentIndex"]
      val=["ContinuousButton","0"]
      down_button.Find(prop,val,20).Click()  
    self.log_message_oracle_form(jFrame,"Intracompany balancing line added by Posting in "+VarToStr(req_id_parent))
    delay(4000) 
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~o")
    Delay(1000)    
    
# #
# Navigating back to view requests

    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000)


        
# Gathering Request ID and Output File for the "Posting: Single Ledger program"  
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChild(prop,val,30)
    
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Request ID",40]
    RequestId1=req_form.Find(prop,val,10).wText
    
    dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
    user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
    pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
    dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,VarToStr(RequestId1)) 
    
    # Navigating back to view requests

    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000)


    
    
    #RequestID="27624283" # Comment later
    self.req_set_save_output1(jFrame,req_form,"Posting: Single Ledger",RequestID)
    Delay(1000)
    dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
    user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
    pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
    dbhelper.verify_journal_import_details(dsn,user_id,pwd,"%"+VarTostr(req_id_parent))
    Delay(1000)
    jFrame.Click()
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~o")
    Delay(1000)    
    web_utils.close_additional_browsers() #Sys.Browser("iexplore").page("https://*ebs.coxautoinc.com/forms/frmservlet*").Close()
    
      
    
    
 def req_set_save_output1(self,jFrame,req_form,srch_child_name,Preqid):
     i=20
     prop=["AWTComponentAccessibleName","AWTComponentIndex"]
     val=["Request ID",i-10] 
     creqid=VarToInt(req_form.Find(prop,val,10).wText)
              
              
     for x in range(i,50):
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Name",x]
        child_name=req_form.Find(prop,val,10)
        child_name.Keys("[Enter]")
        child_name.Click()
        child_name=child_name.wText
        
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Phase",i+20]
        phase=req_form.Find(prop,val,10).wText 
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Request ID",i-10]
        creqid=VarToInt(req_form.Find(prop,val,10).wText) 
        
                            
        if x>20:
           jFrame.Keys("[Down]") 
           
           Delay(1000)
           prop=["AWTComponentAccessibleName","AWTComponentIndex"]
           val=["Phase",i+20]
           phase=req_form.Find(prop,val,10).wText 
           prop=["AWTComponentAccessibleName","AWTComponentIndex"]
           val=["Request ID",i-10]
           creqid=VarToInt(req_form.Find(prop,val,10).wText)
           
  # Check and uncomment later               
#        if (child_name=="Journal Import"): # (child_name=="Posting: Single Ledger") or (child_name=="Program - Automatic Posting")
#        
#          while(phase!="Completed"):
#            prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#            val=["Phase",i+20]
#            phase=req_form.Find(prop,val,10).wText 
#            delay(10000)
#            prop=["AWTComponentAccessibleName","JavaClassName"]
#            val = ["Refresh Data alt R","Button"]
#            req_form.FindChild(prop,val,2000).Click()
#
##            prop=["AWTComponentAccessibleName","AWTComponentIndex"]
##            val=["Phase",i+20]
##            Request_Id1=req_form.Find(prop,val,10).wText 
#            

                          
           
        if (child_name==srch_child_name) and (creqid >= VarToInt(Preqid)): # and (phase == "Completed")
                   
          Delay(600)
          prop=["AWTComponentAccessibleName","JavaClassName"]
          val=["View Output alt p","Button"]
          output_button=req_form.FindChild(prop,val,60)
          output_button.Find("AWTComponentAccessibleName","View Output alt p").Click()         
          #jFrame.Keys("~p")    
          Delay(3000)
          output_page=Sys.Browser("iexplore").Page("https://core-*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")            
          output_page.Click()
          Delay(2000)
          output_page.Keys("~f")
          Delay(6000)
          output_page.Keys("a")
          Delay(6000)
          file_system_utils.create_folder(self.op_log_path)             
          log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"Is Attached_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
          Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
          Delay(1000)
          Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
          Delay(2000)
          Log.Enabled=True
          Log.File(log_path, aqConvert.VarToStr(srch_child_name)+" is completed and Output File Is Attached")
          Log.Enabled=False       
          Sys.Browser("iexplore").page("https://core-*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close()  
          Delay(2000)   
 #         jFrame.Click()
          Delay(2000)
          val=["Name",20]
          req_form.Find(prop,val,10).Keys("[Enter]")
          Delay(500)
          if (srch_child_name=="Journal Import"): # Returning the Log path for the screenshot of Journal created
            return log_path,creqid
          return creqid
          break 
        elif i >=28:
           Delay(20000)
           prop=["AWTComponentAccessibleName","JavaClassName"]
           val = ["Refresh Data alt R","Button"]
           req_form.FindChild(prop,val,2000).Click()

           Delay(3000)
           i=20
           val=["Name",i]
           child_name=req_form.Find(prop,val,10).wText 

           
 def req_set_save_log1(self,jFrame,req_form,srch_child_name,Preqid):
      i=20
      for x in range(i,50):
         prop=["AWTComponentAccessibleName","AWTComponentIndex"]
         val=["Name",x]
         child_name=req_form.Find(prop,val,10)
         child_name.Keys("[Enter]")
         child_name.Click()
         child_name=child_name.wText
            
         if x>20:
            jFrame.Keys("[Down]")             
            Delay(1000)
            prop=["AWTComponentAccessibleName","AWTComponentIndex"]
            val=["Phase",i+20]
            phase=req_form.Find(prop,val,10).wText 
            prop=["AWTComponentAccessibleName","AWTComponentIndex"]
            val=["Request ID",i-10]
            creqid=VarToInt(req_form.Find(prop,val,10).wText)     
         if (child_name==srch_child_name) and (creqid >= VarToInt(Preqid)) and (phase == "Completed"):
           Delay(600)
           prop=["AWTComponentAccessibleName","JavaClassName"]
           val=["View Log alt K","Button"]
           req_form.FindChild(prop,val,60).Click()
           Delay(3000)
           output_page=Sys.Browser("iexplore").Page("https://core-*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")            
           output_page.Click()
           Delay(2000)
           output_page.Keys("~f")
           Delay(6000)
           output_page.Keys("a")
           Delay(6000)
           file_system_utils.create_folder(self.op_log_path)             
           log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"Is Attached_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
           Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
           Delay(1000)
           Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
           Delay(2000)
           Log.Enabled=True
           Log.File(log_path, aqConvert.VarToStr(srch_child_name)+" Program is completed and Output File Is Attached")
           Log.Enabled=False       
           Sys.Browser("iexplore").page("https://core-*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close()  
           Delay(2000)   
  #         jFrame.Click()
           Delay(2000)
           val=["Name",20]
           req_form.Find(prop,val,10).Keys("[Enter]")
           Delay(500)
           if (srch_child_name=="CAI Inbound Global File Validation Program"): #or (srch_child_name=="CAI Inbound Global File Validation Program"): # Returning the Log path for the screenshot of Journal created
            return log_path
           break  


 def req_set_save_log(self,jFrame,req_form,srch_child_name,Preqid):
    self.log_message_oracle_form(req_form,"Checking for Child Program")
    req_form.keys("~r")
    i=20
    for x in range(1,180):     
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Name",i]
        child_name=req_form.Find(prop,val,10).wText 
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Phase",i+20]
        phase=req_form.Find(prop,val,10).wText 
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Request ID",i-10]
        creqid=VarToInt(req_form.Find(prop,val,10).wText)
#        self.log_message_oracle_form(req_form,"Request ID of "+aqConvert.VarToStr(srch_child_name)+" is "+aqConvert.VarToStr(creqid))                                         
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Status",i+30]         
        status =req_form.FindChild(prop,val,60)            
        if (child_name==srch_child_name) and (creqid>=Preqid) and (phase == "Completed"):
            self.log_message_oracle_form(req_form,"phase Completed Successfuly")            
#            self.verify_aqobject_chkproperty(status,"wText",cmpContains,"Normal")        
            status.Keys("[Enter]")
            Delay(1000)
            jFrame.Keys("~g")    
            Delay(3000)
            output_page=Sys.Browser("iexplore").Page(self.testConfig['ebiz']['url']+"/OA_CGI/FNDWRR.exe?*")
            output_page.Click()
            Delay(2000)
            output_page.Keys("~f")
            Delay(2000)
            output_page.Keys("a")
            Delay(5000)
            file_system_utils.create_folder(self.op_log_path)             
            log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"File"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"_%d%b%Y_%H%M")+".txt"    
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
            Delay(1000)
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
            Delay(2000)
            Log.Enabled=True
            Log.File(log_path, aqConvert.VarToStr(srch_child_name)+" Output File Attached")
            Log.Enabled=False     
            Sys.Browser("iexplore").Page("https://*ebs.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close()
            Filesaved = 'True'
            return                           
        elif i >=28:
           Delay(20000)
           req_form.keys("~r")

           Delay(3000)
           i=20
           val=["Name",i]
           child_name=req_form.Find(prop,val,10).wText

        else:  
           Delay(3000)
           i=i+1 







#from dbhelper import *
#from ebiz import *
#import dbhelper
#import file_system_utils
#import winscp_utility
#
#
####This testcase is to place the DT_TEST.txt file in the GL inbound directory using WINSCP### 
####and submit CAI Oracle GL Inbound JE Interface Request Set - DT and capture logs and post the journal which got imported into CAI EBIZ###
#
#class tc82962_gl_inbound_je_interface_dt(Ebiz):
#
# op_log_path="C:\\TC_Logs"
# dt_gl_jrnl_files="C:\\DT_JRNL_Files"
# 
# def login(self):
#    self.login_user="mfallwell"
#    super().login()
# 
# 
# def action(self,book):
#    global jrnl_imp_pro 
#    self.modify_dt_journal_details()
#    self.place_dt_jrnl_file_winscp()
#
#### Modifying DT_2019.csv file 
# def modify_dt_journal_details(self):
#   app = Sys.OleObject["Excel.Application"]
#   Delay(1000)
#   book = app.Workbooks.Open(Project.Path+"\\DataSheets\\Oracle-GL-Journal\\DT_2019.csv")
#   app.Visible = "True"
#   app.DisplayAlerts= 0
#   app1 = book.Sheets.item["DT_2019"]
#   rowno = 2
#   self.ref_id = aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%H%M%S")
#   self.gl_date = aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%Y%m%d")
#   for i in range(0,2):
#     app1.Cells.Item[rowno+i,2] = self.ref_id
#     i = i+1 
#   for j in range(0,2):
#     app1.Cells.Item[rowno+j,4] = self.gl_date
#     j = j+1 
#   file_system_utils.create_folder(self.dt_gl_jrnl_files)
#   book.SaveAs("C:\\DT_JRNL_Files\\DT_2019.csv")
#   book.close()
#   log_path = ("C:\\DT_JRNL_Files\\DT_2019.csv")
#   Log.Enabled=True
#   Log.File(log_path, "CAI DT Journal Import File Attached")
#   Log.Enabled=False 
#
#
#
## Placing DT_2019.csv file in //DAUT2I//incoming//ATG_OU//GL_JE_BALANCES_INTF
# 
# def place_dt_jrnl_file_winscp(self):
#    Stored_session = "opc@stage-fin-iad1-ebsapp1.private.stagefin.oraclevcn.com" #"j_autr@ftpnonprodautr.oracleoutsourcing.com"
#    local_dir = "C:\\DT_JRNL_Files"    
#    remote_dir =  self.winscpConfig[self.testConfig['ebiz']['env']]['remote_dir']+"incoming//ATG_OU//GL_JE_BALANCES_INTF"
#    upload_file_name = "DT_2019.csv"
#    winscp_utility.upload_file(Stored_session,local_dir,remote_dir,upload_file_name)
#    Log.Enabled=True       
#    Log.Message("DT_2019.csv file placed in the GL_JE_BALANCES_INTF directory")           
#    Log.Enabled=False
#
## Login to Oracle EBIZ and select the responsibility
#      
#    self.page.WaitProperty("contentText","CAI ALL GL JOB SCHEDULER",6000)
#    cai_gl_submit_link=self.page.NativeWebObject.Find("contentText","CAI ALL GL JOB SCHEDULER","A")
#    self.verify_aqobject_chkproperty(cai_gl_submit_link,"contentText",cmpIn,"CAI ALL GL JOB SCHEDULER")
#    cai_gl_submit_link.Click() 
#    Delay(2000)
#    self.log_message_web("Click 'CAI ALL GL JOB SCHEDULER' - Successful")        
#    self.page.Wait()
#    self.page.NativeWebObject.Find("contentText","Submit Request","A").Click()
#    self.log_message_web("Click 'Submit Request' - Successful") 
#    jFrame=self.initializeJFrame()
#    delay(3000)
#    form_utils.click_ok_btn(jFrame)    
#    Delay(20000)
#    jFrame.Keys("~s")
#    Delay(1000)
#    jFrame.Keys("~o")   
#    
#    
## Submitting "CAI Oracle GL Inbound JE Interface Request Set - DT" Request Set using CAI ALL GL JOB SCHEDULER' responsibility
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Submit Request Set","ExtendedFrame"]
#    par_form=jFrame.FindChild(prop,val,60)
#    par_form.Find("AWTComponentAccessibleName","Request Set RequiredList of Values",30).Keys("CAI Oracle GL Inbound JE Interface Request Set - DT")
#    delay(1000)
#    jFrame.Keys("[Tab]")
#    delay(1000)
#    par_form=jFrame.FindChild(prop,val,60)
#    par_form.Find("AWTComponentAccessibleName","Submit",30).Click()
#    form_utils.click_ok_btn(jFrame)    
#    Delay(1000)
#    self.log_message_oracle_form(jFrame,"CAI Oracle GL Inbound JE Interface Request Set - DT Submitted")   
#    RequestID = aqConvert.VarToInt(''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit()))
#    Log.Message("Request ID Of  " + aqConvert.VarToStr(RequestID))
#    self.log_checkpoint_message_web("Request ID Of CAI Oracle GL Inbound JE Interface Request Set - DT " + aqConvert.VarToStr(RequestID))
#    Delay(2000)
#    jFrame.Keys("~n")
#    dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
#    user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
#    pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
#    dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,VarToStr(RequestID)) 
#    Delay(4000)
#    jFrame.Keys("~v")
#    Delay(1000)
#    jFrame.Keys("r")
#    Delay(1000)
#    jFrame.Keys("~i")
#    Delay(1000) 
#    
## Gathering Request ID and Output File for the "CAI Inbound Global File Validation Program"   
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Requests","ExtendedFrame"]
#    req_form=jFrame.FindChildEx(prop,val,30,True,90000)
#    self.req_set_save_log1(jFrame,req_form,"CAI Inbound Global File Validation Program",RequestID)
#    jFrame.Click()
#    Delay(2000)
#
#    
## Gathering Request ID and Output File for the "CAI Oracle GL Inbound JE Interface Program"  
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Requests","ExtendedFrame"]
#    req_form=jFrame.FindChildEx(prop,val,30,True,60000)
#    self.req_set_save_output1(jFrame,req_form,"CAI Oracle GL Inbound JE Interface Program",RequestID)
#    jFrame.Click()
#    Delay(2000)
#
#
## Gathering Request ID and Output File for the "Journal Import Program"  
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Requests","ExtendedFrame"]
#    req_form=jFrame.FindChild(prop,val,30)
#    req_id_parent=aqConvert.VarTostr(self.req_set_save_output1(jFrame,req_form,"Journal Import",RequestID))
#    jFrame.Click()
#    Delay(2000)
#    jFrame.Keys("[F4]")
#    Delay(1000)
#    jFrame.Keys("[F4]")
#    Delay(1000)
#    jFrame.Keys("~o")
#    Delay(1000)    
#    web_utils.close_additional_browsers() #Sys.Browser("iexplore").page("https://*ebs.coxautoinc.com/forms/frmservlet*").Close()
#
#    
##Switch the responsibility to CAI ALL GL SETUP
#    cai_gl_setup_link=self.page.NativeWebObject.Find("contentText","CAI ALL GL SETUP","A")
#    self.verify_aqobject_chkproperty(cai_gl_setup_link,"contentText",cmpIn,"CAI ALL GL SETUP")
#    cai_gl_setup_link.Click() 
#    self.log_message_web("Click 'CAI ALL GL SETUP' - Successful") 
#    self.page.Keys("[Down]") 
#    self.page.Keys("[Down]")  
#    delay(2000)     
#    
#    cai_journal_link=self.page.NativeWebObject.Find("contentText","Journals","A")
#    self.verify_aqobject_chkproperty(cai_journal_link,"contentText",cmpIn,"Journals")
#    cai_journal_link.Click() 
#    self.log_message_web("Click Journals - Successful") 
#    delay(2000)    
#    self.page.Keys("[Down]")
#    self.page.Keys("[Down]")
#    self.page.EvaluateXpath("//table[@id='mainMenuRegion']//div[text()='Enter']")[0].Click() #self.page.Find("namePropStr","RF.jsp?function_id=616&resp_id=50678&resp_appl_id=101&security_group_id=0&lang_code=US')",30).Click()
#    self.log_message_web("Click Enter Journals - Successful")
#    Delay(5000)
#    jFrame=self.initializeJFrame()
#    Delay(7000)
#    form_utils.click_ok_btn(jFrame)
#    delay(12000)  
#    
## Finding Journal which was imported and post the Journal
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Find Journals","ExtendedFrame"]
#    jFrame=self.initializeJFrame()
#    Delay(6000)
##    jFrame=Sys.Browser("iexplore").SwingObject("JBufferedFrame", "*", -1, 1)
#    fnd_jrnl=jFrame.FindChildEx(prop,val,60,True,90000)
#    fnd_jrnl.Find("AWTComponentAccessibleName","BatchList of Values",10).Click()
#    fnd_jrnl.Find("AWTComponentAccessibleName","BatchList of Values",10).SetText("%"+req_id_parent+"%")
#    delay(1000) 
#    jFrame.Keys("~i")
#    self.log_message_oracle_form(jFrame,"Find Journal Successful")
#    delay(4000) 
#    jFrame.Keys("~u")
#    delay(3000) 
#    jFrame.Keys("~p")
#    delay(3000)
#    jFrame.Keys("~o") 
#    Delay(3000)
#    jFrame.Keys("[F4]")
#    Delay(1000)
#    jFrame.Keys("~v")
#    Delay(1000)
#    jFrame.Keys("r")
#    Delay(1000)
#    jFrame.Keys("~i")
#    Delay(1000)
#
## Gathering Request ID and Output File for the "Posting: Single Ledger program" 
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Requests","ExtendedFrame"]
#    req_form=jFrame.FindChildEx(prop,val,30,True,90000)
#    self.req_set_save_output1(jFrame,req_form,"Posting: Single Ledger",RequestID)
#    Delay(1000)
#    dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
#    user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
#    pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
#    dbhelper.verify_journal_import_details(dsn,user_id,pwd,"%"+VarTostr(req_id_parent))
#    Delay(1000)
#    jFrame.Click()
#    Delay(1000)
#    jFrame.Keys("[F4]")
#    Delay(1000)
#    jFrame.Keys("[F4]")
#    Delay(1000)
#    jFrame.Keys("~o")
#    Delay(1000)    
#    web_utils.close_additional_browsers()#Sys.Browser("iexplore").page("https://*ebs.coxautoinc.com/forms/frmservlet*").Close()
#     
#
# def req_set_save_output1(self,jFrame,req_form,srch_child_name,Preqid):
#      i=20
#      prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#      val=["Request ID",i-10] 
#      creqid=VarToInt(req_form.Find(prop,val,10).wText)
#               
#               
#      for x in range(i,50):
#         prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#         val=["Name",x]
#         child_name=req_form.Find(prop,val,10)
#         child_name.Keys("[Enter]")
#         child_name.Click()
#         child_name=child_name.wText
#         
#         prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#         val=["Phase",i+20]
#         phase=req_form.Find(prop,val,10).wText 
#         prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#         val=["Request ID",i-10]
#         creqid=VarToInt(req_form.Find(prop,val,10).wText) 
#         
#                             
#         if x>20:
#            jFrame.Keys("[Down]") 
#            
#            Delay(1000)
#            prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#            val=["Phase",i+20]
#            phase=req_form.Find(prop,val,10).wText 
#            prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#            val=["Request ID",i-10]
#            creqid=VarToInt(req_form.Find(prop,val,10).wText)
#            
#                
#         if (child_name=="Posting: Single Ledger") or (child_name=="Journal Import"):
#           
#           while(phase!="Completed"):
#             prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#             val=["Phase",i+20]
#             phase=req_form.Find(prop,val,10).wText 
#             delay(10000)
#             prop=["AWTComponentAccessibleName","JavaClassName"]
#             val = ["Refresh Data alt R","Button"]
#             req_form.FindChild(prop,val,2000).Click()
#               
#            
#         if (child_name==srch_child_name) and (creqid >= VarToInt(Preqid)) and (phase == "Completed"):
#                    
#           Delay(600)
#           prop=["AWTComponentAccessibleName","JavaClassName"]
#           val=["View Output alt p","Button"]
#           output_button=req_form.FindChild(prop,val,60)
#           output_button.Find("AWTComponentAccessibleName","View Output alt p").Click()         
#           #jFrame.Keys("~p")    
#           Delay(3000)
#           output_page=Sys.Browser("iexplore").Page("https://core-*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")            
#           output_page.Click()
#           Delay(2000)
#           output_page.Keys("~f")
#           Delay(6000)
#           output_page.Keys("a")
#           Delay(6000)
#           file_system_utils.create_folder(self.op_log_path)             
#           log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"Is Attached_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
#           Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
#           Delay(1000)
#           Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
#           Delay(2000)
#           Log.Enabled=True
#           Log.File(log_path, aqConvert.VarToStr(srch_child_name)+" Program is completed and Output File Is Attached")
#           Log.Enabled=False       
#           Sys.Browser("iexplore").page("https://core-*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close()  
#           Delay(2000)   
#  #         jFrame.Click()
#           Delay(2000)
#           val=["Name",20]
#           req_form.Find(prop,val,10).Keys("[Enter]")
#           Delay(500)
#           return creqid
#           break 
#         elif i >=28:
#            Delay(20000)
#            prop=["AWTComponentAccessibleName","JavaClassName"]
#            val = ["Refresh Data alt R","Button"]
#            req_form.FindChild(prop,val,2000).Click()
# 
#            Delay(3000)
#            i=20
#            val=["Name",i]
#            child_name=req_form.Find(prop,val,10).wText 
#
# def req_set_save_log1(self,jFrame,req_form,srch_child_name,Preqid):
#      i=20
#      for x in range(i,50):
#         prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#         val=["Name",x]
#         child_name=req_form.Find(prop,val,10)
#         child_name.Keys("[Enter]")
#         child_name.Click()
#         child_name=child_name.wText
#            
#         if x>20:
#            jFrame.Keys("[Down]") 
#            
#            Delay(1000)
#            prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#            val=["Phase",i+20]
#            phase=req_form.Find(prop,val,10).wText 
#            prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#            val=["Request ID",i-10]
#            creqid=VarToInt(req_form.Find(prop,val,10).wText)     
#         if (child_name==srch_child_name) and (creqid >= VarToInt(Preqid)) and (phase == "Completed"):
#  #         Delay(500)
#  #         req_form.Find(prop,val,10).Keys("[Enter]")
#           Delay(600)
#           prop=["AWTComponentAccessibleName","JavaClassName"]
#           val=["View Log alt K","Button"]
#           req_form.FindChild(prop,val,60).Click()
#           #output_button.Find("AWTComponentAccessibleName","View Output alt p").Click()         
#           #jFrame.Keys("~p")    
#           Delay(3000)
#           output_page=Sys.Browser("iexplore").Page("https://core-*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")            
#           output_page.Click()
#           Delay(2000)
#           output_page.Keys("~f")
#           Delay(6000)
#           output_page.Keys("a")
#           Delay(6000)
#           file_system_utils.create_folder(self.op_log_path)             
#           log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"Is Attached_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
#           Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
#           Delay(1000)
#           Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
#           Delay(2000)
#           Log.Enabled=True
#           Log.File(log_path, aqConvert.VarToStr(srch_child_name)+" Program is completed and Output File Is Attached")
#           Log.Enabled=False       
#           Sys.Browser("iexplore").page("https://core-*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close()  
#           Delay(2000)   
#  #         jFrame.Click()
#           Delay(2000)
#           val=["Name",20]
#           req_form.Find(prop,val,10).Keys("[Enter]")
#           Delay(500)
#           break  
#           
#def sample():
#    jFrame=Sys.Process("jp2launcher").WaitSwingObject("JFrame", "Oracle Applications*", -1,1,90000)
#    jFrame.Keys("~s")
#    Delay(1000)
#    jFrame.Keys("~o")  
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Submit Request Set","ExtendedFrame"]
#    par_form=jFrame.FindChild(prop,val,60)
#
#    
#    
#    
#    
#
# 
#    
