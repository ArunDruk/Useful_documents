﻿import configparser
import file_system_utils
import wcc_login_page_v12
import wcc_home_page_v12
import os
import web_utils
from dbhelper import *
import webcentercapture_V12


class capture_singlepage_po_invoice_scan_ca_v12(Webcentercapture_V12):

 def goto_url(self,url):
  pass
   
 def action(self,book):
   
  app = book.Sheets.item["wci_capture"] 
  
  file_system_utils.create_folder("C:\\TC_Logs")
  src_folder=Project.Path+"DataSheets\\WCI\\"
  
  #close all open sessions and make current session active  
  Webcentercapture_V12.use_current_session()
  
  #Get location and set the key for searching the batches
  location = VarToStr(app.Cells.item[2,2]).split("-")[0]
  ocr_key = aqString.SubString(location,0,2)
  Webcentercapture_V12.set_entity_based_on_location(location)
  Delay(3000)
  
  #verify whether the batch_list frame exists
  Webcentercapture_V12.verify_batch_list_frame()
  Delay(5000)
  
  #Click on capture
  wcc_home_page_v12.capture_button().Click()
  self.log_checkpoint_message_web("Clicked on capture button successfully")
  Delay(4000) 
 
   # Click on Import OK button
  if wcc_home_page_v12.import_wdw().Exists:
    wcc_home_page_v12.import_wdw_ok_button().Click()
  

#  # Clicking on parent folder button
#  Sys.Process("capture").SwingObject("FileImportDialog", "Select files to import", -1, 1).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("filechooser").SwingObject("JPanel", "", 0).SwingObject("JPanel", "", 0).SwingObject("JButton", "Up", 0).Click()
#  delay(1000)
#  Sys.Process("capture").SwingObject("FileImportDialog", "Select files to import", -1, 1).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("filechooser").SwingObject("JPanel", "", 0).SwingObject("JPanel", "", 0).SwingObject("JButton", "Up", 0).Click()
#  delay(1000)
#  Sys.Process("capture").SwingObject("FileImportDialog", "Select files to import", -1, 1).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("filechooser").SwingObject("JPanel", "", 0).SwingObject("JPanel", "", 0).SwingObject("JButton", "Up", 0).Click()
#  delay(1000)
#  Sys.Process("capture").SwingObject("FileImportDialog", "Select files to import", -1, 1).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("filechooser").SwingObject("JPanel", "", 0).SwingObject("JPanel", "", 0).SwingObject("JButton", "Up", 0).Click()
#  delay(1000)
  
    # Select file 
  file_path=src_folder+VarToStr(app.Cells.item[2,4])
  Sys.Process("capture").SwingObject("FileImportDialog", "Select files to import", -1, 1).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("filechooser").SwingObject("JPanel", "", 2).SwingObject("JPanel", "", 0).SwingObject("SynthFileChooserUIImpl$3", "File name:", 0).SetText(file_path)
  self.log_checkpoint_message_web("Entered file name to be imported")
  # Click on file name and Ok button
  Sys.Process("capture").SwingObject("FileImportDialog", "Select files to import", -1, 1).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("filechooser").SwingObject("JPanel", "", 2).SwingObject("JPanel", "", 0).SwingObject("SynthFileChooserUIImpl$3", "File name:", 0).Click()
  delay(2000)
  #Sys.Process("capture").SwingObject("FileImportDialog", "Select files to import", -1, 1).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("JPanel", "", 0).SwingObject("btnFileImportOk").Click()
  Sys.Process("capture").SwingObject("FileImportDialog", "Select files to import", -1, 1).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("filechooser").SwingObject("JPanel", "", 2).SwingObject("JPanel", "", 0).SwingObject("SynthFileChooserUIImpl$3", "File name:", 0).Keys("[Enter]")
 # self.refresh()
  delay(2000)
  ###### 
  
    # Uncomment later

 
  self.refresh()
  delay(13000) # Wait till the page loads
  
  #Drag the scroll bar up 
  Sys.Process("capture").SwingObject("RMCMain", "Oracle WebCenter Enterprise Capture - Connected to https://core-capture-dev.epfinnp.coxautoinc.com", 0).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("FormManagerPanel", "", 0).SwingObject("JPanel", "", 2).SwingObject("JPanel", "", 0).SwingObject("BatchEditForm", "", 0).SwingObject("JSplitPane", "", 0).SwingObject("JPanel", "", 0).SwingObject("JSplitPane", "", 0).SwingObject("JPanel", "", 1).SwingObject("JScrollPane", "", 0).SwingObject("JScrollPane$ScrollBar", "", 0).Keys("[PageUp][PageUp][PageUp]")   #Drag(25,255,55,55)
 
  OCR.Recognize(batch_list).BlockByText(ocr_key, spTopMost).Click() # OCR.Recognize(batch_list).BlockByText(ocr_key, spBottomMost).Click()
     
  prop_names = ["AWTComponentAccessibleName","JavaClassName","JavaFullClassName"] 
  prop_values = ["Batch Name:","JTextField","javax.swing.JTextField"] 
  
  batch_name = capture_window.FindChildEx(prop_names,prop_values,30,True,90000).wText 
  #app.Cells.item[2,2]=VarToStr(batch_name)
  
  
  
#  while batch_name.Exists == None: 
#      OCR.Recognize(batch_list).BlockByText(ocr_key, spTopMost).Click()
#      i = i + 1
#      if i == 4:
#        self.log_error_message("Unable to Find Details for the Selected Batch")
 
  # uncomment later
  #Sys.Process("capture").SwingObject("RMCMain", "Oracle WebCenter Enterprise Capture - Connected to https://core-capture-dev.epfinnp.coxautoinc.com", 0).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("FormManagerPanel", "", 0).SwingObject("JPanel", "", 2).SwingObject("JPanel", "", 0).SwingObject("BatchEditForm", "", 0).SwingObject("JSplitPane", "", 0).SwingObject("JPanel", "", 1).SwingObject("JPanel", "", 0).SwingObject("BatchInfoPanel", "", 0).SwingObject("JPanel", "", 3).Click()
  batch_list.Keys("[Right][Right]")
#  self.wait_until_page_loaded()
  Delay(10000)
  prop_names = ["AWTComponentIndex","JavaClassName","JavaFullClassName"]
  prop_values = [0,"ImageViewer","oracle.odc.imageviewer.ImageViewer"]
  ImageViewer =  capture_window.FindChildEx(prop_names,prop_values,30,True,120000)
  value = ImageViewer.VisibleOnScreen
  document_no = 1
  
  while value == True:
  #      self.wait_until_page_loaded()
        Delay(5000)
        key = "APINV"
        self.validate_doc_panel(document_no,app,key)
        delay(2000)
        batch_list.Keys("[Down]")
        Delay(7000)
        document_no = document_no+1
        value = ImageViewer.VisibleOnScreen
  
  #self.validate_doc_panel(document_no,book)
  if value == False and VarToStr(app.Cells.item[2,9]) == "Yes":
      cnt=0
      while value == False:
         Delay(1000)
         Indicator.Show()
         Indicator.PushText("Waiting to load Image...")                                          
         if cnt==20:
           self.log_error_message("Image load timed out!!")
           break
         else:
           cnt+=1  
      Indicator.Clear()
      batch_list.Keys("[Down]")
      value = ImageViewer.VisibleOnScreen
      while value == True:
        delay(2000)
        key = "APSUP"
        self.validate_doc_panel(document_no,app,key)
        delay(2000)
        batch_list.Keys("[Down]")
        Delay(7000)
        document_no = document_no+1
        value = ImageViewer.VisibleOnScreen
      
  elif  value == False and VarToStr(app.Cells.item[2,9]) == "No":    
      batch_list.Keys("[Down]")
      value = ImageViewer.VisibleOnScreen
      while value == True:
        delay(2000)
        key = "APINV"
        self.validate_doc_panel(document_no,app,key)
        delay(2000)
        batch_list.Keys("[Down]")
        Delay(7000)
        document_no = document_no+1
        value = ImageViewer.VisibleOnScreen
  
     
  web_utils.log_checkpoint("Verified and Updated the Document Profile Details Successfully: Ready to Release",500,capture_window)
  delay(3000)
  OCR.Recognize(batch_list).BlockByText(ocr_key, spTopMost).Click()
#  Delay(1000)
#  batch_list.FindID(b_id).click() 
  Delay(1000)
  release_button = capture_window.FindChild("AWTComponentAccessibleName","Release",30)
  while not release_button.Exists:
    delay(1000)
    capture_window.Keys("^~r")
    delay(1000)
    capture_window.Keys("[Down][Down][Enter]")
    delay(1000)
    release_button = capture_window.FindChild("AWTComponentAccessibleName","Release",30)
  release_button.Click()   
    
  Delay(10000)
  self.refresh()
  app.Cells.item[2,2]=VarToStr(batch_name)
  web_utils.log_checkpoint("Clicked on 'Release' button and batch released - Successfull for the batch: "+batch_name,500,capture_window)
 # self.validate_batch_release(app,ocr_key)
  
  
  
  
    
 def get_batch_details(self):
    capture_window = Sys.Process("capture").WaitWindow("SunAwtFrame", "Oracle WebCenter Enterprise Capture - Connected to https://core-capture-dev.epfinnp.coxautoinc.com", 1,10000)
    prop_names = ["AWTComponentAccessibleName","JavaClassName","JavaFullClassName"]
    prop_values = ["Batch Name:","JTextField","javax.swing.JTextField"]
    batch_name = capture_window.FindChildEx(prop_names,prop_values,30,True,500).wText
    app.Cells.item[2,2]=VarToStr(batch_name)
    self.log_checkpoint_message_web("Batch Name: "+VarToStr(batch_name))
  #  web_utils.log_checkpoint("Batch Name: "+batch_name,500,capture_window)
    delay(1000)
    prop_values = ["Date/Time Created:","JTextField","javax.swing.JTextField"]
    date_time = capture_window.FindChildEx(prop_names,prop_values,30,True,500).wText
  #  self.log_message_web("Date Time: "+VarToStr(date_time))
    self.log_checkpoint_message_web("Date_Time: "+VarToStr(date_time))
  #  web_utils.log_checkpoint("Date Time: "+date_time,500,capture_window)
    delay(1000)
  #  batch_notes = wcc_home_page.batch_notes_textfield().wText
    prop_values = ["Batch Notes:","JTextArea","javax.swing.JTextArea"]
    batch_notes = capture_window.FindChildEx(prop_names,prop_values,30,True,500).wText
  #  self.log_message_web("Batch_Notes: "+VarToStr(batch_notes))
    self.log_checkpoint_message_web("Batch Notes: "+VarToStr(batch_notes))
  #  web_utils.log_checkpoint("Batch_Notes: "+VarToStr(batch_notes),500,capture_window)
    
    return batch_name,date_time,batch_notes

  
  
 def refresh(self):
   capture_window = Sys.Process("capture").WaitWindow("SunAwtFrame", "Oracle WebCenter Enterprise Capture - Connected to https://core-capture-dev.epfinnp.coxautoinc.com", 1,10000)
   prop_names = ["AWTComponentName","JavaClassName"]
   prop_values = ["btnRefreshBatches","JButton"]
   delay(1200)
   refresh_button = capture_window.FindChildEx(prop_names,prop_values,30,True,90000)
   refresh_button.Click()
   Delay(2000)
   
 def validate_batch_release(self,app,ocr_key):
    capture_window = Sys.Process("capture").WaitWindow("SunAwtFrame", "Oracle WebCenter Enterprise Capture - Connected to https://core-capture-dev.epfinnp.coxautoinc.com", 1,10000)
    prop_names = ["JavaClassName", "AWTComponentIndex","JavaFullClassName"]
    prop_values = ["BatchEditForm$43",0,"oracle.oddc.client.BatchEditForm$43"]
    batch_list = capture_window.FindChildEx(prop_names,prop_values,30,True,90000) 
    OCR.Recognize(batch_list).BlockByText(ocr_key, spTopMost).Click()
#    batch_list.FindID(b_id).click() 
    delay(2000)  
# Get Batch Details and Validate for Required Batch:
    prop_names = ["AWTComponentAccessibleName","JavaClassName","JavaFullClassName"]
    prop_values = ["Batch Name:","JTextField","javax.swing.JTextField"]
    batch_name = capture_window.FindChildEx(prop_names,prop_values,30,True,90000)
    i = 0
    while batch_name.Exists == None: 
     OCR.Recognize(batch_list).BlockByText(ocr_key, spTopMost).Click()
     i = i + 1
     if i == 4:
      self.log_error_message("Unable to Validate the Release: Test Failed")
      
    batch_name,date_time,batch_notes = self.get_batch_details()
    if batch_name == VarToStr(app.Cells.item[2,2]):
       self.log_error_message("Unable to Verify the Release for Batch : "+VarToStr(app.Cells.item[2,2])+" Batch Record Still Present - Test Failed")
    web_utils.log_checkpoint("Able to Verify the Release for :"+VarToStr(app.Cells.item[2,2])+" - Batch Record Removed from the Page",500,capture_window)
    
 def validate_doc_panel(self,document_no,app,key): # Removed the variable 'book'
    delay(11000)
    capture_window = Sys.Process("capture").WaitWindow("SunAwtFrame", "Oracle WebCenter Enterprise Capture - Connected to https://core-capture-dev.epfinnp.coxautoinc.com", 1,10000)
    cnt = capture_window.FindAllChildren("JavaClassName","JSplitPane",60)
    pro = ("AWTComponentName","JavaClassName","AWTComponentIndex")
    val = ("cboDocumentTypes","VetoableComboBox",0)
    doc_profile = Sys.Process("capture").SwingObject("RMCMain", "Oracle WebCenter Enterprise Capture - Connected to https://core-capture-dev.epfinnp.coxautoinc.com", 0).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("FormManagerPanel", "", 0).SwingObject("JPanel", "", 2).SwingObject("JPanel", "", 0).SwingObject("BatchEditForm", "", 0).SwingObject("JSplitPane", "", 0).SwingObject("JPanel", "", 0).SwingObject("JSplitPane", "", 0).SwingObject("JPanel", "", 0).SwingObject("JPanel", "", 0).SwingObject("cboDocumentTypes")
    if key == "APINV":  
       if OCR.Recognize(doc_profile).FullText == "CAIAP Invoices\n":
          self.log_checkpoint_message_web("Document Profile Exists as 'CAI AP Invoices'")
       else:
         doc_profile.Click()
         doc_profile.Keys("CAIAP Invoices\n")
         self.log_checkpoint_message_web("Document Profile changed as 'CAI AP Invoices'")
    elif key == "APSUPP":
       if OCR.Recognize(doc_profile).FullText == "CAIAP Supplemental Docs\n":
          self.log_checkpoint_message_web("document Profile Exists as 'CAI Supplemental Docs'")
       else:
         doc_profile.Click()
         doc_profile.Keys("CAIAP Supplemental Docs\n")
         self.log_checkpoint_message_web("document Profile changed as 'CAI Supplemental Docs'")     
 
    #app = book.Sheets.item["wci_capture"]  
    delay(11000)
    capture_window = Sys.Process("capture").WaitWindow("SunAwtFrame", "Oracle WebCenter Enterprise Capture - Connected to https://core-capture-dev.epfinnp.coxautoinc.com", 1,10000)
    cnt = capture_window.FindAllChildren("JavaClassName","JSplitPane",60)
    combo_list=cnt[1].FindAllChildren("AWTComponentName","ComboBox.textField",40)
    prop_names = ["AWTComponentIndex","JavaClassName","JavaFullClassName"]
    prop_values = [0,"ImageViewer","oracle.odc.imageviewer.ImageViewer"]
    ImageViewer =  capture_window.FindChildEx(prop_names,prop_values,30,True,120000)
    Sys.HighlightObject(ImageViewer)
    #combo_list[0].Keys("CAIAPAccountDistribution")
    combo_list[5].Keys(VarToStr(app.Cells.item[2,5]))#combo_list[5].Keys("walls, chantyle l")
    combo_list[4].Keys(VarToStr(app.Cells.item[2,6]))#combo_list[4].Keys("SPL")
    delay(2000)
    combo_list[3].Keys(VarToStr(app.Cells.item[2,7]))#combo_list[3].Keys("No")
    delay(2000)
    combo_list[2].Keys(VarToStr(app.Cells.item[2,8]))#combo_list[2].Keys("Yes") 
    delay(4000)
      
    self.log_checkpoint_message_web("Invoice Type: "+VarToStr(combo_list[4].wText)) 
    self.log_checkpoint_message_web("Default Coder: "+VarToStr(combo_list[5].wText)) 
    self.log_checkpoint_message_web("PrintLocal: "+VarToStr(combo_list[3].wText)) 
    self.log_checkpoint_message_web("AdvanceCharge: "+VarToStr(combo_list[2].wText)) 
    self.log_checkpoint_message_web("BatchType: "+VarToStr(combo_list[1].wText)) 
    self.log_checkpoint_message_web("LockBatch: "+VarToStr(combo_list[0].wText))

    web_utils.log_checkpoint("Verified the Document Profile Details Successfully: Ready to Release",500,capture_window)


#from ebiz import *
#import configparser
#import file_system_utils
#import wcc_login_page_v12
#import wcc_home_page_v12
#import os
#import web_utils
#from dbhelper import *
#
#
#class capture_singlepage_po_invoice_scan_ca_v12(Ebiz):
#  
# def login(self):
#    self.login_user="devtest"
#    wscript=Sys.OleObject["WScript.Shell"]
#    wscript.Run("C:\\Users\\"+os.environ.get('USERNAME')+"\\AppData\\Local\\Oracle\\capture\\capture.exe")
##    "C:\\Users\\"+os.environ.get('USERNAME')+"\\Documents\\logfile.log"
#    capture_client = Sys.Process("capture").WaitSwingObject("RMCLogin", "Oracle WebCenter Enterprise Capture", -1,10000)
#    if capture_client.Exists:
#      capture_client.FindChild("AWTComponentAccessibleName","User Name:",30).Click()
#      capture_client.FindChild("AWTComponentAccessibleName","User Name:",30).Keys("devtest")
#      delay(2000)
#      capture_client.FindChild("AWTComponentAccessibleName","Password:",30).Click()
#      capture_client.FindChild("AWTComponentAccessibleName","Password:",30).Keys("oracle123")
#      delay(2000)
#      capture_client.FindChild("AWTComponentAccessibleName","Server:",30).Click()
#      capture_client.FindChild("AWTComponentAccessibleName","Server:",30).Keys("^a[Del]")
#      capture_client.FindChild("AWTComponentAccessibleName","Server:",30).Keys("https://core-capture-dev.epfinnp.coxautoinc.com")
#      delay(2000)
#      capture_client.FindChild("AWTComponentAccessibleName","OK",30).Click()
#    else:
#      self.log_error_message("Unable to Find the CaptureClient Login")
#    capture_window = Sys.Process("capture").WaitWindow("SunAwtFrame", "Oracle WebCenter Enterprise Capture - Connected to https://core-capture-dev.epfinnp.coxautoinc.com", 1,10000)
#    if capture_window.Exists:
#      web_utils.log_checkpoint("Able to Login to WCC Applications - Client Successfully",500,capture_window)
#    else:
#      self.log_error_message("Unable to Login to WCC Applications - Client")
#       
# def goto_url(self,url):
#
#  pass
#   
# def logout(self):
##   self.page.wait() 
#   capture_window = Sys.Process("capture").WaitWindow("SunAwtFrame", "Oracle WebCenter Enterprise Capture - Connected to https://core-capture-dev.epfinnp.coxautoinc.com", 1,10000) 
#   signout_link = capture_window.FindChild("AWTComponentAccessibleName","Signed In As devtest",30) 
##  Sys.HighlightObject(signout_link) 
#   signout_link.Click() 
#   delay(1000) 
#   capture_window.Keys("[Down][Down][Down][Down]") 
#   delay(500) 
#   capture_window.Keys("[Enter]") 
#   capture_window.Close() 
# #  web_utils.log_checkpoint("Completed WCI Capture Application Validation Successfully: Logging out from Applications",500,self.page) 
#   self.log_checkpoint_message_web("Completed WCI Capture Application Validation Successfully: Logging out from Applications")    
#
# def action(self,book):
#  Delay(3000)
#  file_system_utils.create_folder("C:\\TC_Logs")
#  app = book.Sheets.item["wci_capture"]  
#  
#  capture_window = Sys.Process("capture").WaitWindow("SunAwtFrame", "Oracle WebCenter Enterprise Capture - Connected to https://core-capture-dev.epfinnp.coxautoinc.com", 1,10000) 
#  prop_names = ["JavaClassName", "AWTComponentIndex","JavaFullClassName"]
#  prop_values = ["BatchEditForm$43",0,"oracle.oddc.client.BatchEditForm$43"]
#  batch_list = capture_window.FindChildEx(prop_names,prop_values,30,True,90000)  
# 
#  prop_names = ["JavaClassName","JavaFullClassName", "AWTComponentIndex"]
#  prop_values = ["VetoableComboBox","oracle.odc.component.VetoableComboBox","0"]
#  
#  # Selected Location
#  location = VarToStr(app.Cells.item[2,1])
#  ocr_key = aqString.SubString(location,0,2)
#  capture_window.FindChildEx(prop_names,prop_values,30,True,90000).Keys(location) 
#  location_object=Sys.Process("Capture").FindChild(prop_names,prop_values,5000)
#  web_utils.log_checkpoint("Selected Capture Location Sucessfully",500,location_object)
#  self.log_checkpoint_message_web("Location Selected: "+location) 
#
#  Sys.Process("capture").SwingObject("RMCMain", "Oracle *", 0).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("FormManagerPanel", "", 0).SwingObject("JPanel", "", 2).SwingObject("JPanel", "", 0).SwingObject("BatchEditForm", "", 0).SwingObject("JSplitPane", "", 0).SwingObject("JPanel", "", 0).SwingObject("JSplitPane", "", 0).SwingObject("JPanel", "", 1).SwingObject("JToolBar", "", 0).SwingObject("btnScanBatch").Click()
#  self.log_checkpoint_message_web("Clicked on capture")
#  
#  Delay(4000) 
# 
#   # Click on Import OK button
#  
#  Sys.Process("capture").SwingObject("ImportOptionDialog", "Import", -1, 1).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("JPanel", "", 0).SwingObject("btnImportOptionOK").Click()
#
#  # Clicking on parent folder button
#  Sys.Process("capture").SwingObject("FileImportDialog", "Select files to import", -1, 1).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("filechooser").SwingObject("JPanel", "", 0).SwingObject("JPanel", "", 0).SwingObject("JButton", "Up", 0).Click()
#  delay(1000)
#  Sys.Process("capture").SwingObject("FileImportDialog", "Select files to import", -1, 1).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("filechooser").SwingObject("JPanel", "", 0).SwingObject("JPanel", "", 0).SwingObject("JButton", "Up", 0).Click()
#  delay(1000)
#  Sys.Process("capture").SwingObject("FileImportDialog", "Select files to import", -1, 1).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("filechooser").SwingObject("JPanel", "", 0).SwingObject("JPanel", "", 0).SwingObject("JButton", "Up", 0).Click()
#  delay(1000)
#  Sys.Process("capture").SwingObject("FileImportDialog", "Select files to import", -1, 1).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("filechooser").SwingObject("JPanel", "", 0).SwingObject("JPanel", "", 0).SwingObject("JButton", "Up", 0).Click()
#  delay(1000)
#  
#    # Select file 
#  
#  Sys.Process("capture").SwingObject("FileImportDialog", "Select files to import", -1, 1).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("filechooser").SwingObject("JPanel", "", 2).SwingObject("JPanel", "", 0).SwingObject("SynthFileChooserUIImpl$3", "File name:", 0).SetText("C:\TC_Logs\ATC-SinglePageInvoice.tif")
#  self.log_checkpoint_message_web("Entered file name to be imported")
#  # Click on file name and Ok button
#  Sys.Process("capture").SwingObject("FileImportDialog", "Select files to import", -1, 1).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("filechooser").SwingObject("JPanel", "", 2).SwingObject("JPanel", "", 0).SwingObject("SynthFileChooserUIImpl$3", "File name:", 0).Click()
#  delay(2000)
#  #Sys.Process("capture").SwingObject("FileImportDialog", "Select files to import", -1, 1).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("JPanel", "", 0).SwingObject("btnFileImportOk").Click()
#  Sys.Process("capture").SwingObject("FileImportDialog", "Select files to import", -1, 1).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("filechooser").SwingObject("JPanel", "", 2).SwingObject("JPanel", "", 0).SwingObject("SynthFileChooserUIImpl$3", "File name:", 0).Keys("[Enter]")
#  self.refresh()
#  delay(2000)
#  ####### 
#
#  
#  # Is Refresh required here ?
#  
#  #self.refresh()
#  delay(13000) # Wait till the page loads
#  
#  OCR.Recognize(batch_list).BlockByText(ocr_key, spTopMost).Click()
#  
#  prop_names = ["AWTComponentAccessibleName","JavaClassName","JavaFullClassName"] 
#  prop_values = ["Batch Name:","JTextField","javax.swing.JTextField"] 
#  
#  batch_name = capture_window.FindChildEx(prop_names,prop_values,30,True,90000).wText 
#  #app.Cells.item[2,2]=VarToStr(batch_name)
#  
#  
#  batch_list.Keys("[Right][Right]")
##  self.wait_until_page_loaded()
#  Delay(5000)
#  prop_names = ["AWTComponentIndex","JavaClassName","JavaFullClassName"]
#  prop_values = [0,"ImageViewer","oracle.odc.imageviewer.ImageViewer"]
#  ImageViewer =  capture_window.FindChildEx(prop_names,prop_values,30,True,120000)
#  value = ImageViewer.VisibleOnScreen
#  document_no = 1
#  self.validate_doc_panel(document_no)
#  
##  while value == True:
###      self.wait_until_page_loaded()
##      Delay(5000)
##      self.validate_doc_panel(document_no)
##      delay(2000)
##      batch_list.Keys("[Down]")
##      Delay(7000)
##      document_no = document_no+1
##      value = ImageViewer.VisibleOnScreen
##
##  if value == False:
##      batch_list.Keys("[Down]")
##      value = ImageViewer.VisibleOnScreen
##      while value == True:
##        delay(2000)
##        self.validate_doc_panel(document_no)
##        delay(2000)
##        batch_list.Keys("[Down]")
##        Delay(7000)
##        document_no = document_no+1
##        value = ImageViewer.VisibleOnScreen
#      
#  web_utils.log_checkpoint("Verified and Updated the Document Profile Details Successfully: Ready to Release",500,capture_window)
#  delay(3000)
#  OCR.Recognize(batch_list).BlockByText(ocr_key, spTopMost).Click()
##  Delay(1000)
##  batch_list.FindID(b_id).click() 
#  Delay(1000)
#  release_button = capture_window.FindChild("AWTComponentAccessibleName","Release",30)
#  while not release_button.Exists:
#    delay(1000)
#    capture_window.Keys("^~r")
#    delay(1000)
#    capture_window.Keys("[Down][Down][Enter]")
#    delay(1000)
#    release_button = capture_window.FindChild("AWTComponentAccessibleName","Release",30)
#  release_button.Click()   
#    
#  Delay(10000)
#  self.refresh()
#  web_utils.log_checkpoint("Clicked on 'Release' button and batch released - Successfull for the batch: "+batch_name,500,capture_window)
# # self.validate_batch_release(app,ocr_key)  
#  
#  
#  
#  
#    
# def get_batch_details(self):
#    capture_window = Sys.Process("capture").WaitWindow("SunAwtFrame", "Oracle WebCenter Enterprise Capture - Connected to https://core-capture-dev.epfinnp.coxautoinc.com", 1,10000)
#    prop_names = ["AWTComponentAccessibleName","JavaClassName","JavaFullClassName"]
#    prop_values = ["Batch Name:","JTextField","javax.swing.JTextField"]
#    batch_name = capture_window.FindChildEx(prop_names,prop_values,30,True,500).wText
#    app.Cells.item[2,2]=VarToStr(batch_name)
#    self.log_checkpoint_message_web("Batch Name: "+VarToStr(batch_name))
#  #  web_utils.log_checkpoint("Batch Name: "+batch_name,500,capture_window)
#    delay(1000)
#    prop_values = ["Date/Time Created:","JTextField","javax.swing.JTextField"]
#    date_time = capture_window.FindChildEx(prop_names,prop_values,30,True,500).wText
#  #  self.log_message_web("Date Time: "+VarToStr(date_time))
#    self.log_checkpoint_message_web("Date_Time: "+VarToStr(date_time))
#  #  web_utils.log_checkpoint("Date Time: "+date_time,500,capture_window)
#    delay(1000)
#  #  batch_notes = wcc_home_page.batch_notes_textfield().wText
#    prop_values = ["Batch Notes:","JTextArea","javax.swing.JTextArea"]
#    batch_notes = capture_window.FindChildEx(prop_names,prop_values,30,True,500).wText
#  #  self.log_message_web("Batch_Notes: "+VarToStr(batch_notes))
#    self.log_checkpoint_message_web("Batch Notes: "+VarToStr(batch_notes))
#  #  web_utils.log_checkpoint("Batch_Notes: "+VarToStr(batch_notes),500,capture_window)
#    
#    return batch_name,date_time,batch_notes
#
#  
#  
# def refresh(self):
#   capture_window = Sys.Process("capture").WaitWindow("SunAwtFrame", "Oracle WebCenter Enterprise Capture - Connected to https://core-capture-dev.epfinnp.coxautoinc.com", 1,10000)
#   prop_names = ["AWTComponentName","JavaClassName"]
#   prop_values = ["btnRefreshBatches","JButton"]
#   delay(1200)
#   refresh_button = capture_window.FindChildEx(prop_names,prop_values,30,True,90000)
#   refresh_button.Click()
#   Delay(2000)
#   
# def validate_batch_release(self,app,ocr_key):
#    capture_window = Sys.Process("capture").WaitWindow("SunAwtFrame", "Oracle WebCenter Enterprise Capture - Connected to https://core-capture-dev.epfinnp.coxautoinc.com", 1,10000)
#    prop_names = ["JavaClassName", "AWTComponentIndex","JavaFullClassName"]
#    prop_values = ["BatchEditForm$43",0,"oracle.oddc.client.BatchEditForm$43"]
#    batch_list = capture_window.FindChildEx(prop_names,prop_values,30,True,90000) 
#    OCR.Recognize(batch_list).BlockByText(ocr_key, spTopMost).Click()
##    batch_list.FindID(b_id).click() 
#    delay(2000)  
## Get Batch Details and Validate for Required Batch:
#    prop_names = ["AWTComponentAccessibleName","JavaClassName","JavaFullClassName"]
#    prop_values = ["Batch Name:","JTextField","javax.swing.JTextField"]
#    batch_name = capture_window.FindChildEx(prop_names,prop_values,30,True,90000)
#    i = 0
#    while batch_name.Exists == None: 
#     OCR.Recognize(batch_list).BlockByText(ocr_key, spTopMost).Click()
#     i = i + 1
#     if i == 4:
#      self.log_error_message("Unable to Validate the Release: Test Failed")
#      
#    batch_name,date_time,batch_notes = self.get_batch_details()
#    if batch_name == VarToStr(app.Cells.item[2,2]):
#       self.log_error_message("Unable to Verify the Release for Batch : "+VarToStr(app.Cells.item[2,2])+" Batch Record Still Present - Test Failed")
#    web_utils.log_checkpoint("Able to Verify the Release for :"+VarToStr(app.Cells.item[2,2])+" - Batch Record Removed from the Page",500,capture_window)
#    
# def validate_doc_panel(self,document_no):
#    delay(11000)
#    capture_window = Sys.Process("capture").WaitWindow("SunAwtFrame", "Oracle WebCenter Enterprise Capture - Connected to https://core-capture-dev.epfinnp.coxautoinc.com", 1,10000)
#    cnt = capture_window.FindAllChildren("JavaClassName","JSplitPane",60)
#    combo_list=cnt[1].FindAllChildren("AWTComponentName","ComboBox.textField",40)
#    prop_names = ["AWTComponentIndex","JavaClassName","JavaFullClassName"]
#    prop_values = [0,"ImageViewer","oracle.odc.imageviewer.ImageViewer"]
#    ImageViewer =  capture_window.FindChildEx(prop_names,prop_values,30,True,120000)
#    Sys.HighlightObject(ImageViewer)
#    #combo_list[0].Keys("CAIAPAccountDistribution")
#    delay(1000)
#    combo_list[5].Keys("CAIAPAccountDistribution")
#    delay(1000)
#    combo_list[4].Keys("SPL")
#    delay(1000)
#    combo_list[3].Keys("No")
#    delay(1000)
#    combo_list[2].Keys("Yes") 
#    delay(1000)
##    self.log_message_web("Invoice Type: "+VarToStr(combo_list[4].wText))
##    self.log_message_web("Default coder: "+VarToStr(combo_list[5].wText))
##    self.log_message_web("PrintLocal: "+VarToStr(combo_list[3].wText))
##    self.log_message_web("AdvanceCharge: "+VarToStr(combo_list[2].wText))
#
#    self.log_checkpoint_message_web("PrintLocal: "+VarToStr(combo_list[3].wText)) 
#    self.log_checkpoint_message_web("AdvanceCharge: "+VarToStr(combo_list[2].wText)) 
#    self.log_checkpoint_message_web("Default Coder: "+VarToStr(combo_list[5].wText)) 
#    self.log_checkpoint_message_web("BatchType: "+VarToStr(combo_list[1].wText)) 
#    self.log_checkpoint_message_web("LockBatch: "+VarToStr(combo_list[0].wText))
#
#    web_utils.log_checkpoint("Verified the Document Profile Details Successfully: Ready to Release",500,capture_window)
#
#  
#   
#
#def sample(): 
#  
#  capture_window = Sys.Process("capture").WaitWindow("SunAwtFrame", "Oracle WebCenter Enterprise Capture - Connected to https://core-capture-dev.epfinnp.coxautoinc.com", 1,10000) 
#  prop_names = ["JavaClassName", "AWTComponentIndex","JavaFullClassName"]
#  prop_values = ["BatchEditForm$43",0,"oracle.oddc.client.BatchEditForm$43"]
#  batch_list = capture_window.FindChildEx(prop_names,prop_values,30,True,90000)  
#
##  OCR.Recognize(batch_list).BlockByText(ocr_key, spTopMost).Click()
#  
#  prop_names = ["AWTComponentAccessibleName","JavaClassName","JavaFullClassName"] 
#  prop_values = ["Batch Name:","JTextField","javax.swing.JTextField"] 
#  
#  batch_name = capture_window.FindChildEx(prop_names,prop_values,30,True,90000) 
#  app.Cells.item[2,2]=VarToStr(batch_name)
#    
#
#
##
##
## 
##    capture_window = Sys.Process("capture").WaitWindow("SunAwtFrame", "Oracle WebCenter Enterprise Capture - Connected to https://core-capture-dev.epfinnp.coxautoinc.com", 1,10000)
##    cnt = capture_window.FindAllChildren("JavaClassName","JSplitPane",60)
##    combo_list=cnt[1].FindAllChildren("AWTComponentName","ComboBox.textField",40)
##    prop_names = ["AWTComponentIndex","JavaClassName","JavaFullClassName"]
##    prop_values = [0,"ImageViewer","oracle.odc.imageviewer.ImageViewer"]
##    ImageViewer =  capture_window.FindChildEx(prop_names,prop_values,30,True,120000)
##    Sys.HighlightObject(ImageViewer)
##
##    combo_list[5].Keys("walls, chantyle l")
##    combo_list[4].Keys("SPL")
##    delay(1000)
##    combo_list[3].Keys("No")
##    delay(1000)
##    combo_list[2].Keys("Yes") 
##Sys.Process("capture").SwingObject("FileImportDialog", "Select files to import", -1, 1).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("JPanel", "", 0).SwingObject("btnFileImportOk").Click()
