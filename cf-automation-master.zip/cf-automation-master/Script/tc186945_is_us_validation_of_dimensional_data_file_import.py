﻿#from dbhelper import *
from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils
import winscp_utility
import web_utils
from File_Handler import File_Handler as _TXTOBJ
from text_headers import payroll_txt_file_header as _HEADERS


class tc186945_is_us_validation_of_dimensional_data_file_import(Ebiz):
 
 global inv_date,inv_num,rowno
 rowno = 2
 op_log_path="C:\\TC_Logs"
 dd_files="C:\\Dimensional_Data_Files"
 
 def login(self):
    self.login_user="amalappan"
    super().login()
    
 def goto_url(self,url):
   super().goto_url(self.testConfig['ebiz']['oci_is_url'])
 
 def action(self,book):     
    app = book.Sheets.item["Invoice"]
    self.invoice_details(book,app) 
#    self.file_add_winscp(app) 
    self.submit_request(app)
    
# Modifying cai_excel_invoice_import_report_set.csv file 
 def invoice_details(self,book,app):  
   app1 = Sys.OleObject["Excel.Application"]
   Delay(1000)
   book1 = app1.Workbooks.Open(Project.Path+"\\DataSheets\\Oracle-AP-Other\\IS\\apinv_home_dimensiondata_ZC.csv")
#   app1.Visible = "True"
   app1.DisplayAlerts= 0
   app1 = book1.Sheets.Item["apinv_home_dimensiondata_ZC"]
   rowno = 1
   j = 1
   self.dd_file_name = "apinv_home_dimensiondata_ZC_"+aqConvert.DateTimeToFormatStr(aqDateTime.Today(),"%d%m%y")
   self.inv_num = "DD_INV: "+aqConvert.DateTimeToFormatStr(aqDateTime.Time(),"%H:%M:%S")
   dd_sheet = (app1.Cells.Item)
   inv_sheet = (app.Cells.Item)
   val = "00"
   for i in range(0,4):
     if VarToStr(dd_sheet[rowno+i,1]) == "H":
        dd_sheet[rowno+i,2] = self.inv_num
        dd_sheet[rowno+i,6] = inv_sheet[rowno+(i+1),16]
        dd_sheet[rowno+i,7] = aqConvert.DateTimeToFormatStr(aqDateTime.Today(),"%d/%m/%Y")
        dd_sheet[rowno+i,16] = val+VarToStr(inv_sheet[rowno+(i+1),21])
        inv_sheet[rowno+(i+1),14] = self.inv_num
     elif VarToStr(dd_sheet[rowno+i,1]) == "D":
        dd_sheet[rowno+i,2] = self.inv_num
        dd_sheet[rowno+i,4] = inv_sheet[rowno+j,7]
        dd_sheet[rowno+i,23] = VarToStr(inv_sheet[rowno+j,22])
        dd_sheet[rowno+i,24] = "%.1f" % (VarToFloat(inv_sheet[rowno+j,23]))
        dd_sheet[rowno+i,25] = VarToStr(inv_sheet[rowno+j,24])
        dd_sheet[rowno+i,26] = VarToStr(inv_sheet[rowno+j,25])
        j = j+1
     else:
       break
      
   file_system_utils.create_folder(self.dd_files)
   file_exist=aqFileSystem.FindFiles("C:\\Dimensional_Data_Files\\","*.csv")
   if file_exist != None:
      aqFileSystem.DeleteFile("C:\\Dimensional_Data_Files\\*.csv")
   book1.SaveAs("C:\\Dimensional_Data_Files\\"+self.dd_file_name+".csv")
   book1.close()
   log_path = ("C:\\Dimensional_Data_Files\\"+self.dd_file_name+".csv")
   Log.Enabled=True
   Log.File(log_path, "CAI Dimensional Data Inv File Attached")
   Log.Enabled=False  
   self.process_files(book1,log_path)
   
 def process_files(self,book1,log_path):  
      path = log_path
      cobj = _TXTOBJ(path,",")
      cobj.write_csv_file(row for row in(cobj.read_csv_file())) 
#      book1.close()
# Placing cai_excel_invoice_import_report_set.csv file in /DAUT2I/incoming/ATG_OU/AP_XLS_INV_UPLOAD folder
## def file_add_winscp(self,app):
##    Stored_session = "dim_data@mftstg.manheim.com"
###    Stored_session = "opc@stage-fin-iad1-ebsapp1.private.stagefin.oraclevcn.com"
##    local_dir = "C:\\Dimensional_Data_Files"    
##    remote_dir =  self.testConfig['winscp']['remote_dir']  
###    remote_dir =  self.winscpConfig[self.testConfig['ebiz']['env']]['remote_dir']+"incoming//ATG_OU//I29"
##    upload_file_name = self.dd_file_name+".csv"
##    winscp_utility.upload_file(Stored_session,local_dir,remote_dir,upload_file_name)
##    Log.Enabled=True       
##    Log.Message(self.dd_file_name+".csv file placed in the AP_XLS_INV_UPLOAD directory")           
##    Log.Enabled=False

# Submitting the cai_excel_invoice_import_report_set in Oracle
 def submit_request(self,app):

    Log.Message("Inside action...")    
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'AP Home Office Super User')]")
    self.log_message_web("Click 'AP Home Office Super User' - Successful")
    delay(1000)
#    self.page.keys("[Down]")
    self.wait_until_page_loaded()
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Other')]")
    self.log_message_web("Click 'Other' Folder - Successful")
    delay(1000)
#    self.page.keys("[Down]")
    self.wait_until_page_loaded()
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Requests')]")
    self.log_message_web("Click 'Requests' Folder - Successful")
    self.wait_until_page_loaded()
    self.page.NativeWebObject.Find("contentText","Run","A").Click()
    self.log_message_web("Click 'Run' Options - Successful")
    delay(10000) 
#    self.page.wait_until_load()
    jFrame=self.initializeJFrame()
    delay(5000)
    form_utils.click_ok_btn(jFrame)

    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["*Request Set alt s","ExtendedCheckbox"]
    jFrame.Find(prop,val,30).Click()
    Delay(3000)
    #jFrame.Find(prop,val,30).Keys("~o")
    #form_utils.click_ok_btn(jFrame)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit a New Request","ExtendedFrame"]
    jFrame.Find(prop,val,30).Click()

    prop1=["AWTComponentAccessibleName","JavaClassName"]
    val1=["OK alt O","Button"]
    jFrame.FindChildEx(prop,val,60,True,60000).Find(prop1,val1,30).Click()
 
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit Request Set","ExtendedFrame"]
    par_form=jFrame.FindChildEx(prop,val,60,True,60000)
    par_form.Find("AWTComponentAccessibleName","Request Set RequiredList of Values",30).SetText("MANAP Telecom Invoice Interface Request Set")# Updated to SetText
    delay(1000)
    par_form.Find("AWTComponentAccessibleName","Request Set RequiredList of Values",30).Click()
    par_form.Find("AWTComponentAccessibleName","Request Set RequiredList of Values",30).Keys("[Tab]")
    delay(1000)
    jFrame.Keys("[Tab]")
    jFrame.Keys("[Tab]")
    Delay(2000)
#    jFrame.Keys("DIMENSION_DATA_ATG_INV_20190924.csv.gpg")
    jFrame.Keys("~o")
    delay(1000) 
    
    par_form.Find("wText","MAN AP Invoices WF Approval Status Update Program By Source",30).Click()
    jFrame.Keys("[Tab]")
    jFrame.Keys("[Tab]")
    delay(1000)
    jFrame.Keys("~o")    
       
    delay(1000)

    #jFrame.Keys("~m")
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit","Button"]
    submit_button=jFrame.FindChildEx(prop,val,60,True,60000)    
    submit_button.Click()    
    RequestID = ''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit())
    Log.Message("Request ID Of  " + aqConvert.VarToStr(RequestID))
    app.Cells.Item[2,21] = VarToStr(RequestID)
    self.log_checkpoint_message_web("Request ID Of CAI Excel Invoice Import (Report Set) is " + aqConvert.VarToStr(RequestID))    
    delay(1000)    
    jFrame.Keys("~n")
    delay(1000)
    #jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000)
    
    
    dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
    user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
    pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
    dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,VarToStr(RequestID)) 
    delay(200000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,90000)
    
    # Gathering Request ID and Output File for the "CAI Payables Invoice Import Program" 
    
    
    file_format = "log"
    self.req_set_save_file(jFrame,req_form,"MANAP Telecom Invoice Interface Request Set (Report Set)",RequestID,file_format)
    jFrame.Click()
    Delay(2000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000)

    file_format = "log"
    self.req_set_save_file(jFrame,req_form,"MANAP: Load Payables Invoices (MANAP: Load Payables Invoices)",RequestID,file_format)
    jFrame.Click()
    Delay(2000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000)

    
    file_format = "output"
    self.req_set_save_file(jFrame,req_form,"MAN Payables Invoice Import",RequestID,file_format)
    jFrame.Click()
    Delay(2000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000)
    
    dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
    user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
    pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
    dbhelper.verify_costar_invoice_info(dsn,user_id,pwd,self.inv_num)    
    app.Cells.Item[rowno,13] = self.inv_num
    Delay(1000)
    web_utils.close_additional_browsers()
    Delay(1000)
    jFrame.Click()
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~o")
    Delay(3000)    
    
#   Validating the Invoice in the Front end and checking Headerlevel DFF and Linelevel DFF
    self.page.WaitProperty("contentText","AP Home Office Super User",6000)
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" AP INVOICE PROCESSING')]") 
    self.log_message_web("Click 'CAI US AP INVOICE PROCESSING' - Successful")    
    self.page.keys("[Down]")
    Delay(1000)
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Invoices')]")
    self.log_message_web("Click 'Invoices' - Successful")
    delay(20000) 
    jFrame=self.initializeJFrame() 
    Delay(10000)
    form_utils.click_ok_btn(jFrame)
    Delay(6000)
    jFrame.Keys("~v")
    delay(6000)
    jFrame.Keys("f")
    delay(6000)
    
#   Finding Invoice
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Invoices","ExtendedFrame"]
    par_form=jFrame.FindChildEx(prop,val,60,True,60000)
    par_form.Find("AWTComponentAccessibleName","Invoice: Number",10).Click()
    par_form.Find("AWTComponentAccessibleName","Invoice: Number",10).Keys(app.Cells.Item[rowno,13])

    delay(5000) 
    jFrame.Keys("~i")
    Delay(10000)
    self.log_message_oracle_form(jFrame,"'Invoice Workbench' form launched successfully")
    menu_bar=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWMenuBar", "", 0)
    OCR.Recognize(menu_bar).BlockByText("Folder").Click()
    Delay(1000)
    jFrame.Keys("o")
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Invoice Workbench*","ExtendedFrame"]
#    invoice=jFrame.FindChildEx(prop,val,60,True,60000)
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Open Folder*","VButton"]
#    open_fldr_form=invoice.FindChildEx(prop,val,30,True,60000)
#    open_fldr_form.Click()
    Delay(4000)
    jFrame.Keys("AP HEADER")
    delay(5000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Open Folder","FWindow"]
    open_folder=jFrame.FindChildEx(prop,val,50,True,90000)  
    Sys.HighlightObject(open_folder)     
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["OK ALT O","PushButton"]   
    open_folder.FindChild(prop,val,10).Click()
    
#    Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications - EBS", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("FWindow", "Open Folder", 0).AWTObject("LWComponent", "", 0).AWTObject("EwtContainer", "", 0).AWTObject("ButtonBar", "", 0).AWTObject("ButtonBar", "", 1).AWTObject("PushButton", "OK ALT O", 0).Click()
    delay(4000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Invoice Workbench*","ExtendedFrame"]
    invoice=jFrame.FindChildEx(prop,val,60,True,60000)
    prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
    val=["[ ]","VTextField","196"]
    hdr_level_dff=invoice.FindChildEx(prop,val,30,True,60000)
    hdr_level_dff.Click()
    delay(4000)
    self.log_message_oracle_form(jFrame,"'Telecom' Invoice Header Level DFF values reviewed successfully")
    delay(4000)
    jFrame.Keys("[F4]")
    delay(4000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Invoice Workbench*","ExtendedFrame"]
    invoice=jFrame.FindChildEx(prop,val,60,True,60000)
    self.log_message_oracle_form(jFrame,"Click on 'Lines' on 'Invoice Workbench' next")
    Delay(5000)
    invoice.FindChild("AWTComponentName","FormsTabPanel*",60).ClickTab("2 Lines")
    Delay(5000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Open Folder*","VButton"]
    open_fldr_form=jFrame.FindChildEx(prop,val,30,True,60000)
    open_fldr_form.Click()
    Delay(6000)
    jFrame.Keys("AP Lines")
    delay(5000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Open Folder","FWindow"]
    open_folder=jFrame.FindChildEx(prop,val,50,True,90000)  
    Sys.HighlightObject(open_folder)     
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["OK ALT O","PushButton"]   
    open_folder.FindChild(prop,val,10).Click()
#    Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications - EBS", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("FWindow", "Open Folder", 0).AWTObject("LWComponent", "", 0).AWTObject("EwtContainer", "", 0).AWTObject("ButtonBar", "", 0).AWTObject("ButtonBar", "", 1).AWTObject("PushButton", "OK ALT O", 0).Click()
    delay(4000)
    prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
    val=["[ ]","VTextField","405"]
    line_level_dff=jFrame.FindChildEx(prop,val,30,True,60000)
    line_level_dff.Click()
    delay(4000)
    self.log_message_oracle_form(jFrame,"'Telecom' Invoice Line Level DFF values reviewed successfully")
    delay(4000)
    jFrame.Keys("[F4]")
    delay(6000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~o")
    Delay(3000) 
    
    
    
    
    
    
    

 def req_set_save_file(self,jFrame,req_form,srch_child_name,Preqid,file_format):
      self.log_message_oracle_form(req_form,"Checking for "+aqConvert.VarToStr(srch_child_name)+ " Child Program Status")
      req_form.FindChild("AWTComponentAccessibleName","Refresh Data alt R",20).Click()
      i=20
      for x in range(1,180):     
          prop=["AWTComponentAccessibleName","AWTComponentIndex"]
          val=["Name",i]
          child_name=req_form.Find(prop,val,10).wText 
          prop=["AWTComponentAccessibleName","AWTComponentIndex"]
          val=["Phase",i+20]
          phase=req_form.Find(prop,val,10).wText 
          prop=["AWTComponentAccessibleName","AWTComponentIndex"]
          val=["Request ID",i-10]
          creqid=VarToInt(req_form.Find(prop,val,10).wText)
  #        self.log_message_oracle_form(req_form,"Request ID of "+aqConvert.VarToStr(srch_child_name)+" is "+aqConvert.VarToStr(creqid))                                         
          prop=["AWTComponentAccessibleName","AWTComponentIndex"]
          val=["Status",i+30]         
          status =req_form.FindChild(prop,val,60)            
          if (child_name==srch_child_name) and (creqid>=VarToInt(Preqid)) and (phase == "Completed"):
              self.log_message_oracle_form(req_form, aqConvert.VarToStr(srch_child_name)+" Phase Completed Successfuly")             
  #            self.verify_aqobject_chkproperty(status,"wText",cmpContains,"Normal")        
              status.Keys("[Enter]")
              Delay(1000)
  #            jFrame.Keys("~g")  
              if file_format == "log":
                req_form.FindChild("AWTComponentAccessibleName","View Log alt K",20).Click()
              elif file_format == "output":
                req_form.FindChild("AWTComponentAccessibleName","View Output alt p",20).Click()  
              Delay(3000)
              output_page=Sys.Browser("iexplore").Page("https://core*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.*")
              output_page.Click()
              Delay(2000)
              output_page.Keys("~f")
              Delay(2000)
              output_page.Keys("a")
              Delay(5000)
              file_system_utils.create_folder(self.op_log_path)             
              log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"File"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"_%d%b%Y_%H%M")+".txt"    
              Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
              Delay(1000)
              Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
              Delay(2000)
              Log.Enabled=True
              Log.File(log_path, aqConvert.VarToStr(srch_child_name)+" Log/Output File Attached")
              Log.Enabled=False     
              Sys.Browser("iexplore").Page("https://core*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.*").Close()
              Filesaved = 'True'
              web_utils.close_additional_browsers()
              Filesaved = 'True'
              return                           
          elif i >=28:
             Delay(20000)
  #           req_form.keys("~r")
             req_form.FindChild("AWTComponentAccessibleName","Refresh Data alt R",20).Click()
             Delay(3000)
             i=20
             val=["Name",i]
             child_name=req_form.Find(prop,val,10).wText
  
          else:  
             Delay(3000)
             i=i+1 
