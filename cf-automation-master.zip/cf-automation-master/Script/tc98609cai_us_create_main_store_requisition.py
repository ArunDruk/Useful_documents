﻿from ebiz import *
import web_utils 

#Author:            Prabhakaran Rajendran
#TestCaseID:        
#UserStoryID:       
#Reviewed_By:       Syed,Husain



# class defined for this action/function and will be called from driverchain(execute() method)
class tc98609cai_us_create_main_store_requisition(Ebiz): 
  global rowno, RowCount, rel, txnum, app

  # Overrite login function 
  def login(self):
    self.login_user="ctucker"
    super().login()

  
# this method will be called from base class() in the framework  
# action method to call all sub functions(methods)

  def action(self,book): 
      rowno=2
      req = 0
      app = book.Sheets.Item["Requisition"]
      app1 = book.Sheets.Item["Invoice"]
      RowCount = app.UsedRange.Rows.Count
      txnum = VarToInt(app.cells.Item[rowno,1])      
      while rowno<(RowCount+1):
        Log.Enabled=True 
        Log.Message("Creating Requisition No:"+IntToStr(req+1))
        Log.Enabled=False 
        self.navigate_iproc(rowno)
        rowno = self.main_req(rowno,txnum,app,app1)
        self.req_info(app,rowno)
        self.get_reqno(rowno,app)
        rowno=rowno+1
        req = req+1 
        txnum=txnum+1
      book.save()
#      del app,txnum,RowCount,rel,rowno
  #method to navigate 'iprocurement non catalog requisition' entry page
  def navigate_iproc(self,rowno):    
    Delay(4000)
    if rowno ==2:
      self.page.EvaluateXPath("//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" iPROC USER')]")[0].scrollIntoView() 
      Delay(2000)
      self.page.EvaluateXPath("//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" iPROC USER')]")[0].Click() 
      Delay(2000)
    self.wait_until_page_loaded()
    self.page.EvaluateXPath("//table[@id='respList']//div[contains(text(),'iProcurement Home Page')]")[0].HoverMouse() 
    Delay(1000)
    self.page.EvaluateXPath("//table[@id='respList']//div[contains(text(),'iProcurement Home Page')]")[0].Click()
    Delay(2000)
    self.wait_until_page_loaded()
#    self.page.Find("idStr","AllStoresName2_0*",60).Click()
    obj = self.page.EvaluateXPath("//a[contains(text(),'Main Store')]")[0]
    if obj.Exists:
      self.log_checkpoint_message_web("Internal Store Available for user: Main Store")
      obj.Click()
    else:
      self.log_error_message("Unable to Find Main Store to Order Internal Catalog Items")
    Delay(1000)    
    self.wait_until_page_loaded()
    self.page.EvaluateXpath("//a[@id='CategoryLInk']")[0].Click()
    self.wait_until_page_loaded()
    
  def main_req(self,rowno,txnum,app,app1):
    
    self.page.EvaluateXpath("//a[@title='AUTO PARTS.AIR CONDITIONING AUTO PARTS.AIR CONDITIONING.CAI (1)']")[0].Click()
    self.wait_until_page_loaded()
    count = 0 
    amt = 0
    while (VarToString(app.Cells.Item[rowno, 1])== IntToStr(txnum)): 
      self.wait_until_page_loaded()
      self.page.FindChildEx("idStr","SearchResultsTableRN1:Quantity:0",60,True,60000).Click()
      Delay(1000)
      self.page.Find("idStr","SearchResultsTableRN1:Quantity:0",60).Keys("[Del]")
      Delay(1000)
      quantity = VarToInt(app.Cells.Item[rowno,5])
      self.page.Find("idStr","SearchResultsTableRN1:Quantity:0",60).Keys(quantity)
      self.wait_until_page_loaded()
      self.page.EvaluateXpath("//button[@id='SearchResultsTableRN1:AddToCart:0']")[0].Click()

      Delay(5000)
      self.wait_until_page_loaded()
      chk_out = self.page.EvaluateXpath("//table[@id='ButtonTableLayout']//button[@id='PopupCheckout']")[0].contentText
      if chk_out =="View Cart and Checkout":
        self.log_checkpoint_message_web("Items of Quantity "+IntToStr(quantity)+" added to Cart")
      else:
        self.log_error_message("Unable to add Items to Cart")
      self.wait_until_page_loaded()
      self.page.Find("idStr","GoSort",60).Click()
      amt = amt + (quantity*100)
      rowno = rowno + 1
      count = count + 1
    app1.Cells.Item[2,16] = count
    app1.Cells.Item[2,15] = amt
    self.wait_until_page_loaded()  
    self.page.EvaluateXpath("//table[@id='ButtonTableLayout']//button[@id='PopupCheckout']")[0].Click()
    Delay(2000)
    self.wait_until_page_loaded()

#    self.page.NativeWebObject.Find("contentText","Checkout","button").Click()
#    self.wait_until_page_loaded()
    rowno=rowno-1
    return rowno

  def req_info(self,app,rowno):

      fut_date = aqDateTime.AddDays(aqDateTime.Now(),3)
      fut_date1 = aqConvert.DateTimeToFormatStr(fut_date,"%d-%b-%Y %H:%M:%S")
      Delay(2000) 
      currentDate = aqDateTime.Today()
      currentDate1 = aqConvert.DateTimeToFormatStr(currentDate,"%d-%b-%Y") 
      self.wait_until_page_loaded()   
      cart_box = self.page.FindChildEx("idStr","popupShoppingCartPopup",60,True, 40000)
      Delay(2000) 
#      obj=self.page.Find("idStr","NeedByDate",50)
      if cart_box.Exists:
        self.log_checkpoint_message_web("Requisition Information Popup Launched Successfully")
      else:
        self.log_error_message("Unable to Launch Requisition Information PopUp")      
#      cart_box.Find("idStr","NeedByDate",20).Click()
#      Delay(1000)
#      cart_box.Find("idStr","NeedByDate",20).Keys(fut_date1)
#      Delay(2000)
#      self.page.EvaluateXpath("//table[@id = 'HeaderDescTableLayout']//a[contains (text(), 'Show Delivery and Billing')]")[0].Click()
#      cart_box = Sys.Browser("iexplore").page("*").FindChildEx("idStr","popupShoppingCartPopup",50,True,30000)
      Sys.HighlightObject(cart_box)
      Delay(1000)
      cart_box.FindChildEx("idStr","ReqSummaryHideShow__xc_",50,True,30000).DblClick()
      Delay(3000)
      while cart_box.FindChild("contentText","Show Delivery and Billing",30).Exists:
        cart_box.FindChild("contentText","Show Delivery and Billing",30).Click()
      Delay(1000)
      cart_box.EvaluateXpath("//table[@id = 'BillingLabeledFieldLayout']//input[@id='ProjectOnSummaryExpense']")[1].Click()
      Delay(1000)
      cart_box.EvaluateXpath("//table[@id = 'BillingLabeledFieldLayout']//input[@id='ProjectOnSummaryExpense']")[1].Keys(app.Cells.item[rowno,11])
      cart_box.Keys("[Tab]")
      cart_box.Keys("[Tab]")
      Delay(1000)
      cart_box.EvaluateXpath("//table[@id = 'BillingLabeledFieldLayout']//input[@id='TaskExpense']")[1].Keys(app.Cells.item[rowno,12])
      Delay(1000)
      cart_box.Keys("[Tab]")
      cart_box.Keys("[Tab]")
      Delay(1000)
      cart_box.EvaluateXpath("//table[@id = 'BillingLabeledFieldLayout']//input[@id='ExpenditureTypeOnSummary']")[1].Keys(app.Cells.item[rowno,13])
      Delay(1000)
      cart_box.Keys("[Tab]")
      cart_box.Keys("[Tab]")
      Delay(1000)
      cart_box.EvaluateXpath("//table[@id = 'BillingLabeledFieldLayout']//input[@id='ExpenditureOrg']")[0].Keys(app.Cells.item[rowno,14])
      Delay(1000) 
      cart_box.Keys("[Tab]")
      cart_box.Keys("[Tab]")
      Delay(1000)
      cart_box.EvaluateXpath("//table[@id = 'BillingLabeledFieldLayout']//input[@id='ExpenditureItemDate']")[0].Keys(currentDate1)
      Delay(1000) 
      cart_box.Keys("[Tab]")
      cart_box.FindChild("idStr","NeedByDate",20).Click()
      Delay(1000)
      cart_box.FindChild("idStr","NeedByDate",20).Keys(fut_date1)
      Delay(2000)
      
#      Delay(1000)
#      cart_box.Find("idStr","ExpenditureItemDate",30).Click()
#      Delay(1000)
#      cart_box.Find("idStr","ExpenditureItemDate",30).Keys(currentDate1)
      Delay(5000)
      self.wait_until_page_loaded()
      self.log_message_web("Project details entered")
      delay(1000)
      cart_box.FindChild("idStr","ShoppingPopupSubmit",30).DblClick()
      delay(1000)
      while cart_box.FindChild("idStr","ShoppingPopupSubmit",30).Exists:
        cart_box.FindChild("idStr","ShoppingPopupSubmit",30).Click()
        Delay(1000)
#      pro_names=("ObjectLabel","ObjectType","ObjectIdentifier")
#      pro_values=("Next","Button","0")
#      self.page.Find(pro_names,pro_values,30).Click()      
#      Delay(7000)
#      self.wait_until_page_loaded()
#      self.page.EvaluateXPath("//table[@id='PageActionButtonsBar']/tbody/tr//td/button[@title='Next']")[0].Click()      
#      delay(2000)
#      self.wait_until_page_loaded()
#      self.page.EvaluateXPath("//table[@id='PageActionButtonsRN_uixr']//button[@id='SubmitButton_uixr']")[0].Click()
#      self.log_message_web("Requisition submitted successfully") 
      Delay(2000)
      self.wait_until_page_loaded()
     
  #method to submit and to write the requisition details to Excel    
  def get_reqno(self,rowno,app):
      self.wait_until_page_loaded()      
      obj=self.page.FindChildEx("idStr","GoodsStatusText",50,True,40000)
      if obj.Exists:
        self.log_checkpoint_message_web("Requisition No. Generated Successfully: Validated and Captured the Req.number")
      else:
        self.log_message_web("Unable to Complete Creating Non-Catalog Requisition")
      
      Rno = self.page.Find("idStr","ApproverText",30).contentText
      Delay(1000)
      Rno1 = aqString.SubString(Rno,12,5)
      self.log_message_web("Non-Catalog Requisition:" + Rno1)      
      delay(1000)    
      app.Cells.Item[rowno,15] = Rno1
      Delay(2000)      
      self.page.EvaluateXpath("//table[@id = 'globalHeaderID']//a/div/img[@title = 'Home']")[0].Click()
      self.wait_until_page_loaded()
    
    
def test():
# Sys.Browser("iexplore").Page("https://core-dev.epfinnp.coxautoinc.com/OA_HTML/RF.jsp?function_id=*").Panel("oafOraBodyContainer").Form("DefaultFormName").Panel("oafcontent").Panel(0).Panel("oafusercontent").Table(0).Cell(1, 1).Panel("popupShoppingCartPopup").Panel(0).Panel(0).Frame("iframeShoppingCartPopup").Frame(0).Panel("oafOraBodyContainer").Form("DefaultFormName").Table("HeaderDescTableLayout").Cell(0, 1).Panel(2).Table("CheckoutSummaryTableLayout").Cell(0, 1).Panel("BillingSummaryRN").Panel(1).Table("BillingLabeledFieldLayout").Cell(0, 3).Panel("ProjectOnSummaryExpense_xc_").Textbox("ProjectOnSummaryExpense").Click()
 cart_box = Sys.Browser("iexplore").page("*").FindChildEx("idStr","popupShoppingCartPopup",50,True,30000)
 Sys.HighlightObject(cart_box)
 Delay(1000)
 cart_box.FindChildEx("idStr","ReqSummaryHideShow__xc_",50,True,30000).Click()
# fut_date = aqDateTime.AddDays(aqDateTime.Now(),3)
# fut_date1 = aqConvert.DateTimeToFormatStr(fut_date,"%d-%b-%Y")
# Delay(2000)
# cart_box.Find("idStr","NeedByDate",20).Click()
# Delay(1000)
# cart_box.Find("idStr","NeedByDate",20).Keys("[End]")
# Delay(1000)
# cart_box.Find("idStr","NeedByDate",20).Keys("![Home]")
# cart_box.Keys("[Del]")
## Delay(1000)
# cart_box.FindChildByXPath("//table[@id = 'BillingLabeledFieldLayout']//input[@id='ProjectOnSummaryExpense']").Click()
## Delay(1000)
 Delay(1000)
 cart_box.EvaluateXpath("//table[@id = 'BillingLabeledFieldLayout']//input[@id='ProjectOnSummaryExpense']")[1].Click()
 Delay(1000)
 cart_box.EvaluateXpath("//table[@id = 'BillingLabeledFieldLayout']//input[@id='ProjectOnSummaryExpense']")[1].Keys('1004121')
 cart_box.Keys("[Tab]")
 cart_box.Keys("[Tab]")
 Delay(1000)
 cart_box.EvaluateXpath("//table[@id = 'BillingLabeledFieldLayout']//input[@id='TaskExpense']")[1].Keys('1')
 Delay(1000)
 cart_box.Keys("[Tab]")
 cart_box.Keys("[Tab]")
 Delay(1000)
 cart_box.EvaluateXpath("//table[@id = 'BillingLabeledFieldLayout']//input[@id='ExpenditureTypeOnSummary']")[1].Keys('AUTOS')
 Delay(1000)
 cart_box.Keys("[Tab]")
 cart_box.Keys("[Tab]")
 Delay(1000)
 cart_box.EvaluateXpath("//table[@id = 'BillingLabeledFieldLayout']//input[@id='ExpenditureOrg']")[0].Keys('ATC Sites (1306)')
 Delay(1000) 
 cart_box.Keys("[Tab]")
 cart_box.Keys("[Tab]")
 Delay(1000)
 cart_box.EvaluateXpath("//table[@id = 'BillingLabeledFieldLayout']//input[@id='ExpenditureItemDate']")[0].Keys('16-Jul-2019')
 Delay(1000)
 
# Sys.Browser("iexplore").page("*").NativeWebObject.Find("innerText", "ProjectOnSummaryExpense", "a").Click()
# Sys.Browser("iexplore").Page("https://core-dev.epfinnp.coxautoinc.com/OA_HTML/OA.jsp*").Panel("oafOraBodyContainer").Form("DefaultFormName").Panel("oafcontent").Panel(0).Panel("oafusercontent").Table(0).Cell(1, 1).Panel(0).Panel(1).Panel("popupShoppingCartPopup").Panel(0).Panel(0).Frame("iframeShoppingCartPopup").Frame(0).Panel("oafOraBodyContainer").Form("DefaultFormName").Table("HeaderDescTableLayout").Cell(0, 1).Panel(2).Table("CheckoutSummaryTableLayout").Cell(0, 1).Panel("BillingSummaryRN").Panel(1).Table("BillingLabeledFieldLayout").Cell(0, 3).Panel("ProjectOnSummaryExpense_xc_").Textbox("ProjectOnSummaryExpense").Click()
 #cart_box.EvaluateXpath("//table[@id = 'BillingLabeledFieldLayout']//input[@id = 'ProjectOnSummaryExpense']")[0].Click()
# cart_box.Find("idStr","NeedByDate",20).Keys(fut_date1)
# Delay(1000)
# cart_box.EvaluateXpath("//table[@id = 'HeaderDescTableLayout']//a[contains (text(), 'Show Delivery and Billing')]")[0].HoverMouse
# Delay(1000)
# cart_box.EvaluateXpath("//table[@id = 'HeaderDescTableLayout']//a[contains (text(), 'Show Delivery and Billing')]")[0].DblClick() 
# Delay(2000)
# Sys.HighlightObject(Sys.Browser("iexplore").page("*").EvaluateXpath("//table[@id = 'HeaderDescTableLayout']//a[contains (text(), 'Show Delivery and Billing')]")[0])
# Sys.Browser("iexplore").page("*").FindChildEx("idStr","ProjectOnSummaryExpense",20,True,20000).click()

def test1():
      currentDate = aqDateTime.Today()
      currentDate1 = aqConvert.DateTimeToFormatStr(currentDate,"%d-%b-%Y %H:%M:%S") 
      Log.Message(currentDate1)