﻿from ebiz import *
import dbhelper 
import web_utils


class tc170974_is_us_ap_invoices_initiate_approval(Ebiz):
  global rowno, app, book, val

  def login(self):
    self.login_user="rmaran"
    super().login()
  
  def goto_url(self,url):
   super().goto_url(self.testConfig['ebiz']['oci_is_url'])

  def action(self,book):
    
      global rowno, app
      rowno=2
      app = book.Sheets.item["Invoice"]
      RowCount = app.UsedRange.Rows.Count
      
      while rowno<(RowCount+1):
        val = VarToString(app.cells.Item[rowno,13])
        if rowno == 2:
          self.nav_appr()
        else: 
          self.multi_inv()
        self.init_appr(val,app)  
        self.apr_val(app,rowno)
        rowno = rowno+1
        delay(1000)

      book.save()
      Delay(1000)
      del app,rowno,val


#Method for navigating to Invoice AP Home Office Super User
 
  def nav_appr(self):  
        
      self.page.wait()
      web_utils.log_checkpoint("Logged in to Oracle Applications Home Page Successfully",500,self.page)
      self.wait_until_page_loaded()      
      self.page.EvaluateXPath("//table[@id='menuContent']//div[contains(text(),'AP Home Office Super User')]")[0].Click() 
      web_utils.log_checkpoint("Click 'AP Home Office Super User' - Successful",500,self.page) 
      self.page.Keys("[Down]")
      self.wait_until_page_loaded()
      self.page.NativeWebObject.Find("contentText","Invoices","A").Click()
      web_utils.log_checkpoint("Click 'Invoices' - Successful",500,self.page) 
      self.page.Keys("[Down]")
      self.wait_until_page_loaded()
      self.page.NativeWebObject.Find("contentText","Entry","A").Click()
      web_utils.log_checkpoint("Click 'Entry' - Successful",500,self.page) 
      self.page.Keys("[Down]")
      self.wait_until_page_loaded()
      self.page.EvaluateXpath("//table[@id='respList']//div[contains(text(),'Invoices')]")[1].Click() 
      web_utils.log_checkpoint("Click 'Invoices' - Successful",500,self.page)
      web_utils.validate_security_box()    
      delay(10000)   
      self.jFrame = self.initializeJFrame()
      Delay(2000)
      form_utils.click_ok_btn(self.jFrame)

#Method for finding Invoice that needs to initated approval
    
  def init_appr(self,val,app):
      jFrame=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1)
      delay(3000)  
      p_names = ("JavaClassName","AWTComponentAccessibleName")
      p_values = ("ExtendedFrame","Invoice Workbench*")
      obj=self.jFrame.Find(p_names,p_values,50)
      if obj.Exists:
        web_utils.log_checkpoint("AP Invoice Page Launched Successfully",500,self.jFrame) 
      else:
        self.log_message_oracle_form(self.jFrame,"Unable to Launch AP Invoice Form") 
      inv_wb_form = self.jFrame.Find(p_names,p_values,20)
      Delay(1000)
      jFrame.Keys("~v")
      delay(1000)
      jFrame.Keys("f")
      delay(1000)
      web_utils.log_checkpoint("Navigate to Find Invoices Form Successful",500,self.jFrame) 
      p_names = ("JavaClassName","AWTComponentAccessibleName")
      p_values = ("ExtendedFrame","Find Invoices")
      find_inv_form=self.jFrame.FindChildEx(p_names,p_values,40,True,7000)      
      if find_inv_form.Exists:
        web_utils.log_checkpoint("Find Invoices Form Launched Successfully",500,self.jFrame)
      else:
        self.log_message_oracle_form(self.jFrame,"Unable to Launch Find Invoices Form") 
      Delay(1000)    
      pro = ("AWTComponentIndex","AWTComponentAccessibleName")
      values = (6,"Invoice: Number") 
      Delay(1000)      
      find_inv_form.FindChild(pro,values,20).Click()
      delay(1000)
      find_inv_form.FindChild(pro,values,20).SetText(val)
      Delay(1000)
      values = (3,"Find alt i")
      Delay(1000)
      find_inv_form.FindChild(pro,values,20).Click()
      Delay(4000)  
      p_values = ("ExtendedFrame","Invoice Workbench (AP Home Office Super User)")
      obj=self.jFrame.Find(p_names,p_values,50)
      if obj.Exists:
        web_utils.log_checkpoint("AP Invoice form with Invoice Details available",500,self.jFrame)
      else:
        self.log_message_oracle_form(self.jFrame,"Unable to Query Entered Invoice Details")  
      pro = ("AWTComponentIndex","AWTComponentAccessibleName")
      values = (5,"Accounted")
      account_status = inv_wb_form.FindChildEx(pro,values,40,20000).wText
      if(account_status == 'Yes'):
        self.jFrame.Keys("~c")
        delay(2000)
        p_values = ("ExtendedFrame","Invoice Actions")
        fnd_actions = self.jFrame.FindChild(p_names,p_values,20)
        if fnd_actions.Exists:  
          web_utils.log_checkpoint("'Invoice Actions' form launched successfully",500,self.jFrame)
        else:
          self.log_message_oracle_form(self.jFrame,"Unable to open Find Actions Form")
          self.log_error_message("Unable to open Find Actions Form")
        delay(5000)
        self.jFrame.Keys("~n")
        delay(2000)
        p_values = ("Button","OK alt K")
        fnd_actions.FindChild(p_names,p_values,20).Click()
        Delay(13000)
        web_utils.log_checkpoint("Invoice is Accounted: Initiated Approval",500,self.jFrame)
      else:
        self.log_message_oracle_form(self.jFrame,"Invoice is not Accounted: Cannot Initiate Approval")
        self.log_error_message("Invoice not Accounted")
        

#Method for finding Invoice that needs to initated approval
 
  def apr_val(self,app,rowno):        

        pro=("AWTComponentAccessibleName","AWTComponentIndex")
        values=("Invoice Num Required",32)
        inv = self.jFrame.FindChildEx(pro,values,30,True,120000).wText
        delay(1000)        
        p_values = ("Approval",6)
        obj=self.jFrame.FindChildEx(pro,p_values,50,True,120000)
        if obj.wText == "Initiated" or obj.wText == "Not Required":
          web_utils.log_checkpoint("Approval Initiated for AP Invoice: "+inv,500,self.jFrame)
        else:
          self.log_message_oracle_form(self.jFrame,"Current Approval Status: "+obj.wText)
          self.log_error_message("Approval Initiation Failed")
          delay(2000)
        dsn = self.testConfig['man_oracle_db']['dsn']
        user_id = self.testConfig['man_oracle_db']['userid']
        pwd = self.testConfig['man_oracle_db']['pwd']
        inv_id = dbhelper.get_invoice_id(dsn,user_id,pwd,inv)
        delay(1000)
        app.Cells.Item[rowno,17] = inv_id
        self.close_forms(self.jFrame)  
        Delay(2000)  
        
  def multi_inv(self):

        self.wait_until_page_loaded()
        self.jFrame.Keys("[F4]")
        delay(3000)
        self.jFrame.FindChild("AWTComponentAccessibleName","Open alt O",30).Click()
        Delay(3000)
        self.jFrame.FindChild("AWTComponentAccessibleName","Open alt O",30).Click()
        Delay(1000)  
        self.jFrame.Keys("[Down]")
        Delay(1000)
        self.jFrame.Keys("[Enter]")
        delay(10000)
        p_names = ("JavaClassName","AWTComponentAccessibleName")
        p_values = ("ExtendedFrame","Invoice Workbench*")
        obj=self.jFrame.FindChild(p_names,p_values,50)
        if obj.Exists:
          self.log_checkpoint_message_web("AP Invoice Page Launched Successfully")
        else:
          self.log_message_oracle_form(self.jFrame,"Unable to Launch AP Invoice Form")  



