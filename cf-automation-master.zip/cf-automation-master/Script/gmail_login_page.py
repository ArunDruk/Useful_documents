﻿import gvar



def choose_an_account_dropdown():
  return gvar.dataprep['page'].FindChild("contentText","Choose an accou*", 30)
  
def user_dropdown():
  return gvar.dataprep['page'].FindChild("contentText", "caitestautomation user", 20)
  
def username_textfield():
  return gvar.dataprep['page'].FindChild("idStr","identifierId",30)
  
def password_textfield():
  return gvar.dataprep['page'].FindChild("ObjectIdentifier","password",30)
  
def next_button():
  return gvar.dataprep['page'].FindChild("contentText", "Next", 60)
  
def done_button():
  return gvar.dataprep['page'].FindChild('contentText','Done',30)
  
def inbox_link():
  prop=['contentText','ObjectType']
  val = ['Inbox','Link']
  return gvar.dataprep['page'].FindChild(prop,val,60)
  
def remove_an_account():
  prop=['contentText','ObjectType']
  val = ['Remove an account','Panel']
  return gvar.dataprep['page'].FindChild(prop,val,60)

def remove_account():
  prop=['contentText','ObjectType']
  val = ['caiwccautomation@gmail.com','Panel']
  return gvar.dataprep['page'].FindChild(prop,val,60)


def remove_account_popup():
  prop=['contentText','ObjectType']
  val = ['Yes, remove','TextNode']
  return gvar.dataprep['page'].FindChild(prop,val,60)
