﻿#import all_routine_list
from driverchain import *


class Driver(Driverchain):
  global classarr,env
  
  def __init__(self):
    global test_env
    self.test_env="dev3"
    self.classarr=["cai_create_non_catalog_req()"]     
    super().__init__(self.classarr)
	
	
	
	


def main():
  global browser,page
  cobj=Driver().run()

  
  
  
