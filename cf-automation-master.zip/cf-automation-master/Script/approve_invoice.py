﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils
import web_utils



class approve_invoice(Ebiz):
 global rowno
 rowno = 2

 def login(self):
    self.login_user="rmaran"
    super().login()
 
 def goto_url(self,url):
   super().goto_url(self.testConfig['ebiz']['oci_is_url'])
 
 op_log_path="C:\\TC_Logs"
 
 def action(self,book): 
    app = book.Sheets.item["Invoice"]
    web_utils.log_checkpoint("Logged in to Oracle Applications Home Page Successfully",500,self.page)
    self.wait_until_page_loaded()      
    self.page.EvaluateXPath("//table[@id='menuContent']//div[contains(text(),'AP Home Office Super User')]")[0].Click() 
    web_utils.log_checkpoint("Click 'AP Home Office Super User' - Successful",500,self.page) 
    self.page.Keys("[Down]")
    self.wait_until_page_loaded()
    self.page.NativeWebObject.Find("contentText","Invoices","A").Click()
    web_utils.log_checkpoint("Click 'Invoices' - Successful",500,self.page) 
    self.page.Keys("[Down]")
    self.wait_until_page_loaded()
    self.page.NativeWebObject.Find("contentText","Entry","A").Click()
    web_utils.log_checkpoint("Click 'Entry' - Successful",500,self.page) 
    self.page.Keys("[Down]")
    self.wait_until_page_loaded()
    self.page.EvaluateXpath("//table[@id='respList']//div[contains(text(),'Invoices')]")[1].Click() 
    web_utils.log_checkpoint("Click 'Invoices' - Successful",500,self.page)
    web_utils.validate_security_box()   
    jFrame = self.initializeJFrame()
    Delay(2000)
    form_utils.click_ok_btn(jFrame)
    delay(5000)
    jFrame.Keys("~v")
    delay(1000)
    jFrame.Keys("f")
    delay(1000)
    invoice_no = BuiltIn.ParamStr(16)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Invoices","ExtendedFrame"]
    par_form=jFrame.FindChildEx(prop,val,60,True,60000)
    par_form.Find("AWTComponentAccessibleName","Invoice: Number",10).Click()
    par_form.Find("AWTComponentAccessibleName","Invoice: Number",10).Keys(invoice_no)
    jFrame.Keys("~i")
    Delay(25000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Invoice Workbench*","ExtendedFrame"]
    inv_wrk_bench_frm=jFrame.FindChildEx(prop,val,60,True,90000)        
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Type Required",8]
    inv_type=inv_wrk_bench_frm.FindChildEx(prop,val,60,True,90000)
    Log.Enabled=True
    aqObject.CheckProperty(inv_type,"wText",cmpIn,"Standard")
    Log.Enabled=False
    self.log_message_oracle_form(jFrame,"Invoice found Successfully")
    delay(10000) 
    jFrame.Keys("~c")
    delay(1500)
    jFrame.Keys("~f")
    delay(1000)
    jFrame.Keys("~k")
    delay(10000)
    jFrame.Keys("^s")
    delay(2000)        
    p_names = ("JavaClassName","AWTComponentAccessibleName")
    p_values = ("VTextField","Status")
    obj=jFrame.FindChildEx(p_names,p_values,50,True,60000)
    if obj.wText == "Validated":
     self.log_checkpoint_message_web("Invoice is Validated and Approved Successfully")
    else:
     self.log_message_oracle_form(jFrame,"Check for Invoice Holds & Re-Validate")
      # Close Forms
    jFrame.Keys("[F4]")
    Delay(2000)
    jFrame.Keys("[F4]")
    Delay(2000)
    jFrame.Keys("~o")
    Delay(2000)
