﻿from datetime import datetime

def __get_current_time_stampe_with_timezone():
     from datetime import datetime
     return datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%f")

def __get_current_date_YYYY_MM_DD():
     from datetime import datetime   
     return datetime.now().strftime("%Y-%m-%d")
     
def __get_current_date_YYYY_MON_DD():
     from datetime import datetime   
     return datetime.now().strftime("%Y-%b-%d")
 
def __get_current_year():
   import datetime
   return (datetime.datetime.now().year)

def __get_current_week():
     import datetime 
     return (str(datetime.date.today().isocalendar()[1]))
     
def __get_current_date_MM_DD():
     from datetime import datetime   
     return datetime.now().strftime("%m_%d")

