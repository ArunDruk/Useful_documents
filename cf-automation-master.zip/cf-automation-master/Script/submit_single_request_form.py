﻿import gvar
import form_utility 

def submit_request_extended_frame():
    return form_utility.find_object_by_awtcomponentaccessiblename('Submit Request')
  
def request_name_textfield():
    return form_utility.find_object_by_awtcomponentaccessiblename('Name RequiredList of Values')

def auction_location_textfield():
    return form_utility.find_object_by_awtcomponentaccessiblename('Auction Location List Values')
  
def submit_button():
    return form_utility.find_object_by_awtcomponentaccessiblename('Submit alt m')
  
def cancel_button():
    return form_utility.find_object_by_awtcomponentaccessiblename('Cancel alt n')
  
def delivery_opts_button():
    return form_utility.find_object_by_awtcomponentaccessiblename('Delivery Opts alt y')

def ok_button():
    return form_utility.find_object_by_awtcomponentaccessiblename('OK ALT O')


