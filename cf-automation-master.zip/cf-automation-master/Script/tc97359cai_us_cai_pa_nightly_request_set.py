﻿import dbhelper
from ebiz import *
import web_utils
import dbhelper
import file_system_utils 
import form_utils
                        
class tc97359cai_us_cai_pa_nightly_request_set(Ebiz):
   op_log_path="C:\\Tc_Logs"
                        
   def login(self):
     self.login_user='rmaran'
     super().login()
                           
   def action(self,book): 
     global rowno      
     rowno = 2            
     app = book.Sheets.item["Requisition"]
     app1 = book.Sheets.item["Invoice"]      
     web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" PA JOB SCHEDULER')]")
     self.log_message_web("Click 'CAI "+self.oper_unit+" PA JOB SCHEDULER' - Successful")
     Delay(3000)
     self.page.wait()
     web_utils.clk_link_by_xpath(self.page,"//div[contains(text(),'Submit Request')]")
     self.log_message_web("Click 'Submit Request' - Successful")
     Delay(10000)
     web_utils.validate_security_box()
     Delay(10000)
     jFrame=self.initializeJFrame()
     Delay(3000)
     form_utils.click_ok_btn(jFrame)  
     Delay(30000)
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Submit a New Request","ExtendedFrame"]
     jFrame.FindChildEx(prop,val,40,True,90000)
     Delay(2000)
     jFrame.keys("~s")
     Delay(2000)
     jFrame.keys("~o")                    
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Submit Request Set","ExtendedFrame"]
     submitrequest_form=jFrame.FindChildEx(prop,val,60,True,40000)
     self.verify_aqobject_chkproperty(submitrequest_form,"AWTComponentAccessibleName",cmpContains,"Submit Request Set") 
     submitrequest_form.Find("AWTComponentAccessibleName","Request Set RequiredList of Values",10).SetText("CAI PA Nightly Request Set")
     submitrequest_form.Keys("[Tab]")
     proj_no=VarToStr(app.Cells.item[rowno,11])
     self.submit_req_set_params(submitrequest_form,jFrame,15,VarToStr(proj_no),"N")
     Delay(1000)
     self.submit_req_set_params(submitrequest_form,jFrame,16,VarToStr(proj_no),"N")   
     self.submit_req_set_params(submitrequest_form,jFrame,17,VarToStr(proj_no),"Y")   
     self.submit_req_set_params(submitrequest_form,jFrame,18,VarToStr(proj_no),"Y")   
     self.submit_req_set_params(submitrequest_form,jFrame,19,VarToStr(proj_no),"Y")   
     jFrame.Keys("[Down]")
     self.submit_req_set_params(submitrequest_form,jFrame,19,VarToStr(proj_no),"N")   
     Delay(1000)   
     self.log_message_oracle_form(jFrame,"Ready to Submit the CAI PA Nightly Request Set")
     Delay(1000) 
     submitrequest_form.Find("AWTComponentAccessibleName","Submit",10).Click()
     Delay(2000)
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Decision Request submitted*","ChoiceBox"]
     decision_form=jFrame.FindChildEx(prop,val,60,True,40000)
     self.verify_aqobject_chkproperty(decision_form,"AWTComponentAccessibleName",cmpContains,"Request submitted") 
     RequestID = ''.join(x for x in decision_form.AWTComponentAccessibleName if x.isdigit())
     self.log_message_oracle_form(jFrame,"Request ID " + aqConvert.VarToStr(RequestID))   
     Delay(2000)
     jFrame.Keys("~n")  
     Delay(2000)        
     dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
     user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
     pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
     dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,RequestID) 
     jFrame.Keys("~v")
     Delay(2000)
     jFrame.Keys("r")
     Delay(2000)
     
#     jFrame.Keys("~i")
#     Delay(2000) 
     jFrame.Keys("~s")
     Delay(2000)
     jFrame.Keys("[Tab]")
     delay(1000)
     jFrame.Keys(RequestID)
     delay(1000)
     jFrame.Keys("~q")
     delay(1000)
     jFrame.Keys("~i")
     Delay(2000)  
     
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Requests","ExtendedFrame"]
     req_form=jFrame.FindChildEx(prop,val,30,True,40000)  
     #form_utils.req_set_save_output(self,jFrame,req_form,"PRC: Generate Cost Accounting Events",RequestID)  
#    # Comment below after debug 
#     RequestID="27555720" 
#     jFrame=self.initializeJFrame() 
#     prop=["AWTComponentAccessibleName","JavaClassName"]
#     val=["Requests","ExtendedFrame"]
#     req_form=jFrame.FindChildEx(prop,val,30,True,40000)  
#     
#     # Comment above after debug 
     #RequestID="27555720" # Comment it later
     self.req_set_save_output(jFrame,req_form,"PRC: Generate Cost Accounting Events",RequestID)
     Delay(1000)
     # Just for debug, Uncomment later - Uday
     jFrame.Keys("~w") 
     Delay(2000)
     jFrame.Keys("2") 
     self.req_set_save_output(jFrame,req_form,"PRC: Distribute Supplier Cost Adjustments",RequestID)  #form_utils.req_set_save_output(self,jFrame,req_form,"PRC: Distribute Supplier Cost Adjustments",RequestID) #self.req_set_save_output(jFrame,req_form,"PRC: Distribute Supplier Cost Adjustments") 
     Delay(1000)
     jFrame.Keys("~w") 
     Delay(2000)
     jFrame.Keys("2")
#     self.req_set_save_output(jFrame,req_form,"PRC: Distribute Usage and Miscellaneous Costs",RequestID)
#     Delay(1000)
#     
#     jFrame.Keys("~w") 
#     Delay(1000)
#     jFrame.Keys("2")
#     self.req_set_save_output(jFrame,req_form,"PRC: Distribute Labor Costs",RequestID)  
#     Delay(1000)
#     jFrame.Keys("~w") 
#     Delay(1000)
#     jFrame.Keys("2")
#     self.req_set_save_output_sup_costs_intf_audt(jFrame,req_form,"AUD: Supplier Costs Interface Audit")
#     Delay(1000)
#     jFrame.Keys("~w") 
#     Delay(1000)
#     jFrame.Keys("[Down]")
#     jFrame.Keys("[Down]")
#     jFrame.Keys("[Down]")
#     jFrame.Keys("[Down]")
#     Delay(1000)
#     jFrame.Keys("[Enter]")
#     Delay(1000)
     jFrame.Keys("[F4]")
     Delay(2000) 
     jFrame.Keys("~c")
     Delay(2000)
     jFrame.Keys("~f")
     Delay(1000)
     jFrame.Keys("w")
     Delay(3000)
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Responsibilities","FWindow"]
     resp_form=jFrame.FindChildEx(prop,val,30,True,40000)
     resp_form.Find("AWTComponentName","LWTextField*",10).Click()
     Delay(1000)
     resp_form.Find("AWTComponentName","LWTextField*",10).Keys("[BS]")
     Delay(1000)
     resp_form.Find("AWTComponentName","LWTextField*",10).keys("CAI "+self.oper_unit+" PA PROJECT CONTROLS")
     self.log_message_oracle_form( jFrame,"Changed the responsibility to CAI "+self.oper_unit+" PA PROJECT CONTROLS")
     Delay(2000)
     resp_form.Find("AWTComponentName","LWTextField*",10).Click()    
     Delay(2000)
     jFrame.Keys("~f")
     self.log_message_oracle_form( jFrame,"Navigation Details")
     Delay(3000)
     jFrame.keys("e")
     Delay(1000)
     jFrame.keys("e")
     Delay(1000)
     jFrame.keys("~o")
     Delay(3000)
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Find Project Expenditure Items","ExtendedFrame"]
     proj_exp_form=jFrame.FindChildEx(prop,val,30,True,40000) 
     proj_exp_form.Find("AWTComponentAccessibleName","Project NumberList of Values",20).keys(app.Cells.item[rowno,11])
     self.log_message_oracle_form( jFrame,"Entered Project Number in Project Expenditure Items screen : "+ VarToStr(app.Cells.item[rowno,11])) 
     self.verify_aqobject_chkproperty(proj_exp_form,"AWTComponentAccessibleName",cmpContains,"Find Project Expenditure Items")
     Delay(2000)
     proj_exp_form.Find("AWTComponentName","FormsTabPanel*",20).ClickTab("Supplier")
     self.log_message_oracle_form( jFrame,"Supplier Tab Detail")
     Delay(2000)
#     proj_exp_form.Find("AWTComponentAccessibleName","*Invoice NumberList of Values",20).SetText(app1.Cells.item[rowno,13])
#     self.log_message_oracle_form( jFrame," Entered Invoice Number Project Expenditure Items screen: "+ VarToStr(app1.Cells.item[rowno,13]))
     
     proj_exp_form.Find("AWTComponentAccessibleName","*Supplier NameList of Values",20).SetText(app.Cells.item[rowno,9])
     self.log_message_oracle_form( jFrame," Entered Supplier Name in Project Expenditure Items screen: "+ VarToStr(app.Cells.item[rowno,9]))
  
     jFrame.keys("~i")
     self.log_message_oracle_form( jFrame,"View Project Expenditure Items Screen Successful")
     Delay(5000)
     jFrame.keys("~d")
     self.log_message_oracle_form(jFrame,"Click Item Details Button on Project Expenditure Items Screen Successful")
     Delay(3000)
     jFrame.keys("~o")
     Delay(2000)
     self.log_message_oracle_form( jFrame,"Cost Distribution Lines")
     jFrame.Keys("~w")
     delay(1000)
     jFrame.Keys("3")
     delay(2000)
     jFrame.keys("~d")
     delay(2000)
     jFrame.keys("a")
     Delay(3000)
     jFrame.keys("~o")
     Delay(7000)
     self.log_message_oracle_form( jFrame,"Invoice Verified")
#     jFrame.Keys("[F4]")
#     Delay(2000)
#     jFrame.Keys("[F4]")
#     Delay(2000)
#     jFrame.Keys("[F4]"))
     jFrame.Close()
     delay(3000)
     self.log_message_oracle_form(jFrame,"Successfully applied close action - Java Forms")
     prop = ["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
     val = ["Caution Exit Oracle Applications?","ChoiceBox",0]
     if jFrame.FindChild(prop,val,20).Exists:
       self.log_message_oracle_form(jFrame,"Forms Closing Confirmation window found")
       jFrame.Keys("~o")
       
     else:
       self.log_error_message("Forms Closing Confirmation window not found")
     Delay(2000)
     web_utils.close_additional_browsers()
     #Sys.Browser("iexplore").page("https://core-*.epfinnp.coxautoinc.com/forms/frmservlet*").Close()
     del app,app1,jFrame,proj_exp_form,rowno,
                           
                         
                           
   def submit_req_set_params(self,submitrequest_form,jFrame,index_no,proj_no,tab):
     prop=["AWTComponentAccessibleName","AWTComponentIndex"]
     val=["Parameters",index_no]
     submitrequest_form.FindChild(prop,val,60).Click()
     Delay(2000)   
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Parameters","FlexWindow"]   
     parameter_form=jFrame.FindChild(prop,val,10)
     if tab=='Y':
        parameter_form.Keys("[Tab]")
     parameter_form.Keys(proj_no)
     parameter_form.Keys("~o")
     Delay(1000)

                        
   def req_set_save_output(self,jFrame,req_form,srch_child_name,Preqid):
     i=20
     for x in range(i,50):
       prop=["AWTComponentAccessibleName","AWTComponentIndex"]
       val=["Name",x]
       child_name=req_form.Find(prop,val,10)
       child_name.Keys("[Enter]")
       child_name.Click()
       child_name=child_name.wText
          
       if x>20:
          jFrame.Keys("[Down]") 
          
          Delay(1000)
          prop=["AWTComponentAccessibleName","AWTComponentIndex"]
          val=["Phase",i+20]
          phase=req_form.Find(prop,val,10).wText 
          prop=["AWTComponentAccessibleName","AWTComponentIndex"]
          val=["Request ID",i-10]
          creqid=VarToInt(req_form.Find(prop,val,10).wText)     
       if (child_name==srch_child_name) and (creqid >= VarToInt(Preqid)) and (phase == "Completed"):
#         Delay(500)
#         req_form.Find(prop,val,10).Keys("[Enter]")
         Delay(600)
         prop=["AWTComponentAccessibleName","JavaClassName"]
         val=["View Output alt p","Button"]
         output_button=req_form.FindChild(prop,val,60)
         output_button.Find("AWTComponentAccessibleName","View Output alt p").Click()         
         #jFrame.Keys("~p")    
         Delay(3000)
         output_page=Sys.Browser("iexplore").Page("https://core-*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")            
         output_page.Click()
         Delay(2000)
         output_page.Keys("~f")
         Delay(6000)
         output_page.Keys("a")
         Delay(6000)
         file_system_utils.create_folder(self.op_log_path)             
         log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"Is Attached_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
         Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
         Delay(1000)
         Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
         Delay(2000)
         Log.Enabled=True
         Log.File(log_path, aqConvert.VarToStr(srch_child_name)+" Program is completed and Output File Is Attached")
         Log.Enabled=False       
         Sys.Browser("iexplore").page("https://core-*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close()  
         Delay(2000)   
#         jFrame.Click()
         Delay(2000)
         val=["Name",20]
         req_form.Find(prop,val,10).Keys("[Enter]")
         Delay(500)
         break  
                        
                        
   def req_set_save_output_sup_costs_intf_audt(self,jFrame,req_form,srch_child_name):
       i=20
       found=0     
       for x in range(20,51):
         if x>29:
            jFrame.Keys("[Down]")        
            x=29
         prop=["AWTComponentAccessibleName","AWTComponentIndex"]
         val=["Name",x]
         child_name=req_form.Find(prop,val,10).wText
         req_form.Find(prop,val,10).Click()  
         if child_name == srch_child_name:
           found+=1  
         if (child_name==srch_child_name) and found==2: 
           req_form.Find(prop,val,10).Keys("[Enter]")
           Delay(1000)
           #jFrame.Keys("~p") 
           prop=["AWTComponentAccessibleName","JavaClassName"]
           val=["View Output alt p","Button"]
           output_button=req_form.FindChild(prop,val,60)
           output_button.Find("AWTComponentAccessibleName","View Output alt p").Click()     
           Delay(3000)
           output_page=Sys.Browser("iexplore").Page("https://core-*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
           output_page.Click()
           Delay(2000)
           output_page.Keys("~f")
           Delay(2000)
           output_page.Keys("a")
           Delay(5000)
           file_system_utils.create_folder(self.op_log_path)             
           log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"Is Attached_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
           Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
           Delay(1000)
           Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
           Delay(6000)
           Log.Enabled=True
           Log.File(log_path, "Supplier Cost Interface Audit Output File Attached")
           Log.Enabled=False    
           Sys.Browser("iexplore").page("https://core-*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close()  
           Delay(2000)   
           jFrame.Click()
           Delay(2000)
           break
                        
   def submit_req_set_params(self,submitrequest_form,jFrame,index_no,proj_no,tab):
       prop=["AWTComponentAccessibleName","AWTComponentIndex"]
       val=["Parameters",index_no]
       submitrequest_form.FindChild(prop,val,60).Click()
       Delay(2000)   
       prop=["AWTComponentAccessibleName","JavaClassName"]
       val=["Parameters","FlexWindow"]   
       parameter_form=jFrame.FindChild(prop,val,10)
       if tab=='Y':
          parameter_form.Keys("[Tab]")
       parameter_form.Keys(proj_no)
       parameter_form.Keys("~o")
       Delay(1000) 
       
def test():
  
   jFrame = Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1)
   jFrame.keys("~i")
#   self.log_message_oracle_form( jFrame,"View Project Expenditure Items Screen Successful")
   Delay(5000)
   jFrame.keys("~d")
#   self.log_message_oracle_form(jFrame,"Click Item Details Button on Project Expenditure Items Screen Successful")
   Delay(3000)
   jFrame.keys("~o")
   Delay(2000)
#   self.log_message_oracle_form( jFrame,"Cost Distribution Lines")
   jFrame.Keys("~w")
   delay(1000)
   jFrame.Keys("3")
   delay(2000)
   jFrame.keys("~d")
   delay(2000)
   jFrame.keys("a")
   Delay(3000)
   jFrame.keys("~o")
   Delay(6000)
#   self.log_message_oracle_form( jFrame,"Invoice Verified")
        
     

