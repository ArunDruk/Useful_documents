﻿from ebiz import *
import form_utils
#Author:            Prabhakaran Rajendran
#TestCaseID:        TC84510 && TC16320
#UserStoryID:       US192318 && US126471
#Reviewed_By:       Husain Syed & Seelam Lakshmi



class tc84510cai_us_create_manual_ap_invoice_match(Ebiz):
  global login_user
  
  def login(self):
    self.login_user="rmaran"
    super().login()
    
  def action(self,book):
      global rowno, app, p_names
      rowno=2     
      app = book.Sheets.item["Invoice"]
      RowCount = app.UsedRange.Rows.Count
      p_names = ("JavaClassName","AWTComponentAccessibleName")      
#      while (rowno<RowCount+1):          
#        if rowno == 2:
#          self.nav_ap1(p_names)
##        else:
##          self.multi_inv()
#
#        self.ap_inv_hdr(p_names)
#        self.ap_inv_lns(p_names)
#        self.ap_inv_val(p_names)  
#        rowno = rowno + 1
      
      self.nav_ap1(p_names)
      self.ap_inv_hdr(p_names)
      self.ap_inv_lns(p_names)
      self.ap_inv_val(p_names)  
      
      delay(1000)
      book.save()
      del app,RowCount,p_names
#      delay(1000)
#      book.close()
#      delay(1000)
#      p.Terminate()
#      delay(1000)
#      self.close_forms()
     
  
  def nav_ap1(self,p_names): 
      self.log_message_web("Logged in to Oracle Applications Home Page")  
#      self.page.wait()
      self.wait_until_page_loaded()    
      self.page.NativeWebObject.Find("contentText","CAI "+self.oper_unit+" AP INVOICE PROCESSING","A").scrollIntoView()
      delay(1000)  
      self.page.NativeWebObject.Find("contentText","CAI "+self.oper_unit+" AP INVOICE PROCESSING","A").Click()
      delay(2000)
      self.page.wait()
      self.wait_until_page_loaded()
      self.page.NativeWebObject.Find("contentText","Invoices","A").Click()
      delay(2000)
      self.page.NativeWebObject.Find("contentText","Entry","A").Click()
      delay(2000)  
      self.page.EvaluateXpath("//table[@id='respList']//div[contains(text(),'Invoices')]")[1].Click()   
#      delay(3000)
#      web_utils.validate_security_box()
#      delay(10000)     
#      self.jFrame=Sys.Browser("iexplore").WaitSwingObject("JBufferedFrame", "*", -1, 60000)
#      Delay(5000
##      self.jFrame=Sys.Browser("iexplore").SwingObject("JBufferedFrame", "*", -1, 1)
#      self.jFrame.Keys("~o")
      web_utils.validate_security_box()
      self.jFrame = self.initializeJFrame()
      Delay(2000)
      form_utils.click_ok_btn(self.jFrame)
      delay(5000)
      p_values = ("ExtendedFrame","Invoice Workbench (CAI "+self.oper_unit+" AP INVOICE PROCESSING)")

      obj=self.jFrame.FindChild(p_names,p_values,50)
      if obj.Exists:
        self.log_checkpoint_message_web("AP Invoice Page Launched Successfully")
      else:
        self.log_message_oracle_form(self.jFrame,"Unable to Launch AP Invoice Form")
        
  def multi_inv(self):

        self.wait_until_page_loaded()
        self.jFrame.Keys("[F4]")
  #      delay(2000)
  #      self.jFrame.Find("AWTComponentAccessibleName","Yes ALT Y").Click()
        delay(3000)
        self.jFrame.Find("AWTComponentAccessibleName","Open alt O",30).Click()
        Delay(3000)
        self.jFrame.Find("AWTComponentAccessibleName","Open alt O",30).Click()
        Delay(1000)  
        self.jFrame.Keys("[Down]")
        Delay(1000)
        self.jFrame.Keys("[Enter]")
        delay(10000)
        p_names = ("JavaClassName","AWTComponentAccessibleName")
        p_values = ("ExtendedFrame","Invoice Workbench (CAI "+self.oper_unit+" AP INVOICE PROCESSING)")
        obj=self.jFrame.Find(p_names,p_values,50)
        if obj.Exists:
          self.log_checkpoint_message_web("AP Invoice Page Launched Successfully")
        else:
          self.log_message_oracle_form(self.jFrame,"Unable to Launch AP Invoice Form")    

            
  def ap_inv_hdr(self,p_names):   
#
#      self.page.wait_until_page_loaded()     
      self.jFrame.Keys("~l")
      Delay(1000)
      self.jFrame.Keys("o")
      delay(3000)
#      self.page.wait_until_page_loaded() 
      prop=["AWTComponentAccessibleName","JavaClassName"]
      val=["Open Folder","FWindow"]
      open_fldr_form=self.jFrame.FindChildEx(prop,val,30,True,60000)
      delay(1000)
      prop=["JavaClassName","AWTComponentAccessibleName","AWTComponentIndex"]
      val=["LWTextField"," Find",0]
      fnd=open_fldr_form.FindChildEx(prop,val,30,True,6000)
      fnd.Click()
      fnd.SetText("*A")
      delay(2300)
#      fnd.Keys("~o")
#      val=["PushButton","OK ALT O",0]
#      ok_button = open_fldr_form.FindChild(prop,val,20)
      Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("FWindow", "Open Folder", 0).AWTObject("LWComponent", "", 0).AWTObject("EwtContainer", "", 0).AWTObject("ButtonBar", "", 0).AWTObject("ButtonBar", "", 1).AWTObject("PushButton", "OK ALT O", 0).Click()
#      Sys.HighlightObject(ok_button)    
#      ok_button.Click()
      delay(3000)
      prop=["AWTComponentAccessibleName","JavaClassName"]
      val=["Invoice Workbench*","ExtendedFrame"]
      inv_wb_form=self.jFrame.FindChild(prop,val,60)
      p_values = ("VTextField","Trading Partner/Supplier Name RequiredList of Values")
      obj=inv_wb_form.Find(p_names,p_values,50)
      if obj.Exists:
        self.log_checkpoint_message_web("AP Invoice Header template selected successfully")
      else:
        self.log_message_oracle_form(self.jFrame,"Unable to Launch Required Header Template for Creating Invoice")
      
      p_values = ("VTextField","PO NumberList of Values")
      inv_wb_form.Find(p_names,p_values,30).Click()
      inv_wb_form.Find(p_names,p_values,30).Keys(app.Cells.Item[rowno,14])
      delay(2000)
#      p_values = ("VTextField","RequesterList of Values")
##      self.jFrame.Find(p_names,p_values,30).Click()
#      inv_wb_form.Find(p_names,p_values,30).SetText(app.Cells.Item[rowno,2])
#      delay(5000)      
      p_values = ("VTextField","Invoice Date RequiredList of Values")
      inv_wb_form.Find(p_names,p_values,30).Click()
      delay(2000)
#      inv_wb_form.Keys("[TAB]")
#      delay(2000)
      pi_names = ("JavaClassName","AWTComponentAccessibleName","AWTComponentIndex")
      p_values = ("VTextField","Invoice Num Required",32)
      Delay(1000)
      inv_wb_form.Find(pi_names,p_values,10).Click()
      inv_name = ("TST_INV: "+aqConvert.DateTimeToFormatStr(aqDateTime.Time(),"%H:%M:%S"))
      inv_wb_form.FindChild(pi_names, p_values, 20).SetText(inv_name)

      delay(1000)
      inv_wb_form.Keys("[TAB]")
      delay(1000)      
      p_values = ("VTextField","Invoice Amount Required",40)
      inv_wb_form.Find(pi_names,p_values,10).Click()
      delay(1000)
      inv_wb_form.Find(pi_names,p_values,10).Keys(app.Cells.Item[rowno,15])
      delay(1000)
      inv_wb_form.Keys("[TAB]")
      p_values = ("VTextField","Terms RequiredList of Values",112)
      delay(1000)
      inv_wb_form.Find(pi_names,p_values,20).Click()
      delay(1000)
      inv_wb_form.Find(pi_names,p_values,20).SetText("Immediate")
      delay(1000)
      inv_wb_form.Keys("[TAB]")
      p_values = ("VTextField","Payment Method RequiredList of Values",116)
      inv_wb_form.Find(pi_names,p_values,20).Click()
      delay(1000)
      inv_wb_form.Find(pi_names,p_values,20).SetText(app.Cells.Item[rowno,21])
      delay(1000)
      inv_wb_form.Keys("[TAB]")
      Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("FlexWindow1303").AWTObject("LWComponent", "", 0).AWTObject("LWContainer", "", 0).AWTObject("LWContainer", "", 0).AWTObject("LWContainer", "", 0).AWTObject("LWContainer", "", 1).AWTObject("FormButton7").Click()
      delay(1000)
      self.log_message_oracle_form(self.jFrame,"Invoice Header Details Entered Successfully")
      
  def ap_inv_lns(self,p_names):
      delay(1000)

      self.jFrame=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1,1)
      prop=["AWTComponentAccessibleName","JavaClassName"]
      val=["Invoice Workbench*","ExtendedFrame"]
      inv_wb_form=self.jFrame.FindChild(prop,val,30)     
      delay(2000)
      val = ["Match alt M","Button"]
      inv_wb_form.FindChild(prop,val,10).Click()
      Delay(4000)
      
      val = ["Find Purchase Orders for Matching *","ExtendedFrame"]
      find_po_form = self.jFrame.FindChild(prop,val,30) 
      delay(2000)
      val = ["Find alt i","Button"]
      
#      find_po_form.FindChild(prop,val,20).Click()
      self.jFrame.Keys("~i")
      Delay(4000)
      
      p_values = ("ExtendedFrame","Match to Purchase Orders*")
      obj=self.jFrame.FindChildEx(p_names,p_values,50,True,10000)      
      if obj.Exists:
        self.log_checkpoint_message_web("PO Match Form Launched Successfully")
      else:
        self.log_message_oracle_form(self.jFrame,"Unable to Launch PO Match Form to match Invoice")
        
      delay(1000)
#      self.jFrame.Find("AWTComponentName", "CheckBox118",30).HoverMouse()
      lines = aqConvert.StrToInt((app.Cells.Item[rowno,16]).Text)
      temp = 0
      index = 0 
#      crt_qty = 2
      var = VarToStr(app.Cells.item[rowno,19])
      var1 = var.split(',')
      for x in range(0,lines):
        Delay(2000)
        self.jFrame.Keys(" ")
        delay(2000)
        p_values = ["ChoiceBox","Note *"]
        conf_box = self.jFrame.FindChild(p_names,p_values,20)
        if conf_box.Exists:
          self.log_message_oracle_form(self.jFrame,"Payment Terms Confirmation Box Exists")
          Sys.HighlightObject(conf_box)
          delay(2000)
          p_values = ["FormButton","OK ALT O"]
          conf_box.FindChild(p_names,p_values,20).Click()
          self.log_message_oracle_form(self.jFrame,"Accepted Payment Term Confirmation")
        delay(1000)
        p1_names = ("AWTComponentIndex","AWTComponentAccessibleName")
        p_values = (index,"Qty Invoiced Required")
        obj.FindChild(p1_names,p_values,30).Click()
        obj.FindChild(p1_names,p_values,30).SetText(var1[index])
        self.jFrame.Keys("[TAB]")
        delay(1000)
        self.log_message_oracle_form(self.jFrame,"Selected PO Line no: "+aqConvert.IntToStr(index+1))
        p_values = (20+index,"Match Amount Required")
        obj.Find(p1_names,p_values,30).Click()
        delay(1000)
        amount = obj.Find(p1_names,p_values,30).wText
        temp = temp + aqConvert.StrToInt(amount)
        delay(1000)
        self.jFrame.Keys("[Down]")
        index = index+1
#        crt_qty = crt_qty+1
        
      prop=["AWTComponentAccessibleName","JavaClassName"]
      val=["Match to Purchase Orders *","ExtendedFrame"]
      match_po_form=self.jFrame.FindChild(prop,val,30) 
      delay(2000)
      val = ["Match alt M","Button"]
      match_po_form.FindChild(prop,val,20).Click()
      
      delay(5000)
      p_values = ("VTextField","Total")      
      obj = self.jFrame.FindChild(p_names,p_values,30)
      if aqConvert.StrToInt(obj.wText) == temp:
        self.log_checkpoint_message_web("PO Matched to AP Invoice Successfully")
      else:
        self.log_message_oracle_form(self.jFrame,"Difference found in 'Invoice Lines Total' & 'Match Form Total'")

        
        
  def ap_inv_val(self,p_names):

        self.jFrame.FindChild("AWTComponentName","FormsTabPanel1",30).ClickTab("1 General")
        delay(1000)
        self.jFrame.Keys("~c")
        delay(1500)
        self.jFrame.Keys("~v")
        delay(1000)
        self.jFrame.Keys("~k")
        delay(10000)
        self.jFrame.Keys("^s")
        delay(2000)
        pro=("AWTComponentAccessibleName","AWTComponentIndex")
        values=("Invoice Num Required",32)
        inv = self.jFrame.FindChild(pro,values,30).wText
        self.log_message_oracle_form(self.jFrame,"AP Invoice created SuccessFully :"+inv)
        delay(1000)        
        app.Cells.Item[rowno,13] = inv
#        book.save()        
        p_names = ("JavaClassName","AWTComponentAccessibleName")
        p_values = ("VTextField","Status")
        obj=self.jFrame.FindChild(p_names,p_values,50)
        if obj.wText == "Validated":
          self.log_checkpoint_message_web("Invoice Validated Successfully")
        else:
          self.log_message_oracle_form(self.jFrame,"Check for Invoice Holds & Re-Validate")
        # Close Forms
        self.jFrame.Keys("[F4]")
        Delay(2000)
        self.jFrame.Keys("[F4]")
        Delay(2000)
        self.jFrame.Keys("~o")
        Delay(2000)
#        Sys.Browser("iexplore").page("https://core-*.epfinnp.coxautoinc.com/forms/frmservlet?*").Close() 
#        Delay(2000)
        
def test1():
  
  prop = ["AWTComponentAccessibleName","AWTComponentName"]
  val = ["Cancel alt C","Button*"]
#  Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications - Stage", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("ExtendedFrame", "Retirements", 15).Click()
  Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications - Stage", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("ExtendedFrame", "Retirements", 15).FindChild(prop,val,10).Keys("~C")

 

  #Sys.HighlightObject(Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications - Stage", -1, 1).FindChild(prop,val,1000))
  #Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications - Stage", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("ExtendedFrame", "Retirements", 15).FindChild(prop,val,1000).Keys("~C")
def test2():
    p_names =  ["JavaClassName","AWTComponentAccessibleName","AWTComponentIndex"]
    p_values = ["VTextField","Invoice Num Required",32]
    Delay(1000)
    inv_name = ("TST_INV: "+aqConvert.DateTimeToFormatStr(aqDateTime.Time(),"%H:%M:%S"))
    Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications - Stage", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("ExtendedFrame", "Invoice Workbench (CAI US AP INVOICE PROCESSING)", 24).FindChild(p_names,p_values,10).SetText(inv_name)
    Delay(2000)
    jFrame=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1,1)
    jFrame.Keys("~m")
    
def test3():
  
#      Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("FWindow", "Open Folder", 0).AWTObject("LWComponent", "", 0).AWTObject("EwtContainer", "", 0).AWTObject("ButtonBar", "", 0).AWTObject("ButtonBar", "", 1).AWTObject("PushButton", "OK ALT O", 0).Click()
      Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("FWindow", "Open Folder", 0).AWTObject("LWComponent", "", 0).AWTObject("EwtContainer", "", 0).AWTObject("ButtonBar", "", 0).AWTObject("ButtonBar", "", 1).AWTObject("PushButton", "OK ALT O", 0).Click()
      Sys.HighlightObject(ok_button)    
      ok_button.Click()

