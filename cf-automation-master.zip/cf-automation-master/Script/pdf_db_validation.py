﻿import bill_of_sale_query
import invoice_query
import database_service
import gvar
import pdf_utility
import tc_logs

def count_validation():
    tc_logs.validation("PDF Vs DB VALIDATION".center(70,'*'))
    if(gvar.dataprep['document_type'] == 'BOS'):
        sql_count,rows = bill_of_sale_query.oracle_sql_count_bos()
    elif(gvar.dataprep['document_type'] == 'INV' or gvar.dataprep['document_type'] == 'INVOICE'):
        sql_count,rows = invoice_query.oracle_sql_count_inv()
    pdf_count, docobj = pdf_utility.loadpdf()
    page = 1
    second_page_count = 0
    for count in range(0,pdf_count):
        stripper =  JavaClasses.org_apache_pdfbox_text.PDFTextStripper.newInstance()
        stripper.setStartPage(page)
        stripper.setEndPage(page)
        text = stripper.getText(docobj)   
        t = VartoStr(text)
        res = aqString.Find(t,"Yr Wk Ln Rn")
        if(res == -1):
            second_page_count+=1
        Log.Message(page)       
        page+=1
        tc_logs.msg_with_no_picture(page,'second_page(special_sale)')
    if(pdf_count == sql_count):
        tc_logs.validation("Number of Vins in PDF: "+VarToStr(pdf_count)+" and Number of Vins in Oracle DB: "+VarToStr(sql_count)+" matches and test passed successfully") 
    elif(pdf_count-second_page_count == sql_count):
        tc_logs.validation("Number of Vins in PDF: "+VarToStr(pdf_count-second_page_count)+" and Number of Vins in Oracle DB: "+VarToStr(sql_count)+" matches and test passed successfully")
    else:
        tc_logs.error_with_no_picture("Number of Vins in PDF: "+VarToStr(pdf_count)+" and Number of Vins in Oracle DB: "+VarToStr(sql_count)+" doesn't match. Please check the query",'')
  
def check_universal_key_sorted_pdf():
    tc_logs.validation("PDF Vs DB VALIDATION CHECK WHETHER UNIVERSAL KEY SORTED IN (SALE Yr-Wk-Ln-Rn) ORDER".center(100,'*'))
    pdf_count, docobj = pdf_utility.loadpdf()
    page = 1
    unikeys_list = []
    if(gvar.dataprep['document_type'] == 'BOS'):
        sql_count,rows = bill_of_sale_query.oracle_sql_count_bos()
    elif(gvar.dataprep['document_type'] == 'INV' or gvar.dataprep['document_type'] == 'INVOICE'):
        sql_count,rows = invoice_query.oracle_sql_count_inv()
    if(sql_count == pdf_count):
        for i in range(0,sql_count):
            unikey = rows[i]['SALE_YEAR']+'-'+rows[i]['SALE_WEEK']+'-'+rows[i]['SALE_LANE']+'-'+rows[i]['SALE_RUN']
            unikeys_list.append(unikey)
            Log.Message(unikey)
        while(pdf_count>=page):
            stripper =  JavaClasses.org_apache_pdfbox_text.PDFTextStripper.newInstance()
            stripper.setStartPage(page)
            stripper.setEndPage(page)
            text = stripper.getText(docobj)   
            t = VartoStr(text)
            Log.Message(t)
            res = aqString.Find(t,unikeys_list[page-1])
            if(res == -1):
                tc_logs.error_with_no_picture("PDF is not sorted by Universal key(Sale Yr-Wk-Ln-Rn) and validation failed",'') 
                break   
            else:
                page+=1
        tc_logs.validation("PDF sorted by Universal key(Sale Yr-Wk-Ln-Rn) validation is successful")
    else:
        tc_logs.error_with_no_picture("Please check the Vin count query for inconsistency.",'')
        
        
        
def auction_location_universal_key_validation():
    tc_logs.validation("PDF Vs DB VALIDATION".center(70,'*'))
    if(gvar.dataprep['document_type'] == 'BOS'):
        sql_count,rows = bill_of_sale_query.oracle_sql_count_bos()
    elif(gvar.dataprep['document_type'] == 'INV' or gvar.dataprep['document_type'] == 'INVOICE'):
        sql_count,rows = invoice_query.oracle_sql_count_inv()
    pdf_count, docobj = pdf_utility.loadpdf()
    page = 1
    second_page_count = 0
    for count in range(0,pdf_count):
        stripper =  JavaClasses.org_apache_pdfbox_text.PDFTextStripper.newInstance()
        stripper.setStartPage(page)
        stripper.setEndPage(page)
        text = stripper.getText(docobj)   
        t = VartoStr(text)
        res = aqString.Find(t,"Yr Wk Ln Rn")
        if(res == -1):
            second_page_count+=1
        Log.Message(page)       
        page+=1
        tc_logs.msg_with_no_picture(page,'second_page(special_sale)')
    if(pdf_count == sql_count):
        tc_logs.validation("PDF sorted by Auction Location and Universal key(Sale Yr-Wk-Ln-Rn) validation is successful") 
    elif(pdf_count-second_page_count == sql_count):
        tc_logs.validation("PDF sorted by Auction Location and Universal key(Sale Yr-Wk-Ln-Rn) validation is successful")
    else:
        tc_logs.error_with_no_picture("Number of Vins in PDF: "+VarToStr(pdf_count)+" and Number of Vins in Oracle DB: "+VarToStr(sql_count)+" doesn't match. Please check the query",'')
  
def due_from_customer_validation():
    tc_logs.validation("PDF Vs DB VALIDATION".center(70,'*'))
    page, docobj = pdf_utility.loadpdf()
    stripper =  JavaClasses.org_apache_pdfbox_text.PDFTextStripper.newInstance()
    text = stripper.getText(docobj)
    t = VartoStr(text)
    res = aqString.Find(t,gvar.dataprep['p_dealer'])
    if(res == -1):
        tc_logs.error_with_no_picture(f"Customer '{gvar.dataprep['p_dealer']}' is not found and validation failed",'')
    else: 
        tc_logs.validation(f"Customer '{gvar.dataprep['p_dealer']}' is found and validation is successful")    
