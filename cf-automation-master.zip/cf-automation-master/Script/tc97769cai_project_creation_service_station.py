﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils
import winscp_utility
import random
import web_utils
import form_utils
import gvar
####This testcase is to place the excel import file in the AP inbound directory using WINSCP### 


class tc97769cai_project_creation_service_station(Ebiz):

  global inv_date,inv_num
  op_log_path="C:\\TC_Logs"
  exl_inv_files="C:\\Excel_Inv_Files"

  def login(self):
    self.login_user="pkjami"
    super().login()

  def action(self,book):   
    leg_proj_code="43"+VarToStr(random.randint(11111,99999))  
    self.update_proj_creation_xldetails(leg_proj_code)
    self.update_proj_key_mem_xldetails(leg_proj_code)
    self.place_proj_creation_file_winscp()
    self.place_proj_key_mem_file_winscp()
#    
    # Logic to login to CAI US PA JOB SCHEDULER
    self.page.WaitProperty("contentText","CAI US PA JOB SCHEDULER",6000)
    cai_gl_submit_link=self.page.Find("contentText","CAI US PA JOB SCHEDULER",30) #.scrollIntoView()
    self.verify_aqobject_chkproperty(cai_gl_submit_link,"contentText",cmpIn,"CAI US PA JOB SCHEDULER")
    cai_gl_submit_link.scrollIntoView()
    cai_gl_submit_link.Click() 
    self.log_message_web("Click 'CAI US PA JOB SCHEDULER' - Successful")        
    self.page.Wait()
    self.page.NativeWebObject.Find("contentText","Submit Request","A").Click()
    self.log_message_web("Click 'Submit Request' - Successful") 
    
    
    
    #web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" PA PROJECT ADMIN')]")
    #self.log_message_web("Click 'CAI US PA PROJECT ADMIN' - Successful")
#    Delay(1000)
#    self.wait_until_page_loaded()
#    self.page.wait()
#    self.page.NativeWebObject.Find("contentText","Other","A").Click()
#    self.log_message_web("Click 'Other' - Successful")
#    Delay(1000)
    #self.page.EvaluateXPath("//table[@id='respList']//div[contains(text(),'Requests')]")[0].Click()
#    self.page.NativeWebObject.Find("contentText","Requests","A").Click()
#    self.log_message_web("Click 'Requests' - Successful")
#    Delay(1000)
#    self.page.Keys("[Down]")
#    self.wait_until_page_loaded
#    self.page.EvaluateXPath("//table[@id='respList']//div[contains(text(),'Run')]")[0].Click()
#    self.log_message_web("Click 'Run' - Successful")
#    Delay(1000)
    web_utils.validate_security_box()
    jFrame= self.initializeJFrame()
    Delay(5000)
    form_utils.click_ok_btn(jFrame)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit a New Request","ExtendedFrame"]
    SubmitaNewRequest_form=jFrame.FindChildEx(prop,val,60,True,90000)
    self.verify_aqobject_chkproperty(SubmitaNewRequest_form,"AWTComponentAccessibleName",cmpContains,"Submit a New Request")
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["What type of request do you want to run? Request Set alt s","ExtendedCheckbox"]  
    SubmitaNewRequest_form.FindChild(prop,val,10).Click()
     
    Delay(2000)
    prop = ["AwtComponentAccessibleName","JavaClassName"]
    val = ["OK alt O","Button"]
    SubmitaNewRequest_form.FindChild(prop,val,10).Click()
    Delay(2000)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit Request Set","ExtendedFrame"]
    SubmitRequestSet_form=jFrame.FindChildEx(prop,val,60,True,90000)
    self.verify_aqobject_chkproperty(SubmitRequestSet_form,"AWTComponentAccessibleName",cmpContains,"Submit Request Set")
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Request Set RequiredList of Values","VTextField"]
    req_name = SubmitRequestSet_form.Find(prop,val,20)
    req_name.Click()
    Delay(2000)
    req_name.SetText("CAI PA Project Creation Upload")
    Delay(2000)
    
    jFrame.keys("[Tab]")
    
    self.submit_req_set_params(SubmitRequestSet_form,jFrame,15,VarToStr("PA_"+self.oper_unit+"_PROJ_MAIN*"),"Y")
    self.submit_req_set_params(SubmitRequestSet_form,jFrame,16,VarToStr("PA_"+self.oper_unit+"_PROJ_KEYMEM*"),"Y") 
    self.submit_req_set_params(SubmitRequestSet_form,jFrame,17,VarToStr("Y"),"N")
    self.submit_req_set_params(SubmitRequestSet_form,jFrame,18,VarToStr("Y"),"N")
    self.submit_req_set_params(SubmitRequestSet_form,jFrame,19,VarToStr(""),"Y")
    Delay(2000)
    self.log_message_oracle_form(jFrame,"'CAI PA Project Creation Upload' parameters entered successful")
    Delay(2000) 
    SubmitRequestSet_form.Keys("[Down]")
    Delay(2000)
    self.submit_req_set_params(SubmitRequestSet_form,jFrame,19,VarToStr(""),"Y") 
    Delay(2000)
    self.log_message_oracle_form(jFrame,"Parameters to submit the request")
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val = ["Submit", "Button"]
    SubmitRequestSet_form.FindChild(prop,val,10).Click()
    Delay(2000)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val = ["Decision Request submitted*","ChoiceBox"]
    decision_box = jFrame.FindChildEx(prop,val,60,True,12000)
    RequestID = ''.join(x for x in decision_box.AWTComponentAccessibleName if x.isdigit())
    self.log_message_oracle_form(decision_box,f"RequestID:{RequestID}")
    Delay(2000)
    self.log_message_oracle_form(jFrame,"Decision NO")
    jFrame.keys("~n")
    Delay(2000)
    #self.log_message_oracle_form(jFrame,"Decision NO")
    Delay(2000)
    
    jFrame.Keys("~v")
    Delay(2000)
    jFrame.Keys("r")
    Delay(2000)
    jFrame.Keys("~i")
    Delay(2000) 
    
 # Checking in the DB for the concurrent programs completion
    dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
    user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
    pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
    dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd, aqConvert.VarToStr(RequestID))   
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChild(prop,val,30)
    self.verify_aqobject_chkproperty(req_form,"AWTComponentAccessibleName",cmpContains,"Requests") 
    self.log_message_oracle_form(jFrame,"Requests Form Found") 
    
    creq_id,log_path = form_utils.req_set_save_output(self,jFrame,req_form,"CAI Project Validate and Upload Program",RequestID)
    web_utils.close_additional_browsers()
    
  #projects = []
    Log.Enabled=True
    failed_records = None	
    project_number = None
    project_text = None
    #gvar.dataprep['project_fail'] = False
    with open(log_path, 'r') as fo:
      for cnt, line in enumerate(fo):
        if "Total number of Projects validation failed" in line:
         line = line.strip() 
         failed_records = VarToInt(line[-1])
				               
        if "Project Already Exists In Oracle" in line:
         project_text = line.strip() 
         
        if "Oracle Project Number" in line:   
          project_number = ''.join(x for x in line.strip() if x.isdigit())
          self.log_message_web("Project Number:" + project_number)
        if "Legacy Project Number" in line:
          gvar.dataprep['legacy_project_number'] = line[-11:].strip()   
    if failed_records != 0:  
      self.failed_record_hdr_msg()
      self.failed_record_dtl_msg()
      self.failed_record_foot_msg(project_text)
      Log.Enabled=False
      #gvar.dataprep['project_fail'] = True
      return
    
          
    #self.log_message_web("Project Number: - "+projects[0].strip())
    #self.log_message_web("Project Number:" + project_number)
    Delay(2000)
    jFrame.Keys("[F4]")
    Delay(2000)
    jFrame.Keys("[F4]")
    Delay(2000)
    jFrame.Keys("[Enter]")
    Delay(2000)
    
    web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" PA PROJECT ADMIN')]")
    self.log_message_web("Click 'CAI US PA PROJECT ADMIN' - Successful")
    Delay(1000)
    self.wait_until_page_loaded()
    self.page.wait()
    self.page.NativeWebObject.Find("contentText","Project Templates","A").Click()
    self.log_message_web("Click 'Project Templates' - Successful")
    Delay(1000)
    web_utils.validate_security_box()
    jFrame= self.initializeJFrame()
    Delay(4000)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Projects","ExtendedFrame"]
    find_proj_form=jFrame.FindChildEx(prop,val,40,True,90000)
#    self.log_message_oracle_form(jFrame,"Open the Project Window")
    pro_num=find_proj_form.FindChild("AWTComponentAccessibleName","Project NumberList of Values",20)
    pro_num.Click()
    #pro_num.SetText(VarToStr(projects[0]))
    pro_num.SetText(VarToStr(project_number))
    Delay(2000)
    self.log_message_oracle_form(jFrame,"Enter the Project Number")
    jFrame.Keys("~i")
    Delay(2000)
    self.log_message_oracle_form(jFrame,"Projects Templates Form Found")
    Delay(2000)
    jFrame.Keys("[Enter]")
    Delay(2000)
    self.log_message_oracle_form(jFrame,"Projects Details")
   
    
    jFrame.Keys("[F4]")
    Delay(2000)
    jFrame.Keys("[F4]")
    Delay(2000)
    jFrame.Keys("~o")
    Delay(2000)


# Modifying cai_excel_invoice_import_report_set.csv file 

  def update_proj_creation_xldetails(self,leg_proj_code):
   
     Log.Message(leg_proj_code)
     proj_name="CAI Testing Proj"+VarToStr(random.randint(11111,99999))
     proj_des="Tst"+VarToStr(random.randint(111111,999999))
     ref_id = aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%M%S")
     
     file_exist=aqFileSystem.FindFiles("C:\\Excel_Inv_Files","*.csv")
     if file_exist != None:
       aqFileSystem.DeleteFile("C:\\Excel_Inv_Files\\*.csv")
     aqFileSystem.CopyFile(Project.Path+"DataSheets\\Oracle-PA-Add-SNOW\\PA_US_PROJ_MAIN_20190307203006.csv", "C:\\Excel_Inv_Files\\PA_US_PROJ_MAIN_20190307203006.csv")
     self.mainProjFileName="C:\\Excel_Inv_Files\\PA_US_PROJ_MAIN_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d%Y%H%M%S")+".csv"
     aqFileSystem.RenameFile("C:\\Excel_Inv_Files\\PA_US_PROJ_MAIN_20190307203006.csv",self.mainProjFileName) 
     
     fo=open(self.mainProjFileName,"r+")
     data=fo.read()   
     Log.Message(fo.tell())
     fo.seek(481,0)
     fo.write(leg_proj_code)
     fo.seek(494,0)
     fo.write(leg_proj_code)
     fo.seek(506,0)
     fo.write(proj_name)
     fo.seek(538,0)
     fo.write(proj_des)
     fo.seek(690,0)
     fo.write(ref_id)
     fo.seek(797,0)
     fo.write(proj_des+'"')          
     fo.close()
     Log.Enabled=True
     Log.File(self.mainProjFileName, "PA_US_PROJ_MAIN Import File Attached")
     Log.Enabled=False 

   
   
  def update_proj_key_mem_xldetails(self,leg_proj_code):
   
   aqFileSystem.CopyFile(Project.Path+"DataSheets\\Oracle-PA-Add-SNOW\\PA_US_PROJ_KEYMEM_20190307203006.csv", "C:\\Excel_Inv_Files\\PA_US_PROJ_KEYMEM_20190307203006.csv")
   self.newFileName=aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d%Y%H%M%S")+".csv"
   aqFileSystem.RenameFile("C:\\Excel_Inv_Files\\PA_US_PROJ_KEYMEM_20190307203006.csv","C:\\Excel_Inv_Files\\PA_US_PROJ_KEYMEM_"+VarToStr(self.newFileName))  
   Log.Message(leg_proj_code)
   proj_name="CAI Testing Project"+VarToStr(random.randint(11111,99999))
   proj_des="Test"+VarToStr(random.randint(111111,999999))
   
   fo=open("C:\\Excel_Inv_Files\\PA_US_PROJ_KEYMEM_"+self.newFileName,"r+")
   data=fo.read()   
   fo.seek(77,0)
   fo.write(leg_proj_code)
   fo.seek(128,0)
   fo.write(leg_proj_code)
   fo.close() 
   Log.Enabled=True
   Log.File("C:\\Excel_Inv_Files\\PA_US_PROJ_KEYMEM_"+self.newFileName, "PA_US_PROJ_KEYMEM Import File Attached")
   Log.Enabled=False       
   
# Placing cai_excel_invoice_import_report_set.csv file in /EBS/incoming/ATG_OU/PA_XLS_PRJ_UPLOAD/archive folder
  def place_proj_creation_file_winscp(self):
    Stored_session = "cai_snow@mftstg.manheim.com"
#    Stored_session = "opc@stage-fin-iad1-ebsapp1.private.stagefin.oraclevcn.com"
    local_dir = "C:\\Excel_Inv_Files"
#    remote_dir =  self.winscpConfig[self.testConfig['ebiz']['env']]['remote_dir']+"incoming//ATG_OU//PA_XLS_PRJ_UPLOAD"
    remote_dir =  self.testConfig['winscp']['project_file_remote_dir'] 
    upload_file_name = VarToStr(self.mainProjFileName)
    winscp_utility.upload_file(Stored_session,local_dir,remote_dir,upload_file_name)
    Log.Enabled=True       
    Log.Message(upload_file_name+"file placed in the PA_XLS_PRJ_UPLOAD//ATG_OU//PA_XLS_PRJ_UPLOAD directory")           
    Log.Enabled=False
    
  def place_proj_key_mem_file_winscp(self):
#    Stored_session = "opc@stage-fin-iad1-ebsapp1.private.stagefin.oraclevcn.com"
    Stored_session = "cai_snow@mftstg.manheim.com"
    local_dir = "C:\\Excel_Inv_Files"
    remote_dir =  self.testConfig['winscp']['project_file_remote_dir']
#    remote_dir =  self.winscpConfig[self.testConfig['ebiz']['env']]['remote_dir']+"incoming//ATG_OU//PA_XLS_PRJ_UPLOAD"
    upload_file_name = "PA_US_PROJ_KEYMEM_"+VarToStr(self.newFileName)
    winscp_utility.upload_file(Stored_session,local_dir,remote_dir,upload_file_name)
    Log.Enabled=True       
    Log.Message(upload_file_name+"file placed in the PA_XLS_PRJ_UPLOAD//ATG_OU//PA_XLS_PRJ_UPLOAD directory")           
    Log.Enabled=False

  def submit_req_set_params(self,submitrequest_form,jFrame,index_no,proj_no,tab):
     prop=["AWTComponentAccessibleName","AWTComponentIndex"]
     val=["Parameters",index_no]
     submitrequest_form.FindChild(prop,val,60).Click()
     Delay(2000)   
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Parameters","FlexWindow"]   
     parameter_form=jFrame.FindChild(prop,val,10)
     if tab=='Y':
        parameter_form.Keys("[Tab]")
     parameter_form.Keys(proj_no)
     parameter_form.Keys("~o")
     Delay(1000)   
    
  def add_ddc_journal_details():
   
    fo=open("C:\\Excel_Inv_Files\\PA_US_PROJ_MAIN_20190307203006.csv","r+")
    data=fo.read()
    fo.seek(411,0)
    fo.write(ref_id_line1) 
    fo.seek(428,0)
    fo.write (gl_date)
    fo.seek(441,0)
    fo.write(ref_id_line2) 
    fo.seek(464,0)
    fo.write (gl_date)
    fo.seek(485,0)
    fo.write (gl_date)
    fo.seek(612,0)
    fo.write (gl_date)
    fo.close()
    
  def failed_record_hdr_msg(self):
    Log.Message("******************************************************")
    Log.Message("FAILED/INVALID RECORD")
    Log.Message("******************************************************")
        
    
  
  def failed_record_foot_msg(self,project_text):  
    Log.Message(project_text)
    Log.Error("Total number of Projects validation failed      1")
    Log.Message("******************************************************")
    
  def failed_record_dtl_msg(self):
    #global legacy_project_number
    Log.Message(f"Legacy Project Number : {gvar.dataprep['legacy_project_number']}")
  	
