﻿from ebiz import *
import web_utils
import form_utils
import dbhelper
import file_system_utils


class tc179292_is_webadijournal_posting(Ebiz):

 op_log_path ="C:\\TC_Logs"

 def login(self):
   self.login_user='mfallwell'
   super().login()
 
 def goto_url(self,url):
   super().goto_url(self.testConfig['ebiz']['oci_is_url'])
   
 def action(self,book): 
    Log.Enabled=True
    Log.Message("Proj variable currency: "+ProjectSuite.Variables.currency)
    Log.Enabled=False
    if ProjectSuite.Variables.currency =="USD": 
     app = book.Sheets.item["JournalWebAdi_USD"]
    elif ProjectSuite.Variables.currency=="CAD":
     app = book.Sheets.item["JournalWebAdi_CAD"]
    self.page.wait()
    Log.Message("Inside action...")   
    Log.Message("Inside action...")   
    self.page.WaitProperty("contentText","GL SCHEDULER",6000)
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='menuContent']//div[contains(text(),'GL SCHEDULER')]")       
    self.page.Wait()
    self.page.NativeWebObject.Find("contentText","Requests","A").Click()
    web_utils.log_checkpoint("Click 'Requests' - Successful",500,self.page)
    delay(2000)
    self.page.NativeWebObject.Find("contentText","Run","A").Click()
    web_utils.log_checkpoint("Click 'Run' - Successful",500,self.page)
    web_utils.validate_security_box()
    Delay(15000)
    jFrame=self.initializeJFrame()
    form_utils.click_ok_btn(jFrame)   
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit a New Request","ExtendedFrame"]
    submit_new_req_form=jFrame.FindChildEx(prop,val,50,True,90000) 
    Sys.HighlightObject(submit_new_req_form)
    submit_new_req_form.FindChild("AWTComponentAccessibleName","OK alt O",10).Click()
    
# Submitting "Program - Automatic Posting" Request using CAI ALL GL JOB SCHEDULER' responsibility

    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit Request","ExtendedFrame"]
    par_form=jFrame.FindChildEx(prop,val,60,True,90000)
    delay(1000)
    par_form.FindChild("AWTComponentAccessibleName","Name RequiredList of Values",30).SetText("Program - Automatic Posting")
    delay(2000)
    jFrame.Keys("[Tab]")
    delay(2000)
    jFrame.Keys("NIGHTLY")
    delay(1000)
    jFrame.Keys("~o")
    delay(2000)
    par_form.FindChild("AWTComponentAccessibleName","Submit alt m",10).Click()
    Delay(1000)
    web_utils.log_checkpoint("'Program - Automatic Posting' concurrent job is Submitted",500,jFrame)
    RequestID = aqConvert.VarToInt(''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit()))
    Log.Message("Request ID Of  " + aqConvert.VarToStr(RequestID))
    web_utils.log_checkpoint("Request ID Of Program - Automatic Posting is " + aqConvert.VarToStr(RequestID),500,jFrame)
    Delay(2000)
    jFrame.Keys("~n")
    Delay(35000)
    jFrame.Keys("~v")
    Delay(4000)
    jFrame.Keys("r")
    Delay(4000)
    jFrame.Keys("~s")
    Delay(5000)
    prop_names=["JavaClassName","AWTComponentAccessibleName"]
    prop_values=["VTextField","Request ID"]
    temp=jFrame.FindAll(prop_names,prop_values,60)
    jFrame.Find("AWTComponentName",temp[10].AWTComponentName,60).Click()
    jFrame.Find("AWTComponentName",temp[10].AWTComponentName,60).SetText(RequestID)
    Delay(2000)
    
#Click Find 
    jFrame.Keys("~i")
    Delay(2000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,60000)
   
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Phase",40]
    phase=req_form.Find(prop,val,10).wText 
   
    while phase != "Completed":
     Delay(1000)
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Requests","ExtendedFrame"]
     req_form=jFrame.FindChild(prop,val,60)
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Refresh Data alt R","Button"]
     refresh_button=req_form.FindChild(prop,val,60)
     refresh_button.Find("AWTComponentAccessibleName","Refresh Data alt R").Click()
#     req_form.keys("~r")
     Delay(4000)
     phase=req_form.Find(prop,val,10).wText 
    web_utils.log_checkpoint("Program - Automatic Posting phase is completed",500,req_form)
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Status",50]
    request_form=jFrame.FindChild(prop,val,30)
    self.verify_aqobject_chkproperty(request_form,"wSelection",cmpContains,"Normal")
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChild(prop,val,60)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["View Output alt p","Button"]
    output_button=req_form.FindChild(prop,val,60)
    output_button.Find("AWTComponentAccessibleName","View Output alt p").Click()   
#    jFrame.Keys("~p")
    Delay(4000)
    log_page=Sys.Browser("iexplore").Page("https://manheim*.epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
    log_page.Click()
    log_page.TextNode(0).Click()
    Delay(3000)
    log_page.Keys("~f")
    Delay(3000)
    log_page.Keys("a")
    Delay(3000)  
    file_system_utils.create_folder(self.op_log_path)             
    log_path=self.op_log_path+"\\Posting_Single Ledger Output File Is Attached_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
    Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
    Delay(1000)
    Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
    Delay(3000)
    Log.Enabled=True
    Log.File(log_path, "Automatic Posting Output File Is Attached")
    Log.Enabled=False        
    Delay(1000)
    Sys.Browser("iexplore").Page("https://manheim*.epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close()
    Delay(1000)
    jFrame.Click()
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~o")
    Delay(1000)      
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='menuContent']//div[contains(text(),'GL Corporate Accounting User')]") 
    self.wait_until_page_loaded()
    self.page.NativeWebObject.Find("contentText","Journals","A").Click()
    web_utils.log_checkpoint("Click 'Journals' - Successful",500,self.page)
    delay(2000)
    self.page.NativeWebObject.Find("contentText","Enter","A").Click()
    web_utils.log_checkpoint("Click 'Enter' - Successful",500,self.page)
    web_utils.validate_security_box()
    Delay(20000)
    jFrame=self.initializeJFrame()
    form_utils.click_ok_btn(jFrame)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Journals","ExtendedFrame"]
    j_req_id = app.Cells.Item[2,14]
    fnd_jrnl=jFrame.FindChildEx(prop,val,60,True,90000)
    fnd_jrnl.Find("AWTComponentAccessibleName","BatchList of Values",10).Click()
    fnd_jrnl.Find("AWTComponentAccessibleName","BatchList of Values",10).Keys("%"+VarToStr(j_req_id)+"%")
    delay(1000) 
    jFrame.Keys("~i")
    delay(8000)
    web_utils.log_checkpoint(VarToStr(j_req_id)+" find Journal Successful",500,jFrame) 
    jFrame.Keys("~u")
    delay(4000) 
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Journals (MAN GLB ALL)*","ExtendedFrame"]
    jrnls=jFrame.FindChildEx(prop,val,60,True,60000)
    jrnls.FindChild("AWTComponentName","FormsTabPanel*",60).ClickTab("Other Information")
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Status: Approval",2]
    jrnl_appr_val = jFrame.FindChild(prop,val,60)
    jrnl_appr_status=jrnl_appr_val.wText  
    web_utils.log_checkpoint("Journal Approval Status: "+jrnl_appr_status,500,jFrame) 
    Log.Enabled=True
    aqObject.CheckProperty(jrnl_appr_val,"wText",cmpIn,"Approved")
    Log.Enabled=False
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Status: Posting",0]
    jrnl_val = jFrame.FindChild(prop,val,60)
    jrnl_status=jrnl_val.wText  
    web_utils.log_checkpoint("Journal Status: "+jrnl_status,500,jFrame) 
    Log.Enabled=True
    aqObject.CheckProperty(jrnl_val,"wText",cmpIn,"Posted")
    Log.Enabled=False
    web_utils.log_checkpoint(VarToStr(j_req_id)+" Journal is Approved and Posted",500,jFrame) 
    delay(4000) 
    jrnls.FindChild("AWTComponentName","FormsTabPanel*",60).ClickTab("Lines")
    delay(4000) 
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Journals (MAN GLB ALL)*","ExtendedFrame"]
    jrnls=jFrame.FindChildEx(prop,val,30,True,60000)
    prop=["JavaClassName","AWTComponentIndex"]
    val=["LWScrollbar","0"]
    down_button=jrnls.FindChildEx(prop,val,30,True,60000)
    for i in range(0,10):
      prop=["JavaClassName","AWTComponentIndex"]
      val=["ContinuousButton","0"]
      down_button.Find(prop,val,20).Click()  
    delay(4000) 
    self.close_forms(jFrame)    
    

