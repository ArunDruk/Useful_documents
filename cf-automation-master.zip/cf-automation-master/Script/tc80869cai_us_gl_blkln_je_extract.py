﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils
import winscp_utility
### Aruna Gutha, 2021Q2-3, added below two import statements for US473210
import tc_logs
import sys

###This testcase is to place the cai_gl_blkln_je_extract.txt file in the GL inbound directory using WINSCP### 
###and submit CAI Oracle GL Inbound JE Interface Request Set - BL request set and capture logs and post the journal which got imported into CAI EBIZ###

class tc80869cai_us_gl_blkln_je_extract(Ebiz):

 op_log_path="C:\\TC_Logs"
 blkn_gl_jrnl_files="C:\\BLKLN_JE_Files"
### Aruna Gutha, 2021Q2-3, added for error message for US473210
 __Error = tc_logs.error_with_no_picture

 def login(self):
    self.login_user="mfallwell"
    super().login()

 def action(self,book):
    global req_id_parent 
    self.add_blkln_journal_details()
    self.place_blkln_jrnl_file_winscp()
 
 ### Modifying cai_gl_blkln_je_extract.txt file
 ### Aruna Gutha, 2021Q2-3, added f_gl_date for US473210 
 def add_blkln_journal_details(self):
    file_name= Project.Path+"DataSheets\\Oracle-GL-Journal\\CAIGL_BLKLN_JE_EXTRACT_2019.txt"
    ref_id = aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%M%S")
    gl_date = aqConvert.DateTimeToFormatStr(aqDateTime.Today(),"%m/%d/%Y")
    f_gl_date = aqConvert.DateTimeToFormatStr(aqDateTime.AddDays(gl_date, 45),"%m/%d/%Y")
    aqDateTime.AddDays(gl_date, 45)
    period = aqConvert.DateTimeToFormatStr(aqDateTime.Today(),"%b-%y")
          
    fo=open(file_name,"r+")
    data=fo.read()
    
    #1st record
    fo.seek(3,0)
    fo.write(ref_id)
    fo.seek(112,0)
    fo.write(ref_id)
    fo.seek(51,0)
    fo.write (f_gl_date)
    
    #2nd record
    fo.seek(287,0)
    fo.write(ref_id)
    fo.seek(396,0)
    fo.write(ref_id)
    fo.seek(335,0)
    fo.write (f_gl_date)
    
    #3rd record
    fo.seek(571,0)
    fo.write(ref_id)
    fo.seek(680,0)
    fo.write(ref_id)
    fo.seek(619,0)
    fo.write (f_gl_date)
    
    #4th
    fo.seek(854,0)
    fo.write(ref_id)
    fo.seek(963,0)
    fo.write(ref_id)
    fo.seek(902,0)
    fo.write (f_gl_date)
    
    #5th
    fo.seek(1138,0)
    fo.write(ref_id)
    fo.seek(1237,0)
    fo.write(ref_id)
    fo.seek(1195,0)
    fo.write (gl_date)
    
    #6th
    fo.seek(1377,0)
    fo.write(ref_id)
    fo.seek(1476,0)
    fo.write(ref_id)
    fo.seek(1434,0)
    fo.write (gl_date)
    
    #7th
    fo.seek(1616,0)
    fo.write(ref_id)
    fo.seek(1727,0)
    fo.write(ref_id)
    fo.seek(1676,0)
    fo.write (gl_date)
    
    #8th
    fo.seek(1885,0)
    fo.write(ref_id)
    fo.seek(1996,0)
    fo.write(ref_id)
    fo.seek(1945,0)
    fo.write (gl_date)

    fo.close()
    
    file_system_utils.create_folder(self.blkn_gl_jrnl_files)
    file_exist=aqFileSystem.FindFiles("C:\\BLKLN_JE_Files\\","CAIGL_BLKLN_JE_EXTRACT_2019.txt")
    if file_exist != None:
     aqFileSystem.DeleteFile("C:\\BLKLN_JE_Files\\CAIGL_BLKLN_JE_EXTRACT_2019.txt")
    aqFileSystem.CopyFile(Project.Path+"DataSheets\\Oracle-GL-Journal\\CAIGL_BLKLN_JE_EXTRACT_2019.txt", "C:\\BLKLN_JE_Files\\CAIGL_BLKLN_JE_EXTRACT_2019.txt")
    log_path = "C:\\BLKLN_JE_Files\\CAIGL_BLKLN_JE_EXTRACT_2019.txt"
    Log.Enabled=True
    Log.File(log_path, "CAIGL_BLKLN_JE_EXTRACT Import File Attached")
    Log.Enabled=False
       
# Placing cai_gl_blkln_je_extract.txt file in //DAUT2I//incoming//ATG_OU//GL_JE_BALANCES_INTF
 def place_blkln_jrnl_file_winscp(self):
    Stored_session = "blackline3@mftstg.manheim.com"
#    Stored_session = "opc@stage-fin-iad1-ebsapp1.private.stagefin.oraclevcn.com"
    local_dir = "C:\\BLKLN_JE_Files"
    remote_dir =  self.testConfig['winscp']['cai_remote_dir']
#    remote_dir =  "//Outbox//TAUTRI"
    upload_file_name = "CAIGL_BLKLN_JE_EXTRACT_2019.txt"
    winscp_utility.upload_file(Stored_session,local_dir,remote_dir,upload_file_name)
    Log.Enabled=True       
    Log.Message("CAIGL_BLKLN_JE_EXTRACT_2019.txt file placed in the GL_JE_BALANCES_INTF directory")           
    Log.Enabled=False

# Login to Oracle EBIZ and select the responsibility 
    self.page.WaitProperty("contentText","CAI ALL GL JOB SCHEDULER",6000)
    cai_gl_submit_link=self.page.NativeWebObject.Find("contentText","CAI ALL GL JOB SCHEDULER","A")
    self.verify_aqobject_chkproperty(cai_gl_submit_link,"contentText",cmpIn,"CAI ALL GL JOB SCHEDULER")
    cai_gl_submit_link.Click() 
    self.log_message_web("Click 'CAI ALL GL JOB SCHEDULER' - Successful") 
    Delay(1000)  
         
    self.page.Wait()
    self.page.NativeWebObject.Find("contentText","Submit Request","A").Click()
    self.log_message_web("Click 'Submit Request' - Successful") 
    
    jFrame= self.initializeJFrame()
    Delay(10000)

    form_utils.click_ok_btn(jFrame)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit a New Request","ExtendedFrame"]
    submit_new_req_form=jFrame.FindChildEx(prop,val,60,True,90000)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["What type of request do you want to run? Request Set alt s","ExtendedCheckbox"]  
    submit_new_req_form.FindChild(prop,val,10).Click()       
    Delay(1000)
    submit_new_req_form.FindChild("AWTComponentAccessibleName","OK alt O",10).Click()
    
# Submitting "CAI Oracle GL Inbound JE Interface Request Set - BL" Request Set using CAI ALL GL JOB SCHEDULER' responsibility
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit Request Set","ExtendedFrame"]
    par_form=jFrame.FindChildEx(prop,val,60,True,90000)
    par_form.Find("AWTComponentAccessibleName","Request Set RequiredList of Values",30).SetText("CAI Oracle GL Inbound JE Interface Request Set - BL")
    delay(1000)
    
    jFrame.Keys("[Tab]")
    delay(1000)
    
    par_form.FindChild("AWTComponentAccessibleName","Submit",10).Click()
    Delay(1000)
    jFrame.Keys("~o")
    Delay(1000)
    self.log_message_oracle_form(jFrame,"CAI Oracle GL Inbound JE Interface Request Set - BL Submitted")   
    
    RequestID = aqConvert.VarToInt(''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit()))

    self.log_checkpoint_message_web("Request ID Of CAI Oracle GL Inbound JE Interface Request Set - BL " + aqConvert.VarToStr(RequestID))
    Delay(2000)
    jFrame.Keys("~n")
    Delay(4000)
    
    dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
    user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
    pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
    dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,VarToStr(RequestID))
    
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000) 
       
# Gathering Request ID and Output File for the "CAI Oracle GL Inbound JE Interface Program"   
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,90000) 
    
    self.req_set_save_output(jFrame,req_form,"CAI Oracle GL Inbound JE Interface Program",RequestID) 
    
# Gathering Request ID and Output File for the "CAI Oracle GL Journal Status Extract Program"
    self.req_set_save_output(jFrame,req_form,"CAI Oracle GL Journal Status Extract Program",RequestID)

# Gathering Request ID and Output File for the "Journal Import Program"  
    creqid1 = self.req_set_save_output(jFrame,req_form,"Journal Import",RequestID)
    journal_req_ids = []
    journal_req_ids.append(creqid1) 
    
    creqid2 = self.req_set_save_output(jFrame,req_form,"Journal Import",RequestID,journal_req_ids)
    journal_req_ids.append(creqid2)
    
    creqid3 = self.req_set_save_output(jFrame,req_form,"Journal Import",RequestID,journal_req_ids)
    journal_req_ids.append(creqid3)
   
    # Code to Check whether any Journal Import is having empty value.
    if any(journal_req_ids) == False:
       web_utils.log_error("Not able to get Journal import batch name")
    
# Gathering Request ID and Output File for the "Posting: Single Ledger" 
    self.req_set_save_output(jFrame,req_form,"Posting Single Ledger",RequestID)  

# search for CAI Inbound Global File Validation Program
    Delay(5000)
    self.req_set_save_log(jFrame,req_form,"CAI Inbound Global File Validation Program",RequestID,type = "Inbound")  

# Gathering Request ID and Output File for the "CAI: Transfer files to Sterling"
#    Delay(5000)
#    self.req_set_save_log(jFrame,req_form,"CAI: Transfer files to Sterling",RequestID,type = "Outbound")  
   
    Delay(1000)
    jFrame.Close()
    Delay(1000)
    jFrame.Close()
    Delay(1000)
    jFrame.Keys("~o")
    Delay(1000) 
    
    # Navigate to journal from frontEnd
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI ALL GL JOURNAL PROCESSING')]")
    self.log_message_web("Click 'CAI ALL GL JOURNAL PROCESSING' - Successful")
    Delay(3000)
    self.page.EvaluateXpath("//table[@id='respList']//div[text()='Enter Journals']")[0].Click()
    self.log_message_web("Click 'Enter Journals'- Successful")
    
    web_utils.validate_security_box()
    Delay(5000)
    jFrame=self.initializeJFrame()
    Delay(3000)
    form_utils.click_ok_btn(jFrame)
    
    for x in journal_req_ids:
      
      dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
      user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
      pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
#    dbhelper.verify_journal_import_details(dsn,user_id,pwd,"%"+VarTostr(x))      
### Aruna Gutha, 2021Q2-3, added status_value to assign the value returned by the query for US473210
      status_value = dbhelper.verify_journal_import_details(dsn,user_id,pwd,"%"+VarTostr(x))
    
      prop=["AWTComponentAccessibleName","JavaClassName"]
      val=["Find Journals","ExtendedFrame"]
      fnd_jrnl=jFrame.FindChildEx(prop,val,60,True,90000)
      fnd_jrnl.Find("AWTComponentAccessibleName","BatchList of Values",10).Click()
      fnd_jrnl.Find("AWTComponentAccessibleName","BatchList of Values",10).Keys("%"+VarToStr(x)+"%")
      delay(1000) 
      jFrame.Keys("~i")
      self.log_message_oracle_form(jFrame,VarToStr(x)+" find Journal Successful")
      delay(8000) 
      jFrame.Keys("~u")
      delay(4000) 
      prop=["AWTComponentAccessibleName","JavaClassName"]
      val=["Journals (CAI ALL LEDGERS)*","ExtendedFrame"]
      jrnls=jFrame.FindChildEx(prop,val,60,True,60000)
      jrnls.FindChild("AWTComponentName","FormsTabPanel*",60).ClickTab("Other Information")
      prop=["AWTComponentAccessibleName","AWTComponentIndex"]
      val=["Status: Approval",2]
      jrnl_appr_val = jFrame.FindChild(prop,val,60)
      jrnl_appr_status=jrnl_appr_val.wText  
      self.log_message_oracle_form(jFrame,"Journal Approval Status: "+jrnl_appr_status)   
      prop=["AWTComponentAccessibleName","AWTComponentIndex"]
      val=["Status: Posting",0]
      jrnl_val = jFrame.FindChild(prop,val,60)
      jrnl_status=jrnl_val.wText  
      self.log_message_oracle_form(jFrame,"Journal Status: "+jrnl_status)   
      Log.Enabled=True
### Aruna Gutha, 2021Q2-3, commented below statement and added status_value for validation for US473210
      #aqObject.CheckProperty(jrnl_val,"wText",cmpIn,"Posted")
      if status_value == 'POSTED_IN_VALID':
         __Error("Journal posted in a future period ", "") 
         sys.exit(1)
      Log.Enabled=False
#      self.log_message_oracle_form(jFrame,VarToStr(x)+" Journal is Posted")
      delay(4000) 
      jrnls.FindChild("AWTComponentName","FormsTabPanel*",60).ClickTab("Lines")
      delay(4000) 
      prop=["AWTComponentAccessibleName","JavaClassName"]
      val=["Journals (CAI ALL LEDGERS)*","ExtendedFrame"]
      jrnls=jFrame.FindChildEx(prop,val,30,True,60000)
      prop=["JavaClassName","AWTComponentIndex"]
      val=["LWScrollbar","0"]
      down_button=jrnls.FindChildEx(prop,val,30,True,60000)
      for i in range(0,10):
        prop=["JavaClassName","AWTComponentIndex"]
        val=["ContinuousButton","0"]
        down_button.Find(prop,val,20).Click()  
#      self.log_message_oracle_form(jFrame,"Intracompany balancing line added by Posting in "+VarToStr(x))        
      self.log_message_oracle_form(jFrame,"Intracompany balancing line added for "+VarToStr(x))
      delay(4000) 
      jFrame.Keys("[F4]")
      Delay(1000)
      jFrame.Keys("[F4]")
      Delay(1000)
      jFrame.Keys("[F4]")
      Delay(1000)
      jFrame.Keys("~o")
      Delay(1000)
        
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~o")
    Delay(1000)
    
 def req_set_save_output(self,jFrame,req_form,srch_child_name,Preqid,journal_req_ids=[]):
       
       prop=["AWTComponentAccessibleName","JavaClassName"]
       val = ["Refresh Data alt R","Button"]
       req_form.FindChild(prop,val,2000).Click()
       
       for x in range(20,51):
         
         if x>29:
           jFrame.Keys("[Down]")        
           x=29
                      
         prop=["AWTComponentAccessibleName","AWTComponentIndex"]
         val=["Phase",x+20]
         phase=req_form.Find(prop,val,10).wText 
         
         prop=["AWTComponentAccessibleName","AWTComponentIndex"]
         val=["Request ID",x-10]
         creqid= aqConvert.VarToInt(req_form.Find(prop,val,10).wText)
         
         prop=["AWTComponentAccessibleName","AWTComponentIndex"]
         val=["Name",x]
         child_name=req_form.Find(prop,val,10).wText
         req_form.Find(prop,val,10).Click()
         
         prop=["AWTComponentAccessibleName","AWTComponentIndex"]
         val=["Status",x+30]         
         status =req_form.FindChild(prop,val,60) 
         
         if (child_name==srch_child_name) and (creqid>=Preqid) and (creqid not in journal_req_ids)and (phase == "Completed"): 
           
           self.log_message_oracle_form(req_form,aqConvert.VarToStr(srch_child_name)+" Phase Completed Successfuly")            
           self.verify_aqobject_chkproperty(status,"wText",cmpIn,"Normal,Warning")
           self.log_message_oracle_form(req_form,"Request ID of "+aqConvert.VarToStr(srch_child_name)+" is "+aqConvert.VarToStr(creqid))
           req_form.Find(prop,val,10).Keys("[Enter]")
           Delay(1000)
           prop=["AWTComponentAccessibleName","JavaClassName"]
           val=["View Output alt p","Button"]
           output_button=req_form.FindChild(prop,val,60)
           output_button.Find("AWTComponentAccessibleName","View Output alt p").Click()     
           Delay(3000)
           output_page=Sys.Browser("iexplore").Page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
           output_page.Click()
           Delay(2000)
           output_page.Keys("~f")
           Delay(2000)
           output_page.Keys("a")
           Delay(5000)
           file_system_utils.create_folder(self.op_log_path)             
#           log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"Is Attached_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
           log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name)+"Is Attached_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"     
           Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
           Delay(1000)
           Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
           Delay(6000)
           Log.Enabled=True
           Log.File(log_path, aqConvert.VarToStr(srch_child_name)+" Output File Attached")
           Log.Enabled=False    
           Sys.Browser("iexplore").page("https://core-*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close() 
           web_utils.close_additional_browsers() 
           Delay(2000)   
           jFrame.Click()
           Delay(2000)
           return creqid
           
 def req_set_save_log(self,jFrame,req_form,srch_child_name,Preqid,type=""):
    
        prop=["AWTComponentAccessibleName","JavaClassName"]
        val = ["Refresh Data alt R","Button"]
        req_form.FindChild(prop,val,2000).Click() 
         
        for x in range(20,51):
          
          if x>29:
            jFrame.Keys("[Down]")        
            x=29
                        
          prop=["AWTComponentAccessibleName","AWTComponentIndex"]
          val=["Phase",x+20]
          phase=req_form.Find(prop,val,10).wText
           
          prop=["AWTComponentAccessibleName","AWTComponentIndex"]
          val=["Request ID",x-10]
          creqid= aqConvert.VarToInt(req_form.Find(prop,val,10).wText)
          
          prop=["AWTComponentAccessibleName","AWTComponentIndex"]
          val=["Name",x]
          child_name=req_form.Find(prop,val,10).wText
          req_form.Find(prop,val,10).Click()
            
          prop=["AWTComponentAccessibleName","AWTComponentIndex"]
          val=["Status",x+30]         
          status =req_form.FindChild(prop,val,60)
          
          if (child_name==srch_child_name) and (creqid>=Preqid) and (phase == "Completed"): 
            
            self.log_message_oracle_form(req_form,aqConvert.VarToStr(srch_child_name)+" Phase Completed Successfuly")            
            self.verify_aqobject_chkproperty(status,"wText",cmpIn,"Normal,Warning")
            self.log_message_oracle_form(req_form,"Request ID of "+aqConvert.VarToStr(srch_child_name)+" is "+aqConvert.VarToStr(creqid))
            req_form.Find(prop,val,10).Keys("[Enter]")
            Delay(1000)
            
            prop=["AWTComponentAccessibleName","JavaClassName"]
            val=["View Log alt K","Button"]
            log_button=req_form.FindChild(prop,val,60)
            log_button.Click()     
            Delay(3000)
            output_page=Sys.Browser("iexplore").Page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
            output_page.Click()
            Log.Enabled=True
            wnd = Sys.Desktop.ActiveWindow()
            Log.Picture(wnd, f"WinScp File Location path: {type}", wnd.FullName)                 
            Log.Enabled=False
            Delay(2000)
            output_page.Keys("~f")
            Delay(2000)
            output_page.Keys("a")
            Delay(5000)
            file_system_utils.create_folder(self.op_log_path)             
            log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"Is Attached_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
            Delay(1000)
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
            Delay(6000)
            Log.Enabled=True
            Log.File(log_path, aqConvert.VarToStr(srch_child_name)+" Log File Attached")
            Log.Enabled=False    
            Sys.Browser("iexplore").page("https://core-*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close()  
            web_utils.close_additional_browsers()
            Delay(2000)   
            jFrame.Click()
            Delay(2000)
            return creqid


#def test1():
#  import dbhelper
##  dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,VarToStr(RequestID))
#  dbhelper.vfy_oracle_concurrent_job_status("OCI_TEST","RAC_ACCNT","Y4bLC5sb","30760409")
  