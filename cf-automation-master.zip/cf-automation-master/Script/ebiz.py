﻿#import all_routine_list
from base import *
#import webUtils
import traceback
import web_utils

class Ebiz(Base):
  
    def login(self):
      try:                
        self.page.WaitProperty(self.config['login']['propname'],self.config['login']['propval'],60)
        if hasattr(self,'login_user'):
          self.page.Find(self.config['login']['propname'],self.config['login']['propval'],60).setText(self.login_user) 
#          self.log_message_web("Set User ID:  "+self.login_user+" Successful") 
        else:
          self.page.Find(self.config['login']['propname'],self.config['login']['propval'],60).setText(self.testConfig['ebiz']['userid']) 
          self.log_message_web("Set User ID:  "+self.testConfig['ebiz']['userid']+" Successful")       
        self.page.Keys("[Tab]")                
        self.page.Find(self.config['password']['propname'],self.config['password']['propval'],60).setText(self.testConfig['ebiz']['password']) 
#        self.log_message_web("Set Password:  'oracle123' Successful")       
        self.page.Find(self.config['login_btn']['propname'],self.config['login_btn']['propval'],60).Click() 
#        Delay(1000)
        self.wait_until_page_loaded()
        if(self.page.NativeWebObject.Find("contentText", "Oracle Applications Home Page", "h1").Exists):
          self.log_message_web("Login Successful") 
        elif self.page.Find("ObjectType","Alert",60).Exists:
          msg = self.page.Find("ObjectType","Alert",60).Message
          self.log_error_message("Unable to Login, Alert Message Displayed as :"+msg)
        elif self.page.Find("idStr","errmsg",60).Exists:
          msg = self.page.Find("idStr","errmsg",60).contentText
          self.log_error_message("Unable to Login, Error Message Displayed as :"+msg)

        self.wait_until_page_loaded()       
      except Exception as e:
        Log.Enabled=True
        Log.Message("Caught Net:ReadTimeout Error " + e) 
        Log.Error(traceback.format_exc())    
        Log.Enabled=False                     
      self.page.Wait()
      
    def logout(self): 
      self.page.wait() 
      Delay(2000)  
      self.wait_until_page_loaded() 
      self.page.EvaluateXpath("//table[@id = 'globalHeaderID']//a/div/img[@title = 'Logout']")[0].Click()     
      aqUtils.Delay(4000)
      self.page.Wait()      
      self.log_message_web("Successfully Logged out from Oracle Applications")
      self.browser.Close()
      
    def close_forms(self,jFrame):
       Delay(1000)
       jFrame.Close()
       delay(5000)
       self.log_message_oracle_form(jFrame,"Closing Java Forms...")
       web_utils.log_checkpoint("Closing Java Forms after Validation",500,jFrame)
       prop = ["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
       val = ["Caution Exit Oracle Applications?","ChoiceBox",0]
       i = 0
       while not jFrame.FindChild(prop,val,20).Exists:
#         self.log_message_oracle_form(jFrame,"Forms Closing Confirmation window found")
         delay(5000)
         i+=1
         if i == 15:
           self.log_error_message("Forms Closing Confirmation window not found")
       delay(1000)    
       jFrame.Keys("~o")     

        
    def handle_security_popup(self):                
         if Sys.Process("java").SwingObject("JDialog", "Security Information", -1, 1).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("DialogTemplate$15", "", 0).SwingObject("JPanel", "", 2).SwingObject("JPanel", "", 1).WaitSwingObject("JButton", "Run", 0,35000).Exists:
          Sys.Process("java").SwingObject("JDialog", "Security Information", -1, 1).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("DialogTemplate$15", "", 0).SwingObject("JPanel", "", 2).SwingObject("JPanel", "", 1).SwingObject("JButton", "Run", 0).Click()
          self.log_message_web("Click Java Security Successful")
         else:
          Log.Enabled=True 
          Log.Message("Security popup not found!!")
          Log.Enabled=False
          
    def read_excel(self,sheet_path,sheet_name):
          
          app = Sys.OleObject["Excel.Application"]
          Delay(1000)
          book = app.Workbooks.Open(Project.Path+sheet_path)
          
          app.Visible = "True"
          sheet_obj = book.Sheets.item[sheet_name]
          return sheet_obj
          
    def initializeJFrame(self):
      Delay(5000)
      if gvar.dataprep['browser'] == 'ie':
        web_utils.validate_ebs_security_box()
      elif gvar.dataprep['browser'] == 'chrome':
        web_utils.save_and_launch_forms()
      try:
           
        frame = Aliases.jp2launcher.Frame
        frame.Click(358, 22)
        frame.Click(517, 18)
        
        delay(1400)
        temp=Sys.Process("jp2launcher")
        if temp.Exists:    
           initializeJFrame=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1)
           return initializeJFrame     

           temp=Sys.Browser("iexplore").WaitSwingObject("JBufferedFrame", "Oracle Applications*", -1, 4000)   
        elif temp.Exists:
             initializeJFrame=Sys.Browser("iexplore").SwingObject("JBufferedFrame", "Oracle Applications*", -11) 
             return initializeJFrame
                     
             temp=Sys.WaitProcess("java")
        elif temp.Exists:
           initializeJFrame=Sys.WaitProcess("java").WaitSwingObject("JBufferedFrame", "Oracle Applications*", -1, 1,120000)
           return initializeJFrame

      except Exception as e:
        Log.Enabled=True
        Log.Message("Failed to find Java Frame" + e) 
        Log.Error(traceback.format_exc()) 
        sys.exit("Fail")   
        Log.Enabled=False  




