﻿from webCenterVerifier import *
import random


class WCC_Verify_single_page_po_us_v12(webCenterVerifier):
        
 def goto_url(self,url):
   super().goto_url(self.testConfig['ebiz']['WebCentVerUrl'])
      
 def action(self,book): 
   
  app = book.Sheets.item["wci_capture"]
  app1 = book.Sheets.item["wci_verifier"]
  
  #uncomment later 
  if self.page.FindChild("contentText","Options",40).Exists:
      web_utils.log_checkpoint("Able to Login to WFR Application Successfully",500,self.page)
  self.page.FindChild("contentText","Options",40).Click()
  self.page.FindChild("idStr","item_custom_filter-itemEl",40).Click()
  Delay(1000)
  self.wait_until_processing()
  batch_name=VarToStr(app.Cells.item[2,2])
  self.page.FindChild("idStr","bfdFilter",40).Keys("^a[Del]")
  self.page.FindChild("idStr","bfdFilter",40).SetText("[Capture Batch ID] ='"+VarToStr(batch_name)+"'")
  Delay(2000)
  self.page.FindChild("contentText","Apply",40).Click()
  Delay(1000)
  self.wait_until_processing()
 
# Refresh page until expected batch found
  while  Sys.Browser("iexplore").Page("*").EvaluateXPath("//table[@class='x-grid-table x-grid-table-resizer']//span")==None:   # //div[@class='removeAll'] 
    Sys.Browser("iexplore").Page("*").Keys("[F5]")
    Sys.Browser("iexplore").Page("*").Wait()
    Delay(2000)
    Sys.Browser("iexplore").Page("*").Wait()  
  Delay(2000)
  web_utils.log_checkpoint("Filter Options applied for WCC Batch Name: "+batch_name,500,self.page)
  
# Check the verifier batch id's(invoices) created for "Capture batch id":
  i = 1
  j = 0
  val2 = VarToStr(app.Cells.Item[2,2])
  fltr_view=Sys.Browser("iexplore").Page("https://*coxautoinc.com/WebVerifier/BatchView.aspx").Panel(0).Panel(0).Form("aspnetForm").Panel(2).Panel(0).Panel(0).Panel("container").Panel(0).Panel("body").Panel("gridCtl").Panel("body").Panel("gridview").Table(0)  

#  if (self.test_env=="oci_dev"):
#   fltr_view = Sys.Browser("iexplore").Page("http://*coxautoinc.com/WebVerifier/BatchView.aspx").Panel(0).Panel(0).Form("aspnetForm").Panel(2).Panel(0).Panel(0).Panel("container").Panel(0).Panel("body").Panel("gridCtl").Panel("body").Panel("gridview").Table(0)  
#  if (self.test_env=="oci_stage"):
#    fltr_view = Sys.Browser("iexplore").Page("http://tmnh1of.manheim.com/WebVerifier/BatchView.aspx").Panel(0).Panel(0).Form("aspnetForm").Panel(2).Panel(0).Panel(0).Panel("container").Panel(0).Panel("body").Panel("gridCtl").Panel("body").Panel("gridview").Table(0)  
  captr_btch_id = fltr_view.Cell(i, 13).Panel(0)
  val1 = captr_btch_id.contentText
  while  val2 == val1:
    Sys.HighlightObject(captr_btch_id)
    captr_btch_id.Click()
    batch_id = self.page.EvaluateXpath("//table[@class='x-grid-table x-grid-table-resizer']//span")[j].contentText
    i = i+1
    j = j+1
    captr_btch_id = fltr_view.Cell(i, 13).Panel(0)
    self.log_message_web("Available WFR BatchID No:"+VarToStr(i-1)+" = "+batch_id)
    val1 = captr_btch_id.contentText
  self.log_message_web("Count of verifier batch files created for 'Capture Batch Name' - "+VarToStr(app.Cells.Item[2,2])+" = "+VarToStr(j))

# Select the invoice and navigate to details:
  self.page.EvaluateXPath("//table[@class='x-grid-table x-grid-table-resizer']//span")[0].Click()
  web_utils.log_checkpoint("Selecting WFR BatchID: "+batch_id+" for processing",500,self.page) 
  Delay(1000)
  self.wait_until_page_loaded()
  Delay(3000)
  self.page.Wait()
  self.wait_until_page_loaded()
  batchname=self.page.FindChild("idStr","vF_BatchName",30).value   
  self.log_message_web("BatchName : "+VarToStr(batchname))  
  if VarToStr(batch_name)==VarToStr(batchname):
      self.log_checkpoint_message_web("Batch Name match successful") 
      Delay(3000)  
      invoice_number = "TEST_CA_PO_"+VarToStr(aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%m_%y"))+"_"+VarToStr(random.randint(1111,9999))
      

# Get Project Status & Set invoice type
  #project_status = VarToStr(self.page.FindChild("idStr","vF_Project",30).status)
  invoice = self.page.FindChild("idStr","vF_InvoiceType-inputEl",30)
  inv_type = invoice.Text
  if inv_type=="NO-PO":
    invoice.Click()
#    invoice.Keys("[Up]")
#    invoice.Keys("[Enter]")
    self.page.Panel("boundlist").Panel("boundlist_listEl").FindChild("contentText","PO",30).Click()
    web_utils.log_checkpoint("Changing Invoice Type to required value: PO",500,self.page) 

# Get Company code and Operating Unit; Project Selection if required
  comp_code=self.page.FindChild("idStr","vF_CompanyCode",30).value  
  self.log_message_web("Company Code :"+VarToStr(comp_code))
  op_unit=self.page.FindChild("idStr","vF_OperatingUnit",30).value  
  self.log_message_web("Operating Unit :"+VarToStr(op_unit))

#  Set Invoice Number
  self.page.Find("idStr","ctl00_ctl00_ContentPlace_WorkArea_documentViewerCtl_image",40).Click()
  Delay(3000)    
  inv_no=self.page.FindChild("idStr","vF_InvoiceNumber",30)
  inv_no.Click()
  inv_no.Keys("^a[Del]")
  Delay(1000)
  inv_no.Keys(invoice_number)
  self.log_message_web("Invoice Number : "+VarToStr(invoice_number))
     
# Invoice Date
  inv_date=self.page.FindChild("idStr","vF_InvoiceDate",30)
  inv_date.Click()
  inv_date.Keys("^a[Del]")
  Delay(1000)
  inv_date.Keys(aqDateTime.Today())
  inv_date.keys("[Tab]")
  Delay(3000)
  inv_date=inv_date.value  
  self.log_message_web("Invoice Date : "+VarToStr(inv_date))
     
# PO Number     
  po_no=self.page.FindChild("idStr","vF_PONumber",30)
  po_no.Click()
  po_no.Keys("^a[Del]")
  Delay(1000)
  po_no.Keys(VarToStr(app1.Cells.Item[2,3]))
  
  # Message popup 1
  
  self.page.Wait()
  self.wait_until_page_loaded()  
  popup=self.page.FindChild("idStr","messagebox-1001",40)
  popup_text = popup.contentText
  if popup.Exists: 
     popup.FindChild("idStr","OK",40).Click()
     Delay(9000)
     
  # Message popup 2
  
  self.page.Wait()
  self.wait_until_page_loaded()  
  if popup.Exists: 
     popup.FindChild("idStr","OK",40).Click()
     Delay(9000)
    
  
# Update Vendor/site 

  self.page.FindChild("idStr","vF_Button_1",30).Click()
  Delay(6000)
  self.wait_until_page_loaded()
  self.page.FindChild("idStr","TextBoxName",30).Keys(VarToStr(app1.Cells.Item[2,4])) # self.page.FindChild("idStr","TextBoxName",30).Keys(VarToStr(app1.Cells.Item[2,4]))
  Delay(1000)
  self.page.FindChild("idStr","PushButtonSearch",30).Click()
  Delay(2000)
  self.page.FindChild("idStr","List",30).SelectItem(0)
  Delay(1000)
  self.page.FindChild("idStr","OK",30).Click()  
  Delay(3000)
  self.wait_until_page_loaded()
  self.wait_until_processing()
  
  vendor=self.page.FindChild("idStr","vF_VendorID",40).contentText
  self.log_message_web("Updated Vendor ID : "+VarToStr(vendor))
      
  siteID=self.page.FindChild("idStr","vF_SiteID",40).contentText
  self.log_message_web("Updated Site ID : "+VarToStr(siteID)) 
         
  ship_to=self.page.FindChild("idStr","vF_ShipTo",30)
  ship_to.Keys(app1.Cells.Item[2,10]) #ship_to.Keys(app1.Cells.Item[2,8])
  self.log_message_web("Ship To : "+VarToStr(app1.Cells.Item[2,10])) #self.log_message_web("Ship To : "+VarToStr(app1.Cells.Item[2,8]))
  
  approver = self.page.FindChild("idStr","vF_Approver",30)
  approver.Keys(app1.Cells.Item[2,11]) #approver.Keys(app1.Cells.Item[2,11])
    
  supplier=self.page.FindChild("idStr","vF_VendorASSA",30).value   
  self.log_message_web("Supplier : "+VarToStr(supplier))
  
  location=self.page.FindChild("idStr","vF_Location",30).value  
  self.log_message_web("Location : "+VarToStr(location))
  
  scan_date=self.page.FindChild("idStr","vF_ScanDate",30).value  
  self.log_message_web("Scan Date : "+VarToStr(scan_date))
    
  batchname=self.page.FindChild("idStr","vF_BatchName",30).value   
  self.log_message_web("BatchName : "+VarToStr(batchname))
    
#  if VarToStr(batch_name)==VarToStr(batchname):
#    self.log_checkpoint_message_web("Batch Name match successfully") 
#    
#      
#
  po_line_panel=Sys.Browser("iexplore").Page("*").Panel(0).Panel(0).Form("aspnetForm").Panel(2).Panel(0).Panel(0).Panel("layout").Panel("container").Panel(0).Panel("body").Panel(0).Panel("body").Panel("verManager").Panel("verManager_body").Panel("verificationForm").Panel(0)
  po_line_table=Sys.Browser("iexplore").Page("*").Panel(0).Panel(0).Form("aspnetForm").Panel(2).Panel(0).Panel(0).Panel("layout").Panel("container").Panel(0).Panel("body").Panel(0).Panel("body").Panel("verManager").Panel("verManager_body").Panel("verificationForm").Panel(0).Panel("vF_LineItemstableContainer").Panel(0).Panel(1).Panel(1).Table("vF_LineItems_table")

# Creation of line items based on the spreadsheet
  # Deletion of existing rows
  Sys.Browser("iexplore").Page("*").FindChild("idStr","vF_Button_6",30).Click() #self.page.FindChild("idStr","ext-gen1267").Click()
  delay(3000)
  rowno=2
  linerow=0
  while not VarToInt(app1.Cells.Item[rowno,1])==0:
    txnum=app.Cells.Item[rowno,1] 
    po_line_table.Cell(linerow, 0).Panel(0).Click() # 
        
    po_line_table.Cell(linerow, 0).Panel(0).FindChild("idStr","vF_LineItems_0_"+VarToStr(linerow),30).Click() # Item desc
    delay(2000)
    po_line_table.Cell(linerow, 0).Panel(0).Textarea("vF_LineItems_0_"+VarToStr(linerow)).Keys(VarToStr(app1.Cells.item[rowno,14])) #po_line_table.Cell(linerow, 0).Panel(0).Textarea("vF_LineItems_0_"+VarToStr(linerow)).Keys(VarToStr(app1.Cells.item[rowno,26]))
    self.log_message_web("Line Description : "+VarToStr(app1.Cells.item[rowno,14]))#self.log_message_web("Line Description : "+VarToStr(app1.Cells.item[rowno,26]))
    delay(2000)
    
    po_line_table.Cell(linerow, 1).Panel(0).FindChild("idStr","vF_LineItems_1_"+VarToStr(linerow),30).Click()
    delay(2000)
    po_line_table.Cell(linerow, 1).Panel(0).Textarea("vF_LineItems_1_"+VarToStr(linerow)).Keys(VarToStr(app1.Cells.item[rowno,15])) #po_line_table.Cell(linerow, 1).Panel(0).Textarea("vF_LineItems_1_"+VarToStr(linerow)).Keys(VarToStr(app1.Cells.item[rowno,27]))
    self.log_message_web("UOM : "+VarToStr(app1.Cells.item[rowno,15])) #self.log_message_web("UOM : "+VarToStr(app1.Cells.item[rowno,27]))
    delay(2000)
    
    po_line_table.Cell(linerow, 2).Panel(0).FindChild("idStr","vF_LineItems_2_"+VarToStr(linerow),30).Click()
    delay(2000)
    po_line_table.Cell(linerow, 2).Panel(0).Textarea("vF_LineItems_2_"+VarToStr(linerow)).Keys(VarToStr(app1.Cells.item[rowno,16])) #po_line_table.Cell(linerow, 2).Panel(0).Textarea("vF_LineItems_2_"+VarToStr(linerow)).Keys(VarToStr(app1.Cells.item[rowno,28]))
    self.log_message_web("Unit Price : "+VarToStr(app1.Cells.item[rowno,16])) #self.log_message_web("Unit Price : "+VarToStr(app1.Cells.item[rowno,28]))
    delay(2000)
    
    po_line_table.Cell(linerow, 4).Panel(0).FindChild("idStr","vF_LineItems_4_"+VarToStr(linerow),30).Click() 
    delay(2000)
    po_line_table.Cell(linerow, 4).Panel(0).Textarea("vF_LineItems_4_"+VarToStr(linerow)).Keys(VarToStr(app1.Cells.item[rowno,18]))
    self.log_message_web("Quantity : "+VarToStr(app1.Cells.item[rowno,18]))
    delay(2000)
    
    web_utils.log_checkpoint("Entered PO line data successfully",500,self.page)
    
    po_line_table.Cell(linerow, 5).Panel(0).FindChild("idStr","vF_LineItems_5_"+VarToStr(linerow),30).DblClick()
    po_line_table.Cell(linerow, 5).Panel(0).FindChild("idStr","vF_LineItems_5_"+VarToStr(linerow),30).Keys("^a[Del]")
    po_line_table.Cell(linerow, 5).Panel(0).FindChild("idStr","vF_LineItems_5_"+VarToStr(linerow),30).Keys(VarToStr(app1.Cells.item[rowno,20]))
    self.log_message_web("Individual Line Total : "+VarToStr(app1.Cells.item[rowno,20]))
    line_total_field = po_line_panel.Panel("vF_LinesTotal_Container").Textbox("vF_LinesTotal")
    line_total_field.Click()
    line_total_field.Keys("[Home]"+"![End]"+"[Del]")
    line_total_field.Keys(VarToStr(app1.Cells.item[rowno,20]))
    line_total = line_total_field.Text
    self.log_message_web("Combined Lines Total : "+VarToStr(line_total))
    delay(2000)
    web_utils.log_checkpoint("Updated Description, UnitPrice, UOM, Line Total Details successfully for Line Number: "+VarToStr(rowno-1),500,self.page) 
        
    if txnum != app.Cells.Item[rowno+1,1]:
      break
    rowno=rowno+1
    linerow=linerow+1
    
## Click on Add line item button
#    po_line_panel.Panel("vF_LineItemstableContainer").Panel(1).Panel(8).Click()
#    delay(4000)     
#  Delay(2000)
  
# Enter Sub total,qst,total
  sub_total = self.page.FindChild("idStr","vF_AmountSubtotal",30)
  sub_total.Click()
  sub_total.Keys("^a[Del]")
  Delay(2000)
  sub_total.Keys(app1.Cells.item[2,8]) 
  self.log_message_web("Sub_total : "+VarToStr(app1.Cells.item[2,8]))
  
  misc_charge = self.page.FindChild("idStr","vF_AmountMisc",30)
  misc_charge.Click()
  misc_charge.Keys("^a[Del]")
  Delay(2000)
  misc_charge.Keys(app1.Cells.item[2,29])
  self.log_message_web("Misc_charge : "+VarToStr(app1.Cells.item[2,29]))
  
  freight = self.page.FindChild("idStr","vF_AmountFreightPrepaidAndAdded",30)
  freight.Click()
  freight.Keys("^a[Del]")
  Delay(2000)
  freight.Keys(app1.Cells.item[2,28])
  self.log_message_web("Freight : "+VarToStr(app1.Cells.item[2,28])) 
   
  us_sales_tax = self.page.FindChild("idStr","vF_AmountTax",30)
  us_sales_tax.Click()
  us_sales_tax.Keys("^a[Del]")
  Delay(2000)
  us_sales_tax.Keys(app1.Cells.item[2,19])
  self.log_message_web("Sales Tax :"+VarToStr(app1.Cells.item[2,19])) 
  
  discount = self.page.FindChild("idStr","vF_AmountDiscount",30)
  discount.Click()
  discount.Keys("^a[Del]")
  Delay(2000)
  discount.Keys(app1.Cells.item[2,30]) 
  self.log_message_web("Discount : "+VarToStr(app1.Cells.item[2,30]))
  
  # The below taxes are for Canada location - We will put the condition based on location later
  
#  gst_or_hst = self.page.FindChild("idStr","vF_AmountMiscGST",30)
#  gst_or_hst.Click()
#  gst_or_hst.Keys("^a[Del]")
#  Delay(2000)
#  gst_or_hst.Keys(app1.Cells.item[2,22]) 
#  self.log_message_web("GST/HST : "+VarToStr(app1.Cells.item[2,22]))
#  
#  qst=self.page.FindChild("idStr","vF_AmountMiscQST",30)
#  qst.Click()
#  qst.Keys("^a[Del]")
#  Delay(2000)
#  qst.Keys(app1.Cells.item[2,23]) 
#  self.log_message_web("QST : "+VarToStr(app1.Cells.item[2,23]))
#  
#  pst=self.page.FindChild("idStr","vF_AmountMiscPST",30) 
#  pst.Click()
#  pst.Keys("^a[Del]")
#  Delay(2000)
#  pst.Keys(app1.Cells.item[2,24]) 
#  self.log_message_web("PST : "+VarToStr(app1.Cells.item[2,24]))
  
  tot_amt=self.page.FindChild("idStr","vF_AmountTotal",30)
  tot_amt.Click()
  tot_amt.Keys("^a[Del]")

# Check back if the below lines are needed
#  self.page.FindChild("idStr","vF_AmountTotal",30).Keys(VarToStr(app1.Cells.Item[2,9])) #tot_amt=self.page.FindChild("idStr","vF_AmountTotal",30).value  
#  self.log_message_web("Total Amount : "+VarToStr(VarToStr(app1.Cells.Item[2,9]))) 

  
  
  
#  Delay(2000)
#  tot_amt.Keys(app1.Cells.item[2,21])   
#  web_utils.log_checkpoint("Total Amount : "+VarToStr(app1.Cells.item[2,21]),500, self.page) 
  if (self.oper_unit=="US"): 
    taxesAnddis=(VarToFloat(app1.Cells.item[2,19])+VarToFloat(app1.Cells.item[2,28])+VarToFloat(app1.Cells.item[2,29])-VarToFloat(app1.Cells.item[2,30]))
  else:
    taxesAnddis=(VarToFloat(app1.Cells.item[2,31])+VarToFloat(app1.Cells.item[2,32])+VarToFloat(app1.Cells.item[2,33])+VarToFloat(app1.Cells.item[2,28])+VarToFloat(app1.Cells.item[2,29])-VarToFloat(app1.Cells.item[2,30])) # +VarToFloat(app1.Cells.item[2,19])
  total=VarToFloat(app1.Cells.item[2,8])+taxesAnddis
  tot_amt.Keys(total)
  self.log_message_web("Invoice Total :"+VarToStr(total))
  delay(2000)
  web_utils.log_checkpoint("Invoice Header Total and Tax Details Entered Successfully",500,self.page)
   
  self.page.FindChild("idStr","vF_Currency",30).Click()
  delay(1000)
  self.page.FindChild("idStr","vF_Currency",30).Keys("^a[Del]")
  delay(2000)
  self.page.FindChild("idStr","vF_Currency",30).Keys("USD")
  delay(2000)
  self.page.FindChild("idStr","vF_Currency",30).Keys("[Enter]")
  
  if self.page.FindChild("idStr","messagebox-1001",40).Exists:
    pass
  else:
    self.page.FindChild("idStr","vF_Currency",30).Click()
    delay(1000)
    self.page.FindChild("idStr","vF_Currency",30).Keys("[Enter]")
    delay(4000)



#message box
  self.page.Wait()
  self.wait_until_page_loaded()  
  popup=self.page.FindChild("idStr","messagebox-1001",40)
  popup_text = popup.contentText
  if popup.Exists: 
    if StrMatches('Error',popup_text) == True:
       self.log_error_message("Validation Errored Out: Resubmit the Page")
       popup.FindChild("idStr","OK",40).Click()
       Delay(9000)
    popup.FindChild("idStr","OK",40).Click()
    Delay(9000)     
  else:
     self.log_error_message("Unable to find the Confirmation Pop Up: Check for Errors")
     
  web_utils.log_checkpoint("Confirmation Pop-up available to release the verified batch "+batch_id,500,self.page)
  self.popup_wnd_click_yes()
  Delay(6000)
  popup=self.page.FindChildEx("Name","Panel('messagebox')",30,True,6000)
  popup.FindChild("idStr","button-1009-btnInnerEl",30).Click()  
  Delay(3000)
  self.wait_until_page_loaded()   
  self.page.wait()
  
  self.wait_until_page_loaded()  
  popup=self.page.FindChild("idStr","messagebox-1001",40)
  popup_text = popup.contentText
  if popup.Exists: 
       popup.FindChild("idStr","OK",40).Click()
       Delay(9000)    
  else:
     pass
  popup=self.page.FindChildEx("Name","Panel('messagebox')",30,True,6000)
  popup.FindChild("idStr","button-1009-btnInnerEl",30).Click()  
  Delay(3000)
  self.wait_until_page_loaded()   
  self.page.wait()
  
  if self.page.FindChild("contentText","Options",40).Exists:
    pass
  else:
    batchname=self.page.FindChild("idStr","vF_BatchName",30).value 
  self.log_checkpoint_message_web("All invoices are verified and released for batch: "+batch_id)
  web_utils.log_checkpoint("Successfully verified and released WFR BatchID: "+batch_id+" for WCC Batch Name: "+batch_name,500,self.page) 
#  
#  

def sample():  
  po_no=Sys.Browser("iexplore").Page("*").FindChild("idStr","vF_PONumber",30)
  po_no.Click()
  po_no.Keys("[Enter]")
  
                                       #EvaluateXPath("//table[@class='x-grid-table x-grid-table-resizer']//span")
#    po_line_table=Sys.Browser("iexplore").Page("*").Panel(0).Panel(0).Form("aspnetForm").Panel(2).Panel(0).Panel(0).Panel("layout").Panel("container").Panel(0).Panel("body").Panel(0).Panel("body").Panel("verManager").Panel("verManager_body").Panel("verificationForm").Panel(0).Panel("vF_LineItemstableContainer").Panel(0).Panel(1).Panel(1).Table("vF_LineItems_table")
#    po_line_table.Cell(0, 0).Panel(0).FindChild("idStr","vF_LineItems_0_0",30).Click() # Item desc
#    Sys.Browser("iexplore").Page("*").FindChild("idStr","vF_Button_6",30).Click()
#    delay(3000)
#    po_line_table.Cell(0, 0).Panel(0).Click()
#    delay(1000)
#    po_line_table.Cell(0, 0).Panel(0).Textarea("vF_LineItems_0_0").Keys(VarToStr("Testing"))
#    
#    
#    delay(2000)
#    po_line_table.Cell(0, 0).Panel(0).Textarea("vF_LineItems_0_0").Keys("Testing") #po_line_table.Cell(linerow, 0).Panel(0).Textarea("vF_LineItems_0_"+VarToStr(linerow)).Keys(VarToStr(app1.Cells.item[rowno,26]))
#    self.log_message_web("Line Description : "+VarToStr(app1.Cells.item[rowno,14]))#self.log_message_web("Line Description : "+VarToStr(app1.Cells.item[rowno,26]))
#    delay(2000)
#    
#    po_line_table.Cell(linerow, 1).Panel(0).FindChild("idStr","vF_LineItems_1_"+VarToStr(linerow),30).Click()
#    delay(2000)
#    po_line_table.Cell(linerow, 1).Panel(0).Textarea("vF_LineItems_1_"+VarToStr(linerow)).Keys(VarToStr(app1.Cells.item[rowno,15])) #po_line_table.Cell(linerow, 1).Panel(0).Textarea("vF_LineItems_1_"+VarToStr(linerow)).Keys(VarToStr(app1.Cells.item[rowno,27]))
#    self.log_message_web("UOM : "+VarToStr(app1.Cells.item[rowno,15])) #self.log_message_web("UOM : "+VarToStr(app1.Cells.item[rowno,27]))
#    delay(2000)
#    
#    po_line_table.Cell(linerow, 2).Panel(0).FindChild("idStr","vF_LineItems_2_"+VarToStr(linerow),30).Click()
#  






#from webCenterVerifier import *
#import random
#
#
#class WCC_Verify_single_page_po_us_v12(webCenterVerifier):
#        
# def goto_url(self,url):
#   super().goto_url(self.testConfig['ebiz']['WebCentVerUrl'])
#      
# def action(self,book): 
#   
#  app = book.Sheets.item["wci_capture"]
#  app1 = book.Sheets.item["wci_verifier"]
#  
#  if self.page.FindChild("contentText","Options",40).Exists:
#      web_utils.log_checkpoint("Able to Login to WFR Application Successfully",500,self.page)
#  self.page.FindChild("contentText","Options",40).Click()
#  self.page.FindChild("idStr","item_custom_filter-itemEl",40).Click()
#  Delay(1000)
#  self.wait_until_processing()
#  batch_name=VarToStr(app.Cells.item[2,2])
#  self.page.FindChild("idStr","bfdFilter",40).Keys("^a[Del]")
#  self.page.FindChild("idStr","bfdFilter",40).SetText("[Capture Batch ID] ='"+VarToStr(batch_name)+"'")
#  Delay(2000)
#  self.page.FindChild("contentText","Apply",40).Click()
#  Delay(1000)
#  self.wait_until_processing()
# 
## Refresh page until expected batch found
#  while  Sys.Browser("iexplore").Page("*").EvaluateXPath("//table[@class='x-grid-table x-grid-table-resizer']//span")==None:    
#    Sys.Browser("iexplore").Page("*").Keys("[F5]")
#    Sys.Browser("iexplore").Page("*").Wait()
#    Delay(2000)
#    Sys.Browser("iexplore").Page("*").Wait()  
#  Delay(2000)
#  web_utils.log_checkpoint("Filter Options applied for WCC Batch Name: "+batch_name,500,self.page)
#  
## Check the verifier batch id's(invoices) created for "Capture batch id":
#  i = 1
#  j = 0
#  val2 = VarToStr(app.Cells.Item[2,2])
#  fltr_view = Sys.Browser("iexplore").Page("http://tmnh1of.manheim.com/WebVerifier/BatchView.aspx").Panel(0).Panel(0).Form("aspnetForm").Panel(2).Panel(0).Panel(0).Panel("container").Panel(0).Panel("body").Panel("gridCtl").Panel("body").Panel("gridview").Table(0)  
#  captr_btch_id = fltr_view.Cell(i, 13).Panel(0)
#  val1 = captr_btch_id.contentText
#  while  val2 == val1:
#    Sys.HighlightObject(captr_btch_id)
#    captr_btch_id.Click()
#    batch_id = self.page.EvaluateXpath("//table[@class='x-grid-table x-grid-table-resizer']//span")[j].contentText
#    i = i+1
#    j = j+1
#    captr_btch_id = fltr_view.Cell(i, 13).Panel(0)
#    self.log_message_web("Available WFR BatchID No:"+VarToStr(i-1)+" = "+batch_id)
#    val1 = captr_btch_id.contentText
#  self.log_message_web("Count of verifier batch files created for 'Capture Batch Name' - "+VarToStr(app.Cells.Item[2,2])+" = "+VarToStr(j))
#
## Select the invoice and navigate to details:
#  self.page.EvaluateXPath("//table[@class='x-grid-table x-grid-table-resizer']//span")[0].Click()
#  web_utils.log_checkpoint("Selecting WFR BatchID: "+batch_id+" for processing",500,self.page) 
#  Delay(1000)
#  self.wait_until_page_loaded()
#  Delay(3000)
#  self.page.Wait()
#  self.wait_until_page_loaded()
#  batchname=self.page.FindChild("idStr","vF_BatchName",30).value   
#  self.log_message_web("BatchName : "+VarToStr(batchname))  
#  if VarToStr(batch_name)==VarToStr(batchname):
#      self.log_checkpoint_message_web("Batch Name match successful") 
#      Delay(3000)  
#      invoice_number = "TEST_CA_PO_"+VarToStr(aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%m_%y"))+"_"+VarToStr(random.randint(1111,9999))
#
## Get Project Status & Set invoice type
#  project_status = VarToStr(self.page.FindChild("idStr","vF_Project",30).status)
#  invoice = self.page.FindChild("idStr","vF_InvoiceType-inputEl",30)
#  inv_type = invoice.Text
#  if inv_type=="NO-PO":
#    invoice.Click()
#    invoice.Keys("[Up]")
#    invoice.Keys("[Enter]")
#    web_utils.log_checkpoint("Changing Invoice Type to required value: PO",500,self.page) 
#
##  project_status = VarToStr(self.page.FindChild("idStr","vF_Project",30).status)
##  inv_type = self.page.FindChild("idStr","vF_InvoiceType-inputEl",30).Text
##  if inv_type=="NO-PO":
##     self.page.FindChild("idStr","vF_InvoiceType-inputEl",30).SetText("PO")
##  web_utils.log_checkpoint("Expected Invoice Type 'PO' found.",500,self.page) 
#
## Get Company code and Operating Unit; Project Selection if required
#  comp_code=self.page.FindChild("idStr","vF_CompanyCode",30).value  
#  self.log_message_web("Company Code :"+VarToStr(comp_code))
#  op_unit=self.page.FindChild("idStr","vF_OperatingUnit",30).value  
#  self.log_message_web("Operating Unit :"+VarToStr(op_unit))
##  if VarToStr(app.Cells.Item[2,7])=="Yes" and project_status == "False":
##    self.page.FindChild("idStr","vF_Project",30).Click()
##    web_utils.log_checkpoint("Selected Project Checkbox Successfully",500,self.page)
#
##  Set Invoice Number
#  self.page.Find("idStr","ctl00_ctl00_ContentPlace_WorkArea_documentViewerCtl_image",40).Click()
#  Delay(3000)    
#  inv_no=self.page.FindChild("idStr","vF_InvoiceNumber",30)
#  inv_no.Click()
#  inv_no.Keys("^a[Del]")
#  Delay(1000)
#  inv_no.Keys(invoice_number)
#  self.log_message_web("Invoice Number : "+VarToStr(invoice_number))
#     
## Invoice Date
#  inv_date=self.page.FindChild("idStr","vF_InvoiceDate",30)
#  inv_date.Click()
#  inv_date.Keys("^a[Del]")
#  Delay(1000)
#  inv_date.Keys(aqDateTime.Today())
#  inv_date.keys("[Tab]")
#  Delay(3000)
#  inv_date=inv_date.value  
#  self.log_message_web("Invoice Date : "+VarToStr(inv_date))
#     
## PO Number     
#  po_no=self.page.FindChild("idStr","vF_PONumber",30)
#  po_no.Click()
#  po_no.Keys("^a[Del]")
#  Delay(1000)
#  po_no.Keys(VarToStr(app1.Cells.Item[2,7]))
#  
## Update Vendor/site 
#
#  self.page.FindChild("idStr","vF_Button_1",30).Click()
#  Delay(6000)
#  self.wait_until_page_loaded()
#  self.page.FindChild("idStr","TextBoxName",30).Keys(VarToStr(app1.Cells.Item[2,13]))
#  Delay(1000)
#  self.page.FindChild("idStr","PushButtonSearch",30).Click()
#  Delay(2000)
#  self.page.FindChild("idStr","List",30).SelectItem(0)
#  Delay(1000)
#  self.page.FindChild("idStr","OK",30).Click()  
#  Delay(3000)
#  self.wait_until_page_loaded()
#  self.wait_until_processing()
#  
#  vendor=self.page.FindChild("idStr","vF_VendorID",40).contentText
#  self.log_message_web("Updated Vendor ID : "+VarToStr(vendor))
#      
#  siteID=self.page.FindChild("idStr","vF_SiteID",40).contentText
#  self.log_message_web("Updated Site ID : "+VarToStr(siteID)) 
#         
#  ship_to=self.page.FindChild("idStr","vF_ShipTo",30)
#  ship_to.Keys(app1.Cells.Item[2,8])
#  self.log_message_web("Ship To : "+VarToStr(app1.Cells.Item[2,8]))
#  
#  approver = self.page.FindChild("idStr","vF_Approver",30)
#  approver.Keys(app1.Cells.Item[2,11])
#    
#  supplier=self.page.FindChild("idStr","vF_VendorASSA",30).value   
#  self.log_message_web("Supplier : "+VarToStr(supplier))
#  
#  location=self.page.FindChild("idStr","vF_Location",30).value  
#  self.log_message_web("Location : "+VarToStr(location))
#  
#  scan_date=self.page.FindChild("idStr","vF_ScanDate",30).value  
#  self.log_message_web("Scan Date : "+VarToStr(scan_date))
#    
#  batchname=self.page.FindChild("idStr","vF_BatchName",30).value   
#  self.log_message_web("BatchName : "+VarToStr(batchname))
#    
#  if VarToStr(batch_name)==VarToStr(batchname):
#    self.log_checkpoint_message_web("Batch Name match successfully") 
#    
#  tot_amt=self.page.FindChild("idStr","vF_AmountTotal",30).value  
#  self.log_message_web("Total Amount : "+VarToStr(tot_amt)) 
#  
## Click on the left sceen window then do page down
#  self.page.FindChild("idStr","verManager-body",40).Click(673, 236)
#  self.page.Keys("[PageDown]")
#  self.page.Keys("[PageDown]")
#  Delay(3000)
#  self.page.NativeWebObject.Find("idStr","vF_Button_4","BUTTON").ScrollIntoView()
#  Delay(2000)
#  self.page.NativeWebObject.Find("idStr","vF_Button_4","BUTTON").Click()
#  Delay(1000)  
#  self.wait_until_processing()
#  self.page.FindChild("idStr","verManager-body",40).Click(673, 236)
#  self.page.Keys("[PageDown]")
#  Delay(1000)    
#  self.log_checkpoint_message_web("Click Replace PO lines table successfull") 
#  web_utils.log_checkpoint("Deleted Existing Line Items for the Invoice Successfully",500,self.page)     
#
#  po_line_panel=Sys.Browser("iexplore").Page("*").Panel(0).Panel(0).Form("aspnetForm").Panel(2).Panel(0).Panel(0).Panel("layout").Panel("container").Panel(0).Panel("body").Panel(0).Panel("body").Panel("verManager").Panel("verManager_body").Panel("verificationForm").Panel(0)
#  po_line_table=Sys.Browser("iexplore").Page("*").Panel(0).Panel(0).Form("aspnetForm").Panel(2).Panel(0).Panel(0).Panel("layout").Panel("container").Panel(0).Panel("body").Panel(0).Panel("body").Panel("verManager").Panel("verManager_body").Panel("verificationForm").Panel(0).Panel("vF_LineItemstableContainer").Panel(0).Panel(1).Panel(1).Table("vF_LineItems_table")
#
## Creation of line items based on the spreadsheet
#  
#  rowno=2
#  linerow=0
#  while not VarToInt(app.Cells.Item[rowno,1])==0:
#    txnum=app.Cells.Item[rowno,1] 
#         
#    po_line_table.Cell(linerow, 0).Panel(0).FindChild("idStr","vF_LineItems_0_"+VarToStr(linerow),30).Click() # Item desc
#    delay(2000)
#    po_line_table.Cell(linerow, 0).Panel(0).Textarea("vF_LineItems_0_"+VarToStr(linerow)).Keys(VarToStr(app1.Cells.item[rowno,26]))
#    self.log_message_web("Line Description : "+VarToStr(app1.Cells.item[rowno,26]))
#    delay(2000)
#    
#    po_line_table.Cell(linerow, 1).Panel(0).FindChild("idStr","vF_LineItems_1_"+VarToStr(linerow),30).Click()
#    delay(2000)
#    po_line_table.Cell(linerow, 1).Panel(0).Textarea("vF_LineItems_1_"+VarToStr(linerow)).Keys(VarToStr(app1.Cells.item[rowno,27]))
#    self.log_message_web("UOM : "+VarToStr(app1.Cells.item[rowno,27]))
#    delay(2000)
#    
#    po_line_table.Cell(linerow, 2).Panel(0).FindChild("idStr","vF_LineItems_2_"+VarToStr(linerow),30).Click()
#    delay(2000)
#    po_line_table.Cell(linerow, 2).Panel(0).Textarea("vF_LineItems_2_"+VarToStr(linerow)).Keys(VarToStr(app1.Cells.item[rowno,28]))
#    self.log_message_web("Unit Price : "+VarToStr(app1.Cells.item[rowno,28]))
#    delay(2000)
#    
#    po_line_table.Cell(linerow, 4).Panel(0).FindChild("idStr","vF_LineItems_4_"+VarToStr(linerow),30).Click() 
#    delay(2000)
#    po_line_table.Cell(linerow, 4).Panel(0).Textarea("vF_LineItems_4_"+VarToStr(linerow)).Keys(VarToStr(app1.Cells.item[rowno,30]))
#    self.log_message_web("Quantity : "+VarToStr(app1.Cells.item[rowno,30]))
#    delay(2000)
#    
#    web_utils.log_checkpoint("Entered PO line data successfully",500,self.page)
#    
#    po_line_table.Cell(linerow, 5).Panel(0).FindChild("idStr","vF_LineItems_5_"+VarToStr(linerow),30).DblClick()
#    po_line_table.Cell(linerow, 5).Panel(0).FindChild("idStr","vF_LineItems_5_"+VarToStr(linerow),30).Keys("^a[Del]")
#    po_line_table.Cell(linerow, 5).Panel(0).FindChild("idStr","vF_LineItems_5_"+VarToStr(linerow),30).Keys(VarToStr(app1.Cells.item[rowno,34]))
#    self.log_message_web("Individual Line Total : "+VarToStr(app1.Cells.item[rowno,34]))
#    line_total_field = po_line_panel.Panel("vF_LinesTotal_Container").Textbox("vF_LinesTotal")
#    line_total_field.Click()
#    line_total_field.Keys("[Home]"+"![End]"+"[Del]")
#    line_total_field.Keys(VarToStr(app1.Cells.item[rowno,34]))
#    line_total = line_total_field.Text
#    self.log_message_web("Combined Lines Total : "+VarToStr(line_total))
#    delay(2000)
#    web_utils.log_checkpoint("Updated Description, UnitPrice, UOM, Line Total Details successfully for Line Number: "+VarToStr(rowno-1),500,self.page) 
#        
#    if txnum != app.Cells.Item[rowno+1,1]:
#      break
#    rowno=rowno+1
#    linerow=linerow+1
#    
## Click on Add line item button
#    po_line_panel.Panel("vF_LineItemstableContainer").Panel(1).Panel(8).Click()
#    delay(4000)     
#  Delay(2000)
#  
## Enter Sub total,qst,total
#  sub_total = self.page.FindChild("idStr","vF_AmountSubtotal",30)
#  sub_total.Click()
#  sub_total.Keys("^a[Del]")
#  Delay(2000)
#  sub_total.Keys(app1.Cells.item[2,16]) 
#  self.log_message_web("Sub_total : "+VarToStr(app1.Cells.item[2,16]))
#  
#  misc_charge = self.page.FindChild("idStr","vF_AmountMisc",30)
#  misc_charge.Click()
#  misc_charge.Keys("^a[Del]")
#  Delay(2000)
#  misc_charge.Keys(app1.Cells.item[2,17])
#  self.log_message_web("Misc_charge : "+VarToStr(app1.Cells.item[2,17]))
#  
#  freight = self.page.FindChild("idStr","vF_AmountFreightPrepaidAndAdded",30)
#  freight.Click()
#  freight.Keys("^a[Del]")
#  Delay(2000)
#  freight.Keys(app1.Cells.item[2,18])
#  self.log_message_web("Freight : "+VarToStr(app1.Cells.item[2,18])) 
#   
#  us_sales_tax = self.page.FindChild("idStr","vF_AmountTax",30)
#  us_sales_tax.Click()
#  us_sales_tax.Keys("^a[Del]")
#  Delay(2000)
#  us_sales_tax.Keys(app1.Cells.item[2,19])
#  self.log_message_web("Sales Tax : 0.00") 
#  
#  discount = self.page.FindChild("idStr","vF_AmountDiscount",30)
#  discount.Click()
#  discount.Keys("^a[Del]")
#  Delay(2000)
#  discount.Keys(app1.Cells.item[2,20]) 
#  self.log_message_web("Discount : "+VarToStr(app1.Cells.item[2,20]))
#  
#  gst_or_hst = self.page.FindChild("idStr","vF_AmountMiscGST",30)
#  gst_or_hst.Click()
#  gst_or_hst.Keys("^a[Del]")
#  Delay(2000)
#  gst_or_hst.Keys(app1.Cells.item[2,22]) 
#  self.log_message_web("GST/HST : "+VarToStr(app1.Cells.item[2,22]))
#  
#  qst=self.page.FindChild("idStr","vF_AmountMiscQST",30)
#  qst.Click()
#  qst.Keys("^a[Del]")
#  Delay(2000)
#  qst.Keys(app1.Cells.item[2,23]) 
#  self.log_message_web("QST : "+VarToStr(app1.Cells.item[2,23]))
#  
#  pst=self.page.FindChild("idStr","vF_AmountMiscPST",30) 
#  pst.Click()
#  pst.Keys("^a[Del]")
#  Delay(2000)
#  pst.Keys(app1.Cells.item[2,24]) 
#  self.log_message_web("PST : "+VarToStr(app1.Cells.item[2,24]))
#  
#  tot_amt=self.page.FindChild("idStr","vF_AmountTotal",30)
#  tot_amt.Click()
#  tot_amt.Keys("^a[Del]")
##  Delay(2000)
##  tot_amt.Keys(app1.Cells.item[2,21])   
##  web_utils.log_checkpoint("Total Amount : "+VarToStr(app1.Cells.item[2,21]),500, self.page) 
#  if (self.oper_unit=="US"): 
#    taxesAnddis=(VarToFloat(app1.Cells.item[2,17])+VarToFloat(app1.Cells.item[2,18])+VarToFloat(app1.Cells.item[2,19])-VarToFloat(app1.Cells.item[2,20]))
#  else:
#    taxesAnddis=(VarToFloat(app1.Cells.item[2,17])+VarToFloat(app1.Cells.item[2,18])+VarToFloat(app1.Cells.item[2,22])+VarToFloat(app1.Cells.item[2,24])+VarToFloat(app1.Cells.item[2,23])+VarToFloat(app1.Cells.item[2,19])-VarToFloat(app1.Cells.item[2,20]))
#  total=VarToFloat(app1.Cells.item[2,16])+taxesAnddis
#  tot_amt.Keys(total)
#  self.log_message_web("Invoice Total :"+VarToStr(total))
#  delay(2000)
#  web_utils.log_checkpoint("Invoice Header Total and Tax Details Entered Successfully",500,self.page)
#   
#  self.page.FindChild("idStr","vF_Currency",30).Click()
#  delay(1000)
#  self.page.FindChild("idStr","vF_Currency",30).Keys("^a[Del]")
#  delay(2000)
#  self.page.FindChild("idStr","vF_Currency",30).Keys("CAD")
#  delay(2000)
#  self.page.FindChild("idStr","vF_Currency",30).Keys("[Enter]")
#  
#  if self.page.FindChild("idStr","messagebox-1001",40).Exists:
#    pass
#  else:
#    self.page.FindChild("idStr","vF_Currency",30).Click()
#    delay(1000)
#    self.page.FindChild("idStr","vF_Currency",30).Keys("[Enter]")
#    delay(4000)
#
#
### Update Invoice number
##  self.page.FindChild("idStr","verManager-body",40).Click(673, 236)
##  self.page.Keys("[PageUp]")
##  Delay(500)  
##  inv_no=self.page.FindChild("idStr","vF_InvoiceNumber",30)
##  inv_no.Click()
##  Delay(500)
##  inv_no.Keys("[End]")
##  Delay(1000)  
##  inv_no.Keys("_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%H%M%S")+"[Enter]")
##  self.log_message_web("Invoice Number :"+VarToStr(inv_no.contentText))
##  app1.Cells.Item[2,5] =  VarToStr(inv_no.contentText)
#  
##  po_no=self.page.FindChild("idStr","vF_PONumber",30)
##  po_no.Click()
##  po_no.Keys("[Enter]")
##  web_utils.log_checkpoint("Validating the invoice information",500, self.page) 
##
##  Delay(5000)
##  self.page.Wait()
##  self.wait_until_page_loaded()  
##  
##  popup=self.page.FindChild("idStr","messagebox-1001",40)
##  if popup.Exists:
##    popup.FindChild("idStr","OK",40).Click()
##    Delay(9000)
##    web_utils.log_checkpoint("Validation Successful. Invoice ready to be released",500, self.page)
##  else:
##    self.log_error_message("Validation failed. Please correct the errors and try again") 
##  self.popup_wnd_click_yes()
##  web_utils.log_checkpoint("Invoice/Batch released Successfully",500, self.page)
##  Delay(6000)
##  popup=self.page.FindChildEx("Name","Panel('messagebox')",30,True,6000)
##  popup.FindChild("idStr","button-1009-btnInnerEl",30).Click()  
##  Delay(3000)
##  self.wait_until_page_loaded()   
##  self.page.FindChild("contentText","Options",40).Click()
##  self.page.FindChild("idStr","item_custom_filter-itemEl",40).Click()
##  Delay(3000)  
##  self.wait_until_processing()
##  self.page.FindChild("idStr","bfdFilter",40).SetText("")  
##  self.page.FindChild("contentText","Apply",40).Click()
##  Delay(3000)
##  self.page.wait()
#
##message box
#  self.page.Wait()
#  self.wait_until_page_loaded()  
#  popup=self.page.FindChild("idStr","messagebox-1001",40)
#  popup_text = popup.contentText
#  if popup.Exists: 
#    if StrMatches('Error',popup_text) == True:
#       self.log_error_message("Validation Errored Out: Resubmit the Page")
#       popup.FindChild("idStr","OK",40).Click()
#       Delay(9000)
#    popup.FindChild("idStr","OK",40).Click()
#    Delay(9000)     
#  else:
#     self.log_error_message("Unable to find the Confirmation Pop Up: Check for Errors")
#     
#  web_utils.log_checkpoint("Confirmation Pop-up available to release the verified batch "+batch_id,500,self.page)
#  self.popup_wnd_click_yes()
#  Delay(6000)
#  popup=self.page.FindChildEx("Name","Panel('messagebox')",30,True,6000)
#  popup.FindChild("idStr","button-1009-btnInnerEl",30).Click()  
#  Delay(3000)
#  self.wait_until_page_loaded()   
#  self.page.wait()
#  
#  self.wait_until_page_loaded()  
#  popup=self.page.FindChild("idStr","messagebox-1001",40)
#  popup_text = popup.contentText
#  if popup.Exists: 
#       popup.FindChild("idStr","OK",40).Click()
#       Delay(9000)    
#  else:
#     pass
#  popup=self.page.FindChildEx("Name","Panel('messagebox')",30,True,6000)
#  popup.FindChild("idStr","button-1009-btnInnerEl",30).Click()  
#  Delay(3000)
#  self.wait_until_page_loaded()   
#  self.page.wait()
#  
#  if self.page.FindChild("contentText","Options",40).Exists:
#    pass
#  else:
#    batchname=self.page.FindChild("idStr","vF_BatchName",30).value 
#  self.log_checkpoint_message_web("All invoices are verified and released for batch: "+batch_id)
#  web_utils.log_checkpoint("Successfully verified and released WFR BatchID: "+batch_id+" for WCC Batch Name: "+batch_name,500,self.page) 
#
#def sample():
# invoice=Sys.Process("iexplore", 2).Page("http://tmnh1of.manheim.com/WebVerifier/VerificationView.aspx").Panel(0).Panel(0).Form("aspnetForm").Panel(2).Panel(0).Panel(0).Panel("layout").Panel("container").Panel(0).Panel("body").Panel(0).Panel("body").Panel("verManager").Panel("verManager_body").Panel("verificationForm").Panel(0).Panel("vF_InvoiceType_Container").Panel("vF_InvoiceType_c").Table("vF_InvoiceType").Cell(0, 1).Table("vF_InvoiceType_triggerWrap").Cell(0, 0).Textbox("vF_InvoiceType_inputEl")
# invoice.Click()
# invoice.Keys("PO")
# invoice.Keys("Enter")
# 
# 
#  
#
#
#
#
###from dbhelper import *
##from webCenterVerifier import *
###import dbhelper
##import file_system_utils
##import configparser
##import wcc_home_page_v12
##import wcc_login_page_v12
##
###import random
### Code is changed to include more fields (8 in header and 2 in line level) to be entered from the sheet to Verifier
### The above change is requested as part of Scenario review from Req2Check
##
##class WFR_single_page_po_us_v12(webCenterVerifier):
## global book,app
## 
## def login(self):
##    self.login_user="cai-pburugupal"
###    wcc_login_page_v12.username_textfield().SetText(self.login_user)
###    self.log_message_web("Set User ID:  "+self.login_user+" Successful")
###    wcc_login_page_v12.password_textfield().setText(self.testConfig['ebiz']['password'])
###    self.log_message_web("Set Password:  'oracle123' Successful") 
###    wcc_login_page_v12.login_button().Click()  
##       
## def goto_url(self,url):
##   self.testConfig=configparser.ConfigParser()
##   self.testConfig.read(Project.Path+"test_configs\\testconfig_qa.ini") 
##   super().goto_url("http://tmnh1of.manheim.com/WebVerifier/Login.aspx?s=5") #(self.testConfig['ebiz']['webCentVerUrl'])
##      
## def action(self,book):  
##  #app = Sys.OleObject["Excel.Application"]
##  Delay(1000)
##  #app.Visible = "True"
##  app = book.Sheets.item["wci_capture"]
##  delay(4000)
##  self.page.FindChild("contentText","Options",40).Click()
##  delay(4000)
##  self.page.FindChild("idStr","item_custom_filter-itemEl",40).Click()
##  Delay(3000)
##  self.wait_until_processing()
##  #batch_name=VarToStr(app.Cells.item[2,2])
##  batch_name='001-651926' #Capture Id :001-651892	14:20:07	Normal			30.40
##  self.page.FindChild("idStr","bfdFilter",40).SetText("[Capture Batch ID] ='"+VarToStr(batch_name)+"'")
##  self.log_message_web("Capture Id :"+VarToStr(batch_name))
##  Delay(2000)
##  self.page.FindChild("contentText","Apply",40).Click()
##  Delay(1000)
##  self.wait_until_processing()
##  # Refresh page until expected batch found
##  while  Sys.Browser("iexplore").Page("*").EvaluateXPath("//table[@class='x-grid-table x-grid-table-resizer']//span")==None:    
##    Sys.Browser("iexplore").Page("*").Keys("[F5]")
##    Sys.Browser("iexplore").Page("*").Wait()
##    Delay(2000)
##    Sys.Browser("iexplore").Page("*").Wait()    
##  self.page.EvaluateXPath("//table[@class='x-grid-table x-grid-table-resizer']//span")[0].Click()
##  Delay(1000)
##  self.wait_until_page_loaded()
##  app = book.Sheets.item["wci_verifier"]
##  Delay(3000)  
##  inv_type = self.page.FindChild("idStr","vF_InvoiceType-inputEl",30).Text
##  self.log_message_web("Invoice Type :"+inv_type)
##  if inv_type=="PO":
##    self.log_checkpoint_message_web("Expected Invoice Type 'PO' found.") 
##  comp_code=self.page.FindChild("idStr","vF_CompanyCode",30).value  
##  self.log_message_web("Company Code :"+VarToStr(comp_code))
##  op_unit=self.page.FindChild("idStr","vF_OperatingUnit",30).value  
##  self.log_message_web("Operating Unit :"+VarToStr(op_unit))
##  self.page.Find("idStr","ctl00_ctl00_ContentPlace_WorkArea_documentViewerCtl_image",40).Click()
##  Delay(3000)    
##  page=Sys.Browser("iexplore").Page("*").Panel(0).Panel(0).Form("aspnetForm").Panel(2).Panel(0).Panel(0).Panel("layout").Panel("container").Panel(0).Panel("body").Panel(0).Panel("body").Panel("verManager").Panel("verManager_body").Panel("verificationForm").Panel(0)
##  po_line_table=Sys.Browser("iexplore").Page("*").Panel(0).Panel(0).Form("aspnetForm").Panel(2).Panel(0).Panel(0).Panel("layout").Panel("container").Panel(0).Panel("body").Panel(0).Panel("body").Panel("verManager").Panel("verManager_body").Panel("verificationForm").Panel(0).Panel("vF_LineItemstableContainer").Panel(0).Panel(1).Panel(1).Table("vF_LineItems_table")
##  po_line_table.Cell(0, 0).Panel(0).FindChild("idStr","vF_LineItems_0_0",30).Keys(VarToStr(app.Cells.item[2,22]))
##  Sys.Browser("iexplore").Page("*").Panel(0).Panel(0).Form("aspnetForm").Panel(2).Panel(0).Panel(0).Panel("layout").Panel("container").Panel(0).Panel("body").Panel(0).Panel("body").Panel("verManager").Panel("verManager_body").Click()
###  page.FindChild("idStr","vF_InvoiceDate",30).Keys("^a[BS]")
###  page.FindChild("idStr","vF_InvoiceDate",30).Keys(VarToStr(app.Cells.item[2,7]))
###  self.log_message_web("Invoice Date :"+VarToStr(app.Cells.item[2,7]))
###  page.Panel("vF_InvoiceNumber_Container").Textarea("vF_InvoiceNumber").Keys("^a[BS]")
###  page.Panel("vF_InvoiceNumber_Container").Textarea("vF_InvoiceNumber").Keys(VarToStr(app.Cells.item[2,8]))
###  self.log_message_web("Invoice Number :"+VarToStr(app.Cells.item[2,8]))
###  delay(1000)
###  page.FindChild("idStr","vF_PONumber",30).Keys("^a[BS]")
###  page.FindChild("idStr","vF_ShipTo",30).Keys("^a[BS]")
###  page.FindChild("idStr","vF_ShipTo",30).Keys(VarToStr(app.Cells.item[2,16]))
###  delay(1000)
###  page.FindChild("idStr", "vF_Button_5", 30).Click()
###  delay(4000)
###  #self.wait_until_processing()
###  Sys.Browser("iexplore").Page("*").Panel("messagebox").Panel("messagebox_body").Panel("container").Panel("container").Panel("DFInnerContent").Panel("DFcolumn").Panel("DialogFormContentArea").Button("OK").Click()
###  delay(1000)
###  #Postal code
###  #page.FindChild("idStr","vF_ZipPostal",30).Keys(VarToStr(app.Cells.item[2,11]))
###  page.FindChild("idStr","vF_ZipPostal",30).Keys(VarToStr(app.Cells.item[2,17]))
###  delay(3000)
###  # Ship From
###  page.FindChild("idStr","vF_ShipFrom",30).Keys("^a[BS]")
###  #page.FindChild("idStr","vF_ShipFrom",30).Keys(VarToStr(app.Cells.item[2,12]))
###  page.FindChild("idStr","vF_ShipFrom",30).Keys(VarToStr(app.Cells.item[2,18]))
###  delay(3000)
###  # Vendor
###  page.FindChild("idStr","vF_VendorID",30).Keys("^a[BS]")
###  page.FindChild("idStr","vF_VendorID",30).Keys(VarToStr(app.Cells.item[2,5]))
###  self.log_message_web("Vendor Id :"+VarToStr(app.Cells.item[2,5]))
###  delay(1000)
###  # Vendor Site
###  page.FindChild("idStr","vF_SiteID",30).Keys("^a[BS]")
###  page.FindChild("idStr","vF_SiteID",30).Keys(VarToStr(app.Cells.item[2,6]))
###  self.log_message_web("Invoice Site :"+VarToStr(app.Cells.item[2,6]))
###  delay(1000)
###  # Click on Vendor Search
###  page.FindChild("idStr","vF_Button_1",30).Click()
###  delay(1000) 
###  # Click on OK button 
###  Sys.Browser("iexplore").Page("*").Panel("messagebox").Panel("messagebox_body").Panel("container").Panel("container").Panel("DFInnerContent").Panel("DFcolumn").Panel("DialogFormContentArea").Button("OK").Click()
### 
###  # Click on Approver Search
###  page.FindChild("idStr","vF_Button_6",30).Click()
###  delay(5000) 
### # Enter text in Search
###  Sys.Browser("iexplore").Page("*").Panel("messagebox").Panel("messagebox_body").Panel("container").Panel("container").Panel("DFInnerContent").Panel("DFcolumn").Panel("DialogFormContentArea").FindChild("idStr","TextBoxName",30).SetText(VarToStr(app.Cells.item[2,4]))
### # Click on OK button
###  Sys.Browser("iexplore").Page("*").Panel("messagebox").Panel("messagebox_body").Panel("container").Panel("container").Panel("DFInnerContent").Panel("DFcolumn").Panel("DialogFormContentArea").FindChild("idStr","OK",30).Click()
###  delay(2000)
###  # Delete the line item
##  page.Panel("vF_LineItemstableContainer").Panel(1).Panel(11).Click()
###  delay(4000)
##  #self.wait_until_processing()
##  
##  # Creation of line items based on the spreadsheet
##  
##  rowno=2
##  linerow=0
##  #linecol=0
##  #RowCount=app.UsedRange.Rows.Count
##  while not VarToInt(app.Cells.Item[rowno,1])==0:
##    txnum=app.Cells.Item[rowno,1] 
##         
##    #po_line_table.Cell(0, 0).Panel(0).FindChild("idStr","vF_LineItems_0_0",30).Click() # Item desc
##    po_line_table.Cell(linerow, 0).Panel(0).FindChild("idStr","vF_LineItems_0_"+VarToStr(linerow),30).Click() # Item desc
##    delay(3000)
##    po_line_table.Cell(linerow, 0).Panel(0).Textarea("vF_LineItems_0_"+VarToStr(linerow)).Keys(VarToStr(app.Cells.item[rowno,20]))
##    self.log_message_web("Line Descritpion :"+VarToStr(app.Cells.item[rowno,20]))
##    po_line_table.Cell(linerow, 0).Panel(0).Textarea("vF_LineItems_0_"+VarToStr(linerow)).Keys("[Tab]")
##    delay(3000)
##    po_line_table.Cell(linerow, 1).Panel(0).Textarea("vF_LineItems_1_"+VarToStr(linerow)).Keys(VarToStr(app.Cells.item[rowno,21]))
##    self.log_message_web("UOM :"+VarToStr(app.Cells.item[rowno,21]))
##    po_line_table.Cell(linerow, 1).Panel(0).Textarea("vF_LineItems_1_"+VarToStr(linerow)).Keys("[Tab]")
##    delay(2000)
##    po_line_table.Cell(linerow, 2).Panel(0).Textarea("vF_LineItems_2_"+VarToStr(linerow)).Keys(VarToStr(app.Cells.item[rowno,22]))
##    self.log_message_web("Unit Price :"+VarToStr(app.Cells.item[rowno,22]))
##    delay(2000)
##    #po_line_table.Cell(linerow, 4).Panel(0).Click()
##    po_line_table.Cell(0, 4).Panel(0).FindChild("idStr","vF_LineItems_4_"+VarToStr(linerow),30).Click() # Click on Qty
##    delay(2000)
##    #po_line_table.Cell(linerow, 4).Panel(0).Keys(VarToStr(app.Cells.item[rowno,24])) # .Textarea("vF_LineItems_4_0") - Quantity
##    po_line_table.Cell(linerow, 4).Panel(0).FindChild("idStr","vF_LineItems_4_"+VarToStr(linerow),30).Keys(VarToStr(app.Cells.item[rowno,24]))
##    self.log_message_web("Quantity :"+VarToStr(app.Cells.item[rowno,24]))
##    #po_line_table.Cell(linerow, 4).Panel(0).Keys("[Tab]") # .Textarea("vF_LineItems_4_0")
##    po_line_table.Cell(linerow, 4).Panel(0).FindChild("idStr","vF_LineItems_4_"+VarToStr(linerow),30).Keys("[Tab]")
##    delay(2000)
##    #po_line_table.Cell(linerow, 5).Panel(0).Keys(VarToStr(app.Cells.item[rowno,25])) # .Textarea("vF_LineItems_5_0")
##    po_line_table.Cell(linerow, 5).Panel(0).FindChild("idStr","vF_LineItems_5_"+VarToStr(linerow),30).Keys(VarToStr(app.Cells.item[rowno,25]))
##    self.log_message_web("Total of a line :"+VarToStr(app.Cells.item[rowno,25]))
##    delay(2000)
##    if txnum != app.Cells.Item[rowno+1,1]:
##      break
##    rowno=rowno+1
##    linerow=linerow+1
##     # Click on Add line item button
##    page.Panel("vF_LineItemstableContainer").Panel(1).Panel(8).Click()
##    delay(4000)
##    
##  
##  self.page.FindChild("idStr","vF_LinesTotal",40).Click()      #Textbox("vF_LinesTotal")
##  self.page.FindChild("idStr","vF_LinesTotal",40).Keys("[Enter]")
##  self.wait_until_page_loaded()
##  delay(3000)
##  subTot=self.page.FindChild("idStr","vF_AmountSubtotal",40)
##  usTax=self.page.FindChild("idStr","vF_AmountTax",40)
##  miscCharges=self.page.FindChild("idStr","vF_AmountMisc",40)
##  miscCharges.Click()
##  miscCharges.Keys("[Home]"+"![End]"+"[Del]")
##  miscCharges.Keys(app.Cells.item[2,9])
##  freightCharges=self.page.FindChild("idStr","vF_AmountFreightPrepaidAndAdded",40)
##  freightCharges.Click()
##  freightCharges.Keys("[Home]"+"![End]"+"[Del]")
##  freightCharges.Keys(app.Cells.item[2,10])
##  discount=self.page.FindChild("idStr","vF_AmountDiscount",40)
##  discount.Click()
##  discount.Keys("[Home]"+"![End]"+"[Del]")
##  discount.Keys(app.Cells.item[2,12])
##  if (self.oper_unit!="US"): 
##    GST=self.page.FindChild("idStr","vF_AmountMiscGST",40)
##    QST=self.page.FindChild("idStr","vF_AmountMiscQST",40)
##    PST=self.page.FindChild("idStr","vF_AmountMiscPST",40)
##    GST.Keys("[Home]"+"![End]"+"[Del]")
##    GST.Keys(app.Cells.item[2,13])
##    QST.Keys("[Home]"+"![End]"+"[Del]")
##    QST.Keys(app.Cells.item[2,14])
##    PST.Keys("[Home]"+"![End]"+"[Del]")
##    PST.Keys(app.Cells.item[2,15]) 
##  usTax.Keys("[Home]"+"![End]"+"[Del]")
##  usTax.Keys(app.Cells.item[2,11])
##  amt=self.page.FindChild("idStr","vF_LinesTotal",40)
##  subTot.Click()  
##  subTot.Keys("[Home]"+"![End]"+"[Del]")
##  subTot.Keys(amt.Text)
##  delay(1000) 
##  self.log_message_web("Miscellaneous Charges :"+miscCharges.Value)
##  self.log_message_web("Freight Charges :"+freightCharges.Value)
##  self.log_message_web("Discount :"+discount.Value)
##  self.log_message_web("US Sales tax :"+usTax.Value)
##  Tot=page.FindChild("idStr","vF_AmountTotal",40)
##  Tot.Click() 
##  Tot.Keys("[Home]"+"![End]"+"[Del]")
##  taxesAnddis=VarToInt(miscCharges.value)+VarToInt(freightCharges.value)+VarToInt(usTax.value)-VarToInt(discount.value)
##  total=VarToInt(subTot.value)+taxesAnddis
##  Tot.Keys(total)
##  self.log_message_web("Invoice Total :"+Tot.Value)
##  delay(2000)
##  page.FindChild("idStr","vF_VendorID",30).Click()
##  delay(1000)
##  page.FindChild("idStr","vF_VendorID",30).Keys("[Enter]")
##  delay(4000)
##  Sys.Browser("iexplore").Page("*").Panel("messagebox").Panel("toolbar").Panel("toolbar_innerCt").Panel("toolbar_targetEl").Panel("button_2").Table(0).Cell(1, 1).Button("button_btnEl").TextNode("button_btnInnerEl").Click()
##  delay(2000)
##  Sys.Browser("iexplore").Page("*").Panel("messagebox").Panel("toolbar").Panel("toolbar_innerCt").Panel("toolbar_targetEl").Panel("button").Table(0).Cell(1, 1).Button("button_btnEl").TextNode("button_btnInnerEl").Click()
##  
##  
##def close_forms(self):
##      
##        self.log_message_web("Not closing forms for debugging")
##  
##  
##        
##def sample():
##  
##  miscCharges=Sys.Browser("iexplore").page("*").FindChild("idStr","vF_AmountMisc",40)
##  Log_Message("Miscellaneous Charges :"+miscCharges.text)
##  
##  self.log_message_web("Subtotal :"+amt.Text)
##  
##  self.log_message_web("Freight Charges :"+VarToInt(freightCharges.value))
##  self.log_message_web("Discount :"+VarToInt(discount.value))
##  self.log_message_web("US Sales tax :"+VarToInt(usTax.value))
##
##
##
##
##
##  
##  app = Sys.OleObject["Excel.Application"]
##  Delay(1000)
##  app.Visible = "True"
##  #book = app.Workbooks.Open(Project.Path+"\\datasheets\\Oracle-AP-Invoicing\\wci_capture_multiline_dev3_cai.xls")
##  app = book.Sheets.item["wci_verifier"] 
##  
##    
##  #page=Sys.Browser("iexplore").Page("*").Panel(0).Panel(0).Form("aspnetForm").Panel(2).Panel(0).Panel(0).Panel("layout").Panel("container").Panel(0).Panel("body").Panel(0).Panel("body").Panel("verManager").Panel("verManager_body").Panel("verificationForm").Panel(0)
##  
##  page=Sys.Browser("iexplore").Page("*").Panel(0).Panel(0).Form("aspnetForm").Panel(2).Panel(0).Panel(0).Panel("layout").Panel("container").Panel(0).Panel("body").Panel(0).Panel("body").Panel("verManager").Panel("verManager_body").Panel("verificationForm").Panel(0)
##  po_line_table=Sys.Browser("iexplore").Page("*").Panel(0).Panel(0).Form("aspnetForm").Panel(2).Panel(0).Panel(0).Panel("layout").Panel("container").Panel(0).Panel("body").Panel(0).Panel("body").Panel("verManager").Panel("verManager_body").Panel("verificationForm").Panel(0).Panel("vF_LineItemstableContainer").Panel(0).Panel(1).Panel(1).Table("vF_LineItems_table")
##
##  
##  page.FindChild("idStr","vF_VendorID",30).Keys("^a[BS]")
##  page.FindChild("idStr","vF_VendorID",30).Keys(VarToStr(app.Cells.item[2,4]))
##  delay(1000)
##  # Vendor Site
##  page.FindChild("idStr","vF_SiteID",30).Keys("^a[BS]")
##  page.FindChild("idStr","vF_SiteID",30).Keys(VarToStr(app.Cells.item[2,5]))
##  page.FindChild("idStr","vF_VendorID",30).Click()
##  page.FindChild("idStr","vF_VendorID",30).Keys("[Enter]")
##  
##  
##  
##  
##  subTot=page.FindChild("idStr","vF_AmountSubtotal",40)
##  #usTax=page.FindChild("idStr","vF_AmountTax",40)
##  page.FindChild("idStr","vF_AmountTax",40).Keys("[Home]"+"![End]"+"[Del]")
##  page.FindChild("idStr","vF_AmountTax",40).Keys(app.Cells.item[2,19])
##  amt=page.FindChild("idStr","vF_LinesTotal",40)
##  #self.log_checkpoint_message_web("Line Total Amount from PO Lines table: "+VarToStr(amt.contentText))  
##  
##  subTot.Click()  
##  subTot.Keys("[Home]"+"![End]"+"[Del]")
##  subTot.Keys(amt.Text)
##  delay(1000) 
##  #totAmt=amt.Text + usTax.Text
##  #page.FindChild("idStr","vF_AmountSubtotal",40).Keys(app.Cells.item[2,8]) # Invoice Subtotal
##  #self.log_checkpoint_message_web("Sub Total Amount updated from PO Lines table: "+VarToStr(amt.contentText))
##  
##  Tot=page.FindChild("idStr","vF_AmountTotal",40)
##  #self.log_checkpoint_message_web("Total Amount updated from PO Lines table: "+VarToStr(amt.contentText)) 
##  Tot.Click() 
##  Tot.Keys("[Home]"+"![End]"+"[Del]")
##  Tot.Keys(app.Cells.item[2,21])
##  delay(2000)
##  Tot.Keys("[Enter]")
##  delay(4000)
##  Sys.Browser("iexplore").Page("*").Panel("messagebox").Panel("toolbar").Panel("toolbar_innerCt").Panel("toolbar_targetEl").Panel("button_2").Table(0).Cell(1, 1).Button("button_btnEl").TextNode("button_btnInnerEl").Click()
##  
##
