﻿from ebiz import *
import web_utils
import form_utils
import file_system_utils
import ebiz

class OCI_Oracle_EBS_Smoke_Test_SUPPLIERS(Ebiz):
  global rowno
  
  rowno = 2
#  def login(self):
#    self.login_user="rmaran"
#    super().login()
  
  def action(self,book):
    app = book.Sheets.item["Smoke_Test"]
    self.wait_until_page_loaded()    
      
    web_utils.clk_fldr_link_by_xpath_start(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" AP INQUIRY')]")     
    self.wait_until_page_loaded()  
      
    web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Suppliers Inquiry')]")       
    self.log_message_web("Click 'Suppliers Inquiry' - Successful")
    self.wait_until_page_loaded() 
#    
#    temp=web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Suppliers')]")       
#    self.log_message_web("Click 'Suppliers' - Successful")  
#    self.wait_until_page_loaded() 
    
    obj = self.page.FindChild("contentText","Supplier Search",40)     
    if obj.Exists:
      web_utils.log_checkpoint("Able to Launch  'Suppliers Search' page Successfully",500,self.page)  
    else:
      self.page.log_error_message("Unable to Launch Suppliers Search Page")
      
    supplier_name = self.page.EvaluateXpath("//input[@title='Supplier Name']")
    supplier_name[0].SetText("PROSYS INFORMATION SYSTEMS")
    app.cells.Item[2,1] = "PROSYS INFORMATION SYSTEMS"
    Delay(2000)
    self.wait_until_page_loaded()     
    self.page.EvaluateXpath("//table[@id ='SearchHeader']//button[@id = 'GoButton']")[0].Click()
    self.wait_until_page_loaded()
    
    pro = ("contentText","ObjectType")
    val = ("Purchasing","Link")
    obj1 = self.page.FindChild(pro,val,30)
    Delay(2000)
    header = self.page.FindChild("contentText","Update PROSYS INFORMATION SYSTEMS*",40)
    if header.Exists:
      web_utils.log_checkpoint("Able to Query Supplier Details Successfully",500,self.page) 
    else:
      self.log_error_message("Unable to Query the Supplier - Test Failed")
    self.wait_until_page_loaded()
    
    if obj1.Exists:
      self.page.log_error_message("Navigate to 'Purchasing' Section to verify site status")
    else:
      self.page.log_error_message("Unable to Navigate to 'Purchasing' section: Test Failed")
    obj1.Click()
    self.wait_until_page_loaded() 
    Delay(2000)

    site_status = self.page.FindChild("idStr","posSiteStatus",40).wText
    if site_status == 'Active':
      app.cells.Item[2,2] = site_status
      web_utils.log_checkpoint("Able to Verify Site Status Successfully for the Supplier: Test Passed",500,self.page) 
    else:
      self.log_error_message("Unable to Verify Site Status for the Supplier: Test Failed")
      
    
 