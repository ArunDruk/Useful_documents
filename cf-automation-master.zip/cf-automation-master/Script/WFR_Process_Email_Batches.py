﻿from webCenterVerifier import *
import random


class WFR_Process_Email_Batches(webCenterVerifier):
        
 def goto_url(self,url):
   super().goto_url(self.testConfig['ebiz']['WebCentVerUrl'])
      
 def action(self,book): 
  app = book.Sheets.item["mail_wcc"]
  app1 = book.Sheets.item["wci_verifier"]
  if self.page.FindChild("contentText","Options",40).Exists:
    web_utils.log_checkpoint("Able to Login to WFR Application Successfully",500,self.page)
  self.page.FindChild("contentText","Options",40).Click()
  self.page.FindChild("idStr","item_custom_filter-itemEl",40).Click()
  Delay(1000)
  self.wait_until_processing()
  batch_name=VarToStr(app.Cells.item[2,2])
  self.page.FindChild("idStr","bfdFilter",40).Keys("^a[Del]")
  self.page.FindChild("idStr","bfdFilter",40).SetText("[Capture Batch ID] ='"+VarToStr(batch_name)+"'")
  Delay(2000)
  self.page.FindChild("contentText","Apply",40).Click()
  Delay(1000)
  self.wait_until_processing()
  
# Refresh page until expected batch found
  while  Sys.Browser("iexplore").Page("*").EvaluateXPath("//table[@class='x-grid-table x-grid-table-resizer']//span")==None:    
    Sys.Browser("iexplore").Page("*").Keys("[F5]")
    Sys.Browser("iexplore").Page("*").Wait()
    Delay(2000)
    Sys.Browser("iexplore").Page("*").Wait()  
  Delay(2000)
  web_utils.log_checkpoint("Filter Options applied for WCC Batch Name: "+batch_name,500,self.page)  
    
# Check the verifier batch id's(invoices) created for "Capture batch id":
  i = 1
  j = 0
  val2 = VarToStr(app.Cells.Item[2,2])
#  https://core-capture-dev.epfinnp.coxautoinc.com/WebVerifier/BatchView.aspx
  fltr_view = Sys.Browser("iexplore").Page("http://tmnh1of.manheim.com/WebVerifier/BatchView.aspx").Panel(0).Panel(0).Form("aspnetForm").Panel(2).Panel(0).Panel(0).Panel("container").Panel(0).Panel("body").Panel("gridCtl").Panel("body").Panel("gridview").Table(0)  
  captr_btch_id = fltr_view.Cell(i, 13).Panel(0)
  val1 = captr_btch_id.contentText
  while  val2 == val1:
    Sys.HighlightObject(captr_btch_id)
    captr_btch_id.Click()
    batch_id = self.page.EvaluateXpath("//table[@class='x-grid-table x-grid-table-resizer']//span")[j].contentText
    i = i+1
    j = j+1
    captr_btch_id = fltr_view.Cell(i, 13).Panel(0)
    self.log_message_web("Available WFR BatchID No:"+VarToStr(i-1)+" = "+batch_id)
    val1 = captr_btch_id.contentText
  self.log_message_web("Count of verifier batch files created for 'Capture Batch Name' - "+VarToStr(app.Cells.Item[2,2])+" = "+VarToStr(j))
  
#Select the invoice and navigate to details:
  self.page.EvaluateXPath("//table[@class='x-grid-table x-grid-table-resizer']//span")[0].Click()
  web_utils.log_checkpoint("Selecting WFR BatchID: "+batch_id+" for processing",500,self.page) 
  Delay(1000)
  self.wait_until_page_loaded()
  Delay(3000)
  self.page.Wait()
  delay(2000)
  self.wait_until_page_loaded()
  batchname=self.page.FindChild("idStr","vF_BatchName",30).value   
  self.log_message_web("BatchName : "+VarToStr(batchname))  
  while VarToStr(batch_name)==VarToStr(batchname):
      self.log_checkpoint_message_web("Batch Name match successful") 
      Delay(3000)  
      invoice_number = "TEST_US_NOPO_"+VarToStr(aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%m_%y"))+"_"+VarToStr(random.randint(1111,9999))

#Get Project Status & Set invoice type
      project_status = VarToStr(self.page.FindChild("idStr","vF_Project",30).status)
      invoice = self.page.FindChild("idStr","vF_InvoiceType-inputEl",30)
      inv_type = invoice.Text
      if inv_type=="PO":
         invoice.Click()
         invoice.Keys("[Down]")
         invoice.Keys("[Enter]")
         web_utils.log_checkpoint("Changing Invoice Type to required value: NON PO",500,self.page) 

#Get Company code and Operating Unit; Project Selection if required
      comp_code=self.page.FindChild("idStr","vF_CompanyCode",30).value  
      self.log_message_web("Company Code :"+VarToStr(comp_code))
      op_unit=self.page.FindChild("idStr","vF_OperatingUnit",30).value  
      self.log_message_web("Operating Unit :"+VarToStr(op_unit))
      if (VarToStr(app1.Cells.Item[2,5])=="Yes" and project_status == "False"):
        self.page.FindChild("idStr","vF_Project",30).Click()
        self.log_message_web("Selected Project CheckBox Successfully")
        web_utils.log_checkpoint("Selected Project Checkbox Successfully",500,self.page) 

#Set Invoice Number
      self.page.Find("idStr","ctl00_ctl00_ContentPlace_WorkArea_documentViewerCtl_image",40).Click()
      Delay(3000)    
      inv_no=self.page.FindChild("idStr","vF_InvoiceNumber",30)
      inv_no.Click()
      inv_no.Keys("^a[Del]")
      Delay(1000)
      inv_no.Keys(invoice_number)
      self.log_message_web("Invoice Number : "+VarToStr(invoice_number))
     
#Invoice Date
      inv_date=self.page.FindChild("idStr","vF_InvoiceDate",30)
      inv_date.Click()
      inv_date.Keys("^a[Del]")
      Delay(1000)
      inv_date.Keys(aqDateTime.Today())
      inv_date.keys("[Tab]")
      # inv_date.Keys("[Enter]")
      Delay(3000)
      inv_date=inv_date.value  
      self.log_message_web("Invoice Date : "+VarToStr(inv_date))
     
#PO Number     
      po_no=self.page.FindChild("idStr","vF_PONumber",30)
      po_no.Click()
      po_no.Keys("^a[Del]")
      Delay(1000)
      po_no.Keys(VarToStr(app1.Cells.Item[2,4]))
  
#Update Vendor/site  
      if (VarToStr(app1.Cells.Item[2,6])) == "":
         self.page.FindChild("idStr","vF_VendorID",30).Click()
         self.page.FindChild("idStr","vF_VendorID",30).Keys("^a[Del]") 
         delay(1000)
         self.page.FindChild("idStr","vF_SiteID",30).Click()
         self.page.FindChild("idStr","vF_SiteID",30).Keys("^a[Del]")
         delay(1000)
         self.page.FindChild("idStr","vF_VendorASSA",30).Click()
         self.page.FindChild("idStr","vF_VendorASSA",30).Keys("^a[Del]")
         delay(1000)
         self.page.FindChild("idStr","vF_InvalidReason-inputEl",30).Click()
         delay(1000)
         self.log_message_web("Select Invalid Reason: SUPPLIER NOT FOUND")
         self.page.FindChild("contentText","SUPPLIER NOT FOUND",30).Click()
      else:
        self.page.FindChild("idStr","vF_Button_1",30).Click()
        Delay(6000)
        self.wait_until_page_loaded()
        self.page.FindChild("idStr","TextBoxName",30).SetText(VarToStr(app1.Cells.Item[2,6]))
        Delay(1000)
        self.page.FindChild("idStr","PushButtonSearch",30).Click()
        Delay(2000)
        self.page.FindChild("idStr","List",30).SelectItem(0)
        Delay(1000)
        self.page.FindChild("idStr","OK",30).Click()  
        Delay(3000)
        self.wait_until_page_loaded()
        self.wait_until_processing()
        vendor=self.page.FindChild("idStr","vF_VendorID",40).contentText
        self.log_message_web("Updated Vendor ID : "+VarToStr(vendor))
      
        siteID=self.page.FindChild("idStr","vF_SiteID",40).contentText
        self.log_message_web("Updated Site ID : "+VarToStr(siteID)) 
         
      ship_to=self.page.FindChild("idStr","vF_ShipTo",30)      
      ship_to.Keys(app1.Cells.Item[2,8])
      ship_to_val = ship_to.value
      self.log_message_web("Ship To : "+VarToStr(ship_to_val))
      
      zip = self.page.FindChild("idstr","vF_ZipPostal",40)
      zip.Keys(app1.Cells.Item[2,9])
      zip_val = zip.value
      self.log_message_web("Zip/Postal Code : "+VarToStr(zip_val))
          
      ship_from=self.page.FindChild("idStr","vF_ShipFrom",30)     
      ship_from.Keys("^a[Del]") 
      ship_from.Keys(app1.Cells.Item[2,31])
      ship_from_val = ship_from.value
      self.log_message_web("Ship From : "+VarToStr(ship_from_val))
      
      approver = self.page.FindChild("idStr","vF_Approver",30)
      approver.Keys(app1.Cells.Item[2,11])
      approver_val = approver.value
      self.log_message_web("Approver : "+VarToStr(approver_val))
      
      supplier=self.page.FindChild("idStr","vF_VendorASSA",30).value   
      self.log_message_web("Supplier : "+VarToStr(supplier))
      location=self.page.FindChild("idStr","vF_Location",30).value  
      self.log_message_web("Location : "+VarToStr(location))
      scan_date=self.page.FindChild("idStr","vF_ScanDate",30).value  
      self.log_message_web("Scan Date : "+VarToStr(scan_date))  
      batchname=self.page.FindChild("idStr","vF_BatchName",30).value   
      self.log_message_web("BatchName : "+VarToStr(batchname))  
      if VarToStr(batch_name)==VarToStr(batchname):
        self.log_checkpoint_message_web("Batch Name match successfully") 
   
#Click on the left sceen window then do page down
      self.page.FindChild("idStr","verManager-body",40).Click(673, 236)
      self.page.Keys("[PageDown]")
      self.page.Keys("[PageDown]")
      Delay(3000)
      self.page.NativeWebObject.Find("idStr","vF_Button_4","BUTTON").ScrollIntoView()
      Delay(2000)
      self.page.NativeWebObject.Find("idStr","vF_Button_4","BUTTON").Click()
      Delay(1000)  
      self.wait_until_processing()
      self.page.FindChild("idStr","verManager-body",40).Click(673, 236)
      self.page.Keys("[PageDown]")
      Delay(1000)    
      self.log_checkpoint_message_web("Click Replace PO lines table successfull") 
      web_utils.log_checkpoint("Deleted Existing Line Items for the Invoice Successfully",500,self.page)     

    #  po_table=self.page.FindChild("idStr","vF_EBSPOLineItemstableContainer",40)
      po_line_panel=Sys.Browser("iexplore").Page("*").Panel(0).Panel(0).Form("aspnetForm").Panel(2).Panel(0).Panel(0).Panel("layout").Panel("container").Panel(0).Panel("body").Panel(0).Panel("body").Panel("verManager").Panel("verManager_body").Panel("verificationForm").Panel(0)
      po_line_table=Sys.Browser("iexplore").Page("*").Panel(0).Panel(0).Form("aspnetForm").Panel(2).Panel(0).Panel(0).Panel("layout").Panel("container").Panel(0).Panel("body").Panel(0).Panel("body").Panel("verManager").Panel("verManager_body").Panel("verificationForm").Panel(0).Panel("vF_LineItemstableContainer").Panel(0).Panel(1).Panel(1).Table("vF_LineItems_table")

#Creation of line items based on the spreadsheet
  
      rowno=2
      linerow=0
#      while not VarToInt(app.Cells.Item[rowno,1])==0:
      RowCount = app1.UsedRange.Rows.Count
#      txnum = VarToInt(app.cells.Item[rowno,1])      
      while rowno<(RowCount+1):
        txnum=VarToInt(app1.cells.Item[rowno,1])
         
        po_line_table.Cell(linerow, 0).Panel(0).FindChild("idStr","vF_LineItems_0_"+VarToStr(linerow),30).Click() # Item desc
        delay(3000)
        po_line_table.Cell(linerow, 0).Panel(0).Textarea("vF_LineItems_0_"+VarToStr(linerow)).Keys(VarToStr(app1.Cells.item[rowno,15]))
        self.log_message_web("Line Description : "+VarToStr(app1.Cells.item[rowno,15]))
        po_line_table.Cell(linerow, 0).Panel(0).Textarea("vF_LineItems_0_"+VarToStr(linerow)).Keys("[Tab]")
        delay(3000)
        po_line_table.Cell(linerow, 1).Panel(0).FindChild("idStr","vF_LineItems_1_"+VarToStr(linerow),30).Click()
        po_line_table.Cell(linerow, 1).Panel(0).Textarea("vF_LineItems_1_"+VarToStr(linerow)).Keys(VarToStr(app1.Cells.item[rowno,16]))
        self.log_message_web("UOM : "+VarToStr(app1.Cells.item[rowno,16]))
        po_line_table.Cell(linerow, 1).Panel(0).Textarea("vF_LineItems_1_"+VarToStr(linerow)).Keys("[Tab]")
        delay(2000)
        po_line_table.Cell(linerow, 2).Panel(0).FindChild("idStr","vF_LineItems_2_"+VarToStr(linerow),30).Click()
        po_line_table.Cell(linerow, 2).Panel(0).Textarea("vF_LineItems_2_"+VarToStr(linerow)).Keys(VarToStr(app1.Cells.item[rowno,17]))
        self.log_message_web("Unit Price : "+VarToStr(app1.Cells.item[rowno,17]))
        delay(2000)
        #po_line_table.Cell(linerow, 4).Panel(0).Click()
        po_line_table.Cell(linerow, 4).Panel(0).FindChild("idStr","vF_LineItems_4_"+VarToStr(linerow),30).Click() # Click on Qty
        delay(2000)
        #po_line_table.Cell(linerow, 4).Panel(0).Keys(VarToStr(app.Cells.item[rowno,24])) # .Textarea("vF_LineItems_4_0") - Quantity
        po_line_table.Cell(linerow, 4).Panel(0).FindChild("idStr","vF_LineItems_4_"+VarToStr(linerow),30).Keys(VarToStr(app1.Cells.item[rowno,19]))
        self.log_message_web("Quantity : "+VarToStr(app1.Cells.item[rowno,19]))
        #po_line_table.Cell(linerow, 4).Panel(0).Keys("[Tab]") # .Textarea("vF_LineItems_4_0")
#        po_line_table.Cell(linerow, 4).Panel(0).FindChild("idStr","vF_LineItems_4_"+VarToStr(linerow),30).Keys("[Tab]")
        delay(2000)
        po_line_table.Cell(linerow, 5).Panel(0).FindChild("idStr","vF_LineItems_5_"+VarToStr(linerow),30).DblClick()
        po_line_table.Cell(linerow, 5).Panel(0).FindChild("idStr","vF_LineItems_5_"+VarToStr(linerow),30).Keys("^a[Del]")
        po_line_table.Cell(linerow, 5).Panel(0).FindChild("idStr","vF_LineItems_5_"+VarToStr(linerow),30).Keys(VarToStr(app1.Cells.item[rowno,21]))
        self.log_message_web("Individual Line Total : "+VarToStr(app1.Cells.item[rowno,21]))
        delay(2000)
        web_utils.log_checkpoint("Updated Description, UnitPrice, UOM, Line Total Details successfully for Line Number: "+VarToStr(rowno-1),500,self.page) 
        if txnum != app1.Cells.Item[rowno+1,1]:
          break
        rowno=rowno+1
        linerow=linerow+1
    
#Click on Add line item button
        po_line_panel.Panel("vF_LineItemstableContainer").Panel(1).Panel(8).Click()
        delay(4000)     
      Delay(2000)
  
#Check Line Total, Subtotal & Tax
      line_total_field = po_line_panel.Panel("vF_LinesTotal_Container").Textbox("vF_LinesTotal")
      line_total_field.Click()
      line_total_field.Keys("[Home]"+"![End]"+"[Del]")
      line_total = "%.2f" % (VarToInt(app1.Cells.item[2,22]))
      line_total_field.Keys(line_total)
      line_total = line_total_field.Text
      self.log_message_web("Combined Lines Total : "+VarToStr(line_total))
      self.page.FindChild("idStr","vF_LinesTotal",40).Click()      #Textbox("vF_LinesTotal")
#      self.page.FindChild("idStr","vF_LinesTotal",40).Keys("[Enter]")
      self.wait_until_page_loaded()
      delay(3000)
      subTot=self.page.FindChild("idStr","vF_AmountSubtotal",40)
      usTax=self.page.FindChild("idStr","vF_AmountTax",40)
      miscCharges=self.page.FindChild("idStr","vF_AmountMisc",40)
      miscCharges.Click()
      miscCharges.Keys("[Home]"+"![End]"+"[Del]")
      misc = "%2.2f" %(VarToInt(app1.Cells.item[2,25]))
      miscCharges.Keys(misc)
      freightCharges=self.page.FindChild("idStr","vF_AmountFreightPrepaidAndAdded",40)
      freightCharges.Click()
      freightCharges.Keys("[Home]"+"![End]"+"[Del]")
      freight = "%2.2f" %(VarToInt(app1.Cells.item[2,24]))
      freightCharges.Keys(freight)
      discount=self.page.FindChild("idStr","vF_AmountDiscount",40)
      discount.Click()
      discount.Keys("[Home]"+"![End]"+"[Del]")
      discount_val =  "%2.2f" %(VarToInt(app1.Cells.item[2,23]))
      discount.Keys(discount_val)
      us_tax = (VarToFloat(app1.Cells.item[2,30]))
      a = 0
      ca_tax = "%2.2f" % a
      if (self.oper_unit!="US"): 
        usTax.Keys("[Home]"+"![End]"+"[Del]")
        usTax.Keys(ca_tax)
      else:
        usTax.Keys("[Home]"+"![End]"+"[Del]")
        usTax.Keys(us_tax)
      GST=self.page.FindChild("idStr","vF_AmountMiscGST",40)
      QST=self.page.FindChild("idStr","vF_AmountMiscQST",40)
      PST=self.page.FindChild("idStr","vF_AmountMiscPST",40)
      GST.Keys("[Home]"+"![End]"+"[Del]")
      GST_val =  "%2.2f" %(VarToInt(app1.Cells.item[2,27]))
      GST.Keys(GST_val)
      self.log_message_web("GST Charges :"+GST.Value)
      QST.Keys("[Home]"+"![End]"+"[Del]")
      QST_val =  "%2.2f" %(VarToInt(app1.Cells.item[2,28]))
      QST.Keys(QST_val)
      PST.Keys("[Home]"+"![End]"+"[Del]")
      PST_val =  "%2.2f" %(VarToInt(app1.Cells.item[2,29]))
      PST.Keys(PST_val) 
      amt=self.page.FindChild("idStr","vF_LinesTotal",40)
      subTot.Click()  
      subTot.Keys("[Home]"+"![End]"+"[Del]")
      subtotal = "%.2f" % (VarToInt(app1.Cells.item[2,12]))
      subTot.Keys(subtotal)
      delay(1000) 
      self.log_message_web("Miscellaneous Charges :"+miscCharges.Value)
      self.log_message_web("Freight Charges :"+freightCharges.Value)
      self.log_message_web("Discount :"+discount.Value)
      self.log_message_web("US Sales tax :"+usTax.Value)
      Tot=self.page.FindChild("idStr","vF_AmountTotal",40)
      Tot.Click() 
      Tot.Keys("[Home]"+"![End]"+"[Del]")
      if (self.oper_unit=="US"): 
        taxesAnddis=(VarToFloat(miscCharges.Value)+VarToFloat(freightCharges.Value)+VarToFloat(usTax.Value))-VarToFloat(discount.Value)
      elif (self.oper_unit=="CA"):
        taxesAnddis=(VarToFloat(miscCharges.Value)+VarToFloat(freightCharges.Value)+VarToFloat(GST.Value)+VarToFloat(PST.Value)+VarToFloat(QST.Value)+VarToFloat(usTax.Value))-VarToFloat(discount.Value)
      self.log_message_web("Taxes and Discounts :"+VarToStr(taxesAnddis))
#      total=(VarToFloat(subTot.value)+VarToFloat("%0.2f" % (taxesAnddis)))
      total=(VarToFloat(subTot.value)+VarToFloat(taxesAnddis))
      Tot.Keys(total)
      self.log_message_web("Invoice Total :"+Tot.Value)
      delay(2000)
      web_utils.log_checkpoint("Invoice Header Total and Tax Details Entered Successfully",500,self.page)
      tot_amt=self.page.FindChild("idStr","vF_AmountTotal",30).value  
      self.log_message_web("Invoice Total Amount : "+VarToStr(tot_amt))  
      self.page.FindChild("idStr","vF_Currency",30).Click()
      delay(1000)
      self.page.FindChild("idStr","vF_Currency",30).Keys("[Enter]")
      if self.page.FindChild("idStr","messagebox-1001",40).Exists:
        pass
      else:
        self.page.FindChild("idStr","vF_Currency",30).DblClick()
        delay(1000)
        self.page.FindChild("idStr","vF_Currency",30).Keys("[Enter]")
        delay(4000)

#message box
      self.page.Wait()
      self.wait_until_page_loaded()  
      popup=self.page.FindChild("idStr","messagebox-1001",40)
      popup_text = popup.contentText
      if popup.Exists: 
        if StrMatches('Error',popup_text) == True:
           self.log_error_message("Validation Errored Out: Resubmit the Page")
           popup.FindChild("idStr","OK",40).Click()
           Delay(9000)
        popup.FindChild("idStr","OK",40).Click()
        Delay(9000)
       
      else:
         self.log_error_message("Unable to find the Confirmation Pop Up: Check for Errors")
      web_utils.log_checkpoint("Confirmation Pop-up available to release the verified batch "+batch_id,500,self.page)
      self.popup_wnd_click_yes()
      Delay(6000)
      popup=self.page.FindChildEx("Name","Panel('messagebox')",30,True,6000)
      popup.FindChild("idStr","button-1009-btnInnerEl",30).Click()  
      Delay(3000)
      self.wait_until_page_loaded()   
#      self.page.FindChild("contentText","Options",40).Click()
#      self.page.FindChild("idStr","item_custom_filter-itemEl",40).Click()
#      Delay(3000
#      self.page.FindChild("idStr","bfdFilter",40).SetText("")  
#      self.page.FindChild("contentText",)  
#      self.wait_until_processing()"Apply",40).Click()
#      Delay(3000)
      self.page.wait()
#      home_scr = self.page.FindChild("contentText","Options",40)
      if self.page.FindChild("contentText","Options",40).Exists:
        break
      else:
        batchname=self.page.FindChild("idStr","vF_BatchName",30).value 
  self.log_checkpoint_message_web("All invoices are verified and released for batch: "+batch_id)
  web_utils.log_checkpoint("Successfully verified and released WFR BatchID: "+batch_id+" for WCC Batch Name: "+batch_name,500,self.page) 


def test():
    page = Sys.Browser("iexplore").page("*")
    page.FindChild("idStr","vF_InvalidReason-inputEl",30).Click()
    delay(1000)
    page.FindChild("contentText","SUPPLIER NOT FOUND",30).Click()

