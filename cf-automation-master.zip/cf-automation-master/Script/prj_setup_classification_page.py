﻿import gvar

### In this method objects for below pages have been captured ###

#PROJECT > SETUP > CLASSIFICATIONS link page

def prj_setup_classifications_apply_button():
  prop_names = ["ObjectIdentifier","ObjectType"]
  prop_values = ["Apply","Button"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def prj_setup_classifications_cancel_button():
  prop_names = ["ObjectIdentifier","ObjectType"]
  prop_values = ["Cancel","Button"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
  

def prj_setup_classifications_delete_button():
  prop_names = ["ObjectIdentifier","ObjectType"]
  prop_values = ["Delete","Button"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def prj_setup_select_classifications_checkbox():
  checkbox = Sys.Browser("iexplore").Page("*").Panel("oafOraBodyContainer").Form("DefaultFormName").Panel("oafcontent").Panel(0).Panel("oafusercontent").Panel(0).Panel("p_SwanPageLayout").Panel(0).Panel(1).Table("EditClassifications").Cell(3, 0).Table(0).Cell(0, 0).Panel(0).Panel(0).Panel("ClassificationsEditTable").Panel("ClassificationsEditTable").Panel("ClassificationsEditTable").Panel("ClassificationsEditTable_3").Table("Content").Cell(1, 0).Checkbox(0)
  return checkbox
  

def prj_setup_class_category_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["N28:ClassCategoryEdit:1","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def prj_setup_class_code_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["N28:ClassCodeEdit:1","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def prj_setup_percentage_edit_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["N28:PercentageEdit:1","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def prj_setup_update_info_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["N28:FlexImageDisabled:1","Image"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

