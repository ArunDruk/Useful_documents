﻿from ebiz import *
import file_system_utils
import form_utils
import web_utils
import dbhelper

###This testcase is to submit IS: CAI Intercompany Transactions Outbound Interface and capture output###

class tc215849_is_cai_intercompany_trx_outbound_interface_a(Ebiz):

 op_log_path="C:\\TC_Logs"
 
 def login(self):
    self.login_user="mfallwell"
    super().login()
 
 def goto_url(self,url):
   super().goto_url(self.testConfig['ebiz']['oci_is_url'])
 
 def action(self,book):

# Login to Oracle EBIZ and select the GL SCHEDULER responsibility  
    web_utils.log_checkpoint("Logged in to MAN Oracle Ebiz Instance Successfully",500,self.page)
    self.wait_until_page_loaded()  
    self.page.WaitProperty("contentText","GL SCHEDULER",6000)
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='menuContent']//div[contains(text(),'GL SCHEDULER')]")       
    self.page.Wait()
    self.page.NativeWebObject.Find("contentText","Requests","A").Click()
    web_utils.log_checkpoint("Click 'Requests' - Successful",500,self.page)
    delay(2000)
    self.page.NativeWebObject.Find("contentText","Run","A").Click()
    web_utils.log_checkpoint("Click 'Run' - Successful",500,self.page)
    web_utils.validate_security_box()
    Delay(15000)
    jFrame=self.initializeJFrame()
    form_utils.click_ok_btn(jFrame)  
    Delay(3000)
    
# Submitting "IS: CAI Intercompany Transactions Outbound Interface" Request Set using GL SCHEDULER' responsibility
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit a New Request","ExtendedFrame"]
    submit_req_form=jFrame.FindChildEx(prop,val,30,True,60000)
    submit_req_form.FindChild("AWTComponentAccessibleName","OK alt O",10).Click()
    Delay(2000)
    jFrame.Keys("IS: CAI Intercompany Transactions Outbound Interface")
    web_utils.log_checkpoint("Request Name: 'IS: CAI Intercompany Transactions Outbound Interface' - populated Successfully",500,jFrame)
    jFrame.Keys("[Tab]")
    delay(1000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Parameters","FlexWindow"]
    parameters_form=jFrame.FindChildEx(prop,val,60,True,60000)
    period_name=parameters_form.FindChild("AWTComponentAccessibleName","Period Name REQUIRED List Values",10)
    period_name.Click()
    delay(2000)
    cur_period = aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%b-%Y").upper()
    period_name.Keys(cur_period)
    delay(2000)
    web_utils.log_checkpoint("Request Name: 'IS: CAI Intercompany Transactions Outbound Interface' parameters - populated Successfully",500,jFrame)
    val = ["OK ALT O","FormButton"]
    parameters_form.FindChild(prop,val,60).Click()
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit Request","ExtendedFrame"]
    submit_req_form=jFrame.FindChildEx(prop,val,30,True,60000)
    submit_req_form.FindChild("AWTComponentAccessibleName","Submit alt m",10).Click()
    web_utils.log_checkpoint("Click Submit Successful",500,jFrame)
    Delay(2000)
    jFrame.Keys("~o")
    web_utils.log_checkpoint("'IS: CAI Intercompany Transactions Outbound Interface' is submitted",500,jFrame) 
    RequestID = ''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit()) 
    web_utils.log_checkpoint("Request ID Of 'IS: CAI Intercompany Transactions Outbound Interface' is " + aqConvert.VarToStr(RequestID),500,jFrame)
    Delay(2000)
    jFrame.Keys("~n")
    Delay(2000)
    dsn = self.testConfig['man_oracle_db']['dsn']
    user_id = self.testConfig['man_oracle_db']['userid']
    pwd = self.testConfig['man_oracle_db']['pwd']
    dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,RequestID)
    Delay(4000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000) 
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,90000)
    self.req_set_save_log(jFrame,req_form,"IS: CAI Intercompany Transactions Outbound Interface",RequestID)
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~o")
    Delay(1000)    
    
      

 def req_set_save_output(self,jFrame,req_form,srch_child_name,Preqid):
    web_utils.log_checkpoint("Checking for "+aqConvert.VarToStr(srch_child_name)+ " Child Program Status",500,jFrame)
    req_form.FindChild("AWTComponentAccessibleName","Refresh Data alt R",20).Click()
    i=20
    for x in range(1,180):     
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Name",i]
        child_name=req_form.Find(prop,val,10).wText 
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Phase",i+20]
        phase=req_form.Find(prop,val,10).wText 
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Request ID",i-10]
        creqid=VarToInt(req_form.Find(prop,val,10).wText)                                        
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Status",i+30]         
        status =req_form.FindChild(prop,val,60)            
        if (child_name==srch_child_name) and (aqConvert.VarToInt(creqid)>=aqConvert.VarToInt(Preqid)) and (phase == "Completed"):
            web_utils.log_checkpoint(aqConvert.VarToStr(srch_child_name)+" Phase Completed Successfuly",500,jFrame)                             
            status.Keys("[Enter]")
            Delay(1000)
            req_form.FindChild("AWTComponentAccessibleName","View Output alt p",20).Click()  
            Delay(4000)
            output_page=Sys.Browser("iexplore").Page("https://manheim*.epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
            output_page.Click()
            Delay(2000)
            output_page.Keys("~f")
            Delay(2000)
            output_page.Keys("a")
            Delay(5000)
            file_system_utils.create_folder(self.op_log_path)             
            self.log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"File"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"_%d%b%Y_%H%M")+".txt"    
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(self.log_path)
            Delay(1000)
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
            Delay(8000)
            Log.Enabled=True
            Log.File(self.log_path, aqConvert.VarToStr(srch_child_name)+" is Completed And Output file is attached")
            Log.Enabled=False     
            web_utils.close_additional_browsers()         
            Filesaved = 'True'
            return                           
        elif i >=29:
           Delay(15000)           
           req_form.FindChild("AWTComponentAccessibleName","Refresh Data alt R",20).Click()
           Delay(3000)
           i=20
           val=["Name",i]
           child_name=req_form.Find(prop,val,10).wText
        else:  
           Delay(2000)
           i=i+1 
           
 
 def req_set_save_log(self,jFrame,req_form,srch_child_name,Preqid):
    web_utils.log_checkpoint("Checking for "+aqConvert.VarToStr(srch_child_name)+ " Child Program Status",500,jFrame)
    req_form.FindChild("AWTComponentAccessibleName","Refresh Data alt R",20).Click()
    i=20
    for x in range(1,180):     
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Name",i]
        child_name=req_form.Find(prop,val,10).wText 
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Phase",i+20]
        phase=req_form.Find(prop,val,10).wText 
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Request ID",i-10]
        creqid=VarToInt(req_form.Find(prop,val,10).wText)
                                       
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Status",i+30]         
        status =req_form.FindChild(prop,val,60)            
        if (child_name==srch_child_name) and (aqConvert.VarToInt(creqid)>=aqConvert.VarToInt(Preqid)) and (phase == "Completed"):
            web_utils.log_checkpoint(aqConvert.VarToStr(srch_child_name)+" Phase Completed Successfuly",500,jFrame)                            
            status.Keys("[Enter]")
            Delay(1000)
            req_form.FindChild("AWTComponentAccessibleName","View Log alt K",20).Click()  
            Delay(4000)
            output_page=Sys.Browser("iexplore").Page("https://manheim*.epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
            output_page.Click()
            Delay(2000)
            output_page.Keys("~f")
            Delay(2000)
            output_page.Keys("a")
            Delay(5000)
            file_system_utils.create_folder(self.op_log_path)             
            self.log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"File"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"_%d%b%Y_%H%M")+".txt"    
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(self.log_path)
            Delay(1000)
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
            Delay(8000)
            Log.Enabled=True
            Log.File(self.log_path, aqConvert.VarToStr(srch_child_name)+" is Completed And Log file is attached")
            Log.Enabled=False     
            web_utils.close_additional_browsers()         
            Filesaved = 'True'
            return                           
        elif i >=29:
           Delay(15000)           
           req_form.FindChild("AWTComponentAccessibleName","Refresh Data alt R",20).Click()
           Delay(3000)
           i=20
           val=["Name",i]
           child_name=req_form.Find(prop,val,10).wText
        else:  
           Delay(2000)
           i=i+1 
    
