﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils
import winscp_utility
import random
import web_utils
import form_utils
####This testcase is to place the excel import file in the AP inbound directory using WINSCP### 


class tc97776cai_us_project_contractor_labor_cost(Ebiz):

 global inv_date,inv_num
 op_log_path="C:\\TC_Logs"
 exl_inv_files="C:\\prj_contrt_file"

 def login(self):
    self.login_user="rmaran"
    super().login()

 def action(self,book):   
 
    self.update_proj_creation_xldetails()
    self.place_proj_creation_file_winscp()

    web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" AP INVOICE MAINTENANCE')]")
    Delay(1000)
    self.page.Find("contentText","Other",30).Click()
    Delay(1000)
    self.page.Find("contentText","Requests",30).Click()
    Delay(1000)
    self.page.Keys("[Down]")
    Delay(2000)
    self.wait_until_page_loaded
    self.page.EvaluateXPath("//table[@id='respList']//div[contains(text(),'Run')]")[0].Click()
    Delay(1000)
    web_utils.validate_security_box()
    delay(2000)
    jFrame= self.initializeJFrame()
    Delay(3000)
    form_utils.click_ok_btn(jFrame)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit a New Request","ExtendedFrame"]
    SubmitaNewRequest_form=jFrame.FindChildEx(prop,val,60,True,90000)
    self.verify_aqobject_chkproperty(SubmitaNewRequest_form,"AWTComponentAccessibleName",cmpContains,"Submit a New Request")
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["What type of request do you want to run? Request Set alt s","ExtendedCheckbox"]  
    SubmitaNewRequest_form.FindChild(prop,val,10).Click()
    Delay(2000)
    
    prop = ["AWTComponentAccessibleName","JavaClassName"]
    val = ["OK alt O","Button"]
    SubmitaNewRequest_form.FindChild(prop,val,10).Click()
    Delay(2000)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit Request Set","ExtendedFrame"]
    SubmitRequestSet_form=jFrame.FindChildEx(prop,val,60,True,90000)
    self.verify_aqobject_chkproperty(SubmitRequestSet_form,"AWTComponentAccessibleName",cmpContains,"Submit Request Set")
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Request Set RequiredList of Values","VTextField"]
    req_name = SubmitRequestSet_form.Find(prop,val,20)
    req_name.Click()
    Delay(2000)
    req_name.SetText("CAI Excel Invoice Import")
    Delay(2000)
    jFrame.keys("[Tab]")
    Delay(2000)
    
    self.submit_req_set_params(SubmitRequestSet_form,jFrame,15,VarToStr("apinv_cai_zerochaos_AUTO.csv.gpg"),"N")
    self.submit_req_set_params(SubmitRequestSet_form,jFrame,16,VarToStr("Y"),"N") 
    self.submit_req_set_params(SubmitRequestSet_form,jFrame,17,VarToStr("Y"),"N")
    self.submit_req_set_params(SubmitRequestSet_form,jFrame,18,VarToStr("EXCEL"),"N")
    Delay(2000)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val = ["Submit", "Button"]
    SubmitRequestSet_form.FindChild(prop,val,10).Click()
    Delay(2000)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val = ["Decision Request submitted*","ChoiceBox"]
    decision_box = jFrame.FindChildEx(prop,val,60,True,12000)
    RequestID = ''.join(x for x in decision_box.AWTComponentAccessibleName if x.isdigit())

    prop=["AWTComponentAccessibleName","JavaClassName"]
    val = ["No ALT N","FormButton"]
    decision_box.FindChild(prop,val,10).Click()
    Delay(2000)
    self.log_message_oracle_form( jFrame,"Decision NO")
        
    menu_bar=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWMenuBar", "", 0)
    OCR.Recognize(menu_bar).BlockByText("View").Click()
    Delay(1000)
    view_menu=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("LWPopupMenu", "", 0)
    OCR.Recognize(view_menu).BlockByText("Requests").Click()
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Requests","ExtendedFrame"]
    findreq_form = jFrame.FindChildEx(prop,val,60,True,6000)
    Delay(2000)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find alt i","Button"]
    findreq_form.FindChild(prop,val,30).Click()
    Delay(2000)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChild(prop,val,30)
    self.verify_aqobject_chkproperty(req_form,"AWTComponentAccessibleName",cmpContains,"Requests") 
    self.log_message_oracle_form(jFrame,"Requests Form Found") 

 # Checking in the DB for the completion of the concurrent programs
       
    dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
    user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
    pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
    dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,VarToStr(RequestID)) 
    
    form_utils.req_set_save_output(self,jFrame,req_form,"CAI Payables Open Interface Import - EXCEL (Payables Open Interface Import)",RequestID)
    web_utils.close_additional_browsers()  
    Delay(3000) 
       
    req_form.Close()
    Delay(2000)
    
    navigator_form = Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("ExtendedFrame", "Navigator*", 4).AWTObject("LWComponent", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("FScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("DrawnPanel", "", 0).AWTObject("FormsTabPanel", "", 0).AWTObject("TabPanelSheet", "", 0).AWTObject("FScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("DrawnPanel", "", 0).AWTObject("VTList", "Function List", 0).AWTObject("ScrollBox", "", 0).AWTObject("LWDataSourceList$Content", "", 0)
    OCR.Recognize(navigator_form).BlockByText("Invoices").DblClick()
    Delay(1000)
    OCR.Recognize(navigator_form).BlockByText("Entry").DblClick()
    Delay(1000)
    OCR.Recognize(navigator_form).BlockByText("Invoices",spBottomMost).DblClick()   
    Delay(3000)
   
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Invoice Workbench (CAI "+self.oper_unit+" AP INVOICE MAINTENANCE)","ExtendedFrame"]
    jFrame.FindChildEx(prop,val,40,True,90000)
    
    menu_bar=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWMenuBar", "", 0)
    OCR.Recognize(menu_bar).BlockByText("View").Click()
    Delay(1000)
    view_menu=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("LWPopupMenu", "", 0)
    OCR.Recognize(view_menu).BlockByText("Find").Click()
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Invoices","ExtendedFrame"]    
    find_inv_form=jFrame.FindChildEx(prop,val,40,True,90000)
    inv_num=find_inv_form.FindChild("AWTComponentAccessibleName","Invoice: Number",20)
    inv_num.Click()
    inv_num.SetText(VarToStr(self.Inv_num))
    self.log_message_oracle_form(jFrame,"Invoice Number: "+VarToStr(self.Inv_num)) 
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val = ["Find alt i","Button"] 
    find_inv_form.FindChild(prop,val,60).Click()
    Delay(4000)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val = ["Invoice Workbench (CAI US AP INVOICE MAINTENANCE)","ExtendedFrame"] 
    inv_workbench=jFrame.FindChildEx(prop,val,40,True,90000)
    Delay(4000)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val = ["Actions... 1 alt c","Button"] 
    inv_workbench.FindChild(prop,val,40).Click()
    Delay(2000)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val = ["Invoice Actions","ExtendedFrame"] 
    inv_actions=jFrame.FindChildEx(prop,val,40,True,90000)
    Delay(4000)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val = ["Validate alt V","LWCheckbox"] 
    inv_actions.FindChild(prop,val,40).Click()
    Delay(2000)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val = ["Force Approval alt F","LWCheckbox"] 
    inv_actions.FindChild(prop,val,40).Click()
    Delay(2000)
    
    prop = ["AWTComponentAccessibleName","JavaClassName"]
    val = ["OK alt K","Button"]
    inv_actions.FindChild(prop,val,10).Click()
    Delay(3000)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val = ["Actions... 1 alt c","Button"] 
    inv_workbench.FindChild(prop,val,40).Click()
    Delay(2000)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val = ["Create Accounting alt t","LWCheckbox"] 
    inv_actions.FindChild(prop,val,40).Click()
    Delay(2000)

    prop=["AWTComponentAccessibleName","JavaClassName"]
    val = ["Final alt a","ExtendedCheckbox"] 
    inv_actions.FindChild(prop,val,60).Click()
    Delay(2000)

    prop = ["AWTComponentAccessibleName","JavaClassName"]
    val = ["OK alt K","Button"]
    inv_actions.FindChild(prop,val,10).Click()
    Delay(3000)
    
    prop = ["AWTComponentAccessibleName","JavaClassName"]
    val = ["Note Accounting has been successfully created for this transaction.","ChoiceBox"]
    note_window = jFrame.FindChildEx(prop,val,10,True,5000)
    Delay(3000)
    
    prop = ["AWTComponentAccessibleName","JavaClassName"]
    val = ["OK ALT O","FormButton"]
    note_window.FindChild(prop,val,10).Click()
    Delay(3000)
    
    inv_workbench.Close()
    Delay(5000)
    
#    prop = ["AWTComponentAccessibleName","JavaClassName"]
#    val = ["File mnemonic F","LWMenu"]
#    file = jFrame.Find(prop,val,20)
#    file.Click()
#    Delay(2000)
#    file.Keys("w")
#    menu_bar=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWMenuBar", "", 0)
#    OCR.Recognize(menu_bar).BlockByText("File").Click()
#    Delay(2000)
#    jFrame.Keys("w")
#    Delay(2000)

    jFrame.Close()
    Delay(2000)
    jFrame.Keys("~o")

#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Responsibilities","FWindow"]
#    resp_form=jFrame.FindChild(prop,val,30)
#    resp_form.Find("AWTComponentName","LWTextField*",10).Click() 
#    resp_form.Find("AWTComponentName","LWTextField*",10).keys("CAI "+self.oper_unit+" PA JOB SCHEDULER")
#    self.verify_aqobject_chkproperty(resp_form,"AWTComponentAccessibleName",cmpContains,"Responsibilities")   
#    Delay(2000)
#
#    prop = ["AWTComponentAccessibleName","JavaClassName"]
#    val = ["Find ALT F","PushButton"]
#    resp_form.FindChild(prop,val,10).Click()
#    Delay(3000)

    web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" PA JOB SCHEDULER')]")
    Delay(1000)
    self.page.Find("contentText","Submit Request",30).Click()
    Delay(1000)
    jFrame= self.initializeJFrame()
    Delay(3000)
    form_utils.click_ok_btn(jFrame)
    
#    OCR.Recognize(navigator_form).BlockByText("Submit Request").DblClick()
#    Delay(2000)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit a New Request","ExtendedFrame"]
    SubmitaNewRequest_form=jFrame.FindChildEx(prop,val,60,True,90000)
    self.verify_aqobject_chkproperty(SubmitaNewRequest_form,"AWTComponentAccessibleName",cmpContains,"Submit a New Request")
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["What type of request do you want to run? Request Set alt s","ExtendedCheckbox"]  
    SubmitaNewRequest_form.FindChild(prop,val,10).Click()
    Delay(2000)
    
    prop = ["AwtComponentAccessibleName","JavaClassName"]
    val = ["OK alt O","Button"]
    SubmitaNewRequest_form.FindChild(prop,val,10).Click()
    Delay(2000)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit Request Set","ExtendedFrame"]
    SubmitRequestSet_form=jFrame.FindChildEx(prop,val,60,True,90000)
    self.verify_aqobject_chkproperty(SubmitRequestSet_form,"AWTComponentAccessibleName",cmpContains,"Submit Request Set")
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Request Set RequiredList of Values","VTextField"]
    req_name = SubmitRequestSet_form.Find(prop,val,20)
    req_name.Click()
    Delay(2000)
    req_name.SetText("CAI PA Nightly Request Set")
    Delay(2000)
    jFrame.keys("[Tab]")
    Delay(2000)

    prop=["AWTComponentAccessibleName","JavaClassName"]
    val = ["Submit", "Button"]
    SubmitRequestSet_form.FindChild(prop,val,10).Click()
    Delay(2000)
    
    jFrame.keys("~o")
    delay(2000)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val = ["Decision Request submitted*","ChoiceBox"]
    decision_box = jFrame.FindChildEx(prop,val,60,True,12000)
    RequestID = ''.join(x for x in decision_box.AWTComponentAccessibleName if x.isdigit())

    prop=["AWTComponentAccessibleName","JavaClassName"]
    val = ["No ALT N","FormButton"]
    decision_box.FindChild(prop,val,10).Click()
    Delay(2000)
    self.log_message_oracle_form(jFrame,"Decision NO")
    Delay(2000)
    
    menu_bar=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWMenuBar", "", 0)
    OCR.Recognize(menu_bar).BlockByText("View").Click()
    Delay(1000)
    view_menu=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("LWPopupMenu", "", 0)
    OCR.Recognize(view_menu).BlockByText("Requests").Click()
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Requests","ExtendedFrame"]
    findreq_form = jFrame.FindChildEx(prop,val,60,True,6000)
    Delay(1000)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find alt i","Button"]
    findreq_form.FindChild(prop,val,20).Click()
    Delay(2000)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChild(prop,val,30)
    self.verify_aqobject_chkproperty(req_form,"AWTComponentAccessibleName",cmpContains,"Requests") 
    self.log_message_oracle_form(jFrame,"Requests Form Found") 
    
    form_utils.req_set_save_output(self,jFrame,req_form,"AUD: Supplier Costs Interface Audit",RequestID)
    web_utils.close_additional_browsers()  
    Delay(3000) 

    req_form.Close()
    Delay(5000)
    jFrame.Close()
    Delay(2000)
    jFrame.Keys("~o")
    
#    prop = ["AWTComponentAccessibleName","JavaClassName"]
#    val = ["File mnemonic F","LWMenu"]
#    file = jFrame.Find(prop,val,20)
#    file.Click()
#    Delay(2000)
#    jFrame.Keys("w")
#    Delay(2000)
#    
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Responsibilities","FWindow"]
#    resp_form=jFrame.FindChild(prop,val,30)
#    resp_form.Find("AWTComponentName","LWTextField*",10).Click() 
#    resp_form.Find("AWTComponentName","LWTextField*",10).keys("CAI "+self.oper_unit+" PA PROJECT CONTROLS")
#    self.verify_aqobject_chkproperty(resp_form,"AWTComponentAccessibleName",cmpContains,"Responsibilities")   
#    Delay(2000)
#    
#    prop = ["AWTComponentAccessibleName","JavaClassName"]
#    val = ["Find ALT F","PushButton"]
#    resp_form.FindChild(prop,val,10).Click()
#    Delay(3000)
#    self.log_message_oracle_form(jFrame,"Navigation Details")
#    Delay(3000)
#    
#    navigator_form = Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("ExtendedFrame", "Navigator*", 4).AWTObject("LWComponent", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("FScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("DrawnPanel", "", 0).AWTObject("FormsTabPanel", "", 0).AWTObject("TabPanelSheet", "", 0).AWTObject("FScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("DrawnPanel", "", 0).AWTObject("VTList", "Function List", 0).AWTObject("ScrollBox", "", 0).AWTObject("LWDataSourceList$Content", "", 0)
#    OCR.Recognize(navigator_form).BlockByText("Expenditures").DblClick()
#    Delay(1000)
#    OCR.Recognize(navigator_form).BlockByText("Expenditure Inquiry").DblClick()
#    Delay(1000)
#    OCR.Recognize(navigator_form).BlockByText("Project").DblClick()   
#    Delay(3000)
    
    web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" PA PROJECT CONTROLS')]")
    Delay(1000)
    self.page.Find("contentText","Expenditures",30).Click()
    Delay(1000)
    self.page.Find("contentText","Expenditure Inquiry",30).Click()
    Delay(1000)
    self.page.Find("contentText","Project",30).Click()
    Delay(1000)
    jFrame= self.initializeJFrame()
    Delay(3000)
    form_utils.click_ok_btn(jFrame)
    Delay(1000)
    jFrame.Keys("~o")
    Delay(5000)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Project Expenditure Items","ExtendedFrame"]
    proj_exp_form=jFrame.FindChild(prop,val,30) 
    
    #Project number is hardcoded, Project number should change when we use the .csv file
    proj_exp_form.Find("AWTComponentAccessibleName","Project NumberList of Values",20).keys("1000208") #("1005538")
    self.verify_aqobject_chkproperty(proj_exp_form,"AWTComponentAccessibleName",cmpContains,"Find Project Expenditure Items")
    Delay(2000)
    
    proj_exp_form.Find("AWTComponentName","FormsTabPanel*",20).ClickTab("Supplier")
    self.log_message_oracle_form( jFrame,"Supplier Tab Detail")
    Delay(2000)
    proj_exp_form.Find("AWTComponentAccessibleName","*Invoice NumberList of Values",20).SetText(VarToStr(self.Inv_num))
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find alt i","Button"]
    proj_exp_form.FindChild(prop,val,30).Click()
    self.log_message_oracle_form(jFrame,"Project Expenditure Items")
    Delay(5000)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Project Expenditure Items","ExtendedFrame"]
    proj_exp_item_form=jFrame.FindChild(prop,val,30) 
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Item Details alt D","Button"]
    proj_exp_item_form.FindChild(prop,val,30).Click()
    self.log_message_oracle_form(jFrame,"Item Details")
    Delay(3000)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Item Details","ExtendedFrame"]
    item_det_form=jFrame.FindChild(prop,val,30) 
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["OK alt O","Button"]
    item_det_form.FindChild(prop,val,30).Click()
    self.log_message_oracle_form(jFrame,"Cost Verified")
    
    jFrame.Close()
    Delay(2000)
    jFrame.Keys("~o")
    Delay(2000)     
 

# Modifying cai_excel_invoice_import_report_set.csv file 
 def update_proj_creation_xldetails(self):
     file_system_utils.create_folder("C:\\prj_contrt_file")
     file_exist=aqFileSystem.FindFiles("C:\\prj_contrt_file","apinv_cai_zerochaos_AUTO.csv")
     if file_exist != None:
       aqFileSystem.DeleteFile("C:\\prj_contrt_file\\*.csv")
     aqFileSystem.CopyFile(Project.Path+"DataSheets\\Oracle-PA-Additions\\apinv_cai_zerochaos_AUTO.csv", "C:\\prj_contrt_file\\apinv_cai_zerochaos_AUTO.csv")   
     self.Inv_num="TestInv"+VarToStr(random.randint(1111,9999))
     
     fo=open("C:\\prj_contrt_file\\apinv_cai_zerochaos_AUTO.csv","r+")
     data=fo.read()   
     Log.Message(fo.tell())
     fo.seek(899,0)
     fo.write(self.Inv_num)
     fo.seek(1015,0)
     fo.write(self.Inv_num)
     fo.seek(1304,0)
     fo.write(self.Inv_num)          
     fo.close()   
     Log.Enabled=True
     Log.File(VarToStr("C:\\prj_contrt_file\\apinv_cai_zerochaos_AUTO.csv"), "apinv_home_excel_ZC Import File Attached")
     Log.Enabled=False 
   
# Placing cai_excel_invoice_import_report_set.csv file in /DAUT2I/incoming/ATG_OU/PA_XLS_PRJ_UPLOAD folder
 def place_proj_creation_file_winscp(self,):
#    Stored_session = "opc@stage-fin-iad1-ebsapp1.private.stagefin.oraclevcn.com"
    Stored_session = "cai_oracle_apinvoices@mftstg.manheim.com"
    local_dir = "C:\\prj_contrt_file"
#    remote_dir =  self.testConfig['winscp']['remote_dir'] 
    remote_dir =  "//Outbox//TAUTRI"
#    remote_dir =  self.winscpConfig[self.testConfig['ebiz']['env']]['remote_dir']+"incoming//ATG_OU//AP_XLS_INV_UPLOAD"
    upload_file_name="apinv_cai_zerochaos_AUTO.csv"
    winscp_utility.upload_file(Stored_session,local_dir,remote_dir,upload_file_name)
    Log.Enabled=True       
    Log.Message("apinv_home_excel_ZC_20190501.csv file placed in the //ATG_OU//AP_XLS_INV_UPLOAD directory")           
    Log.Enabled=False
    

 def submit_req_set_params(self,submitrequest_form,jFrame,index_no,proj_no,tab):
     prop=["AWTComponentAccessibleName","AWTComponentIndex"]
     val=["Parameters",index_no]
     submitrequest_form.FindChild(prop,val,60).Click()
     Delay(2000)   
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Parameters","FlexWindow"]   
     parameter_form=jFrame.FindChild(prop,val,60)
     if tab=='Y':
        parameter_form.Keys("[Tab]")
     Delay(2000)  
      
     parameter_form.Keys(proj_no)
     parameter_form.Keys("~o")
     Delay(1000)  
