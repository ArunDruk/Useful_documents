﻿import gvar
import web_utility
import tc_logs

def ar_home_office_super_user_link():
  return web_utility.find_link_by_contenttext("AR Home Office Super User") 

#Begin - Adding new links for 12.2.8 upgrade - Balaji
def control_link():
  return web_utility.find_link_by_contenttext("Control")
  
def requests_link():
  return web_utility.find_link_by_contenttext("Requests")

def run_link():
  return web_utility.find_link_by_contenttext("Run")
  
def set_link():
  return web_utility.find_link_by_contenttext("Set")

def receipts_link():
  return web_utility.find_link_by_contenttext("Receipts")

def batches_link():
  return web_utility.find_link_by_contenttext("Batches")
  
def customers_link():
  return web_utility.find_link_by_contenttext("Customers")

def customers_page_link():
  return web_utility.find_by_xpath("//li[@id='LICustomers']//div[@class='textdiv'][contains(text(),'Customers')]")
  
#End - adding new links for 12.2.8 upgrade - Balaji
  
def control_requests_run_link():
  return web_utility.find_link_by_contenttext("Run")
  
def transactions_link(): 
  return web_utility.find_link_by_contenttext("Transactions")
  
def logout_link():
  prop_names = ["namePropStr", "ObjectIdentifier", "ObjectType"]
  prop_values = ["signout.png", "signout_png", "Image"]
  if gvar.dataprep['page'].Find(prop_names,prop_values,10000).Exists:
    return gvar.dataprep['page'].Find(prop_names,prop_values,10000)
  else:tc_logs.error_with_picture("unable to find logout/signout link","",gvar.dataprep['page'])

def order_management_super_user_link():
  return web_utility.find_link_by_contenttext('Order Management Super User')
  
def salespersons_link():
  return web_utility.find_link_by_contenttext('Salespersons')
  
def sales_orders_link():
  return web_utility.find_link_by_contenttext('Sales Orders')
  
def receivables_link():
  return web_utility.find_link_by_contenttext('Receivables')

def inventory_link():
  return web_utility.find_link_by_contenttext('Inventory')

def master_items_link():
  return web_utility.find_link_by_contenttext('Master Items')

def ar_cash_reciept_control_requests_run_link():
    return web_utility.find_link_by_contenttext('Run')

def ar_cash_reciept_batches_link():
    return web_utility.find_link_by_contenttext('Batches')

  
def consignment_manager_link():
  prop_names = ["tagName", "contentText"]
  prop_values = ["A", "Consignment Manager" ]
  return gvar.dataprep['page'].Find(prop_names,prop_values,5000)
  tc_logs.checkpt_with_picture("Click on 'Consignment Manager' - Successful","",gvar.dataprep['page'])
  
def workflow_web_administrator_new_link():
  return web_utility.find_link_by_contenttext("Workflow Administrator Web (New)")
 
def status_monitor():
 return web_utility.find_link_by_contenttext("Status Monitor")
  
def receivables_manager_link():
  prop_names = ["tagName", "contentText", "idStr"]
  prop_values = ["A", "Receivables Manager", "AppsNavLink" ]
  return gvar.dataprep['page'].Find(prop_names,prop_values,5000)
  
def gl_cai_corporate_accounting_user_link():
  prop_names = ["tagName", "contentText", "idStr"]
  prop_values = ["A", "GL CAI Corporate Accounting User", "AppsNavLink" ]
  return gvar.dataprep['page'].Find(prop_names,prop_values,5000)

def gl_cai_corporate_accounting_user_report_requests_run_link():
  return gvar.dataprep['page'].Find("textContent","Run",60)

def cash_management_super_user_link(): 
   prop_names=["contentText","idStr"]
   prop_values=["Cash Management Superuser","AppsNavLink"]
   return gvar.dataprep['page'].Find(prop_names,prop_values,5000)

def cash_management_super_user_concurrent_link():
   return gvar.dataprep['page'].Find("textContent","Concurrent",60)
   
def receivables_manager_receipts_link():
  return gvar.dataprep['page'].Find("textContent","Receipts",60)
  
def order_mgmt_sales_order_link(): 
  return gvar.dataprep['page'].Find("textContent","Sales Orders",60)
  
def ar_home_office_payment_approver_link(): 
  prop_names = ["tagName", "contentText", "idStr"]
  prop_values = ["A", "AR Home Office Payment Approver", "AppsNavLink" ]
  return gvar.dataprep['page'].Find(prop_names,prop_values,5000)

def ap_home_office_super_user_link():
  return web_utility.find_link_by_contenttext("AP Home Office Super User") 

def payment_manager_link():
  return web_utility.find_link_by_contenttext("Payments Manager") 
# Adding new link for 12.2.8  
def payments_link():
  return web_utility.find_by_contenttext("Payments")
# Adding new link for 12.2.8    
def entry_link():
  prop_names = ["tagName", "contentText", "className"]
  prop_values = ["DIV", "Entry", "textdivresp" ]
  return gvar.dataprep['page'].Find(prop_names,prop_values,5000)

#  return web_utility.find_by_xpath("//div[@class='textdivresp'][contains(text(),'Entry')]")

    
def ar_00418_oralando_payment_approver_link():
  return web_utility.find_link_by_contenttext("AR 00418 Orlando Payment Approver")
  
 # Adding ar payment dashboard as part of porting 12.2.8 
def ar_payment_dashboard_link():
  return web_utility.find_link_by_contenttext("AR Payment Dashboard")
    
def ar_cash_receipt_link():
   return web_utility.find_link_by_contenttext("AR Cash Receipt")
  
def ar_inquiry_link():
   return web_utility.find_link_by_contenttext("AR Inquiry")

# US392534 rmishra2++ added new method for OCI upgrade      
def reports_link():
   return web_utility.find_link_by_contenttext("Reports")
# US392534 rmishra2--

def others_link():
   return web_utility.find_link_by_contenttext("Other")
   
def ar_inquiry_transactions_link():
   return web_utility.find_link_by_contenttext("Transactions")
  
def collections_administrator_link():
  return web_utility.find_link_by_contenttext("Collections Administrator")      

def collections_administrator_lookup_types_link():
  return gvar.dataprep['page'].Find("textContent","Lookup Types",60)
  
def home_header_title():
   return web_utility.find_by_contenttext("Home")

def transactions_summary_link(): 
  return web_utility.find_link_by_contenttext("Transactions Summary")
   
 
