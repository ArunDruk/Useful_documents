﻿from ebiz import *
import web_utils
import form_utils
import dbhelper
import file_system_utils


class tc206488_is_webadi_tax_lines_reclass(Ebiz):

 op_log_path ="C:\\TC_Logs"

 def login(self):
   self.login_user='pkjami'
   super().login()
 
 def goto_url(self,url):
   super().goto_url(self.testConfig['ebiz']['oci_is_url'])
   
 def action(self,book):
   web_utils.log_checkpoint("Login to Oracle Applications Successful",500,self.page) 
#   web_utils.log_checkpoint("Currency Selected WebADI Journal entry: "+ProjectSuite.Variables.currency,500,self.page) 
   rowno=2 
   app_prj=book.Sheets.item["Project"] 
   app_req=book.Sheets.item["Requisition"] 
   app_inv=book.Sheets.item["Invoice"]  
    
# Navigation to Oracle Home Page

   web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='menuContent']//div[contains(text(),'PC User')]") 
   self.wait_until_page_loaded()
   self.page.NativeWebObject.Find("contentText","Manheim WebAdi","A").scrollIntoView()
   self.page.NativeWebObject.Find("contentText","Manheim WebAdi","A").Click()
   web_utils.log_checkpoint("Click 'Manheim WebAdi' - Successful",500,self.page)
   delay(2000)
   self.page.wait()
   self.page.NativeWebObject.Find("contentText","Non Adopters Cost","A").scrollIntoView()
   delay(2000)
   self.page.NativeWebObject.Find("contentText","Non Adopters Cost","A").Click()
#   web_utils.log_checkpoint("Click 'Non Adopters Cost' - Successful",500,self.page)
   self.wait_until_page_loaded()

#Navigating to Non Adopters Cost & Launching WebADI template

  
   Delay(3000)
#   self.page.Find("idStr","LayoutList",30).ClickItem("Manheim Functional Actuals")
   self.page.Find("idStr","*Viewer",30).ClickItem("Excel 2016")
   Delay(4000)
   web_utils.log_checkpoint("Click 'Non Adopters Cost' - Successful and Selecting the 'Excel 2016'",500,self.page)
   self.page.Find("idStr","createDocument",30).Click()
   web_utils.log_checkpoint("Click on 'Create' in Create Document - Successful",500,self.page)
   Delay(20000)   
   Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Notification Bar", "", 1).UIAObject("Notification").UIAObject("Open").Click()         

   xl_window=Sys.Process("EXCEL", 2).Window("XLMAIN", "Projects - Transaction Impor*", 1).Window("XLDESK", "", 1).Window("EXCEL7", "Projects - Transaction Impor*", 1)
   Delay(10000)
   wnd = Sys.Desktop.ActiveWindow()
   Log.Enabled=True
   Log.Picture(wnd, "Displaying the WebADI template - Successful",wnd.FullName)
   Log.Enabled=False

   self.template_values(xl_window,app_prj,app_req,app_inv)

   Log.Enabled=True  
   Log.Picture(wnd, "WebADI has been launched and Project, Task, Organization, Expenditure date, type, Class, quantity all other details have been entered in WebADI successfully", wnd.FullName)                   
   Log.Enabled=False  
   Delay(3000)

#   excel_obj=Sys.Process("EXCEL", 2).Window("XLMAIN", "General Ledger - Journals*", 1).Window("EXCEL2", "", 2).Window("MsoCommandBar", "Ribbon", 1).Window("MsoWorkPane", "Ribbon", 1).Window("NUIPane", "", 1).Window("NetUIHWND", "", 1)
   excel_obj=Sys.Process("EXCEL", 2).Window("XLMAIN", "Projects - Transaction Impor*", 1).Window("EXCEL2", "", 2).Window("MsoCommandBar", "Ribbon", 1).Window("MsoWorkPane", "Ribbon", 1).Window("NUIPane", "", 1).Window("NetUIHWND", "", 1)  
   Delay(1000)
#   OCR.Recognize(excel_obj).BlockByText("Oracle").Click()
#   Delay(4000)
#   OCR.Recognize(excel_obj).BlockByText("Upload").Click()
#   Delay(4000) 
   Delay(1000)
   excel_obj.Keys("~")
   Delay(1000)
   excel_obj.Keys("Y1")
   Delay(3000)
   oracle_menu = Sys.Process("EXCEL", 2).Window("Net UI Tool Window", "", 1).Window("NetUIHWND", "", 1)
   Sys.HighlightObject(oracle_menu)
   OCR.Recognize(excel_obj).BlockByText("Upload").Click() 
   oracle_menu.Keys("U")
   delay(1100)
   oracle_menu.Keys("P") 
   delay(3000)
      
#   delay(3000) 
   upload_wnd=Sys.Process("EXCEL", 2).Window("ThunderDFrame", "Upload Parameters", 1)
   if upload_wnd.Exists:
       prop=("ObjectLabel","ObjectLabel")
       val=("Flagged Rows","RadioButton")  
       Flag=upload_wnd.FindChild(prop,val,40).wChecked 
       if Flag==False:
         upload_wnd.FindChild(prop,val,40).Click()
       Delay(3000)  
       upload_wnd.Find("contentText","Pre-Validate",40).Click()
       Delay(2000)
       self.log_message_oracle_excel_popup(upload_wnd,"Displaying the upload window - successful")
       upload_wnd.Find("ObjectLabel","Upload",40).Click()
       Delay(23000)
       if upload_wnd.Find("ObjectIdentifier","error_png",40).Exists:  #"errorl_gif"
         self.log_message_oracle_excel_popup(upload_wnd,"Upload Failed!!")
         Log.Error("Tax Lines WebADI Upload Failed.") 
         Runner.Stop()                 
       else:
         Log.Enabled=True
         wnd = Sys.Desktop.ActiveWindow()
         Log.Picture(wnd, "Tax Lines WebADI Upload Passed",wnd.FullName)
         Log.Enabled=False   
         
   conf_msg=upload_wnd.Find("idStr","BneAsyncUploadPageConfirmation",40).contentText 
   self.log_message_oracle_excel_popup(upload_wnd,"Confirmation Message:- "+aqConvert.VarToStr(conf_msg))
   Delay(4000)            
   upload_wnd.Find("ObjectLabel","Close",20).Click() 
#   req_id=conf_msg.split("Request ID",4)[1][1:10]
   req_id_msg=upload_wnd.Find("contentText","Request id is*",40).contentText    
   req_id="".join(i for i in req_id_msg if i.isdigit())
   delay(1000) 
#   app.Cells.Item[2,13] =VarToStr(req_id)
   Delay(4000) 
   xl_window.Keys("~[F4]")
   Delay(7000)
   xl_window.Keys("~n")
   delay(5000)
#   self.page.EvaluateXPath("//img[@title='Home']")[0].Click()
#   self.page.wait_until_page_loaded()
   Delay(5000)  
   

# Navigating to PC User -> Other -> Request -> Run
   
   
#   web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='menuContent']//div[contains(text(),'PC User')]") 
#   self.wait_until_page_loaded()
#   web_utils.log_checkpoint("Click 'PC User' - Successful",500,self.page)
   self.page.NativeWebObject.Find("contentText","Other","A").scrollIntoView()
   self.page.NativeWebObject.Find("contentText","Other","A").Click() 
   web_utils.log_checkpoint("Click 'Other' - Successful",500,self.page)
   Delay(2000)
   self.page.NativeWebObject.Find("contentText","Requests","A").Click()
   web_utils.log_checkpoint("Click 'Requests' - Successful",500,self.page)
   Delay(2000)
   self.page.NativeWebObject.Find("contentText","Run","A").Click()
   web_utils.log_checkpoint("Click 'Run' - Successful",500,self.page)
   Delay(2000)

#   self.page.NativeWebObject.Find("contentText","Enter","A").Click()
#   web_utils.log_checkpoint("Click 'Enter' - Successful",500,self.page)

   web_utils.validate_security_box()
   Delay(10000)
   jFrame=self.initializeJFrame()
   Delay(15000)
   form_utils.click_ok_btn(jFrame) 
   Delay(5000)
   jFrame.Keys("[F4]")
   Delay(3000)
#   form_utils.save_output_singlereq(self,jFrame,self.op_log_path,"Web ADI - Journal Import (Journal Import)",req_id)
   form_utils.save_output_singlereq(self,jFrame,self.op_log_path,"WebADI_PRC_Transaction_Import",req_id) 
   Delay(3000)
   jFrame.Click()
   Delay(3000)
#   jFrame.Keys("[F4]")
#   Delay(5000)
#   jFrame.Keys("[F4]")
#   Delay(3000)
   
# Navigation to Expenditures -> Expenditures Inquiry -> All

   navigator_form=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("ExtendedFrame", "Navigator - PC User", 4)
   Sys.HighlightObject(navigator_form)
   OCR.Recognize(navigator_form).BlockByText("Expenditures").DblClick()
   delay(2000)
   OCR.Recognize(navigator_form).BlockByText("Expenditure Inquiry").DblClick()
   delay(2000)
   web_utils.log_checkpoint("Navigating to 'Expenditures' > 'Expenditure Inquiry' > 'All' ",500,jFrame)  #self.page
   OCR.Recognize(navigator_form).BlockByText("All").DblClick()
   delay(2000)
   
# In Find Expenditures form, querying the project num
   
   p_names = ("AWTComponentAccessibleName","JavaClassName")
   p_values = ("Find Expenditure Items","ExtendedFrame")
   find_expd_form=jFrame.FindChildEx(p_names,p_values,60,True,1200000)
   Sys.HighlightObject(find_expd_form)
   
   obj=jFrame.FindChild(p_names,p_values,50)
   if obj.Exists:
      web_utils.log_checkpoint("'Find Expenditure Items' form launched successfully",500,jFrame) 
   else:
      self.log_message_oracle_form(jFrame,"Unable to Launch 'Find Expenditure Items' form")
      
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Project NumberList of Values","VTextField"]
   Proj_num=find_expd_form.FindChild(prop,val,20)
   Sys.HighlightObject(Proj_num)
   Proj_num.Click()
   Proj_num.Find(prop,val,30).Keys(app_prj.Cells.Item[rowno,11]) #proj_num.Find(prop, val,30).Keys
   delay(2000)
   web_utils.log_checkpoint(" On 'Find Expenditure Items' form Project number : "+aqConvert.VarToStr(app_prj.Cells.Item[rowno,11])+" entered successfully",500,jFrame) 
#   web_utils.log_checkpoint(" On 'Find Expenditure Items' form Project number : "+ "111594" +" entered successfully",500,jFrame) 
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Find alt i","Button"]
   find_bttn = find_expd_form.FindChild(prop,val,20)
   Sys.HighlightObject(find_bttn)    
   find_bttn.Click()  
   web_utils.log_checkpoint(" On 'Find Expenditure Items' form click 'Find' button successful",500,jFrame)   
   Delay(5000)    
   
   p_names = ("AWTComponentAccessibleName","JavaClassName")
   p_values = ("Expenditure Items","ExtendedFrame")
   expd_items_form=jFrame.FindChildEx(p_names,p_values,60,True,1200000)
   Sys.HighlightObject(expd_items_form)
   expd_title_bar=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("ExtendedFrame", "Expenditure Items", 23).AWTObject("TitleBar", "", 0).AWTObject("LWComponent", "", 0).AWTObject("TitleBar$CaptionComp", "", 0)
   Sys.HighlightObject(expd_title_bar)
   expd_title_bar.DblClick()
#   web_utils.log_checkpoint(" 'Expenditure Items form' Displaying the Tax lines",500,jFrame)   
   delay(4000)
   
   i=80
   tax_component= app_inv.Cells.Item[rowno,23] #"150.00"
#   tax_component = tax_component + ".00"
   for x in range(1,9):
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Proj Func Burdened Cost",i]
    expd_items_form.FindChild(prop,val,20).Click()
    tax_val=expd_items_form.FindChild(prop,val,20).wText
    i+=1
    if(VarToFloat(tax_val) == VarToFloat(tax_component)):
      web_utils.log_checkpoint(" In 'Expenditure Items form' Validated the Tax component added",500,jFrame)  
      prop=["AWTComponentAccessibleName","JavaClassName"]
      val=["Item Details alt D","Button"]
      expd_items_form.FindChild(prop,val,20).Click()
      delay(2000)
      jFrame.Keys("~o")
      delay(2000)
      web_utils.log_checkpoint("Displaying 'Cost Distribution Lines' for the tax amount",500,jFrame)
      p_names = ("AWTComponentAccessibleName","JavaClassName")
      p_values = ("Cost Distribution Lines","ExtendedFrame")
      cost_dis_form=jFrame.FindChildEx(p_names,p_values,60,True,1200000)
      cost_dis_form.Close() 
      break
   else:
      web_utils.log_error("Not able to find the Tax Component added")
#    self.log_error_message("Not able to find the Tax Component added")
      
   expd_items_form.Close()
   Delay(5000)
   
#   jFrame.Keys("[F4]")
#   Delay(5000)
#   jFrame.Keys("[F4]")
   find_expd_form.Close() 
   Delay(7000)
   
   
# Navigating to Capitalization -> Capital Projects

   navigator_form=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("ExtendedFrame", "Navigator - PC User", 4)
   Sys.HighlightObject(navigator_form)
   OCR.Recognize(navigator_form).BlockByText("Capitalization").DblClick()
   delay(2000)
   web_utils.log_checkpoint("Navigating to 'Capitalization' > 'Capital Projects' ",500,jFrame)    #self.page
#   OCR.Recognize(navigator_form).BlockByText("Capital Projects").DblClick()
   jFrame.Keys("[Enter]") 
   delay(4000)
   
   p_names = ("AWTComponentAccessibleName","JavaClassName")
   p_values = ("Find Capital Projects","ExtendedFrame")
   find_cap_prj_form=jFrame.FindChildEx(p_names,p_values,60,True,1200000)
   Sys.HighlightObject(find_cap_prj_form)
   
   obj=jFrame.FindChild(p_names,p_values,50)
   if obj.Exists:
      web_utils.log_checkpoint("'Find Capital Projects' form launched successfully",500,jFrame) 
   else:
      self.log_message_oracle_form(jFrame,"Unable to Launch 'Find Capital Projects' form")
      
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Project: NumberList of Values","VTextField"]
   Proj_num=find_cap_prj_form.FindChild(prop,val,20)
   Sys.HighlightObject(Proj_num)
   Proj_num.Click()
   Proj_num.Find(prop,val,30).Keys(app_prj.Cells.Item[rowno,11]) #proj_num.Find(prop, val,30).Keys
   delay(3000)
   web_utils.log_checkpoint(" On 'Find Capital Projects' form Project number : "+aqConvert.VarToStr(app_prj.Cells.Item[rowno,11])+" entered successfully",500,jFrame) 
#   web_utils.log_checkpoint(" On 'Find Expenditure Items' form Project number : "+ "111594" +" entered successfully",500,jFrame) 
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Find alt i","Button"]
   find_bttn = find_cap_prj_form.FindChild(prop,val,20)
   Sys.HighlightObject(find_bttn)    
   find_bttn.Click()  
   web_utils.log_checkpoint(" On 'Find Capital Projects' form click 'Find' button successful",500,jFrame)   
   Delay(5000)
   
   p_names = ("AWTComponentAccessibleName","JavaClassName")
   p_values = ("Capital Projects*","ExtendedFrame")
   cap_prj_form=jFrame.FindChildEx(p_names,p_values,60,True,1200000)
   Sys.HighlightObject(cap_prj_form)
   
   prop=["AWTComponentAccessibleName","AWTComponentIndex"]
   val=["CIP","40"]
   tax_value = cap_prj_form.FindChild(prop,val,20).wText
   tax_component=tax_value.replace(",","").replace(".00","")
#   inv_amount = app_inv.Cells.Item[rowno,4]
#   sa_tax = app_inv.Cells.Item[rowno,23]
#   tax_component = VarToFloat(inv_amount)+VarToFloat(sa_tax)
   if (VarToInt(tax_component) > 0):
#   if (VarToFloat(tax_value) == VarToFloat(tax_component)): 
    web_utils.log_checkpoint("In 'Capital Projects' form, Validated the Tax value",500,jFrame)
   else:
    web_utils.log_error("Not able to find the Tax Component added")
   
#   web_utils.log_checkpoint("In 'Capital Projects' form Click on 'Lines'",500,jFrame)
#   prop=["AWTComponentAccessibleName","JavaClassName"]
#   val=["Lines alt i","Button"]
#   find_bttn = cap_prj_form.FindChild(prop,val,20)
#   Sys.HighlightObject(find_bttn)    
#   find_bttn.Click()
#   Delay(4000)
#   
#   p_names = ("AWTComponentAccessibleName","JavaClassName")
#   p_values = ("Asset Lines*","ExtendedFrame")
#   asset_lines_form=jFrame.FindChildEx(p_names,p_values,60,True,1200000)
#   Sys.HighlightObject(asset_lines_form)
#   web_utils.log_checkpoint(" 'Asset lines form' Displaying the Tax lines",500,jFrame)   
#   delay(4000)
#   asset_lines_form.Close()
#   Delay(4000)
   
   cap_prj_form.Close()
   Delay(4000)
   
   find_cap_prj_form.Close()
   Delay(5000)
   
   jFrame.Keys("[F4]")
   delay(6000)
   jFrame.Keys("~o")
   Delay(5000)
   self.close_forms(jFrame)
   delay(5000)
   
   
#Entering values in WebADI template for US currency

 def template_values(self,xl_window,app_prj,app_req,app_inv):  
   rowno=2
   row_no=3 #22
   xl_window.Click()
   Delay(2000)
   xl_window.keys("^g")
   Delay(2000)
   goTo_wnd=Sys.Process("EXCEL", 2).Window("bosa_sdm_XL9", "Go To", 1).Window("EDTBX", "", 1)
   goTo_wnd.Click()
   goTo_wnd.Keys("E4") #("H9")   
   Delay(1000)
   goTo_wnd.keys("[Enter]")
   Delay(1000)
   
   cur_day_week = aqDateTime.Today()
   wk_diff = 7-aqDateTime.GetDayOfWeek(cur_day_week)
   wknd_date = aqConvert.DateTimeToFormatStr(aqDateTime.AddDays(cur_day_week,wk_diff),"%d-%b-%Y")
   
   xl_window.Keys(VarToStr(wknd_date)) 
   Delay(1000)
   xl_window.Keys("[Down]") #("[Tab]")
   Delay(1000)
   xl_window.Keys("[Down]") #("[Tab]")
   Delay(1000)
   xl_window.Keys("Self_Assessed_Tax_Reclass_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%M%S"))
   Delay(1000)
   xl_window.Click()
   xl_window.keys("^g")
   Delay(2000)
   goTo_wnd=Sys.Process("EXCEL", 2).Window("bosa_sdm_XL9", "Go To", 1).Window("EDTBX", "", 1)
   goTo_wnd.Click()
   goTo_wnd.Keys("[BS]")
   goTo_wnd.Keys("[BS]")
   goTo_wnd.Keys("[BS]")
   Delay(1000)
   goTo_wnd.Keys("C14") #("C18")   
   Delay(1000)
   goTo_wnd.keys("[Enter]")
   Delay(1000)
   while rowno<row_no:
    xl_window.Keys(app_prj.Cells.Item[rowno,11]) #  (app.Cells.Item[rowno,1])
    xl_window.Keys("[Tab]")
    
#    task = "%2.1f"%(VarToInt(app_req.Cells.item[rowno,12]))
    task = VarToStr(app_inv.Cells.Item[rowno,10])[2:]
    xl_window.Keys(task) #  (app.Cells.Item[rowno,2])
    xl_window.Keys("[Tab]")
    xl_window.Keys(app_inv.Cells.Item[rowno,12])
    xl_window.Keys("[Tab]")
    xl_window.Keys(aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d-%b-%Y")) #(app.Cells.Item[rowno,4])
    xl_window.Keys("[Tab]")
    
    inv_num=VarToStr(app_inv.Cells.Item[rowno,13])
    supp_name=VarToStr(app_inv.Cells.Item[rowno,3])
    exp_comment= inv_num +' - ' + supp_name
    
    xl_window.Keys(VarToStr(exp_comment)) #(app.Cells.Item[rowno,5])
    xl_window.Keys("[Tab]")
    xl_window.Keys(app_prj.Cells.Item[rowno,11])  #(app.Cells.Item[rowno,6])
    xl_window.Keys("[Tab]")
    xl_window.Keys(app_inv.Cells.Item[rowno,23])
    xl_window.Keys("[Tab]")
    
#    expd_type="BUILDING & PROPERTY MAINT"

    xl_window.Keys(app_inv.Cells.Item[rowno,11]) #  (expd_type)
    xl_window.Keys("[Tab]")
#    xl_window.Keys(app.Cells.Item[rowno,9])
#    xl_window.Keys("[Tab]")
#    xl_window.Keys(app.Cells.Item[rowno,10])
#    xl_window.Keys("[Tab]")
#    xl_window.Keys(app.Cells.Item[rowno,11]) #  ("Test Line Description_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%M%S"))
    xl_window.Keys("[Tab][Tab][Tab]")
    xl_window.Keys(aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d-%b-%Y"))
    xl_window.Keys("[Tab]")
    xl_window.Keys("[Tab]")
    rowno=rowno+1
#    Delay(100000)
    






