﻿import tc_logs
from gvar import dataprep as DATAPREP
from database_service import query_oracle_db as ORACLE_DB
import dealer_queries 
                                           
import gvar
import odm_datatype
import database_service
import login_logout_utility
import oracle_responsibility_utility
import form_utility
import tc_logs
import validate_queue_details
import title_change
import Inv_api_response_validation
import adjustments_api 
import traceback 
                                           
                                           
class Dealer(object):
                                              
  __print = tc_logs.msg_with_no_picture
  __Error = tc_logs.error_with_no_picture
                                             
                                              
  def __init__(self):
      pass 
                                                  
  def random_dealers(self):
      self.random_seller()
      self.random_buyer()
      
  def random_dealers_ach(self):
      self.random_seller()
      self.random_buyer_ach()
                                                  
  def execute_qry(self,qry):
     rows = ORACLE_DB(qry)
     if (GetVarType(rows)== VarToInt(9) 
             and len(rows) > 0 ):
         return rows  
                                                      
  def random_seller(self):
     __5M_SELLER = dealer_queries.random_5M_seller_qry
     SELLER = self.execute_qry(__5M_SELLER())[0]['DEALER']
     self._load_seller_fields(SELLER,SELLER)          
                                            
                                                
  def random_buyer_ach(self):
     __5M_BUYER  = dealer_queries.ach_pref_5M_buyer_qry
     rows = self.execute_qry(__5M_BUYER())
     buyer = rows[0]['DEALER']
     rep   = rows[0]['REP']          
     self._load_buyer_fields(buyer,buyer,rep) 
  
  def random_buyer(self):
     __5M_BUYER  = dealer_queries.random_5M_buyer_qry
     rows = self.execute_qry(__5M_BUYER())
     buyer = rows[0]['DEALER']
     rep   = rows[0]['REP']          
     self._load_buyer_fields(buyer,buyer,rep) 
                                             
                                                                      
  def _load_seller_fields(self,bill_to,sold_to):
    DATAPREP['seller'] = DATAPREP['seller_bill_to'] = bill_to
    DATAPREP['seller_sold_to'] = sold_to
                                                   
  def _load_buyer_fields(self,bill_to,sold_to,rep):
    DATAPREP['buyer'] =  DATAPREP['buyer_bill_to'] = bill_to
    DATAPREP['buyer_sold_to'] = sold_to
    DATAPREP['rep'] = rep
                                           
def test():
                                               
   tc_logs.header_name("GET Test Data From ODM.")
   gvar.dataprep['env'] = 'TRND'
   gvar.dataprep['auction'] = 'QIM5'
   gvar.load_environment_files()
   odm_datatype.load_test_data(odm_datatype.GENERAL_5M_DATA_SF)
   D =  Dealer().random_dealers()
   Log.Message(f" SELLER : {DATAPREP['seller']} ")  
   Log.Message(f" BUYER : {DATAPREP['buyer']} ") 
   Log.Message(f" REP : {DATAPREP['rep']} ")      
