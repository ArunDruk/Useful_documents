﻿from ebiz import *
import web_utils
import form_utils
import dbhelper
import file_system_utils


class tc198730_is_us_project_costing_webadi_taxline_reclass(Ebiz):

 op_log_path ="C:\\TC_Logs"

 def login(self):
   self.login_user='mfallwell'
   super().login()
 
 def goto_url(self,url):
   super().goto_url(self.testConfig['ebiz']['oci_is_url'])
   
 def action(self,book):
   web_utils.log_checkpoint("Login to Oracle Applications Successful",500,self.page) 
   web_utils.log_checkpoint("Currency Selected: "+ProjectSuite.Variables.currency,500,self.page) 
   if ProjectSuite.Variables.currency =="USD": 
    app = book.Sheets.item["JournalWebAdi_USD"]
   elif ProjectSuite.Variables.currency=="CAD":
    app = book.Sheets.item["JournalWebAdi_CAD"]
    
# Navigation to Oracle Home Page

   web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='menuContent']//div[contains(text(),'PC User')]") 
   self.wait_until_page_loaded()
   self.page.NativeWebObject.Find("contentText","Manheim WebAdi","A").Click()
   web_utils.log_checkpoint("Click 'Manheim WebADI' - Successful",500,self.page)
   delay(2000)
   self.page.NativeWebObject.Find("contentText","Non Adopters Cost","A").Click()
   web_utils.log_checkpoint("Click 'Non Adopters Cost' - Successful",500,self.page)
   self.wait_until_page_loaded()

#Navigating to CAI ALL WEBADI USER & Launching WebADI template

   if ProjectSuite.Variables.currency=="USD":
     self.page.Find("idStr","LayoutList",30).ClickItem("Manheim Functional Actuals")
     web_utils.log_checkpoint("Selecting WebADI template 'Manheim Functional Actuals' - Successful",500,self.page)  
   elif ProjectSuite.Variables.currency=="CAD":
     self.page.Find("idStr","LayoutList",30).ClickItem("Manheim Foreign Actuals")
     web_utils.log_checkpoint("Selecting WebADI template 'Manheim Foreign Actuals' - Successful",500,self.page)   
   Delay(3000)
   self.page.Find("idStr","CreateDocumentSubmitButton",30).Click()
   Delay(20000)   
   Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Notification Bar", "", 1).UIAObject("Notification").UIAObject("Open").Click()         
   xl_window=Sys.Process("EXCEL", 2).Window("XLMAIN", "General Ledger - Journals*", 1).Window("XLDESK", "", 1).Window("EXCEL7", "General Ledger*", 1)
   Delay(10000)
   if ProjectSuite.Variables.currency=="USD":
    self.usd_template_values(xl_window,app)
   elif ProjectSuite.Variables.currency=="CAD":
    self.cad_template_values(xl_window,app)
   Log.Enabled=True
   wnd = Sys.Desktop.ActiveWindow()
   Log.Picture(wnd, "WebADI has been launched and Ledger,Category,Source,Currency,Accounting Date,Accounting Information,Amounts have been entered in WebADI successfully", wnd.FullName)                  
   Log.Enabled=False  
   excel_obj=Sys.Process("EXCEL", 2).Window("XLMAIN", "General Ledger - Journals*", 1).Window("EXCEL2", "", 2).Window("MsoCommandBar", "Ribbon", 1).Window("MsoWorkPane", "Ribbon", 1).Window("NUIPane", "", 1).Window("NetUIHWND", "", 1)
   Delay(1000)
   OCR.Recognize(excel_obj).BlockByText("Oracle").Click()
   Delay(1000)
   OCR.Recognize(excel_obj).BlockByText("Upload").Click()
   Delay(4000) 

   
#Uploading the Journal

   upload_wnd=Sys.Process("EXCEL",2).WaitWindow("ThunderDFrame", "Journals Upload", 1,20000)
   if upload_wnd.Exists:
       Sys.Process("EXCEL",2).Window("ThunderDFrame", "Journals Upload", 1).Find("contentText","Import With Validation",40).Click()
       Sys.Process("EXCEL",2).Window("ThunderDFrame", "Journals Upload", 1).Find("ObjectLabel","Upload",40).Click()
       Delay(23000)
       if upload_wnd.Find("ObjectIdentifier","errorl_gif",40).Exists:
         self.log_message_oracle_excel_popup(upload_wnd,"Journal Upload Failed!!")
         Log.Error("Journal WebADI Upload Failed.") 
         Runner.Stop()                 
       else:
         Log.Enabled=True
         wnd = Sys.Desktop.ActiveWindow()
         Log.Picture(wnd, "Journal WebADI Upload Passed",wnd.FullName)
         Log.Enabled=False
         
   conf_msg=upload_wnd.Find("idStr","BneAsyncUploadPageConfirmation",40).contentText 
   self.log_message_oracle_excel_popup(upload_wnd,"Confirmation Message:- "+aqConvert.VarToStr(conf_msg))
   Delay(4000)            
   upload_wnd.Find("ObjectLabel","Close",20).Click() 
   req_id=conf_msg.split("Request ID",4)[1][1:10]
   app.Cells.Item[2,14] =VarToStr(req_id)
   Delay(4000) 
   xl_window.Keys("~[F4]")
   Delay(7000)
   xl_window.Keys("~n")
   self.page.EvaluateXPath("//img[@title='Home']")[0].Click()
   self.page.wait_until_page_loaded()
   Delay(5000)  
   
#Navigating to CAI ALL GL JOURNAL PROCESSING & Checking Web ADI - Journal Import (Journal Import) process
   
   self.page.NativeWebObject.Find("contentText","Enter","A").Click()
   web_utils.log_checkpoint("Click 'Enter' - Successful",500,self.page)
   web_utils.validate_security_box()
   Delay(10000)
   jFrame=self.initializeJFrame()
   Delay(15000)
   form_utils.click_ok_btn(jFrame) 
   Delay(5000)
   jFrame.Keys("[F4]")
   Delay(3000)
   form_utils.save_output_singlereq(self,jFrame,self.op_log_path,"Web ADI - Journal Import (Journal Import)",req_id)
   jFrame.Click()
   Delay(3000)
   jFrame.Keys("[F4]")
   Delay(3000)
   
#Review Imported Journals and Send for Approval
   jFrame.Keys("[F4]")
   Delay(3000)
   jFrame.Keys("~o")
   Delay(3000)
   self.page.NativeWebObject.Find("contentText","Enter","A").Click()
   web_utils.validate_security_box()
   jFrame=self.initializeJFrame()
   Delay(10000)
   form_utils.click_ok_btn(jFrame) 
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Find Journals","ExtendedFrame"]
   Find_Journals_Frame=jFrame.FindChildEx(prop,val,60,True,40000)
   web_utils.log_checkpoint("Navigation Successful from navigator: Journals > Enter",500,jFrame)
   Delay(3000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["BatchList of Values","VTextField"]
   Find_Journals_Frame.FindChild(prop,val,60).Click()
   Find_Journals_Frame.FindChild(prop,val,60).Keys("%"+req_id+"%")
   Delay(3000)
   web_utils.log_checkpoint("Enter Journal Import RequestID: "+req_id+" in Find Journals Screen and Click Find Next",500,jFrame)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Find alt i","Button"] 
   fnd_button=Find_Journals_Frame.FindChild(prop,val,60)
   fnd_button.Find("AWTComponentAccessibleName","Find alt i",10).Click()
   Delay(5000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Enter Journals (MAN GLB ALL)*","ExtendedFrame"]
   Enter_Journals_Frame=jFrame.FindChildEx(prop,val,60,True,40000)
   web_utils.log_checkpoint("Click Review on Enter Journals Form",500,jFrame)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Review Journal alt u","Button"]
   Enter_Journals_Frame.FindChild(prop,val,60).Click()
   Delay(3000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Journals (MAN GLB ALL)*","ExtendedFrame"]
   Journals_Frame=jFrame.FindChildEx(prop,val,60,True,40000)
   web_utils.log_checkpoint("Review Journal Information",500,jFrame)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Approve alt A","Button"]
   web_utils.log_checkpoint("Click Approve Button on Journals Form",500,jFrame)
   Journals_Frame.FindChild(prop,val,60).Click()
   Delay(3000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Note Your journal batch*","ChoiceBox"]
   Note_Form=jFrame.FindChildEx(prop,val,60,True,40000)
   web_utils.log_checkpoint("Your journal batch was forwarded to an approver.",500,jFrame)
   Delay(3000)
   Note_Form.Find("AWTComponentAccessibleName","OK ALT O").Click()  
   Delay(2000)
   dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
   user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
   pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
   if self.testConfig['ebiz']['env'] != "preprod":
    dbhelper.verify_cai_journal_status(dsn,user_id,pwd,"%"+VarTostr(req_id))
   jFrame.Keys("[F4]")
   Delay(4000)
   jFrame.Keys("[F4]")
   Delay(2000)
   jFrame.Keys("~o")
   Delay(2000)
   self.close_forms(jFrame)


   
#Entering values in WebADI template for US currency

 def usd_template_values(self,xl_window,app):  
   rowno=2
   row_no=22
   xl_window.Click()
   Delay(2000)
   xl_window.keys("^g")
   Delay(2000)
   goTo_wnd=Sys.Process("EXCEL", 2).Window("bosa_sdm_XL9", "Go To", 1).Window("EDTBX", "", 1)
   goTo_wnd.Click()
   goTo_wnd.Keys("H9")   
   Delay(1000)
   goTo_wnd.keys("[Enter]")
   Delay(1000)
   xl_window.Keys(app.Cells.Item[rowno,12])
   Delay(1000)
   xl_window.Keys("[Tab]")
   Delay(1000)
   xl_window.Keys("[Tab]")
   Delay(1000)
   xl_window.Keys(aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d-%b-%Y"))
   Delay(1000)
   xl_window.Click()
   xl_window.keys("^g")
   Delay(2000)
   goTo_wnd=Sys.Process("EXCEL", 2).Window("bosa_sdm_XL9", "Go To", 1).Window("EDTBX", "", 1)
   goTo_wnd.Click()
   goTo_wnd.Keys("[BS]")
   goTo_wnd.Keys("[BS]")
   goTo_wnd.Keys("[BS]")
   Delay(1000)
   goTo_wnd.Keys("C18")   
   Delay(1000)
   goTo_wnd.keys("[Enter]")
   Delay(1000)
   while rowno<row_no:
    xl_window.Keys(app.Cells.Item[rowno,1])
    xl_window.Keys("[Tab]")
    xl_window.Keys(app.Cells.Item[rowno,2])
    xl_window.Keys("[Tab]")
    xl_window.Keys(app.Cells.Item[rowno,3])
    xl_window.Keys("[Tab]")
    xl_window.Keys(app.Cells.Item[rowno,4])
    xl_window.Keys("[Tab]")
    xl_window.Keys(app.Cells.Item[rowno,5])
    xl_window.Keys("[Tab]")
    xl_window.Keys(app.Cells.Item[rowno,6])
    xl_window.Keys("[Tab]")
    xl_window.Keys(app.Cells.Item[rowno,7])
    xl_window.Keys("[Tab]")
    xl_window.Keys(app.Cells.Item[rowno,9])
    xl_window.Keys("[Tab]")
    xl_window.Keys(app.Cells.Item[rowno,10])
    xl_window.Keys("[Tab]")
    xl_window.Keys("Test Line Description_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%M%S"))
    xl_window.Keys("[Tab]")
    xl_window.Keys("[Tab]")
    xl_window.Keys("[Tab]")
    rowno=rowno+1

#Entering values in WebADI template for CAD currency

 def cad_template_values(self,xl_window,app):
   rowno=2
   row_no=22
   xl_window.Click()
   Delay(2000)
   xl_window.keys("^g")
   Delay(2000)
   goTo_wnd=Sys.Process("EXCEL", 2).Window("bosa_sdm_XL9", "Go To", 1).Window("EDTBX", "", 1)
   goTo_wnd.Click()
   goTo_wnd.Keys("[BS]")
   goTo_wnd.Keys("[BS]")
   goTo_wnd.Keys("[BS]")
   Delay(1000)
   goTo_wnd.Keys("H12")   
   Delay(1000)
   goTo_wnd.keys("[Enter]")
   Delay(1000)
   xl_window.Keys("[BS]")
   xl_window.Keys("[BS]")
   xl_window.Keys("[BS]")
   xl_window.Keys(app.Cells.Item[rowno,11])
   xl_window.Keys("[Tab]")
   xl_window.Keys(aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d-%b-%Y"))
   xl_window.Keys("[Tab]")
   xl_window.Keys("[Tab]")
   xl_window.Keys("[Tab]")
   xl_window.Keys(app.Cells.Item[rowno,8])
   xl_window.Click()
   xl_window.keys("^g")
   Delay(2000)
   goTo_wnd=Sys.Process("EXCEL", 2).Window("bosa_sdm_XL9", "Go To", 1).Window("EDTBX", "", 1)
   goTo_wnd.Click()
   goTo_wnd.Keys("[BS]")
   goTo_wnd.Keys("[BS]")
   goTo_wnd.Keys("[BS]")
   Delay(1000)
   goTo_wnd.Keys("C22")   
   Delay(1000)
   goTo_wnd.keys("[Enter]")
   Delay(1000)
   while rowno<row_no:
    xl_window.Keys(app.Cells.Item[rowno,1])
    xl_window.Keys("[Tab]")
    xl_window.Keys(app.Cells.Item[rowno,2])
    xl_window.Keys("[Tab]")
    xl_window.Keys(app.Cells.Item[rowno,3])
    xl_window.Keys("[Tab]")
    xl_window.Keys(app.Cells.Item[rowno,4])
    xl_window.Keys("[Tab]")
    xl_window.Keys(app.Cells.Item[rowno,5])
    xl_window.Keys("[Tab]")
    xl_window.Keys(app.Cells.Item[rowno,6])
    xl_window.Keys("[Tab]")
    xl_window.Keys(app.Cells.Item[rowno,7])
    xl_window.Keys("[Tab]")
    xl_window.Keys(app.Cells.Item[rowno,9])
    xl_window.Keys("[Tab]")
    xl_window.Keys(app.Cells.Item[rowno,10])
    xl_window.Keys("[Tab]")
    xl_window.Keys("Test Line Description_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%M%S"))
    xl_window.Keys("[Tab]")
    xl_window.Keys("[Tab]")
    xl_window.Keys("[Tab]")
    rowno=rowno+1





