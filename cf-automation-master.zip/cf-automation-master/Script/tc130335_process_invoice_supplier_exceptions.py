﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils
import web_utils


class tc130335_process_invoice_supplier_exceptions(Ebiz):
 global rowno
 rowno = 2

 def login(self):
    self.login_user="mkumar"
    super().login()
 
 op_log_path="C:\\TC_Logs"
 
 def action(self,book): 
    app = book.Sheets.item["Invoice"]
    app1 = book.Sheets.item["Requisition"]
    web_utils.log_checkpoint("Logged in to Oracle Applications Home Page Successfully",500,self.page)
    self.wait_until_page_loaded()  
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" AP INVOICE PROCESSING')]") 
    Delay(1000)  
    self.wait_until_page_loaded()           
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Invoices')]")
    Delay(1000)
    self.wait_until_page_loaded() 
    Delay(1000) 
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Entry')]")
    Delay(1000) 
    self.wait_until_page_loaded()
    self.page.EvaluateXPath("//div[text()='Invoices']")[1].Click()
    delay(10000) 
    jFrame = self.initializeJFrame()
    Delay(10000)
    form_utils.click_ok_btn(jFrame)
    p_names = ("JavaClassName","AWTComponentAccessibleName")
    p_values = ("ExtendedFrame","Invoice Workbench (CAI "+self.oper_unit+" AP INVOICE PROCESSING)")
    inv_form=jFrame.FindChildEx(p_names,p_values,60,True,120000)
    Delay(2000)
    jFrame.Keys("~v")
    delay(1000)
    jFrame.Keys("f")
    delay(1000)
    
 #Finding Invoice in the invoice workbench
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Invoices","ExtendedFrame"]
    par_form=jFrame.FindChildEx(prop,val,60,True,60000)
    par_form.Find("AWTComponentAccessibleName","Invoice: Number",30).Click()
    Delay(4000)
    par_form.Find("AWTComponentAccessibleName","Invoice: Number",30).SetText(app.Cells.Item[rowno,13])
    jFrame.Keys("[Tab]")
    delay(3000)
    val = ["Find alt i","Button"] 
    par_form.FindChild(prop,val,60).Click()
    Delay(4000)    
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Type Required",8]
    inv_type=jFrame.FindChildEx(prop,val,60,True,9000000)
    Log.Enabled=True
    aqObject.CheckProperty(inv_type,"wText",cmpIn,"Standard")
    Log.Enabled=False
    web_utils.log_checkpoint("Find Invoice Successful: "+aqConvert.VarToStr(app.Cells.Item[rowno,13]),500,jFrame) 
    Delay(4000)   
    prop=["AWTComponentAccessibleName","AWTComponentIndex","JavaClassName"]
    val=["Holds",8,"VTextField"]
    hold=jFrame.FindChildEx(prop,val,60,True,9000000)
    Log.Enabled=True
    aqObject.CheckProperty(hold,"wText",cmpIn,"1")
    Log.Enabled=False
    Delay(2000)
    jFrame.Keys("~v")
    Delay(3000)
    jFrame.Keys("z")
    Delay(2000)
    web_utils.log_checkpoint("Selecting 'Start Excep Processing -US' form Zoom options",500,jFrame)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Zooms","FWindow"]
    zoom=jFrame.FindChildEx(prop,val,60,True,90000)
    Sys.HighlightObject(zoom)
    zoom.Find("AWTComponentAccessibleName","Find",30).Click()
    zoom.Find("AWTComponentAccessibleName","Find",30).Keys("^a[BS]")
    Delay(3000)
    zoom.Find("AWTComponentAccessibleName","Find",30).Keys("3.Start Excep Processing - US")
    Delay(3000)
    jFrame.Keys("~o")
    Delay(15000)
    
    
 # Logging into Oracle:Webcenter Imaging to view the invoice image
 
      #********** IDCS Login added by Lakshmi Seelam************
    self.wait_until_page_loaded()
    Delay(5000)
    
    self.page.Find("idStr","idcs-signin-basic-signin-form-username",30).Click()
    self.page.Find("idStr","idcs-signin-basic-signin-form-username",30).Click()
    Sys.Keys(Sys.Keys(self.testConfig['wccodingV12']['userid']))
    Sys.Keys("[Tab]")
    Delay(2000)
    self.page.Find("idStr","idcs-signin-basic-signin-form-password|input",30).Click()
    Delay(2000)
    Sys.Keys((self.testConfig['wccodingV12']['password']))
    Sys.Keys("[Tab]"+"[Enter]")
    Delay(3000)
    #self.page.Find("contentText","Sign In",30).Click()
    
    self.wait_until_page_loaded()
    Delay(2000)
    #********** IDCS Login added by Lakshmi Seelam************
#    imaging_web_page = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/imaging/faces/Authentication/Login.jspx").Panel("doc").Panel("ps_l1").Panel("c").Panel("pslForm").Panel("c").Panel("pglForm")
#    web_utils.log_checkpoint("Log in to 'Oracle:Webcenter Imaging next to view the image",500,imaging_web_page)
#    self.wait_until_page_loaded()
#    Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/imaging/faces/Authentication/Login.jspx").Panel("doc").Panel("ps_l1").Panel("c").Panel("pslForm").Panel("c").Panel("pglForm").Panel(0).Panel("formBox").Panel(0).Panel("content").Panel("pflForm").Table(0).Cell(0, 0).Table(0).Cell(1, 0).Table("usernameLabel").Cell(1, 0).Textbox("username").Click()
#    Delay(2000)
#    Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/imaging/faces/Authentication/Login.jspx").Panel("doc").Panel("ps_l1").Panel("c").Panel("pslForm").Panel("c").Panel("pglForm").Panel(0).Panel("formBox").Panel(0).Panel("content").Panel("pflForm").Table(0).Cell(0, 0).Table(0).Cell(1, 0).Table("usernameLabel").Cell(1, 0).Textbox("username").SetText('mkumar')
#    web_utils.log_checkpoint("On 'Oracle:Webcenter Imaging page: 'UserID' entered successfully",500,imaging_web_page)
#    Delay(2000)
#    Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/imaging/faces/Authentication/Login.jspx").Panel("doc").Panel("ps_l1").Panel("c").Panel("pslForm").Panel("c").Panel("pglForm").Panel(0).Panel("formBox").Panel(0).Panel("content").Panel("pflForm").Table(0).Cell(0, 0).Table(0).Cell(2, 0).Table("passwordLabel").Cell(1, 0).PasswordBox("password").Click()
#    Delay(2000)
#    Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/imaging/faces/Authentication/Login.jspx").Panel("doc").Panel("ps_l1").Panel("c").Panel("pslForm").Panel("c").Panel("pglForm").Panel(0).Panel("formBox").Panel(0).Panel("content").Panel("pflForm").Table(0).Cell(0, 0).Table(0).Cell(2, 0).Table("passwordLabel").Cell(1, 0).PasswordBox("password").SetText('oracle123')
#    web_utils.log_checkpoint("On 'Oracle:Webcenter Imaging page: 'Password' entered successfully",500,imaging_web_page)
#    Delay(2000)
#    Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/imaging/faces/Authentication/Login.jspx").Panel("doc").Panel("ps_l1").Panel("c").Panel("pslForm").Panel("c").Panel("pglForm").Panel(0).Panel("formBox").Panel(0).Panel("content").Panel("pflForm").Table(0).Cell(0, 0).Table(0).Cell(4, 0).Table("submitButton").Cell(1, 0).SubmitButton("btnSubmit").Click()
#    Delay(2000)
#    self.wait_until_page_loaded()
    
    cai_excep_processing = Sys.Browser("iexplore").Page("https://core*.epfinnp.coxautoinc.com/imaging/faces/AxfFacade*")
    welcome_msg=cai_excep_processing.FindChildEx("contentText","CAIExceptionsProcessing*",30,True,40000) 
    count =  0  
    while not welcome_msg.Exists:
      Delay(2000)
      welcome_msg=cai_excep_processing.Find("contentText","CAIExceptionsProcessing*",30) 
      count = count + 1 
      if count == 10:
       self.log_error_message("Unable to Login to CAIExceptionsProcessing")    
    web_utils.log_checkpoint("Logged in to CAIExceptionsProcessing* Queue Successfully",500,cai_excep_processing) 
  
    delay(2000)
    self.page.wait_until_loaded()
#   profile = Sys.Browser("iexplore").Page("https://core*.epfinnp.coxautoinc.com/imaging/faces/AxfFacade.jsp?*").Frame("contentFrame").Panel("doc1").Form("mnFrm").Panel(0).Panel("s").Panel(0).Panel("f").Panel(0).Panel("c").Panel("conTabs").Panel("tabb").Panel("tabbc").Panel("body").Panel(0).Panel(0).Panel(0).Panel("c").Panel("dhjdf").Panel("c").Panel("outTL").Panel("c").Panel(0).Panel("otrWpr").Panel("t").Panel("tbx").Panel(0).Table(0).Cell(0, 1).Panel(0).Panel(0).Panel("oc").Table(0).Cell(0, 1).Table("vPick").Cell(0, 1).Select("content")
    profile = Sys.Browser("iexplore").Page("https://core*.epfinnp.coxautoinc.com/imaging/faces/AxfFacade.jsp?*").Frame("contentFrame1").Panel("doc1").Form("mnFrm").Panel(0).Panel("s").Panel(0).Panel("f").Panel(0).Panel("c").Panel("conTabs").Panel("tabb").Panel("tabbc").Panel("body").Panel(0).Panel(0).Panel(0).Panel("c").Panel("dhjdf").Panel("c").Panel("outTL").Panel("c").Panel(0).Panel("otrWpr").Panel("t").Panel("tbx").Panel(0).Table(0).Cell(0, 1).Panel(0).Panel(0).Panel("oc").Table(0).Cell(0, 1).Table("vPick").Cell(0, 1).Select("content")
    profile.Click()
    profile.ClickItem("CAI-USExceptions")
    self.page.wait_until_loaded()
    delay(6000)
    web_utils.log_checkpoint("Selected 'CAI-USExceptions' from the Profile dropdown",500,cai_excep_processing)
  
    view_task = cai_excep_processing.FindChild("contentText","View Task",40)
    if view_task.Exists:
      Sys.HighlightObject(view_task)
      web_utils.log_checkpoint("Tasks exists in 'CAIExceptionsProcessing' Queue",500,cai_excep_processing)
    else:
      self.log_error_message("No Tasks exists in 'CAIExceptionsProcessing'")
  
# Searching the tasks
    search_task = cai_excep_processing.FindChild("idStr","axfTpl:pt_rgn0:0:pc1:it1::content",40)
    Sys.HighlightObject(search_task)
    search_task.Click()
    delay(4000)
    search_task.Keys(app.Cells.Item[rowno,13])
    delay(4000)
    search_button = cai_excep_processing.FindChild("idStr","axfTpl:pt_rgn0:0:pc1:task_search::icon",40)
    search_button.Click()
    delay(8000)
    view_task_link = cai_excep_processing.FindChild("idStr","axfTpl:pt_rgn0:0:pc1:t1:*:vLink::text",40)
    if view_task_link.Exists:
      Sys.HighlightObject(view_task_link)
      web_utils.log_checkpoint("Task for "+aqConvert.VarToStr(app.Cells.Item[rowno,13])+" exists in 'CAI-SupplierMaintenance' Queue",500,cai_excep_processing)
    else:
      self.log_error_message("No Tasks exists for " +aqConvert.VarToStr(app.Cells.Item[rowno,13]))


#Working on Tasks
    web_utils.log_checkpoint("Click on 'View Task' next",500,cai_excep_processing)
    view_task_link.Click()
    delay(35000)
    self.page.wait_until_loaded()
  
# Viewing the image
    count = 0
#    while not Sys.Browser("iexplore").Page("https://core*.epfinnp.coxautoinc.com/imaging/faces/AxfFacade*").Frame("contentFrame").Panel("doc1").Form("mnFrm").Panel(0).Panel("s").Panel(0).Panel("f").Panel(0).Panel("c").Panel("conTabs").Panel("tabb").Panel("tabbc").Panel("body").Panel(0).Panel(0).Panel(0).Panel("c").Panel(0).Panel("s").Panel(0).Panel("f").Panel("dhjdf").Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("c").Panel("panelSplitterTopAndBottom").Panel("f").Panel("panelSplitterTopLeftAndRight").Panel("s").Panel("boxWrap").Panel("c").Panel(0).Panel("panelStretchLayoutApplet").Panel(0).Panel(0).Panel("c").Object("oraImgVwr").AWTObject("PluginEmbeddedFrame", "").SwingObject("Viewer", "", 0).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("ImageView", "", 0).SwingObject("JViewport", "", 0).Exists:
    while not Sys.Browser("iexplore").Page("https://core*.epfinnp.coxautoinc.com/imaging/faces/AxfFacade*").Frame("contentFrame1").Panel("doc1").Form("mnFrm").Panel(0).Panel("s").Panel(0).Panel("f").Panel(0).Panel("c").Panel("conTabs").Panel("tabb").Panel("tabbc").Panel("body").Panel(0).Panel(0).Panel(0).Panel("c").Panel(0).Panel("s").Panel(0).Panel("f").Panel("dhjdf").Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("c").Panel("panelSplitterTopAndBottom").Panel("f").Panel("panelSplitterTopLeftAndRight").Panel("s").Panel("boxWrap").Panel("c").Panel(0).Panel("panelStretchLayoutApplet").Panel(0).Panel(0).Panel("c").Object("oraImgVwr").AWTObject("PluginEmbeddedFrame", "").SwingObject("Viewer", "", 0).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("ImageView", "", 0).SwingObject("JViewport", "", 0).Exists:
      delay(5000) 
      if count == 5:
        self.log_error_message("Unable to retrieve the Invoice Image")  
      count=count+1
#    image_view = Sys.Browser("iexplore").Page("https://core*.epfinnp.coxautoinc.com/imaging/faces/AxfFacade*").Frame("contentFrame").Panel("doc1").Form("mnFrm").Panel(0).Panel("s").Panel(0).Panel("f").Panel(0).Panel("c").Panel("conTabs").Panel("tabb").Panel("tabbc").Panel("body").Panel(0).Panel(0).Panel(0).Panel("c").Panel(0).Panel("s").Panel(0).Panel("f").Panel("dhjdf").Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("c").Panel("panelSplitterTopAndBottom").Panel("f").Panel("panelSplitterTopLeftAndRight").Panel("s").Panel("boxWrap").Panel("c").Panel(0).Panel("panelStretchLayoutApplet").Panel(0).Panel(0).Panel("c").Object("oraImgVwr").AWTObject("PluginEmbeddedFrame", "").SwingObject("Viewer", "", 0).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("ImageView", "", 0).SwingObject("JViewport", "", 0)
    image_view = Sys.Browser("iexplore").Page("https://core*.epfinnp.coxautoinc.com/imaging/faces/AxfFacade*").Frame("contentFrame1").Panel("doc1").Form("mnFrm").Panel(0).Panel("s").Panel(0).Panel("f").Panel(0).Panel("c").Panel("conTabs").Panel("tabb").Panel("tabbc").Panel("body").Panel(0).Panel(0).Panel(0).Panel("c").Panel(0).Panel("s").Panel(0).Panel("f").Panel("dhjdf").Panel("c").Panel(0).Panel("c").Panel(0).Panel(0).Panel("c").Panel("panelSplitterTopAndBottom").Panel("f").Panel("panelSplitterTopLeftAndRight").Panel("s").Panel("boxWrap").Panel("c").Panel(0).Panel("panelStretchLayoutApplet").Panel(0).Panel(0).Panel("c").Object("oraImgVwr").AWTObject("PluginEmbeddedFrame", "").SwingObject("Viewer", "", 0).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("ImageView", "", 0).SwingObject("JViewport", "", 0)
    Sys.HighlightObject(image_view)
    web_utils.log_checkpoint("Invoice Image exists for "+aqConvert.VarToStr(app.Cells.Item[rowno,13]),500,image_view)
    delay(8000)

# Entering Supplier Name and Supplier Site Information in the invoice workbench
    jFrame.Click()
    delay(4000)
    web_utils.log_checkpoint("Enter the valid 'Supplier' and 'Supplier Site' information on Invoice Workbench",500,jFrame)
    inv_form.Find("AWTComponentAccessibleName","Trading Partner RequiredList of Values",30).Click()
    delay(4000)
    inv_form.Find("AWTComponentAccessibleName","Trading Partner RequiredList of Values",30).Keys("^a[BS]")
    delay(2000)
    inv_form.Find("AWTComponentAccessibleName","Trading Partner RequiredList of Values",30).SetText(app1.Cells.Item[rowno,9])
    web_utils.log_checkpoint("Entered the 'Supplier': "+aqConvert.VarToStr(app1.Cells.Item[rowno,9]),500,jFrame)
    delay(4000)
    inv_form.Find("AWTComponentAccessibleName","Supplier Site Name RequiredList of Values",30).Click()
    delay(4000)
    inv_form.Find("AWTComponentAccessibleName","Supplier Site Name RequiredList of Values",30).Keys("^a[BS]")
    delay(2000)
    inv_form.Find("AWTComponentAccessibleName","Supplier Site Name RequiredList of Values",30).SetText(app1.Cells.Item[rowno,10])
    web_utils.log_checkpoint("Entered the 'Supplier Site': "+aqConvert.VarToStr(app1.Cells.Item[rowno,10]),500,jFrame)
    delay(4000)
    jFrame.Keys("^s")
    delay(4000)
    jFrame.Keys("~o")
    delay(4000)
    
# Completing the invoice in the exception queue
    image_view.Click()
    delay(3000)
    web_utils.log_checkpoint("Complete the Task next in 'CAIExceptionsProcessing' Queue next",500,cai_excep_processing)
    complete_link = cai_excep_processing.FindChild("contentText","Complete Invoice",40)
    complete_link.Click()
    delay(5000) 
    self.page.wait_until_loaded()
    if view_task_link.Exists:
       self.log_error_message("Tasks exists for "+aqConvert.VarToStr(app.Cells.Item[rowno,13]))
    else:
      web_utils.log_checkpoint("Task completed successfully for "+aqConvert.VarToStr(app.Cells.Item[rowno,13]),500,cai_excep_processing)
    cai_excep_processing.close()
    
# Requerying the invoice
    jFrame.Click()
    delay(4000)
    jFrame.Keys("~v")
    Delay(5000)
    jFrame.Keys("f")
    Delay(5000)
    web_utils.log_checkpoint("Requery the invoice "+aqConvert.VarToStr(app.Cells.Item[rowno,13])+" to validate holds next",500,jFrame)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Invoices","ExtendedFrame"]
    par_form=jFrame.FindChildEx(prop,val,60,True,60000)
    par_form.Find("AWTComponentAccessibleName","Invoice: Number",30).Click()
    Delay(4000)
    par_form.Find("AWTComponentAccessibleName","Invoice: Number",30).Keys("^a[BS]")
    Delay(2000)
    par_form.Find("AWTComponentAccessibleName","Invoice: Number",30).SetText(app.Cells.Item[rowno,13])
    jFrame.Keys("[Tab]")
    delay(3000)
    val = ["Find alt i","Button"] 
    par_form.FindChild(prop,val,60).Click()
    Delay(4000)    
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Type Required",8]
    inv_type=jFrame.FindChildEx(prop,val,60,True,9000000)
    Log.Enabled=True
    aqObject.CheckProperty(inv_type,"wText",cmpIn,"Standard")
    Log.Enabled=False
    web_utils.log_checkpoint("Find Invoice Successful: "+aqConvert.VarToStr(app.Cells.Item[rowno,13]),500,jFrame) 
    Delay(4000)   

# Checking for holds  
    prop=["AWTComponentAccessibleName","AWTComponentIndex","JavaClassName"]
    val=["Holds",8,"VTextField"]
    hold=jFrame.FindChildEx(prop,val,60,True,9000000)
    Log.Enabled=True
    aqObject.CheckProperty(hold,"wText",cmpIn,"0")
    Log.Enabled=False
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Invoice Workbench*","ExtendedFrame"]
    inv_wkbnch=jFrame.FindChildEx(prop,val,60,True,60000)
    inv_wkbnch.FindChild("AWTComponentName","FormsTabPanel*",60).ClickTab("3 Holds")
    Delay(3000)   
    web_utils.log_checkpoint("Invoice: "+aqConvert.VarToStr(app.Cells.Item[rowno,13])+" has no holds'",500,jFrame)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~o")

    
