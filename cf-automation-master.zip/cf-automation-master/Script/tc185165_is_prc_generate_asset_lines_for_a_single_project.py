﻿from dbhelper import *
from ebiz import *
import web_utils
import dbhelper
import file_system_utils

class tc185165_is_prc_generate_asset_lines_for_a_single_project(Ebiz):

 op_log_path ="C:\\TC_Logs"

 def login(self):
   self.login_user='pkjami'
   super().login()
 
 def goto_url(self,url):
  super().goto_url(self.testConfig['ebiz']['oci_is_url'])
   
 
 def action(self,book): 
   app = book.Sheets.item["Requisition"]
   rowno = 2
   web_utils.log_checkpoint("Logged in to Oracle Applications Home Page Successfully",500,self.page)
   self.wait_until_page_loaded()       
   self.page.EvaluateXPath("//table[@id='menuContent']//div[contains(text(),'PC User')]")[0].Click() 
   web_utils.log_checkpoint("Click 'PC User' - Successful",500,self.page) 
   self.page.Keys("[Down]")
   self.page.Keys("[Down]")
   self.page.Keys("[Down]")
   self.page.Keys("[Down]")
   self.wait_until_page_loaded()
   self.page.NativeWebObject.Find("contentText","Other","A").Click()
   web_utils.log_checkpoint("Click 'Other' - Successful",500,self.page) 
   self.page.Keys("[Down]")
   self.page.Keys("[Down]")
   self.page.NativeWebObject.Find("contentText","Requests","A").Click()
   web_utils.log_checkpoint("Click 'Requests' - Successful",500,self.page)
   self.page.Keys("[Down]")
   self.page.NativeWebObject.Find("contentText","Run","A").Click()
   web_utils.log_checkpoint("Click 'Run' - Successful",500,self.page)
   web_utils.validate_security_box()
   Delay(15000)
   jFrame=self.initializeJFrame()
   form_utils.click_ok_btn(jFrame)  
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Submit a New Request","ExtendedFrame"]
   submit_req_form=jFrame.FindChildEx(prop,val,30,True,60000)
   submit_req_form.FindChild("AWTComponentAccessibleName","OK alt O",10).Click()
   Delay(2000)

#US545181: Fix QA Automation: MAN STAGE - E2E_Scenario_24: Updated Program from "PRC: Generate Asset Lines for a Single Project"
# to "MAN: Generate Asset Lines for a Single Project"  
#Submit MAN: Generate Asset Lines for a Single Project Request 

   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Submit Request","ExtendedFrame"]
   submitrequest_form=jFrame.FindChildEx(prop,val,60,True,90000)
   self.verify_aqobject_chkproperty(submitrequest_form,"AWTComponentAccessibleName",cmpContains,"Submit Request")
#US545181: Updated
   submitrequest_form.Find("AWTComponentAccessibleName","Name RequiredList of Values",30).SetText("MAN: Generate Asset Lines for a Single Project")
   web_utils.log_checkpoint("Request Name: 'MAN: Generate Asset Lines for a Single Project' - populated Successfully",500,jFrame)

   jFrame.Keys("[Tab]")
   Delay(8000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Parameters","FlexWindow"]
   parameters_form=jFrame.FindChild(prop,val,60)
   Delay(1000) 
   parameters_form.Find("AWTComponentAccessibleName","Project Number REQUIRED List Values",30).Click()    
   jFrame.Find("AWTComponentAccessibleName","Project Number REQUIRED List Values",30).Keys(app.Cells.Item[rowno,11])
   delay(2000)
   currentDate = aqDateTime.Today()
   date_format = aqConvert.DateTimeToFormatStr(currentDate,"%d-%b-%Y")
   month_end_date = self.calc_month_end()
   month_end_format = aqConvert.DateTimeToFormatStr(month_end_date,"%d-%b-%Y")
   Delay(2000)
   jFrame.Keys("[Tab]")
   Delay(2000)
   jFrame.Find("AWTComponentAccessibleName","Date Placed In Service Through REQUIRED:*",30).Click()  
   Delay(4000)
   jFrame.Find("AWTComponentAccessibleName","Date Placed In Service Through REQUIRED:*",30).Keys(month_end_format)
   Delay(2000)
   jFrame.Keys("[Tab]")
   Delay(2000)
   jFrame.Find("AWTComponentAccessibleName","PA Through Date REQUIRED:*",30).Click()  
   Delay(4000)
   jFrame.Find("AWTComponentAccessibleName","PA Through Date REQUIRED:*",30).Keys(month_end_format)
   Delay(1000) 
   jFrame.Keys("[Tab]")
   web_utils.log_checkpoint("'MAN: Generate Asset Lines for a Single Project' program parameters entered successfully",500,jFrame)
   jFrame.keys("~o")
   Delay(2000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Submit alt m","Button"]
   submit_button=submitrequest_form.FindChild(prop,val,60)
   submit_button.Find("AWTComponentAccessibleName","Submit alt m").Click()
   Delay(3000)
   
# Capturing RequestID

   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Decision","LWLabel"]
   parameters_form=jFrame.FindChildEx(prop,val,60,True,60000)
   Delay(2000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Decision Request Submitted*","ChoiceBox"]
   decision_form=jFrame.FindChildEx(prop,val,60,True,40000)  
   RequestID = ''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit())
#US545181: Updated
   web_utils.log_checkpoint("'MAN: Generate Asset Lines for a Single Project' is submitted and Request ID is " + aqConvert.VarToStr(RequestID),500,jFrame)

   Delay(2000)
   Rid =aqConvert.VarToStr(RequestID)
   jFrame.Keys("~n")
   Delay(9900)  
   dsn = self.testConfig['man_oracle_db']['dsn']
   user_id = self.testConfig['man_oracle_db']['userid']
   pwd = self.testConfig['man_oracle_db']['pwd']
   dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,RequestID)
      
#US545181: Updated        
#Capturing Outputs for MAN: Generate Asset Lines for a Single Project

   jFrame.Keys("~v")
   Delay(4000)
   jFrame.Keys("r")
   Delay(4000)
   jFrame.Keys("~s")
   Delay(3000)
   prop_names=["JavaClassName","AWTComponentAccessibleName"]
   prop_values=["VTextField","Request ID"]
   temp=jFrame.FindAll(prop_names,prop_values,60)
   jFrame.Find("AWTComponentName",temp[10].AWTComponentName,60).Click()
   jFrame.Find("AWTComponentName",temp[10].AWTComponentName,60).SetText(RequestID)
   Delay(2000)
   self.log_message_oracle_form(jFrame ,"Query for Submitted Request ID:" +RequestID)
   jFrame.Keys("~i")
   Delay(2000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Requests","ExtendedFrame"]
   req_form=jFrame.FindChildEx(prop,val,30,True,60000)
   prop=["AWTComponentAccessibleName","AWTComponentIndex"]
   val=["Phase",40]
   phase=req_form.Find(prop,val,10).wText 
   while phase != 'Completed':
     Delay(1000)
     req_form.keys("~r")
     Delay(4000)
#US545181: Updated
   web_utils.log_checkpoint("'MAN: Generate Asset Lines for a Single Project' program phase Completed",500,jFrame)

   jFrame.Keys("~k")
   file_type = 'Log'
   self.save_log(file_type)
   delay(4000)
   jFrame.Keys("~p")
   file_type = 'Output'
   self.save_log(file_type)
   Delay(6000)
   jFrame.Keys("[F4]")
   Delay(4000)
#   jFrame.Keys("[F4]")
#   Delay(2000)
#   jFrame.Keys("~o")
#   Delay(2000)
   wscript=Sys.OleObject["WScript.Shell"]
   wscript.Run("taskkill.exe /F /IM jp2launcher.exe /T")
   self.page.wait_until_page_loaded()
   
#Finding capital projects
   self.page.Keys("[Up][Up]")
   self.page.NativeWebObject.Find("contentText","Capitalization","A").Click()
   web_utils.log_checkpoint("Click 'CAPITALIZATION' - Successful",500,self.page)

#US545181: Fix QA Automation: MAN STAGE - E2E_Scenario_24: Added Steps to Assign Asset Lines to the Asset
#This is because 'MAN: Generate Asset Lines for a Single Project' program created Asset Lines which are UNASSIGNED
#02/16/2021: START: Adding Steps to Assign Asset Lines to the Asset
   Delay(2000)
   self.wait_until_page_loaded() 
   self.page.NativeWebObject.Find("contentText","Capital Projects","A").Click()
   web_utils.log_checkpoint("Click 'Capital Projects' - Successful",500,self.page)  
   Delay(2000)
   web_utils.validate_security_box()
   Delay(15000)
   jFrame=self.initializeJFrame()
   form_utils.click_ok_btn(jFrame)
   Delay(4000)

# Navigating to Find Capital Projects form

   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Find Capital Projects","ExtendedFrame"]
   findcapitalprojects_form=jFrame.FindChildEx(prop,val,60,True,90000)
   self.verify_aqobject_chkproperty(findcapitalprojects_form,"AWTComponentAccessibleName",cmpContains,"Find Capital Projects")
   findcapitalprojects_form.Find("AWTComponentAccessibleName","Project: NumberList of Values",10).SetText(app.Cells.item[rowno,11])
   web_utils.log_checkpoint("Project Number Entered in Capital Projects screen is : "+ VarToStr(app.Cells.item[rowno,11]),500,jFrame)  
   findcapitalprojects_form.Keys("[Tab]")
   findcapitalprojects_form.Keys("[Tab]")
   Delay(3000)
   findcapitalprojects_form.Find("AWTComponentAccessibleName","Find alt i",10).Click()
   Delay(3000)
 
   # Navigating to Capital Projects form
   self.page.Keys("[Up]")
   self.verify_aqobject_chkproperty(findcapitalprojects_form,"AWTComponentAccessibleName",cmpContains,"Capital Projects")
   web_utils.log_checkpoint("'Capital Projects Details' form launched successfully",500,jFrame)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Capital Projects (Manheim Corporate Services)","ExtendedFrame"]
   capitalprojects_form=jFrame.FindChildEx(prop,val,60,True,90000)

   # Navigating to Assets form
   capitalprojects_form.Find("AWTComponentAccessibleName","Assets alt A",10).Click()  
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=[" Assets*","ExtendedFrame"]
   asset_form=jFrame.FindChildEx(prop,val,60,True,40000)
   Delay(2000) 
   while not asset_form.Exists: 
     Delay(2000)
     asset_form=jFrame.FindChild(prop,val,60)
   web_utils.log_checkpoint("'Assets' form launched successfully",500,jFrame)   
   Delay(2000) 

   #Capture Asset Name
   pi_names = ("JavaClassName","AWTComponentAccessibleName","AWTComponentIndex")
   p_values = ("VTextField","Capitalization Details tab page Asset Name Required",10)
   asset_name_field=asset_form.Find(pi_names,p_values,20)
   asset_name_val=VarToStr(asset_name_field.GetText())
   web_utils.log_checkpoint("Asset Name captured: "+VarToStr(asset_name_val),500,jFrame)
   Delay(2000)
   self.close_forms(jFrame)

# Navigate to Asset Lines Form
   Delay(2000)
   self.wait_until_page_loaded() 
   Delay(2000)
   self.page.NativeWebObject.Find("contentText","Capital Projects","A").Click()
   web_utils.log_checkpoint("Click 'Capital Projects' - Successful",500,self.page)  
   Delay(2000)
   web_utils.validate_security_box()
   Delay(15000)
   jFrame=self.initializeJFrame()
   form_utils.click_ok_btn(jFrame)
   Delay(4000)

# Navigating to Find Capital Projects form

   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Find Capital Projects","ExtendedFrame"]
   findcapitalprojects_form=jFrame.FindChildEx(prop,val,60,True,90000)
   self.verify_aqobject_chkproperty(findcapitalprojects_form,"AWTComponentAccessibleName",cmpContains,"Find Capital Projects")
   findcapitalprojects_form.Find("AWTComponentAccessibleName","Project: NumberList of Values",10).SetText(app.Cells.item[rowno,11])
   web_utils.log_checkpoint("Project Number Entered in Capital Projects screen is : "+ VarToStr(app.Cells.item[rowno,11]),500,jFrame)  
   findcapitalprojects_form.Keys("[Tab]")
   findcapitalprojects_form.Keys("[Tab]")
   Delay(3000)
   findcapitalprojects_form.Find("AWTComponentAccessibleName","Find alt i",10).Click()
   Delay(3000)

   # Navigating to Capital Projects form
   self.page.Keys("[Up]")
   self.verify_aqobject_chkproperty(findcapitalprojects_form,"AWTComponentAccessibleName",cmpContains,"Capital Projects")
   web_utils.log_checkpoint("'Capital Projects Details' form launched successfully",500,jFrame)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Capital Projects (Manheim Corporate Services)","ExtendedFrame"]
   capitalprojects_form=jFrame.FindChildEx(prop,val,60,True,90000)
   
   
   # Navigating to Asset Lines form
   capitalprojects_form.Find("AWTComponentAccessibleName","Lines alt i",10).Click()  
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Asset Lines*","ExtendedFrame"]
   asset_lines=jFrame.FindChildEx(prop,val,30,True,40000)
   Delay(2000) 
   while not asset_lines.Exists: 
     Delay(2000)
     asset_linesrame.FindChild(prop,val,60)
   web_utils.log_checkpoint("'Asset Lines' form launched successfully",500,jFrame)   
   Delay(2000)
   
   #Update Asset Name on Asset Lines
   for i in range(8,11):
     pi_names = ("JavaClassName","AWTComponentAccessibleName","AWTComponentIndex")
     p_values = ("VTextField","Asset Name RequiredList of Values",i)
     asset_name=asset_lines.Find(pi_names,p_values,20)
     Delay(2000)
     asset_name.Click()
     Delay(2000)
     asset_name.Keys("[End]")
     asset_name.Keys("[BS][BS][BS][BS][BS][BS][BS][BS][BS][BS][BS][BS][BS][BS][BS][BS][BS]")
     Delay(5000)
     asset_name.SetText(VarToStr(asset_name_val))
     Delay(5000)
     asset_name.Click()
     Delay(5000)
     asset_name.Keys("[Tab]")
     Delay(5000)
     jFrame.Keys("^s")
     Delay(5000)
     web_utils.log_checkpoint("Asset Line Assigned successfully",500,jFrame)   
     Delay(2000)
     i+=1

   web_utils.log_checkpoint("All Asset Lines Assigned successfully",500,jFrame)
   Delay(2000)
   self.close_forms(jFrame)
   Delay(10000)
 
#Finding capital projects
   self.page.Keys("[Up][Up]")
#   self.page.NativeWebObject.Find("contentText","Capitalization","A").Click()
#   web_utils.log_checkpoint("Click 'CAPITALIZATION' - Successful",500,self.page)
#02/16/2021: END: Adding Steps to Assign Asset Lines to the Asset
#US545181: Fix QA Automation: MAN STAGE - E2E_Scenario_24: END of Added Steps to Assign Asset Lines to the Asset

#   self.page.Keys("[Down]") 
   Delay(2000)
   self.wait_until_page_loaded() 
   self.page.NativeWebObject.Find("contentText","Capital Projects","A").Click()
   web_utils.log_checkpoint("Click 'Capital Projects' - Successful",500,self.page)  
   Delay(2000)
   web_utils.validate_security_box()
   Delay(15000)
   jFrame=self.initializeJFrame()
   form_utils.click_ok_btn(jFrame)
   Delay(4000)

# Navigating to Find Capital Projects form

   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Find Capital Projects","ExtendedFrame"]
   findcapitalprojects_form=jFrame.FindChildEx(prop,val,60,True,90000)
   self.verify_aqobject_chkproperty(findcapitalprojects_form,"AWTComponentAccessibleName",cmpContains,"Find Capital Projects")
   findcapitalprojects_form.Find("AWTComponentAccessibleName","Project: NumberList of Values",10).SetText(app.Cells.item[rowno,11])
   web_utils.log_checkpoint("Project Number Entered in Capital Projects screen is : "+ VarToStr(app.Cells.item[rowno,11]),500,jFrame)  
   findcapitalprojects_form.Keys("[Tab]")
   findcapitalprojects_form.Keys("[Tab]")
   Delay(3000)
   findcapitalprojects_form.Find("AWTComponentAccessibleName","Find alt i",10).Click()
   Delay(3000)
     
     
# Navigating to Capital Projects form
   self.page.Keys("[Up]")
   self.verify_aqobject_chkproperty(findcapitalprojects_form,"AWTComponentAccessibleName",cmpContains,"Capital Projects")
   web_utils.log_checkpoint("'Capital Projects Details' form launched successfully",500,jFrame)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Capital Projects (Manheim Corporate Services)","ExtendedFrame"]
   capitalprojects_form=jFrame.FindChildEx(prop,val,60,True,90000)
   capitalprojects_form.Find("AWTComponentAccessibleName","Assets alt A",10).Click()  
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=[" Assets*","ExtendedFrame"]
   asset_form=jFrame.FindChildEx(prop,val,60,True,40000)
   Delay(2000) 
   while not asset_form.Exists: 
     Delay(2000)
     asset_form=jFrame.FindChild(prop,val,60)
   web_utils.log_checkpoint("'Assets' form launched successfully",500,jFrame)   
   Delay(2000) 
   asset_form.Find("AWTComponentAccessibleName","Asset Lines alt i",10).Click() 
   Delay(2000)  
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Asset Lines*","ExtendedFrame"]
   asset_lines=jFrame.FindChildEx(prop,val,30,True,40000)
   self.verify_aqobject_chkproperty(asset_lines,"AWTComponentAccessibleName",cmpStartsWith,"Asset Lines")
   web_utils.log_checkpoint("'Asset Lines' form launched successfully",500,jFrame) 
   asset_lines.Find("AWTComponentAccessibleName","Details alt D",10).Click()
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Asset Line Details (Manheim Corporate Services)*","ExtendedFrame"]
   asset_line_details=jFrame.FindChildEx(prop,val,60,True,90000)
   prop = ["AWTComponentAccessibleName","AWTComponentIndex","JavaClassName"]
   val = ["CIP Cost","60","VTextField"]
#   cip_cost = asset_line_details.FindChild(prop,val,30).wText
#   if(VarToFloat(cip_cost) <= 0.00):
#     self.log_error_message(f"CIP Cost: {cip_cost}. CIP COST is not positive")
   web_utils.log_checkpoint("'Asset Line Details' reviewed successfully",500,jFrame)  
   delay(2000)
#   web_utils.log_checkpoint("'Asset Line Details' reviewed successfully",500,jFrame) 
#   delay(1000)
   self.close_forms(jFrame)
   del app,jFrame

          
 def leap_year(self,year):
   global yr 
   if StrToInt(year)%4 == 0:
     yr = "Y"
   else:
     yr = "N"
   return yr
         
 def calc_month_end(self):
    var = aqConvert.DateTimeToFormatStr(aqDateTime.Today(),"%b/%d/%Y")
    var1 = aqString.SubString(var,0,3)
    var3 = aqString.SubString(var,7,4)
    Log.Message(var1)
    if var1 == "Jan" or var1 == "Mar" or var1 == "May" or var1 == "Jul" or var1 == "Oct" or var1 == "Dec" or var1 == "Aug":
      month_end_date =   aqString.Replace(var,aqString.SubString(var,4,3),'31/',1)
      Log.Message(month_end_date)
    elif var1 == "Feb":
      if self.leap_year(var3) == "Y":
        month_end_date =   aqString.Replace(var,aqString.SubString(var,4,3),'29/',1)
        Log.Message(month_end_date)
      elif self.leap_year(var3) == "N":
        month_end_date =   aqString.Replace(var,aqString.SubString(var,4,3),'28/',1)
        Log.Message(month_end_date)
    else:
        month_end_date =   aqString.Replace(var,aqString.SubString(var,4,3),'30/',1)
        Log.Message(month_end_date)
    return month_end_date
    
    
 def save_log(self,file_type):
   
   Delay(15000)
   self.wait_until_page_loaded()
   log_page=Sys.Browser("iexplore").Page("https://manheim-*.epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
   Delay(1000)
   log_page.Click()
   log_page.TextNode(0).Click()
   Delay(1000)
   Log.Enabled=True     
   screenshot=log_page.PagePicture()
   msg = (file_type+" File Opened Successfully")
   Log.Picture(screenshot,msg)
   Log.Enabled=False
   log_page.Keys("~f")
   Delay(5000)
   log_page.Keys("a")
   Delay(5000) 
   file_system_utils.create_folder(self.op_log_path)             
#US545181: Updated
   log_path=self.op_log_path+"\\man generate asset lines for a single project "+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    

   Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
   Delay(3000)
   Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
   Delay(5000)
   Log.Enabled=True
#US545181: Updated
   Log.File(log_path,"MAN: Generate Asset Lines for a Single Project "+file_type+" File Attached")

   Log.Enabled=False     
   Sys.Browser("iexplore").Page("https://manheim-*.epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close()
   web_utils.close_additional_browsers()

   
