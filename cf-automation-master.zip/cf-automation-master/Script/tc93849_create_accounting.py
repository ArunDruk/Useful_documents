﻿import driverchain
import tc93849cai_us_create_accounting
#Author:            Sandeep Kowtha
#TestCaseID:        TC93849
#UserStoryID:       US200743
#Reviewed_By:       Syed Hussain



class driver(Driverchain):
  global classarr
  
  def __init__(self):    
    global env

    Project.Variables.test_env="dauti"  
    self.classarr=["create_accounting()"]     
    super().__init__(self.classarr)
    
    
def main():  
  cobj=driver().run()
