﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils
import web_utils

#This testcase is to validate subledger accounting

class OCI_Oracle_EBS_Smoke_Test(Ebiz):
 global rowno, app
 
 rowno = 2
 op_log_path="C:\\TC_Logs"
# def login(self):
#    self.login_user="rmaran"
#    super().login()
    
 
 def action(self,book):
    app = book.Sheets.item["Smoke_Test"]
    self.wait_until_page_loaded()
#    self.log_message_web("Logged in Successfully to Oracle Applications Home Page")
#    web_utils.log_checkpoint("Logged in Successfully to Oracle Applications Home Page",500,self.page)
    web_utils.clk_fldr_link_by_xpath_start(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" AP INQUIRY')]")
#    self.log_message_web("Click 'CAI "+self.oper_unit+" AP INVOICE PROCESSING' link - Successful")
    Delay(1000)
    self.wait_until_page_loaded() 
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Invoices Inquiry')]")
#    self.log_message_web("Click 'Invoices' link - Successful") 
    Delay(1000)
    self.wait_until_page_loaded()
    web_utils.clk_link_by_xpath_indexed(self.page,"//div[text()='Invoices']",0)
#    self.log_message_web("Click 'Invoices' link - Successful")
    delay(5000)

    jFrame = self.initializeJFrame()
    Delay(5000)
    form_utils.click_ok_btn(jFrame)
    delay(3000)
    
#    self.log_message_oracle_form(jFrame,"Navigate to Find Invoices Form")
    p_names = ("JavaClassName","AWTComponentAccessibleName","AWTComponentIndex")
    p_values = ("ExtendedFrame","Find Invoices",24)
    find_inv_form=jFrame.FindChildEx(p_names,p_values,20,True,20000)      
    if find_inv_form.Exists:
#       self.log_message_oracle_form(jFrame,"Unable to Launch Find Invoices Form") 
       web_utils.log_checkpoint("Able to Launch  'Find Invoices' Form Successfully",500,jFrame)
    else:
       web_utils.log_checkpoint("Unable to Launch 'Find Invoices' Form",500,jFrame)
    Delay(1000) 
    
    dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
    user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
    pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
    invoice_num = dbhelper.invoice_num(dsn,user_id,pwd)
    app.Cells.Item[rowno,1] = invoice_num
    pro = ("AWTComponentIndex","AWTComponentAccessibleName","JavaClassName")
    values = (6,"Invoice: Number","VTextField") 
    Delay(1000)      
    find_inv_form.FindChild(pro,values,20).Click()
#    delay(1000)
    find_inv_form.FindChild(pro,values,20).SetText(invoice_num)
    Delay(1000)
    values = (3,"Find alt i","Button")
    Delay(2000)
    cnt = 0
    find_button = find_inv_form.FindChild(pro,values,20)
    find_button.click()
    delay(2000)
    if find_button.Exists:
      find_button.click()
    Delay(5000)  

    p_names = ("JavaClassName","AWTComponentAccessibleName")
    p_values = ("ExtendedFrame","Invoice Workbench (CAI "+self.oper_unit+" AP INQUIRY)")
    inv_wb_form=jFrame.FindChildEx(p_names,p_values,40,True,20000) 
    if inv_wb_form.Exists:
#      self.log_message_oracle_form(jFrame,"Able to Query AP Invoice : "+invoice_num+" Successfully")
      web_utils.log_checkpoint("Able to Query AP Invoice Successfully: Test Passed",500,jFrame)
      app.Cells.Item[rowno,2] = "Success"
    else:
#      self.log_error_message("Unable to Query AP Invoice : "+invoice_num+"- Test Failed")
      self.log_error_message("Unable to Query AP Invoice:  Test Failed")

      app.Cells.Item[rowno,2] = "Failed"
    self.close_forms(jFrame)
