﻿from dbhelper import *
from ebiz import *
import web_utils
import wcc_login_page
import wcc_home_page


class OCI_WCI_Capture_Smoke_Test(Ebiz):
  
 def login(self):
    self.login_user="pburugupal"
    wcc_login_page.username_textfield().SetText(self.login_user) 
    self.page.Keys("[Tab]")
    wcc_login_page.password_textfield().SetText(self.testConfig['ebiz']['password']) 
    self.page.wait_until_loaded()
    wcc_login_page.login_button().Click()
    self.wait_until_page_loaded()    
    
 def goto_url(self,url):
   super().goto_url(self.testConfig['ebiz']['webCenCapUrl'])
   
 def logout(self):
   self.page.wait()
   wcc_home_page.sign_out_link().Click()
   web_utils.log_checkpoint("Completed WCI Capture Application Validation Successfully: Logging out from Applications",500,self.page)
   wcc_home_page.final_page().Close()
   
 def wait_until_page_loaded(self):
   Delay(5000)  
   
 def action(self,book):
  app = book.Sheets.item["smoke_test"]    
  Delay(6000)
  if wcc_login_page.login_alert_popup().Exists:
    wcc_login_page.login_alert_popup().Alert.Button("OK").Click()
  Delay(2000)
  self.wait_until_page_loaded()
  Delay(2000)
  if wcc_login_page.java_plugin_ok_button().Exists:
    Sys.Browser("iexplore").BrowserWindow(0).Keys("[Enter]")
  wcc_login_page.security_window_checkbox().Click()
  wcc_login_page.security_window_enter().Keys("[Enter]")
  Delay(2000)
  self.wait_until_page_loaded()
  if wcc_login_page.java_plugin_ok_button().Exists:
    Sys.Browser("iexplore").BrowserWindow(0).Keys("[Enter]")
  self.wait_until_page_loaded()  
  batch_list = wcc_home_page.batch_edit_form()
  count =  0
  
#Enter Applications and Validate the Home Page:
  while not batch_list.Exists:
    Delay(2000)
    batch_list=wcc_home_page.batch_edit_form() 
    count = count + 1 
    if count == 10:
      self.log_error_message("Unable to Login to WCI Capture Application")    
  web_utils.log_checkpoint("Logged in to Web Center Capture Applications Successfully",500,self.page) 
  
# Validate Location dropdown:  
  location_dropdown =  wcc_home_page.location_dropdown()
  if location_dropdown.Exists:
    wcc_home_page.location_dropdown().Click()
    web_utils.log_checkpoint("Able to verify Location Dropdown object successfully",500,self.page)
  else:
    self.log_error_message("Unable to Verify Object: 'Location Dropdown ' in WCI - Capture Application")
    
# Validate Capture Link:    
  capture_link = wcc_home_page.capture_link()
#  capture_link=self.page.FindChildEx("AWTComponentAccessibleName","Capture",30,True,60000)
  if capture_link.Exists:
    web_utils.log_checkpoint("Able to verify 'Capture' object in WCI Capture Application",500,self.page)
  else:
    self.log_error_message("Unable to Verify Object: 'Capture' in WCI - Capture Application")

  capture_link.DblClick()
#  wcc_home_page.import_dialog_ok_button().Click()
  
#  capture_client = wcc_home_page.import_dialog_ok_button()
  capture_client = Sys.Process("jp2launcher").WaitSwingObject("ImportOptionDialog", "Import", -1, 1,10000)
  if capture_client.Exists:  
    web_utils.log_checkpoint("Able to verify 'Capture Client Interface' in WCI Capture Application: Test Passed",500,self.page)
    capture_client.FindChild("AWTComponentAccessibleName","Cancel",30).Click()
    app.Cells.item[2,1] = "SUCCESS"
  else:
    self.log_error_message("Unable to Verify Object: 'Capture Client Interface' in WCI - Capture Application")
    app.Cells.item[2,1] = "FAILED"


def test():
  prop_names = ["AWTComponentAccessibleName", "JavaFullClassName"]
  prop_values = ["Capture", "javax.swing.JButton"]
  Sys.Browser("iexplore").Page("*").FindChild(prop_names,prop_values,5000).Click() 
