﻿import gvar

def get_cash_payment_payload():
  return   {
         "customerNumber": gvar.dataprep['buyer'],
         "auctionCode": gvar.dataprep['auction'],
         "holdPayment": False,
         "currency": "USD",
         "receiptAmount":VarToStr(VarToInt(gvar.dataprep['amount_due_remaining'])+50), 
         "onAccountAmount": 0,
         "floatContract": False,
         "noOfHundreds": 0,
         "suspicious": False,
      "payer": {
          "payerID":gvar.dataprep['payerID'],
          "repNumber":gvar.dataprep['repNumber'],
          "firstName":gvar.dataprep['firstName'],
          "middleName":gvar.dataprep['middleName'],
          "lastName":gvar.dataprep['lastName'],
          "tin": gvar.dataprep['tin'],
          "dateOfBirth": gvar.dataprep['dateOfBirth'],
          "streetAddress": gvar.dataprep['streetAddress'],
          "city": gvar.dataprep['city'],
          "state": gvar.dataprep['state'],
          "zip": gvar.dataprep['zip'],
          "country": gvar.dataprep['country'],
          "occupation": gvar.dataprep['occupation'],
          "idNumber": gvar.dataprep['idNumber'],
          "idType": gvar.dataprep['idType'],
          "idExpiration": gvar.dataprep['idExpiration'],
          "idIssuedCountry": gvar.dataprep['idIssuedCountry'],
          "idIssuedState": gvar.dataprep['idIssuedState'],
          "notApplicable": False 
    },
    "invoiceDetails": [
      {
        "invoiceID": gvar.dataprep['buyer_invoice_number'] ,
        "invoiceSource": gvar.dataprep['source'],
        "applicationAmount":gvar.dataprep['amount_due_remaining'],
        "cashHandlingFee": 50
      }
    ],
    "Id": "2008"
  }
      
def get_cashier_check_payload():
  return {
             "customerNumber":gvar.dataprep['buyer'],
             "auctionCode":gvar.dataprep['auction'],
             "holdPayment":False,
             "currency":"USD",
             "receiptAmount":gvar.dataprep['amount_due_remaining'],
             "onAccountAmount":0,
             "floatContract":False,
             "noOfHundreds":0,
             "Id":"2009",
             "payer":{},
             "invoiceDetails":[
              {
                    "invoiceID":gvar.dataprep['buyer_invoice_number'],
                    "invoiceSource":gvar.dataprep['source'],
                    "applicationAmount":gvar.dataprep['amount_due_remaining']
              }
            ]
        }      
        
def get_ach_payment_payload():
  return {
             "customerNumber":gvar.dataprep['buyer'],
             "auctionCode":gvar.dataprep['auction'],
             "holdPayment":False,
             "currency":"USD",
             "receiptAmount":gvar.dataprep['amount_due_remaining'],
             "onAccountAmount":0,
             "floatContract":False,
             "noOfHundreds":0,
             "Id":gvar.dataprep['payment_id'],
             "payer":{},
             "invoiceDetails":[
              {
                    "invoiceID":gvar.dataprep['header_id'],
                    "invoiceSource":gvar.dataprep['source'],
                    "applicationAmount":gvar.dataprep['amount_due_remaining']
              }
            ]
        }  
    
        
def get_check_payment_payload():
 from random import randint 
 DATAPREP = gvar.dataprep
 return {
     "customerNumber": DATAPREP['buyer'],
     "auctionCode": DATAPREP['auction'],
     "holdPayment": False,
     "currency": "USD",
     "receiptAmount": DATAPREP['amount_due_remaining'],
     "onAccountAmount": 0,
     "floatContract": False,
     "noOfHundreds": 0,
     "suspicious": False,
     "payer": {},
     "invoiceDetails": [
        {
            "invoiceID": DATAPREP['buyer_invoice_number'],
            "invoiceSource": DATAPREP['source'],  
            "applicationAmount": DATAPREP['amount_due_remaining'],
        }
     ],
  "Id": DATAPREP['payment_method_id'],
  "checkNumber": VarToStr(randint(170000000, 179999999))   
}

