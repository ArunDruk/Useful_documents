﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils
import web_utils

#This testcase is to submit create accounting and getting journal batch name from the output

class create_accounting(Ebiz):
 global rowno
 rowno = 2

 def login(self):
    self.login_user="rmaran"
    super().login()
 
 def goto_url(self,url):
   super().goto_url(self.testConfig['ebiz']['oci_is_url'])
 
 op_log_path="C:\\TC_Logs"
 
 def action(self,book): 
    app = book.Sheets.item["Invoice"]
    web_utils.log_checkpoint("Logged in to Oracle Applications Home Page Successfully",500,self.page)
    self.wait_until_page_loaded()      
    self.page.EvaluateXPath("//table[@id='menuContent']//div[contains(text(),'AP Home Office Super User')]")[0].Click() 
    web_utils.log_checkpoint("Click 'AP Home Office Super User' - Successful",500,self.page) 
    self.page.Keys("[Down]")
    self.wait_until_page_loaded()
    self.page.NativeWebObject.Find("contentText","Invoices","A").Click()
    web_utils.log_checkpoint("Click 'Invoices' - Successful",500,self.page) 
    self.page.Keys("[Down]")
    self.wait_until_page_loaded()
    self.page.NativeWebObject.Find("contentText","Entry","A").Click()
    web_utils.log_checkpoint("Click 'Entry' - Successful",500,self.page) 
    self.page.Keys("[Down]")
    self.wait_until_page_loaded()
    self.page.EvaluateXpath("//table[@id='respList']//div[contains(text(),'Invoices')]")[1].Click() 
    web_utils.log_checkpoint("Click 'Invoices' - Successful",500,self.page)
    web_utils.validate_security_box()   
    jFrame = self.initializeJFrame()
    Delay(2000)
    form_utils.click_ok_btn(jFrame)
    delay(5000)
    p_names = ("JavaClassName","AWTComponentAccessibleName") 
    p_values = ("ExtendedFrame","Invoice Workbench*")
    obj=jFrame.FindChild(p_names,p_values,50)
    if obj.Exists:
     web_utils.log_checkpoint("Invoice Workbench (AP Home Office Super User) Launched Successfully",500,jFrame)
    else:
     web_utils.log_checkpoint("Unable to Launch Invoice Workbench Form",500,jFrame)
    Delay(2000)
    jFrame.Keys("~v")
    delay(1000)
    jFrame.Keys("f")
    delay(1000)
    
#Finding Invoice that needs to be accounted

    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Invoices","ExtendedFrame"]
    par_form=jFrame.FindChildEx(prop,val,60,True,60000)
    par_form.Find("AWTComponentAccessibleName","Invoice: Number",30).Click()
    Delay(4000)
    invoice_no = BuiltIn.ParamStr(16)
    par_form.Find("AWTComponentAccessibleName","Invoice: Number",30).Keys(invoice_no)
    jFrame.Keys("[Tab]")
    delay(3000)
    val = ["Find alt i","Button"] 
    par_form.FindChild(prop,val,60).Click()
    Delay(4000)    
    
#    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#    val=["Type RequiredList of Values",8]
#    inv_type=jFrame.FindChildEx(prop,val,60,True,90000)
#    Log.Enabled=True
#    aqObject.CheckProperty(inv_type,"wText",cmpIn,"Standard")
#    Log.Enabled=False
    
    web_utils.log_checkpoint("Find Invoice Successful",500,jFrame)
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Status",4]
    inv_val = jFrame.FindChild(prop,val,60)
    inv_status=inv_val.wText
    

    while inv_status != "Validated" and inv_status == "Never Validated":
        delay(1000)
        jFrame.Keys("~c")
        delay(1500)
        jFrame.Keys("~v")
        delay(1000)
        jFrame.Keys("~k")
        delay(10000)
        jFrame.Keys("^s")
        delay(2000)
        inv_status=inv_val.wText
    web_utils.log_checkpoint("Invoice Status: "+inv_status,500,jFrame) 

    
    delay(3000)
    jFrame.Keys("~c")
    delay(3000)
    jFrame.Keys("~t")
    delay(3000)
    jFrame.Keys("~o")
    delay(3000)
    jFrame.Keys("~k")
    delay(18000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Note*","ChoiceBox"]
    note_popup=jFrame.FindChildEx(prop,val,30,True,60000)
    delay(1000)
    jFrame.Keys("~o")
    web_utils.log_checkpoint("'Create Accounting' concurrent job submitted successfully ",500,jFrame)
    delay(3000)
    jFrame.Keys("[F4]")
    delay(3000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(2000)
    jFrame.Keys("~i")
    Delay(1000)
    
#Gathering Request ID for the Create Accounting Parent Program  

    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,120000)  
    job_name_parent="false"
    phase_parent="false"
    i=20
    while (job_name_parent!="Create Accounting") or (phase_parent!="Completed") :
     prop=["AWTComponentAccessibleName","AWTComponentIndex"]
     val=["Name",i]
     job_name_parent=req_form.Find(prop,val,10).wText
     prop=["AWTComponentAccessibleName","AWTComponentIndex"]
     val=["Phase",i+20]
     phase_parent=req_form.Find(prop,val,10).wText
     prop=["AWTComponentAccessibleName","AWTComponentIndex"]
     val=["Status",i+30]
     status_parent=req_form.Find(prop,val,10)      
     i+=1     
     if i==29:
       prop=["AWTComponentAccessibleName","JavaClassName"]
       val = ["Refresh Data alt R","Button"]
       req_form.FindChild(prop,val,2000).Click() 
       i=20
    Log.Enabled=True
    aqObject.CheckProperty(status_parent,"wText",cmpIn,"Normal,Warning")
    Log.Enabled=False
    web_utils.log_checkpoint("Job Name "+aqConvert.VarToStr(job_name_parent),500,jFrame)
    web_utils.log_checkpoint("Phase of Create Accounting "+aqConvert.VarToStr(phase_parent),500,jFrame)   
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Request ID",i-11]
    req_id_parent=req_form.Find(prop,val,10).wText
    web_utils.log_checkpoint("Request ID of Create Accounting "+aqConvert.VarToStr(req_id_parent),500,jFrame) 


#Gathering Request ID for the Journal Import Child Program

    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,60000)  
    job_name="false"
    phase="false"
    i=20
    while (job_name!="Journal Import") or (phase!="Completed"):
     prop=["AWTComponentAccessibleName","AWTComponentIndex"]
     val=["Name",i]
     job_name=req_form.Find(prop,val,10).wText
     prop=["AWTComponentAccessibleName","AWTComponentIndex"]
     val=["Phase",i+20]
     phase=req_form.Find(prop,val,10).wText
     prop=["AWTComponentAccessibleName","AWTComponentIndex"]
     val=["Status",i+30]
     status=req_form.Find(prop,val,10)       
     i+=1     
     if i==28:
       prop=["AWTComponentAccessibleName","JavaClassName"]
       val = ["Refresh Data alt R","Button"]
       req_form.FindChild(prop,val,2000).Click() 
       i=20
    Log.Enabled=True
    aqObject.CheckProperty(status,"wText",cmpIn,"Normal,Warning")
    Log.Enabled=False
    web_utils.log_checkpoint("Job Name "+aqConvert.VarToStr(job_name),500,jFrame)
    web_utils.log_checkpoint("Phase of Journal Import Program "+aqConvert.VarToStr(phase),500,jFrame)   
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Request ID",i-11]
    req_id=req_form.Find(prop,val,10).wText
    app.Cells.item[rowno,20] = req_id
    web_utils.log_checkpoint("Request ID of Journal Import Program "+aqConvert.VarToStr(req_id),500,jFrame)

#Gathering output for the Journal Import Child Program   

    jFrame.Keys("[F4]")
    Delay(2000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(2000)
    jFrame.Keys("~s")
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Requests","ExtendedFrame"]
    find_req_form=jFrame.FindChildEx(prop,val,10,True,60000)
    find_req_form.Find("AWTComponentAccessibleName","Request ID",10).Click()
    find_req_form.Find("AWTComponentAccessibleName","Request ID",10).SetText(req_id)
    Delay(3000)
    jFrame.Keys("~i")
    Delay(2000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,120000)
    req_form.FindChild("AWTComponentAccessibleName","View Output alt p",20).Click()
    Delay(1000)
    log_page=Sys.Browser("iexplore").Page("https://manheim*.epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
    log_page.Click()
    log_page.TextNode(0).Click()
    Delay(1000)
    log_page.Keys("~f")
    Delay(1000)
    log_page.Keys("a")
    Delay(4000)  
    file_system_utils.create_folder(self.op_log_path)             
    log_path=self.op_log_path+"\\Journal Import Program Output Is Attached_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
    Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
    Delay(1000)
    Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
    Delay(5000)
    Log.Enabled=True
    Log.File(log_path, "Journal Import Concurrent Program Output File Attached")
    Log.Enabled=False        
    Delay(1000)
    Sys.Browser("iexplore").Page("https://manheim*.epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close()
    Delay(1000)
    jFrame.Click()
    Delay(1000)
    dsn = self.testConfig['man_oracle_db']['dsn']
    user_id = self.testConfig['man_oracle_db']['userid']
    pwd = self.testConfig['man_oracle_db']['pwd']
    dbhelper.verify_invoice_accting_posting_status(dsn,user_id,pwd,VarToStr(app.Cells.Item[rowno,13]))    
    self.close_forms(jFrame)    
    Delay(1000) 
    del app,jFrame,log_path,find_req_form,prop,val

