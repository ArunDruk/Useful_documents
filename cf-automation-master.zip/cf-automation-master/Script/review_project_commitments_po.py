﻿import dbhelper
from ebiz import *
import web_utils
import dbhelper
import file_system_utils 
import form_utils
                        
class review_project_commitments_po(Ebiz):
   op_log_path="C:\\Tc_Logs"
                        
   def login(self):
     self.login_user='pkjami'
     super().login()
     
   def goto_url(self,url):
    super().goto_url(self.testConfig['ebiz']['oci_is_url'])
                           
   def action(self,book): 
     global rowno      
     rowno = 2            
     app = book.Sheets.item["Requisition"]
     app1 = book.Sheets.item["Project"]  
     app2 = book.Sheets.item["Invoice"]   
     app.Cells.item[rowno,11] = BuiltIn.ParamStr(16)
     
     web_utils.log_checkpoint("Logged in to Oracle Applications Home Page Successfully",500,self.page)
     self.wait_until_page_loaded()       
     self.page.EvaluateXPath("//table[@id='menuContent']//div[contains(text(),'PC Inquiry')]")[0].scrollIntoView()
     self.page.EvaluateXPath("//table[@id='menuContent']//div[contains(text(),'PC Inquiry')]")[0].Click()
     web_utils.log_checkpoint("Click 'PC Inquiry' - Successful",500,self.page) 
     self.wait_until_page_loaded()
     delay(1000)
     self.page.NativeWebObject.Find("contentText","Project Status","A").Click()
     web_utils.log_checkpoint("Click 'Project Status' - Successful",500,self.page) 
     self.wait_until_page_loaded()
     delay(1000)
     self.page.NativeWebObject.Find("contentText","Project Status Inquiry","A").scrollIntoView()
     self.page.NativeWebObject.Find("contentText","Project Status Inquiry","A").Click()
     web_utils.log_checkpoint("Click 'Project Status Inquiry' - Successful",500,self.page)
     self.wait_until_page_loaded()
     Delay(10000)
     web_utils.validate_security_box()
     Delay(10000)
     jFrame=self.initializeJFrame()
     Delay(3000)
     form_utils.click_ok_btn(jFrame)  
     Delay(10000)
     
# Navigate to 'Find Project Status' Form:
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Find Project Status (Manheim Corporate Services)","ExtendedFrame"]
     proj_status = jFrame.FindChildEx(prop,val,40,True,90000)
     Sys.HighlightObject(proj_status)
     Delay(2000)
     web_utils.log_checkpoint("Navigation to  'Find Project Status Form' - Successful",500,jFrame)   
     
# Enter project Number:         
     val=["Project: NumberList of Values","VTextField"]
     proj_no=proj_status.FindChildEx(prop,val,60,True,40000)
     proj_no.Click()
     proj_no.Keys(app.Cells.item[rowno,11])
     delay(1000)
     web_utils.log_checkpoint("Entering Project Number :"+VarToStr(app.Cells.item[rowno,11])+" to validate commitment details",500,jFrame)        
# Click Find Button:    
     val=["Find alt i","Button"]
     find_btn=proj_status.FindChild(prop,val,60)
     find_btn.Click()
     delay(2000)
# Validate 'Project Status' Form:
     val=["Project Status *","ExtendedFrame"]
     proj_sts_form=jFrame.FindChild(prop,val,60)
     Sys.HighlightObject(proj_sts_form)
     web_utils.log_checkpoint("Navigation to Project Status Form Successfull",500,jFrame) 
     delay(1000)
# Click 'Commitments' button:
     val=["Commitments alt C","Button"]
     find_btn=proj_sts_form.FindChild(prop,val,60)
     find_btn.Click()
     delay(2000)
# Validate Commitments Form:
     val=["Find Commitments *","ExtendedFrame"]
     commit_form=jFrame.FindChild(prop,val,60)
     Sys.HighlightObject(commit_form)
     web_utils.log_checkpoint("Navigation to Commitments Form Successfull",500,jFrame) 
     delay(1000)
# Click Find Button in Commitments Form:
     val=["Find alt i","Button"]
     c_find_btn=commit_form.FindChild(prop,val,60)
     c_find_btn.Click()
     delay(2000)
# Validate Commitment Details Form:
     val=["Commitment Details (Manheim Corporate Services)*","ExtendedFrame"]
     com_det_frm=jFrame.FindChild(prop,val,60)
     Sys.HighlightObject(com_det_frm)
     delay(1000)
     web_utils.log_checkpoint("Navigation to Commitment Details Form Successfull",500,jFrame) 
     tool_bar = Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("ExtendedFrame", "Commitment Details (Manheim Corporate Services)*", 23).AWTObject("TitleBar", "", 0).AWTObject("LWComponent", "", 0).AWTObject("TitleBar$CaptionComp", "", 0)
     Sys.HighlightObject(tool_bar)
     tool_bar.DblClick()
# Validate Commitment Cost:
     prop1=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
     val1=["Project Raw Cost","VTextField",70]
     proj_raw_cost=com_det_frm.FindChild(prop1,val1,60)
     Sys.HighlightObject(proj_raw_cost)
     project_raw_cost_val = "%.2f" %(VarToFloat(proj_raw_cost.wText))
     web_utils.log_checkpoint("Project Raw Cost Value - $"+VarToStr(project_raw_cost_val),500,jFrame)  
     delay(3000)    

     delay(1000)
     self.close_forms(jFrame)
     

def main():
     jFrame=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1)
     delay(2000) 
     jFrame.Keys("~k")
     file_type = 'Log'
     program_name="PRC Update Project Summary Amounts for a Single Project"
#     self.save_log(file_type)
     save_log(file_type,program_name)
     delay(4000)
     jFrame.Keys("~p")
     file_type = 'Output'
#     self.save_log(file_type)
     save_log(file_type,program_name) 
     Delay(6000)
  

def save_log(file_type,program_name):
     import web_utils
     import file_system_utils
     op_log_path="C:\\TC_Logs"
          
     Delay(15000)
#     self.wait_until_page_loaded()
     log_page=Sys.Browser("iexplore").Page("https://manheim-*.epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
     Delay(1000)
     log_page.Click()
     log_page.TextNode(0).Click()
     Delay(1000)
     Log.Enabled=True     
     screenshot=log_page.PagePicture()
     msg = file_type+" File Opened Successfully"
     Log.Picture(screenshot,msg)
     Log.Enabled=False
     log_page.Keys("~f")
     Delay(5000)
     log_page.Keys("a")
     Delay(5000) 
     file_system_utils.create_folder(op_log_path)             
   #  log_path=self.op_log_path+"\\prc update project summary amount "+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt" 
     log_path=op_log_path+"\\"+program_name+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"   
     Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
     Delay(1000)
     Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
     Delay(5000)
     Log.Enabled=True
#     Log.File(log_path,"PRC: Update Project Summary Amounts for a Single Project "+file_type+" file Attached")
     Log.File(log_path,program_name+" "+file_type+" file Attached") 
     Log.Enabled=False     
     Sys.Browser("iexplore").Page("https://manheim-*.epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
     web_utils.close_additional_browsers()
     
     
     
     
     
     
     
  
