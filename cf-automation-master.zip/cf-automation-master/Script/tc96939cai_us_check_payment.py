﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils

#This test case is to make Check payment for an AP INVOICE and retrieving the payment information

class tc96939cai_us_check_payment(Ebiz):
  
  op_log_path="C:\\TC_Logs"

  def login(self):
    self.login_user="mcampbell8"
    super().login()

  def action(self,book): 
   
    app = book.Sheets.item["Invoice"]    
    app1 = book.Sheets.item["Requisition"]
    self.wait_until_page_loaded()    
    web_utils.clk_fldr_link_by_xpath(self.page,"//div[text()='CAI "+self.oper_unit+" AP PAYMENT PROCESSING']")    

    self.log_message_web("Click 'CAI "+self.oper_unit+" AP PAYMENT PROCESSING' - Successful")    
    delay(2000)
    self.page.wait()
    self.wait_until_page_loaded()
    self.page.EvaluateXPath("//div[text()='Payments']")[0].Click()     
    delay(2000)
    
    self.page.wait()
    self.wait_until_page_loaded()  
    self.log_message_web("Click 'Payments' - Successful")      
    self.page.EvaluateXPath("//div[text()='Entry']")[0].Click()  
    delay(2000)  
    
    self.page.wait()
    self.wait_until_page_loaded()    
    self.log_message_web("Click 'Entry' - Successful")
    self.page.EvaluateXPath("//div[text()='Payments Manager']")[0].Click() 
    delay(2000) 
    
    self.page.wait()
    self.wait_until_page_loaded()   
    self.log_message_web("Click 'Payments Manager' - Successful") 
    self.page.EvaluateXPath("//a[text()='Submit Single Payment Process Request']")[0].Click()
    self.log_message_web("Click Submit Single Payment Process Request - Successful")
    delay(2000)
    self.page.wait()
    
#Entering Check Payment Process Request Name
    self.page.Find("idStr","CheckrunName",30).Click()
    pay_des="CAI_ATG_Check_Payment_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")
    self.page.Find("idStr","CheckrunName",30).Keys(pay_des)
    self.log_message_web("Enter Payment Process Request Name - Successful")
    delay(2000)
    
#Entering Payment Template
    self.page.Find("idStr","TemplateName",30).Click()
    self.page.Find("idStr","TemplateName",30).Keys("ATG Payment Template - Check")
    self.page.Keys("[Tab]")
    self.log_message_web("Select Payment Template - Successful")
    delay(2000)
    
#Entering Payee Information  
    self.page.Find("idStr","Payee",30).Click()
    self.page.Find("idStr","Payee",30).Keys(VarToStr(app1.Cells.item[2,9]))
    self.page.Keys("[Tab]")
    delay(2000)
    self.page.Find("idStr","Payee",30).Click()
    self.page.Find("idStr","Submit",30).Click()
    Delay(2000)
    self.page.wait()
    self.page.Find("idStr","SearchCheckrunName",30).Click()
    self.page.Find("idStr","SearchCheckrunName",30).Keys(pay_des)
    self.page.Keys("[Tab]")
    delay(2000)
    
#Submitting for the payment
    self.page.Find("contentText","Go",30).Click()
    self.log_message_web(pay_des+" - Payment Submitted")
    delay(1000)
    self.page.wait()
    self.wait_until_page_loaded()
#Invoice Pending Review
    paymnt_status=self.page.EvaluateXPath("//span[@id='ResultsTable:StatusCodeDsp:0']")[0].contentText
    while paymnt_status != 'Invoices Pending Review':
      Delay(1000)
      self.page.Find("idStr","ResultsTable:Refresh:*",30).Click()
      Delay(1000)
      self.page.wait()
      self.wait_until_page_loaded()
      paymnt_status=self.page.EvaluateXPath("//span[@id='ResultsTable:StatusCodeDsp:0']")[0].contentText
      if paymnt_status == "Cancelled - No Invoices Selected":      
        self.log_error_message("Invoice not eligible for payment")
    delay(2000) 
    self.page.Find("namePropStr","takeaction_enabled.gif",30).Click()
    delay(2000)
    self.wait_until_page_loaded()
    self.page.Find("idStr","ResubmitPsr",30).Click() 
    self.log_message_web(pay_des+" - Invoices Pending Review")
    delay(1000)
    self.page.wait()
    self.wait_until_page_loaded()
#Pending Proposed Payment Review   
    while paymnt_status != 'Pending Proposed Payment Review':
     Delay(1000)
     self.page.Find("idStr","ResultsTable:Refresh:*",30).Click()
     Delay(1000)
     self.page.wait()
     self.wait_until_page_loaded()
     paymnt_status=self.page.EvaluateXPath("//span[@id='ResultsTable:StatusCodeDsp:0']")[0].contentText 
    delay(2000)
    self.page.Find("namePropStr","takeaction_enabled.gif",30).Click()
    delay(1000)
    self.page.wait()
    self.wait_until_page_loaded()
#    self.page.Find("contentText","Go",30).Click()
    self.page.EvaluateXPath("//button[@title='Go']")[0].Click()
    delay(1000)
    self.page.wait()
    self.wait_until_page_loaded()
    self.page.Find("idStr","SearchCheckrunName",30).Click()
    self.page.Find("idStr","SearchCheckrunName",30).SetText("")
    self.page.Find("idStr","SearchCheckrunName",30).Keys(pay_des)
    self.page.Keys("[Tab]")
    delay(1000)
    self.page.Find("contentText","Go",30).Click()
    self.page.wait()
    self.wait_until_page_loaded()
    self.log_message_web(pay_des+" - Pending Proposed Payment Review")
    delay(2000)
    
#Formatting Payment    
    while paymnt_status != 'Formatting':
       Delay(1000)
       self.page.Find("idStr","ResultsTable:Refresh:*",30).Click()
       Delay(1000)
       self.page.wait()
       self.wait_until_page_loaded()
       paymnt_status=self.page.EvaluateXPath("//span[@id='ResultsTable:StatusCodeDsp:0']")[0].contentText
    self.log_message_web(pay_des+" - Formatting Payment")
    delay(2000)
    self.page.Find("idStr","ResultsTable:Refresh:*",30).Click()
    delay(1000)
    self.page.wait()
    self.wait_until_page_loaded()
    self.page.Find("idStr","ResultsTable:Refresh:*",30).Click()
    delay(1000)
    self.page.wait()
    self.wait_until_page_loaded()
#    self.page.NativeWebObject.Find("contentText","Show","A").Click()
    self.page.EvaluateXPath("//img[@title='Select to show information']")[0].Click()
    delay(5000)
    self.page.wait()
    self.wait_until_page_loaded()
    while (self.page.FindChild("idStr","PmtInstructionsTable___PmtInstructionsVO1___0:Status:0",30).Exists) !=True:      
      self.page.EvaluateXPath("//button[@title='Refresh Status']")[1].Click()
      self.wait_until_page_loaded()
    Delay(1000)  
#    self.page.NativeWebObject.Find("contentText","Show","A").Click()    
    Delay(1000)
    self.page.EvaluateXPath("//img[@alt='Take Action']")[1].Click()
    delay(2000)
    self.page.wait()
    self.wait_until_page_loaded()    
    self.page.EvaluateXPath("//button[@id='RecordPrintStatus']")[0].Click()    
    delay(2000)
    self.page.wait()
    self.wait_until_page_loaded()
    self.page.Keys("~c")
    delay(2000)
    self.page.Find("idStr","Apply",30).Click()
    delay(9000)
    self.page.wait()
    self.wait_until_page_loaded()
    self.page.EvaluateXPath("//button[@title='Refresh Status']")[0].Click()
    self.page.wait()
    self.wait_until_page_loaded()
#    self.page.Find("contentText","Payment Process Requests",30).Click()
    delay(1000)
    self.page.Find("idStr","SearchCheckrunName",30).Click()
    delay(1000)
    self.page.Find("idStr","SearchCheckrunName",30).SetText("")
    delay(1000)
    self.page.Find("idStr","SearchCheckrunName",30).Keys(pay_des)
    self.page.Keys("[Tab]")
    delay(2000)
    self.page.Find("contentText","Go",30).Click()
    delay(1000)
    self.page.wait()
    self.wait_until_page_loaded()
#Confirmed Payment    
    while paymnt_status != 'Confirmed':
       Delay(1000)
       self.page.Find("idStr","ResultsTable:Refresh:*",30).Click()
       Delay(2000)
       self.page.wait()
       self.wait_until_page_loaded()
       paymnt_status=self.page.EvaluateXPath("//span[@id='ResultsTable:StatusCodeDsp:0']")[0].contentText
    self.log_message_web(pay_des+" - Confirmed Payment")
    
#Review Concurrent Programs Outputs    
    self.page.EvaluateXPath("//img[@title='Home']")[0].Click()
    Delay(2000)
    self.page.wait()
    self.wait_until_page_loaded()
    self.page.NativeWebObject.Find("contentText","Other","DIV").Click()
    delay(2000)    
    self.page.wait()
    self.page.Keys("[Down][Down][Down]")
    Delay(1000)
    self.page.NativeWebObject.Find("contentText","Requests","DIV").Click()
    delay(2000)  
    self.page.wait()
    self.page.Keys("[Down][Down]")
    Delay(1000)
    self.page.NativeWebObject.Find("contentText","Run","DIV").Click()
    delay(15000) 
    jFrame=self.initializeJFrame()
    Delay(20000)
    form_utils.click_ok_btn(jFrame)
    Delay(5000)
    
    prop=["AWTComponentName","JavaClassName"]
    val=["ChoiceBox*","ChoiceBox"]
    ok_btn=jFrame.FindChildEx(prop,val,30,True,3000)
    if ok_btn.Exists:
     jFrame.Keys("~o")
    delay(10000)
    val=["Submit a New Request","ExtendedFrame"]
    srs_wnd = jFrame.FindChildEx(prop,val,30,True,5000)
    if srs_wnd.Exists:
        srs_wnd.Close()
    else:
        jFrame.Keys("[F4]")
    
    Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("ExtendedFrame", "Submit a New Request", 0).AWTObject("TitleBar", "", 0).AWTObject("ToolBar", "", 0).Click()
    Delay(5000)
    
    menu_bar=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWMenuBar", "", 0)
    OCR.Recognize(menu_bar).BlockByText("View").Click()
    Delay(1000)

    view_menu=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("LWPopupMenu", "", 0)
    OCR.Recognize(view_menu).BlockByText("Requests").Click()
    
    jFrame.Keys("~i")
    Delay(2000) 

## Gathering Request ID and Output File for the "Format Payment Instructions Program"
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,30000)  
    job_name_parent="false"
    phase_parent="false"
    i=19
    while (job_name_parent!="Format Payment Instructions") or (phase_parent!="Completed"):
       i+=1     
       if i==28:
         req_form.keys("~r") 
         i=20      
       prop=["AWTComponentAccessibleName","AWTComponentIndex"]
       val=["Name",i]
       job_name_parent=req_form.Find(prop,val,10).wText
       prop=["AWTComponentAccessibleName","AWTComponentIndex"]
       val=["Phase",i+20]
       phase_parent=req_form.Find(prop,val,10).wText          

    self.log_message_oracle_form(req_form,"Job Name "+aqConvert.VarToStr(job_name_parent)+" submitted")
    self.log_message_oracle_form(req_form,"Phase code of Format Payment Instructions is "+aqConvert.VarToStr(phase_parent))   
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Request ID",i-10]
    req_id_parent=req_form.Find(prop,val,10).wText
    self.log_message_oracle_form(req_form,"Request ID of Format Payment Instructions is "+aqConvert.VarToStr(req_id_parent))
    
    ## Commenting out the FILE validation for Format Payment Instructions - This is a TechDebt task. --Michael Dang 10/24/2019
#    jFrame.Keys("[F4]")
#    Delay(1500)
#    jFrame.Keys("~v")
#    Delay(1000)
#    jFrame.Keys("r")
#    Delay(1000)
#    jFrame.Keys("~s")
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Find Requests","ExtendedFrame"]    
#    find_req_form=jFrame.FindChild(prop,val,10)
#    find_req_form.Find("AWTComponentAccessibleName","Request ID",10).Click()
#    find_req_form.Find("AWTComponentAccessibleName","Request ID",10).SetText(req_id_parent)
#    Delay(1000)
#    jFrame.Keys("~i")
#    Delay(1000)
#    jFrame.Keys("~p")
#    Delay(8000)
#    Sys.Keys("~")
#    Sys.Keys("f")
#    Delay(3000)
#    Sys.Keys("a")
#    Delay(6000)  
#    file_system_utils.create_folder(self.op_log_path)             
#    log_path=self.op_log_path+"\\Format Payment Instructions Program Output Is Attached_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".pdf"    
#    Sys.Browser("iexplore").Window("#32770", "Save As", 1).Keys(log_path)
#    Delay(2000)
#    Sys.Browser("iexplore").Window("#32770", "Save As", 1).Keys("[Enter]")
#    Delay(2000)
#    Log.Enabled=True
#    Log.File(log_path, "Format Payment Instructions Program Output File Attached (Printed Check)")
#    Log.Enabled=False 
#    Sys.Keys("~")
#    Sys.Keys("f")
#    Delay(1000)
#    Sys.Keys("x")
#    Delay(1000)
#    Sys.Keys("[Tab]")
#    Delay(1000)
#    Sys.Keys("[Enter]")    
#    Delay(2000)        
#    jFrame.Click()
#    Delay(2000)
#    jFrame.Keys("[F4]")
#    Delay(1000)
#    jFrame.Keys("~v")
#    Delay(1000)
#    jFrame.Keys("r")
#    Delay(1000)
#    jFrame.Keys("~i")
#    Delay(1000)
#
## Gathering Request ID and Output File for the "Payment Instruction Register Program"
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Requests","ExtendedFrame"]
#    req_form=jFrame.FindChildEx(prop,val,30,True,30000)  
#    job_name="false"
#    phase="false"
##    i=19
#    while (job_name!="Payment Instruction Register") or (phase!="Completed"):
#       i+=1     
#       if i==26:
#         req_form.keys("~r") 
#         i=20      
#       prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#       val=["Name",i]
#       job_name=req_form.Find(prop,val,10).wText
#       prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#       val=["Phase",i+20]
#       phase=req_form.Find(prop,val,10).wText          
#
#    self.log_message_oracle_form(req_form,"Job Name "+aqConvert.VarToStr(job_name)+" submitted")
#    self.log_message_oracle_form(req_form,"Phase Code of Payment Instruction Register Program is "+aqConvert.VarToStr(phase))   
#    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#    val=["Request ID",i-10]
#    req_id=req_form.Find(prop,val,10).wText
#    self.log_message_oracle_form(req_form,"Request ID of Payment Instruction Register Program is  "+aqConvert.VarToStr(req_id)) 
#    jFrame.Keys("[F4]") 
#    Delay(1000) 
#    jFrame.Keys("~v")
#    Delay(1000)
#    jFrame.Keys("r")
#    Delay(1000)
#    jFrame.Keys("~s")
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Find Requests","ExtendedFrame"]    
#    find_req_form=jFrame.FindChild(prop,val,10)
#    find_req_form.Find("AWTComponentAccessibleName","Request ID",10).Click()
#    find_req_form.Find("AWTComponentAccessibleName","Request ID",10).SetText(req_id)
#    Delay(1000)
#    jFrame.Keys("~i")
#    Delay(1000)
#    jFrame.Keys("~p")
#    Delay(8000)
#    Sys.Keys("~")
#    Sys.Keys("f")
#    Delay(3000)
#    Sys.Keys("a")
#    Delay(6000)  
#    file_system_utils.create_folder(self.op_log_path)             
#    log_path=self.op_log_path+"\\Payment Instruction Register Program Output Is Attached_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".pdf"    
#    Sys.Browser("iexplore").Window("#32770", "Save As", 1).Keys(log_path)
#    Delay(2000)
#    Sys.Browser("iexplore").Window("#32770", "Save As", 1).Keys("[Enter]")
#    Delay(2000)
#    Log.Enabled=True
#    Log.File(log_path, "Payment Instruction Register Program Output File Attached")
#    Log.Enabled=False 
#    Sys.Keys("~")
#    Sys.Keys("f")
#    Delay(1000)
#    Sys.Keys("x")
#    Delay(1000)
#    Sys.Keys("[Tab]")
#    Delay(1000)
#    Sys.Keys("[Enter]")    
#    Delay(2000)
#    jFrame.Click()
#    Delay(2000)
#    jFrame.Keys("[F4]")
#    Delay(1000)
#    jFrame.Keys("~v")
#    Delay(1000)
#    jFrame.Keys("r")
#    Delay(1000)
#    jFrame.Keys("~i")
#    Delay(1000)
    
# Gathering Request ID and Output File for the Postive Pay file Program 
 
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,30000)  
    job_name="false"
    phase="false"
    i=19
    while (job_name!="Positive Pay File") or (phase!="Completed") :
       i+=1     
       if i==29:
         req_form.keys("~r") 
         i=20      
       prop=["AWTComponentAccessibleName","AWTComponentIndex"]
       val=["Name",i]
       job_name=req_form.Find(prop,val,10).wText
       prop=["AWTComponentAccessibleName","AWTComponentIndex"]
       val=["Phase",i+20]
       phase=req_form.Find(prop,val,10).wText          

    self.log_message_oracle_form(req_form,"Job Name "+aqConvert.VarToStr(job_name)+" submitted")
    self.log_message_oracle_form(req_form,"Phase Code of Positive Pay File is "+aqConvert.VarToStr(phase))   
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Request ID",i-10]
    ppf_req_id=req_form.Find(prop,val,10).wText
    self.log_message_oracle_form(req_form,"Request ID of Positive Pay File is  "+aqConvert.VarToStr(ppf_req_id)) 
    jFrame.Keys("[F4]")  
    Delay(1000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~s")
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Requests","ExtendedFrame"]    
    find_req_form=jFrame.FindChild(prop,val,10)
    find_req_form.Find("AWTComponentAccessibleName","Request ID",10).Click()
    find_req_form.Find("AWTComponentAccessibleName","Request ID",10).SetText(ppf_req_id)
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000)
    jFrame.Keys("~p")
    Delay(8000)
    log_page=Sys.Browser("iexplore").Page("https://core*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.*")
    log_page.Click()
    log_page.TextNode(0).Click()
    Delay(1000)    
    Sys.Keys("~")
    Sys.Keys("f")
    Delay(3000)
    Sys.Keys("a")
    Delay(6000)  
    file_system_utils.create_folder(self.op_log_path)             
    log_path=self.op_log_path+"\\Positive Pay File Output Is Attached_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
    Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
    Delay(2000)
    Sys.Browser("iexplore").Window("#32770", "Save Webpage*", 1).Keys("[Enter]")
    Delay(5000)
    Log.Enabled=True
    Log.File(log_path, "Positive Pay File Output File Attached")
    Log.Enabled=False 
    Sys.Browser("iexplore").Page("https://core*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.*").Close()
    Delay(4000)
    self.close_forms(jFrame)  
    Delay(2000)
#Payment Inquiry
#    self.page.EvaluateXPath("//img[@title='Home']")[0].Click()
    self.page.wait_until_page_loaded()
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" AP INQUIRY')]")
    self.log_message_web("Click 'CAI "+self.oper_unit+" AP INQUIRY' - Successful")
    Delay(1000)
    self.wait_until_page_loaded() 
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Invoices Inquiry')]")
    self.log_message_web("Click 'Invoices Inquiry' - Successful") 
    Delay(1000)
    self.wait_until_page_loaded()
    self.page.EvaluateXPath("//div[text()='Invoices']")[0].Click()
    self.log_message_web("Click 'Invoices' - Successful")
    delay(5000)
    web_utils.validate_security_box()
    delay(6000)
    jFrame = self.initializeJFrame()
    Delay(10000)
    form_utils.click_ok_btn(jFrame)
    Delay(5000)
        
    prop=["AWTComponentName","JavaClassName"]
    val=["ChoiceBox*","ChoiceBox"]
    ok_btn=jFrame.FindChildEx(prop,val,30,True,3000)
    if ok_btn.Exists:
     jFrame.Keys("~o")
    delay(10000)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Invoices","ExtendedFrame"]   
    par_form=jFrame.FindChildEx(prop,val,60,True,90000)
    par_form.Find("AWTComponentAccessibleName","Invoice: Number",10).Click()
    par_form.Find("AWTComponentAccessibleName","Invoice: Number",10).SetText(VarToStr(app.Cells.item[2,13]))
    
    par_form.Find("AWTComponentAccessibleName","Invoice: Dates: StartList of Values",10).SetText(aqConvert.DateTimeToFormatStr(aqDateTime.Today(),"%d-%b-%Y"))
    par_form.Keys("[Tab]")
    par_form.Find("AWTComponentAccessibleName","Invoice: Dates: EndList of Values",10).SetText(aqConvert.DateTimeToFormatStr(aqDateTime.Today(),"%d-%b-%Y"))
    delay(1000) 
    par_form.FindChild("AWTComponentAccessibleName","Find alt i",10).Click()
    delay(10000)
#    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#    val=["Status",4]
#    inv_status=jFrame.FindChildEx(prop,val,60,True,90000)
#    Log.Enabled=True
#    aqObject.CheckProperty(inv_status,"wText",cmpIn,"Validated")
#    Log.Enabled=False
#    self.log_message_oracle_form(jFrame,"Invoice Is Validated")
    
    jFrame.Keys("~4")
    delay(2000)
    jFrame.Keys("~p")
    delay(2000)
    
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Status",7]
    pay_recon_status=jFrame.FindChildEx(prop,val,60,True,90000)
    Log.Enabled=True
    aqObject.CheckProperty(pay_recon_status,"wText",cmpIn,"Negotiable")
    Log.Enabled=False
    self.log_message_oracle_form(jFrame,"Invoice Is Paid")
    dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
    user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
    pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
    dbhelper.verify_oracle_payment_status(dsn,user_id,pwd,VarToStr(app.Cells.item[2,13]))
#    dbhelper.verify_oracle_payment_status(VarToStr(app.Cells.item[rowno,13]))
    delay(2000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~o")
    Delay(1000)
#    Sys.Browser("iexplore").page("https://core-*.epfinnp.coxautoinc.com/forms/frmservlet*").Close()
    del app,jFrame,val,prop#,inv_status

