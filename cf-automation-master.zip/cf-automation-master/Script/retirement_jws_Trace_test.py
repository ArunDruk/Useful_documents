﻿from dbhelper import *
from ebiz import *
import web_utils
import dbhelper
import file_system_utils 
import form_utils

class retirement_jws_Trace_test(Ebiz):
 op_log_path="C:\\Tc_Logs"

 def login(self):
   self.login_user='rmaran'
   super().login()
   
 def action(self,book): 
   app = book.Sheets.item["Assets"] 
   rowno=2
   #Login to Oracle
   self.wait_until_page_loaded()    
   self.log_checkpoint_message_web("Login Successful")
   
   #Selecting the responsibility
   web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" FA ASSET TRANSACTION')]")
   Delay(3000)
   self.page.NativeWebObject.Find("contentText","Assets","A").Click()
   Delay(2000)
   self.page.wait()
   self.page.NativeWebObject.Find("contentText","Asset Workbench","A").Click()
   Delay(2000)
   self.page.wait()
   self.page.NativeWebObject.Find("contentText","Assets","A").Click()
   Delay(6000)
   
   #Handling the security pop-up and opening forms
   jFrame= self.initializeJFrame()
   Delay(3000)
   form_utils.click_ok_btn(jFrame)
   Delay(3000)
   
   #Getting Asset Number from database
   self.log_message_oracle_form(jFrame,"Find Assets form found")  
   dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
   user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
   pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
   asset_num = dbhelper.asset_add(dsn,user_id,pwd)

   #Find Assets form frame
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Find Assets","ExtendedFrame"]
   findassets_form=jFrame.FindChildEx(prop,val,60,True,60000)
   
   #Entering Asset number in Find Assets form
   findassets_form.Find("AWTComponentAccessibleName","Asset Number",10).SetText(asset_num) 
   findassets_form.Keys("[Tab]")
   app.Cells.Item[rowno,12] = asset_num 
   
   #Verifying for Asset Number textfield object existence   
   self.verify_aqobject_chkproperty(findassets_form,"AWTComponentAccessibleName",cmpContains,"Find Assets")
   Delay(3000)
   findassets_form.FindChild("AWTComponentAccessibleName","Find alt i",10).Click()
   Delay(3000)

   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Assets","ExtendedFrame"]
   assets_form=jFrame.FindChildEx(prop,val,60,True,60000)
   self.log_message_oracle_form( jFrame,"Assets Form Found")
   self.verify_aqobject_chkproperty(assets_form,"AWTComponentAccessibleName",cmpContains,"Assets")
   jFrame.keys("~r")
   Delay(2000)
   self.log_message_oracle_form( jFrame,"Assets Retirements Form Found")
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["retirements","ExtendedFrame"]   
   retirements_form=jFrame.FindChildEx(prop,val,60,True,60000)
   Delay(2000)
   prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
   val=["Book RequiredList of Values","VTextField",2]      
   retirements_form.FindChild(prop,val,10).Keys("ATG CORP")
   self.log_message_oracle_form( jFrame,"Assets Book Entered")
   Delay(2000)
   retirements_form.FindChild(prop,val,10).keys("[Tab]")   
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Current Cost","VTextField"]    
   Delay(2000)  
   ret_val = retirements_form.FindChild(prop,val,10).wText
   self.log_message_oracle_form( jFrame,"Asset value "+VarToStr(ret_val))
#   partial_amt=VarToFloat(ret_val)         
   prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
   val=["Cost Retired Required","VTextField",10]    
   Delay(2000)  
   costRet_vxt_field=retirements_form.Find(prop,val,10)
   costRet_vxt_field.Click()
#   costRet_vxt_field.SetText(VarToStr(partial_amt))
#   costRet_vxt_field.SetText(VarToInt(VarToFloat(VarToFloat(ret_val))))
   costRet_vxt_field.SetText(VarToStr(ret_val))
   costRet_vxt_field.Keys("[Tab]")
   self.log_message_oracle_form( jFrame,"Assets Retirement Amount: "+VarToStr(ret_val))
   Delay(2000)
   retirements_form.Keys("~d")
   Delay(1000)
   prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
   val=["Forms FRM-40400*","FWindow",0] 
   conf_msg_form=jFrame.FindChildEx(prop,val,60,True,90000)         
   jFrame.keys("~o")
   Delay(2000)
   jFrame.Keys("[F4]")
   Delay(2000)
   jFrame.Keys("o")
   Delay(2000)
   jFrame.Keys("r")
   Delay(5000)
   jFrame.Keys("~o")
   Delay(2000) 
   jFrame.Keys("~o")
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Submit Request","ExtendedFrame"]
   submitrequest_form=jFrame.FindChildEx(prop,val,60,True,60000)
   submitrequest_form.Find("AWTComponentAccessibleName","Name RequiredList of Values",10).Keys("Calculate Gains and Losses")
   self.log_message_oracle_form( jFrame,"Submitting Request Calculate Gain and Losses") 
   submitrequest_form.Keys("[Tab]")
   Delay(2000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Parameters","FlexWindow"]
   parameters_form=jFrame.FindChildEx(prop,val,60,True,60000)
   book_txtfield=parameters_form.FindChild("AWTComponentAccessibleName","Book REQUIRED List Values",10)
   book_txtfield.Click()
   book_txtfield.Keys("ATG CORP")
   Delay(1000)
   self.log_message_oracle_form( jFrame,"Entered Parameters for Calculate Gain and Losses Program") 
   book_txtfield.Keys("~o")
   Delay(2000)
   jFrame.Keys("~m")
   self.log_message_oracle_form( jFrame,"Submitted Caluculated Gain and Losses Program") 
   Delay(3000)
   jFrame.Keys("~n")
   Delay(2000)
   jFrame.Keys("~v")
   Delay(2000)
   jFrame.Keys("r")
   Delay(2000)
   jFrame.Keys("~i")
   Delay(2000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Requests","ExtendedFrame"]
   req_form=jFrame.FindChildEx(prop,val,30,True,90000)   
   
   job_name_child="false"
   phase_parent="false"  
   i=20
   while not (job_name_child == "Calculate Gains and Losses" and phase_parent == "Completed"):
    Delay(2000)      
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Name",i]
    job_name_child=req_form.Find(prop,val,10).wText    
    req_form.Find(prop,val,10).Keys("[Enter]")
    Delay(2000)
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Phase",i+20]
    phase_parent=req_form.Find(prop,val,10).wText    
    if i==25:
     req_form.keys("~r") 
     i=20       
    else:          
      i+=1     
   Delay(2000) 
   req_form.keys("~p")
   Delay(3000)
   output_page=Sys.Browser("iexplore").Page("https://*ebs.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
   output_page.Click()
   Delay(3000)
   output_page.Keys("~f")
   output_page.Keys("a")
   Delay(3000)

   file_system_utils.create_folder(self.op_log_path)             
   log_path=self.op_log_path+"\\Calculate Gains and Losses_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
   Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
   Delay(1000)
   Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
   Delay(1000)
   Log.Enabled=True
   Log.File(log_path, "Calculate Gains and Losses Report Output File Attached")
   Log.Enabled=False     
   Sys.Browser("iexplore").Page("https://*ebs.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close() 
   Delay(2000) 
   jFrame.Keys("~m")  
   jFrame.Keys("~o")
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Submit Request","ExtendedFrame"]
   submitrequest_form=jFrame.FindChildEx(prop,val,60,True,90000)
   submitrequest_form.Find("AWTComponentAccessibleName","Name RequiredList of Values",10).Keys("Asset Retirements Report")
   self.log_message_oracle_form( jFrame,"Submitting Asset Retirement Program") 
   submitrequest_form.Keys("[Tab]")
   Delay(2000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Parameters","FlexWindow"]
   parameters_form=jFrame.FindChildEx(prop,val,60,True,60000)
   book_txtfield=parameters_form.FindChild("AWTComponentAccessibleName","Book REQUIRED List Values",10)
   book_txtfield.Click()
   book_txtfield.Keys("ATG CORP")
   Delay(1000)
   parameters_form.Keys("[Tab]")
   Delay(1000)
   parameters_form.Keys("[Tab]")
    
   Delay(1000)
   parameters_form.Keys(aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%b-%y").upper())
#   parameters_form.Keys("MAY-19")
   Delay(1000)
   parameters_form.Keys("[Tab]")
   Delay(1000)
   parameters_form.Keys(aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%b-%y").upper())
#   parameters_form.Keys("MAY-19")
   self.log_message_oracle_form( jFrame,"Entered Parameters for Asset Retirement Program")
   Delay(1000)
   book_txtfield.Keys("~o")
   Delay(2000)
   jFrame.Keys("~m")
   self.log_message_oracle_form( jFrame,"Submitted Asset Retirement Program")
   Delay(3000)
   jFrame.Keys("~n")
   Delay(2000)
#submitting Asset Retiement Program
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Requests","ExtendedFrame"]
   req_form=jFrame.FindChildEx(prop,val,30,True,60000)   
   
   job_name_child="false"
   phase_parent="false"  
   i=20
                           
   while not (job_name_child == "Asset Retirements Report" and phase_parent == "Completed"):
    Delay(2000)      
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Name",i]
    job_name_child=req_form.Find(prop,val,10).wText    
    req_form.Find(prop,val,10).Keys("[Enter]")
    Delay(2000)
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Phase",i+20]
    phase_parent=req_form.Find(prop,val,10).wText    
    if i==25:
     req_form.keys("~r") 
     i=20       
    else:          
      i+=1
   Delay(2000) 
   req_form.keys("~p")
   Delay(3000)
   output_page=Sys.Browser("iexplore").Page("https://*ebs.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
   output_page.Click()
   Delay(2000)
   output_page.Keys("~f")
   output_page.Keys("a")
   Delay(3000)
   file_system_utils.create_folder(self.op_log_path)             
   log_path=self.op_log_path+"\\Asset Retirements Report_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
   Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
   Delay(1000)
   Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
   Delay(1000)
   Log.Enabled=True
   Log.File(log_path, "Asset Retirements Report Report Output File Attached")
   Log.Enabled=False     
   Sys.Browser("iexplore").Page("https://*ebs.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close() 
   Delay(2000)      
   jFrame.Click()
   Delay(1000)
   jFrame.Keys("[F4]")
   Delay(1000)  
   jFrame.Keys("[Up][Up]")   
   Delay(1000)
   jFrame.Keys("a")   
   Delay(2000)     
   jFrame.Keys("[Enter]")
   Delay(1000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Find Assets","ExtendedFrame"]
   findassets_form=jFrame.FindChildEx(prop,val,60,True,90000)
   findassets_form.Find("AWTComponentAccessibleName","Asset Number",10).SetText(VarToStr(asset_num))  
   Delay(1000) 
   jFrame.Keys("~i")
   Delay(1000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Assets","ExtendedFrame"]
   assets_form=jFrame.FindChildEx(prop,val,60,True,90000)
   self.log_message_oracle_form( jFrame,"Assets form found")     
   jFrame.Keys("~i")
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["View Financial Information*","ExtendedFrame"]
   view_fin_form=jFrame.FindChildEx(prop,val,60,True,90000) 
   self.log_message_oracle_form( jFrame,"View Financial Information form found")     
   view_fin_form.FindChild("AWTComponentName","FormsTabPane*",20).ClickTab("Cost History")   
   self.log_message_oracle_form( jFrame,"Cost History Tab Retirement Information found")              
   jFrame.Keys("[F4]")
   Delay(2000)    
   self.log_message_oracle_form( jFrame,"Switching Responsibilty")    
#   Submitting Create Accounting Program
   jFrame.Keys("~f")
   Delay(2000)
   jFrame.Keys("w")
   Delay(3000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Responsibilities","FWindow"]
   resp_form=jFrame.FindChildEx(prop,val,30,True,60000)
   resp_form.Find("AWTComponentName","LWTextField*",10).Click() 
   resp_form.Find("AWTComponentName","LWTextField*",10).keys("CAI US FA JOB SCHEDULER")
   self.verify_aqobject_chkproperty(resp_form,"AWTComponentAccessibleName",cmpContains,"Responsibilities")   
   Delay(2000)
   self.log_message_oracle_form( jFrame,"Switched Responsbility to CAI US FA JOB SCHEDULER")
#   resp_form.Keys("~f")
   jFrame.Keys("~f")
   self.log_message_oracle_form( jFrame,"Navigation Details")
   Delay(3000)
   jFrame.Keys("~o")
   self.log_message_oracle_form( jFrame,"Submit New Request form Found")
   Delay(2000)
   jFrame.Keys("~o")
   self.log_message_oracle_form( jFrame,"Submitting Create Accounting Program")
#   self.log_message_oracle_form( jFrame,"Navigation Details")
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Submit Request","ExtendedFrame"]
   submitrequest_form=jFrame.FindChildEx(prop,val,60,True,60000)
   submitrequest_form.Find("AWTComponentAccessibleName","Name RequiredList of Values",10).Keys("Create Accounting")
   submitrequest_form.Keys("[Tab]")
   Delay(2000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Parameters","FlexWindow"]
   parameters_form=jFrame.FindChildEx(prop,val,60,True,60000)
   book_txtfield=parameters_form.FindChild("AWTComponentAccessibleName","Ledger REQUIRED List Values",10)
   book_txtfield.Click()
   book_txtfield.Keys("CAI US LEDGER")
   Delay(1000)
   parameters_form.Keys("[Tab]")
   Delay(1000)
   parameters_form.Keys("[Tab]")
   Delay(1000)
   jFrame.Keys(aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d-%b-%Y"))
   Delay(1000)
   parameters_form.Keys("[Tab]")
   Delay(1000)
   jFrame.Keys("~o")
   Delay(1000)
   jFrame.Keys("~m")
   self.log_message_oracle_form(jFrame,"Create Accounting job submitted")
   Delay(2000)
   jFrame.Keys("~n")
   Delay(2000)
   
   Delay(2000)
   jFrame.Keys("~v")
   Delay(2000)
   jFrame.Keys("r")
   Delay(2000)
   jFrame.Keys("~i")
   Delay(2000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Requests","ExtendedFrame"]
   req_form=jFrame.FindChildEx(prop,val,30,True,90000)   
   
   job_name_child="false"
   phase_parent="false"  
   i=20
   while not (job_name_child == "Journal Import" and phase_parent == "Completed"):
    Delay(2000)      
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Name",i]
    job_name_child=req_form.Find(prop,val,10).wText    
    req_form.Find(prop,val,10).Keys("[Enter]")
    Delay(2000)
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Phase",i+20]
    phase_parent=req_form.Find(prop,val,10).wText    
    if i==25:
     req_form.keys("~r") 
     i=20       
    else:          
     i+=1

   Delay(2000) 
   req_form.keys("~p")
   Delay(3000)
   output_page=Sys.Browser("iexplore").Page("https://*ebs.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
   output_page.Click()
   Delay(2000)
   output_page.Keys("~f")
   output_page.Keys("a")
   Delay(3000)

   file_system_utils.create_folder(self.op_log_path)             
   log_path=self.op_log_path+"\\Journal Import_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
   Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
   Delay(1000)
   Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
   Delay(1000)
   Log.Enabled=True
   Log.File(log_path, "Journal Import Report Output File Attached")
   Log.Enabled=False     
   Sys.Browser("iexplore").Page("https://*ebs.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close() 
   Delay(2000) 
   fo=open(log_path,"r") 
   lines=fo.readlines()
   self.log_message_web("BATCH Name: - "+lines[17][8:33].strip())
   app.Cells.Item[rowno,1] = lines[17][8:33].strip()   
   jFrame.Click()
   Delay(1000)
   jFrame.Keys("[F4]")
   Delay(2000)
   jFrame.Keys("~o")
   Delay(2000)
   book.save()
   Sys.Browser("iexplore").page("https://*ebs.coxautoinc.com/forms/frmservlet*").Close()    


   
   
   






