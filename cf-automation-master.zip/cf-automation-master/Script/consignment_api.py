﻿import tc_logs
from gvar import dataprep as DATAPREP
import api_utility
import consingment_api_payloads 

__print = tc_logs.checkpt_with_no_picture
__Error = tc_logs.error_with_no_picture
__API_POST  = api_utility.post_or_put
__API_PUT   = api_utility.put
__API_GET  = api_utility.get
__CON_POST_PAYLOAD = consingment_api_payloads.post_payload
__CON_PUT_PAYLOAD  = consingment_api_payloads.put_payload

def fire_payload(api_name,action):
      
      if action in('POST'):   
        __validate_post_response(__API_POST(api_name,__CON_POST_PAYLOAD())) 
      elif action in('PUT'):
        __validate_post_response(__API_PUT(api_name,__CON_PUT_PAYLOAD()))
      else:  
        __validate_get_response(__API_GET(api_name,None))
        
def __validate_post_response(response):

    if 'consignmentId' in response:
      __print(f"Consignment ID was successfully created or updated: {response['consignmentId']}") 
      DATAPREP['consignment_id'] = response['consignmentId'] 
      
    else:
      __Error(f"Failed Message: {response['errorMessage']} ")
      

def create_consignment_id(api_name,action):
   fire_payload(api_name,action)
 
  
     
          
   
   
