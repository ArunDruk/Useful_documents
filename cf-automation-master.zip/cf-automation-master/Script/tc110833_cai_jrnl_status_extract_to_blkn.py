﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils
import winscp_utility


###This testcase is to submit CAI Oracle GL Journal Status Extract to Blackline and capture logs###

class tc110833_cai_jrnl_status_extract_to_blkn(Ebiz):

 op_log_path="C:\\TC_Logs"

 def login(self):
    self.login_user="mfallwell"
    super().login()

 def action(self,book):

# Login to Oracle EBIZ and select CAI ALL GL JOB SCHEDULER responsibility
    self.page.wait()    
    self.page.WaitProperty("contentText","CAI ALL GL JOB SCHEDULER",6000)
    cai_gl_job_scheduler=self.page.Find("contentText","CAI ALL GL JOB SCHEDULER",30)
#    self.verify_aqobject_chkproperty(cai_gl_job_scheduler,"contentText",cmpIn,"CAI ALL GL JOB SCHEDULER")
    cai_gl_job_scheduler.Click() 
    self.log_message_web("Click 'CAI ALL GL JOB SCHEDULER' - Successful")            
    self.page.Wait()
    Delay(2000)
    self.page.EvaluateXPath("//div[text()='Submit Request']")[0].Click()
#    cai_gl_submit_link=self.page.Find("contentText","Submit Request",30)
#    self.verify_aqobject_chkproperty(cai_gl_submit_link,"contentText",cmpIn,"Submit Request")
#    cai_gl_submit_link.Click() 
    self.log_message_web("Click 'Submit Request' - Successful") 
    Delay(8000)
    jFrame=self.initializeJFrame() 
    Delay(20000)
    form_utils.click_ok_btn(jFrame)
    Delay(4000)
    # Select ReqSet option
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit a New Request","ExtendedFrame"]
    submit_new_req_form=jFrame.FindChildEx(prop,val,50,True,90000) 
    Sys.HighlightObject(submit_new_req_form)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["What type of request do you want to run? Request Set alt s","ExtendedCheckbox"]   
    submit_new_req_form.FindChild(prop,val,10).Click()
    Delay(1000)
    submit_new_req_form.FindChild("AWTComponentAccessibleName","OK alt O",10).Click()
#    jFrame.Keys("~s")
    Delay(1000)
#    jFrame.Keys("~o")
    
# Submitting "CAI Oracle GL Journal Status Extract to Blackline" Request Set using CAI ALL GL JOB SCHEDULER' responsibility
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit Request Set","ExtendedFrame"]
    par_form=jFrame.FindChildEx(prop,val,60,True,60000)
    par_form.Find("AWTComponentAccessibleName","Request Set RequiredList of Values",30).Keys("CAI Oracle GL Journal Status Extract to Blackline")
    delay(1000)
    jFrame.Keys("[Tab]")
    delay(1000)
    par_form.Find("wText","CAI: Transfer files to Sterling (30)",30).Click()
    jFrame.Keys("[Tab]")
    delay(1000)
    jFrame.Keys("GuardiansQA@coxautoinc.com")
    delay(1000)
    jFrame.Keys("~o")
    delay(2000)
    par_form.FindChild("AWTComponentAccessibleName","Submit",10).Click()
#    jFrame.Keys("~m")
    Delay(2000)
    self.log_message_oracle_form(jFrame,"CAI Oracle GL Journal Status Extract to Blackline is Submitted")   
    RequestID = aqConvert.VarToInt(''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit()))
    Log.Message("Request ID Of  " + aqConvert.VarToStr(RequestID))
    self.log_checkpoint_message_web("Request ID Of CAI Oracle GL Journal Status Extract to Blackline " + aqConvert.VarToStr(RequestID))
    Delay(2000)
    jFrame.Keys("~n")
    Delay(4000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000) 
    
# Gathering Request ID and Output File for the "CAI Oracle GL Journal Status Extract Program"  
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,60000)
    self.req_set_save_log(jFrame,req_form,"CAI Oracle GL Journal Status Extract Program",RequestID)
    jFrame.Click()
    Delay(2000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000)


# Gathering Request ID and Output File for the "CAI File Encrypt Program for Sterling Program"  
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,60000)
    self.req_set_save_log(jFrame,req_form,"CAI File Encrypt Program for Sterling",RequestID)
    jFrame.Click()
    Delay(2000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000)

# Gathering Request ID and Output File for the "CAI: Transfer files to Sterling"  
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,60000)
    self.req_set_save_log(jFrame,req_form,"CAI: Transfer files to Sterling",RequestID)
    Delay(1000)
    jFrame.Click()
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~o")
    Delay(1000)    
#    Sys.Browser("iexplore").page("https://*ebs.coxautoinc.com/forms/frmservlet*").Close()
    

 def req_set_save_log(self,jFrame,req_form,srch_child_name,Preqid):
    self.log_message_oracle_form(req_form,"Checking for Child Program")
#    req_form.keys("~r")
    req_form.FindChild("AWTComponentAccessibleName","Refresh Data alt R",20).Click()
    i=20
    for x in range(1,180):     
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Name",i]
        child_name=req_form.Find(prop,val,10).wText 
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Phase",i+20]
        phase=req_form.Find(prop,val,10).wText 
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Request ID",i-10]
        creqid=VarToInt(req_form.Find(prop,val,10).wText)
#        self.log_message_oracle_form(req_form,"Request ID of "+aqConvert.VarToStr(srch_child_name)+" is "+aqConvert.VarToStr(creqid))                                         
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Status",i+30]         
        status =req_form.FindChild(prop,val,60)            
        if (child_name==srch_child_name) and (creqid>=Preqid) and (phase == "Completed"):
            self.log_message_oracle_form(req_form,"phase Completed Successfuly")            
#            self.verify_aqobject_chkproperty(status,"wText",cmpContains,"Normal")        
            status.Keys("[Enter]")
            Delay(1000)
            self.log_message_oracle_form(req_form,"selected job")     
            req_form.FindChild("AWTComponentAccessibleName","View Log alt K",20).Click()  
            Delay(3000)
            output_page=Sys.Browser("iexplore").Page("https://core*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.*")
            output_page.Click()
            Delay(2000)
            output_page.Keys("~f")
            Delay(2000)
            output_page.Keys("a")
            Delay(5000)
            file_system_utils.create_folder(self.op_log_path)             
            log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"File"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"_%d%b%Y_%H%M")+".txt"    
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
            Delay(1000)
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
            Delay(2000)
            Log.Enabled=True
            Log.File(log_path, aqConvert.VarToStr(srch_child_name)+" Output File Attached")
            Log.Enabled=False     
            Sys.Browser("iexplore").Page("https://core*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.*").Close()
            Filesaved = 'True'
            web_utils.close_additional_browsers()
            return                           
        elif i >=29:
           Delay(20000)
#           req_form.keys("~r")
           req_form.FindChild("AWTComponentAccessibleName","Refresh Data alt R",20).Click()  
           Delay(3000)
           i=20
           val=["Name",i]
           child_name=req_form.Find(prop,val,10).wText

        else:  
           Delay(3000)
           i=i+1 
