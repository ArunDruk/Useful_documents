﻿from webCenterVerifier import *
import random


class WFR_process_po_invoice_verifier_ca(webCenterVerifier):
        
 def goto_url(self,url):
   super().goto_url(self.testConfig['ebiz']['WebCentVerUrl'])
      
 def action(self,book): 
   
  app = book.Sheets.item["wci_capture"]
  app1 = book.Sheets.item["wci_verifier"]
  
  if self.page.FindChild("contentText","Options",40).Exists:
      web_utils.log_checkpoint("Able to Login to WFR Application Successfully",500,self.page)
  self.page.FindChild("contentText","Options",40).Click()
  self.page.FindChild("idStr","item_custom_filter-itemEl",40).Click()
  Delay(1000)
  self.wait_until_processing()
  batch_name=VarToStr(app.Cells.item[2,2])
  self.page.FindChild("idStr","bfdFilter",40).Keys("^a[Del]")
  self.page.FindChild("idStr","bfdFilter",40).SetText("[Capture Batch ID] ='"+VarToStr(batch_name)+"'")
  Delay(2000)
  self.page.FindChild("contentText","Apply",40).Click()
  Delay(1000)
  self.wait_until_processing()
 
# Refresh page until expected batch found
  while  Sys.Browser("iexplore").Page("*").EvaluateXPath("//table[@class='x-grid-table x-grid-table-resizer']//span")==None:    
    Sys.Browser("iexplore").Page("*").Keys("[F5]")
    Sys.Browser("iexplore").Page("*").Wait()
    Delay(2000)
    Sys.Browser("iexplore").Page("*").Wait()  
  Delay(2000)
  web_utils.log_checkpoint("Filter Options applied for WCC Batch Name: "+batch_name,500,self.page)
  
# Check the verifier batch id's(invoices) created for "Capture batch id":
  i = 1
  j = 0
  val2 = VarToStr(app.Cells.Item[2,2])
  fltr_view = Sys.Browser("iexplore").Page("http://tmnh1of.manheim.com/WebVerifier/BatchView.aspx").Panel(0).Panel(0).Form("aspnetForm").Panel(2).Panel(0).Panel(0).Panel("container").Panel(0).Panel("body").Panel("gridCtl").Panel("body").Panel("gridview").Table(0)  
  captr_btch_id = fltr_view.Cell(i, 13).Panel(0)
  val1 = captr_btch_id.contentText
  while  val2 == val1:
    Sys.HighlightObject(captr_btch_id)
    captr_btch_id.Click()
    batch_id = self.page.EvaluateXpath("//table[@class='x-grid-table x-grid-table-resizer']//span")[j].contentText
    i = i+1
    j = j+1
    captr_btch_id = fltr_view.Cell(i, 13).Panel(0)
    self.log_message_web("Available WFR BatchID No:"+VarToStr(i-1)+" = "+batch_id)
    val1 = captr_btch_id.contentText
  self.log_message_web("Count of verifier batch files created for 'Capture Batch Name' - "+VarToStr(app.Cells.Item[2,2])+" = "+VarToStr(j))

# Select the invoice and navigate to details:
  self.page.EvaluateXPath("//table[@class='x-grid-table x-grid-table-resizer']//span")[0].Click()
  web_utils.log_checkpoint("Selecting WFR BatchID: "+batch_id+" for processing",500,self.page) 
  Delay(1000)
  self.wait_until_page_loaded()
  Delay(3000)
  self.page.Wait()
  self.wait_until_page_loaded()
  batchname=self.page.FindChild("idStr","vF_BatchName",30).value   
  self.log_message_web("BatchName : "+VarToStr(batchname))  
  if VarToStr(batch_name)==VarToStr(batchname):
      self.log_checkpoint_message_web("Batch Name match successful") 
      Delay(3000)  
      invoice_number = "TEST_CA_PO_"+VarToStr(aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%m_%y"))+"_"+VarToStr(random.randint(1111,9999))

# Get Project Status & Set invoice type
  project_status = VarToStr(self.page.FindChild("idStr","vF_Project",30).status)
  invoice = self.page.FindChild("idStr","vF_InvoiceType-inputEl",30)
  inv_type = invoice.Text
  if inv_type=="NO-PO":
    invoice.Click()
    invoice.Keys("[Up]")
    invoice.Keys("[Enter]")
    web_utils.log_checkpoint("Changing Invoice Type to required value: PO",500,self.page) 

#  project_status = VarToStr(self.page.FindChild("idStr","vF_Project",30).status)
#  inv_type = self.page.FindChild("idStr","vF_InvoiceType-inputEl",30).Text
#  if inv_type=="NO-PO":
#     self.page.FindChild("idStr","vF_InvoiceType-inputEl",30).SetText("PO")
#  web_utils.log_checkpoint("Expected Invoice Type 'PO' found.",500,self.page) 

# Get Company code and Operating Unit; Project Selection if required
  comp_code=self.page.FindChild("idStr","vF_CompanyCode",30).value  
  self.log_message_web("Company Code :"+VarToStr(comp_code))
  op_unit=self.page.FindChild("idStr","vF_OperatingUnit",30).value  
  self.log_message_web("Operating Unit :"+VarToStr(op_unit))
#  if VarToStr(app.Cells.Item[2,7])=="Yes" and project_status == "False":
#    self.page.FindChild("idStr","vF_Project",30).Click()
#    web_utils.log_checkpoint("Selected Project Checkbox Successfully",500,self.page)

#  Set Invoice Number
  self.page.Find("idStr","ctl00_ctl00_ContentPlace_WorkArea_documentViewerCtl_image",40).Click()
  Delay(3000)    
  inv_no=self.page.FindChild("idStr","vF_InvoiceNumber",30)
  inv_no.Click()
  inv_no.Keys("^a[Del]")
  Delay(1000)
  inv_no.Keys(invoice_number)
  self.log_message_web("Invoice Number : "+VarToStr(invoice_number))
     
# Invoice Date
  inv_date=self.page.FindChild("idStr","vF_InvoiceDate",30)
  inv_date.Click()
  inv_date.Keys("^a[Del]")
  Delay(1000)
  inv_date.Keys(aqDateTime.Today())
  inv_date.keys("[Tab]")
  Delay(3000)
  inv_date=inv_date.value  
  self.log_message_web("Invoice Date : "+VarToStr(inv_date))
     
# PO Number     
  po_no=self.page.FindChild("idStr","vF_PONumber",30)
  po_no.Click()
  po_no.Keys("^a[Del]")
  Delay(1000)
  po_no.Keys(VarToStr(app1.Cells.Item[2,7]))
  
# Update Vendor/site 

  self.page.FindChild("idStr","vF_Button_1",30).Click()
  Delay(6000)
  self.wait_until_page_loaded()
  self.page.FindChild("idStr","TextBoxName",30).Keys(VarToStr(app1.Cells.Item[2,13]))
  Delay(1000)
  self.page.FindChild("idStr","PushButtonSearch",30).Click()
  Delay(2000)
  self.page.FindChild("idStr","List",30).SelectItem(0)
  Delay(1000)
  self.page.FindChild("idStr","OK",30).Click()  
  Delay(3000)
  self.wait_until_page_loaded()
  self.wait_until_processing()
  
  vendor=self.page.FindChild("idStr","vF_VendorID",40).contentText
  self.log_message_web("Updated Vendor ID : "+VarToStr(vendor))
      
  siteID=self.page.FindChild("idStr","vF_SiteID",40).contentText
  self.log_message_web("Updated Site ID : "+VarToStr(siteID)) 
         
  ship_to=self.page.FindChild("idStr","vF_ShipTo",30)
  ship_to.Keys(app1.Cells.Item[2,8])
  self.log_message_web("Ship To : "+VarToStr(app1.Cells.Item[2,8]))
  
  approver = self.page.FindChild("idStr","vF_Approver",30)
  approver.Keys(app1.Cells.Item[2,11])
    
  supplier=self.page.FindChild("idStr","vF_VendorASSA",30).value   
  self.log_message_web("Supplier : "+VarToStr(supplier))
  
  location=self.page.FindChild("idStr","vF_Location",30).value  
  self.log_message_web("Location : "+VarToStr(location))
  
  scan_date=self.page.FindChild("idStr","vF_ScanDate",30).value  
  self.log_message_web("Scan Date : "+VarToStr(scan_date))
    
  batchname=self.page.FindChild("idStr","vF_BatchName",30).value   
  self.log_message_web("BatchName : "+VarToStr(batchname))
    
  if VarToStr(batch_name)==VarToStr(batchname):
    self.log_checkpoint_message_web("Batch Name match successfully") 
    
  tot_amt=self.page.FindChild("idStr","vF_AmountTotal",30).value  
  self.log_message_web("Total Amount : "+VarToStr(tot_amt)) 
  
# Click on the left sceen window then do page down
  self.page.FindChild("idStr","verManager-body",40).Click(673, 236)
  self.page.Keys("[PageDown]")
  self.page.Keys("[PageDown]")
  Delay(3000)
  self.page.NativeWebObject.Find("idStr","vF_Button_4","BUTTON").ScrollIntoView()
  Delay(2000)
  self.page.NativeWebObject.Find("idStr","vF_Button_4","BUTTON").Click()
  Delay(1000)  
  self.wait_until_processing()
  self.page.FindChild("idStr","verManager-body",40).Click(673, 236)
  self.page.Keys("[PageDown]")
  Delay(1000)    
  self.log_checkpoint_message_web("Click Replace PO lines table successfull") 
  web_utils.log_checkpoint("Deleted Existing Line Items for the Invoice Successfully",500,self.page)     

  po_line_panel=Sys.Browser("iexplore").Page("*").Panel(0).Panel(0).Form("aspnetForm").Panel(2).Panel(0).Panel(0).Panel("layout").Panel("container").Panel(0).Panel("body").Panel(0).Panel("body").Panel("verManager").Panel("verManager_body").Panel("verificationForm").Panel(0)
  po_line_table=Sys.Browser("iexplore").Page("*").Panel(0).Panel(0).Form("aspnetForm").Panel(2).Panel(0).Panel(0).Panel("layout").Panel("container").Panel(0).Panel("body").Panel(0).Panel("body").Panel("verManager").Panel("verManager_body").Panel("verificationForm").Panel(0).Panel("vF_LineItemstableContainer").Panel(0).Panel(1).Panel(1).Table("vF_LineItems_table")

# Creation of line items based on the spreadsheet
  
  rowno=2
  linerow=0
  while not VarToInt(app.Cells.Item[rowno,1])==0:
    txnum=app.Cells.Item[rowno,1] 
         
    po_line_table.Cell(linerow, 0).Panel(0).FindChild("idStr","vF_LineItems_0_"+VarToStr(linerow),30).Click() # Item desc
    delay(2000)
    po_line_table.Cell(linerow, 0).Panel(0).Textarea("vF_LineItems_0_"+VarToStr(linerow)).Keys(VarToStr(app1.Cells.item[rowno,26]))
    self.log_message_web("Line Description : "+VarToStr(app1.Cells.item[rowno,26]))
    delay(2000)
    
    po_line_table.Cell(linerow, 1).Panel(0).FindChild("idStr","vF_LineItems_1_"+VarToStr(linerow),30).Click()
    delay(2000)
    po_line_table.Cell(linerow, 1).Panel(0).Textarea("vF_LineItems_1_"+VarToStr(linerow)).Keys(VarToStr(app1.Cells.item[rowno,27]))
    self.log_message_web("UOM : "+VarToStr(app1.Cells.item[rowno,27]))
    delay(2000)
    
    po_line_table.Cell(linerow, 2).Panel(0).FindChild("idStr","vF_LineItems_2_"+VarToStr(linerow),30).Click()
    delay(2000)
    po_line_table.Cell(linerow, 2).Panel(0).Textarea("vF_LineItems_2_"+VarToStr(linerow)).Keys(VarToStr(app1.Cells.item[rowno,28]))
    self.log_message_web("Unit Price : "+VarToStr(app1.Cells.item[rowno,28]))
    delay(2000)
    
    po_line_table.Cell(linerow, 4).Panel(0).FindChild("idStr","vF_LineItems_4_"+VarToStr(linerow),30).Click() 
    delay(2000)
    po_line_table.Cell(linerow, 4).Panel(0).Textarea("vF_LineItems_4_"+VarToStr(linerow)).Keys(VarToStr(app1.Cells.item[rowno,30]))
    self.log_message_web("Quantity : "+VarToStr(app1.Cells.item[rowno,30]))
    delay(2000)
    
    web_utils.log_checkpoint("Entered PO line data successfully",500,self.page)
    
    po_line_table.Cell(linerow, 5).Panel(0).FindChild("idStr","vF_LineItems_5_"+VarToStr(linerow),30).DblClick()
    po_line_table.Cell(linerow, 5).Panel(0).FindChild("idStr","vF_LineItems_5_"+VarToStr(linerow),30).Keys("^a[Del]")
    po_line_table.Cell(linerow, 5).Panel(0).FindChild("idStr","vF_LineItems_5_"+VarToStr(linerow),30).Keys(VarToStr(app1.Cells.item[rowno,34]))
    self.log_message_web("Individual Line Total : "+VarToStr(app1.Cells.item[rowno,34]))
    line_total_field = po_line_panel.Panel("vF_LinesTotal_Container").Textbox("vF_LinesTotal")
    line_total_field.Click()
    line_total_field.Keys("[Home]"+"![End]"+"[Del]")
    line_total_field.Keys(VarToStr(app1.Cells.item[rowno,34]))
    line_total = line_total_field.Text
    self.log_message_web("Combined Lines Total : "+VarToStr(line_total))
    delay(2000)
    web_utils.log_checkpoint("Updated Description, UnitPrice, UOM, Line Total Details successfully for Line Number: "+VarToStr(rowno-1),500,self.page) 
        
    if txnum != app.Cells.Item[rowno+1,1]:
      break
    rowno=rowno+1
    linerow=linerow+1
    
# Click on Add line item button
    po_line_panel.Panel("vF_LineItemstableContainer").Panel(1).Panel(8).Click()
    delay(4000)     
  Delay(2000)
  
# Enter Sub total,qst,total
  sub_total = self.page.FindChild("idStr","vF_AmountSubtotal",30)
  sub_total.Click()
  sub_total.Keys("^a[Del]")
  Delay(2000)
  sub_total.Keys(app1.Cells.item[2,16]) 
  self.log_message_web("Sub_total : "+VarToStr(app1.Cells.item[2,16]))
  
  misc_charge = self.page.FindChild("idStr","vF_AmountMisc",30)
  misc_charge.Click()
  misc_charge.Keys("^a[Del]")
  Delay(2000)
  misc_charge.Keys(app1.Cells.item[2,17])
  self.log_message_web("Misc_charge : "+VarToStr(app1.Cells.item[2,17]))
  
  freight = self.page.FindChild("idStr","vF_AmountFreightPrepaidAndAdded",30)
  freight.Click()
  freight.Keys("^a[Del]")
  Delay(2000)
  freight.Keys(app1.Cells.item[2,18])
  self.log_message_web("Freight : "+VarToStr(app1.Cells.item[2,18])) 
   
  us_sales_tax = self.page.FindChild("idStr","vF_AmountTax",30)
  us_sales_tax.Click()
  us_sales_tax.Keys("^a[Del]")
  Delay(2000)
  us_sales_tax.Keys("0.00")
  self.log_message_web("Sales Tax : 0.00") 
  
  discount = self.page.FindChild("idStr","vF_AmountDiscount",30)
  discount.Click()
  discount.Keys("^a[Del]")
  Delay(2000)
  discount.Keys(app1.Cells.item[2,20]) 
  self.log_message_web("Discount : "+VarToStr(app1.Cells.item[2,20]))
  
  gst_or_hst = self.page.FindChild("idStr","vF_AmountMiscGST",30)
  gst_or_hst.Click()
  gst_or_hst.Keys("^a[Del]")
  Delay(2000)
  gst_or_hst.Keys(app1.Cells.item[2,22]) 
  self.log_message_web("GST/HST : "+VarToStr(app1.Cells.item[2,22]))
  
  qst=self.page.FindChild("idStr","vF_AmountMiscQST",30)
  qst.Click()
  qst.Keys("^a[Del]")
  Delay(2000)
  qst.Keys(app1.Cells.item[2,23]) 
  self.log_message_web("QST : "+VarToStr(app1.Cells.item[2,23]))
  
  pst=self.page.FindChild("idStr","vF_AmountMiscPST",30) 
  pst.Click()
  pst.Keys("^a[Del]")
  Delay(2000)
  pst.Keys(app1.Cells.item[2,24]) 
  self.log_message_web("PST : "+VarToStr(app1.Cells.item[2,24]))
  
  tot_amt=self.page.FindChild("idStr","vF_AmountTotal",30)
  tot_amt.Click()
  tot_amt.Keys("^a[Del]")
#  Delay(2000)
#  tot_amt.Keys(app1.Cells.item[2,21])   
#  web_utils.log_checkpoint("Total Amount : "+VarToStr(app1.Cells.item[2,21]),500, self.page) 
  if (self.oper_unit=="US"): 
    taxesAnddis=(VarToFloat(app1.Cells.item[2,17])+VarToFloat(app1.Cells.item[2,18])+VarToFloat(app1.Cells.item[2,19])-VarToFloat(app1.Cells.item[2,20]))
  else:
    taxesAnddis=(VarToFloat(app1.Cells.item[2,17])+VarToFloat(app1.Cells.item[2,18])+VarToFloat(app1.Cells.item[2,22])+VarToFloat(app1.Cells.item[2,24])+VarToFloat(app1.Cells.item[2,23])+VarToFloat(app1.Cells.item[2,19])-VarToFloat(app1.Cells.item[2,20]))
  total=VarToFloat(app1.Cells.item[2,16])+taxesAnddis
  tot_amt.Keys(total)
  self.log_message_web("Invoice Total :"+VarToStr(total))
  delay(2000)
  web_utils.log_checkpoint("Invoice Header Total and Tax Details Entered Successfully",500,self.page)
   
  self.page.FindChild("idStr","vF_Currency",30).Click()
  delay(1000)
  self.page.FindChild("idStr","vF_Currency",30).Keys("^a[Del]")
  delay(2000)
  self.page.FindChild("idStr","vF_Currency",30).Keys("CAD")
  delay(2000)
  self.page.FindChild("idStr","vF_Currency",30).Keys("[Enter]")
  
  if self.page.FindChild("idStr","messagebox-1001",40).Exists:
    pass
  else:
    self.page.FindChild("idStr","vF_Currency",30).Click()
    delay(1000)
    self.page.FindChild("idStr","vF_Currency",30).Keys("[Enter]")
    delay(4000)


## Update Invoice number
#  self.page.FindChild("idStr","verManager-body",40).Click(673, 236)
#  self.page.Keys("[PageUp]")
#  Delay(500)  
#  inv_no=self.page.FindChild("idStr","vF_InvoiceNumber",30)
#  inv_no.Click()
#  Delay(500)
#  inv_no.Keys("[End]")
#  Delay(1000)  
#  inv_no.Keys("_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%H%M%S")+"[Enter]")
#  self.log_message_web("Invoice Number :"+VarToStr(inv_no.contentText))
#  app1.Cells.Item[2,5] =  VarToStr(inv_no.contentText)
  
#  po_no=self.page.FindChild("idStr","vF_PONumber",30)
#  po_no.Click()
#  po_no.Keys("[Enter]")
#  web_utils.log_checkpoint("Validating the invoice information",500, self.page) 
#
#  Delay(5000)
#  self.page.Wait()
#  self.wait_until_page_loaded()  
#  
#  popup=self.page.FindChild("idStr","messagebox-1001",40)
#  if popup.Exists:
#    popup.FindChild("idStr","OK",40).Click()
#    Delay(9000)
#    web_utils.log_checkpoint("Validation Successful. Invoice ready to be released",500, self.page)
#  else:
#    self.log_error_message("Validation failed. Please correct the errors and try again") 
#  self.popup_wnd_click_yes()
#  web_utils.log_checkpoint("Invoice/Batch released Successfully",500, self.page)
#  Delay(6000)
#  popup=self.page.FindChildEx("Name","Panel('messagebox')",30,True,6000)
#  popup.FindChild("idStr","button-1009-btnInnerEl",30).Click()  
#  Delay(3000)
#  self.wait_until_page_loaded()   
#  self.page.FindChild("contentText","Options",40).Click()
#  self.page.FindChild("idStr","item_custom_filter-itemEl",40).Click()
#  Delay(3000)  
#  self.wait_until_processing()
#  self.page.FindChild("idStr","bfdFilter",40).SetText("")  
#  self.page.FindChild("contentText","Apply",40).Click()
#  Delay(3000)
#  self.page.wait()

#message box
  self.page.Wait()
  self.wait_until_page_loaded()  
  popup=self.page.FindChild("idStr","messagebox-1001",40)
  popup_text = popup.contentText
  if popup.Exists: 
    if StrMatches('Error',popup_text) == True:
       self.log_error_message("Validation Errored Out: Resubmit the Page")
       popup.FindChild("idStr","OK",40).Click()
       Delay(9000)
    popup.FindChild("idStr","OK",40).Click()
    Delay(9000)     
  else:
     self.log_error_message("Unable to find the Confirmation Pop Up: Check for Errors")
     
  web_utils.log_checkpoint("Confirmation Pop-up available to release the verified batch "+batch_id,500,self.page)
  self.popup_wnd_click_yes()
  Delay(6000)
  popup=self.page.FindChildEx("Name","Panel('messagebox')",30,True,6000)
  popup.FindChild("idStr","button-1009-btnInnerEl",30).Click()  
  Delay(3000)
  self.wait_until_page_loaded()   
  self.page.wait()
  
  self.wait_until_page_loaded()  
  popup=self.page.FindChild("idStr","messagebox-1001",40)
  popup_text = popup.contentText
  if popup.Exists: 
       popup.FindChild("idStr","OK",40).Click()
       Delay(9000)    
  else:
     pass
  popup=self.page.FindChildEx("Name","Panel('messagebox')",30,True,6000)
  popup.FindChild("idStr","button-1009-btnInnerEl",30).Click()  
  Delay(3000)
  self.wait_until_page_loaded()   
  self.page.wait()
  
  if self.page.FindChild("contentText","Options",40).Exists:
    pass
  else:
    batchname=self.page.FindChild("idStr","vF_BatchName",30).value 
  self.log_checkpoint_message_web("All invoices are verified and released for batch: "+batch_id)
  web_utils.log_checkpoint("Successfully verified and released WFR BatchID: "+batch_id+" for WCC Batch Name: "+batch_name,500,self.page) 

