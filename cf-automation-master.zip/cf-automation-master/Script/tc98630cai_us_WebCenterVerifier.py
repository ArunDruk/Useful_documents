﻿from webCenterVerifier import *


class tc98630cai_us_WebCenterVerifier(webCenterVerifier):
        
 def goto_url(self,url):
   super().goto_url(self.testConfig['ebiz']['WebCentVerUrl'])
      
 def action(self,book): 
  app = book.Sheets.item["Invoice"]
  self.page.FindChild("contentText","Options",40).Click()
  self.page.FindChild("idStr","item_custom_filter-itemEl",40).Click()
  Delay(1000)
  self.wait_until_processing()
  batch_name=VarToStr(app.Cells.item[2,22])
  self.page.FindChild("idStr","bfdFilter",40).SetText("[Capture Batch ID] ='"+VarToStr(batch_name)+"'")
  Delay(2000)
  self.page.FindChild("contentText","Apply",40).Click()
  Delay(1000)
  self.wait_until_processing()
  # Refresh page until expected batch found
  while  Sys.Browser("iexplore").Page("*").EvaluateXPath("//table[@class='x-grid-table x-grid-table-resizer']//span")==None:    
    Sys.Browser("iexplore").Page("*").Keys("[F5]")
    Sys.Browser("iexplore").Page("*").Wait()
    Delay(2000)
    Sys.Browser("iexplore").Page("*").Wait()  
  Delay(2000)    
  self.page.EvaluateXPath("//table[@class='x-grid-table x-grid-table-resizer']//span")[0].Click()
  Delay(1000)
  self.wait_until_page_loaded()
  # drag pdf window
#  self.page.FindChild("idStr", "ctl00_ctl00_ContentPlace_WorkArea_ctl01-splitter", 60).Drag(4, 384, 1779, 49)
  Delay(3000)
#  self.page.Keys("[F5]")
  self.page.Wait()
  self.wait_until_page_loaded()
#  self.page.FindChild("idStr", "ctl00_ctl00_ContentPlace_WorkArea_ctl01-splitter", 60).Drag(7, 343, -1044, -19)
  Delay(3000)  
  inv_type = self.page.FindChild("idStr","vF_InvoiceType-inputEl",30).Text
  if inv_type=="PO":
    self.log_checkpoint_message_web("Expected Invoice Type 'PO' found.") 
  comp_code=self.page.FindChild("idStr","vF_CompanyCode",30).value  
  self.log_message_web("Company Code :"+VarToStr(comp_code))
  op_unit=self.page.FindChild("idStr","vF_OperatingUnit",30).value  
  self.log_message_web("Operating Unit :"+VarToStr(op_unit))
  # Click on the pdf image to clear any unselected text
#  self.page.Find("idStr","ctl00_ctl00_ContentPlace_WorkArea_documentViewerCtl_image",40).Click(395,322)
  self.page.Find("idStr","ctl00_ctl00_ContentPlace_WorkArea_documentViewerCtl_image",40).Click()
  Delay(3000)    
  # Capture Invoice No from PDF
#  inv_pdf_txt=Sys.Browser("iexplore").Page("http://*of.manheim.com/WebVerifier/VerificationView.aspx").Panel(0).Panel(0).Form("aspnetForm").Panel(2).Panel(0).Panel(0).Panel("layout").Panel("container").Panel(0).Panel("body").Panel(1)
#  inv_pdf_txt=OCR.Recognize(inv_pdf_txt).FullText 
#  self.log_message_web("Captured Invoice PDF Text: "+VarToStr(inv_pdf_txt))
#  pos=aqString.Find(inv_pdf_txt,"DATE")  
#  inv_no_pdf=aqString.SubString(inv_pdf_txt,pos+5,9)
  Delay(1000)    
  inv_no=self.page.FindChild("idStr","vF_InvoiceNumber",30)
  self.log_message_web("Invoice Number  "+VarToStr(inv_no.wText()))
#  if VarToStr(inv_no.wText()) == VarToStr(inv_no_pdf):
#    self.log_message_web("Invoice Number displayed correclty from PDF "+VarToStr(inv_pdf_txt))      
  # Invoice Date
  inv_date=self.page.FindChild("idStr","vF_InvoiceDate",30)
  inv_date.Click()
  inv_date.Keys("^a[Del]")
  Delay(1000)
  inv_date.Keys(aqDateTime.Today())
  inv_date.keys("[Tab]")
  # inv_date.Keys("[Enter]")
  Delay(3000)
  inv_date=inv_date.value  
  self.log_message_web("Invoice Date :"+VarToStr(inv_date))   
  # PO Number     
  po_no=self.page.FindChild("idStr","vF_PONumber",30)
  po=po_no.contentText
  # Capture PO from pdf
  
#  pos=aqString.Find(inv_pdf_txt,"Order #")  
#  po_no_pdf=aqString.SubString(inv_pdf_txt,pos+8,6)  
#  self.log_checkpoint_message_web("Invoice number from PDF :"+VarToStr(po_no_pdf)) 
#  if VarToStr(po_no_pdf)==VarToStr(po):
#    self.log_checkpoint_message_web("PDF Invoice number match found successfully") 
  
  # Update PO no
  po_no.Click()
  po_no.Keys("[Home]")
  Delay(1000)
#  po_no.Keys(VarToStr(app.Cells.Item[2,14])) 
  po_no.Keys(VarToStr(app.Cells.Item[2,14])) 
  po_no.Keys("[Del][Del][Del][Del][Del][Del][Del][Del][Del][Del][Tab]")
  #  po_no.Keys("[Enter]") 
  self.log_message_web("Purchase order Number :"+VarToStr(app.Cells.Item[2,14]))  
  # Update Vendor/site  
  self.page.FindChild("idStr","vF_Button_1",30).Click()
  Delay(6000)
  self.wait_until_page_loaded()
  self.page.FindChild("idStr","TextBoxName",30).SetText(VarToStr(app.Cells.Item[2,21]))
  Delay(1000)
  self.page.FindChild("idStr","PushButtonSearch",30).Click()
  Delay(2000)
  self.page.FindChild("idStr","List",30).SelectItem(0)
  Delay(1000)
  self.page.FindChild("idStr","OK",30).Click()  
  Delay(3000)
  self.wait_until_page_loaded()
  self.wait_until_processing()
  vendor=self.page.FindChild("idStr","vF_VendorID",40).contentText
  self.log_message_web("Updated Vendor ID :"+VarToStr(vendor))
  siteID=self.page.FindChild("idStr","vF_SiteID",40).contentText
  self.log_message_web("Updated Site ID :"+VarToStr(siteID))    
  ship_to=self.page.FindChild("idStr","vF_ShipTo",30).value  
  self.log_message_web("Ship To: "+VarToStr(ship_to))
  supplier=self.page.FindChild("idStr","vF_VendorASSA",30).value   
  self.log_message_web("Supplier: "+VarToStr(supplier))
  location=self.page.FindChild("idStr","vF_Location",30).value  
  self.log_message_web("Location: "+VarToStr(location))
  scan_date=self.page.FindChild("idStr","vF_ScanDate",30).value  
  self.log_message_web("Scan Date: "+VarToStr(scan_date))  
  batchname=self.page.FindChild("idStr","vF_BatchName",30).value   
  self.log_message_web("BatchName: "+VarToStr(batchname))  
  if VarToStr(batch_name)==VarToStr(batchname):
    self.log_checkpoint_message_web("PDF Batch Name match found successfully") 
  tot_amt=self.page.FindChild("idStr","vF_AmountTotal",30).value  
  self.log_message_web("Total Amount: "+VarToStr(tot_amt))  
  # Click on the left sceen window then do page down
  self.page.FindChild("idStr","verManager-body",40).Click(673, 236)
  self.page.Keys("[PageDown]")
  self.page.Keys("[PageDown]")
  Delay(3000)
  self.page.NativeWebObject.Find("idStr","vF_Button_2","BUTTON").ScrollIntoView()
  Delay(2000)
  self.page.NativeWebObject.Find("idStr","vF_Button_2","BUTTON").Click()
  Delay(1000)  
  self.wait_until_processing()
  self.page.FindChild("idStr","verManager-body",40).Click(673, 236)
  self.page.Keys("[PageDown]")
  Delay(1000)    
  self.log_checkpoint_message_web("Click Replace PO lines table successfull")     
  # Select all checkboxes  
  po_table=self.page.FindChild("idStr","vF_EBSPOLineItemstableContainer",40)
  for x in range(0,1):
    if po_table.Find("idStr","vF_EBSPOLineItems_0_"+VarToStr(x),40).Exists:
      po_table.Find("idStr","vF_EBSPOLineItems_0_"+VarToStr(x),40).Click()
      self.log_checkpoint_message_web("Successfully selected from PO Lines table")
      self.page.NativeWebObject.Find("idStr","vF_Button_4","BUTTON").Click()
      Delay(2000)      
      amt=self.page.FindChild("idStr","vF_LinesTotal",40)
      self.log_checkpoint_message_web("Line Total Amount from PO Lines table: "+VarToStr(amt.contentText))  
      subTot=self.page.FindChild("idStr","vF_AmountSubtotal",40)
      self.log_checkpoint_message_web("Sub Total Amount updated from PO Lines table: "+VarToStr(amt.contentText))
      subTot.Click()  
      subTot.Keys("[Home]"+amt.Text+".00[Del][Del][Del][Del][Del][Del][Del][Del][Del][Del][Tab]")
      Tot=self.page.FindChild("idStr","vF_AmountTotal",40)
      self.log_checkpoint_message_web("Total Amount updated from PO Lines table: "+VarToStr(amt.contentText)) 
      Tot.Click() 
      Tot.Keys("[Home]"+amt.Text+".00[Del][Del][Del][Del][Del][Del][Del][Del][Del][Del][Tab]")      
      self.log_checkpoint_message_web("Line Amount from PO Lines table: "+VarToStr(amt.contentText))     
    else:
      break      
  Delay(2000)
  
  # Update Invoice number
  self.page.FindChild("idStr","verManager-body",40).Click(673, 236)
  self.page.Keys("[PageUp]")
  Delay(500)  
  inv_no=self.page.FindChild("idStr","vF_InvoiceNumber",30)
  inv_no.Click()
  Delay(500)
  inv_no.Keys("[End]")
  Delay(1000)  
  inv_no.Keys("_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%H%M%S")+"[Enter]")
  self.log_message_web("Invoice Number :"+VarToStr(inv_no.contentText))
  app.Cells.Item[2,13] =  VarToStr(inv_no.contentText)
#  inv_no.Keys("[Enter]")
  Delay(5000)
  self.page.Wait()
  self.wait_until_page_loaded()  
  popup=self.page.FindChild("idStr","messagebox-1001",40)
  if popup.Exists:
    popup.FindChild("idStr","OK",40).Click()
    Delay(9000)
  self.popup_wnd_click_yes()
  Delay(6000)
  popup=self.page.FindChildEx("Name","Panel('messagebox')",30,True,6000)
  popup.FindChild("idStr","button-1009-btnInnerEl",30).Click()  
  Delay(3000)
  self.wait_until_page_loaded()   
  self.page.FindChild("contentText","Options",40).Click()
  self.page.FindChild("idStr","item_custom_filter-itemEl",40).Click()
  Delay(3000)  
  self.wait_until_processing()
  self.page.FindChild("idStr","bfdFilter",40).SetText("")  
  self.page.FindChild("contentText","Apply",40).Click()
  Delay(3000)
  self.page.wait()
