﻿import gvar

### In this method objects for below pages have been captured ###

#PROJECT > ATTACHMENTS page

def prj_attachments_page_link():
  prop_names = ["idStr","contentText","ObjectType"]
  prop_values = ["PROJ_ATTACHMENT_SUBMENU","Attachments","Link"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def prj_copyattach_dropdown():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["copyAttachChoice","Select"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def prj_templatename_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["projTemplateName","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def prj_template_copy_button():
  prop_names = ["idStr","ObjectType","ObjectLabel"]
  prop_values = ["copySubmit","Button","Copy"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def attchment_category_dropdown():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["attachmentCategory","Select"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
  

def attch_category_go_dropdown():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["attachmentCategory","Select"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
  
  
def attch_category_go_button():
  prop_names = ["contentText","ObjectIdentifier","ObjectType"]
  prop_values = ["Go","ViewByAttCatGoBN","Button"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
  
  
def add_attachment_dropdown():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["AttachFunction","Select"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def add_attchment_go_button():
  prop_names = ["contentText","ObjectIdentifier","ObjectType"]
  prop_values = ["Go","AttachCreateGo","Button"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def attch_srch_more_criteria_link():
  resource_breakdown_structures = gvar.dataprep['page'].NativeWebObject.Find("contentText","Show More Search Criteria","A")
  return resource_breakdown_structures
  

def attch_srch_criteria_name_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["SearchName","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
  

def attch_srch_criteria_desc_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["SearchDescription","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def attch_srch_criteria_lastmodifiedby_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["SearchLastUpdatedBy","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def attch_srch_criteria_lastmodifieddate_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["SearchLastUpdateDate","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
  

def attch_srch_criteria_clear_button():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["ClearButton","Button"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def attch_srch_criteria_go_button():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["SearchGo","Button"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def prj_show_key_notation_link():
  resource_breakdown_structures = gvar.dataprep['page'].NativeWebObject.Find("contentText","Show Key Notation","A")
  return resource_breakdown_structures

  
