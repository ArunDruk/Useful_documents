﻿import gvar
from gvar import config as CONFIG 
import json 
import tc_logs
import datetime 
import odm_datatype
from random import * 

__HEAD  = tc_logs.header_name
__PRINT = tc_logs.checkpt_with_no_picture
__VALIDATE = tc_logs.validation
__ERROR    = tc_logs.error_with_no_picture
__MESSAGE  = tc_logs.msg_with_no_picture
__POST = aqHttp.CreatePostRequest
__PUT  = aqHttp.CreateRequest
__GET  = aqHttp.CreateGetRequest
__path = aqFileSystem.IncludeTrailingBackSlash(Project.Path+'DataSheets\\API_Response')
__HTTP_METHOD = {'POST':__POST,'PUT' :__PUT,'GET' :__GET }


    
def post_or_put(api_name,payload):
  return __common_code(*['POST',api_name,payload,None])
   
def put(api_name,payload):
  return __common_code(*['PUT',api_name,payload,None])
        
def get(api_name, query, expected_status = "200"):
       
      if api_name and query:
          return __common_code(*['GET',api_name,None,query])
      else:
       odm_datatype.update_status('Failed') 
       __ERROR("Pls provide valid paramters - api_name or Query ")
        
def header_log(api_name, query=None):
    
    __VALIDATE(f" **** REQUEST SECTION ***** ")
    with open(__path+'\\request','w') as request_file:
      request_file.write(f"End Point : '{CONFIG['API']['ep']}'\n")
      if query:
        request_file.write(f"Query : {query}\n")                                                            
      request_file.writelines([f"{key} : '{item}'\n" 
        for key,item in CONFIG[api_name].items() if key != 'pswd']) 
    if 'custom_head' in gvar.dataprep:
       tc_logs.log_file(__path+'\\request',f"{gvar.dataprep['custom_head'].upper()} HEADER DETAILS")
       Log.File(Project.Path+'\\DataSheets\\API_Response\\request',"Request/Response File Attached")
    else:
       tc_logs.log_file(__path+'\\request',f"{api_name.strip().upper()} HEADER DETAILS")
      
def payload_log(api_name,payload):

    with open(__path+'\\payload','w') as request_file:
     request_file.write(payload)
    if 'custom_head' in gvar.dataprep.keys():
       tc_logs.log_file(__path+'\\payload',f"{gvar.dataprep['custom_head'].upper()} PAYLOAD DETAILS")
       Log.File(Project.Path+'\\DataSheets\\API_Response\\payload',"Request/Response File Attached")
    else:
       tc_logs.log_file(__path+'\\payload',f"{api_name.strip().upper()} PAYLOAD DETAILS") 

def __common_code(action,api_name,payload=None,qry=None):
    
    if action != 'GET':
      payload = __validate_post_params(api_name,payload)
    
    if 'custom_head' in gvar.dataprep:
       __HEAD(f"{gvar.dataprep['custom_head']}{action} METHOD EXECUTION ")
    else:
       __HEAD(f"{api_name.upper()} {action} METHOD EXECUTION ")       

    resource,address,userid, pswd = [ 
      CONFIG[api_name]['resource'], 
      CONFIG['API']['ep'] + CONFIG[api_name]['resource'],
      CONFIG[api_name]['usrid'],CONFIG[api_name]['pswd']]

    header_log(api_name)
    if qry: 
      address += qry
    
    if action != 'GET': payload_log(api_name,payload)
    
    method_args = [address,userid,pswd]
    if action in('PUT'): method_args.insert(0,"PUT")
#    if action in('GET'): 
#          request_obj = set_header_hard_code(address,userid,pswd,api_name)
#    else:
    request_obj = set_request_header(
           __HTTP_METHOD[action](*method_args),api_name)
         

     
    gvar.dataprep['currentapi'] = api_name    

    return __response(
    request_obj.Send(payload) if action != 'GET' else request_obj.Send()
                        ,api_name,"200")

def __validate_post_params(api_name,payload):
   
    if api_name and payload:
        post_2_text(payload,api_name)
        payload = json.dumps(payload)
        return payload 
    else:
       odm_datatype.update_status('Failed') 
       __ERROR("Pls provide valid paramters - payload or api_name")
  
def set_request_header(aqHttpRequest, api_name):
  
     [  aqHttpRequest.SetHeader( key, 
                  CONFIG[api_name][key] ) 
          for key in ['accept','Version',
               'Manheim-Employee-ID','Content-Type'] 
               if key in CONFIG[api_name]] 
     
     return aqHttpRequest  

def __response(aqHttpResponse,api_name,status="200"):

      validate_response_status_code(aqHttpResponse,status)
      return json_2_dict(aqHttpResponse,api_name)

def validate_response_status_code(aqHttpResponse, expected_status):
    
    __VALIDATE(f" **** RESPONSE SECTION *****")  
    __PRINT(f"Actual status code : {VarToStr(aqHttpResponse.StatusCode)}")
      
    if (VarToStr(aqHttpResponse.StatusCode) == expected_status):
       return aqHttpResponse
    else:
       json_2_dict(aqHttpResponse,gvar.dataprep['currentapi'])
       odm_datatype.update_status('Failed')
       __ERROR(f"Expected status: '{expected_status}' but actual status code: '{VarToStr(aqHttpResponse.StatusCode)}'")
        
def message_checkpts(aqHttpResponse):

  __PRINT(f"Response Header information: {VarToStr(aqHttpResponse.AllHeaders)}")
  __PRINT(f"Response status code: {VarToStr(aqHttpResponse.StatusCode)}")
  __PRINT(f"Response status Text: {VarToStr(aqHttpResponse.StatusCode)}")
  __PRINT(f"Response details: {VarToStr(aqHttpResponse.Text)}")

def json_2_dict(aqHttpResponse,api_name):
  
  response = None
  path = __path+"response"
  aqHttpResponse.SaveToFile(path) 
  with open(path) as json_file:
    response = json.load(json_file)
  with open(path,"w") as txt_file:
    txt_file.write(str(response))
  
  if 'custom_head' in gvar.dataprep:
     tc_logs.log_file(path,f"{gvar.dataprep['custom_head'].upper()} RESPONSE DETAILS")
  else:
    tc_logs.log_file(path,f"{api_name.strip().upper()} RESPONSE DETAILS")
  
  return response
  
def post_2_text(text,api_name):
  with open(__path+api_name, 'w') as file:
    file.write(json.dumps(text))
   
def response2textFile(aqHttpResponse, path):
  if aqHttpResponse and path:
        pass
  else:
    odm_datatype.update_status('Failed') 
    __ERROR("Pls provide valid paramters - Response or Path")
  aqHttpResponse.SaveToFile(path) 
  with open(path) as json_file:
    response = json.load(json_file)
  return response
 
def load_input_payload_to_gvar(payload):
     if payload:
        for key , value in payload.items():
           gvar.dataprep[key] = value
    
def log_message(aqHttpResponse):
    Log.Message(aqHttpResponse.AllHeaders)
    Log.Message(aqHttpResponse.GetHeader("Content-Type"))
    Log.Message(aqHttpResponse.StatusCode)  
    Log.Message(aqHttpResponse.StatusText) 
    Log.Message(aqHttpResponse.Text) 
    Log.Message(aqHttpResponse.GetHeader("Date"))
    
    
def set_header_hard_code(address,userid,pswd,api_name):
  aqHttpRequest = aqHttp.CreateGetRequest(address,userid,pswd)
  aqHttpRequest.SetHeader("Content-Type", "application/json")
  aqHttpRequest.SetHeader("resource", CONFIG[api_name]['resource'])
#  aqHttpRequest.SetHeader("usrid", "cpcsauser")
  aqHttpRequest.SetHeader("Accept", "application/json")
#  aqHttpRequest.SetHeader("pswd", "v7QfvhYsHyw5@Sqv")
  if 'manheim-employee-id' in CONFIG[api_name]:
    aqHttpRequest.SetHeader("manheim-employee-id", CONFIG[api_name]['manheim-employee-id'])
  aqHttpRequest.SetHeader("Version", CONFIG[api_name]['Version'])
  return aqHttpRequest
