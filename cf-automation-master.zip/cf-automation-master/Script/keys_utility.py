﻿import gvar

# This is a helper module to simulate keyboard strokes within Oracle Forms, which are shortcuts to clicking actual buttons. 
# The methods are defined by the actual keys that are pressed, which will simulate the action based on the form being accessed.


def press_tab():
    gvar.dataprep['jformobject'].Keys("[Tab]")
    
def press_tab_n_times(n):
    while n > 0:
        gvar.dataprep['jformobject'].Keys("[Tab]")
        n-=1
        
def press_alt_m():
    gvar.dataprep['jformobject'].Keys("~m")
  
def press_alt_i():
    gvar.dataprep['jformobject'].Keys("~i")

def press_alt_p():
    gvar.dataprep['jformobject'].Keys("~p")
  
def press_alt_g():
    gvar.dataprep['jformobject'].Keys("~g")

def press_alt_n():
    gvar.dataprep['jformobject'].Keys("~n")
               
def press_alt_r():
    gvar.dataprep['jformobject'].Keys("~r")
                 
def press_alt_y():
    gvar.dataprep['jformobject'].Keys("~y")
             
def press_alt_f():
    gvar.dataprep['jformobject'].Keys("~f")
         
def press_a():
    gvar.dataprep['jformobject'].Keys("a")

def press_alt_o():
    gvar.dataprep['jformobject'].Keys("~o")

def press_enter():
     gvar.dataprep['jformobject'].Keys("[Enter]")
    
def press_x():
   gvar.dataprep['jformobject'].Keys("x")
   
def close_form():
   gvar.dataprep['jformobject'].Keys("~[F4]")
   
def close_oracle_forms():
  press_alt_f()
  press_x()
  press_alt_o()
  
def press_up_arrow_n_times(n):
  while n > 0:
    gvar.dataprep['jformobject'].Keys("[Up]")
    n -= 1

def press_ok_button():
    gvar.dataprep['jformobject'].Keys("~o")

    

    

