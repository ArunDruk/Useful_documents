﻿import gvar

### In this method objects for below pages have been captured ###

#PROJECT > SETUP > RESOURCE BREAKDOWN STRUCTURES link page

  
def prj_setup_resource_remove_button():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["Remove","Button"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def prj_setup_resource_setprimary_button():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["SetPrimary","Button"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def prj_setup_atg_resource_bkdwn_structure_radiobutton():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["AssignRBSProjTable:SelectCol:0","RadioButton"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
  
