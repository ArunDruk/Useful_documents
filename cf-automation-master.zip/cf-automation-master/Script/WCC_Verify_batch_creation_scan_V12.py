﻿from webcentercapture_V12 import *
import configparser
import file_system_utils
import wcc_login_page_v12
import wcc_home_page_v12
import os
import web_utils
from dbhelper import *


class WCC_Verify_batch_creation_scan_V12(Webcentercapture_V12):
  
 def goto_url(self,url):
  pass
   
 def action(self,book):
   
  app = book.Sheets.item["mail_wcc"] 
  
  file_system_utils.create_folder("C:\\TC_Logs")
  src_folder=Project.Path+"DataSheets\\WCI\\"
  file_path=src_folder+VarToStr(app.Cells.item[2,4])
  
  #close all open sessions and make current session active  
  Webcentercapture_V12.use_current_session()
  
  #Get location and set the key for searching the batches
  location = VarToStr(app.Cells.item[2,3])[2:]
  ocr_key = aqString.SubString(location,0,2)
  Webcentercapture_V12.set_entity_based_on_location(location)
  Delay(3000)
  
  #verify whether the batch_list frame exists
  Webcentercapture_V12.verify_batch_list_frame()
  Delay(5000)
  
  Webcentercapture_V12.capture_inv_create_batch(file_path,app)
  #Drag the scroll bar up 
  gvar.dataprep['capt_wdw'].Keys("[PageUp]")
  
  #select the first batch
  Webcentercapture_V12.select_first_batch(ocr_key)
  Delay(3000)
  
  #Verify whether batch created and the batch details 
  Webcentercapture_V12.verify_batch_by_batch_name(ocr_key,app)
  
  # Verify and Update Document Profile and Release the Batch to WFR Form for Verification:       
  Webcentercapture_V12.verify_update_document_profile_details(app)
  Delay(1000)
  
  # select batch header and release the selected batch:
  Webcentercapture_V12.select_batch_for_release(ocr_key,app) 
  
  # validate batch release
  Webcentercapture_V12.validate_batch_release(app,ocr_key)
  
 

  
  
  