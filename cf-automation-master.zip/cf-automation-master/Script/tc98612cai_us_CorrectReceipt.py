﻿from ebiz import *
import web_utils
import form_utils
import file_system_utils
import ebiz


class tc98612cai_us_CorrectReceipt(Ebiz):
  global rowno, RowCount
  
  def login(self):
    self.login_user="rmaran"
    super().login()
  
  
  def action(self,book):
    rowno = 2
    app = book.Sheets.item["Invoice"]
    app1 = book.Sheets.item["Requisition"]    
    RowCount = app.UsedRange.Rows.Count    
    self.wait_until_page_loaded()
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" iPROC USER')]")  
    Delay(4000)
    web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'iProcurement Home Page')]")
    web_utils.clk_link_by_xpath(self.page,"//a[@id='ICXPOR_RECEIVING_HOME']")
    web_utils.clk_link_by_xpath(self.page,"//a[@id='CorrectReceiptsLink1']")
    web_utils.set_text(self.page,"//input[@id='ReceiptNumber']",app.cells.Item[rowno,18])
    web_utils.clk_btn_by_xpath(self.page,"//table[@id='SearchMessageComponentLayout']//button[contains(text(),'Go')]")  
    self.wait_until_page_loaded()
    index = 0
    var = VarToStr(app.Cells.item[rowno,19])
    var1 = var.split(',')
    temp = 0
    while rowno<RowCount+1:
      unit_price = aqConvert.VarToInt(app1.Cells.item[rowno,7])      
      web_utils.set_text(self.page,"//span[@id='ResultsTableRN']//input[@name='N3:QuantityCorrected:"+aqConvert.VarToStr(index)+"']",var1[index])    
      amount = aqConvert.StrToInt(var1[index])*unit_price
      temp = StrToInt(temp)+amount
      index = index+1
      rowno = rowno+1
    app.Cells.item[2,15] = temp
    self.page.Keys("~c")
    self.wait_until_page_loaded()
    self.page.Keys("~m")
    self.wait_until_page_loaded()
    conf_msg=self.page.NativeWebObject.Find("innerText", "Your corrections have been submitted.", "div")
    self.log_message_web("Confirmation message found: "+aqConvert.VarToStr(conf_msg))  
    book.save()
    del app,app1,RowCount,var,var1,index,rowno,conf_msg
