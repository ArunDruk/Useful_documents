﻿
from ebiz import *
import web_utils 

#Author:            Prabhakaran Rajendran
#TestCaseID:        TC80901
#UserStoryID:       US188373
#Reviewed_By:       Syed,Husain



# class defined for this action/function and will be called from driverchain(execute() method)
class tc98618cai_us_create_catalog_req(Ebiz): 
  global rowno, RowCount, rel, txnum, app

  # Overrite login function 
  def login(self):
    self.login_user="ajyachera"
    super().login()

  
# this method will be called from base class() in the framework  
# action method to call all sub functions(methods)

  def action(self,book): 
      rowno=2
      req = 0
      app = book.Sheets.item["Requisition"]
      RowCount = app.UsedRange.Rows.Count
      txnum = VarToInt(app.cells.Item[rowno,1])      
      while rowno<(RowCount+1):
        Log.Enabled=True 
        Log.Message("Creating Requisition No:"+IntToStr(req+1))
        Log.Enabled=False 
        self.navigate_iproc(rowno)
        rowno = self.cat_request(txnum,rowno,app)
        self.req_info(app,rowno)
        self.get_reqno(rowno,app)
        rowno=rowno+1
        req = req+1 
        txnum=txnum+1
      book.save()
#      del app,txnum,RowCount,rel,rowno
  #method to navigate 'iprocurement non catalog requisition' entry page
  def navigate_iproc(self,rowno):    
    Delay(4000)
    if rowno ==2:
      self.page.wait()
      self.page.EvaluateXPath("//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" iPROC USER')]")[0].scrollIntoView() 
      Delay(2000)
      self.page.EvaluateXPath("//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" iPROC USER')]")[0].Click() 
      Delay(2000)
    self.wait_until_page_loaded()
    self.page.EvaluateXPath("//table[@id='respList']//div[contains(text(),'iProcurement Home Page')]")[0].Click() 
    Delay(2000)
    self.wait_until_page_loaded()
    self.page.EvaluateXpath("//a[@id='ICXPOR_STORES']")[0].Click()
    Delay(6000)
    self.page.wait()
    self.wait_until_page_loaded()
    obj=self.page.NativeWebObject.Find("contentText","Prosys","A")
    if obj.Exists:
      self.log_checkpoint_message_web("External Store Available: Prosys")
    else:
      self.log_error_message("Unable to Find External Store to Order Catalog Items")
      
    self.page.NativeWebObject.Find("contentText","Prosys","A").Click()
    self.wait_until_page_loaded()
    
  def cat_request(self,txnum,rowno,app): 
    Delay(5000)
#    prosys = Sys.Browser("iexplore").Page("https://interconnect-uat.pivotts.com/*")
    prosys=Sys.Browser("iexplore").WaitPage("https://interconnect-uat.pivotts.com/*",40000)
    web_utils.wait_until_page_loaded(prosys)
    prosys.wait()
    Delay(8000)
    if prosys.NativeWebObject.Find("idStr","mainContent","div").Exists:
      self.log_checkpoint_message_web("Prosys Store Page Launched Successfully")
    else:
      self.log_error_message("Unable to Launch Prosys Store Page")

    while (VarToString(app.Cells.Item[rowno, 1])== IntToStr(txnum)):  
         
      prosys.Find("idStr","mainSearchProductSuggestFieldLg",50).Click()
      Delay(2000)
      prosys.Find("idStr","mainSearchProductSuggestFieldLg",50).Keys(app.Cells.Item[rowno,3])
      Delay(1000)
      prosys.Find("idStr","mainSearchButtonLg",50).Click()
      Delay(3000)
      web_utils.wait_until_page_loaded(prosys)
      
#      pro = ("ObjectIdentifier","ObjectType","Name")
#      val = (0,"Textbox","Textbox(0)")
#      prosys.FindChildEx(pro,val,60,True,60000).Click()
      prosys.EvaluateXpath("//input[@placeholder='Qty']")[0].Keys(app.Cells.Item[rowno,5])
      Delay(2000)
#      prosys.Find(pro,val,50).Keys(app.Cells.Item[rowno,5])
#      Delay(1000)
      prosys.EvaluateXpath("//button[@class='btn btn-primary btn-block']")[0].Click()
      Delay(2000)
      self.log_checkpoint_message_web("Added Item "+VarToStr(app.Cells.Item[rowno,3])+" to Cart")
      prosys.Find("idStr","mainSearchButtonLg",50).Keys("[BS]")
      rowno = rowno + 1

  
    web_utils.wait_until_page_loaded(prosys)
    Delay(1000)
    prosys.EvaluateXpath("//a[@class='blue cartNavigatorTrigger highlightBgOnHover']")[0].Click()
    Delay(2000)
    web_utils.wait_until_page_loaded(prosys)
    prosys.EvaluateXpath("//button[@ng-show='vm.cartViewOptionsDto.DisplayReturnToProcurement']")[0].Click()
    Delay(4000)
    self.page = Sys.Browser("iexplore").Page("*")
    self.page.wait()
    obj = self.page.NativeWebObject.Find("contentText","Submit","button")
#    while not obj.Exists:
    i = 0
    while Sys.Browser("iexplore").Page("*").EvaluateXPath("//table[@id='PageButtonBarRn']//button[@id='Submit']")==None:
        delay(2000)
        i+=1
        if i == 20:
          self.log_error_message("Procured Items not returned to Oracle Requisition Cart")
#        obj = self.page.NativeWebObject.Find("contentText","Checkout","button")
    self.log_message_web("Added Items Ordered from Prosys store to Oracle IProc. Requisition Cart")
#    obj.Click()
    self.wait_until_page_loaded()
    rowno=rowno-1
    return rowno
  
  def req_info(self,app,rowno):
      fut_date = aqDateTime.AddDays(aqDateTime.Now(),3)
      fut_date1 = aqConvert.DateTimeToFormatStr(fut_date,"%d-%b-%Y %H:%M:%S")
      Delay(2000)  
      self.wait_until_page_loaded()    
      self.page.EvaluateXpath("//table[@id='LinesAdvTblRN:Content']//input[@id='LinesAdvTblRN:triState']")[0].Click()
      Delay(2000)
      self.page.EvaluateXpath("//div[@id = 'loadDiv:LinesAdvTblRN']//span[@id='tblActionsFlowLayout']//button[@id='updateButton']")[0].Click()
      Delay(2000)
      self.wait_until_page_loaded()
      cart_box_multiple = self.page.FindChildEx("idStr","popupmultipopup",60,True, 40000)
      cart_box_single = self.page.FindChildEx("idStr","popupsinglepopup",60,True, 40000)
      Delay(2000) 
#      obj=self.page.Find("idStr","NeedByDate",50)
      if cart_box_multiple.Visible == True:
        self.log_checkpoint_message_web("Requisition Information Popup for Multiple Lines Launched Successfully")
        
        Sys.HighlightObject(cart_box_multiple)
        cart_box_multiple.EvaluateXpath("//table[@id = 'BillingLabeledFieldLayout']//input[@id = 'ProjectOnUpdateMultipleExpense']")[0].Click()
        Delay(1000)
        cart_box_multiple.EvaluateXpath("//table[@id = 'BillingLabeledFieldLayout']//input[@id = 'ProjectOnUpdateMultipleExpense']")[0].Keys(app.Cells.Item[rowno,11])
        cart_box_multiple.Keys("[Tab]")
        cart_box_multiple.Keys("[Tab]")
        Delay(1000)
        cart_box_multiple.EvaluateXpath("//table[@id = 'BillingLabeledFieldLayout']//input[@id = 'TaskExpense']")[1].Keys(app.Cells.Item[rowno,12])
        Delay(1000)
        cart_box_multiple.Keys("[Tab]")
        cart_box_multiple.Keys("[Tab]")
        Delay(1000)
        cart_box_multiple.EvaluateXpath("//table[@id = 'BillingLabeledFieldLayout']//input[@id = 'ExpenditureTypeOnUpdateMultiple']")[1].Keys(app.Cells.Item[rowno,13])
        Delay(1000)
        cart_box_multiple.Keys("[Tab]")
        cart_box_multiple.Keys("[Tab]")
        Delay(1000)
        cart_box_multiple.EvaluateXpath("//table[@id = 'BillingLabeledFieldLayout']//input[@id = 'ExpenditureOrg']")[0].Keys(app.Cells.Item[rowno,14])
        Delay(1000)
        cart_box_multiple.Keys("[Tab]")
        Delay(2000)
        currentDate = aqDateTime.Today()
        currentDate1 = aqConvert.DateTimeToFormatStr(currentDate,"%d-%b-%Y %H:%M:%S")
        Delay(1000)
        cart_box_multiple.EvaluateXpath("//table[@id = 'BillingLabeledFieldLayout']//input[@id = 'ExpenditureItemDate']")[0].Keys(currentDate1)
        Delay(1000)
        cart_box_multiple.FindChild("idStr","NeedByDate",20).Click()
        Delay(1000)
        cart_box_multiple.FindChild("idStr","NeedByDate",20).Keys(fut_date1)
        Delay(2000)
        self.wait_until_page_loaded()
        self.log_message_web("Project Details details entered for the Requisition")
        delay(2000)
        cart_box_multiple.FindChildEx("contentText","Apply",60,True, 40000).Click()  
        Delay(7000)
        self.wait_until_page_loaded()
        self.page.EvaluateXPath("//table[@id='PageButtonBarRn']//button[@id='Submit']")[0].Click()
        self.log_message_web("Requisition submitted successfully")  
        Delay(2000)
        self.wait_until_page_loaded()
      elif cart_box_single.Visible == True:
        self.log_checkpoint_message_web("Requisition Information Popup for Single Line Launched Successfully")
        
        Sys.HighlightObject(cart_box_single)
        cart_box_single.EvaluateXpath("//div[@id = 'BillingRN']//input[@id='BillingTblRN:ProjectOnDist:0']")[0].Click()
        Delay(1000)
        cart_box_single.EvaluateXpath("//div[@id = 'BillingRN']//input[@id='BillingTblRN:ProjectOnDist:0']")[0].Keys(app.Cells.Item[rowno,11])
        cart_box_single.Keys("[Tab]")
        cart_box_single.Keys("[Tab]")
        Delay(1000)
        cart_box_single.EvaluateXpath("//div[@id = 'BillingRN']//input[@id='BillingTblRN:Task:0']")[0].Keys(app.Cells.Item[rowno,12])
        Delay(1000)
        cart_box_single.Keys("[Tab]")
        cart_box_single.Keys("[Tab]")
        Delay(1000)
        cart_box_single.EvaluateXpath("//div[@id = 'BillingRN']//input[@id='BillingTblRN:ExpenditureType:0']")[0].Keys(app.Cells.Item[rowno,13])
        Delay(1000)
        cart_box_single.Keys("[Tab]")
        cart_box_single.Keys("[Tab]")
        cart_box_single.EvaluateXpath("//div[@id = 'BillingRN']//input[@id='BillingTblRN:ExpenditureOrg:0']")[0].Keys(app.Cells.Item[rowno,14])
        Delay(1000)
        cart_box_single.Keys("[Tab]")
        Delay(2000)
        currentDate = aqDateTime.Today()
        currentDate1 = aqConvert.DateTimeToFormatStr(currentDate,"%d-%b-%Y %H:%M:%S")
        cart_box_single.EvaluateXpath("//div[@id = 'BillingRN']//input[@id='BillingTblRN:ExpenditureItemDate:0']")[0].Keys(currentDate1)
        Delay(1000)
        cart_box_single.FindChild("idStr","NeedByDate",20).Click()
        Delay(1000)
        cart_box_single.FindChild("idStr","NeedByDate",20).Keys(fut_date1)
        Delay(2000)
        self.wait_until_page_loaded()
        self.log_message_web("Project Details details entered for the Requisition")
        delay(2000)
        cart_box_single.FindChildEx("contentText","Apply",60,True, 40000).Click()  
        Delay(7000)
        self.wait_until_page_loaded()
        self.page.EvaluateXPath("//table[@id='PageButtonBarRn']//button[@id='Submit']")[0].Click()
        self.log_message_web("Requisition submitted successfully") 
        Delay(2000)
        self.wait_until_page_loaded()
      else: self.log_error_message("Unable to Launch Requisition Information PopUp") 
      
  
  def get_reqno(self,rowno,app):
      self.wait_until_page_loaded()
      confirm_msg = self.page.Find("idStr","iframedefaultDialogPopup",30)      
      obj=confirm_msg.Find("idStr","ApproverText",50)
      if obj.Exists:
        self.log_message_web("Requisition No. Generated Successfully: Validated and Captured the Req.number")
      else:
        self.log_message_web("Unable to Complete Creating Catalog Requisition")
      
      Rno = confirm_msg.Find("idStr","ApproverText",30).contentText
      Delay(1000)
      Rno1 = aqString.SubString(Rno,12,5)
      self.log_message_web("Catalog Requisition:" + Rno1)      
      delay(1000)    
      app.Cells.Item[rowno,15] = Rno1
      Delay(2000)     
      confirm_msg.Find("contentText","Continue Shopping",30).Click()
      delay(2000) 
      self.page.Find("contentText","Home",20).Click()
      self.wait_until_page_loaded()
    
    
def test():
  
        cart_box_single = Sys.Browser("iexplore").page("*").FindChildEx("idStr","popupsinglepopup",60,True, 40000)
        cart_box_single.EvaluateXpath("//div[@id = 'BillingRN']//input[@id='BillingTblRN:ProjectOnDist:0']")[0].Click()
        Delay(1000)
#        cart_box_single.EvaluateXpath("//div[@id = 'BillingRN']//input[@id='BillingTblRN:ProjectOnDist:0']")[0].Keys(app.Cells.Item[rowno,11])
        cart_box_single.Keys("[Tab]")
        cart_box_single.Keys("[Tab]")
        Delay(1000)
        cart_box_single.EvaluateXpath("//div[@id = 'BillingRN']//input[@id='BillingTblRN:Task:0']")[0].Click()
        Delay(1000)
        cart_box_single.Keys("[Tab]")
        cart_box_single.Keys("[Tab]")
        Delay(1000)

