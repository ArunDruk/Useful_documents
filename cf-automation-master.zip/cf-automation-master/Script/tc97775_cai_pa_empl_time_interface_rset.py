﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils
import winscp_utility
import form_utils
import web_utils


###This testcase is to place the CAISNOW_US_LABOR_Test.txt file in the GL inbound directory using WINSCP### 
###and submit CAI PA Employee Time Interface Request Set and capture logs and validate Employee Time record in CAI EBIZ###

class tc97775_cai_pa_empl_time_interface_rset(Ebiz):

  op_log_path="C:\\TC_Logs"
  empl_time_files="C:\\EMPL_TIME_Files"

  def login(self):
    self.login_user="naggarwal"
    super().login()

  def action(self,book):
    global jrnl_imp_pro 
    self.modify_empl_time_file_details()
    self.place_empl_time_file_winscp()

### Modifying CAISNOW_US_LABOR_Test.txt file 
  def modify_empl_time_file_details(self):
    file_name= Project.Path+"DataSheets\\Oracle-PA-Other\\CAISNOW_US_LABOR_Test.txt"
    week_start_date = aqConvert.DateTimeToFormatStr(aqDateTime.AddDays(aqDateTime.Today(), -aqDateTime.GetDayOfWeek(aqDateTime.Today())+1),"%m/%d/%Y")
    week_end_date = aqConvert.DateTimeToFormatStr(aqDateTime.AddDays(aqDateTime.Today(), -aqDateTime.GetDayOfWeek(aqDateTime.Today())+7),"%m/%d/%Y")
    work_date = aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%m/%d/%Y")
    amt = (aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%S"))
    fo=open(file_name,"r+")
    lines=fo.readlines()  
    fo.close()
    fo=open(file_name,"r+")
    data=fo.read()
    #fo.seek(504,0)
    #fo.write(amt)
    fo.seek(512,0)
    fo.write(work_date) 
    fo.seek(525,0)
    fo.write (week_end_date)
    fo.seek(538,0)
    fo.write (week_start_date)
    fo.seek(551,0)
    fo.write (week_end_date)
    fo.seek(564,0)
    fo.write (week_end_date)
    fo.close()
    file_system_utils.create_folder(self.empl_time_files)
    file_exist=aqFileSystem.FindFiles("C:\\EMPL_TIME_Files","CAISNOW_US_LABOR_Test.txt")
    if file_exist != None:
     aqFileSystem.DeleteFile("C:\\EMPL_TIME_Files\\CAISNOW_US_LABOR_Test.txt")
    aqFileSystem.CopyFile(Project.Path+"DataSheets\\Oracle-PA-Other\\CAISNOW_US_LABOR_Test.txt", "C:\\EMPL_TIME_Files\\CAISNOW_US_LABOR_Test.txt")
    log_path = ("C:\\EMPL_TIME_Files\\CAISNOW_US_LABOR_Test.txt")
    Log.Enabled=True
    Log.File(log_path, "CAISNOW_US_LABOR Import File Attached")
    Log.Enabled=False 


# Placing CAISNOW_US_LABOR_Test.txt file in //DAUT2I//incoming//ATG_OU//I18

  def place_empl_time_file_winscp(self):
    Stored_session = "cai_snow@mftstg.manheim.com"
#    Stored_session = "opc@stage-fin-iad1-ebsapp1.private.stagefin.oraclevcn.com"
    local_dir = "C:\\EMPL_TIME_Files"
    remote_dir =  self.testConfig['winscp']['cai_labor_file_remote_dir']
#    remote_dir = self.winscpConfig[self.testConfig['ebiz']['env']]['remote_dir']+"incoming//ATG_OU//I18"
    upload_file_name = "CAISNOW_US_LABOR_Test.txt"
    winscp_utility.upload_file(Stored_session,local_dir,remote_dir,upload_file_name)
    Log.Enabled=True       
    Log.Message("CAISNOW_US_LABOR_Test.txt file placed in the I18 directory")           
    Log.Enabled=False
    

# Login to Oracle EBIZ and select the responsibility        
    self.page.WaitProperty("contentText","CAI US PA JOB SCHEDULER",6000)
    cai_gl_submit_link=self.page.Find("contentText","CAI US PA JOB SCHEDULER",30)
    self.verify_aqobject_chkproperty(cai_gl_submit_link,"contentText",cmpIn,"CAI US PA JOB SCHEDULER")
    cai_gl_submit_link.Click() 
    self.log_message_web("Click 'CAI US PA JOB SCHEDULER' - Successful")        
    self.page.Wait()
    self.page.NativeWebObject.Find("contentText","Submit Request","A").Click()
    self.log_message_web("Click 'Submit Request' - Successful") 
    jFrame=self.initializeJFrame()
    Delay(10000)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]     
    val=["Submit a New Request","ExtendedFrame"]      
    SubmitaNewRequest_form=jFrame.FindChildEx(prop,val,60,True,90000)   
    #self.verify_aqobject_chkproperty(SubmitaNewRequest_form,"AWTComponentAccessibleName",cmpContains,"Submit a New Request")   

    prop=["AWTComponentAccessibleName","JavaClassName"]     
    val=["What type of request do you want to run? Request Set alt s","ExtendedCheckbox"]        
    SubmitaNewRequest_form.FindChild(prop,val,10).Click()
    
    Delay(2000)       
    prop = ["AwtComponentAccessibleName","JavaClassName"]       
    val = ["OK alt O","Button"]     
    SubmitaNewRequest_form.FindChild(prop,val,10).Click()   
    Delay(2000)
        
# Submitting "CAI PA Employee Time Interface Request Set" Request Set using CAI ALL GL JOB SCHEDULER' responsibility
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit Request Set","ExtendedFrame"]
    SubmitRequestSet_form=jFrame.FindChildEx(prop,val,60,True,90000)
    self.verify_aqobject_chkproperty(SubmitRequestSet_form,"AWTComponentAccessibleName",cmpContains,"Submit Request Set")
    
    prop=["AWTComponentAccessibleName","JavaClassName"]         
    val=["Request Set RequiredList of Values","VTextField"]    
    req_name = SubmitRequestSet_form.Find(prop,val,20)          
    req_name.Click()       
    Delay(2000)   
    req_name.SetText("CAI PA Employee Time Interface Request Set")      
    Delay(2000)   
    jFrame.keys("[Tab]")      
    Delay(2000)   
    #self.log_message_oracle_form(jFrame,"CAI PA Employee Time Interface Request Set Parameters Successfully")

    prop=["AWTComponentAccessibleName","JavaClassName"]     
    val = ["Submit", "Button"]      
    SubmitRequestSet_form.FindChild(prop,val,10).Click()    
    Delay(2000)
    
    jFrame.Keys("~o")
    Delay(2000)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val = ["Decision Request submitted*","ChoiceBox"] 
    decision_box = jFrame.FindChildEx(prop,val,60,True,12000)     

    RequestID = aqConvert.VarToStr(''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit()))
    self.log_message_oracle_form(jFrame,"Request ID Of CAI PA Employee Time Interface Request Set " + aqConvert.VarToStr(RequestID))
    #RequestID = ''.join(x for x in decision_box.AWTComponentAccessibleName if x.isdigit())      
    #self.log_message_oracle_form(jFrame,"CAI PA Employee Time Interface Request Set Submitted") 

    jFrame.keys("~n")   
    Delay(2000)   
    #self.log_message_oracle_form( jFrame,"Decision NO")     
    Delay(2000)   

    jFrame.Keys("~v")   
    Delay(2000)   
    jFrame.Keys("r")    
    Delay(2000)   
    jFrame.Keys("~i")   
    Delay(2000)   
    self.log_message_oracle_form( jFrame,"Checking the Status for Child Programs of 'CAI PA Employee Time Interface Request Set'")
    Delay(2000) 
    
# Gathering Request ID and Output File for the "CAI Validate and Import Employee Labor Hours Interface"    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,60000)
    empl_lab_hrs_id, log_path = form_utils.req_set_save_output(self,jFrame,req_form,"CAI Validate and Import Employee Labor Hours Interface",RequestID)
    Delay(2000)
    fo=open(log_path,"r")
    lines=fo.readlines()
    self.log_message_web("CAISNOW Employee Time Entry Batch Name is : - "+lines[5][22:71].strip())
    batch_name = lines[5][22:71].strip()
    Log.Enabled=True
    Log.Message("Batch Name is : - "+batch_name)
    Log.Enabled=False

# Gathering Request ID and Output File for the "PRC: Distribute Labor Costs Program"  
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,60000)
    prc_dis_lab_cost_id, log_path = form_utils.req_set_save_output(self,jFrame,req_form,"PRC: Distribute Labor Costs",RequestID)
    Delay(2000)

# Gathering Request ID and Output File for the "PRC:Update Project Summary Amounts Program"  
    prop=["AWTComponentAccessibleName","JavaClassName"]         
    val=["Requests","ExtendedFrame"]         
    req_form=jFrame.FindChildEx(prop,val,30,True,60000)        
    prc_summary_amts_id, output_log_path = form_utils.req_set_save_output(self,jFrame,req_form,"PRC: Update Project Summary Amounts",RequestID)     
    web_utils.close_additional_browsers()
    fo=open(output_log_path,"r")
    lines=fo.readlines()
    #self.log_message_web("Project Number is : - "+lines[25][55:62].strip())
    project_number = lines[25][55:62].strip()
    #Log.Enabled=True
    #Log.Message("Project Number is : - "+project_number)
    #Log.Enabled=False 
    Delay(2000)
    jFrame.Keys("~w")
    Delay(2000)
    jFrame.Keys("2")
    Delay(2000)    
    jFrame.Click()
    Delay(2000)
    jFrame.Keys("~w")
    Delay(2000)
    jFrame.Keys("2")
    Delay(2000)
    jFrame.keys("[F4]")
    Delay(4000)
    jFrame.Keys("~v")
    Delay(4000)
    jFrame.Keys("r")
    Delay(4000)


# Gathering Request ID and Output File for the "PRC: Transaction Import" 
    jFrame.Click() 
    jFrame.Keys("[F4]")
    jFrame.Keys("~v")
    Delay(4000)
    jFrame.Keys("r")
    Delay(4000)

    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Requests","ExtendedFrame"]
    FindRequests_form=jFrame.FindChildEx(prop,val,60,True,20000) 
    self.log_message_oracle_form(FindRequests_form,"Navigation Successful : View > Request;Find Request Window Opened") 
                      
#    FindRequests_form.Keys("~i")
    props = ["AWTComponentAccessibleName","JavaClassName"]
    vals = ["Find alt i","Button"]
    FindRequests_form.FindChild(props,vals,20).Click()
    Delay(3000)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,60000)
    form_utils.req_set_save_output(self,jFrame,req_form,"PRC: Transaction Import",RequestID)
    Delay(2000)

    #dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
    #user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
    #pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
    #dbhelper.verify_pa_trns_import_details(dsn,user_id,pwd,VarTostr(prc_dis_lab_cost_id))
    jFrame.Keys("~w")
    Delay(2000)
    jFrame.Keys("2")
    Delay(2000)    
    jFrame.Click()
    Delay(2000)
    jFrame.Keys("~w")
    Delay(2000)
    jFrame.Keys("2")
    Delay(2000)
    jFrame.keys("[F4]")
    Delay(2000)
    menu_bar=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWMenuBar", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWMenu", "File mnemonic F", 0)
    self.log_message_oracle_form( jFrame,"Switching Responsibility to 'CAI US PA INQUIRY' next")    

#Switching Responsibility
    OCR.Recognize(menu_bar).BlockByText("File").Click()
    Delay(1000)
    jFrame.Keys("w")
    Delay(2000)

#Switiching responsibility form identification    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Responsibilities","FWindow"]
    resp_form=jFrame.FindChildEx(prop,val,30,True,60000)

#selecting the responsibility
    resp_form.Find("AWTComponentName","LWTextField*",10).Click() 
    resp_form.Find("AWTComponentName","LWTextField*",10).keys("CAI US PA INQUIRY")
    #self.verify_aqobject_chkproperty(resp_form,"AWTComponentAccessibleName",cmpContains,"Responsibilities")   
    Delay(2000)
    val = ["Find ALT F","PushButton"]
    resp_form.FindChild(prop,val,20).Click()
    Delay(2000) 
    self.log_message_oracle_form(jFrame,"'CAI US PA INQUIRY' launched successfully")
    Delay(2000) 
    jFrame.Keys("e")
    Delay(2000)
    jFrame.Keys("a")
    Delay(4000)
    prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
    val=["Find Expenditure Items","ExtendedFrame","23"]
    find_expenditure_form=jFrame.FindChildEx(prop,val,20,True,20000)
    Sys.HighlightObject(find_expenditure_form)
    self.log_message_oracle_form(jFrame,"Enter 'Project number' in Find Expenditure form Next")
    prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
    val=["Project NumberList of Values","VTextField","0"]
    proj_num=find_expenditure_form.FindChildEx(prop,val,20,True,20000)
    proj_num.Click()
    proj_num.SetText(project_number)
    Delay(5000)
    prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
    val=["Expenditure BatchList of Values","VTextField","3"]
    expenditure_batch=find_expenditure_form.FindChildEx(prop,val,20,True,20000)
    expenditure_batch.Click()
    expenditure_batch.SetText(batch_name)
    Delay(5000)
    self.log_message_oracle_form( jFrame,"Click 'Find'button next on Expenditure form ") 
    find_button=find_expenditure_form.Find("AWTComponentAccessibleName","Find alt i",20)
    find_button.Click()
    Delay(5000)
    self.log_message_oracle_form(jFrame,"Project Expenditure form launched successfully")
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Expenditure Items","ExtendedFrame"]
    project_expenditure_form=jFrame.FindChildEx(prop,val,60,True,60000)
    Sys.HighlightObject(project_expenditure_form)
    project_expenditure_form.Find("AWTComponentAccessibleName","Item Details alt D",20).Click()
    Delay(5000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Item Details","ExtendedFrame"]
    item_details=jFrame.FindChildEx(prop,val,60,True,60000)
    Sys.HighlightObject(item_details)
    item_details.Find("AWTComponentAccessibleName","OK alt O",20).Click()
    Delay(5000)
    self.log_message_oracle_form(jFrame,"Cost Distribution Lines Reviewed Successfully")
    dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
    user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
    pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
    dbhelper.verify_pa_trns_import_details(dsn,user_id,pwd,VarTostr(prc_dis_lab_cost_id))
    Delay(1000)
    jFrame.keys("[F4]")
    Delay(2000)
    jFrame.keys("[F4]")
    Delay(2000)
    jFrame.keys("~o")
    web_utils.close_additional_browsers()
