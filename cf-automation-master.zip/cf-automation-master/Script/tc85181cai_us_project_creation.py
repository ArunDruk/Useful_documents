﻿from ebiz import *
import web_utils
import dbhelper
import file_system_utils
import random

class tc85181cai_us_project_creation(Ebiz):


   def login(self):
     self.login_user='pkjami'
     super().login()
   
   def action(self,book): 
     app = book.Sheets.item["Project"] 
     app1 = book.Sheets.item["Requisition"]  
     rowno = 2
     self.wait_until_page_loaded()
     ## Navigation to Request set
     obj =  self.page.FindChild("innerHTML","Home",30)
     self.log_message_web("Navigation to Oracle Home page Successful")
     self.verify_aqobject_chkproperty(obj,"contentText",cmpContains,"Home")
     web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" PA PROJECT CONTROLS')]")
     self.log_message_web("Click 'CAI "+self.oper_unit+" PA PROJECT CONTROLS' - Successful")
     Delay(2000)
     self.page.wait()
     self.wait_until_page_loaded()     
#     self.page.NativeWebObject.Find("contentText","Project Managment","A").Click()
     web_utils.clk_link_by_xpath(self.page,"//div[text()='Project Managment']")
     self.log_message_web("Click 'Project Managment' - Successful")
     Delay(2000)
     self.wait_until_page_loaded()
     web_utils.clk_link_by_xpath(self.page,"//div[text()='Projects: Delivery']")
     self.log_message_web("Click 'Projects: Delivery' - Successful")
#     self.page.NativeWebObject.Find("contentText","Projects: Delivery","A").Click()
     Delay(2000)
     self.page.wait()
     self.wait_until_page_loaded()
     web_utils.clk_link_by_xpath(self.page,"//div[text()='Create Project']")
     self.log_message_web("Click 'Create Project' - Successful")
#     self.page.NativeWebObject.Find("contentText","Create Project","A").Click() 
     Delay(2000)
     self.page.wait()
     self.wait_until_page_loaded()       
    #CAI US XTIME BILLABLE PROJECT
     ## Naviagate to Submit a New Request Window 
   
  #   app = Sys.OleObject["Excel.Application"]
  #   Delay(1000)
  #   book = app.Workbooks.Open(Project.Path+"\\Datasheets\\Oracle-Oracle-PA-Setup\Project_creation.xls") 
  #   rowno =2
     prop=["innerHTML","ObjectType"]
     val=["Create Project: Select Source","TextNode"]
     obj =  self.page.FindChild(prop,val,40)
     self.verify_aqobject_chkproperty(obj,"contentText",cmpContains,"Create Project: Select Source")
     self.log_message_web("Navigation to 'Create Project: Select Source' Page is successful")
     prop=["idStr"]
     val=["TemplateName*"]
     self.page.FindChild(prop,val,30).SetText(app.Cells.Item[rowno,1])
     Delay(2000)
     self.page.FindChild('contentText','Go',50).Click()
     Delay(2000)
     self.page.FindChildEx('ObjectIdentifier','selected',50,True,20000).Click()
     Delay(2000)
     self.log_message_web(VarToStr(app.Cells.Item[rowno,1])+" Project Template selected successfully")
     prop=["idStr"]
     val=["Continue"]
#     self.page.FindChild(prop,val,60).Click()
     self.page.Keys("~c")
     self.wait_until_page_loaded()
     Delay(1000)   
     prop=["idStr"]
     val=["ProjectName"]
     self.page.FindChild(prop,val,40).SetText(VarToStr(app.Cells.Item[rowno,2])+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d%b%Y_%H%M%S"))
     self.log_message_web(("Project Name entered successfully :")+(VarToStr(app.Cells.Item[rowno,2])+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d%b%Y_%H%M%S")))
     Delay(1000)
     prop=["idStr"]
     val=["CarryingOutOrgName"]
     self.page.FindChild(prop,val,40).SetText(app.Cells.Item[rowno,3])
     self.log_message_web(("Owning Organization entered successfully : ")+VarToStr(app.Cells.Item[rowno,3]))
     Delay(1000)
     self.page.FindChild("idStr","ClassCode",40).Keys(VarToStr(app.Cells.Item[rowno,4]))
     self.log_message_web(("Work Type entered successfully : ")+VarToStr(app.Cells.Item[rowno,4]))
     Delay(1000)
     prop=["idStr"]
     val=["ClassCode2"]
     self.page.FindChild(prop,val,60).Click()
     self.page.FindChild(prop,val,60).SetText(VarToStr(app.Cells.Item[rowno,5]))
     self.log_message_web(("Portfolio entered successfully : ")+VarToStr(app.Cells.Item[rowno,5]))
     Delay(1000)
     prop=["idStr"]
     val=["ClassCode3"]
     self.page.FindChild(prop,val,60).Keys(VarToStr(app.Cells.Item[rowno,6]))
     self.log_message_web(("Program entered successfully : ")+VarToStr(app.Cells.Item[rowno,6]))
     Delay(1000)
     prop=["idStr"]
     val=["ClassCode4"]
     self.page.FindChild(prop,val,60).SetText(VarToStr(app.Cells.Item[rowno,7]))
     self.log_message_web(("Funding Category entered successfully : ")+VarToStr(app.Cells.Item[rowno,7]))
     Delay(1000)
     prop=["idStr"]
     val=["ClassCode5"]
     self.page.FindChild(prop,val,60).Keys(VarToStr(app.Cells.Item[rowno,8]))
     self.log_message_web(("Project Funding Funding Sub Category entered successfully : ")+VarToStr(app.Cells.Item[rowno,8]))
     Delay(1000)
     prop=["idStr"]
     val=["KeyMemberName"]
     self.page.FindChild(prop,val,60).SetText(app.Cells.Item[rowno,9])
     self.log_message_web(("Project Manager entered successfully : ")+VarToStr(app.Cells.Item[rowno,9]))
     Delay(1000)
     prop=["idStr"]
     val=["KeyMemberName2"]
     self.page.FindChild(prop,val,60).SetText(app.Cells.Item[rowno,10])
     self.log_message_web(("Business Owner entered successfully : ")+VarToStr(app.Cells.Item[rowno,10]))
     Delay(1000)
     self.log_message_web("Create Project: Details entered successfully")
##     prop=["idStr"]
##     val=["CopyOptions_uixr"]
##     self.page.FindChild(prop,val,60).Click()
     self.wait_until_page_loaded()
##     Delay(2000)
##     prop=["innerHTML"]
##     val=["Copy Options"]
##     obj =  self.page.FindChild(prop,val,30)
##     self.verify_aqobject_chkproperty(obj,"contentText",cmpContains,"Copy Options")
##     Delay(2000)
##     self.log_message_web("Copied Options Successfully")
#     prop=["idStr","ObjectLabel"]
#     val=["Apply_uixr","Continue"]
#     self.page.FindChild(prop,val,60).Click()
##     self.page.Keys("~c")
##     self.wait_until_page_loaded()
##     Delay(2000)
##   
##     prop=["innerHTML","ObjectType"]
##     val=["Create Project: Details","TextNode"]
##     obj =  self.page.FindChild(prop,val,30)
##     self.verify_aqobject_chkproperty(obj,"contentText",cmpContains,"Create Project: Details")
##     self.log_message_web("Ready to Finish Project")
     Delay(2000)
#     prop=["idStr","ObjectLabel"]
#     val=["Apply_uixr","Finish"]
#     self.page.FindChild(prop,val,60).Click()
#     self.page.Keys("~i")
     complete = self.page.EvaluateXpath("//table[@id='ContinueCancel']//button[@title='Finish']")[0]
     complete.Click()
     Delay(15000)
     while complete.Exists:
       complete.Click()
       Delay(3000)
     self.wait_until_page_loaded()
     self.page.wait()      
     
     prop=["innerHTML","ObjectType"]
     val=["Home: *","TextNode"]
     proj = self.page.FindChild(prop,val,30).contentText
  #   obj = Sys.Browser("iexplore").Page("*").FindChild(prop,val,30)   
     #self.log_message_web("Project Number generated"+ VarToStr(proj))
     projectnum = aqString.Trim(proj.split(" ",3)[2].replace("(","").replace(")",""))
     self.log_message_web("Project is successfully created and Project Number is : "+aqConvert.VarToStr(projectnum))
     app1.Cells.Item[rowno,11] =projectnum
     
     #self.verify_aqobject_chkproperty(obj,"contentText",cmpContains,"Home:*")     
     self.page.NativeWebObject.Find("contentText","Setup","A").Click()
     self.log_message_web("In Project Setup Page: Click Setup is successful")
     Delay(2000)
     self.wait_until_page_loaded()     
     prop=["innerHTML"]
     val=["Project Setup"]
     obj =  self.page.FindChild(prop,val,30)
     self.verify_aqobject_chkproperty(obj,"contentText",cmpContains,"Project Setup")
#     self.log_message_web("Navigation to Project Setup is successful")
     self.log_message_web("In 'Project Setup' page: Click on 'CAI Additional Project Information' link next")
     self.page.NativeWebObject.Find("contentText","CAI Additional Project Information","A").Click()
     self.log_message_web("Navigation to 'CAI Additional Project Information' is successful")
     Delay(1000)
     self.wait_until_page_loaded()
     
#     prop=["innerHTML"]
#     val=["CAI Additional Project Information"]
#     obj =  self.page.FindChild(prop,val,30)
#     self.verify_aqobject_chkproperty(obj,"contentText",cmpContains,"CAI Additional Project Information")

     prop=["idStr"]
     val=["PA_PROJ_ATTR_GROUP_TYPE222902LOVDisp"]
     
#     self.page.FindChild(prop,val,30).SetText(app.Cells.Item[rowno,12])

     comp_txt_fld=self.page.FindChild(prop,val,30)
     comp_txt_fld.Click()
     comp_txt_fld.Keys(VarToStr(app.Cells.Item[rowno,12]))
     self.page.Keys("[Tab]")
     Delay(2000)
     self.log_message_web("In CAI Addition Project Information page: Project Code entered successfully :"+(VarToStr(app.Cells.Item[rowno,12])))     

     self.page.Keys("~p")
     self.log_message_web("In CAI Additional Project Information page: Click 'Apply' button successful")
     self.wait_until_page_loaded()
     Delay(2000)
   
     prop=["idStr"]
     val=["ProjectStatus"]
     obj =  self.page.FindChild(prop,val,30)
#     self.verify_aqobject_chkproperty(obj,"contentText",cmpContains,"Unapproved")
     self.log_message_web("In Project Setup page: Project "+VarToStr(app1.Cells.Item[rowno,11])+" is in 'Unapproved' Status")
    
     prop=["idStr","ObjectLabel"]
     val=["ProjectStatusChange","Change Status"]
     self.page.FindChild(prop,val,60).Click()
     self.log_message_web("In Project Setup page: Click on 'Change Status' button successful")
     
#     self.wait_until_page_loaded()
#     Delay(2000)
#     prop=["innerHTML"]
#     val=["Change Status"]
#     obj =  self.page.FindChild(prop,val,30)
#     self.verify_aqobject_chkproperty(obj,"contentText",cmpContains,"Change Status")
  
     prop=["idStr"]
     val=["ToStatus"]
     self.page.FindChild(prop,val,60).ClickItem("Approved")
   
     prop=["innerHTML"]
     val=["Change Status"]
     obj =  self.page.FindChild(prop,val,30)
#     self.verify_aqobject_chkproperty(obj,"contentText",cmpContains,"Change Status") 
     self.log_message_web("In Change Status page: Project "+VarToStr(app1.Cells.Item[rowno,11])+" is Approved successfully")
   
     prop=["idStr","ObjectLabel"]
     val=["Apply","Apply"]
     #self.page.FindChild(prop,val,60).Click()
     self.page.Keys("~p")
     self.wait_until_page_loaded()
     Delay(2000)
   
#     self.page.NativeWebObject.Find("contentText","CAI Additional Project Information","A").Click()
#     Delay(1000)
#     self.wait_until_page_loaded()
#     
##     prop=["innerHTML"]
##     val=["CAI Additional Project Information"]
##     obj =  self.page.FindChild(prop,val,30)
##     self.verify_aqobject_chkproperty(obj,"contentText",cmpContains,"CAI Additional Project Information")
#
#     prop=["idStr"]
#     val=["PA_PROJ_ATTR_GROUP_TYPE222902LOVDisp"]
#     
##     self.page.FindChild(prop,val,30).SetText(app.Cells.Item[rowno,12])
#
#     comp_txt_fld=self.page.FindChild(prop,val,30)
#     comp_txt_fld.Click()
#     comp_txt_fld.Keys(VarToStr(app.Cells.Item[rowno,12]))
#     self.page.Keys("[Tab]")
#     Delay(2000)
#     self.log_message_web("In CAI Addition Project Information page: Project Code entered successfully :"+(VarToStr(app.Cells.Item[rowno,12])))     
#
#     self.page.Keys("~p")
#     self.wait_until_page_loaded()
#     Delay(2000)
   
     prop=["innerHTML"]
     val=["Project Setup"]
     obj =  self.page.FindChild(prop,val,30)
#     self.verify_aqobject_chkproperty(obj,"contentText",cmpContains,"Project Setup") 
     self.log_message_web("Project "+VarToStr(app1.Cells.Item[rowno,11])+" is Ready to be Saved")

     self.page.Keys("~s")
     self.wait_until_page_loaded()
     self.page.wait()
     obj =  self.page.NativeWebObject.Find("contentText","Confirmation","H1")
#     self.verify_aqobject_chkproperty(obj,"contentText",cmpContains,"Confirmation")
    

     obj =  self.page.NativeWebObject.Find("innerText","Your changes have been saved.","div")
#     self.verify_aqobject_chkproperty(obj,"contentText",cmpContains,"Your changes have been saved.")
     self.log_message_web("Project "+VarToStr(app1.Cells.Item[rowno,11])+" changes are 'Confirmed'") 

     obj = Sys.Browser("iexplore").Page("*").NativeWebObject.Find("idStr","ProjectStatus","span")
#     self.verify_aqobject_chkproperty(obj,"contentText",cmpContains,"Approved")
#     self.log_message_web("Project "+VarToStr(app1.Cells.Item[rowno,11])+" is 'Approved'") 
     book.save()    
   
 

 

