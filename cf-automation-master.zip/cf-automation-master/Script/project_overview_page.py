﻿import gvar

### In this method objects for below pages have been captured ###

#PROJECT > OVERVIEW page

def prj_overview_page_link():
  prop_names = ["idStr","innerHTML","ObjectType"]
  prop_values = ["PA_PROJ_OVERVIEW_FUNC","Overview","Link"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def prj_overviewpage_printable_button():
  prop_names = ["contentText","idStr","ObjectType"]
  prop_values = ["Printable Page","IcxPrintablePageButton","Button"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def prj_overviewpage_email_gif():
  prop_names = ["namePropStr","ObjectIdentifier","ObjectType"]
  prop_values = ["email_enabled.gif","email_enabled_gif","Image"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

