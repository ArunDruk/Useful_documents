﻿import tc_logs
import odm_datatype
import gvar
import api_utility
import receipts_api
import database_service
import receipts_api_queries
import receipts_api_payloads as rc_payload
import receipts_api_queries  as R_query

FIRE_API = api_utility.post_or_put


def print_no_picture(data):
  tc_logs.checkpt_with_no_picture(data)
  
def get_trx_number():
   
   sqlQuery = receipts_api_queries.get_trx_query()
   rows = database_service.query_oracle_db(sqlQuery)
   if (GetVarType(rows)== VarToInt(9)and len(rows)> 0):
     for row in rows:
        gvar.dataprep['buyer_invoice_number'] = row['INVOICE_NUMBER']
        gvar.dataprep['source'] = row['SOURCE']
        gvar.dataprep['amount_due_remaining'] = row['AMT_DUE_REMAINING']
        
def get_order_details():
   sqlQuery = receipts_api_queries.get_ach_trx_query()
   rows = database_service.query_oracle_db(sqlQuery)
   if (GetVarType(rows)== VarToInt(9)and len(rows)> 0):
     for row in rows:
        gvar.dataprep['buyer_order_number'] = row['ORDER_NUMBER']
        gvar.dataprep['header_id'] = row['HEADER_ID']
        gvar.dataprep['source'] = row['SOURCE']
        gvar.dataprep['amount_due_remaining'] = row['AMT_DUE_REMAINING']
        
def get_ach_pmt_id():
   sqlQuery = receipts_api_queries.get_pmt_method_id('ACH')
   rows = database_service.query_oracle_db(sqlQuery)
   if (GetVarType(rows)== VarToInt(9)and len(rows)> 0):
     for row in rows:
        gvar.dataprep['payment_id'] = row['PAYMENTMETHODID']

def receipts_api_get_payment_id_details():
   return "?customerRepNumber="+gvar.dataprep['buyer']
 
def update_cash_payment_id_details_for_buyer(response):
    if len(response['payers']) > 0:
       gvar.dataprep['payerID']    = response['payers'][0]['payerID']
       gvar.dataprep['repNumber']  = response['payers'][0]['repNumber']
       gvar.dataprep['firstName']  = response['payers'][0]['firstName']
       gvar.dataprep['middleName'] = response['payers'][0]['middleName']
       gvar.dataprep['lastName'] = response['payers'][0]['lastName']
       gvar.dataprep['tin'] = response['payers'][0]['tin']
       gvar.dataprep['dateOfBirth'] = response['payers'][0]['dateOfBirth']
       gvar.dataprep['streetAddress'] = response['payers'][0]['streetAddress']
       gvar.dataprep['city'] = response['payers'][0]['city']
       gvar.dataprep['state'] = response['payers'][0]['state']
       gvar.dataprep['zip'] = response['payers'][0]['zip']
       gvar.dataprep['country'] = response['payers'][0]['country']
       gvar.dataprep['occupation'] = response['payers'][0]['occupation']
       gvar.dataprep['idNumber'] = response['payers'][0]['idNumber']
       gvar.dataprep['idType'] = response['payers'][0]['idType']
       gvar.dataprep['idExpiration'] = response['payers'][0]['idExpiration']
       gvar.dataprep['idIssuedCountry'] = response['payers'][0]['issuedByCountry']
       gvar.dataprep['idIssuedState'] = response['payers'][0]['issuedByState']
       
    else:
       tc_logs.error_with_no_picture(f"Response Error - Receipts API GET Operation") 
       odm_datatype.update_status('Failed')     
   
def receipt_get_buyer_payment_ID():
   query =  receipts_api_get_payment_id_details()
   return api_utility.get('receipts_api',query, '200')    
   
def receipt_api_cash_post():
    update_cash_payment_id_details_for_buyer(receipt_get_buyer_payment_ID())
    get_trx_number()
    response = FIRE_API('receipts_api',rc_payload.get_cash_payment_payload())   
    validate_payment_response(response)

def receipt_api_cashier_check_post():
    get_trx_number()
    response = FIRE_API('receipts_api',rc_payload.get_cashier_check_payload())   
    validate_payment_response(response)   
    
def receipt_api_ach_post():
    get_order_details()
    get_ach_pmt_id()
    response = FIRE_API('receipts_api',rc_payload.get_ach_payment_payload())   
    validate_payment_response(response) 
     
 
def validate_payment_response(response):
    if response['errorMessage'] == None:
       tc_logs.validation(f"***** RECEIPT RESPONSE DETAILS *********")
       print_no_picture(f" ReceiptStatus: {response['receiptStatus']}")
       print_no_picture(f" ReceiptID: {response['receiptID']}")
       print_no_picture(f" ReceiptNumber: {response['receiptNumber']}")
       tc_logs.validation(f"***** END *********")
    else:
      tc_logs.validation(f"Error occured : {response['errorMessage']}")
             
def receipt_api_check_post():
    R_query.get_payment_method_id_for_check()
    get_trx_number()
    response = FIRE_API('receipts_api',rc_payload.get_check_payment_payload())   
    validate_payment_response(response)
          
   
   
