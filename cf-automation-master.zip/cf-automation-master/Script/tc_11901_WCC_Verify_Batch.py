﻿from base import *
from driverchain import *
from ebiz import *
import gvar
  
  
class Driver(Driverchain):
    global classarr,env
    
    def __init__(self):
      global test_env, sheet_obj, book     
      app = Sys.OleObject["Excel.Application"]
      Delay(1000)
      self.book = app.Workbooks.Open(Project.Path+"\\datasheets\\WCI\\WCC_email.xls")          
      app.Visible = "True"    
      self.test_env="oci_dev"
      self.oper_unit="US"
      self.classarr=["capture_invoice_via_email()","WCC_Verify_batch_creation_email_V12()"]
#      self.classarr=["WCC_verify_batch_creation_2page()"]
      super().__init__(self.classarr)
      
    def close_excel(self):    
      self.book.save()
      delay(1000)
      self.book.close()
      
      
      
def main():  
    gvar.dataprep['env'] = 'oci_dev'
    obj=Driver()
    cobj = obj.run()
    obj.close_excel()
