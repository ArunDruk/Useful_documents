﻿import dbhelper
from ebiz import *
import web_utils
import dbhelper
import file_system_utils 
import form_utils
                        
class tc184757_run_prc_interface_supplier_costs(Ebiz):
   op_log_path="C:\\Tc_Logs"
                        
   def login(self):
     self.login_user='pkjami'
     super().login()
   
   def goto_url(self,url):
    super().goto_url(self.testConfig['ebiz']['oci_is_url'])
                           
   def action(self,book): 
     global rowno      
     rowno = 2            
     app = book.Sheets.item["Requisition"]
     app1 = book.Sheets.item["Invoice"]  
     web_utils.log_checkpoint("Logged in to Oracle Applications Home Page Successfully",500,self.page)
     self.wait_until_page_loaded()       
     self.page.EvaluateXPath("//table[@id='menuContent']//div[contains(text(),'PC User')]")[0].Click()  
     web_utils.log_checkpoint("Click 'PC User' - Successful",500,self.page) 
     self.page.Keys("[Down]")
     self.page.Keys("[Down]")
     self.page.Keys("[Down]")
     self.page.Keys("[Down]")
     self.wait_until_page_loaded()
     self.page.NativeWebObject.Find("contentText","Other","A").Click()
     web_utils.log_checkpoint("Click 'Other' - Successful",500,self.page) 
     self.page.Keys("[Down]")
     self.page.Keys("[Down]")
     self.page.NativeWebObject.Find("contentText","Requests","A").Click()
     web_utils.log_checkpoint("Click 'Requests' - Successful",500,self.page)
     self.page.Keys("[Down]")
     self.page.NativeWebObject.Find("contentText","Run","A").Click()
     web_utils.log_checkpoint("Click 'Run' - Successful",500,self.page)
     web_utils.validate_security_box()
     Delay(15000)
     jFrame=self.initializeJFrame()
     form_utils.click_ok_btn(jFrame)  
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Submit a New Request","ExtendedFrame"]
     submit_req_form=jFrame.FindChildEx(prop,val,30,True,60000)
     submit_req_form.FindChild("AWTComponentAccessibleName","OK alt O",10).Click()
     Delay(2000)
     jFrame.Keys("PRC: Interface Supplier Costs")
     jFrame.Keys("[Tab]")
     delay(1000)
     web_utils.log_checkpoint("Request Name: 'PRC: Interface Supplier Costs' - populated Successfully",500,jFrame)
   
# Entering Parameters

     prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
     val=["Parameters","FlexWindow","0"]
     parameters_form=jFrame.FindChildEx(prop,val,60,True,90000)
     self.verify_aqobject_chkproperty(parameters_form,"AWTComponentAccessibleName",cmpContains,"Parameters")
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Project Number List Values","FlexTextField"]
     req_name = parameters_form.Find(prop,val,20)
     req_name.Click()
     Delay(2000)
     req_name.Keys(app.Cells.Item[rowno,11])
     jFrame.keys("[Tab]")
     Delay(2000)
     web_utils.log_checkpoint("Request Name: 'PRC: Interface Supplier Costs' - parameters populated Successfully",500,jFrame)
     jFrame.Keys("~o")
     Delay(2000)
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Submit Request","ExtendedFrame"]
     submit_req_form=jFrame.FindChildEx(prop,val,30,True,60000)
     submit_req_form.FindChild("AWTComponentAccessibleName","Submit alt m",10).Click()
     web_utils.log_checkpoint("Request Name: 'PRC: Interface Supplier Costs' - submitted Successfully",500,jFrame)
     Delay(2000)  
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Decision Request submitted*","ChoiceBox"]
     decision_form=jFrame.FindChildEx(prop,val,60,True,40000)
     RequestID = ''.join(x for x in decision_form.AWTComponentAccessibleName if x.isdigit())
     web_utils.log_checkpoint("Request ID Of 'PRC: Interface Supplier Costs' is " + aqConvert.VarToStr(RequestID),500,jFrame)
     Delay(2000)    
     jFrame.Keys("~n")  
     Delay(2000)    
     dsn = self.testConfig['man_oracle_db']['dsn']
     user_id = self.testConfig['man_oracle_db']['userid']
     pwd = self.testConfig['man_oracle_db']['pwd']
     dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,RequestID)
     jFrame.Keys("~v")
     Delay(2000)
     jFrame.Keys("r")
     Delay(2000)
     jFrame.Keys("~i")
     Delay(2000) 

# Capturing Outputs for PRC: Interface Supplier Costs & AUD: Supplier Costs Interface Audit

     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Requests","ExtendedFrame"]
     req_form=jFrame.FindChildEx(prop,val,30,True,40000)
     self.req_set_save_output(jFrame,req_form,"AUD: Supplier Costs Interface Audit",aqConvert.VarToInt(RequestID))  
     Delay(1000)
     jFrame.Keys("~n") 
     Delay(1000)
     jFrame.Keys("~v")
     Delay(2000)
     jFrame.Keys("r")
     Delay(2000)
     jFrame.Keys("~i")
     Delay(2000) 
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Requests","ExtendedFrame"]
     req_form=jFrame.FindChildEx(prop,val,30,True,90000)
     self.req_set_save_output(jFrame,req_form,"PRC: Interface Supplier Costs",aqConvert.VarToInt(RequestID))
     jFrame.Click()
     Delay(1000)
     self.close_forms(jFrame)    
     Delay(1000) 

     
     
             
   def req_set_save_output(self,jFrame,req_form,srch_child_name,Preqid):
    web_utils.log_checkpoint("Checking for "+aqConvert.VarToStr(srch_child_name)+ " Child Program Status",500,jFrame)
    req_form.FindChild("AWTComponentAccessibleName","Refresh Data alt R",20).Click()
    i=20
    for x in range(1,180):     
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Name",i]
        child_name=req_form.Find(prop,val,10).wText 
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Phase",i+20]
        phase=req_form.Find(prop,val,10).wText 
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Request ID",i-10]
        creqid=VarToInt(req_form.Find(prop,val,10).wText)                                        
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Status",i+30]         
        status =req_form.FindChild(prop,val,60)            
        if (child_name==srch_child_name) and (creqid >= Preqid) and (phase == "Completed"):
            web_utils.log_checkpoint(aqConvert.VarToStr(srch_child_name)+" Phase Completed Successfuly",500,jFrame)                             
            status.Keys("[Enter]")
            Delay(1000)
            req_form.FindChild("AWTComponentAccessibleName","View Output alt p",20).Click()  
            Delay(4000)
            self.wait_until_page_loaded()
            output_page=Sys.Browser("iexplore").Page("https://manheim*.epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
            output_page.Click()
            Delay(5000)
            output_page.Keys("~f")
            Delay(5000)
            output_page.Keys("a")
            Delay(5000)
            file_system_utils.create_folder(self.op_log_path)             
            self.log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"File"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"_%d%b%Y_%H%M")+".txt"    
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(self.log_path)
            Delay(1000)
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
            Delay(8000)
            Log.Enabled=True
            Log.File(self.log_path, aqConvert.VarToStr(srch_child_name)+" is Completed And Output file is attached")
            Log.Enabled=False     
            web_utils.close_additional_browsers()         
            Filesaved = 'True'
            return                           
        elif i >=29:
           Delay(15000)           
           req_form.FindChild("AWTComponentAccessibleName","Refresh Data alt R",20).Click()
           Delay(3000)
           i=20
           val=["Name",i]
           child_name=req_form.Find(prop,val,10).wText
        else:  
           Delay(2000)
           i=i+1 
           
