﻿from dbhelper import *
from ebiz import *
import web_utils
import dbhelper
import file_system_utils 
import form_utils

class tc188295_is_us_asset_transfer(Ebiz):
 op_log_path="C:\\Tc_Logs"

 def login(self):
   self.login_user='pkjami'
   super().login()
 
 def goto_url(self,url):
   super().goto_url(self.testConfig['ebiz']['oci_is_url'])
   
 def action(self,book):
   
   app = book.Sheets.item["PA-FA"]
   RowCount = book.ActiveSheet.UsedRange.Rows.Count
   rowno = 2 
   web_utils.log_checkpoint("Logged in to Oracle Applications Home Page Successfully",500,self.page)
   self.wait_until_page_loaded()   
   self.page.EvaluateXPath("//table[@id='menuContent']//div[contains(text(),'AM Super User')]")[0].Click() 
   web_utils.log_checkpoint("Click 'AM Super User' - Successful",500,self.page) 
   self.wait_until_page_loaded()
   self.page.Keys("[Down]")
   self.page.Keys("[Down]")
   Delay(2000)
   self.page.NativeWebObject.Find("contentText","Assets","A").Click()
   web_utils.log_checkpoint("Click 'Assets' - Successful",500,self.page) 
   self.wait_until_page_loaded()
   self.page.Keys("[Down]")
   Delay(2000)
   self.page.wait()
   self.page.NativeWebObject.Find("contentText","Asset Workbench","A").Click()
   web_utils.log_checkpoint("Click 'Asset Workbench' - Successful",500,self.page) 
   web_utils.validate_security_box()
   Delay(15000)
   jFrame=self.initializeJFrame()
   form_utils.click_ok_btn(jFrame) 
   Delay(8000)   

# Form Validation

   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Find Assets","ExtendedFrame"]
   find_asset_form=jFrame.FindChildEx(prop,val,60,True,90000)
   if find_asset_form.Exists:
    web_utils.log_checkpoint("Navigation Successful : AM Super User > Assets > Asset Workbench; 'Find Assets' form launched successfully",500,jFrame)
   else:
    self.log_message_oracle_form(jFrame,"Unable to Launch 'Find Assets' form")

# Finding the Asset that needs to be transferred

   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Find Assets","ExtendedFrame"]
   findassets_form=jFrame.FindChildEx(prop,val,60,True,60000)
   Delay(4000)
   findassets_form.Find("AWTComponentAccessibleName","Asset Number",10).Click()
   findassets_form.Find("AWTComponentAccessibleName","Asset Number",10).Keys(app.Cells.item[rowno,1])
   findassets_form.Keys("[Tab]")
   web_utils.log_checkpoint("In 'Find Assets' form: Enter Asset Number "+VarToStr(app.Cells.Item[rowno,1]),500,jFrame)
   web_utils.log_checkpoint("In 'Find Assets' Form: Click 'Find' button next",500,jFrame)
   findassets_form.Find("AWTComponentAccessibleName","Find alt i",10).Click()
   Delay(3000)
   web_utils.log_checkpoint("'Assets' form launched successfully",500,jFrame)

   
# Click Assignments button on Assets Window 

   Delay(3000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Assets","ExtendedFrame"]
   assets_form=jFrame.FindChildEx(prop,val,60,True,40000)
   web_utils.log_checkpoint("In 'Find Asset' form: Click on 'Assignments' button next",500,jFrame)
   assets_form.Find("AWTComponentAccessibleName","Assignments alt g",10).Click()
   Delay(2000)
   web_utils.log_checkpoint("'Assignments' form launched successfully",500,jFrame)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Assignments","ExtendedFrame"]   
   assingments_form=jFrame.FindChildEx(prop,val,60,True,60000)
   prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
   val=["Unit\nChange","VTextField",16]  
   assingments_form.Find(prop,val,10).Click()    
   assingments_form.Find(prop,val,10).Keys("-1")
   web_utils.log_checkpoint("In 'Assignments' form: In the first line update 'Unit' to '-1'",500,jFrame)
   Delay(2000)
   assingments_form.Find(prop,val,10).keys("[Down]")
   prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
   val=["Unit\nChange Required","VTextField",17]   
   assingments_form.Find(prop,val,10).Click()   
   assingments_form.Find(prop,val,10).Keys("1")
   web_utils.log_checkpoint("In 'Assignments' form: In the second line add 'Unit' to '1'",500,jFrame)
   delay(1000)
   prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
   val=["Expense Account RequiredList of Values","VTextField",57]  
   assingments_form.Find(prop,val,10).Click()
   delay(1000)    
   assingments_form.Find(prop,val,10).keys("00718.710010.0000.000.000.00000.0000")
   web_utils.log_checkpoint("In 'Assignments' form: New 'Expense Account' given - 00718.710010.0000.000.000.00000.0000",500,jFrame)
   Delay(2000)
   prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
   val=["Location RequiredList of Values","VTextField",67]   
   assingments_form.Find(prop,val,10).Click()
   delay(1000)   
   assingments_form.Find(prop,val,10).Keys("00718.HATFIELD.MONTGOMERY.PA.US")
   Delay(9000)
   assingments_form.keys("[Tab]")
   web_utils.log_checkpoint("In 'Assignments' form: New 'Location' given - 00718.HATFIELD.MONTGOMERY.PA.US",500,jFrame)
   delay(1000)
   web_utils.log_checkpoint("In 'Assignments' form: Click on 'Done' Button next",500,jFrame)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Done alt D","Button"]
   assingments_form.Find(prop,val,10).Click()
   Delay(6000)
   web_utils.log_checkpoint("Transactions Complete Note",500,jFrame)
   Delay(2000)
   jFrame.keys("~o")
   Delay(2000)
   web_utils.log_checkpoint("Click 'F4' to Close form",500,jFrame)
   jFrame.Keys("[F4]")
   Delay(2000)
   jFrame.Keys("~f")
   Delay(1000)
   jFrame.Keys("w")
   Delay(3000)

# Switch Responsibility to AM Supervisor and submit Asset Transfers Report capture the output

   web_utils.log_checkpoint("Switch Responsibility to 'AM Supervisor' by clicking File > Switch Responsibility next",500,jFrame)       
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Responsibilities","FWindow"]
   resp_form=jFrame.FindChildEx(prop,val,30,True,40000)
   resp_form.Find("AWTComponentName","LWTextField*",10).Click() 
   resp_form.Find("AWTComponentName","LWTextField*",10).keys("AM Supervisor")  
   Delay(2000)
   jFrame.Keys("~f")
   Delay(4000)
   form_utils.Nav_Submit_Single_Request(self,jFrame)       
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Submit Request","ExtendedFrame"]
   submitrequest_form=jFrame.FindChild(prop,val,60)
   submitrequest_form.Find("AWTComponentAccessibleName","Name RequiredList of Values",10).Keys("MAN: FA Asset Transfers Report")
   web_utils.log_checkpoint("Submiting 'MAN: FA Asset Transfers Report' concurrent request",500,jFrame)
   Delay(2000)
   submitrequest_form.Find("AWTComponentAccessibleName","Parameters",10).Click()
   Delay(2000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Parameters","FlexWindow"]
   parameters_form=jFrame.FindChild(prop,val,60)
   book_txtfield=parameters_form.FindChild("AWTComponentAccessibleName","Book REQUIRED List Values",10)
   book_txtfield.Click()
   book_txtfield.Keys("MAN USCORP BOOK")
   web_utils.log_checkpoint("MAN: FA Asset Transfers Report' Parameter:'BOOK'-'MAN USCORP BOOK' entered successfully",500,jFrame)
   Delay(1000)
   parameters_form.Keys("[Tab]")
   Delay(1000)
#   parameters_form.Keys("[Tab]")
#   Delay(1000)
   period=parameters_form.FindChild("AWTComponentAccessibleName","Period REQUIRED List Values",10)
   period.Click()
   period.Keys(aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%b-%Y"))
   web_utils.log_checkpoint("MAN: FA Asset Transfers Report' Parameter:'Period' entered successfully",500,jFrame)
   Delay(1000)
   web_utils.log_checkpoint("Click OK Button Next",500,jFrame)
   parameters_form.keys("~o")
   Delay(2000)
   web_utils.log_checkpoint("Click Submit Button Next",500,jFrame)
   submitrequest_form.Find("AWTComponentAccessibleName","Submit alt m",10).Click()
   Delay(3000)
   form_utils.capture_reqid_and_save_output_singlereq(self,jFrame,self.op_log_path,"MAN: FA Asset Transfers Report")
   Delay(2000)   
   jFrame.Keys("[F4]")
   Delay(3000)
   web_utils.log_checkpoint("Navigating to AM Supervisor>Find Transactions>Trnascation History>Transaction Detail form next",500,jFrame)
   jFrame.Keys("i")
   Delay(3000)
   jFrame.Keys("t")
   Delay(2000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Find Transactions","ExtendedFrame"]  
   find_transactions=jFrame.FindChildEx(prop,val,60,True,60000)
   find_transactions.Find("AWTComponentAccessibleName","Book RequiredList of Values",10).Click()
   find_transactions.Find("AWTComponentAccessibleName","Book RequiredList of Values",10).Keys("MAN USCORP BOOK")
   jFrame.Keys("[Tab]")
   Delay(3000)
   find_transactions.Find("AWTComponentAccessibleName","From Asset Number RequiredList of Values",10).Click()
   find_transactions.Find("AWTComponentAccessibleName","From Asset Number RequiredList of Values",10).Keys(app.Cells.item[rowno,1])
   Delay(3000)
   find_transactions.Find("AWTComponentAccessibleName","Transaction TypeList of Values",10).Click()
   find_transactions.Find("AWTComponentAccessibleName","Transaction TypeList of Values",10).Keys("TRANSFER")
   jFrame.Keys("[Tab]")
   Delay(3000)

# Validating Asset Transfer details

   web_utils.log_checkpoint("Review Search Parameters for 'Transaction History'",500,jFrame)	
   Delay(3000)
   find_transactions.Find("AWTComponentAccessibleName","Find alt i",10).Click()
   Delay(6000)
   web_utils.log_checkpoint("Review Transaction History Information",500,jFrame)
   Delay(1000)
   web_utils.log_checkpoint("In Transaction History form: Click on 'Details' next",500,jFrame)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Transaction History","ExtendedFrame"]  
   transaction_history=jFrame.FindChildEx(prop,val,60,True,60000)
   prop=["AWTComponentAccessibleName","AWTComponentIndex"]
   val=["Transaction Type Required",28]
   trns_status = transaction_history.FindChild(prop,val,60) 
   Log.Enabled=True
   aqObject.CheckProperty(trns_status,"wText",cmpIn,"TRANSFER")
   Log.Enabled=False  
   transaction_history.Find("AWTComponentAccessibleName","Details alt D",10).Click()
   Delay(6000)
   web_utils.log_checkpoint("Review Transaction History Details",500,jFrame)
   Delay(1000)
   web_utils.log_checkpoint("In Transaction Detail form: New 'Expense Account' and New 'Location' reviewed successfully",500,jFrame)
   Delay(1000)
   jFrame.Keys("[F4]")
   Delay(5000)
   jFrame.Keys("~v")
   Delay(2000)
   jFrame.Keys("r")
   Delay(2000)
   jFrame.Keys("~n")
  
# Submitting Create Accounting-Assets Program and capturing the Journal Imported Batch   

   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Submit Request","ExtendedFrame"]
   submitrequest_form=jFrame.FindChildEx(prop,val,60,True,60000)
   web_utils.log_checkpoint("Submitting 'Create Accounting' Program",500,jFrame)
   name = submitrequest_form.Find("AWTComponentAccessibleName","Name RequiredList of Values",20)
   name.Click()
   name.SetText("Create Accounting - Assets")
   Delay(5000)
   jFrame.Keys("[Tab]")
   Delay(2000)
   prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
   val=["Parameters","FlexWindow","0"]
   parameters_form=jFrame.FindChildEx(prop,val,60,True,90000)
   book_txtfield=parameters_form.FindChild("AWTComponentAccessibleName","Book Type Code REQUIRED List Values",10)
   book_txtfield.Click()
   book_txtfield.Keys("MAN USCORP BOOK")
   Delay(1000)
   parameters_form.Keys("[Tab]")
   Delay(1000)
   parameters_form.Keys("Transfers")
   delay(1000)
   parameters_form.Keys("[Tab]")
   Delay(1000)
   jFrame.Keys(aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d-%b-%Y"))
   Delay(1000)
   parameters_form.Keys("[Tab][Tab]")
   Delay(1000)
   parameters_form.Keys("a^[BS]")
   Delay(1000)
   parameters_form.Keys("Detail")
   parameters_form.Keys("[Tab]")
   web_utils.log_checkpoint("'Create Accounting - Assets' Program Parameters entered successfully",500,jFrame)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val = ["OK ALT O","FormButton"]
   parameters_form.FindChild(prop,val,60).Click()
   Delay(2000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Submit alt m","Button"]
   submitrequest_form.FindChild(prop,val,60).Click()
   Delay(2000)
   val = ["Decision Request submitted*","ChoiceBox"]
   decision_box = jFrame.FindChildEx(prop,val,60,True,12000)
   RequestID = aqConvert.VarToStr(''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit()))
   web_utils.log_checkpoint("'Create Accounting - Assets' program submitted successfully and Request ID is "+VarToStr(RequestID),500,jFrame)
   jFrame.Keys("~n")
   Delay(2000)
  
# Verifying create accounting concurrent job completing from the database

   dsn = self.testConfig['man_oracle_db']['dsn']
   user_id = self.testConfig['man_oracle_db']['userid']
   pwd = self.testConfig['man_oracle_db']['pwd']
   dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,RequestID)
   jFrame.Keys("~v")
   Delay(2000)
   jFrame.Keys("r")
   Delay(2000)
   jFrame.Keys("~i")
   Delay(2000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Requests","ExtendedFrame"]
   req_form=jFrame.FindChildEx(prop,val,30,True,90000)
   creq_id,log_path = form_utils.req_set_save_output(self,jFrame,req_form,"Journal Import",RequestID)
   web_utils.close_additional_browsers()
   

# Capturing Journal Imported Batch Name from the Journal Import program output file

   fo=open(log_path,"r") 
   lines=fo.readlines()
   self.log_message_web("Journal Imported Batch Name is : - "+lines[17][8:36].strip())
   app.Cells.Item[rowno,15] = lines[17][8:33].strip()    
   jFrame.Click()
   Delay(2000)
   self.close_forms(jFrame)   
   book.save()


 def save_log(self,file_type):
   Delay(8000)
   log_page=Sys.Browser("iexplore").Page("https://manheim-*.epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
   Delay(1000)
   log_page.Click()
   log_page.TextNode(0).Click()
   Delay(1000)
   Log.Enabled=True     
   screenshot=log_page.PagePicture()
   msg = (file_type+" File Opened Successfully")
   Log.Picture(screenshot,msg)
   Log.Enabled=False
   log_page.Keys("~f")
   Delay(5000)
   log_page.Keys("a")
   Delay(5000) 
   file_system_utils.create_folder(self.op_log_path)             
   log_path=self.op_log_path+"\\prc generate asset lines for a single project "+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
   Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
   Delay(3000)
   Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
   Delay(5000)
   Log.Enabled=True
   Log.File(log_path," Cost Adjustments Report "+file_type+" File Attached")
   Log.Enabled=False     
   Sys.Browser("iexplore").Page("https://manheim-*.epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close()
   web_utils.close_additional_browsers()



