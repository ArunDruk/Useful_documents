﻿import dbhelper
from ebiz import *
import web_utils
import dbhelper
import file_system_utils 
import form_utils
                        
class tc202082_is_us_review_project_commitments_po(Ebiz):
   op_log_path="C:\\Tc_Logs"
                        
   def login(self):
     self.login_user='pkjami'
     super().login()
     
   def goto_url(self,url):
    super().goto_url(self.testConfig['ebiz']['oci_is_url'])
                           
   def action(self,book): 
     global rowno      
     rowno = 2            
     app = book.Sheets.item["Requisition"]
     app1 = book.Sheets.item["Project"]  
     app2 = book.Sheets.item["Invoice"]   
     
     web_utils.log_checkpoint("Logged in to Oracle Applications Home Page Successfully",500,self.page)
     self.wait_until_page_loaded()       
     self.page.EvaluateXPath("//table[@id='menuContent']//div[contains(text(),'PC Inquiry')]")[0].scrollIntoView()
     self.page.EvaluateXPath("//table[@id='menuContent']//div[contains(text(),'PC Inquiry')]")[0].Click()
     web_utils.log_checkpoint("Click 'PC Inquiry' - Successful",500,self.page) 
     self.wait_until_page_loaded()
     delay(1000)
     self.page.NativeWebObject.Find("contentText","Project Status","A").Click()
     web_utils.log_checkpoint("Click 'Project Status' - Successful",500,self.page) 
     self.wait_until_page_loaded()
     delay(1000)
     self.page.NativeWebObject.Find("contentText","Project Status Inquiry","A").scrollIntoView()
     self.page.NativeWebObject.Find("contentText","Project Status Inquiry","A").Click()
     web_utils.log_checkpoint("Click 'Project Status Inquiry' - Successful",500,self.page)
     self.wait_until_page_loaded()
     Delay(10000)
     web_utils.validate_security_box()
     Delay(10000)
     jFrame=self.initializeJFrame()
     Delay(3000)
     form_utils.click_ok_btn(jFrame)  
     Delay(10000)
     
# Navigate to 'Find Project Status' Form:
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Find Project Status (Manheim Corporate Services)","ExtendedFrame"]
     proj_status = jFrame.FindChildEx(prop,val,40,True,90000)
     Sys.HighlightObject(proj_status)
     Delay(2000)
     web_utils.log_checkpoint("Navigation to  'Find Project Status Form' - Successful",500,jFrame)   
     
# Enter project Number:         
     val=["Project: NumberList of Values","VTextField"]
     proj_no=proj_status.FindChildEx(prop,val,60,True,40000)
     proj_no.Click()
     proj_no.Keys(app.Cells.item[rowno,11])
     delay(1000)
     web_utils.log_checkpoint("Entering Project Number :"+VarToStr(app.Cells.item[rowno,11])+" to validate commitment details",500,jFrame)        
# Click Find Button:    
     val=["Find alt i","Button"]
     find_btn=proj_status.FindChild(prop,val,60)
     find_btn.Click()
     delay(2000)
# Validate 'Project Status' Form:
     val=["Project Status *","ExtendedFrame"]
     proj_sts_form=jFrame.FindChild(prop,val,60)
     Sys.HighlightObject(proj_sts_form)
     web_utils.log_checkpoint("Navigation to Project Status Form Successfull",500,jFrame) 
     delay(1000)
# Click 'Commitments' button:
     val=["Commitments alt C","Button"]
     find_btn=proj_sts_form.FindChild(prop,val,60)
     find_btn.Click()
     delay(2000)
# Validate Commitments Form:
     val=["Find Commitments *","ExtendedFrame"]
     commit_form=jFrame.FindChild(prop,val,60)
     Sys.HighlightObject(commit_form)
     web_utils.log_checkpoint("Navigation to Commitments Form Successfull",500,jFrame) 
     delay(1000)
# Click Find Button in Commitments Form:
     val=["Find alt i","Button"]
     c_find_btn=commit_form.FindChild(prop,val,60)
     c_find_btn.Click()
     delay(2000)
# Validate Commitment Details Form:
     val=["Commitment Details (Manheim Corporate Services)*","ExtendedFrame"]
     com_det_frm=jFrame.FindChild(prop,val,60)
     Sys.HighlightObject(com_det_frm)
     delay(1000)
     web_utils.log_checkpoint("Navigation to Commitment Details Form Successfull",500,jFrame) 
     tool_bar = Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("ExtendedFrame", "Commitment Details (Manheim Corporate Services)*", 23).AWTObject("TitleBar", "", 0).AWTObject("LWComponent", "", 0).AWTObject("TitleBar$CaptionComp", "", 0)
     Sys.HighlightObject(tool_bar)
     tool_bar.DblClick()
# Validate Commitment Cost:
     prop1=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
     val1=["Project Raw Cost","VTextField",70]
     proj_raw_cost=com_det_frm.FindChild(prop1,val1,60)
     Sys.HighlightObject(proj_raw_cost)
     project_raw_cost_val = "%.2f" %(VarToFloat(proj_raw_cost.wText))
#     purchase_order_cost_value = "%.2f" %(VarToFloat(app2.Cells.item[rowno,15]))
     web_utils.log_checkpoint("Project Raw Cost Value - $"+VarToStr(project_raw_cost_val),500,jFrame) 
#     web_utils.log_checkpoint("Purchase Order Cost Value - $"+VarToStr(purchase_order_cost_value),500,jFrame)  
     delay(3000)    
#     if purchase_order_cost_value == project_raw_cost_val:
#            web_utils.log_checkpoint("Project Raw Cost Value matches with purchase order amount",500,jFrame)
#     else:
#            web_utils.log_error("Unable to match the po value with project raw cost")
     delay(1000)
     self.close_forms(jFrame)
     
     
     
def test():
  
 val = 1000
 val2 = VarToStr(val)+".00"   
 val3 = "%.2i" %(VartoInt(val2))
 print("success")
     
     
     
     
     
     
     
  