﻿from base import *
from driverchain import *
from ebiz import *
import test_utility
import gvar
import tc_logs



class Driver(Driverchain):
  global classarr,env
  
  def __init__(self):
    global test_env, sheet_obj, book     
    app = Sys.OleObject["Excel.Application"]
    Delay(1000)
    self.book = app.Workbooks.Open(Project.Path+"\\datasheets\\E2E\\E2E_022.xls")          
#    app.Visible = "True"    
    self.test_env=BuiltIn.ParamStr(14)
    self.oper_unit=BuiltIn.ParamStr(15) 
#    self.test_env="oci_stage"
#    self.oper_unit="US" 
    self.classarr = ["ie_clear_cache()","tc97776cai_us_project_contractor_labor_cost()"]
    super().__init__(self.classarr)
	
  def close_excel(self):    
    self.book.save()
    delay(1000)
    self.book.close()
	
	
### Added utilities in the main method for Rally TestComplete API Integration (Pushing to GIT in TOGGLE:OFF mode)###
    	
def main():
  try:
    gvar.dataprep['env'] =BuiltIn.ParamStr(14)
    obj=Driver()
    test_utility.start_test(__name__.center(70,'*'),'Core Financials - CF','CAI E2E','123075','CAI E2E - OCI Stage') 
    cobj = obj.run()
    print('evoke test_utility')
  except:
    gvar.dataprep['verdict'] = 'Fail'
    tc_logs.header_name('Test Failed - traceback shown below')       
    tc_logs.error_with_no_picture(traceback.format_exc(),'')       
    print('evoke test_utility')
  finally:
    test_utility.end_test()
    obj.close_excel()

