﻿import gvar

def google_account_dropdown():
  return gvar.dataprep['page'].EvaluateXPath("*//div//a[starts-with(@aria-label, 'Google Account:')]")[0]
  
def sign_out():
  return gvar.dataprep['page'].EvaluateXPath("*//div/a[contains(text(),'Sign out')]")[0]
  
def attach_icon():
  return gvar.dataprep['page'].EvaluateXpath("*//div[@class = 'M9']//div[@aria-label= 'Attach files']")[0]
  
def upload_button_window():
  return Sys.Browser("chrome").Window("#32770", "Open", 1).Window("ComboBoxEx32", "", 1).Window("ComboBox", "", 1).Window("Edit", "", 1)
  
def file_attachment(file_name):
  return gvar.dataprep['page'].EvaluateXpath("*//div[starts-with(@aria-label, 'Attachment: "+file_name+"')]")[0]
  
def compose_email_button():
  return gvar.dataprep['page'].EvaluateXpath("*//div[@class = 'nH']//div[contains(text(),'Compose')]")[0]
  
def new_message():
  return gvar.dataprep['page'].EvaluateXpath("*//div[@class = 'M9']//div[@aria-label = 'New Message']")[0]
  
def to_textbox():
  return gvar.dataprep['page'].EvaluateXpath("*//div[@class = 'M9']//div//textarea[@aria-label = 'To']")[0]
  
def subject_textbox():
  return gvar.dataprep['page'].EvaluateXpath("*//div[@class = 'M9']//div//input[@aria-label = 'Subject']")[0]
  
def send_button():
  return gvar.dataprep['page'].EvaluateXpath("*//div[@class = 'M9']//div[contains(text(),'Send')]")[0]
  
def msg_sent_validation():
  return gvar.dataprep['page'].FindChild("contentText","Message sent*",30)