﻿from ebiz import *
import web_utils
import form_utils
import file_system_utils
import ebiz

class tc93548cai_us_CreatePO(Ebiz):
  global rowno
  
  rowno = 2
  def login(self):
    self.login_user="rmaran"
    super().login()
  
  def action(self,book):
    app = book.Sheets.item["Requisition"]
    app1 = book.Sheets.item["Invoice"]
    self.wait_until_page_loaded()    
    self.log_checkpoint_message_web("Login Successful")
    
    temp=web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" PO PROCESS PURCHASE ORDERS')]")       
    self.verify_aqobject_chkproperty(temp[0],"contentText",cmpIn,"CAI "+self.oper_unit+" PO PROCESS PURCHASE ORDERS")
    self.log_message_web("Click 'CAI "+self.oper_unit+" PO PROCESS PURCHASE ORDERS' - Successful")      
    self.wait_until_page_loaded()  
      
    web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Buyer Work Center')]")       
    self.log_message_web("Click 'Buyer Work Center' - Successful")
    self.wait_until_page_loaded() 
    
    temp=web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Requisitions')]")       
    self.log_message_web("Click 'Requisitions' - Successful")  
    self.wait_until_page_loaded() 
            
    temp=web_utils.set_text(self.page,"//input[@title='Search Value: Buyer']","")
    
    temp=web_utils.slct_drpdwn_by_xpath(self.page,"//select[@name='addMorePickList']",'Unassigned')  
    temp=web_utils.clk_btn_by_xpath(self.page,"//button[contains(text(),'Add')]")
    self.log_message_web("Added 'Unassigned Requisitions' field to search category - Successful")
    self.wait_until_page_loaded()
    
    temp=web_utils.slct_drpdwn_by_xpath(self.page,"//select[@title='Search Value: Unassigned']",'Yes')
    search_req_no =VarToInt(app.cells.Item[2,15])
    
    temp=web_utils.set_text(self.page,"//input[@title='Search Value: Requisition']",VarToStr(app.cells.Item[2,15]))
    
    # Click Go Button
    obj=web_utils.get_btn_obj_by_xpath(self.page,"//button[contains(text(),'Go')]")     
    self.verify_aqobject_chkproperty(obj[0],"contentText",cmpIn,"Go")
    Delay(5000)
    obj[0].Click()  
    self.log_message_web("Click 'Go': Query Requisition Number Successful")     
    self.wait_until_page_loaded()
    #Delete later
    #select all
    temp=web_utils.slct_checkbox_by_xpath(self.page,"//input[@id='ResultsTable:triState']")
    
    
     
#    # loop thru table   
#    res_table=self.page.EvaluateXPath("//table[@class='x1o']")[0]    
#    tot_rows=res_table.rows.length
##    search_req_no=excel_obj.Cells.Item[rowno,15]
#    search_req_no =VarToInt(app.cells.Item[2,15])
#    count_lines=0
#   
#    for i in range(tot_rows-1):
#      pos=(web_utils.get_content_text_by_xpath(self.page,"//a[@id='ResultsTable:Request:"+aqConvert.VarToStr(i)+"']")).find(',')
#      if (web_utils.get_content_text_by_xpath(self.page,"//a[@id='ResultsTable:Request:"+aqConvert.VarToStr(i)+"']"))[0:VarToInt(pos)] == VarToStr(search_req_no):
#        web_utils.slct_checkbox_by_xpath(self.page,"//input[@name='ResultsTable:selected:"+aqConvert.VarToStr(i)+"']")
#        self.log_message_web("Select Requisition:'"+ aqConvert.VarToStr(search_req_no) +"'  - Successful")
#        count_lines+=1
#    
#    app1.Cells.item[rowno,16] = count_lines
#    if count_lines == 0:
#      self.log_error_message("Zero Requisitions selected.")
#      
#    self.log_message_web("No of lines selected "+aqConvert.VarToStr(count_lines))          
    # click Add       
    obj=web_utils.get_btn_obj_by_xpath(self.page,"//button[@id='AddToDocumentBuilder']")  
    self.verify_aqobject_chkproperty(obj[0],"contentText",cmpIn,"Add")
    obj[0].Click()    
    self.wait_until_page_loaded()
    self.log_message_web("Click 'Add' - Successful: Requisition added to Document Builder to create new order")

    total_amt=(Sys.Browser("iexplore").page("*").EvaluateXPath("//span[@id='BuilderTotalAmount']")[0].contentText)[:-3]
    self.log_message_web("TotalAmount: "+aqConvert.VarToStr(total_amt))
    
    app1.Cells.item[rowno,15] = total_amt
    
    # Click Create  
    obj=web_utils.get_btn_obj_by_xpath(self.page,"//button[@id='Create']")       
    if obj[0].isDisabled == False:
      obj[0].Click()  
    else:
      self.log_error_message("Create Button in Document Builder Section is not enabled")     
    self.log_message_web("Click 'Create' - Successful") 
    self.wait_until_page_loaded()   
#    excel_obj.Cells.Item[rowno,16] = Project.Variables.po_number
#    self.verify_aqobject_chkproperty(self.page.NativeWebObject.Find("contentText", "Standard Purchase Order*", "div"),"ContentText",cmpStartsWith,"Standard Purchase Order")
    delay(2000)
    pro = ("ObjectType","contentText") 
    val = ("TextNode","Update Standard Purchase Order *")
    apprPage = self.page.Find(pro,val,30)
    self.verify_aqobject_chkproperty(apprPage,"contentText",cmpStartsWith,"Update Standard Purchase Order")
    self.log_message_web("Navigate to 'update standard PO Page'  - successful")
    web_utils.clk_link_by_xpath(self.page,"//table[@id = 'PageActionButtonsRN']//button[@id='SubmitButton']")
    self.wait_until_page_loaded()      
    po_ord=self.page.NativeWebObject.Find("contentText", "Standard Purchase Order*", "div").ContentText  
    app1.Cells.Item[rowno,14]=''.join(x for x in po_ord if x.isdigit())
    self.log_message_web("PO Order Confirmation Message: "+aqConvert.VarToStr(po_ord))
    self.wait_until_page_loaded()  
    Delay(1000)  
    del app,app1,obj,po_ord,temp
    
  def click_cai_us_pur_ords(self):
     temp=web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//li/a[contains(text(),'CAI US PO PROCESS PURCHASE ORDERS')]")       
     self.verify_aqobject_chkproperty(temp[0],"contentText",cmpIn,"CAI US PO PROCESS PURCHASE ORDERS")
     self.log_message_web("Click 'CAI US PO PROCESS PURCHASE ORDERS' - Successful")      
     self.wait_until_page_loaded() 
     book.save()
     
