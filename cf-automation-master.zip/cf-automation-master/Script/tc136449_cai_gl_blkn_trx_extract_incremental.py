﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils
import winscp_utility
import web_utils


###This testcase is to submit CAI: GL Blackline Transactions Extract - Incremental and capture output and logs###

class tc136449_cai_gl_blkn_trx_extract_incremental(Ebiz):

  op_log_path="C:\\TC_Logs"

  def login(self):
    self.login_user="mfallwell"
    super().login()

  def action(self,book):

# Login to Oracle EBIZ and select CAI ALL GL BLACKLINE USER responsibility

    Log.Message("Inside action...") 
    web_utils.clk_fldr_link_by_xpath(self.page,"//div[text()='CAI ALL GL JOURNAL PROCESSING']")
    self.log_message_web("Click 'CAI ALL GL JOURNAL PROCESSING' - Successful")
    self.wait_until_page_loaded() 
    web_utils.clk_fldr_link_by_xpath(self.page,"//div[text()='Other']")
    self.log_message_web("Click 'Other' - Successful")
    self.wait_until_page_loaded() 
    web_utils.clk_link_by_xpath(self.page,"//div[text()='Profile']")
    self.log_message_web("Click 'Profile' - Successful")
    jFrame=self.initializeJFrame() 
    Delay(5000)
    form_utils.click_ok_btn(jFrame)
    Delay(3000)
    jFrame.Keys("[F11]")
    Delay(3000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Personal Profile Values","ExtendedFrame"]
    profile_values=jFrame.FindChildEx(prop,val,60,True,60000)
    profile_name = profile_values.Find("AWTComponentAccessibleName","Profile Name",20)
    profile_name.Click()
    Delay(3000)
    jFrame.Keys("XXCAI GL Blackline Extract Last Run Date")
    Delay(3000)
    jFrame.Keys("^[F11]")
    self.log_message_oracle_form(jFrame,"'XXCAI GL Blackline Extract Last Run Date' Profile Option information is attached")
    Delay(3000)
    jFrame.Keys("[F4]")
    Delay(3000)
    jFrame.Keys("[F4]")
    Delay(3000)
    jFrame.Keys("~o")
    Delay(4000)
    self.page.WaitProperty("contentText","CAI ALL GL BLACKLINE USER",6000)
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI ALL GL BLACKLINE USER')]")
    self.log_message_web("Click 'CAI ALL GL BLACKLINE USER' - Successful")
    Delay(3000)  
    self.page.wait() 
    self.page.EvaluateXpath("//table[@id='respList']//div[text()='Run']")[0].Click()
    self.log_message_web("Click 'Run' - Successful")
    Delay(2000)
    jFrame=self.initializeJFrame() 
    Delay(10000)
    form_utils.click_ok_btn(jFrame) 
    Delay(3000)
    
# Submitting "CAI: GL Blackline Transactions Extract - Incremental" Request Set using CAI ALL GL BLACKLINE USER responsibility
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit a New Request","ExtendedFrame"]
    submit_req_form=jFrame.FindChildEx(prop,val,30,True,60000)
    submit_req_form.FindChild("AWTComponentAccessibleName","OK alt O",10).Click()
    Delay(2000)
    jFrame.Keys("CAI: GL Blackline Transactions Extract - Incremental")
    delay(3000)
    self.log_message_web("Request Set Name: 'CAI: GL Blackline Transactions Extract - Incremental' - populated Successfully") 
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit Request","ExtendedFrame"]
    submit_req_form=jFrame.FindChildEx(prop,val,30,True,60000)
    submit_req_form.FindChild("AWTComponentAccessibleName","Submit alt m",10).Click()
    self.log_message_web("Click Submit Successful") 
    Delay(2000)
    jFrame.Keys("~o")
    self.log_message_oracle_form(jFrame,"'CAI: GL Blackline Transactions Extract - Incremental' is submitted")   
    RequestID = aqConvert.VarToInt(''.join(x for x in jFrame.find("AWTComponentAccessibleName","Request submitted*",100).AWTComponentAccessibleName if x.isdigit()))
    self.log_message_oracle_form(jFrame,"Request ID Of 'CAI: GL Blackline Transactions Extract - Incremental' is " + aqConvert.VarToStr(RequestID))
    Delay(2000)
    jFrame.Keys("~n")
    Delay(4000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000) 
    
#Checking in the DB for the completion of the concurrent programs
    dsn = self.testConfig['oracle_db']['dsn']
    user_id = self.testConfig['oracle_db']['userid']
    pwd = self.testConfig['oracle_db']['pwd']
    dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,VarToStr(RequestID)) 
    
# Gathering Request ID and Log File for the "CAI: GL Blackline Transactions Extract - Incremental" 
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,90000)
    self.req_set_save_output(jFrame,req_form,"CAI: GL Blackline Transactions Extract - Incremental",RequestID)
    fo=open(self.log_path,"r")
    lines=fo.readlines()
    Log.Enabled=True
    Log.Message(lines[0][0:104].strip())
    Log.Message(lines[1][0:40].strip())
    Log.Message(lines[2][0:85].strip())
    Log.Message(lines[3][0:104].strip())
    Log.Message(lines[4][0:104].strip())
    Log.Enabled=False
#    jFrame.Click()
#    Delay(2000)
#    jFrame.Keys("[F4]")
#    Delay(1000)
#    jFrame.Keys("~v")
#    Delay(1000)
#    jFrame.Keys("r")
#    Delay(1000)
#    jFrame.Keys("~i")
    Delay(2000)

# Gathering Request ID and Output File for the "CAI File Encrypt Program for Sterling Program"  
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,90000)
    self.req_set_save_log(jFrame,req_form,"CAI File Encrypt Program for Sterling",RequestID)
#    jFrame.Click()
#    Delay(2000)
#    jFrame.Keys("[F4]")
#    Delay(1000)
#    jFrame.Keys("~v")
#    Delay(1000)
#    jFrame.Keys("r")
#    Delay(1000)
#    jFrame.Keys("~i")
    Delay(2000)

# Gathering Request ID and Output File for the "CAI: Transfer files to Sterling"  
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,90000)
    self.req_set_save_log(jFrame,req_form,"CAI:Transfer files to Sterling (CAI: Transfer files to Sterling)",RequestID)
    fo=open(self.log_path,"r")
    lines=fo.readlines()
    Log.Enabled=True
    Log.Message("Outbound Extract Information : - "+lines[5][0:64].strip())
    Log.Message(lines[12][0:112].strip())
    Log.Message(lines[13][0:112].strip())
    Log.Message(lines[14][0:62].strip())
    Log.Message(lines[15][0:54].strip())
    Log.Message(lines[16][0:79].strip())
    Log.Message(lines[17][0:60].strip())
    Log.Message(lines[18][0:94].strip())
    Log.Message(lines[19][0:59].strip())
    Log.Message(lines[21][0:72].strip())
    Log.Message(lines[22][0:78].strip())
    Log.Message(lines[24][0:78].strip())
    Log.Message(lines[26][0:234].strip())
    Log.Message(lines[27][0:158].strip())
    Log.Message(lines[28][0:68].strip())
    Log.Message(lines[29][0:72].strip())
    Log.Enabled=False
    Delay(1000)
    jFrame.Click()
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~o")
    Delay(1000)      


  def req_set_save_log(self,jFrame,req_form,srch_child_name,Preqid):
    self.log_message_oracle_form(req_form,"Checking for "+aqConvert.VarToStr(srch_child_name)+ " Child Program Status")
    req_form.FindChild("AWTComponentAccessibleName","Refresh Data alt R",20).Click()
    i=20
    for x in range(1,180):     
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Name",i]
        child_name=req_form.Find(prop,val,10).wText 
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Phase",i+20]
        phase=req_form.Find(prop,val,10).wText 
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Request ID",i-10]
        creqid= aqConvert.VarToInt(req_form.Find(prop,val,10).wText)
                                       
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Status",i+30]         
        status =req_form.FindChild(prop,val,60)            
        if (child_name==srch_child_name) and (creqid>=Preqid) and (phase == "Completed"):
            self.log_message_oracle_form(req_form, aqConvert.VarToStr(srch_child_name)+" Phase Completed Successfuly")                             
            status.Keys("[Enter]")
            Delay(1000)
            req_form.FindChild("AWTComponentAccessibleName","View Log alt K",20).Click()  
            Delay(4000)
            output_page=Sys.Browser("iexplore").Page("https://core*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.*")
            output_page.Click()
            Delay(2000)
            output_page.Keys("~f")
            Delay(2000)
            output_page.Keys("a")
            Delay(5000)
            file_system_utils.create_folder(self.op_log_path)             
            self.log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"File"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"_%d%b%Y_%H%M")+".txt"    
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(self.log_path)
            Delay(1000)
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
            Delay(8000)
            Log.Enabled=True
            Log.File(self.log_path, aqConvert.VarToStr(srch_child_name)+" is Completed And Log file is attached")
            Log.Enabled=False     
            web_utils.close_additional_browsers()         
            Filesaved = 'True'
            return                           
        elif i >=29:
           Delay(15000)           
           req_form.FindChild("AWTComponentAccessibleName","Refresh Data alt R",20).Click()
           Delay(3000)
           i=20
           val=["Name",i]
           child_name=req_form.Find(prop,val,10).wText
        else:  
           Delay(2000)
           i=i+1 


  def req_set_save_output(self,jFrame,req_form,srch_child_name,Preqid):
    self.log_message_oracle_form(req_form,"Checking for "+aqConvert.VarToStr(srch_child_name)+ " Child Program Status")
    req_form.FindChild("AWTComponentAccessibleName","Refresh Data alt R",20).Click()
    i=20
    for x in range(1,180):     
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Name",i]
        child_name=req_form.Find(prop,val,10).wText 
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Phase",i+20]
        phase=req_form.Find(prop,val,10).wText 
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Request ID",i-10]
        creqid= aqConvert.VarToInt(req_form.Find(prop,val,10).wText)                                        
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Status",i+30]         
        status =req_form.FindChild(prop,val,60)            
        if (child_name==srch_child_name) and (creqid>=Preqid) and (phase == "Completed"):
            self.log_message_oracle_form(req_form, aqConvert.VarToStr(srch_child_name)+" Phase Completed Successfuly")                              
            status.Keys("[Enter]")
            Delay(1000)
            req_form.FindChild("AWTComponentAccessibleName","View Output alt p",20).Click()  
            Delay(4000)
            output_page=Sys.Browser("iexplore").Page("https://core*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.*")
            output_page.Click()
            Delay(2000)
            output_page.Keys("~f")
            Delay(2000)
            output_page.Keys("a")
            Delay(5000)
            file_system_utils.create_folder(self.op_log_path)             
            self.log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"File"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"_%d%b%Y_%H%M")+".txt"    
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(self.log_path)
            Delay(1000)
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
            Delay(8000)
            Log.Enabled=True
            Log.File(self.log_path, aqConvert.VarToStr(srch_child_name)+" is Completed And Output file is attached")
            Log.Enabled=False     
            web_utils.close_additional_browsers()         
            Filesaved = 'True'
            return                           
        elif i >=29:
           Delay(15000)           
           req_form.FindChild("AWTComponentAccessibleName","Refresh Data alt R",20).Click()
           Delay(3000)
           i=20
           val=["Name",i]
           child_name=req_form.Find(prop,val,10).wText
        else:  
           Delay(2000)
           i=i+1 
           
