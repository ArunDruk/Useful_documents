﻿import gvar

### In this method objects for below pages have been captured ###

#Control : Change Orders

def change_orders_tablink():
  prop_names = ["idStr","contentText","ObjectType"]
  prop_values = ["PA_CTRL_CHG_ORDS","Change Orders","Link"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def search_dropdown():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["customizationsPoplist","Select"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def go_button():
  prop_names = ["contentText","ObjectType"]
  prop_values = ["Go","Button"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def personalize_button():
  prop_names = ["contentText","ObjectType"]
  prop_values = ["Personalize","Button"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def advance_search_button():
  prop_names = ["contentText","ObjectType"]
  prop_values = ["Advanced Search","Button"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def any_radiobutton():
  prop_names = ["idStr","ObjectType","ObjectLabel"]
  prop_values = ["M__Ida","Button","Any"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def control_issues_link():
  control_issues = gvar.dataprep['page'].NativeWebObject.Find("contentText","Control: Issues","A")
  return control_issues


def type_shortname_textfeild():
  prop_names = ["idStr","ObjectType","ObjectLabel"]
  prop_values = ["Value_0","Textbox","Type Short Name"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def number_textfeild():
  prop_names = ["idStr","ObjectType","ObjectLabel"]
  prop_values = ["Value_1","Textbox","Number"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def summary_textfeild():
  prop_names = ["idStr","ObjectType","ObjectLabel"]
  prop_values = ["Value_3","Textbox","Task"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
  

def return_to_change_orders_link():
  return_issues = gvar.dataprep['page'].NativeWebObject.Find("contentText","Return to Change Orders","A")
  return return_issues


def saved_searches_button():
  prop_names = ["contentText","ObjectType"]
  prop_values = ["Saved Searches","Button"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
