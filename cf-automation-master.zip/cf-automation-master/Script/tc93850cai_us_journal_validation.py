﻿from ebiz import *
import dbhelper 
from file_system_utils import *

#This test case is to review Journal and capture status & accounting information

class tc93850cai_us_journal_validation(Ebiz):
 global rowno 
 
  
 def login(self):
    self.login_user="mfallwell"
    super().login()
    
 def action(self,book): 
   
    rowno = 2
    app = book.Sheets.item["Invoice"]
    Log.Message("Inside cai_us_journal_validation action...")     
    cai_gl_setup_link=self.page.Find("contentText","CAI ALL GL SETUP",30)
    self.verify_aqobject_chkproperty(cai_gl_setup_link,"contentText",cmpIn,"CAI ALL GL SETUP")
    cai_gl_setup_link.Click() 
    self.log_message_web("Click 'CAI ALL GL SETUP' - Successful")    
    self.page.wait_until_page_loaded()
    Delay(3000)
    self.page.keys("[Down]")
    self.page.keys("[Down]")
    Delay(2000)
    self.page.EvaluateXPath("//div[text()='Journals']")[0].ScrollIntoView()
    Delay(500)
    self.page.EvaluateXPath("//div[text()='Journals']")[0].Click()
#    self.page.NativeWebObject.Find("contentText","Journals","A").Click()    
    Delay(2000)
    self.page.wait_until_page_loaded()
    self.page.wait()
    self.log_message_web("Click 'Journals' - Successful")
    self.page.EvaluateXPath("//div[text()='Enter']")[0].Click()        
#    self.page.Find("namePropStr","RF.jsp?function_id=616&resp_id=50678&resp_appl_id=101&security_group_id=0&lang_code=US')",30).Click()
    self.log_message_web("Click Enter Journals - Successful")
    delay(10000)      
    jFrame=self.initializeJFrame()
    Delay(1000)
    form_utils.click_ok_btn(jFrame)
#    jFrame.Keys("~o")
#    ok_btn=Sys.Browser("iexplore").SwingObject("JBufferedFrame", "Oracle Applications*", -1).FindChild("AWTComponentName","ChoiceBox*",60)
#    if ok_btn.Exists:
#       ok_btn.Find("AWTComponentAccessibleName","OK ALT O",40).Click()
    
    # Find Journal  
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Journals","ExtendedFrame"]
#    jFrame=Sys.Browser("iexplore").WaitSwingObject("JBufferedFrame", "*", -1, 1)
    fnd_jrnl=jFrame.FindChildEx(prop,val,60,True,90000)
    fnd_jrnl.Find("AWTComponentAccessibleName","BatchList of Values",10).Click()
    fnd_jrnl.Find("AWTComponentAccessibleName","BatchList of Values",10).SetText("%"+VarToStr(app.Cells.item[rowno,20])+"%")
    self.log_message_oracle_form(jFrame,"Journal Batch : "+VarToStr(app.Cells.item[rowno,20])) 
    delay(1000) 
    jFrame.Keys("~i")
    Delay(5000)
    self.log_message_oracle_form(jFrame,"Find Journal Successful")      
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Enter Journals (CAI ALL LEDGERS)","ExtendedFrame"]
    ent_journals = jFrame.FindchildEx(prop,val,60,True,200000)  
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Batch Status",16]
    batch_status = ent_journals.Find(prop,val,60)
    while batch_status.wText =="":
      Delay(2000)
      batch_status = ent_journals.Find(prop,val,60)
    
    Log.Enabled=True
    aqObject.CheckProperty(batch_status,"wText",cmpIn,"Posted")
    Log.Enabled=False    
    delay(4000) 
    jFrame.Keys("~u")
    delay(2000)

#Verify Journal status and accounting inforamtion 
#    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#    val=["Category Required",3]
#    jrnl_category=jFrame.FindChildEx(prop,val,60,True,90000)
#    Log.Enabled=True
#    aqObject.CheckProperty(jrnl_category,"wText",cmpIn,"Purchase Invoices")
#    Log.Enabled=False
    
    dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
    user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
    pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
    dbhelper.verify_cai_journal_status(dsn,user_id,pwd,VarToStr(app.Cells.item[rowno,20]))

#    dbhelper.verify_cai_journal_status(VarToStr(app.Cells.item[rowno,20]))
    self.log_message_oracle_form(jFrame,"Review Journal Successful")
    self.close_forms(jFrame)
#    jFrame.Keys("[F4]")
#    Delay(1000)
#    jFrame.Keys("[F4]")
#    Delay(1000)
#    jFrame.Keys("[F4]")
#    Delay(1000)
#    jFrame.Keys("~o")
#    Delay(4000)
#    Sys.Browser("iexplore").page("https://*ebs.coxautoinc.com/forms/frmservlet*").Close()
    Delay(1000)
    

#def test_practice():
#  import dbhelper
#  dbhelper.verify_cai_journal_status("OCI_STAGE","RAC_ACCNT","Y4bLC5sb","30454041")
  





