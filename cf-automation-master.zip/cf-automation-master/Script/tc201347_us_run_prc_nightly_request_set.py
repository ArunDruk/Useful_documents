﻿import dbhelper
from ebiz import *
import web_utils
import dbhelper
import file_system_utils 
import form_utils
                        
class tc201347_us_run_prc_nightly_request_set(Ebiz):
   op_log_path="C:\\Tc_Logs"
                        
   def login(self):
     self.login_user='pkjami'
     super().login()
     
   def goto_url(self,url):
    super().goto_url(self.testConfig['ebiz']['oci_is_url'])
      
                           
   def action(self,book): 
     global rowno      
     rowno = 2            
     app = book.Sheets.item["Requisition"]
     app1 = book.Sheets.item["Project"]    
     
     web_utils.log_checkpoint("Logged in to Oracle Applications Home Page Successfully",500,self.page)
     self.wait_until_page_loaded()       
     self.page.EvaluateXPath("//table[@id='menuContent']//div[contains(text(),'PC User')]")[0].scrollIntoView()
     self.page.EvaluateXPath("//table[@id='menuContent']//div[contains(text(),'PC User')]")[0].Click()
     web_utils.log_checkpoint("Click 'PC User' - Successful",500,self.page) 
     self.wait_until_page_loaded()
     delay(1000)
     self.page.NativeWebObject.Find("contentText","Other","A").Click()
     web_utils.log_checkpoint("Click 'Other' - Successful",500,self.page) 
     self.wait_until_page_loaded()
     delay(1000)
     self.page.Keys("[Down]")
     self.page.NativeWebObject.Find("contentText","Requests","A").scrollIntoView()
     self.page.NativeWebObject.Find("contentText","Requests","A").Click()
     web_utils.log_checkpoint("Click 'Requests' - Successful",500,self.page)
     self.wait_until_page_loaded()

     delay(1000)
     self.page.NativeWebObject.Find("contentText","Run","A").Click()
     web_utils.log_checkpoint("Click 'Run' - Successful",500,self.page)
     Delay(10000)
     web_utils.validate_security_box()
     Delay(10000)
     jFrame=self.initializeJFrame()
     Delay(3000)
     form_utils.click_ok_btn(jFrame)  
     Delay(10000)
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Submit a New Request","ExtendedFrame"]
     jFrame.FindChildEx(prop,val,40,True,90000)
     Delay(2000)
     jFrame.keys("~s")
     Delay(2000)
     jFrame.keys("~o")                    
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Submit Request Set","ExtendedFrame"]
     submitrequest_form=jFrame.FindChildEx(prop,val,60,True,40000)
     self.verify_aqobject_chkproperty(submitrequest_form,"AWTComponentAccessibleName",cmpContains,"Submit Request Set") 
     Delay(2000)
     submitrequest_form.Find("AWTComponentAccessibleName","Request Set RequiredList of Values",60).Keys("MAN: PC US NIGHTLY INTERFACE")
     submitrequest_form.Keys("[Tab]")
     proj_no=VarToStr(app.Cells.item[rowno,11])
#     index_no,proj_no,tab,proj2,enddate,servdate,padate
     self.submit_req_set_params(submitrequest_form,jFrame,15,VarToStr(proj_no),"S","N","N","N","N","N")
     Delay(1000)
     self.submit_req_set_params(submitrequest_form,jFrame,16,VarToStr(proj_no),"S","N","N","N","N","N")   
     self.submit_req_set_params(submitrequest_form,jFrame,17,VarToStr(proj_no),"S","N","N","N","N","N")   
     self.submit_req_set_params(submitrequest_form,jFrame,18,VarToStr(proj_no),"Y","N","N","N","N","N")   
     self.submit_req_set_params(submitrequest_form,jFrame,19,VarToStr(proj_no),"Y","N","N","N","N","N")   
     jFrame.Keys("[Down]")
     self.submit_req_set_params(submitrequest_form,jFrame,19,VarToStr(proj_no),"Y","N","N","N","N","N")   
     jFrame.Keys("[Down]")
     jFrame.Keys("[Down]")
     self.submit_req_set_params(submitrequest_form,jFrame,19,VarToStr(proj_no),"Y","N","N","N","N","N")  
     jFrame.Keys("[Down]")
     self.submit_req_set_params(submitrequest_form,jFrame,19,VarToStr(proj_no),"S","N","N","N","N","N") 
     jFrame.Keys("[Down]")
     jFrame.Keys("[Down]")
#     self.submit_req_set_params(submitrequest_form,jFrame,19,VarToStr(proj_no),"Y","N","N","N","N")#date
     jFrame.Keys("[Down]")
     self.submit_req_set_params(submitrequest_form,jFrame,19,VarToStr(proj_no),"N","Y","N","N","N","N")#extra tab
     jFrame.Keys("[Down]")
     self.submit_req_set_params(submitrequest_form,jFrame,19,VarToStr(proj_no),"N","N","Y","N","N","N")
     jFrame.Keys("[Down]")
     self.submit_req_set_params(submitrequest_form,jFrame,19,VarToStr(proj_no),"N","Y","N","N","N","N")#extra tab and date
     jFrame.Keys("[Down]")
     self.submit_req_set_params(submitrequest_form,jFrame,19,VarToStr(proj_no),"N","N","N","Y","Y","Y")#2 iter. project and 2 dates
     jFrame.Keys("[Down]")
     self.submit_req_set_params(submitrequest_form,jFrame,19,VarToStr(proj_no),"N","Y","N","N","N","N")#extra tab and date
         
     Delay(1000)   
     self.log_message_oracle_form(jFrame,"Ready to Submit the MAN: PC US NIGHTLY INTERFACE Request Set")
     Delay(1000) 
     submitrequest_form.Find("AWTComponentAccessibleName","Submit",10).Click()
     Delay(2000)
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Decision Request submitted*","ChoiceBox"]
     decision_form=jFrame.FindChildEx(prop,val,60,True,40000)
     self.verify_aqobject_chkproperty(decision_form,"AWTComponentAccessibleName",cmpContains,"Request submitted") 
     RequestID = ''.join(x for x in decision_form.AWTComponentAccessibleName if x.isdigit())
     app.Cells.item[rowno,19] = RequestID
     self.log_message_oracle_form(jFrame,"Request ID " + aqConvert.VarToStr(RequestID))   
     Delay(2000)
     jFrame.Keys("~n")  
     Delay(2000)  
     self.close_forms(jFrame)  
     delay(1000)     

#     jFrame=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1)
#     RequestID = "156604524" 
           
   def submit_req_set_params(self,submitrequest_form,jFrame,index_no,proj_no,tab,proj2,enddate,servdate,padate,proj3):
     prop=["AWTComponentAccessibleName","AWTComponentIndex"]
     val=["Parameters",index_no]
     submitrequest_form.FindChild(prop,val,60).Click()
     Delay(2000)   
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Parameters","FlexWindow"]   
     parameter_form=jFrame.FindChild(prop,val,10)
     end_date = self.get_month_end()
     if tab == 'Y':
       parameter_form.Keys("[Tab]")
       val=["Project Number List Values","FlexTextField"]
       project_no = parameter_form.FindChild(prop,val,10)
       project_no.Keys(proj_no)
     elif tab == 'S':
       val=["Project Number List Values","FlexTextField"]
       project_no = parameter_form.FindChild(prop,val,10)
       project_no.Keys(proj_no)
#     parameter_form.Keys("~o")
     if proj2 == 'Y':
        val=["From Project Number*","FlexTextField"]
        project_from = parameter_form.FindChild(prop,val,10)
        project_from.click()
        project_from.Keys("^a[Del]")
        project_from.Keys(proj_no)
        val=["To Project Number*","FlexTextField"]
        project_to = parameter_form.FindChild(prop,val,10)
        project_to.click()
        project_to.Keys("^a[Del]")
        project_to.Keys(proj_no)
#        parameter_form.Keys("~o")
     if proj3 == 'Y':
        val = ["Project Number REQUIRED*","FlexTextField"]
        project_from = parameter_form.FindChild(prop,val,10)
        project_from.click()
        project_from.Keys("^a[Del]")
        project_from.Keys(proj_no)
        val=["To Project Number*","FlexTextField"]
        project_to = parameter_form.FindChild(prop,val,10)
        project_to.click()
        project_to.Keys("^a[Del]")
        project_to.Keys(proj_no)
     if enddate == 'Y':
        val=["End Date REQUIRED*","FlexTextField"]
        end_dt = parameter_form.FindChild(prop,val,10)
        end_dt.click()
        end_dt.Keys("^a[Del]")
        end_dt.Keys(end_date)
     if servdate == 'Y':
        val=["Date Placed In Service Through*","FlexTextField"]
        serv_date = parameter_form.FindChild(prop,val,10)
        serv_date.click()
        serv_date.Keys(end_date)
     if padate == 'Y':
        val=["PA Through Date REQUIRE*","FlexTextField"]
        pa_date = parameter_form.FindChild(prop,val,10)
        pa_date.click()
        pa_date.Keys(end_date)
     parameter_form.Keys("~o")   
     Delay(1000)

   def get_month_end(self):
       today = aqConvert.DateTimeToFormatStr(aqDateTime.Now(),'%d-%b-%Y')
       year = VarToInt(aqString.SubString(today,7,4)) 
       if aqString.SubString(today,3,3)== ('Mar' or 'May' or 'Jul' or 'Sep' or 'Nov'):
         end_date = '31-'+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),'%b-%Y')
         return end_date
       elif aqString.SubString(today,3,3) == 'Feb':
         if year % 4 == 0 and year % 100 != 0:
            end_date = '29-'+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),'%b-%Y')
         elif year % 100 == 0:
            end_date = '28-'+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),'%b-%Y')
         elif year % 400 ==0:
            end_date = '29-'+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),'%b-%Y')
         else:
            end_date = '28-'+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),'%b-%Y')
         return end_date 
       else:
         end_date = '30-'+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),'%b-%Y')
         return end_date 
     

     
def test():
  


  jFrame = Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1)
  prop3 = ["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]  
  val3 = ["Employee/Supplier","VTextField",51]
  supplier_det = jFrame.FindChild(prop3,val3,30).wText
  if supplier_det == "":
    Log.Message("True")
  prop1=["JavaFullClassName","AWTComponentIndex"]
  val1=["oracle.ewt.button.ContinuousButton","0"]
  drop_btn =  Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications - EBS", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("ExtendedFrame", "Requests", 26).AWTObject("LWComponent", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("FScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("DrawnPanel", "", 0).AWTObject("FScrollBox", "", 2).AWTObject("ScrollBox$1", "", 0).AWTObject("DrawnPanel", "", 0).AWTObject("LWScrollbar", "", 0).AWTObject("ContinuousButton", "", 0)
  Sys.HighlightObject(drop_btn)
  drop_btn.Click()
#   today = aqConvert.DateTimeToFormatStr(aqDateTime.Now(),'%d-%b-%Y')
#   year = VarToInt(aqString.SubString(today,7,4)) 
#   if aqString.SubString(today,3,3)== ('Mar' or 'May' or 'Jul' or 'Sep' or 'Nov'):
#     end_date = '31-'+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),'%b-%Y')
#     return end_date
#   elif aqString.SubString(today,3,3) == 'Feb':
#     if year % 4 == 0 and year % 100 != 0:
#        end_date = '29-'+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),'%b-%Y')
#     elif year % 100 == 0:
#        end_date = '28-'+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),'%b-%Y')
#     elif year % 400 ==0:
#        end_date = '29-'+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),'%b-%Y')
#     else:
#        end_date = '28-'+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),'%b-%Y')
#     return end_date 
#   else:
#     end_date = '30-'+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),'%b-%Y')
#     return end_date 
#     
#
#
#     
#
