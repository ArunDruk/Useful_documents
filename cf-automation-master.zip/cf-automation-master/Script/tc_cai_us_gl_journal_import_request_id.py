﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils
import winscp_utility

### AUTHOR: UDAYASHANKAR MALAY
### DATE: NOV 12 2019


### This script finds out the request id of the Journal import 

class tc_cai_us_gl_journal_import_request_id(Ebiz):

# op_log_path="C:\\TC_Logs"
# ct_gl_jrnl_files="C:\\CT_JRNL_Files"

 def login(self):
    self.login_user="amalappan"
    super().login()

 def action(self,book):
#    global jrnl_imp_pro 
#    self.add_ct_journal_details() # uncomment later
     self.get_journal_import_request_id(book)

### Modifying CT_TEST.txt file 
# def add_ct_journal_details(self):
#    file_name= Project.Path+"DataSheets\\Oracle-GL-Journal\\CT_TEST.DAT"
#    gl_date = aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%m/%d/%Y")
#    period = aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%b-%y")
#    sprd_desc = aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%b/%d/%y")
#    desc = aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%b/%d/%y")
#    ref_id_1 = aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d%S")
#    ref_id_2 = aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%S%d")
#    fo=open(file_name,"r+")
#    lines=fo.readlines()
#    old_gl_date_line1=lines[0][34:44].strip()
#    old_period_line1=lines[0][75:81].strip()
#    old_sprd_desc_line1=lines[0][146:155].strip()
#    old_desc_line1=lines[0][176:185].strip()
#    old_ref_id_line1=lines[0][266:270].strip() 
#    old_gl_date_line2=lines[1][34:44].strip()
#    old_period_line2=lines[1][75:81].strip()
#    old_sprd_desc_line2=lines[1][146:155].strip() 
#    old_desc_line2=lines[1][176:185].strip() 
#    old_ref_id_line2=lines[1][266:270].strip()  
#    fo.close()
#    fo=open(file_name,"r+")
#    data=fo.read()
#    fo.seek(34,0)
#    fo.write(gl_date) 
#    fo.seek(75,0)
#    fo.write(period.upper()) 
#    fo.seek(146,0)
#    fo.write(sprd_desc)
#    fo.seek(176,0)
#    fo.write(desc)
#    fo.seek(266,0)
#    fo.write(ref_id_1)  
#    fo.seek(331,0)
#    fo.write(gl_date) 
#    fo.seek(372,0)
#    fo.write(period.upper()) 
#    fo.seek(443,0)
#    fo.write(sprd_desc)
#    fo.seek(473,0)
#    fo.write(desc)
#    fo.seek(563,0)
#    fo.write(ref_id_2) 
#    fo.close()
#    file_system_utils.create_folder(self.ct_gl_jrnl_files)
#    file_exist=aqFileSystem.FindFiles("C:\\CT_JRNL_Files","CT_TEST.DAT")
#    if file_exist != None:
#     aqFileSystem.DeleteFile("C:\\CT_JRNL_Files\\CT_TEST.DAT")
#    aqFileSystem.CopyFile(Project.Path+"DataSheets\\Oracle-GL-Journal\\CT_TEST.DAT", "C:\\CT_JRNL_Files\\CT_TEST.DAT")
#    log_path = ("C:\\CT_JRNL_Files\\CT_TEST.DAT")
#    Log.Enabled=True
#    Log.File(log_path, "CT_GL_JE Import File Attached")
#    Log.Enabled=False 
#
#
## Placing CT_TEST.DAT file in //DAUT2I//incoming//ATG_OU//GL_JE_BALANCES_INTF

 def get_journal_import_request_id(self,book):
      
#     # uncomment later
#     
#    Stored_session = "opc@stage-fin-iad1-ebsapp1.private.stagefin.oraclevcn.com" #"j_autr@ftpnonprodautr.oracleoutsourcing.com"
#    local_dir = "C:\\CT_JRNL_Files"    
#    remote_dir =  self.winscpConfig[self.testConfig['ebiz']['env']]['remote_dir']+"incoming//ATG_OU//GL_JE_BALANCES_INTF"
#    upload_file_name = "CT_TEST.DAT"
#    winscp_utility.upload_file(Stored_session,local_dir,remote_dir,upload_file_name)
#    Log.Enabled=True       
#    Log.Message("CT_TEST.DAT file placed in the GL_JE_BALANCES_INTF directory")           
#    Log.Enabled=False
#
## Login to Oracle EBIZ and select the responsibility
#  
#    Log.Message("Inside action...")   
#    self.page.WaitProperty("contentText","CAI ALL GL JOB SCHEDULER",6000)
#    cai_gl_submit_link=self.page.Find("contentText","CAI ALL GL JOB SCHEDULER",30)
#    self.verify_aqobject_chkproperty(cai_gl_submit_link,"contentText",cmpIn,"CAI ALL GL JOB SCHEDULER")
#    cai_gl_submit_link.Click() 
#    self.log_message_web("Click 'CAI ALL GL JOB SCHEDULER' - Successful")        
#    self.page.Wait()    
#    cai_gl_submit_link=self.page.NativeWebObject.Find("contentText","Submit Request","A")
#    cai_gl_submit_link.Click() 
#    self.page.Wait() 
#    self.log_message_web("Click 'Submit Request' - Successful") 

    app = book.Sheets.item["Invoice"]
    self.wait_until_page_loaded()
    Log.Message("Inside action...")
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" AP INVOICE PROCESSING')]")
    self.log_message_web("Click 'CAI "+self.oper_unit+" AP INVOICE PROCESSING' - Successful")
    Delay(1000)
    self.wait_until_page_loaded() 
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Invoices')]")
    self.log_message_web("Click 'Invoices' - Successful") 
    Delay(1000)
    self.wait_until_page_loaded()
    Delay(1000)  
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Entry')]")
    self.log_message_web("Click 'Entry' - Successful") 
    Delay(1000)
    self.wait_until_page_loaded()
    self.page.EvaluateXPath("//div[text()='Invoices']")[1].Click()
    self.log_message_web("Click 'Invoices' - Successful")
    delay(5000)
#    web_utils.validate_security_box()
#    delay(10000)
    jFrame = self.initializeJFrame()
    Delay(5000)
    form_utils.click_ok_btn(jFrame)
    delay(5000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000)    
    
# uncomment later
# Gathering Request ID and Output File for the "CAI Oracle GL Inbound JE Interface Program" 
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChild(prop,val,30)
    #RequestID=app.Cells.Item[2,20]
    RequestID='28452475'
    self.req_set_save_output1(jFrame,req_form,"JOURNAL IMPORT",RequestID)
    jFrame.Click()
    self.close_forms(jFrame) 
    Delay(2000)
  
      
    
    
 def req_set_save_output1(self,jFrame,req_form,srch_child_name,Preqid):
     i=20
     prop=["AWTComponentAccessibleName","AWTComponentIndex"]
     val=["Request ID",i-10] 
     creqid=VarToInt(req_form.Find(prop,val,10).wText)             
              
     for x in range(i,50):
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Name",x]
        child_name=req_form.Find(prop,val,10)
        child_name.Keys("[Enter]")
        child_name.Click()
        child_name=child_name.wText
        
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Phase",i+20]
        phase=req_form.Find(prop,val,10).wText 
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Request ID",i-10]
        creqid=VarToInt(req_form.Find(prop,val,10).wText)         
                            
        if x>20:
           jFrame.Keys("[Down]") 
           
           Delay(1000)
           prop=["AWTComponentAccessibleName","AWTComponentIndex"]
           val=["Phase",i+20]
           phase=req_form.Find(prop,val,10).wText 
           prop=["AWTComponentAccessibleName","AWTComponentIndex"]
           val=["Request ID",i-10]
           creqid=VarToInt(req_form.Find(prop,val,10).wText)
                        
           
        if (child_name==srch_child_name): #and (creqid >= VarToInt(Preqid)): # and (phase == "Completed")
         app.Cells.Item[2,21]=creqid
        
        i=i+1
                   
         
           
 