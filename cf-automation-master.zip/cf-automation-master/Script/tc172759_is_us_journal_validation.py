﻿from ebiz import *
import dbhelper 
from file_system_utils import *



class tc172759_is_us_journal_validation(Ebiz):
 global rowno 
 
  
 def login(self):
    self.login_user="mfallwell"
    super().login()

 def goto_url(self,url):
   super().goto_url(self.testConfig['ebiz']['oci_is_url'])
    
 def action(self,book): 
   
    rowno = 2
    app = book.Sheets.item["Invoice"]
    web_utils.log_checkpoint("Logged in to Oracle Applications Home Page Successfully",500,self.page) 
    self.wait_until_page_loaded()      
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='menuContent']//div[contains(text(),'GL Corporate Accounting User')]") 
    self.wait_until_page_loaded()
    self.page.NativeWebObject.Find("contentText","Journals","A").Click()
    web_utils.log_checkpoint("Click 'Journals' - Successful",500,self.page)
    delay(2000)
    self.page.NativeWebObject.Find("contentText","Enter","A").Click()
    web_utils.log_checkpoint("Click 'Enter' - Successful",500,self.page)
    web_utils.validate_security_box()
    Delay(20000)
    jFrame=self.initializeJFrame()
    form_utils.click_ok_btn(jFrame)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Journals","ExtendedFrame"]
    fnd_jrnl=jFrame.FindChildEx(prop,val,60,True,90000)
    fnd_jrnl.Find("AWTComponentAccessibleName","BatchList of Values",10).Click()
    fnd_jrnl.Find("AWTComponentAccessibleName","BatchList of Values",10).SetText("%"+VarToStr(app.Cells.item[rowno,20])+"%")
    web_utils.log_checkpoint(" Enter Journal Import Batch ID : "+VarToStr(app.Cells.item[rowno,20]),500,jFrame) 
    delay(2000) 
    jFrame.Keys("~i")
    Delay(20000)
    web_utils.log_checkpoint("Find Journal Successful",500,jFrame) 
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Enter Journals*","ExtendedFrame"]
    ent_journals = jFrame.FindchildEx(prop,val,60,True,200000)  
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Batch Status",16]
    batch_status = ent_journals.Find(prop,val,60)
    while batch_status.wText =="":
      Delay(2000)
      batch_status = ent_journals.Find(prop,val,60)  
    delay(4000) 
    jFrame.Keys("~u")
    delay(4000) 
    web_utils.log_checkpoint("Review Journal Successful",500,jFrame) 
    delay(1000) 
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Journals (MAN GLB ALL)*","ExtendedFrame"]
    jrnls=jFrame.FindChildEx(prop,val,60,True,60000)
    jrnls.FindChild("AWTComponentName","FormsTabPanel*",60).ClickTab("Other Information")
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Status: Posting",0]
    jrnl_val = jFrame.FindChild(prop,val,60)
    jrnl_status=jrnl_val.wText  
    web_utils.log_checkpoint("Journal Status: "+jrnl_status,500,jFrame) 
    Log.Enabled=True
    aqObject.CheckProperty(jrnl_val,"wText",cmpIn,"Posted")
    Log.Enabled=False
    web_utils.log_checkpoint("Journal is Posted",500,jFrame) 
    delay(4000) 
    jrnls.FindChild("AWTComponentName","FormsTabPanel*",60).ClickTab("Lines")
    delay(4000) 
    dsn = self.testConfig['man_oracle_db']['dsn']
    user_id = self.testConfig['man_oracle_db']['userid']
    pwd = self.testConfig['man_oracle_db']['pwd']
    dbhelper.verify_is_journal_status(dsn,user_id,pwd,VarToStr(app.Cells.item[rowno,20]))
    web_utils.log_checkpoint("Review Journal Successful",500,jFrame) 
    self.close_forms(jFrame)
    Delay(1000)





