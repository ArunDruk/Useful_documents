﻿from ebiz import *

#Author:            Prabhakaran Rajendran
#TestCaseID:        TC84508
#UserStoryID:       US192318
#Reviewed_By:       Husain Syed & Seelam Lakshmi



class tc84508cai_us_create_manual_ap_invoice_no_match(Ebiz):
  global login_user
  
  def login(self):
    self.login_user="amalappan"
    super().login()
    
  def action(self):
      global rowno, app, txnum, tabno
    
      rowno=2
      tabno=1
      p = Sys.Process("EXCEL")
      app = Sys.OleObject["Excel.Application"]
      Delay(1000)
      app.Visible = "True"
      book = app.Workbooks.Open(Project.Path+"\\datasheets\\Oracle-Iprocurement\\Inv_01.Xls")
      delay(3000) 
      
      RowCount = book.ActiveSheet.UsedRange.Rows.Count
      
      while (rowno<RowCount+1):
          txnum = app.cells.Item[rowno,1]
          if rowno ==2:
            self.nav_ap1()
          else:
            self.multi_inv()
          self.ap_inv_hdr(rowno,app)
          rowno = self.ap_inv_lns(rowno,app,txnum,tabno)
          self.ap_inv_val(app,book,rowno)
#          book.save()
          delay(1000)
          rowno=rowno + 1
          tabno = tabno + 1
#          Log.Message("rowno after 1st invoice: "+ aqConvert.IntToStr(rowno))

      delay(1000)
      book.save()
      delay(1000)
      book.close()
      delay(1000)
      p.Terminate()
      delay(1000)
#      self.close_forms()
      jFrame.Keys("[F4]")
      Delay(1000)
      jFrame.Keys("[F4]")
      Delay(1000)
      jFrame.Keys("~o")
      Delay(1000)
      self.browser.page("*").Close() 
  
  def nav_ap1(self):      
      self.log_message_web("Logged in to Oracle Applications Home Page")  
      web_utils.clk_link_by_xpath(self.page,"//a[text()='CAI "+self.oper_unit+" AP INVOICE PROCESSING']") 
#      self.page.Find("contentText","CAI "+self.oper_unit+" AP INVOICE PROCESSING",30).Click()
      delay(2000)
      self.page.Find("contentText","Invoices",30).Click()
      delay(2000)
      self.page.wait()
      self.page.Find("contentText","Entry",30).Click()
      delay(2000)  
      self.page.Find("namePropStr","RF.jsp?function_id=1026&resp_id=50816&resp_appl_id=200&security_group_id=0&lang_code=US')",30).Click()
      delay(13000)
      jFrame=self.initializeJFrame()
#      jFrame.Keys("~o")
      delay(10000)            
      p_names = ("JavaClassName","AWTComponentAccessibleName")
      p_values = ("ExtendedFrame","Invoice Workbench (CAI "+self.oper_unit+" AP INVOICE PROCESSING)")
      obj=jFrame.FindChildEx(p_names,p_values,50,True,60000)
      if obj.Exists:
        self.log_checkpoint_message_web("AP Invoice Page Launched Successfully")
      else:
        self.log_message_oracle_form(jFrame,"Unable to Launch AP Invoice Form")
        
  def multi_inv(self):
      jFrame=self.initializeJFrame()      
      Delay(4000)
      jFrame.Keys("[F4]")
#      delay(2000)
#      jFrame.Find("AWTComponentAccessibleName","Yes ALT Y").Click()
      delay(3000)
      jFrame.Find("AWTComponentAccessibleName","Open alt O",30).Click()
      Delay(3000)
      jFrame.Find("AWTComponentAccessibleName","Open alt O",30).Click()
      Delay(1000)  
      jFrame.Keys("[Down]")
      Delay(1000)
      jFrame.Keys("[Enter]")
      delay(10000)
      p_names = ("JavaClassName","AWTComponentAccessibleName")
      p_values = ("ExtendedFrame","Invoice Workbench (CAI "+self.oper_unit+" AP INVOICE PROCESSING)")
      obj=jFrame.FindChild(p_names,p_values,50)
      if obj.Exists:
        self.log_checkpoint_message_web("AP Invoice Page Launched Successfully")
      else:
        self.log_message_oracle_form(jFrame,"Unable to Launch AP Invoice Form")     
            
  def ap_inv_hdr(self,rowno,app):  
      jFrame=self.initializeJFrame()
      self.page.wait()
      delay(2000)
      jFrame.Keys("~l")
      Delay(1000)
      jFrame.Keys("o")
#      jFrame.Find("AWTComponentName","VButton20",30).Click()
      delay(2000)
      jFrame.Find("AWTComponentAccessibleName", "Find",30).Click()
      delay(1000)
      jFrame.Find("AWTComponentAccessibleName", "Find",30).Keys("*A")
      delay(2000)
      jFrame.Keys("~o")
      delay(2000)
      p_names = ("JavaClassName","AWTComponentAccessibleName")
      p_values = ("VTextField","Trading Partner/Supplier Name RequiredList of Values")
      obj=jFrame.Find(p_names,p_values,50)
      if obj.Exists:
        self.log_checkpoint_message_web("AP Invoice Header template selected successfully")
      else:
        self.log_message_oracle_form(jFrame,"Unable to Launch Required Header Template for Creating Invoice")
      
      jFrame.Find("AWTComponentAccessibleName","RequesterList of Values",30).Click()
      delay(1000)
      jFrame.Find("AWTComponentAccessibleName","RequesterList of Values",30).Keys(app.Cells.Item[rowno,2])
      delay(1000)
      jFrame.Find("AWTComponentAccessibleName","Trading Partner/Supplier Name RequiredList of Values",30).Click()
      delay(1000)
      jFrame.Find("AWTComponentAccessibleName","Trading Partner/Supplier Name RequiredList of Values",30).Keys(app.Cells.Item[rowno,3])
      delay(1000)
      jFrame.Keys("[TAB]")
      delay(5000)
      jFrame.Find("AWTComponentAccessibleName", "Invoice Date RequiredList of Values",30).Click()
      jFrame.Keys("[TAB]")
      jFrame.Find("AWTComponentAccessibleName", "Invoice Num Required",30).Keys("TST_INV: "+aqConvert.DateTimeToFormatStr(aqDateTime.Time(),"%H:%M:%S"))
      delay(1000)
      jFrame.Keys("[TAB]")
      jFrame.Find("AWTComponentAccessibleName", "Invoice Amount Required",30).Click()
      delay(1000)
      jFrame.Find("AWTComponentAccessibleName", "Invoice Amount Required",30).Keys(app.Cells.Item[rowno,4])
      delay(1000)
      jFrame.Keys("[TAB]")
      self.log_message_oracle_form(jFrame,"Invoice Header Details Entered Successfully")
      
  def ap_inv_lns(self,rowno,app,txnum,tabno):
   
      delay(1000)
#      Log.Message("rowno line level: "+ aqConvert.IntToStr(rowno))
      jFrame=Sys.Browser("iexplore").SwingObject("JBufferedFrame", "*", -1, 1)
#      if (rowno == 2):  
#        jFrame.FindChild("AWTComponentName","FormsTabPanel0",30).ClickTab("2 Lines")
#      else:
      jFrame.FindChild("AWTComponentName","FormsTabPanel"+(aqConvert.VarToStr(tabno)),30).ClickTab("2 Lines")
      delay(3000)
      jFrame.Keys("~l")
      Delay(1000)
      jFrame.Keys("o")
      delay(2000)
        
      jFrame.Find("AWTComponentAccessibleName", "Find",30).Click()
      delay(1000)
      jFrame.Find("AWTComponentAccessibleName", "Find",30).Keys("*A")
      delay(2000)
      jFrame.Keys("~o")
      delay(4000)
      p_names = ("JavaClassName","AWTComponentAccessibleName")
      p_values = ("VTextField","Quantity Invoiced")
      obj=jFrame.Find(p_names,p_values,50)
      if obj.Exists:
        self.log_checkpoint_message_web("AP Invoice Line template selected successfully")
      else:
        self.log_message_oracle_form(jFrame,"Unable to Launch Required Line Template for Creating Invoice")
      delay(1000)
      
      line = 0
      while ((app.Cells.Item[rowno, 1])== txnum):
        pro = ("AWTComponentAccessibleName","AWTComponentIndex")
        values = ("Ship To LocationList of Values",255 +line)
        delay(1000)
        if line == 0:
          jFrame.Find(pro,values,50).Click()
          delay(2000)
        else:
          jFrame.Keys("[Down]")
          delay(1000)
          jFrame.Find(pro,values,50).Click()
          
        jFrame.Find(pro,values,50).Keys(app.Cells.Item[rowno,5])
        
        delay(1000)
        jFrame.Find("AWTComponentAccessibleName","Amount Required",30).Click()
        delay(2000)
        jFrame.Find("AWTComponentAccessibleName","Amount Required",30).Keys(app.Cells.Item[rowno,6])
        delay(1000)
        jFrame.Find("AWTComponentAccessibleName","Purchasing CategoryList of Values",30).Click()
        delay(1000)
        jFrame.Find("AWTComponentAccessibleName","Purchasing CategoryList of Values",30).Keys(app.Cells.Item[rowno,7])
        delay(1000)
        jFrame.Find("AWTComponentAccessibleName","Default Distribution AccountList of Values",30).Click()
        delay(1000)
        jFrame.Find("AWTComponentAccessibleName","Default Distribution AccountList of Values",30).Keys(app.Cells.Item[rowno,8])
        delay(1000)
        jFrame.Find("AWTComponentAccessibleName","Project NumberList of Values",30).Click()
        delay(1000)
        jFrame.Find("AWTComponentAccessibleName","Project NumberList of Values",30).Keys(app.Cells.Item[rowno,9])
  #      delay(1000)
  #      jFrame.Keys("[TAB]")
        delay(1000)
        jFrame.Find("AWTComponentAccessibleName","Task",30).Click()
        delay(1000)
        jFrame.Find("AWTComponentAccessibleName","Task",30).Keys(app.Cells.Item[rowno,10])
        delay(1000)
        jFrame.Find("AWTComponentAccessibleName","Expenditure Type RequiredList of Values",30).Click()
        delay(1000)
        jFrame.Find("AWTComponentAccessibleName","Expenditure Type RequiredList of Values",30).Keys(app.Cells.Item[rowno,11])
        delay(1000)
        jFrame.Find("AWTComponentAccessibleName","Expenditure Organization RequiredList of Values",30).Click()
        delay(1000)
        jFrame.Find("AWTComponentAccessibleName","Expenditure Organization RequiredList of Values",30).Keys(app.Cells.Item[rowno,12])
        delay(1000)
        jFrame.Keys("^s")
        self.log_message_oracle_form(jFrame,"Invoice Line Details Entered Successfully: Line no -"+aqConvert.IntToStr(line+1))
        line = line + 1
        rowno = rowno + 1
        
      rowno = rowno - 1
      return rowno
#      Log.Message("return rowno: "+ aqConvert.IntToStr(rowno))
      
  def ap_inv_val(self,app,book,rowno):
      jFrame=Sys.Browser("iexplore").SwingObject("JBufferedFrame", "*", -1, 1)
      jFrame.FindChild("AWTComponentName","FormsTabPanel1",30).ClickTab("1 General")
      delay(1000)
      jFrame.Keys("~c")
      delay(1500)
      jFrame.Keys("~v")
      delay(1000)
      jFrame.Keys("~k")
      delay(10000)
      jFrame.Keys("^s")
      delay(2000)
      pro=("AWTComponentAccessibleName","AWTComponentIndex")
      values=("Invoice Num Required",32)
      inv = jFrame.Find(pro,values,30).wText
      self.log_message_oracle_form(jFrame,"AP Invoice created SuccessFully :"+inv)
      delay(1000)
#      app = Sys.OleObject["Excel.Application"]
#      Delay(1000)
#
#      book = app.Workbooks.Open(Project.Path+"\\datasheets\\Oracle-Iprocurement\\.xlsx")
#      delay(1000)
#      sheet = book.Sheets.Item["Sheet1"]      
      app.Cells.Item[rowno,13] = inv
      book.save()
      
      p_names = ("JavaClassName","AWTComponentAccessibleName")
      p_values = ("VTextField","Status")
      obj=jFrame.Find(p_names,p_values,50)
      if obj.wText == "Validated":
        self.log_checkpoint_message_web("Invoice Validated Successfully")
      else:
        self.log_message_oracle_form(jFrame,"Check for Invoice Holds & Re-Validate")
