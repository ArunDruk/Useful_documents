﻿import database_service
import traceback
import gvar
import key_utilities
import tc_logs
    
 
def get_order_header_details_query():
   sql = """SELECT  ooha.header_id AS "headerId"
            , ooha.order_number AS "orderNumber"
            , moc.consignment_id AS "orderConsignmentId"
            , moc.vin as "orderVIN"
            , ooha.flow_status_code as "flowStatusCode"
            , ooha.open_flag as "orderOpenFlag"
            , ooha.cancelled_flag  "orderCancelledFlag"
            , TO_CHAR(nvl(moc.sale_date , ooha.creation_date),'DD-MON-YYYY') "orderSaleDate"
            , oos.name                        "orderSource"
            , ooha.orig_sys_document_ref      "orderSourceReferenceId"
            , hca_bill.cust_account_id        "billToCustomerId"
            , hca_bill.account_number         "orderBillToCustomerNumber"
            , hca_bill.account_name           "billToCustomerName"
            , hca_bill.attribute15            "billToGroupCode" 
            , hcsua_sold_to.cust_account_id   "soldToCustomerId"
            , hcsua_sold_to.account_number    "orderSoldToCustomerNumber"
            , hcsua_sold_to.account_name      "soldToCustomerName"
            , hcsua_sold_to.attribute15       "soldToGroupCode"
            , nvl( moc.purchase_location_code, ( SELECT hcasa.attribute1
                                          FROM hz_cust_acct_sites_all hcasa, hz_cust_site_uses_all hcsua
                                          WHERE  1=1
                                          AND   hcsua.site_use_id = ooha.ship_to_org_id
                                          AND hcsua.cust_acct_site_id = hcasa.cust_acct_site_id
                                          AND hcsua.site_use_code = 'SHIP_TO'
                                          AND hcsua.status = 'A'
                                         ) ) "orderPurchaseLocation"
            , jrre.attribute2        "orderAuctionNumber"
            , jrret.resource_name    "salesRepName" 
            , moc.sold_flag   "consignmentSoldFlag"
            , ooha.context    "orderContext"
            , ooha.attribute1        "serviceOrderId"
            , ooha.attribute15       "orderBusinessUnit"
            , ooha.attribute16       "orderLateFeeExempt" 			  
            , ooha.attribute12       "orderSalesChannel"  
            , ooha.attribute14       "orderSalesType"
            , ooha.attribute6        "orderAuctionFormat"
            , ooha.attribute8        "orderLeaseAccountNr"   
            , ooha.attribute13       "orderLease"
            , ooha.ATTRIBUTE7        "Independent_Auction"
            , ooha.ATTRIBUTE9        "Operator"               
            , ooha.ATTRIBUTE10       "orderThirdPartyRemarketer"
            , ooha.ATTRIBUTE11       "orderVehicleOffsite"
      FROM   oe_order_headers_all         OOHA 
           , oe_transaction_types_tl      OTTA
           , oe_order_sources             OOS
           , manar.man_om_consignments    MOC
           , jtf_rs_salesreps             JRS
           , jtf_rs_resource_extns        JRRE  
           , jtf_rs_resource_extns_tl     JRRET
           , hz_cust_accounts             HCA_BILL
           , hz_cust_acct_sites_all       HCASA_BILL_TO
           , hz_cust_site_uses_all        HCSUA_BILL_TO
           , hz_cust_accounts             HCSUA_SOLD_TO
      WHERE  1=1
      AND    moc.consignment_id(+)                 = to_number(nvl(ooha.attribute2,0)) 
      AND    ooha.order_type_id                    = otta.transaction_type_id
      AND    ooha.order_source_id                  = oos.order_source_id   
      AND   jrs.salesrep_id                        = ooha.salesrep_id
      AND   jrre.resource_id                       = jrs.resource_id
      AND   jrret.resource_id                      = jrre.resource_id 
      AND   otta.language                          = USERENV ('LANG')  
      AND   jrret.language                         = USERENV ('LANG')  
      AND   ooha.invoice_to_org_id                 = hcsua_bill_to.site_use_id
      AND   hcsua_bill_to.cust_acct_site_id        = hcasa_bill_to.cust_acct_site_id
      AND   hcasa_bill_to.cust_account_id          = hca_bill.cust_account_id
      AND   ooha.sold_to_org_id                    = hcsua_sold_to.cust_account_id """
   return sql    
def get_order_header_details():
  try:    
   sql = get_order_header_details_query()
   if aqString.Trim(gvar.dataprep['orderNumber']): 
    sql = sql + " AND ooha.order_number = " + VarToStr(gvar.dataprep['orderNumber'])
   if aqString.Trim(gvar.dataprep['consignmentId']):
    sql = sql + " AND moc.consignment_id = " + VarToStr(gvar.dataprep['consignmentId'])
   if ( ( gvar.dataprep['orderNumber']   and gvar.dataprep['customerNumber'])  or 
        ( gvar.dataprep['consignmentId'] and gvar.dataprep['customerNumber']) ):     
      sql = sql + aqString.Format(" AND (hca_bill.account_number = '%s' OR hcsua_sold_to.account_number = '%s')",gvar.dataprep['customerNumber'],gvar.dataprep['customerNumber'])      
   sql = sql + ' ' + ' ORDER BY ooha.order_number ASC'
   rows = database_service.query_oracle_db(sql)
   if(GetVarType(rows)== VarToInt(9)): 
     return rows 
   else:
      Log.Error('No Recoeds Found, Please check your Query')
      Runner.Stop()
  except Exception as e:
      Log.Message(traceback.format_exc())      
  
def get_order_api_testtype_data(testtype):
     execute_test_data(sql = test_data_sql_query(testtype))

def test_data_sql_query(testtype):
    if testtype == 'order_api_get': 
       sql = """SELECT * FROM G2G.TCGLOBAL 
            WHERE system = '%s' and invoice = 'N' and transfer = 'N' and oms = 'N' and title = 'N' 
            and vehicle_status = 'SF' and nextgear = 'N' and test_result = 'Pass' limit 1""" 
    if testtype == 'order_api_post': 
       sql = """SELECT * FROM G2G.TCGLOBAL 
          WHERE system = '%s' and invoice = 'N' and transfer = 'N' and oms = 'N' and title = 'N' 
          and vehicle_status is null and nextgear = 'N' and test_result is null limit 1""" 
    return sql 

def execute_test_data(sql):
    sql = aqString.Format(sql, gvar.dataprep['env'] )
    results = database_service.query_mysql(sql)
    if (GetVarType(results)== VarToInt(9)):
       gvar.db_store(results)
    else:
      Log.Error("Data Exception-No Test Data")
       
def get_manheim_resale_vin(): 
  try:
    sql = f""" SELECT hz.account_name "SOLD_TO CUST",hz.account_number "SOLD_TO_NUM",hcb.account_name "BILL_TO_CUST",
              hcb.account_number "BILL_TO_NUM",hz.attribute15 group_code,H.CONTEXT,H.order_number,
              S.NAME "SOURCE",H.attribute2 "CONSIGN_ID",H.attribute4 "VIN",H.ordered_date 
              FROM oe_order_headers_all H,hz_cust_accounts hz,hz_cust_accounts hcb,hz_cust_site_uses_all hcsua,
              hz_cust_acct_sites_all hcasa,apps.oe_order_sources S, oe_order_lines_all l     
              WHERE h.header_id = l.header_id
                 AND H.open_flag IN ('Y','N')
                 AND L.open_flag = 'N'
                 AND H.cancelled_flag = 'N' 
                 AND H.CONTEXT IN ('US SELLER')
                 AND S.NAME = 'ODS'
                 AND length(h.attribute4) = 17
                 AND H.attribute2 <> 0  
                 AND H.order_source_id = S.order_source_id 
                 AND H.sold_to_org_id = hz.cust_account_id 
                 AND hcsua.site_use_id = H.invoice_to_org_id 
                 AND hcsua.cust_acct_site_id = hcasa.cust_acct_site_id 
                 AND hcasa.cust_account_id = hcb.cust_account_id 
                 AND EXISTS ( SELECT 1 FROM fa_additions fa where fa.tag_number = h.attribute2 )
                 AND hz.attribute15 = '{gvar.dataprep['group_code']}'
              ORDER BY h.ordered_date DESC 
              FETCH FIRST 1 rows only """
    rows = database_service.query_oracle_db(sql)
    if (GetVarType(rows) == VarToInt(9)) and len(rows)>0:
      for row in rows:
        vin = row['VIN']
        tc_logs.checkpt_with_no_picture(f"Manheim resale VIN: {vin}")
      return vin
  except Exception as e:
    tc_logs.error_with_no_picture(traceback.format_exc(),'')
    
def validate_bulk_upload():
  try:
    sql = f""" SELECT batch.name, aps.trx_date , rcta.trx_number, rcta.customer_trx_id, aps.amount_due_original, aps.amount_due_remaining
               FROM ra_customer_trx_all rcta,
               ra_batch_sources_all batch,
               ar_payment_schedules_all aps
                WHERE 1=1--rcta.trx_number='218723'  
                   AND batch.batch_source_id = rcta.batch_source_id
                   AND rcta.customer_trx_id = aps.customer_trx_id
                   AND batch.batch_source_id = 1021 ---name ='Online Solutions'
                   AND trunc(aps.trx_date) = '15-JAN-2020'
                   ORDER BY rcta.trx_number desc 
                   fetch first 1 row only; """
    rows = database_service.query_oracle_db(aqString.Format(sql))
    tc_logs.test_data("----- Verifying the Bulk Upload Data -----")
    if (GetVarType(rows) == VarToInt(9)) and len(rows)>0: 
      for row in rows:
        name= row['NAME']
        tc_logs.checkpt_with_no_picture(f"Batch Name: {name}")
      return name
  except Exception as e:
    tc_logs.error_with_no_picture(traceback.format_exc(),'')
 
       
def validate_order_creation(vin):
  try:
    sql = f""" SELECT CONTEXT,order_number,ordered_date 
                FROM oe_order_headers_all 
               WHERE 1=1 
                 --AND cancelled_flag = 'N'
                 AND attribute4 = '{vin}'
              ORDER BY ordered_date DESC
               FETCH FIRST 2 ROWS ONLY """
    rows = database_service.query_oracle_db(aqString.Format(sql))
    tc_logs.test_data("----- Verifying the order creation after resale -----")
    if (GetVarType(rows) == VarToInt(9)) and len(rows)>0:
      for row in rows:
        order_type = row['CONTEXT']
        order_number = row['ORDER_NUMBER']
        if order_type == 'US SELLER':
          tc_logs.checkpt_with_no_picture(f"Order number associated with the order type '{order_type}' having a group code of '{gvar.dataprep['group_code']}' is '{order_number}'")
        elif order_type == 'US BUYER':
          tc_logs.checkpt_with_no_picture(f"Order number associated with the order type '{order_type}' is '{order_number}'")
        else:
          Log.Checkpoint(f"{order_type} order number not found. Possible reasons could be either inactive dealer or invalid/corrupted data.")  
  except Exception as e:
    Log.Message(traceback.format_exc())
    
def get_fa_asset_number(vin):
  try:
    sql = f""" SELECT faa.asset_number,faa.tag_number,faa.DESCRIPTION,faa.serial_number,
                     FAR.asset_id,FAR.status,FAR.book_type_code,FAR.date_retired
                FROM fa_additions faa, fa_retirements  FAR
                WHERE 1=1 
                AND FAR.asset_id  = faa.asset_id
                AND FAA.serial_number = '{vin}'
                --AND TRUNC(FAR.date_retired)<= TRUNC(sysdate)
                ORDER BY FAR.date_retired DESC
                FETCH FIRST 1 ROW ONLY """
    rows = database_service.query_oracle_db(aqString.Format(sql))
    tc_logs.test_data("----- Capturing asset number and asset status -----")
    if (GetVarType(rows) == VarToInt(9)) and len(rows)>0:
      for row in rows:
        db_asset_number = row['ASSET_NUMBER']
        tc_logs.checkpt_with_no_picture(f"Fixed Asset number: '{db_asset_number}'")
        db_asset_status = row['STATUS']
        tc_logs.checkpt_with_no_picture(f"Asset status captured from Oracle Database: '{db_asset_status}'")
      return db_asset_number,db_asset_status
    else:
      tc_logs.error_with_no_picture("Asset number data not found becuase of possiblily running the depreciation program")
  except Exception as e:
    Log.Message(traceback.format_exc())


def get_manheim_resale_vin_remarketer():
  try:
    sql = """ SELECT  DISTINCT hz.account_name "SOLD_TO_CUST", hz.account_number "SOLD_TO_NUM",hcb.account_name "BILL_TO_CUST"
                              , hcb.account_number "BILL_TO_NUM", H.attribute10 "3PR DEALER",H.CONTEXT, H.order_number,L.ordered_item
                              , S.NAME "SOURCE", H.attribute2 "CONSIGN_ID", H.attribute4 "VIN", H.ordered_date
              FROM    oe_order_headers_all H,hz_cust_accounts hz,hz_cust_accounts hcb,hz_cust_site_uses_all hcsua
                      ,hz_cust_acct_sites_all hcasa,apps.oe_order_sources S,apps.oe_order_lines_all L--,ra_customer_trx_all ract
              WHERE   H.open_flag IN('Y','N')
              AND     H.cancelled_flag = 'N'
              AND     H.CONTEXT NOT IN ('US VEHICLE SERVICES','US ASSURANCE')   
              AND h.attribute10 is not null
              AND     S.NAME = 'ODS'
              AND     H.header_id = L.header_id
              AND     H.order_source_id = S.order_source_id
              AND     H.sold_to_org_id = hz.cust_account_id
              AND     hcsua.site_use_id = H.invoice_to_org_id
              AND     hcsua.cust_acct_site_id = hcasa.cust_acct_site_id
              AND     hcasa.cust_account_id = hcb.cust_account_id
              AND   hcb.attribute15 = 'GEAB'
              and   hz.attribute15 = '%s'
              ORDER BY H.ordered_date DESC
              FETCH FIRST 1 ROW ONLY"""
    rows = database_service.query_oracle_db(aqString.Format(sql,gvar.dataprep['group_code']))
    if (GetVarType(rows) == VarToInt(9)) and len(rows)>0:
      for row in rows:
        Log.Checkpoint(f"Manheim resale VIN: {row['VIN']}")
      return row['VIN']
  except Exception as e:
    Log.Message(traceback.format_exc())
    
def get_pending_or_processed_asset_number(status):
  tc_logs.test_data("----- Get asset number and asset status from Oracle DB -----")
  try:
    sql = f""" SELECT faa.asset_number,faa.tag_number,faa.DESCRIPTION,faa.serial_number,
                     FAR.asset_id,FAR.status,FAR.book_type_code,FAR.date_retired
                FROM fa_additions faa, fa_retirements  FAR
                WHERE 1=1 
                AND FAR.asset_id  = faa.asset_id
                AND FAR.status = '{status}'
                AND FAA.serial_number is not null
                AND LENGTH(FAA.serial_number) = 17
                AND TRUNC(FAR.date_retired)<= TRUNC(sysdate)
                ORDER BY FAR.date_retired DESC
                FETCH FIRST 1 ROW ONLY """
    rows = database_service.query_oracle_db(sql)
    if (GetVarType(rows) == VarToInt(9)) and len(rows)>0:
      for row in rows:
        db_asset_number = row['ASSET_NUMBER']
        tc_logs.checkpt_with_no_picture(f"Fixed Asset number: {db_asset_number}")
        db_asset_status = row['STATUS']
        tc_logs.checkpt_with_no_picture(f"Asset Status: {db_asset_status}")
      return db_asset_number,db_asset_status
    else:
      tc_logs.error_with_no_picture("Asset number data not found becuase of possiblily running the depreciation program")
  except Exception as e:
    Log.Message(traceback.format_exc())

def check_request_id_status(request_id, wait_time = 60000):
  try:
    completed_flag = False
    sql = f""" SELECT DESCRIPTION,request_id,actual_start_date,actual_completion_date
                    ,phase_code,status_code,completion_text 
                FROM fnd_concurrent_requests 
               WHERE request_id = '{request_id}' """
    for count in range(1,11):
      tc_logs.msg_with_no_picture(f"Sql queried for {count} time(s).")
      aqUtils.Delay(wait_time)
      rows = database_service.query_oracle_db(sql)
      if (GetVarType(rows) == VarToInt(9)) and len(rows)>0:
        for row in rows:
          status = row['STATUS_CODE']
          phase = row['PHASE_CODE']
          completed_flag = (status == 'C' and phase == 'C')
          if completed_flag:
             tc_logs.checkpt_with_no_picture(f"Concurrent program completed successfully for requestid: {request_id} with status: {status} and phase: {phase}")
             break
          elif phase == 'C' and status == 'E':
            tc_logs.error_with_no_picture("Concurrent job completed with error!!!")
      return completed_flag
    if(count == 10):
      tc_logs.error_with_no_picture(f"Concurrent program failed for requestid: {request_id} with status: {status} and phase: {phase}.Please check the issue and re-submit the program!!!"," ") 
  except Exception as e:
    Log.Message(traceback.format_exc())
 
def check_request_id_status_new(request_id, wait_time = 30000):
#  tc_logs.validation("----- Capturing and validating the Request_id status and phase code -----")
  try:
    completed_flag = False
    sql = """ SELECT DESCRIPTION,request_id,actual_start_date,actual_completion_date
                    ,phase_code,status_code,completion_text 
                FROM fnd_concurrent_requests 
               WHERE request_id = '%s' """
    aqUtils.Delay(wait_time)           
    for count in range(1,11):
      rows = database_service.query_oracle_db(aqString.Format(sql,request_id))
      if ( (GetVarType(rows) == VarToInt(9)) and len(rows)>0 and 
           (rows[0]['STATUS_CODE'] == 'C' and rows[0]['PHASE_CODE'] == 'C') ):
          tc_logs.checkpt_with_no_picture(f"Request completed ")
          tc_logs.checkpt_with_no_picture(f"Status: Completed ")
          tc_logs.checkpt_with_no_picture(f"Phase: {rows[0]['PHASE_CODE']}")
          completed_flag = True
          break
      else:
          aqUtils.Delay(wait_time)     
    if(count == 10):
      tc_logs.error_with_no_picture(f"""Request didn't completed \n status: {rows[0]['STATUS_CODE']} \n phase: {rows[0]['PHASE_CODE']}""")
    return  completed_flag       
  except Exception as e:
    Log.Message(traceback.format_exc())

def get_booked_status_order():
  tc_logs.header_name("TEST DATA PROVIDES".center(70,'*'))
  ##Added for Handling NG Scenario Raghu
  action = {'SELLER' : 'US SELLER',
            'BUYER'  : 'US BUYER',
            'NG SELLER':'US NG SELLER'}
  sql = f""" SELECT ooha.order_number ORDER_NUMBER  
        FROM  manar.man_om_consignments moca
           ,  oe_order_lines_all      oola
           ,  oe_order_headers_all    ooha
        where 1=1
        AND   moca.purchase_location_code ='{gvar.dataprep['auction_code']}'
        AND   to_char(moca.consignment_id)  = ooha.attribute2
        AND   ooha.header_id      = oola.header_id
        AND   ooha.context like '{action[gvar.dataprep['finalize_type']]}'
        AND   oola.CONTEXT    like 'US VEH%'
        AND   oola.FLOW_STATUS_CODE ='BOOKED'
        AND   ooha.creation_date >=  add_months(TRUNC(sysdate),-5)
        FETCH FIRST 1 ROWS ONLY """
  Log.Message(sql)      
  rows = database_service.query_oracle_db(sql)
  if (GetVarType(rows) == VarToInt(9)) and len(rows)>0:
    gvar.dataprep['order_number'] = rows[0]['ORDER_NUMBER']
    tc_logs.test_data(f" {gvar.dataprep['finalize_type']} ORDER_NUMBER:{gvar.dataprep['order_number']}")
    tc_logs.test_data(f"AUCTION_CODE: {gvar.dataprep['auction_code']}")
    
def get_booked_status_order_new():
  tc_logs.header_name("TEST DATA PROVIDES".center(70,'*'))
  ##Added for Handling NG Scenario Raghu
  action = {'SELLER' : 'US SELLER',
            'BUYER'  : 'US BUYER',
            'NG SELLER':'US NG SELLER'}
  sql = f""" SELECT ooha.order_number ORDER_NUMBER  , moca.purchase_location_code AUCTION_CODE
        FROM  manar.man_om_consignments moca
           ,  oe_order_lines_all      oola
           ,  oe_order_headers_all    ooha
        where 1=1
        --AND   moca.purchase_location_code ='{gvar.dataprep['auction_code']}'
        AND   to_char(moca.consignment_id)  = ooha.attribute2
        AND   ooha.header_id      = oola.header_id
        AND   ooha.context like '{action[gvar.dataprep['finalize_type']]}'
        AND   oola.CONTEXT    like 'US VEH%'
        AND   oola.FLOW_STATUS_CODE ='BOOKED'
        AND   ooha.creation_date >=  add_months(TRUNC(sysdate),-5)
        FETCH FIRST 1 ROWS ONLY """
  Log.Message(sql)      
  rows = database_service.query_oracle_db(sql)
  if (GetVarType(rows) == VarToInt(9)) and len(rows)>0:
    gvar.dataprep['order_number'] = rows[0]['ORDER_NUMBER']
    gvar.DATAPREP['auction_code'] = rows[0]['AUCTION_CODE']
    tc_logs.test_data(f" {gvar.dataprep['finalize_type']} ORDER_NUMBER:{gvar.dataprep['order_number']}")
    tc_logs.test_data(f"AUCTION_CODE: {gvar.dataprep['auction_code']}")

        
def asset_status_after_gain_loss_program(asset_number): 
  tc_logs.test_data("----- Asset Status and Amount after running the Calculate Gains and Losses program -----")
  try:
    sql = f""" SELECT retirement_id,book_type_code,asset_id,status,gain_loss_amount
                FROM fa_retirements 
               WHERE asset_id = '{asset_number}' """
    rows = database_service.query_oracle_db(sql)
    if (GetVarType(rows) == VarToInt(9)) and len(rows)>0:
      for row in rows:
        asset_status = row['STATUS']
        tc_logs.checkpt_with_no_picture(f"Asset status after runinng the calculate gain and loss program: {asset_status}")
        db_gain_loss_amount = row['GAIN_LOSS_AMOUNT']
        tc_logs.checkpt_with_no_picture(f"Total Gain and loss after running the calculate gain and loss program: {db_gain_loss_amount}")
      return asset_status,db_gain_loss_amount
  except Exception as e:
    Log.Message(traceback.format_exc())
    
    
def get_current_fa_open_period():
  try:
    sql = """ SELECT book_type_code,period_name,fiscal_year,period_num,period_open_date,period_close_date
                FROM fa_deprn_periods 
               WHERE 1=1 
                 AND book_type_code = 'MAN USPOLI BOOK' 
                 ORDER BY period_open_date DESC
                 FETCH FIRST 1 ROW ONLY """
    rows = database_service.query_oracle_db(sql)
    if (GetVarType(rows) == VarToInt(9)) and len(rows)>0:
      for row in rows:
        db_current_open_period = row['PERIOD_NAME']
        Log.Checkpoint("Current open peiod captured from Oracle database: " + db_current_open_period)
      return db_current_open_period
  except Exception as e:
    Log.Message(traceback.format_exc())

def get_odm_default_auction():
  try:
    sql = f"select AUCTION from odm.config_tb where env = '{gvar.dataprep['env']}' and active = 'Y'"
    rows = database_service.query_mysql(sql)
    if (GetVarType(rows) == VarToInt(9)) and len(rows)>0:
      for row in rows:
        gvar.store('auction_code',row['AUCTION'])
        tc_logs.test_data(f"AUCTION_CODE: {gvar.dataprep['auction_code']}")
    if ( (GetVarType(rows) == VarToInt(9)) and ( len(rows) == 0 ) ):
        tc_logs.error_with_no_picture("No record found pls check the Qry")
  except Exception as e:
    Log.Message(traceback.format_exc())

def get_booked_order(orderType,auction_code):
  tc_logs.header_name("TEST DATA PROVIDES".center(70,'*'))
  try:
    sql =f"""SELECT jrdv.attribute1,header.order_number, header.context, 
             line.flow_status_code,line.attribute5,header.ordered_date 
             FROM oe_order_headers_all header, oe_order_lines_all line,jtf_rs_defresources_v jrdv 
             WHERE header.header_id = line.header_id
             AND jrdv.attribute6 = line.attribute5
             AND regexp_like(jrdv.attribute1,'[51]')
             AND header.context = {orderType}
             AND header.open_flag = 'Y'
             AND line.open_flag = 'Y'
             AND line.flow_status_code = 'BOOKED'
             AND header.last_update_date > add_months(TRUNC(sysdate),-2)
             AND jrdv.attribute1 = {auction_code}
             ORDER BY header.last_update_date DESC
             FETCH FIRST 1 ROW ONLY"""
    
    rows = database_service.query_oracle_db(sql)
    if (GetVarType(rows) == VarToInt(9)) and len(rows)>0:
      for row in rows:
        gvar.store('buyer_order_number',row['ORDER_NUMBER'])
        tc_logs.test_data(f"BUYER_ORDER_NUMBER: {gvar.dataprep['buyer_order_number']}")
      
  except Exception as e:
    Log.Message(traceback.format_exc())

       
def get_orders_where_lines_booked(sql3 =""):
  tc_logs.header_name("TEST DATA PROVIDES".center(70,'*'))
  try:
    sql1 = """SELECT jrdv.attribute1,header.order_number, header.context, 
             line.flow_status_code,line.attribute5,header.ordered_date 
             FROM oe_order_headers_all header, oe_order_lines_all line,jtf_rs_defresources_v jrdv 
             WHERE header.header_id = line.header_id
             AND jrdv.attribute6 = line.attribute5
             --AND regexp_like(jrdv.attribute1,'[51]')
             AND header.context = 'US BUYER'
             AND header.open_flag = 'Y'
             AND line.open_flag = 'Y'
             AND line.flow_status_code = 'BOOKED'
             AND header.last_update_date > add_months(TRUNC(sysdate),-2)"""
    
    sql2 = """ORDER BY header.last_update_date DESC
             FETCH FIRST 1 ROW ONLY"""
    sql = sql1 + sql3 + sql2
    rows = database_service.query_oracle_db(sql)
    if (GetVarType(rows) == VarToInt(9)) and len(rows)>0:
      for row in rows:
        gvar.store('buyer_order_number',row['ORDER_NUMBER'])
        gvar.store('auction_code',row['ATTRIBUTE1'])
        tc_logs.test_data(f"BUYER_ORDER_NUMBER: {gvar.dataprep['buyer_order_number']}")
        tc_logs.test_data(f"AUCTION_CODE: {gvar.dataprep['auction_code']}")
      return rows
  except Exception as e:
    Log.Message(traceback.format_exc())
    
def verify_buyer_lines_status(order_number,wait_time = 120000,status = 'CLOSED'):
  tc_logs.validation(f"Verifying and Validating the Buyer lines {status}".center(70,'*'))
  Delay(wait_time)
  closed = False
  try:  
    sql = f"""SELECT header.order_number, line.line_id, line.ordered_item,
             line.flow_status_code, header.context 
             FROM oe_order_headers_all header, oe_order_lines_all line
             WHERE header.header_id = line.header_id 
             AND header.order_number = '{order_number}'
             AND line.ordered_item <> 'TITLE RELEASE'"""
    rows = database_service.query_oracle_db(sql)
    tc_logs.checkpt_with_no_picture(f"For buyer_order_number {order_number}:")
    if ((GetVarType(rows) == VarToInt(9)) and len(rows)>0):
      for row in rows:
        if not row['FLOW_STATUS_CODE'] == status: 
          tc_logs.error_with_no_picture(f"line_id: {row['LINE_ID']} and line_status: {row['FLOW_STATUS_CODE']}.Please check this line as its not closed"," ")
        else:
         closed = True
         tc_logs.checkpt_with_no_picture(f"line_id: {row['LINE_ID']} and line_status: {row['FLOW_STATUS_CODE']}")
    return closed
  except Exception as e:
    Log.Message(traceback.format_exc())

        
    
def verify_order_lines_status(order_number,wait_time = 30000,status = 'CLOSED'):
  tc_logs.validation(f"Order Line Workflow Status Validation {status}".center(70,'*'))
  Delay(wait_time)
  try:  
    sql = f"""SELECT header.order_number, line.line_id, line.ordered_item,
             line.flow_status_code, header.context , to_char(line.line_id) item_key, line.context context_line_type
             FROM oe_order_headers_all header, oe_order_lines_all line
             WHERE header.header_id = line.header_id 
             AND header.order_number = '{order_number}'
             AND line.ordered_item <> 'TITLE RELEASE'"""
    rows = database_service.query_oracle_db(sql)
    tc_logs.checkpt_with_no_picture(f"For order_number {order_number}:")
    if ((GetVarType(rows) == VarToInt(9)) and len(rows)>0):
      for row in rows:
        if not row['FLOW_STATUS_CODE'] == status:
#          print_workflow_order_line_info ('OEOL',row['ITEM_KEY'],row['CONTEXT_LINE_TYPE'])
          tc_logs.error_with_no_picture(f"Order Number: {row['ORDER_NUMBER']} Item Type: OE : {row['LINE_ID']} and line_status: {row['FLOW_STATUS_CODE']}.Please check this line as its not closed"," ")
          raise 
#        print_workflow_order_line_info ('OEOL',row['ITEM_KEY'],row['CONTEXT_LINE_TYPE'])
        tc_logs.checkpt_with_no_picture(f"Order Number: {row['ORDER_NUMBER']}  line_id: {row['LINE_ID']} and line_status: {row['FLOW_STATUS_CODE']}")
  except Exception as e:
    Log.Message(traceback.format_exc())    
 
    
def get_netting_status_code(request_id,wait_time = 10000):
  tc_logs.checkpt_with_no_picture(f"----- Validate status code for request id: {request_id} -----")
  try:
    sql = f""" SELECT request_id,total_dr_amt, total_cr_amt, refund_rcpt_amt,status_code  
                FROM manar.man_ar_netting_headers_tbl
               WHERE 1=1
               AND request_id = '{request_id}'
               ORDER BY creation_date DESC 
               FETCH FIRST 1 ROW ONLY """ 
    found = False
    for count in range(1,11):
      tc_logs.msg_with_no_picture(f"Sql queried for {count} time(s).")
      rows = database_service.query_oracle_db((sql))
      if (GetVarType(rows) == VarToInt(9)) and len(rows)>0:
        for row in rows:
          status_code = row['STATUS_CODE']
          if status_code == 'COMPLETE':
            tc_logs.validation(f"Expected status code '{status_code}' is found, and the payment is processed successfully")
            found = True
            break
      if found:
        break 
      aqUtils.Delay(wait_time)
    if (count == 10):
      tc_logs.error_with_no_picture("Expected status code not found. Please check the data and rerun the test!!!")
  except:
    tc_logs.checkpt_with_no_picture(traceback.format_exc())
      
def get_revenue_invoice_number(type):
  try:
    sql = f""" SELECT hca.account_number,TYPE.NAME,rcta.trx_number,rctla.description,rcta.trx_date
                FROM ra_customer_trx_all rcta, ra_cust_trx_types_all TYPE, 
                hz_cust_accounts hca, ra_customer_trx_lines_all rctla
               WHERE 1=1
                 AND rcta.customer_trx_id = rctla.customer_trx_id 
                 AND rcta.cust_trx_type_id = TYPE.cust_trx_type_id
                 AND hca.cust_account_id = rcta.sold_to_customer_id
                 AND rcta.batch_source_id = '1023'
                 AND TYPE.NAME = '{type}'
                 AND rctla.description = 'GASOLINE SALES'
                 AND rcta.trx_date > add_months(trunc(sysdate),-3)
                ORDER BY rcta.trx_date DESC
                FETCH FIRST 1 ROW ONLY; """
    rows = database_service.query_oracle_db(aqString.Format(sql))
    tc_logs.test_data("----- Capturing invoice number -----")
    if (GetVarType(rows) == VarToInt(9)) and len(rows)>0:
      for row in rows:
        db_invoice_number = row['TRX_NUMBER']
        tc_logs.checkpt_with_no_picture(f"Invoice number: '{db_invoice_number}'")
      return db_invoice_number
    else:
      tc_logs.error_with_no_picture("Invoice number data not found becuase of No Data Return")
  
  except Exception as e:
    tc_logs.error_with_no_picture(traceback.format_exc())

def get_psi_requested_data():
  try:
    sql = f""" SELECT ool.line_id,
                    NVL (ool.open_flag, 'Y') open_flag,
                    ool.flow_status_code,
                    ooh.order_number,
                    ooh.header_id,
                   ( SELECT ooh1.attribute1
                      FROM oe_order_headers_all ooh1
                      WHERE ooh1.attribute2 = ooh.attribute2       
                        AND ooh1.flow_status_code NOT IN ('CANCELLED')  
                        AND ooh1.order_type_id = ( SELECT transaction_type_id
                                                     FROM apps.oe_transaction_types_tl
                                                    WHERE     LANGUAGE = USERENV ('LANG')
                                                      AND NAME = 'US BUYER'))
                     buyer_service_id                                         
             FROM oe_order_headers_all  ooh,
                  oe_order_lines_all    ool,
                  mtl_system_items_b    mtl
            WHERE ooh.header_id = ool.header_id
              AND ooh.attribute2 IN  (SELECT attribute2
                                        FROM oe_order_headers_all ooh
                                       WHERE     1 = 1     
                                         AND ooh.flow_status_code NOT IN ('CANCELLED') --ver 4.3 added
                                         AND order_type_id =  (SELECT  transaction_type_id
                                                                 FROM  apps.oe_transaction_types_tl
                                                                WHERE  LANGUAGE = USERENV ('LANG')
                                                                AND NAME = 'US BUYER'))
             AND ool.ordered_item_id = mtl.inventory_item_id
             AND mtl.attribute6 = 'PSI'
             AND ool.flow_status_code != 'PSI_CANCELLED'
             AND ooh.order_type_id =  ( SELECT transaction_type_id
                                         FROM apps.oe_transaction_types_tl
                                        WHERE LANGUAGE = USERENV ('LANG') AND NAME = 'US ASSURANCE'
                                      )
             AND NVL (ool.cancelled_flag, 'N') = 'N'
             AND mtl.organization_id = ool.ship_from_org_id
             AND ool.open_flag = 'Y'
             AND ool.unit_selling_price > 0
             FETCH FIRST 1 ROW ONLY """
    rows = database_service.query_oracle_db(aqString.Format(sql)) 
    tc_logs.test_data("----- Capturing PSI Requested Order number -----")
    if (GetVarType(rows) == VarToInt(9)) and len(rows)>0:
      for row in rows:
        gvar.dataprep['order_number'] = row['ORDER_NUMBER']
        tc_logs.checkpt_with_no_picture(f"order number: row['ORDER_NUMBER']")
      
    else:
      tc_logs.error_with_no_picture("PSI Order Number data not found becuase of No Data Return") 
     
  except Exception as e:
    tc_logs.error_with_no_picture(traceback.format_exc())    
    
def get_consignment_data():
  tc_logs.header_name("TEST DATA PROVIDES".center(70,'*'))
  try:
    sql =f"""Select consignment_id, consignment_status, title_status_code, buyer_account_id, seller_acct_id  
             from manar.man_om_consignments
             where vin = '%s'
             FETCH FIRST 1 ROW ONLY;"""                      

    sqlQuery = aqString.Format(sql, gvar.dataprep['vin'])          
    Log.Message(sqlQuery)
    rows = database_service.query_oracle_db(sqlQuery)
    if (GetVarType(rows) == VarToInt(9)) and len(rows)>0:
      for row in rows:
        gvar.store('consignment_id',row['CONSIGNMENT_ID'])
        gvar.store('consignment_status',row['CONSIGNMENT_STATUS'])
        gvar.store('title_status',row['TITLE_STATUS_CODE'])
        gvar.store('buyer_acct_id',row['BUYER_ACCOUNT_ID'])
        gvar.store('seller_acct_id',row['SELLER_ACCT_ID'])       
        tc_logs.checkpt_with_no_picture(f"CONSIGNMENT_ID: {gvar.dataprep['consignment_id']}, CONSIGNMENT_STATUS: {gvar.dataprep['consignment_status']}, TITLE_STATUS: {gvar.dataprep['title_status']}")
        tc_logs.checkpt_with_no_picture(f"SELLER_ACCT_ID: {gvar.dataprep['seller_acct_id']}, BUYER_ACCOUNT_ID: {gvar.dataprep['buyer_acct_id']}")
    else:
      tc_logs.error_with_no_picture("CONSIGNMENT data not found becuase of No Data Return")  
  except Exception as e:
    tc_logs.error_with_no_picture(traceback.format_exc())

#  reference2 is ods service order id    
def get_references_data(): 
  try:
    sql =f"""Select * from manar.man_om_consignment_refs where consignment_id ='%s';"""                      

    sqlQuery = aqString.Format(sql, gvar.dataprep['consignment_id'])          
    Log.Message(sqlQuery)
    rows = database_service.query_oracle_db(sqlQuery)
    if (GetVarType(rows) == VarToInt(9)) and len(rows)>0:
      for row in rows:
        gvar.store('reference2',row['REFERENCE2'])
        gvar.store('source',row['REFERENCE1'])
        tc_logs.checkpt_with_no_picture(f"REFERENCE2: {gvar.dataprep['reference2']}")
    else:
      tc_logs.error_with_no_picture("CONSIGNMENT data not found becuase of No Data Return")  
  except Exception as e:
    tc_logs.error_with_no_picture(traceback.format_exc())  
    
      
def get_seller_number_data(): 
  try:
    sql =f"""Select ACCOUNT_NUMBER from hz_cust_accounts_all   
             where cust_account_id ='%s';"""                      

    sqlQuery = aqString.Format(sql, gvar.dataprep['seller_acct_id'])          
    Log.Message(sqlQuery)
    rows = database_service.query_oracle_db(sqlQuery)
    if (GetVarType(rows) == VarToInt(9)) and len(rows)>0:
      for row in rows:
        gvar.store('seller_number',row['ACCOUNT_NUMBER'])
        tc_logs.checkpt_with_no_picture(f"SELLER_NUMBER: {gvar.dataprep['seller_number']}")
    else:
      tc_logs.error_with_no_picture("CONSIGNMENT data not found becuase of No Data Return")  
  except Exception as e:
    tc_logs.error_with_no_picture(traceback.format_exc())
 
       
def get_buyer_number_data(): 
  try:
    sql =f"""Select ACCOUNT_NUMBER from hz_cust_accounts_all   
             where cust_account_id ='%s';"""                      

    sqlQuery = aqString.Format(sql, gvar.dataprep['buyer_acct_id'])          
    Log.Message(sqlQuery)
    rows = database_service.query_oracle_db(sqlQuery)
    if (GetVarType(rows) == VarToInt(9)) and len(rows)>0:
      for row in rows:
        gvar.store('buyer_number',row['ACCOUNT_NUMBER'])
        tc_logs.checkpt_with_no_picture(f"BUYER_NUMBER: {gvar.dataprep['buyer_number']}")
    else:
      tc_logs.error_with_no_picture("CONSIGNMENT data not found becuase of No Data Return")  
  except Exception as e:
    tc_logs.error_with_no_picture(traceback.format_exc())
    

def get_trx_number():
    tc_logs.test_data("-------- Input Test Data --------")
    try:
      sql = """ SELECT hz.account_name,hz.account_number,rctta.NAME, rctla.Description,rctla.interface_line_attribute1,rcta.trx_number,rcta.trx_date 
                  FROM ra_customer_trx_all rcta, ra_cust_trx_types_all rctta, hz_cust_accounts hz,ra_customer_trx_lines_all rctla
                 WHERE rcta.cust_trx_type_id = rctta.cust_trx_type_id
                   AND rcta.customer_trx_id = rctla.customer_trx_id
                   AND hz.cust_account_id = rcta.sold_to_customer_id
                   AND rctla.interface_line_attribute1 is not null
                   AND rcta.attribute_category <> 'Floorplan Invoice'
                   AND rctta.NAME IN ('US BUYER VEH AR','US SELLER VEH AR CM')
                   AND rcta.last_update_date > add_months(TRUNC(sysdate),-3)
                   ORDER BY rcta.trx_date DESC
                   FETCH FIRST 1 ROWS ONLY """
      rows = database_service.query_oracle_db(aqString.Format(sql))
      if (GetVarType(rows) == VarToInt(9)) and len(rows)>0:
        for row in rows:
          db_trx_number = row['TRX_NUMBER']
          tc_logs.checkpt_with_no_picture(f"Transaction number retrieved from the database: '{db_trx_number}'")
          db_sold_to_customer = row['ACCOUNT_NUMBER']
          tc_logs.checkpt_with_no_picture(f"Sold to customer associated to the transaction number '{db_trx_number}' is '{db_sold_to_customer}'")
          item_desc = row['DESCRIPTION']
          tc_logs.checkpt_with_no_picture(f"Item description associated to the transaction number '{db_trx_number}' is '{item_desc}'") 
          sales_order = row['INTERFACE_LINE_ATTRIBUTE1']
          tc_logs.checkpt_with_no_picture(f"Sales Order linked to the transaction number '{db_trx_number}' is '{sales_order}'")
        return db_sold_to_customer,db_trx_number,item_desc,sales_order
    except Exception as e:
      Log.Message(traceback.format_exc())
      
def get_order_number(order_type,appl_name):
 try:
  sql = f""" select distinct context,order_number,attribute12,ordered_date from oe_order_headers_all 
         where 1=1 
         and context =  '{order_type}'
         and attribute12 = '{appl_name}'
         and flow_status_code != 'CANCELLED'
         and last_update_date > add_months(trunc(sysdate),-12)
         order by ordered_date desc
         Fetch first 1 row only """
  rows=database_service.query_oracle_db(sql)
  if (GetVarType(rows)== VarToInt(9)):
   for row in rows:
     order_number=row['ORDER_NUMBER']
     tc_logs.checkpt_with_no_picture(f"{order_type} Order Number: {order_number}")
   return order_number
  else:
   Log.Error("No records found please check the Query!!!")
 except Exception as e:
  Log.Message(traceback.format_exc())
  
def fetch_master_item():
  tc_logs.test_data("----- Input Data -----")
  try:
    sql = """SELECT * FROM mtl_system_items_b 
             WHERE enabled_flag = 'Y'
             AND attribute20 = 'Y' 
             AND attribute4 = 'N'
             AND attribute7 = 'Y'
             AND invoice_enabled_flag = 'Y'
             AND item_type = 'RECON_SERVICES' --user item type
             AND inventory_item_status_code = 'Active'
             AND attribute5 NOT IN('PSI','ASSURANCE') 
             AND attribute6 NOT IN ('PSI','ASSURANCE')
             ORDER BY dbms_random.VALUE
             FETCH FIRST 1 ROW ONLY """ 
    rows = database_service.query_oracle_db(aqString.Format(sql))
    if (GetVarType(rows) == VarToInt(9)) and len(rows)>0:
      for row in rows:
        item_description = row['DESCRIPTION']
        tc_logs.checkpt_with_no_picture(f"Item fetched from Master Items: '{item_description}'")
      return item_description
  except Exception as e:
    Log.Message(traceback.format_exc())

def get_buyer_or_seller_trx_number(item_desc,name):
    tc_logs.test_data("-------- Item Information --------")
    try:
       sql = f""" SELECT hz.account_name,hz.account_number,rctta.NAME, rctla.Description,rctla.interface_line_attribute1,rcta.trx_number,rcta.trx_date 
                    FROM ra_customer_trx_all rcta, ra_cust_trx_types_all rctta, hz_cust_accounts hz,ra_customer_trx_lines_all rctla
                   WHERE rcta.cust_trx_type_id = rctta.cust_trx_type_id
                     AND rcta.customer_trx_id = rctla.customer_trx_id
                     AND hz.cust_account_id = rcta.sold_to_customer_id
                     AND rcta.attribute_category <> 'Floorplan Invoice'
                     AND rctla.description = '{item_desc}'
                     AND rctta.name = '{name}'
                    -- AND rcta.last_update_date > add_months(TRUNC(sysdate),-3)
                    ORDER BY rcta.trx_date DESC
                    FETCH FIRST 1 ROWS ONLY """
       rows = database_service.query_oracle_db(sql)
       if (GetVarType(rows) == VarToInt(9)) and len(rows)>0:
        for row in rows:
          db_trx_number = row['TRX_NUMBER']
          tc_logs.checkpt_with_no_picture(f"Transaction number retrieved from the DB for the item '{item_desc}': '{db_trx_number}'")
          sold_to_customer = row['ACCOUNT_NUMBER']
          tc_logs.checkpt_with_no_picture(f"Sold to customer associated with the transaction number: '{sold_to_customer}'")
        return db_trx_number,sold_to_customer
    except Exception as e:
      Log.Message(traceback.format_exc())
      
def get_accounting_from_cust_site_uses_all(trx_number):
  try:
    sql = f""" SELECT  hca.account_number sold_to
        ,hcab.account_number bill_to
        ,rcta.trx_number
        ,rctla.description
        ,gcc_rec.segment1||'-'||gcc_rec.segment2||'-'||gcc_rec.segment3||'-'||gcc_rec.segment4||'-'||gcc_rec.segment5||'-'||gcc_rec.segment6||'-'||gcc_rec.segment7 rec_account
        ,gcc_rev.segment1||'-'||gcc_rev.segment2||'-'||gcc_rev.segment3||'-'||gcc_rev.segment4||'-'||gcc_rev.segment5||'-'||gcc_rev.segment6||'-'||gcc_rev.segment7 rev_account
        ,gcc_tax.segment1||'-'||gcc_tax.segment2||'-'||gcc_tax.segment3||'-'||gcc_tax.segment4||'-'||gcc_tax.segment5||'-'||gcc_tax.segment6||'-'||gcc_tax.segment7 tax_account
        ,gcc_freight.segment1||'-'||gcc_freight.segment2||'-'||gcc_freight.segment3||'-'||gcc_freight.segment4||'-'||gcc_freight.segment5||'-'||gcc_freight.segment6||'-'||gcc_freight.segment7 freight_account
        ,gcc_clearing.segment1||'-'||gcc_clearing.segment2||'-'||gcc_clearing.segment3||'-'||gcc_clearing.segment4||'-'||gcc_clearing.segment5||'-'||gcc_clearing.segment6||'-'||gcc_clearing.segment7 clearing_account
        ,gcc_unbilled.segment1||'-'||gcc_unbilled.segment2||'-'||gcc_unbilled.segment3||'-'||gcc_unbilled.segment4||'-'||gcc_unbilled.segment5||'-'||gcc_unbilled.segment6||'-'||gcc_unbilled.segment7 unbilled_account
        ,gcc_unearned.segment1||'-'||gcc_unearned.segment2||'-'||gcc_unearned.segment3||'-'||gcc_unearned.segment4||'-'||gcc_unearned.segment5||'-'||gcc_unearned.segment6||'-'||gcc_unearned.segment7 unearned_account
        FROM    ra_customer_trx_all rcta
        ,ra_customer_trx_lines_all rctla
        ,hz_cust_accounts hca
        ,hz_cust_accounts hcab
        ,hz_cust_acct_sites_all hcasa
        ,hz_cust_site_uses_all hcsua
        ,gl_code_combinations gcc_rec
        ,gl_code_combinations gcc_rev
        ,gl_code_combinations gcc_tax
        ,gl_code_combinations gcc_freight
        ,gl_code_combinations gcc_clearing
        ,gl_code_combinations gcc_unbilled
        ,gl_code_combinations gcc_unearned
        WHERE   1 = 1
        AND     rctla.customer_trx_id = rcta.customer_trx_id
        AND     hca.cust_account_id = rcta.sold_to_customer_id
        AND     hcab.cust_account_id = rcta.bill_to_customer_id
        AND     hcasa.cust_Account_id = hca.cust_Account_id
        AND     hcasa.status = 'A'
        AND     hcsua.cust_acct_site_id = hcasa.cust_acct_site_id 
        AND     hcsua.SITE_USE_CODE = 'BILL_TO' 
        AND     hcsua.primary_flag = 'Y'
        AND     gcc_rec.code_combination_id = hcsua.gl_id_rec
        AND     gcc_rev.code_combination_id = hcsua.gl_id_rev
        AND     gcc_tax.code_combination_id = hcsua.gl_id_tax
        AND     gcc_freight.code_combination_id = hcsua.gl_id_freight
        AND     gcc_clearing.code_combination_id = hcsua.gl_id_clearing
        AND     gcc_unbilled.code_combination_id = hcsua.gl_id_unbilled
        AND     gcc_unearned.code_combination_id = hcsua.gl_id_unearned
        AND     rcta.trx_number = '{trx_number}'  """
    rows = database_service.query_oracle_db(aqString.Format(sql))
    if (GetVarType(rows) == VarToInt(9)) and len(rows)>0:
      revenue_account = rows[0]['REV_ACCOUNT']
      tc_logs.checkpt_with_no_picture(f"Revenue account captured from the customer site uses all: '{revenue_account}'")
    return revenue_account
  except Exception as e:
     Log.Message(traceback.format_exc())

  
def get_requestid_details(Request_id, wait_time = 4000):
    try:
      completed_flag = False
      sqlQuery =  f"SELECT * FROM FND_CONC_REQ_SUMMARY_V WHERE request_id = {Request_id}"
      Log.Message(sqlQuery)
      for count in range(1,11):
       aqUtils.Delay(wait_time)
       Log.Message("Querying for concurrent request completion status "+str(count)+" time")
       rows = database_service.query_oracle_db(sqlQuery)
       if (GetVarType(rows)== VarToInt(9)):
          for row in rows:
           tc_logs.msg_with_no_picture(aqString.Format("PHASE Expected:C:'Completed' ACTUAL: %s",row['PHASE_CODE']))
           tc_logs.msg_with_no_picture(aqString.Format("STATUS Expected:C:'Normal'ACTUAL: %s",row['STATUS_CODE']))
           phase = row['PHASE_CODE']
           status = row['STATUS_CODE']    
       else:
            tc_logs.error_with_no_picture('No records found please check Query!!!','')
               
       if(phase == "C" and status == "C"):
            completed_flag = True
#            tc_logs.validation(aqString.Format("PHASE Expected:C ACTUAL: %s",row['PHASE_CODE']))
#            tc_logs.validation(aqString.Format("STATUS Expected:C ACTUAL: %s",row['STATUS_CODE']))   
                   
       if completed_flag:
           tc_logs.validation("Job Completed for RequestID: '"+Request_id+"'")
           return completed_flag
    
      return completed_flag
     
    except Exception as e:
          log_exception(e)



