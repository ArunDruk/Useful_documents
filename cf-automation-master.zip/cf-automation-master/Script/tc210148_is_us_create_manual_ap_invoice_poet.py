﻿from ebiz import *
import form_utils


class tc210148_is_us_create_manual_ap_invoice_poet(Ebiz):
#  global login_user
  
  
  def login(self):
    self.login_user="rmaran"
    super().login()
  
  def goto_url(self,url):
   super().goto_url(self.testConfig['ebiz']['oci_is_url'])
    
  def action(self,book):
    
      global rowno, app, p_names, app_prj
      rowno=2     
      app = book.Sheets.item["Invoice"]
      app_prj = book.Sheets.item["Project"]

      web_utils.log_checkpoint("Logged in to Oracle Applications Home Page Successfully",500,self.page)
      self.wait_until_page_loaded()      
      self.page.EvaluateXPath("//table[@id='menuContent']//div[contains(text(),'AP Home Office Super User')]")[0].Click() 
      web_utils.log_checkpoint("Click 'AP Home Office Super User' - Successful",500,self.page) 
      self.page.Keys("[Down]")
      self.wait_until_page_loaded()
      self.page.NativeWebObject.Find("contentText","Invoices","A").Click()
      web_utils.log_checkpoint("Click 'Invoices' - Successful",500,self.page) 
      self.page.Keys("[Down]")
      self.wait_until_page_loaded()
      self.page.NativeWebObject.Find("contentText","Entry","A").Click()
      web_utils.log_checkpoint("Click 'Entry' - Successful",500,self.page) 
      self.page.Keys("[Down]")
      self.wait_until_page_loaded()
      self.page.EvaluateXpath("//table[@id='respList']//div[contains(text(),'Invoices')]")[1].Click() 
      web_utils.log_checkpoint("Click 'Invoices' - Successful",500,self.page)
      web_utils.validate_security_box()   
      self.jFrame = self.initializeJFrame()
      Delay(2000)
#      jFrame.Keys("~o")
      form_utils.click_ok_btn(self.jFrame)
      delay(5000)
      p_names = ("JavaClassName","AWTComponentAccessibleName")
      p_values = ("ExtendedFrame","Invoice Workbench*")
      obj=self.jFrame.FindChild(p_names,p_values,50)
      if obj.Exists:
        web_utils.log_checkpoint("Invoice Workbench (AP Home Office Super User) Launched Successfully",500,self.jFrame)
      else:
        self.log_message_oracle_form(self.jFrame,"Unable to Launch Invoice Workbench Form")


      p_names=["AWTComponentAccessibleName","JavaClassName"]
      p_values=["Invoice Workbench (AP Home Office Super User)","ExtendedFrame"]
      inv_wb_form=self.jFrame.FindChildEx(p_names,p_values,60,True,120000)  
      
      Sys.HighlightObject(inv_wb_form)
      inv_wb_form_title_bar=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("ExtendedFrame", "Invoice Workbench (AP Home Office Super User)", 24).AWTObject("TitleBar", "", 0).AWTObject("LWComponent", "", 0).AWTObject("TitleBar$CaptionComp", "", 0)
      Sys.HighlightObject(inv_wb_form_title_bar)
      inv_wb_form_title_bar.DblClick()
      Delay(2000)  
      
      web_utils.log_checkpoint("Entering Invoice Header Details",500,self.jFrame)
      p_names = ("JavaClassName","AWTComponentAccessibleName")
      p_values = ("VTextField","Trading Partner RequiredList of Values")
      inv_wb_form.Find(p_names,p_values,30).Click()
      inv_wb_form.Find(p_names,p_values,30).Keys(app.Cells.Item[rowno,3])
      delay(2000) 
      web_utils.log_checkpoint("Trading Partner: "+VarToStr(app.Cells.Item[rowno,3]),500,self.jFrame)   
      inv_wb_form.Keys("[TAB]")
      delay(3000)
      
      p_values = ("VTextField","Invoice Date RequiredList of Values")
      inv_wb_form.Find(p_names,p_values,30).Click()
      delay(2000)
      
      pi_names = ("JavaClassName","AWTComponentAccessibleName","AWTComponentIndex")
      p_values = ("VTextField","Invoice Num Required",32)
      Delay(1000)
      inv_wb_form.Find(pi_names,p_values,10).Click()
      inv_name = ("TST_INV: "+aqConvert.DateTimeToFormatStr(aqDateTime.Time(),"%H:%M:%S"))
      inv_wb_form.FindChild(pi_names, p_values, 20).SetText(inv_name)
      delay(1000)
      web_utils.log_checkpoint("Invoice Number: "+inv_name,500,self.jFrame)
      inv_wb_form.Keys("[TAB]")
      delay(1000)     
       
      p_values = ("VTextField","Invoice Amount Required",40)
      inv_wb_form.Find(pi_names,p_values,10).Click()
      delay(1000)
      inv_wb_form.Find(pi_names,p_values,10).Keys(app.Cells.Item[rowno,4])
      web_utils.log_checkpoint("Invoice Amount: "+VarToStr(app.Cells.Item[rowno,4]),500,self.jFrame)
      delay(3000)
      
      p_values = ("VTextField","Tax Amount",44)
      inv_wb_form.Find(pi_names,p_values,10).Click() 
      web_utils.log_checkpoint("Invoice Header Details Entered Successfully",500,self.jFrame)
      delay(3000)
 # Switching to Lines and Opening AP Lines
#      inv_wb_form.Click()
#      delay(2000)
#      inv_wb_form.Keys("[Alt2]") 
      self.jFrame.Keys("~2")
      delay(3000)
      
#      prop=["AWTComponentAccessibleName","JavaClassName"]
#      val=["Open Folder...","VButton"]
#      open_fldr_form=self.jFrame.FindChildEx(prop,val,30,True,60000)
#      delay(1000)
#      open_fldr_form.Click()
#      delay(2000)
      
      self.jFrame.Keys("~l")
      Delay(1000)
      self.jFrame.Keys("o")
      delay(3000)
      prop=["AWTComponentAccessibleName","JavaClassName"]
      val=["Open Folder","FWindow"]
      open_fldr_form=self.jFrame.FindChildEx(prop,val,30,True,60000)
      delay(1000)
      prop=["JavaClassName","AWTComponentAccessibleName","AWTComponentIndex"]
      val=["LWTextField"," Find",0]
      fnd=open_fldr_form.FindChildEx(prop,val,30,True,6000)
      fnd.Click()
      fnd.SetText("AP Lines")
      delay(2300)
      self.jFrame.Keys("~f")
      delay(2000)
      prop=["AWTComponentAccessibleName","JavaClassName"]
      val=["OK ALT O","PushButton"]
      ok_button = open_fldr_form.FindChild(prop,val,20)
      Sys.HighlightObject(ok_button)    
      ok_button.Click()
      delay(3000)
 
#Entering Invoice details in Lines
      web_utils.log_checkpoint("Entering Invoice Lines Details",500,self.jFrame)
      pi_names = ("JavaClassName","AWTComponentAccessibleName","AWTComponentIndex")
      p_values = ("VTextField","Amount Required",10)
      Delay(1000)
      inv_wb_form.Find(pi_names,p_values,10).Click()
      inv_wb_form.Find(pi_names,p_values,10).Keys(app.Cells.Item[rowno,4])      
      delay(3000)
      web_utils.log_checkpoint("Invoice Amount: "+VarToStr(app.Cells.Item[rowno,4]),500,self.jFrame)
#      inv_wb_form.Keys("[Tab]") 
      delay(3000)
#Ship to      
      p_values = ("VTextField","Ship toList of Values",255)
      Delay(1000)
      inv_wb_form.Find(pi_names,p_values,10).Click()
      inv_wb_form.Find(pi_names,p_values,10).Keys(app.Cells.Item[rowno,5])      
      delay(1000)
      web_utils.log_checkpoint("Ship to: "+VarToStr(app.Cells.Item[rowno,5]),500,self.jFrame)
#      inv_wb_form.Keys("[Tab]") 
      delay(3000)
#Purchasing Category 
      p_values = ("VTextField","Purchasing CategoryList of Values",420)
      Delay(1000)
      inv_wb_form.Find(pi_names,p_values,10).Click()   
      inv_wb_form.Find(pi_names,p_values,10).Keys(app.Cells.Item[rowno,7])
      delay(3000)
      web_utils.log_checkpoint("Purchasing Category: "+VarToStr(app.Cells.Item[rowno,7]),500,self.jFrame)
#Primary Intended Use      
      p_values = ("VTextField","Primary Intended UseList of Values",245)
      Delay(1000)
      inv_wb_form.Find(pi_names,p_values,10).Click()
      inv_wb_form.Find(pi_names,p_values,10).Keys(app.Cells.Item[rowno,8])
      delay(3000)
      web_utils.log_checkpoint("Primary Intended Use: "+VarToStr(app.Cells.Item[rowno,8]),500,self.jFrame)
#Entering Project Num 
      p_values = ("VTextField","ProjectList of Values",305)
      Delay(1000)
      inv_wb_form.Find(pi_names,p_values,10).Click()  
      inv_wb_form.Find(pi_names,p_values,10).Keys(app_prj.Cells.Item[rowno,11])
      delay(3000)
      web_utils.log_checkpoint("Project Number: "+VarToStr(app_prj.Cells.Item[rowno,11]),500,self.jFrame)
      self.jFrame.Keys("[Tab]") 
      delay(2000)
#Entering Task Num            
#      p_values = ("VTextField","Task Required",310)
#      Delay(1000)
#      inv_wb_form.Find(pi_names,p_values,10).Click()
#      delay(2000)
      p_values = ("VTextField","Task RequiredList of Values",310)
      inv_wb_form.Find(pi_names,p_values,10).Click()
      task = VarToStr(app.Cells.Item[rowno,10])[2:]      
      inv_wb_form.Find(pi_names,p_values,10).Keys(task)
      delay(3000)
      web_utils.log_checkpoint("Task: "+task,500,self.jFrame)
#Entering Expenditure Type
      p_values = ("VTextField","Expenditure Type RequiredList of Values",320)
      Delay(1000)
      inv_wb_form.Find(pi_names,p_values,10).Click()   
#      inv_wb_form.Find(pi_names,p_values,10).Keys("BLDG")
      inv_wb_form.Find(pi_names,p_values,10).Keys(app.Cells.Item[rowno,11])
      delay(3000)
#      self.jFrame.Keys("[Tab]")
#      delay(3000)  
#      prop=["AWTComponentAccessibleName","JavaClassName"]
#      val=["Expenditure Types","FWindow"]
#      expd_items_form=self.jFrame.FindChildEx(prop,val,30,True,60000)
#      delay(1000)
#      if expd_items_form.Exists:
#        Delay(2000)
#        prop=["JavaClassName","AWTComponentAccessibleName","AWTComponentIndex"]
#        val=["LWTextField"," Find",0]
#        fnd=expd_items_form.FindChildEx(prop,val,30,True,6000)
#        fnd.Click()
#  #      fnd.Keys(app.Cells.Item[rowno,12])
#        fnd.SetText("")
#        fnd.SetText("%BLDG MNT%")
#        delay(2300)
#        self.jFrame.Keys("~f")
#        delay(2000)
#        self.jFrame.Keys("[Down][Down][Down]")
#        delay(2000)
#        web_utils.log_checkpoint("Expenditure Type: "+VarToStr(app.Cells.Item[rowno,11]),500,self.jFrame)
#        prop=["AWTComponentAccessibleName","JavaClassName"]
#        val=["OK ALT O","PushButton"]
#        ok_button = expd_items_form.FindChild(prop,val,20)
#        Sys.HighlightObject(ok_button)    
#        ok_button.Click()
#        delay(3000)
#Entering Expenditure Organization      
      p_values = ("VTextField","Expenditure Organization RequiredList of Values",325)
      Delay(1000)
      inv_wb_form.Find(pi_names,p_values,10).Click()
      inv_wb_form.Find(pi_names,p_values,10).Keys(app.Cells.Item[rowno,12])
      delay(1000)
      web_utils.log_checkpoint("Expenditure Organization: "+VarToStr(app.Cells.Item[rowno,12]),500,self.jFrame) 
      delay(3000)
      web_utils.log_checkpoint("Invoice AP Lines Details Entered Successfully",500,self.jFrame)
      
# Invoice Validation
#      self.jFrame.FindChild("AWTComponentName","FormsTabPanel1",30).ClickTab("1 General")
      self.jFrame.Keys("~1")
      delay(3000)
      self.jFrame.Keys("~c")
      delay(1500)
      self.jFrame.Keys("~v")
      delay(1000)
      self.jFrame.Keys("~k")
      delay(10000)
      self.jFrame.Keys("^s")
      delay(2000)
      pro=("AWTComponentAccessibleName","AWTComponentIndex")
      values=("Invoice Num Required",32)
      inv = self.jFrame.FindChild(pro,values,30).wText
      web_utils.log_checkpoint("AP Invoice created SuccessFully :"+inv,500,self.jFrame)
      delay(1000)        
      app.Cells.Item[rowno,13] = inv  
      delay(2000)
# The below method calling is for Generating SA Tax as presently there is a known issue.   
      if VarToStr(app.Cells.Item[rowno,25])== "Yes":
        def workaround_sa_tax():
            delay(3000)
            jFrame=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1)
            jFrame.Click()
            jFrame.Keys("~2")
            Delay(3000)
            jFrame.Click()
            p_names=["AWTComponentAccessibleName","JavaClassName"]
            p_values=["Invoice Workbench (AP Home Office Super User)","ExtendedFrame"]
            inv_wb_form=jFrame.FindChildEx(p_names,p_values,60,True,120000)
            pi_names = ("JavaClassName","AWTComponentAccessibleName","AWTComponentIndex")
            p_values = ("VTextField","Primary Intended UseList of Values",245)
            Delay(1000)
            int_use = inv_wb_form.Find(pi_names,p_values,60)
            Sys.HighlightObject(int_use)
            int_use = inv_wb_form.Find(pi_names,p_values,60)
            int_use.Click()
            delay(2000)
            int_use.Keys("[BS]") # ("^a[Del]")
            delay(2000)
            int_use.Keys("SGA Manheim")#(app.Cells.Item[rowno,24]) #
            delay(3000)
            jFrame.Keys("~1")
            delay(3000)
            jFrame.Keys("~y")
            delay(3000)
            jFrame.Keys("~1")
            delay(3000)
            jFrame.Keys("~c")
            delay(1500)
            jFrame.Keys("~v")
            delay(1000)
            jFrame.Keys("~k")
            delay(10000)
            jFrame.Keys("^s")
            delay(2000) 

         
        workaround_sa_tax()
      
        pro=("AWTComponentAccessibleName","AWTComponentIndex")
        values=("Self-Assessed Tax Amount",152)
        sa_tax = self.jFrame.FindChild(pro,values,30).wText
        if (VarToInt(sa_tax) > 0):
            Log.Enabled=True
            Log.Message(" Self-Assessed Tax Amount generated SuccessFully :  "+aqConvert.VartoStr(sa_tax))
            Log.Enabled=False
        else:
            web_utils.log_error("Self-Assessed Tax Amount Not Generated.")
  #      web_utils.log_checkpoint("Self-Assessed Tax Amount generated SuccessFully :"+sa_tax,500,self.jFrame)
        delay(1000)        
        app.Cells.Item[rowno,23] = sa_tax
           
        p_names = ("JavaClassName","AWTComponentAccessibleName")
        p_values = ("VTextField","Status")
        obj=self.jFrame.FindChild(p_names,p_values,50)
        if obj.wText == "Validated":
          web_utils.log_checkpoint(inv+" Invoice Validated Successfully",500,self.jFrame)
        else:
          web_utils.log_checkpoint(inv+" Check for Invoice Holds & Re-Validate ",500,self.jFrame)
     
        
      self.jFrame.Keys("[F4]")
      Delay(2000)
      self.jFrame.Keys("[F4]")
      Delay(2000)
      self.jFrame.Keys("~o")
      Delay(2000) 
      
      
            




