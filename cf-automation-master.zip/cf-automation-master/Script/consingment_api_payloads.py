﻿from gvar import dataprep as DATAPREP 
import tc_logs

def post_payload():
  return   	{
		 "consignment" : {
		  "bodyStyleCode" : "Fastback",
		  "make" : "Honda",
		  "model" : "Accord",
		  "model15" : "Model15",
		  "vin" : DATAPREP['vin'],
		  "year" : "2014"
		},
		"saleAttributes" : {
		  "blueLight" : False,
		  "branchCode" : "BC",
		   "dealerCode" : "DC",
		  "driveable" : "U",
		  "factoryCode" : "FC",
		  "greenLight" : False,
		  "industryStandardType" : "IND_STD_TYPE",
		  "licensePlateNumber" : "DSL-RULZ",
		  "odometerDigits" : 6,
		  "odometerValue" : 10,
		  "odometerUnits" : "Miles",
		  "redLight" : False,
		  "removedFromLot" : __get_current_time_stampe_with_timezone(),
		 "salePrice" : DATAPREP['sale_price'],
		  "saleDate" : __get_current_time_stampe_with_timezone(),
		  "saleWeek" : __get_current_week(),
		  "saleYear" : __get_current_year(),
		  "saleChannel" : "RMS",
		  "salvageIndicator" : False,
		  "soldFlag" : True ,
		  "specialtyListing" : False,
		   "trueMilageIndicator" : False,
		  "vehicleLocationName" : "DEALER LOT",
		  "vehicleAddressLine1" : "100 Grover Street",
		  "vehicleAddressLine2" : "Lot C",
		  "vehicleCity" : "Buffalo",
		  "vehicleState" : "NY",
		  "vehiclePostalCode" : "14222",
		  "vehicleCountry" : "US",
		  "offsite" : True,
		   "yellowLight" : False,
		  "purchaseLocationCode" : "PFSR",
		  "systemSource" : "RMS",
		  "consignmentReferenceId" : f"REF{DATAPREP['vin'][-7::]}",
		  "hondaFloorplanThresholdFlag" : True    
		},
		"title" : {
		 
		  "titleHandlingMethod" : "STANDARD"
		
		},
		"vehicleFeatures" : {
		  "airConditioning" : "ZonedAC",
		  "airbags" : "Airbags",
		  "cruiseControl" : "CCAutoPilot",
		  "driveType" : "Hyper",
		  "electricSeats" : "ES",
		  "electricWindows" : "AutoWindows",
		  "emissionDesc" : "49 State",
		  "engineDesc" : "12CG",
		  "exteriorColor" : "Black",
		  "exteriorLocks" : "AutoLocks",
		  "interiorColor" : "BLK",
		  "interiorSeatsCode" : "Leather",
		  "powerBrakes" : "PB",
		  "powerSteering" : "AutoSteer",
		  "radioType" : "SmartRadio",
		  "rearDefroster" : "RD",
		  "airbagsSide" : "AirBSide",
		  "subseriesTrim" : "Subseries",
		  "tiltWheel" : "TW",
		  "top" : "Cabrio",
		  "transmission" : "MANUAL",
		  "subtype" : "SuperSportSub"
		}
	}
 
def put_payload():
 
  return {
           "consignment":    {
              "consignmentId": DATAPREP['consignment_id'] ,
              "consignmentStatus": "BOOKED" }
         }
	
def get_query():
  
  return f"?consignmentId={DATAPREP['consignment_id']}"
    
def __get_current_time_stampe_with_timezone():
     from datetime import datetime
     return datetime.now().strftime("%Y-%m-%dT%H:%M:%S.%f")

def __get_current_date():
     from datetime import datetime   
     return datetime.now().strftime("%Y-%m-%d")
     
def __get_current_year():
   import datetime
   return datetime.datetime.now().year
   
def __get_current_week():
     import datetime 
     return(datetime.date.today().isocalendar()[1])
   
   
   
