﻿from dbhelper import *
from webcentercapture_V12 import *
import web_utils
import wcc_login_page
import wcc_home_page
import os

class WCC_Verify_batch_creation_email_V12(Webcentercapture_V12):
        
 def goto_url(self,url):
    gvar.dataprep['browser'] = 'ie' 
    pass
         
 def action(self,book):
  
  app = book.Sheets.item["mail_wcc"] 
  
  #close all open sessions and make current session active  
  Webcentercapture_V12.use_current_session()
  
  #Get location and set the key for searching the batches
#  location = VarToStr(app.Cells.item[2,3]).split("-")[1]
  location = VarToStr(app.Cells.item[2,3])[2:]
  ocr_key = aqString.SubString(location,0,2)
  Webcentercapture_V12.set_entity_based_on_location(location)
  Delay(3000)
  
  #verify whether the batch_list frame exists
  Webcentercapture_V12.verify_batch_list_frame()
  Delay(5000)
   
  #select the first batch
  Webcentercapture_V12.select_first_batch(ocr_key)
  Delay(3000)
  
  #Verify whether batch created and the batch details 
  Webcentercapture_V12.verify_batch_by_email_subject(ocr_key,app) 
  
  # Verify and Update Document Profile and Release the Batch to WFR Form for Verification:       
  Webcentercapture_V12.verify_update_document_profile_details(app)
  Delay(1000)
  
  # select batch header and release the selected batch:
  Webcentercapture_V12.select_batch_for_release(ocr_key,app) 
  
  # validate batch release
  Webcentercapture_V12.validate_batch_release(app,ocr_key)