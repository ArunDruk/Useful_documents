﻿from dbhelper import *
from ebiz import *
import web_utils
import dbhelper
import file_system_utils 
import form_utils

class tc189586_is_asset_retirement(Ebiz):
 op_log_path="C:\\Tc_Logs"

 def login(self):
   self.login_user='pkjami'
   super().login()
 
 def goto_url(self,url):
    super().goto_url(self.testConfig['ebiz']['oci_is_url'])
   
 def action(self,book): 
   app = book.Sheets.item["Assets"] 
   rowno=2
   
   #Login to Oracle
   self.wait_until_page_loaded()    
   self.log_checkpoint_message_web("Login Successful")
   
   #Selecting the responsibility
   web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'AM Supervisor')]")
#   self.log_message_web("Click 'AM Supervisor' - Successful")
   Delay(3000)
   self.page.NativeWebObject.Find("contentText","Assets","A").Click()
   web_utils.log_checkpoint("Click 'Assets' - Successful",500,self.page)
#   self.log_message_web("Click 'Assets' - Successful")
   Delay(2000)
   self.page.wait()
   self.page.NativeWebObject.Find("contentText","Asset Workbench","A").Click()
   web_utils.log_checkpoint("Click 'Asset Workbench' - Successful",500,self.page)
#   self.log_message_web("Click 'Asset Workbench' - Successful")
   Delay(2000)
   self.page.wait()
   
   #Handling the security pop-up and opening forms
   web_utils.validate_security_box()
   jFrame= self.initializeJFrame()
   Delay(5000)
   form_utils.click_ok_btn(jFrame)
   Delay(5000)
   
   #Getting Asset Number from database
   self.log_message_oracle_form(jFrame,"'Find Assets' form launched successfully")  
   dsn = self.testConfig['man_oracle_db']['dsn']
   user_id = self.testConfig['man_oracle_db']['userid']
   pwd = self.testConfig['man_oracle_db']['pwd']
   asset_num = dbhelper.is_asset_add(dsn,user_id,pwd)
   

   #Find Assets form frame
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Find Assets","ExtendedFrame"]
   findassets_form=jFrame.FindChildEx(prop,val,60,True,60000)
 
   
   #Entering Asset number in Find Assets form
   prop = ["AWTComponentAccessibleName","JavaClassName"]
   val = ["Asset Number","VTextField"]
   self.log_message_oracle_form(jFrame,"In 'Find Assets' form enter 'Asset Number' next")
   findassets_form.FindChild(prop,val,10).SetText(asset_num) #(asset_num) 
   findassets_form.Keys("[Tab]")
   app.Cells.Item[rowno,2] = asset_num 
   Delay(3000)
   
   #Finding the asset number
   self.log_message_oracle_form(jFrame,"In 'Find Assets' click 'Find' button next")
   prop = ["AWTComponentAccessibleName","JavaClassName"]
   val = ["Find alt i","Button"]
   findassets_form.FindChild(prop,val,20).Click()
   Delay(3000)
   
   #Assets form identification and verifying its existence
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Assets","ExtendedFrame"]
   assets_form=jFrame.FindChildEx(prop,val,60,True,60000)
   self.log_message_oracle_form( jFrame,"'Assets' form launched successfully")
   self.verify_aqobject_chkproperty(assets_form,"AWTComponentAccessibleName",cmpContains,"Assets")
   
   #Selecting Retirements button
   self.log_message_oracle_form( jFrame,"In 'Assets' form click on 'Retirements' next")
   assets_form.FindChild("AWTComponentAccessibleName","Retirements alt R",10).Click()
   Delay(2000)
   
   #Retirements form identification
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["retirements","ExtendedFrame"]   
   retirements_form=jFrame.FindChildEx(prop,val,10,True,60000)
   self.log_message_oracle_form( jFrame,"'Retirements' form launched successfully")
   Delay(2000)
   
   #Entering Bookname for the Asset in retirements form
   prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
   val=["Book RequiredList of Values","VTextField",2]      
   book = retirements_form.FindChild(prop,val,10)
   book.Click()
   book.SetText("MAN USCORP BOOK")
   self.log_message_oracle_form( jFrame,"In 'Retirements' form 'Book' entered successfully ")
   Delay(5000)
   book.keys("[Tab]")
   
   
   #Extracting the current cost in retirements form   
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Current Cost","VTextField"]    
   Delay(2000)  
   ret_val = retirements_form.FindChild(prop,val,10).wText
   self.log_message_oracle_form( jFrame,"Current Cost of an Asset : "+VarToStr(ret_val))
   
   prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
   val=["Retirement TypeList of Values","VTextField",11]    
   Delay(2000)  
   retirement_type=retirements_form.Find(prop,val,10)
   retirement_type.Click()
   retirement_type.SetText("Extraordinary")
   self.log_message_oracle_form( jFrame,"In 'Retirements' form 'Retirement Type' entered successfully ")
   
   #Entering cost retired in retirements form     
   prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
   val=["Cost Retired Required","VTextField",10]    
   Delay(2000)  
   costRet_vxt_field=retirements_form.Find(prop,val,10)
   costRet_vxt_field.Click()
   costRet_vxt_field.SetText(VarToStr(ret_val))
   costRet_vxt_field.Keys("[Tab]")
   self.log_message_oracle_form(retirements_form,"Assets Retirement Amount: "+VarToStr(ret_val))
   Delay(2000)

   
   #Selecting Done button in retirements form
   self.log_message_oracle_form( jFrame,"In 'Retirements' form click 'Done' next ")
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Done alt D","Button"]   
   retirements_form.FindChild(prop,val,30).Click()
   
   #Confirmation message form identification and selecting OK button
   prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
   val=["Forms FRM-40400*","FWindow",0] 
   conf_msg_form=jFrame.FindChildEx(prop,val,10,True,90000)   
   val = ["OK ALT O","PushButton",0]    
   Delay(1000)  
   conf_msg_form.FindChild(prop,val,10).Click()
   Delay(2000)
   jFrame.Keys("[F4]")
   delay(4000) 
   
   #Selecting other->req->run in navigator form 
   
   jFrame.keys("~v")
   delay(2000)
   jFrame.keys("r") 
   delay(3000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Find Requests","ExtendedFrame"]
   findreq_form=jFrame.FindChildEx(prop,val,30,True,90000)
   
   val=["Submit a New Request alt N","Button"]
   findreq_form.FindChild(prop,val,30).Click()
   
   #Identifying the submit request window and providing request name 
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Submit Request","ExtendedFrame"]
   submitrequest_form=jFrame.FindChildEx(prop,val,60,True,60000)
   submitrequest_form.Find("AWTComponentAccessibleName","Name RequiredList of Values",10).Click()
   Delay(1000)
   submitrequest_form.Find("AWTComponentAccessibleName","Name RequiredList of Values",10).SetText("Calculate Gains and Losses")
   self.log_message_oracle_form(jFrame,"Submitting Concurrent Request 'Calculate Gain and Losses' program") 
   Delay(5000)
   jFrame.Keys("[Tab]")
   Delay(2000)
   
   #Identifying the parameters frame to enter the parameters
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Parameters","FlexWindow"]
   parameters_form=jFrame.FindChildEx(prop,val,60,True,60000)
   
   book_txtfield=parameters_form.FindChild("AWTComponentAccessibleName","Book REQUIRED List Values",10)
   book_txtfield.Click()
   book_txtfield.Keys("MAN USCORP BOOK")
   Delay(5000)
   jFrame.Keys("[Tab]")
   Delay(2000)
   jFrame.keys("~o")
   self.log_message_oracle_form( jFrame,"Parameters for 'Calculate Gain and Losses Program' succesfully") 
   Delay(2000)
   
   #Submit request
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Submit alt m","Button"]
   submitrequest_form.FindChild(prop,val,60).Click()
   Delay(3000)
   
   val = ["Decision Request submitted*","ChoiceBox"]
   decision_box = jFrame.FindChildEx(prop,val,60,True,12000)
   RequestID = ''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit())
   self.log_message_oracle_form( jFrame,"'Calculate Gain and Losses Program' submitted successfully and Request ID is "+VarToStr(RequestID))
   
   #select no
   jFrame.Keys("~n")
   Delay(2000)
   dsn = self.testConfig['man_oracle_db']['dsn']
   user_id = self.testConfig['man_oracle_db']['userid']
   pwd = self.testConfig['man_oracle_db']['pwd']
   dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,RequestID)
   
   #Find all requests
   jFrame.Keys("~v")
   Delay(2000)
   jFrame.Keys("r")
   Delay(2000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Find Requests","ExtendedFrame"]
   find_req_form=jFrame.FindChild(prop,val,30)
   Delay(3000)
   jFrame.Keys("[Right]")
   Delay(2000) 
   jFrame.Keys("[Tab]")
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Request ID","VTextField"]
   find_req_form.FindChild(prop,val,60).Click()
   find_req_form.FindChild(prop,val,60).SetText(RequestID)
   jFrame.Keys("~i")
   Delay(2000)
   
   #find request form identification
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Requests","ExtendedFrame"]
   req_form=jFrame.FindChildEx(prop,val,30,True,90000)   
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val = ["Refresh Data alt R","Button"]
   req_form.FindChild(prop,val,2000).Click()
   
   #Click on output button  
   prop = ["AWTComponentAccessibleName","JavaClassName"]
   val = ["View Output alt p","Button"]
   req_form.FindChild(prop,val,2000).Click()
   Delay(3000)
   
   output_page=Sys.Browser("iexplore").Page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
   output_page.Click()
   Delay(3000)
   
   #Save the output file and close the window
   output_page.Keys("~f")
   output_page.Keys("a")
   Delay(3000)

   file_system_utils.create_folder(self.op_log_path)             
   log_path=self.op_log_path+"\\Calculate Gains and Losses_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
   Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
   Delay(1000)
   Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
   Delay(1000)
   Log.Enabled=True
   Log.File(log_path, "Calculate Gains and Losses Report Output File Attached")
   Log.Enabled=False     
   Sys.Browser("iexplore").Page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close() 
   Delay(2000) 
   
   #Submit new request
   jFrame.Keys("~m") 
   delay(3000) 
   
   #Asset Retirements report program
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Submit Request","ExtendedFrame"]
   submitrequest_form=jFrame.FindChildEx(prop,val,60,True,60000)
   submitrequest_form.Find("AWTComponentAccessibleName","Name RequiredList of Values",10).Click()
   Delay(1000)
   submitrequest_form.Find("AWTComponentAccessibleName","Name RequiredList of Values",10).SetText("MAN: FA Asset Retirements Report - EXCEL")
   self.log_message_oracle_form(jFrame,"Submitting Concurrent Request 'MAN: FA Asset Retirements Report - EXCEL' program") 
   Delay(5000)
   jFrame.Keys("[Tab]")
   Delay(2000)
   
   #Identifying the parameters frame to enter the parameters
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Parameters","FlexWindow"]
   parameters_form=jFrame.FindChildEx(prop,val,60,True,60000)
   book_txtfield=parameters_form.FindChild("AWTComponentAccessibleName","Book REQUIRED List Values",10)
   book_txtfield.Click()
   book_txtfield.Keys("MAN USCORP BOOK")
   Delay(2000)
   parameters_form.Keys("[Tab]")
   Delay(2000)
   parameters_form.Keys(aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%b-%Y").upper())
   Delay(2000)
   parameters_form.Keys("[Tab]")
   Delay(2000)
   parameters_form.Keys(aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%b-%Y").upper())
   Delay(2000)
   self.log_message_oracle_form( jFrame,"Parameters for 'MAN: FA Asset Retirements Report - EXCEL'- Book,Ledger Currency,From Period,To Period entered successfully")
   Delay(1000)
   val = ["OK ALT O","FormButton"]
   parameters_form.FindChild(prop,val,60).Click()
   Delay(2000)
   
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Submit alt m","Button"]
   submitrequest_form.FindChild(prop,val,60).Click()
   Delay(3000)
   
   val = ["Decision Request submitted*","ChoiceBox"]
   decision_box = jFrame.FindChildEx(prop,val,60,True,12000)
   RequestID = ''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit())
#   RequestID = aqConvert.VarToStr(''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit()))
   self.log_message_oracle_form( jFrame,"'MAN: FA Asset Retirements Report - EXCEL' submitted successfully and Request ID is "+VarToStr(RequestID))
   
   #select no
   jFrame.Keys("~n")
   Delay(3000)
   dsn = self.testConfig['man_oracle_db']['dsn']
   user_id = self.testConfig['man_oracle_db']['userid']
   pwd = self.testConfig['man_oracle_db']['pwd']
   dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,RequestID)
   Delay(3000)
   jFrame.Keys("~o")
   Delay(2000)
   jFrame.Keys("~v")
   Delay(2000)    
   jFrame.Keys("f")
   Delay(2000)
   jFrame.keys("~a")
   Delay(2000)
   
   #Find all requests
   Delay(2000)
   jFrame.Keys("[Right]")
   Delay(2000) 
   jFrame.Keys("[Tab]")
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Request ID","VTextField"]
   find_req_form.FindChild(prop,val,60).Click()
   find_req_form.FindChild(prop,val,60).SetText(RequestID)
   jFrame.Keys("~i")
   Delay(4000)
   
   #find request form identification
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Requests","ExtendedFrame"]
   req_form=jFrame.FindChildEx(prop,val,30,True,90000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val = ["Refresh Data alt R","Button"]
   req_form.FindChild(prop,val,2000).Click()
   
   
   #Click on output button  
   prop = ["AWTComponentAccessibleName","JavaClassName"]
   val = ["View Output alt p","Button"]
   req_form.FindChild(prop,val,2000).Click()
   Delay(3000)
   
   #Save the output file and close the window
   output_save_as=Sys.Browser("iexplore", 2).Window("#32770", "Internet Explorer", 1).UIAObject("Internet_Explorer").Window("CtrlNotifySink", "", 9).Window("Button", "Save &as", 1) 
   output_save_as.Click()
   Delay(5000)    
   
   file_system_utils.create_folder(self.op_log_path)             
   log_path=self.op_log_path+"\\Man Asset Retirements Report Excel_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".xls"    
   Sys.Browser("iexplore", 2).Window("#32770", "Save As", 1).Keys(log_path)
   Delay(2000)
   Sys.Browser("iexplore", 2).Window("#32770", "Save As", 1).Keys("[Enter]")   
   Delay(2000)
   Log.Enabled=True
   Log.File(log_path, "MAN: FA Asset Retirements Report - EXCEL Output File Attached")
   Log.Enabled=False     
   view_download=Sys.Browser("iexplore", 2).Window("#32770", "View Downloads - Internet Explorer", 1) 
   delay(2000)
   view_download.Keys("~c")
   Delay(3000)
   req_form.Close()

   
   Delay(4000)
   navigator_form = Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("ExtendedFrame", "Navigator - AM Supervisor", 4).AWTObject("LWComponent", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("FScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("DrawnPanel", "", 0).AWTObject("FormsTabPanel", "", 0).AWTObject("TabPanelSheet", "", 0).AWTObject("FScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("DrawnPanel", "", 0).AWTObject("VTList", "Function List", 0).AWTObject("ScrollBox", "", 0).AWTObject("LWDataSourceList$Content", "", 0)
   OCR.Recognize(navigator_form).BlockByText("Assets").DblClick()
   Delay(3000)
   jFrame.Keys("~o")
   Delay(3000)
   jFrame.Keys("~o")
   Delay(5000) 

   self.log_message_oracle_form( jFrame,"Navigating to 'Find Assets' form")
   
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Find Assets","ExtendedFrame"]
   findassets_form=jFrame.FindChildEx(prop,val,60,True,60000)
   #query asset number in find assets form
   findassets_form.Find("AWTComponentAccessibleName","Asset Number",10).Click()
   findassets_form.Find("AWTComponentAccessibleName","Asset Number",10).SetText(asset_num) 
   self.log_message_oracle_form( jFrame,"In 'Find Assets' form Asset Number: "+VarToStr(asset_num)+" entered")
   Delay(5000)
   findassets_form.Keys("[Tab]")
   
   #Finding the asset number
   self.log_message_oracle_form( jFrame,"In 'Find Assets' form: Click 'Find' next")
   findassets_form.FindChild("AWTComponentAccessibleName","Find alt i",10).Click()
   Delay(3000)
   
   #Assets form identification and verifying its existence
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Assets","ExtendedFrame"]
   assets_form=jFrame.FindChildEx(prop,val,60,True,60000)
   self.log_message_oracle_form( jFrame,"'Assets' form launched successfully")
#   self.verify_aqobject_chkproperty(assets_form,"AWTComponentAccessibleName",cmpContains,"Assets")

   
   #Financial inquiry button in assets form
   self.log_message_oracle_form( jFrame,"In 'Assets' form click on 'Financial Inquiry' button next")
   assets_form=jFrame.FindChildEx(prop,val,60,True,90000)
#   self.log_message_oracle_form( jFrame,"Assets form found")     
   prop = ["AWTComponentAccessibleName","JavaClassName"]
   val = ["Financial Inquiry alt i","Button"]
   assets_form.FindChild(prop,val,2000).Click()
   Delay(3000)
   
   #Financial inquiry form identification
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["View Financial Information*","ExtendedFrame"]
   view_fin_form=jFrame.FindChildEx(prop,val,60,True,90000) 
   self.log_message_oracle_form( jFrame,"View Financial Information form launched successfully")  
   self.log_message_oracle_form( jFrame,"In 'View Financial Information' form click on 'Cost History' Tab next") 
   #Navigate to cost history and close the form   
   view_fin_form.FindChild("AWTComponentName","FormsTabPane*",20).ClickTab("Cost History")   
   self.log_message_oracle_form( jFrame,"Review Retirement Information on 'Cost History' Tab")    
   prop=["AWTComponentAccessibleName","AWTComponentIndex"]
   val=["Cost Required",42]
   cost=view_fin_form.FindChild(prop,val,30)
   self.verify_aqobject_chkproperty(cost,"wSelection",cmpContains,"0")   
   
#  Below code is for displaying the Retirements form showing the Gain / loss of an asset 
   view_fin_form.Close()
   delay(5000)
   assets_form.FindChild("AWTComponentAccessibleName","Retirements alt R",10).Click()
   delay(5000)
   jFrame.Keys("[F11]")
   delay(2000)
   jFrame.Keys("^[F11]")
   delay(4000)
   
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["retirements","ExtendedFrame"]   
   retirements_form=jFrame.FindChildEx(prop,val,10,True,60000)
   prop=["AWTComponentAccessibleName","AWTComponentIndex"]
   val=['Status Required',5]    
   Delay(2000)  
   status_val = retirements_form.FindChild(prop,val,10)
   Delay(2000)
   Log.Enabled=True
   aqObject.CheckProperty(status_val,"wText",cmpIn,"Processed")
   Log.Enabled=False

   Delay(2000)       
   self.log_message_oracle_form( jFrame,"Retirement Form displaying the Gain/loss of an asset")
   delay(3000)
   
   prop=["AWTComponentAccessibleName","AWTComponentIndex"]
   val=['Gain/Loss Amount',15]    
   Delay(2000)  
   Gain_loss_val = retirements_form.FindChild(prop,val,10).wText
   self.log_message_oracle_form( jFrame,"Gain/Loss of an Asset : "+'$'+VarToStr(Gain_loss_val))
   Delay(2000) 
    
   jFrame.Keys("[F4]")
   Delay(2000) 
   self.log_message_oracle_form( jFrame,"Switching Responsibility to 'AM Supervisor' next")    
     
   #Switching Responsibility
#   OCR.Recognize(menu_bar).BlockByText("File").Click()
#   Delay(1000)
#   jFrame.Keys("w")
#   Delay(2000)

   jFrame.Click()
   Delay(2000)
   jFrame.Keys("~f")
   Delay(4000)
   jFrame.Keys("w")
   Delay(4000)

   #Switiching responsibility form identification    
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Responsibilities","FWindow"]
   resp_form=jFrame.FindChildEx(prop,val,30,True,60000)
   
   #selecting the responsibility
   resp_form.Find("AWTComponentName","LWTextField*",10).Click() 
   resp_form.Find("AWTComponentName","LWTextField*",10).keys("AM Supervisor")
   val = ["Find ALT F","PushButton"]
   resp_form.FindChild(prop,val,20).Click()
   Delay(2000) 
   jFrame.Keys("~v")
   delay(2000)
   jFrame.Keys("r")
   delay(4000) 
   self.log_message_oracle_form(jFrame,"'AM Supervisor' launched successfully and Submit New Request next")
   delay(2000) 
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Find Requests","ExtendedFrame"]
   findreq_form=jFrame.FindChildEx(prop,val,30,True,90000)
   
   val=["Submit a New Request alt N","Button"]
   findreq_form.FindChild(prop,val,30).Click()
   self.log_message_oracle_form(jFrame,"Submitting 'Create Accounting' Program")
   
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Submit Request","ExtendedFrame"]
   submitrequest_form=jFrame.FindChildEx(prop,val,60,True,60000)
   submitrequest_form.Find("AWTComponentAccessibleName","Name RequiredList of Values",10).Click()
   Delay(4000)
   submitrequest_form.Find("AWTComponentAccessibleName","Name RequiredList of Values",10).SetText("Create Accounting - Assets")
   delay(3000)
   jFrame.Keys("[Tab]")
   delay(4000) 
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Parameters","FlexWindow"]
   parameters_form=jFrame.FindChildEx(prop,val,60,True,60000)
   book_txtfield=parameters_form.FindChild("AWTComponentAccessibleName","Book Type Code REQUIRED List Values",10)
   book_txtfield.Click()
   delay(2000)
   book_txtfield.Keys("MAN USCORP BOOK")
   Delay(2000)
   parameters_form.Keys("[Tab]")
   Delay(2000)
   process_category=parameters_form.FindChild("AWTComponentAccessibleName","Process Category List Values",10)
   process_category.Click()
   process_category.Keys("Retirements")
   Delay(2000)
   parameters_form.Keys("[Tab]")
   Delay(2000)
   report_txtfield=parameters_form.FindChild("AWTComponentAccessibleName","Report REQUIRED List Values: No Report",10)
   report_txtfield.Click()
   report_txtfield.Keys("Detail")
   Delay(2000)
   parameters_form.Keys("[Tab]")
   Delay(2000)
   self.log_message_oracle_form(jFrame,"'Create Accounting - Assets' Program Parameters entered successfully")
   val = ["OK ALT O","FormButton"]
   parameters_form.FindChild(prop,val,60).Click()
   Delay(2000)
   
   #submit
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Submit alt m","Button"]
   submitrequest_form.FindChild(prop,val,60).Click()
   self.log_message_oracle_form(jFrame,"Create Accounting - Assets job submitted")
   Delay(2000)
   
   val = ["Decision Request submitted*","ChoiceBox"]
   decision_box = jFrame.FindChildEx(prop,val,60,True,12000)
#   RequestID = ''.join(x for x in decision_box.AWTComponentAccessibleName if x.isdigit())
   RequestID = ''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit())
#   RequestID = aqConvert.VarToStr(''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit()))
   self.log_message_oracle_form( jFrame,"'Create Accounting - Assets' program submitted successfully and Request ID is "+VarToStr(RequestID))
   
   jFrame.Keys("~n")
   Delay(2000)
   dsn = self.testConfig['man_oracle_db']['dsn']
   user_id = self.testConfig['man_oracle_db']['userid']
   pwd = self.testConfig['man_oracle_db']['pwd']
   dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,RequestID)
   form_utils.save_output_singlereq(self,jFrame,self.op_log_path,"Create Accounting - Assets",RequestID) 
   Delay(5000) 
   jFrame.Click()
   Delay(5000)
   
#   menu_bar=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWMenuBar", "", 0)
#   OCR.Recognize(menu_bar).BlockByText("View").Click()
#   Delay(1000)
#   view_menu=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("LWPopupMenu", "", 0)
#   OCR.Recognize(view_menu).BlockByText("Requests").Click()
#
#   view_menu=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("LWPopupMenu", "", 0)
#   OCR.Recognize(view_menu).BlockByText("Requests").Click()
#
#   Delay(2000)
#   jFrame.Keys("~i")
#   Delay(2000)

#   jFrame.Keys("~v")
#   delay(2000)
#   jFrame.Keys("r")
#   Delay(3000)
#   jFrame.Keys("~i")
#   Delay(2000) 
#   Delay(160000)
## Navigating to Create Accounting Request ID   
#   jFrame.Keys("~v")
#   delay(2000)
#   jFrame.Keys("r")
#   Delay(3000)
#   jFrame.Keys("~a")
#   Delay(2000)
#   jFrame.Keys("[Right]")
#   Delay(5000)
##   jFrame.Keys("~o") 
##   Delay(5000)
#   jFrame.Keys("[Tab]")
#   delay(5000)
#   jFrame.Keys("~o") 
#   Delay(5000)
#   
#   prop=["AWTComponentAccessibleName","JavaClassName"]
#   val=["Find Requests","ExtendedFrame"]
#   find_req_form=jFrame.FindChildEx(prop,val,30,True,90000)
#   
#   prop=["AWTComponentAccessibleName","JavaClassName"]
#   val=["Request ID","VTextField"]
#   jFrame.Keys("~o") 
#   Delay(5000)
#   find_req_form.FindChild(prop,val,60).Click()
#   find_req_form.FindChild(prop,val,60).SetText(RequestID)
#   delay(2000)
#   jFrame.Keys("~i")
#   Delay(4000)
#   
#   prop=["AWTComponentAccessibleName","JavaClassName"]
#   val=["Requests","ExtendedFrame"]
#   req_form=jFrame.FindChildEx(prop,val,30,True,90000)
#
#   
#   prop = ["AWTComponentAccessibleName","JavaClassName"]
#   val = ["View Output alt p","Button"]
#   req_form.FindChild(prop,val,2000).Click()
#   Delay(3000)
   
 # Saving the Create Accounting Output file, Without having any PDF reader in system.
#   view_download=Sys.Process("iexplore", 3).Window("#32770", "View Downloads - Internet Explorer", 1).UIAObject("View_and_track_your_downloads").UIAObject("Create_Accounting_Assets*").UIAObject("Save").UIAObject(1)
#   delay(2000)
#   Sys.HighlightObject(view_download)
#   view_download.Click()
#   delay(2000) 
#   view_download.Keys("[Down]")
#   delay(2000)
#   view_download.Keys("[Enter]")
#   delay(2000)
#		
#   log_path=self.op_log_path+"\\Create Accounting Assets_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".pdf"    
#   Sys.Process("iexplore", 3).Window("#32770", "Save As", 1).Keys(log_path)
#   Delay(2000)
#   Sys.Process("iexplore", 3).Window("#32770", "Save As", 1).Keys("[Enter]")   
#   Delay(2000) 
#   Log.Enabled=True
#   Log.File(log_path, "Create Accounting Output File Attached")
#   Log.Enabled=False
#   Delay(2000)   
#   view_download=Sys.Process("iexplore", 3).Window("#32770", "View Downloads - Internet Explorer", 1).UIAObject("View_and_track_your_downloads")	
#   delay(2000)
#   view_download.Keys("~l")
#   delay(3000)
#   view_download.Keys("~c")
#   Delay(3000) 

# Saving the Create Accounting Output file, with Acrobat Adobe PDF reader installed.

#   web_utils.log_checkpoint("PDF Output generated Successfully",500,Sys.Browser("iexplore").BrowserWindow(0))
#   Sys.Keys("!^s")
#   Delay(10000) 
#   log_path=self.op_log_path+"\\+Create Accounting Assets_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".pdf"
#   Sys.Process("AcroRd32").Window("#32770", "Save As", 1).Keys(log_path)
#   delay(2000)
#   Sys.Process("AcroRd32").Window("#32770", "Save As", 1).Keys("[Enter]")
#   delay(2000)
#   Log.Enabled=True
#   Log.File(log_path, "Create Accounting Output File Attached")
#   Log.Enabled=False  
#   delay(2000)
#   Sys.Process("iexplore", 3).Window("IEFrame", "https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*", 1).Close() 
   
#   Delay(160000) 
#   form_utils.save_output_singlereq(self,jFrame,self.op_log_path,"Create Accounting - Assets",RequestID) 
#   Delay(5000) 
#   Sys.HighlightObject(jFrame)
#   delay(2000)

#   jFrame.Click()
#   Delay(5000)
#   jFrame.Keys("~v")
#   delay(3000)
#   jFrame.Keys("r")
#   Delay(3000)
#   jFrame.Keys("~i")
#   Delay(3000)
#     
#    
#   #Verify job completion
#   #output file view, save and close the output window
#   
#   creq_id,log_path = form_utils.req_set_save_output(self,jFrame,req_form,"Journal Import",RequestID)
#   delay(3000)
#   web_utils.close_additional_browsers()
#   
#   #read the output file and save in excel
#   fo=open(log_path,"r") 
#   lines=fo.readlines()
#   self.log_message_web("Journal Imported Batch Name is : - "+lines[17][8:34].strip())
#   app.Cells.Item[rowno,1] = lines[17][8:34].strip()   
   
   #Close form
   jFrame.Click()
   Delay(1000)
   jFrame.keys("[F4]")
   Delay(2000)
   self.close_forms(jFrame)

   Sys.Browser("iexplore", 2).Window("#32770", "View Downloads - Internet Explorer", 1).keys("~c")
   #save book and close addition tabs in IE
   book.save()


   
   
   
   
   
