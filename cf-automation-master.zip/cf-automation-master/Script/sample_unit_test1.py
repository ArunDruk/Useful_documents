﻿class test1():
  import file_system_utils
  op_log_path="C:\\Tc_Logs"
  def func1(self):  
    jFrame=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1)
    Sys.HighlightObject(jFrame)
    jFrame.Click()
    delay(1000)
#    jFrame.Keys("~v")
#    delay(2000)
#    jFrame.Keys("r")
#    delay(2000)
#    jFrame.Keys("~i")
#    delay(2000)
#    jFrame.Keys("[F4]")
#    delay(3000)
##    jFrame.Keys("[Enter]")
#    navigator_form = Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("ExtendedFrame", "Navigator - CAI ALL GL JOURNAL PROCESSING", 4)
#    Sys.HighlightObject(navigator_form)
##    OCR.Recognize(navigator_form).BlockByText("Enter Journals").DblClick()
#    OCR.Recognize(navigator_form).BlockByText("Open").Click()
#    delay(2000)
#
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,40000) 
    RequestID = "30457989" 
    self.req_set_save_output(jFrame,req_form,"PRC: Generate Cost Accounting Events",RequestID)
    Delay(1000)
    # Just for debug, Uncomment later - Uday
    jFrame.Keys("~w") 
    Delay(2000)
    jFrame.Keys("2") 
    self.req_set_save_output(jFrame,req_form,"PRC: Distribute Supplier Cost Adjustments",RequestID)  #form_utils.req_set_save_output(self,jFrame,req_form,"PRC: Distribute Supplier Cost Adjustments",RequestID) #self.req_set_save_output(jFrame,req_form,"PRC: Distribute Supplier Cost Adjustments") 
    Delay(1000)
    jFrame.Keys("~w") 
    Delay(2000)
    jFrame.Keys("2")
    self.req_set_save_output(jFrame,req_form,"PRC: Distribute Usage and Miscellaneous Costs",RequestID)
    Delay(1000)
     
    jFrame.Keys("~w") 
    Delay(1000)
    jFrame.Keys("2")
    self.req_set_save_output(jFrame,req_form,"PRC: Distribute Labor Costs",RequestID)  
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(2000) 
    jFrame.Keys("~c")
    Delay(2000)
    jFrame.Keys("~f")
    Delay(1000)
    jFrame.Keys("w")
    Delay(3000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Responsibilities","FWindow"]
    resp_form=jFrame.FindChildEx(prop,val,30,True,40000)
    resp_form.Find("AWTComponentName","LWTextField*",10).Click()
    Delay(1000)
    resp_form.Find("AWTComponentName","LWTextField*",10).Keys("[BS]")
    Delay(1000)
    resp_form.Find("AWTComponentName","LWTextField*",10).keys("CAI "+self.oper_unit+" PA PROJECT CONTROLS")
    self.log_message_oracle_form( jFrame,"Changed the responsibility to CAI "+self.oper_unit+" PA PROJECT CONTROLS")
    Delay(2000)
    resp_form.Find("AWTComponentName","LWTextField*",10).Click()    
    Delay(2000)
    jFrame.Keys("~f")
    self.log_message_oracle_form( jFrame,"Navigation Details")
    Delay(3000)
    jFrame.keys("e")
    Delay(1000)
    jFrame.keys("e")
    Delay(1000)
    jFrame.keys("~o")
    Delay(3000) 
    
  def req_set_save_output(self,jFrame,req_form,srch_child_name,Preqid):
         import file_system_utils 
         i=20
         for x in range(i,50):
           prop=["AWTComponentAccessibleName","AWTComponentIndex"]
           val=["Name",x]
           child_name=req_form.Find(prop,val,10)
           child_name.Keys("[Enter]")
           child_name.Click()
           child_name=child_name.wText
              
           if x>20:
              jFrame.Keys("[Down]") 
              
              Delay(1000)
              prop=["AWTComponentAccessibleName","AWTComponentIndex"]
              val=["Phase",i+20]
              phase=req_form.Find(prop,val,10).wText 
              prop=["AWTComponentAccessibleName","AWTComponentIndex"]
              val=["Request ID",i-10]
              creqid=VarToInt(req_form.Find(prop,val,10).wText)     
           if (child_name==srch_child_name) and (creqid >= VarToInt(Preqid)) and (phase == "Completed"):
    #         Delay(500)
    #         req_form.Find(prop,val,10).Keys("[Enter]")
             Delay(600)
             prop=["AWTComponentAccessibleName","JavaClassName"]
             val=["View Output alt p","Button"]
             output_button=req_form.FindChild(prop,val,60)
             output_button.Find("AWTComponentAccessibleName","View Output alt p").Click()         
             #jFrame.Keys("~p")    
             Delay(3000)
             output_page=Sys.Browser("iexplore").Page("https://core-*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")            
             output_page.Click()
             Delay(2000)
             output_page.Keys("~f")
             Delay(6000)
             output_page.Keys("a")
             Delay(6000)
             file_system_utils.create_folder("C:\\Tc_Logs")   #self.op_log_path          
             log_path="C:\\Tc_Logs"+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"Is Attached_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
             Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
             Delay(1000)
             Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
             Delay(2000)
             Log.Enabled=True
             Log.File(log_path, aqConvert.VarToStr(srch_child_name)+" Program is completed and Output File Is Attached")
             Log.Enabled=False       
             Sys.Browser("iexplore").page("https://core-*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close()  
             Delay(2000)   
    #         jFrame.Click()
             Delay(2000)
             val=["Name",20]
             req_form.Find(prop,val,10).Keys("[Enter]")
             Delay(500)
             break  

def main():
  class_obj= test1()
  class_obj.func1()
  
def main1():
    jFrame=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1)
    Sys.HighlightObject(jFrame)
    jFrame.Click()
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,40000)
    req_form.Close()
    jFrame.Keys("~f")
    Delay(1000)
    jFrame.Keys("w")
    Delay(3000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Responsibilities","FWindow"]
    resp_form=jFrame.FindChildEx(prop,val,30,True,40000)
    resp_form.Find("AWTComponentName","LWTextField*",10).Click()
    Delay(1000)
    resp_form.Find("AWTComponentName","LWTextField*",10).Keys("[BS]")
    Delay(1000)
    resp_form.Find("AWTComponentName","LWTextField*",10).keys("CAI "+self.oper_unit+" PA PROJECT CONTROLS")
  
  
    
    