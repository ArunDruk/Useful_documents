﻿#import all_routine_list

from driverchain import *
from EbizVerfiyWebAdiJournals import *


class driver(Driverchain):
  global classarr
  
  def __init__(self):   
    global test_env
    self.test_env="tmnh2i"  
    self.classarr=["EbizVerfiyWebAdiJournals()"]     
    super().__init__(self.classarr)
    
    
def main():  
  obj=driver().run()
