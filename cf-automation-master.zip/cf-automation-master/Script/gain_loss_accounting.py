﻿from dbhelper import *
from ebiz import *
import web_utils
import dbhelper
import file_system_utils 
import form_utils

class gain_loss_accounting(Ebiz):
 op_log_path="C:\\Tc_Logs"

 def login(self):
   self.login_user='pkjami'
   super().login()
 
 def goto_url(self,url):
    super().goto_url(self.testConfig['ebiz']['oci_is_url'])
   
 def action(self,book): 
   app = book.Sheets.item["Assets"] 
   rowno=2
   
   #Login to Oracle
   self.wait_until_page_loaded()    
   self.log_checkpoint_message_web("Login Successful")
   
   #Selecting the responsibility
   web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'AM Super User')]")
   self.log_message_web("Click 'AM Super User' - Successful")
   Delay(3000)
   self.page.NativeWebObject.Find("contentText","Other","A").Click()
   self.log_message_web("Click 'Other' - Successful")
   Delay(2000)
   self.page.wait()
   self.page.NativeWebObject.Find("contentText","Requests","A").Click()
   self.log_message_web("Click 'Requests' - Successful")
   Delay(2000)
   self.page.wait()
   self.page.NativeWebObject.Find("contentText","Run","A").Click()
   self.log_message_web("Click 'Run' - Successful")
   Delay(2000)
   self.page.wait()
   #Handling the security pop-up and opening forms
   web_utils.validate_security_box()
   jFrame= self.initializeJFrame()
   Delay(5000)
   form_utils.click_ok_btn(jFrame)
   Delay(5000)
   jFrame.Keys("~c")
   delay(4000) 
   jFrame.keys("~v")
   delay(2000)
   jFrame.keys("r") 
   delay(3000)

#####   menu_bar=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWMenuBar", "", 0)
#####   OCR.Recognize(menu_bar).BlockByText("View").Click()
#####   Delay(1000)
#####
#####   view_menu=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("LWPopupMenu", "", 0)
#####   OCR.Recognize(view_menu).BlockByText("Requests").Click()
   
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Find Requests","ExtendedFrame"]
   findreq_form=jFrame.FindChildEx(prop,val,30,True,90000)
   
   val=["Submit a New Request alt N","Button"]
   findreq_form.FindChild(prop,val,30).Click()
   
   #Identifying the submit request window and providing request name 
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Submit Request","ExtendedFrame"]
   submitrequest_form=jFrame.FindChildEx(prop,val,60,True,60000)
   submitrequest_form.Find("AWTComponentAccessibleName","Name RequiredList of Values",10).Click()
   Delay(1000)
   submitrequest_form.Find("AWTComponentAccessibleName","Name RequiredList of Values",10).SetText("Calculate Gains and Losses")
   self.log_message_oracle_form(jFrame,"Submitting Concurrent Request 'Calculate Gain and Losses' program") 
   Delay(5000)
   jFrame.Keys("[Tab]")
   Delay(2000)
   
   #Identifying the parameters frame to enter the parameters
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Parameters","FlexWindow"]
   parameters_form=jFrame.FindChildEx(prop,val,60,True,60000)
   
   book_txtfield=parameters_form.FindChild("AWTComponentAccessibleName","Book REQUIRED List Values",10)
   book_txtfield.Click()
   book_val = VarToStr(app.Cells.Item[2,4])
   book_txtfield.Keys(book_val)
   Delay(5000)
   jFrame.Keys("[Tab]")
   Delay(2000)
   jFrame.keys("~o")
   self.log_message_oracle_form( jFrame,"Parameters for 'Calculate Gain and Losses Program' succesfully") 
   Delay(2000)
   
   #Submit request
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Submit alt m","Button"]
   submitrequest_form.FindChild(prop,val,60).Click()
   Delay(3000)
   
   val = ["Decision Request submitted*","ChoiceBox"]
   decision_box = jFrame.FindChildEx(prop,val,60,True,12000)
#   RequestID = ''.join(x for x in decision_box.AWTComponentAccessibleName if x.isdigit())
   RequestID = aqConvert.VarToStr(''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit()))
   self.log_message_oracle_form( jFrame,"'Calculate Gain and Losses Program' submitted successfully and Request ID is "+VarToStr(RequestID))
   
   #select no
   jFrame.Keys("~n")
   Delay(2000)
   
   #Find all requests
   jFrame.Keys("~v")
   Delay(2000)
   jFrame.Keys("r")
   Delay(2000)
   
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Find Requests","ExtendedFrame"]
   find_req_form=jFrame.FindChild(prop,val,30)
   Delay(3000)

   jFrame.Keys("[Right]")
   Delay(2000) 
   jFrame.Keys("[Tab]")

   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Request ID","VTextField"]
   find_req_form.FindChild(prop,val,60).Click()
   find_req_form.FindChild(prop,val,60).SetText(RequestID)
   
   jFrame.Keys("~i")
   Delay(2000)
   
   #find request form identification
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Requests","ExtendedFrame"]
   req_form=jFrame.FindChildEx(prop,val,30,True,90000)   
   
   #verifying for request completion
   dsn = self.dbconfig[self.testConfig['ebiz']['env']]['man_dsn']
   user_id = self.dbconfig[self.testConfig['ebiz']['env']]['man_userid']
   pwd = self.dbconfig[self.testConfig['ebiz']['env']]['man_pwd']
   dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,RequestID)
   
   Delay(100000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val = ["Refresh Data alt R","Button"]
   req_form.FindChild(prop,val,2000).Click()
   
   #Click on output button  
   prop = ["AWTComponentAccessibleName","JavaClassName"]
   val = ["View Output alt p","Button"]
   req_form.FindChild(prop,val,2000).Click()
   Delay(3000)
   
   output_page=Sys.Browser("iexplore").Page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
   output_page.Click()
   Delay(3000)
   
   #Save the output file and close the window
   output_page.Keys("~f")
   output_page.Keys("a")
   Delay(3000)

   file_system_utils.create_folder(self.op_log_path)             
   log_path=self.op_log_path+"\\Calculate Gains and Losses_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
   Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
   Delay(1000)
   Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
   Delay(3000)
   Log.Enabled=True
   Log.File(log_path,"Calculate Gains and Losses Report Output File Attached")
   Log.Enabled=False     
   Sys.Browser("iexplore").Page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close() 
   Delay(2000) 
   
####   #Submit new request
   jFrame.Keys("~m") 
   
# submit create accounting program:
   delay(3000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Submit Request","ExtendedFrame"]
   submitrequest_form=jFrame.FindChildEx(prop,val,60,True,60000)
   submitrequest_form.Find("AWTComponentAccessibleName","Name RequiredList of Values",10).Click()
   Delay(4000)
   submitrequest_form.Find("AWTComponentAccessibleName","Name RequiredList of Values",10).SetText("Create Accounting - Assets")
   delay(3000)
   jFrame.Keys("[Tab]")
   delay(4000) 
   
#Entering Parameters
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Parameters","FlexWindow"]
   parameters_form=jFrame.FindChildEx(prop,val,60,True,60000)
   book_txtfield=parameters_form.FindChild("AWTComponentAccessibleName","Book Type Code REQUIRED List Values",10)
   book_txtfield.Click()
   book_txtfield.Keys(VarToStr(app.Cells.Item[2,4]))
   Delay(1000)
   parameters_form.Keys("[Tab]")
   Delay(1000)
   report = parameters_form.FindChild("AWTComponentAccessibleName","Report REQUIRED List Values: No Report",10)
   report.Click()
   report.Keys("Detail")
   Delay(1000)
   parameters_form.Keys("[Tab]")
   Delay(1000)
   self.log_message_oracle_form(jFrame,"'Create Accounting - Assets' Program Parameters entered successfully")
   val = ["OK ALT O","FormButton"]
   parameters_form.FindChild(prop,val,60).Click()
   Delay(2000)
   
#submit create  accounting
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Submit alt m","Button"]
   submitrequest_form.FindChild(prop,val,60).Click()
   self.log_message_oracle_form(jFrame,"Create Accounting - Assets job submitted")
   Delay(2000)
   
   val = ["Decision Request submitted*","ChoiceBox"]
   decision_box = jFrame.FindChildEx(prop,val,60,True,12000)
   RequestID = aqConvert.VarToStr(''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit()))
   self.log_message_oracle_form( jFrame,"'Create Accounting-Assets' program submitted successfully and Request ID is "+VarToStr(RequestID))
   delay(1000)
   jFrame.Keys("~n")
   delay(1000)
   jFrame.Keys("~o")
   delay(1000)
   jFrame.Keys("~[F4]")
   delay(1000)
#   jFrame.Keys("~[F4]")
   self.close_forms(jFrame)
#   RequestID = VarToStr(172842724)

   
# launch jframe againt to validate journal import
   self.page.EvaluateXpath("//li[@id='LIRequests']/a/div[2]")[0].scrollIntoView()
   self.page.EvaluateXpath("//li[@id='LIRequests']/a/div[2]")[0].Click()
   
   web_utils.log_checkpoint("Navigating to Requests Form to Validate Create Accounting and Journal Import Report",500,self.page)   
   web_utils.validate_security_box()
   Delay(6000)
   jFrame=self.initializeJFrame()
   Delay(20000)
   form_utils.click_ok_btn(jFrame) 
   Delay(7000)
   jFrame.Keys("~c")
   Delay(3000)
   web_utils.log_checkpoint("*******Validating output for Create Accounting Program*********",500,jFrame) 
   form_utils.save_output_singlereq(self,jFrame,self.op_log_path,"Create Accounting - Assets",RequestID)
   delay(2000)
   self.close_forms(jFrame)
   Delay(5000)
   self.page.EvaluateXpath("//li[@id='LIRequests']/a/div[2]")[0].scrollIntoView()
   self.page.EvaluateXpath("//li[@id='LIRequests']/a/div[2]")[0].Click()
   web_utils.validate_security_box()
   Delay(10000)
   jFrame=self.initializeJFrame()
   Delay(20000)
   form_utils.click_ok_btn(jFrame) 
   Delay(7000)
   jFrame.Keys("~c")
   Delay(3000)
   
   #verifying for request completion
   dsn = self.dbconfig[self.testConfig['ebiz']['env']]['man_dsn']
   user_id = self.dbconfig[self.testConfig['ebiz']['env']]['man_userid']
   pwd = self.dbconfig[self.testConfig['ebiz']['env']]['man_pwd']
   je_req_id = dbhelper.vfy_oracle_concurrent_job_je(dsn,user_id,pwd,RequestID)
   delay(2000)
   
   web_utils.log_checkpoint("Journal Import Request ID : "+VarToStr(je_req_id),500,jFrame) 
   web_utils.log_checkpoint("*******Validating output for Journal Import*********",500,jFrame) 
   log_path = form_utils.save_output_ji(self,jFrame,self.op_log_path,"Journal Import",je_req_id)
   fo=open(log_path,"r") 
   lines=fo.readlines()
   self.log_message_web("Journal Imported Batch Name is : - "+lines[17][8:39].strip())
   if app.Cells.Item[2,5] == "Retired":
      app.Cells.Item[rowno,3] = lines[17][8:39].strip()  
      app.Cells.Item[rowno,4] = VarToStr(je_req_id)
   else:  
     app.Cells.Item[rowno,1] = lines[17][8:39].strip()  
     app.Cells.Item[rowno,2] = VarToStr(je_req_id)
   jFrame.Click()
   Delay(3000)
   jFrame.Keys("[F4]")
   Delay(3000)

   wscript=Sys.OleObject["WScript.Shell"]
   wscript.Run("taskkill.exe /F /IM jp2launcher.exe /T")
   Delay(3000)
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
 