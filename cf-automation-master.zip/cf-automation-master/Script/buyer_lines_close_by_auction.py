﻿import gvar
import database_helper
import login_logout_utility
import oracle_responsibility_utility
import form_utility
import tc_logs
import buyer_lines_closure

def closure():
#  closed =  database_helper.verify_buyer_lines_status(gvar.dataprep['buyer_order'])
#  if closed == 'CLOSED':
#    login_logout_utility.oracle_login()    
    oracle_responsibility_utility.ar_home_office_super_user('Run')
    form_utility.get_java_parent_form()
    buyer_lines_closure.submit_buyer_invoice_creation_program()
#    form_utility.close_form()
    aqUtils.Delay(20000)
#    login_logout_utility.oracle_logout()
