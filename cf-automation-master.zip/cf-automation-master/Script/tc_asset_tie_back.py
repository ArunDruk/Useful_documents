﻿from base import *
from driverchain import *
from ebiz import *
import test_utility
import gvar
import tc_logs



class Driver(Driverchain):
  global classarr,env
  
  def __init__(self):
    global test_env, sheet_obj, book     
    app = Sys.OleObject["Excel.Application"]
    Delay(1000)
    self.book = app.Workbooks.Open(Project.Path+"\\datasheets\\ISRegression\\createpo_prj_ncrequest.xls")          
    app.Visible = "True"    
    self.test_env=BuiltIn.ParamStr(14)
    self.oper_unit = BuiltIn.ParamStr(15)
    self.classarr=["asset_tie_back()"]
    super().__init__(self.classarr)
        
  def close_excel(self):    
    self.book.save()
    delay(1000)
    self.book.close()
	

    	
def main():
 try:
   obj=Driver()
   if obj.test_env == "oci_stage":   
     test_utility.start_test(__name__.center(70,'*'),'Core Financials - CF','A2R - Fixed Assets Reporting','186160','MAN CBR - OCI Stage')   
   elif obj.test_env =="oci_test":
     test_utility.start_test(__name__.center(70,'*'),'Core Financials - CF','A2R - Fixed Assets Reporting','186160','MAN CBR - OCI Test')
 
   cobj = obj.run()
   print('evoke test_utility')
 except:
   gvar.dataprep['verdict'] = 'Fail'
   tc_logs.header_name('Test Failed - traceback shown below')       
   tc_logs.error_with_no_picture(traceback.format_exc(),'')       
   print('evoke test_utility')
 finally:
#   test_utility.end_test()
   obj.close_excel()


