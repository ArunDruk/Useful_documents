﻿from base import *
from driverchain import *
from ebiz import *
import test_utility
import gvar
import tc_logs
import store_retrieve_po_details

class Driver(Driverchain):
  global classarr,env
  
  def __init__(self):
    global test_env, sheet_obj, book  
    app = Sys.OleObject["Excel.Application"]
    Delay(1000)
    self.book = app.Workbooks.Open(Project.Path+"\\datasheets\\WCI\\wci_po_creation_ca.xls")
    gvar.dataprep['book'] = self.book   
    app.Visible = "True"    
    self.test_env=BuiltIn.ParamStr(14)
    self.oper_unit=BuiltIn.ParamStr(15) 
    gvar.dataprep['test_env'] = self.test_env
    gvar.dataprep['oper_unit'] = self.oper_unit
    self.classarr=["tc85181cai_us_project_creation()","ie_clear_cache()","tc93546cai_us_create_non_catalog_req()","ie_clear_cache()","test_approve_requisition()","ie_clear_cache()","tc93548cai_us_CreatePO()","tc98611cai_us_auto_create_po_validation_1()","receive_po_items_wfr_quantity()"]
    super().__init__(self.classarr)         

    	  
  def close_excel(self):    
    self.book.save()
    delay(1000)
    self.book.close()
	
### Added utilities in the main method for Rally TestComplete API Integration (Pushing to GIT in TOGGLE:OFF mode)###
    	
def main():

    obj=Driver()
    cobj = obj.run()
    store_retrieve_po_details.send_results_to_db()
    obj.close_excel()


