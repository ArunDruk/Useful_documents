﻿#import all_routine_list
import traceback
import configparser
import web_utils
import form_utils
import file_system_utils
import sys
import gvar

 
class Base():
   
   def __init__(self,test_env,oper_unit,comp_name):
    global browser,page,min_wait,max_wait,med_wait,config,low_wait,avg_wait
    self.oper_unit=oper_unit.upper()
    if self.oper_unit=="" or self.oper_unit== None:
      self.log_error_message("Operating Unit parameter cannot be blank!!")
    min_wait=2000
    max_wait=20000
    med_wait=5000
    avg_wait=3000
    low_wait=1000
    Log.Enabled=False
    self.testConfig=configparser.ConfigParser()
    self.winscpConfig=configparser.ConfigParser()
    self.dbconfig=configparser.ConfigParser()
    self.config=configparser.ConfigParser()
    # Read/load config file
    if test_env.lower()=='dev3':
      config_name='testconfig_dev3.ini'
      login_attr = 'login.ini'  
    elif test_env.lower()=='silo5':
      config_name = 'testconfig.ini'
      login_attr = 'login.ini'  
    elif test_env.lower()=='qa':
      config_name = 'testconfig_qa.ini'
      login_attr = 'login.ini'  
    elif test_env.lower()=='preprod':
      config_name = 'testconfig_preprod.ini' 
      login_attr = 'login.ini'  
    elif test_env.lower()=='oci_dev':
      config_name = 'testconfig_oci_dev.ini' 
      login_attr = 'login_oci_dev3.ini'
    elif test_env.lower()=='oci_stage':
      config_name = 'testconfig_oci_stage.ini' 
      login_attr = 'login_oci_stage.ini'
    elif test_env.lower()=='oci_test':
      config_name = 'testconfig_oci_test.ini' 
      login_attr = 'login_oci_test.ini'
    elif test_env.lower()=='oci_idcs':
      config_name = 'testconfig_oci_idcs.ini' 
      login_attr = 'login_oci_idcs.ini'
    elif test_env.lower()=='oci_prod':
      config_name = 'testconfig_oci_prod.ini' 
      login_attr = 'login_oci_prod.ini'
      
#--loading gvar environment variables---prabha11/6/2019       
#    gvar.load_environment_files() 
    
    self.testConfig.read(Project.Path+"test_configs\\"+config_name)  
    self.winscpConfig.read(Project.Path+"test_configs\\winscpconfig.ini")  
    
    self.config.read(Project.Path+'\\obj_repo\\'+login_attr)
    self.dbconfig.read(Project.Path+"test_configs\\dbcredentials.ini")  
    self.test_prep()       
    self.goto_url(self.testConfig['ebiz']['url'])   
    attr = web_utils.log_attributes()   
    web_utils.log_checkpoint_message("#################################Component: '"+aqConvert.VarToStr(comp_name)+"' ###########################################################",pmHighest,attr,"")
#    self.log_message_web("#################################Component: '"+aqConvert.VarToStr(comp_name)+"' ###########################################################")    
#    self.log_message_web("URL: "+self.testConfig['ebiz']['url'])
      
   def __del__(self):
      Log.Enabled=True
      Log.Message(self.__class__.__name__+" object deleted successfully")
      Log.Enabled=False 
    
   def execute(self,book):
     try:
       self.login()
       self.action(book)
       self.logout()
#       self.clear_test()
     except Exception as e:
#       gvar.dataprep['verdict'] = 'Fail' ##### Added code to handle Rally API Integration###
#       tc_logs.header_name('Test Failed - traceback shown below')     ##### Added code to handle Rally API Integration###  
#       tc_logs.error_with_no_picture(traceback.format_exc(),'')  ##### Added code to handle Rally API Integration###       
#       print('evoke test_utility')##### Added code to handle Rally API Integration###  
       self.log_active_screen("Failed. Error Screenshot")  
       if self.__class__.__name__ =="capture_invoice_via_email":
         self.logout()
       book.save()
       Delay(3000)
       book.close()
       self.clear_test()    
       Delay(1000)
       Log.Enabled=True
       Log.Error(traceback.format_exc()) 
       Log.Enabled=False
       sys.exit("Fail")
       Runner.Stop(True)
       
   def clear_test(self):
       wscript=Sys.OleObject["WScript.Shell"]
       wscript.Run("taskkill.exe /F /IM jp2launcher.exe /T")
       if gvar.dataprep['browser'] == "ie":
          self.cache_clear()
          wscript.Run("taskkill.exe /F /IM iexplore.exe /T")
       elif gvar.dataprep['browser'] == "chrome":  
          wscript.Run("taskkill.exe /F /IM chrome.exe /T")
          self.cache_clear()
#       wscript.Run("taskkill.exe /F /IM EXCEL.exe /T")     
       wscript.Run("taskkill.exe /F /IM capture.exe /T") 
       
   def cache_clear(self):
         if gvar.dataprep['browser'] == 'ie':
            wscript=Sys.OleObject["WScript.Shell"]
            wscript.Run("RunDll32.exe InetCpl.cpl,ClearMyTracksByProcess 8")
            Delay(3000)
            wscript.Run("RunDll32.exe InetCpl.cpl,ClearMyTracksByProcess 255")
            Delay(3000)
            wscript.Run("RunDll32.exe InetCpl.cpl,ClearMyTracksByProcess 1")
            Delay(3000)
            wscript.Run("RunDll32.exe InetCpl.cpl,ClearMyTracksByProcess 2")
            Delay(3000)
            wscript.Run("RunDll32.exe InetCpl.cpl,ClearMyTracksByProcess 16")
            Delay(3000)
            wscript.Run("RunDll32.exe InetCpl.cpl,ClearMyTracksByProcess 32")
            Delay(3000)
            Log.Enabled=True
            Log.Message("IE Browser History cleared successfully!","")
            Log.Enabled=False
         elif gvar.dataprep['browser'] == 'chrome':
            aqFile.Delete("%LOCALAPPDATA%\\Google\\Chrome\\User Data\\Default\\History")
            aqFile.Delete("%LOCALAPPDATA%\\Google\\Chrome\\User Data\\Default\\Cache")
            aqFile.Delete("%LOCALAPPDATA%\\Google\\Chrome\\User Data\\Default\\Cookies")
            Log.Enabled=True
            Log.Message("Chrome Browser History cleared successfully!","")
            Log.Enabled=False
            
   def goto_url(self,url):
     if gvar.dataprep['browser'] == "ie":
       Browsers.Item[btIExplorer].Run("about:blank")       
       Browsers.CurrentBrowser.Navigate(url,3000)       
       Delay(3000)  
       #Setting the Browser & Page Object        
       self.browser = Sys.Browser("iexplore")
       gvar.store('browser_value', Sys.Browser("iexplore"))       
       self.page=self.browser.page("*")       
       self.page.Wait()
       gvar.store('page', Sys.Browser("iexplore").page("*"))
       Sys.Browser().BrowserWindow(0).Maximize()
       Log.Enabled=True
       Log.Message("Navigate to URL :"+url+" successful")
       Log.Enabled=False  
     elif gvar.dataprep['browser'] == "chrome":
       Browsers.Item[btChrome].Run("about:blank")       
       Browsers.CurrentBrowser.Navigate(url,3000)       
       Delay(3000)  
       #Setting the Browser & Page Object        
       self.browser = Sys.Browser("chrome")
       gvar.store('browser_value', Sys.Browser("chrome"))       
       self.page=self.browser.page("*")       
       self.page.Wait()
       gvar.store('page', Sys.Browser("chrome").page("*"))
       Sys.Browser().BrowserWindow(0).Maximize()
       Log.Enabled=True
       Log.Message("Navigate to URL :"+url+" successful")
       Log.Enabled=False  
       
       
   def log_message_web(self,msg):
     try:
       Log.Enabled=True     
       screenshot=self.page.PagePicture()
       Log.Picture(screenshot,msg)
       Log.Enabled=False
     except Exception as e:
       Log.Enabled=True
       Log.Message("error handled in log_message_web: "+e)  
       wnd = Sys.Desktop.ActiveWindow()
       Log.Picture(wnd, msg, wnd.FullName)            
       Log.Enabled=False
       
   def log_active_screen(self,msg):
       Log.Enabled=True
       #Log.Message(msg)  
       wnd=Sys.Desktop.Picture()
       Log.Picture(wnd,msg)       
#       wnd = Sys.Desktop.ActiveWindow()
#       Log.Picture(wnd, msg, wnd.FullName)            
       Log.Enabled=False       
     
   def log_message_oracle_excel_popup(self,excel_obj,msg):
     Log.Enabled=True    
     screenshot=excel_obj.Picture()
     Log.Picture(screenshot,msg)
     Log.Enabled=False        
     
   def log_message_oracle_form(self,oracle_obj,msg):
       Log.Enabled=True
       screenshot=oracle_obj.Picture()
       Log.Picture(screenshot,msg)
       Log.enabled=False
       
   def log_checkpoint_message_web(self,msg):
       Log.Enabled=True     
#       Log.Checkpoint(msg)
       wnd = Sys.Desktop.ActiveWindow()
       Log.Picture(wnd, msg, wnd.FullName)  
       Log.Enabled=False   
         
   def log_error_message(self,msg):
       Log.Enabled=True
       Log.Error(msg)
       wnd = Sys.Desktop.ActiveWindow()
       Log.Picture(wnd, "Error Screenshot", wnd.FullName)                  
       Log.Enabled=False  
              


   def verify_aqobject_chkproperty(self,obj,prop_name,condition,prop_val):
    Log.Enabled=True
    aqObject.CheckProperty(obj,prop_name,condition,prop_val)
    Log.Enabled=False
   
   def wait_until_page_loaded(self):
     try:
         Delay(10000)
         cnt=0
         while self.page.contentDocument.readyState != "complete":
               Delay(2000)
               cnt+=1
               if cnt==300:
                 self.log_error_message("Page load timed out!!!")
     except Exception as e:
       Delay(3000)
       self.page.wait()
       self.log_message_web("Exception handled in page load")   
       
   def test_prep(self):
    if gvar.dataprep['browser'] == "ie":                 
      if Sys.Browser("iexplore").Exists:
        if Sys.Browser("iexplore").page("https://*.coxautoinc.com/OA_HTML/OA.jsp*").EvaluateXPath("//a[text()='Logout']") != None:
            Sys.Browser("iexplore").page("https://*.coxautoinc.com/OA_HTML/OA.jsp*").EvaluateXPath("//a[text()='Logout']")[0].Click()        
            Delay(1000) 
            self.cache_clear()
    elif gvar.dataprep['browser'] == "chrome":
      if Sys.Browser("chrome").Exists:
        if Sys.Browser("chrome").page("https://*.coxautoinc.com/OA_HTML/OA.jsp*").EvaluateXPath("//a[text()='Logout']") != None:
            Sys.Browser("chrome").page("https://*.coxautoinc.com/OA_HTML/OA.jsp*").EvaluateXPath("//a[text()='Logout']")[0].Click()        
            Delay(1000)
            self.cache_clear()  
    Delay(1000)
      
#   def email_logout(self):
#    self.page.wait() 
#    Delay(2000)  
#    self.wait_until_page_loaded() 
#    self.page.EvaluateXPath("*//div//a[starts-with(@aria-label, 'Google Account:')]")[0].Click()    
#    aqUtils.Delay(4000)
#    self.page.Wait() 
#    if self.page.EvaluateXPath("*//div/a[contains(text(),'Sign out')]")[0].Exists:
#      self.page.EvaluateXPath("*//div/a[contains(text(),'Sign out')]")[0].Click()
#      self.wait_until_page_loaded() 
#      web_utils.log_checkpoint("Successfully Logged out from Gmail Applications",500,self.page)
#    else:
#      self.log_error_message("Unable to Find 'Sign out' Option in Gmail Applicaiton") 
