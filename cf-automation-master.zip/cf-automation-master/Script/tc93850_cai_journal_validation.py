﻿import driverchain
import tc93850cai_us_journal_validation
#Author:            Sandeep Kowtha
#TestCaseID:        TC93850
#UserStoryID:       US200743
#Reviewed_By:       Syed Hussain



class driver(Driverchain):
  global classarr
  
  def __init__(self):  
    global test_env
    self.test_env="dauti" 
    self.classarr=["cai_journal_validation()"]     
    super().__init__(self.classarr)
    
    
def main():  
  cobj=driver().run()
