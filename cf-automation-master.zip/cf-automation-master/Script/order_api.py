﻿import tc_logs
from gvar import dataprep as DATAPREP
import api_utility
import order_api_payloads  

__print = tc_logs.checkpt_with_no_picture
__Error = tc_logs.error_with_no_picture
__API_POST  = api_utility.post_or_put
__API_PUT   = api_utility.put
__API_GET   = api_utility.get
__ORDER_SELLER_POST_ = order_api_payloads.post_seller_payload
__ORDER_BUYER_POST_  = order_api_payloads.post_buyer_payload


def __validate_post_response(response, action ):
    
    if 'orderNumber'  in response:
      __print(f"{action} order Number      : {response['orderNumber']}")
      __print(f"{action} order Invoice ID  : {response['orderInvoiceId']}")
      if action == 'SELLER':
        DATAPREP['seller_order'] = response['orderNumber'] 
      else:
        DATAPREP['buyer_order'] = response['orderNumber'] 
    else:
      __Error(f"Failed Message: {response['errorMessage']} ")
      

def create_order(api_name,action):
      
      if action in('SELLER'):   
        __validate_post_response(__API_POST(api_name,__ORDER_SELLER_POST_()),action) 
      elif action in('BUYER') :  
        __validate_post_response(__API_POST(api_name,__ORDER_BUYER_POST_()),action) 
      else:
         pass    
  
     
          
   
   
