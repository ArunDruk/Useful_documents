﻿import gvar

### In this method objects for below pages have been captured ###

#REPORTING > SETUP PAGE

def enable_db_analytics_checkbox():
  prop_names = ["idStr","ObjectLabel","ObjectType"]
  prop_values = ["pjtRollupEnabledFlag","Enable In Database Analytics (OLAP Cube) Based Summarization","Checkbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
