﻿from ebiz import *
import file_system_utils
import form_utils
import web_utils

###This testcase is to submit CAI COA Segments And Combination Extract for Blackline and capture logs###

class tc110832_cai_coa_segments_combinations_extract_blkn(Ebiz):

 op_log_path="C:\\TC_Logs"
 
 def login(self):
    self.login_user="mfallwell"
    super().login()
 
 def action(self,book):

# Login to Oracle EBIZ and select the CAI ALL GL BLACKLINE USER responsibility  
    Log.Message("Inside action...") 
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI ALL GL BLACKLINE USER')]")
    self.log_message_web("Click 'CAI ALL GL BLACKLINE USER' - Successful")
    Delay(3000)  
    self.page.wait() 
    self.page.EvaluateXpath("//table[@id='respList']//div[text()='Run']")[0].Click()
    self.log_message_web("Click 'Run' - Successful")
    Delay(2000)
    jFrame=self.initializeJFrame() 
    Delay(10000)
    form_utils.click_ok_btn(jFrame) 
    Delay(3000)
    
# Submitting "CAI COA Segments And Combination Extract for Blackline" Request Set using CAI ALL GL JOB SCHEDULER' responsibility
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit a New Request","ExtendedFrame"]
    submit_req_form=jFrame.FindChildEx(prop,val,30,True,60000)
    submit_req_form.FindChild("AWTComponentAccessibleName","OK alt O",10).Click()
    Delay(2000)
    jFrame.Keys("CAI COA Segments And Combination Extract for Blackline")
    jFrame.Keys("[Tab]")
    delay(1000)
    self.log_message_web("Request Set Name: 'CAI COA Segments And Combination Extract for Blackline' - populated Successfully") 
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit Request","ExtendedFrame"]
    submit_req_form=jFrame.FindChildEx(prop,val,30,True,60000)
    submit_req_form.FindChild("AWTComponentAccessibleName","Submit alt m",10).Click()
    self.log_message_web("Click Submit Successful") 
    Delay(2000)
    jFrame.Keys("~o")
    self.log_message_oracle_form(jFrame,"'CAI COA Segments And Combination Extract for Blackline' is submitted")   
    RequestID = aqConvert.VarToInt(''.join(x for x in jFrame.find("AWTComponentAccessibleName","Request submitted*",100).AWTComponentAccessibleName if x.isdigit()))
    self.log_message_oracle_form(jFrame,"Request ID Of 'CAI COA Segments And Combination Extract for Blackline' is " + aqConvert.VarToStr(RequestID))
    Delay(2000)
    jFrame.Keys("~n")
    Delay(4000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000) 
    
# Gathering Request ID and Output File for the "CAI COA Segments And Combination Extract for Blackline Program" 
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,90000)
    self.req_set_save_log(jFrame,req_form,"CAI COA Segments And Combination Extract for Blackline",RequestID)
    Delay(2000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000)
    
# Gathering Request ID and Output File for the "CAI File Encrypt Program for Sterling Program"  
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,90000)
    self.req_set_save_log(jFrame,req_form,"CAI File Encrypt Program for Sterling",RequestID)
    Delay(2000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000)

# Gathering Request ID and Output File for the "CAI: Transfer files to Sterling"  
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,90000)
    self.req_set_save_log(jFrame,req_form,"CAI:Transfer files to Sterling (CAI: Transfer files to Sterling)",RequestID)
    Delay(1000)
    fo=open(self.log_path,"r")
    lines=fo.readlines()
    Log.Enabled=True
    Log.Message("Outbound Extract Information : - "+lines[5][0:64].strip())
    Log.Message(lines[12][0:112].strip())
    Log.Message(lines[13][0:112].strip())
    Log.Message(lines[14][0:62].strip())
    Log.Message(lines[15][0:54].strip())
    Log.Message(lines[16][0:79].strip())
    Log.Message(lines[17][0:60].strip())
    Log.Message(lines[18][0:94].strip())
    Log.Message(lines[19][0:59].strip())
    Log.Message(lines[21][0:72].strip())
    Log.Message(lines[22][0:78].strip())
    Log.Message(lines[24][0:78].strip())
    Log.Message(lines[26][0:234].strip())
    Log.Message(lines[27][0:158].strip())
    Log.Message(lines[28][0:68].strip())
    Log.Message(lines[29][0:72].strip())
    Log.Enabled=False
    Delay(2000)
    jFrame.Click()
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~o")
    Delay(1000)      



 def req_set_save_log(self,jFrame,req_form,srch_child_name,Preqid):
    self.log_message_oracle_form(req_form,"Checking for "+aqConvert.VarToStr(srch_child_name)+ " Child Program Status")
    req_form.FindChild("AWTComponentAccessibleName","Refresh Data alt R",20).Click()
    i=20
    for x in range(1,180):     
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Name",i]
        child_name=req_form.Find(prop,val,10).wText 
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Phase",i+20]
        phase=req_form.Find(prop,val,10).wText 
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Request ID",i-10]
        creqid=VarToInt(req_form.Find(prop,val,10).wText)                                       
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Status",i+30]         
        status =req_form.FindChild(prop,val,60)            
        if (child_name==srch_child_name) and (creqid>=Preqid) and (phase == "Completed"):
            self.log_message_oracle_form(req_form, aqConvert.VarToStr(srch_child_name)+" Phase Completed Successfuly")                                
            status.Keys("[Enter]")
            Delay(1000)
            req_form.FindChild("AWTComponentAccessibleName","View Log alt K",20).Click()    
            Delay(4000)
            output_page=Sys.Browser("iexplore").Page("https://core*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.*")
            output_page.Click()
            Delay(2000)
            output_page.Keys("~f")
            Delay(2000)
            output_page.Keys("a")
            Delay(5000)
            file_system_utils.create_folder(self.op_log_path)             
            self.log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"File"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"_%d%b%Y_%H%M")+".txt"    
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(self.log_path)
            Delay(1000)
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
            Delay(8000)
            Log.Enabled=True
            Log.File(self.log_path, aqConvert.VarToStr(srch_child_name)+" is Completed And Log file is attached")
            Log.Enabled=False     
            web_utils.close_additional_browsers()         
            Filesaved = 'True'
            return                           
        elif i >=29:
           Delay(15000)           
           req_form.FindChild("AWTComponentAccessibleName","Refresh Data alt R",20).Click()
           Delay(3000)
           i=20
           val=["Name",i]
           child_name=req_form.Find(prop,val,10).wText
        else:  
           Delay(2000)
           i=i+1 
