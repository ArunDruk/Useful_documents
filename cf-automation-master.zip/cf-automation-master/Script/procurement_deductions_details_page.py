﻿import gvar

### In this method objects for below pages have been captured ###

#PROCUREMENT > DEDUCTION > Procurement Deductions Page

################################# Deduction Details Section #################################################


def procurment_deductions_link():
  classifications = gvar.dataprep['page'].NativeWebObject.Find("contentText","Procurement: Deductions","A")
  return classifications


def deductions_number_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["DeductionReqNumber","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def deduction_date_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["DeductionHeaderDate","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def supplier_name_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["SupplierName","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def supplier_site_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["SupplierSite","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def change_doc_number_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["ChangeDocumentNumber","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def po_number_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["PurchaseOrderNumber","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def deductionheaderdesc_dropdown():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["DeductionHeaderDesc","Textarea"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def debit_memo_no_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["DebitMemoNumber","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def debit_memo_dt_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["DebitMemoDate","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,2000)


def rate_type_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["RateTyp","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,2000)

  
def rate_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["Rate","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,2000)



################################# Deduction Transactions Section #################################################


def delete_button():
  prop_names = ["contentText","idStr","ObjectType"]
  prop_values = ["Delete","RemoveBtn","Button"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def task_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["TransLinesTblRN:Task:0","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def expenditure_type_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["TransLinesTblRN:ExpendType:0","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def expenditure_org_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["TransLinesTblRN:ExpendOrg:0","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def expenditure_item_dt_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["TransLinesTblRN:ExpendDate:0","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def prj_func_deduction_amt_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["TransLinesTblRN:Amount:0","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def deductions_trx_desc_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["TransLinesTblRN:Description:0","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def select_checkbox():
  select_checkbox = Sys.Browser("iexplore").Page("*").Panel("oafOraBodyContainer").Form("DefaultFormName").Panel("oafcontent").Panel(0).Panel("oafusercontent").Panel(0).Panel("p_SwanPageLayout").Panel(0).Panel(1).Table("DeductionLines").Cell(3, 0).Table(0).Cell(0, 0).Panel(0).Panel(0).Table("DeductionLines1").Cell(3, 0).Table(0).Cell(0, 0).Panel(0).Panel(0).Panel("TransLinesTblRN").Panel("TransLinesTblRN").Panel("TransLinesTblRN").Panel("TransLinesTblRN_3").Table("Content").Cell(0, 0).Checkbox(0)
  return select_checkbox
  

def cancel_button():
  prop_names = ["contentText","idStr","ObjectType"]
  prop_values = ["Cancel","HCancel","Button"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def save_button():
  prop_names = ["contentText","idStr","ObjectType"]
  prop_values = ["Save","HSave","Button"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def submit_button():
  prop_names = ["contentText","idStr","ObjectType"]
  prop_values = ["Submit","HSubmit","Button"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)




