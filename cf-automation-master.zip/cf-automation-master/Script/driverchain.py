﻿#from cai_approve_non_catalog_req import *
#from cai_create_manual_ap_invoice_match import *
#from cai_create_manual_ap_invoice_no_match import *
#from  cai_create_non_catalog_req import *


class Driverchain:
  global chain
 
  def __init__(self,obj):
      self.chain=obj
     
  def run(self):
    for x in self.chain:
      comp_name=x[:-2]     
      mod = __import__(comp_name)
      obj=getattr(mod,comp_name)
      instance=obj(self.test_env,self.oper_unit,comp_name).execute(self.book)
            
  def prep_test(self):
       wscript=Sys.OleObject["WScript.Shell"]
       wscript.Run("taskkill.exe /F /IM iexplore.exe /T")  
       wscript.Run("taskkill.exe /F /IM jp2launcher.exe /T")
       wscript.Run("taskkill.exe /F /IM EXCEL.exe /T") 
       Delay(1000)
       
  def close_excel(self):      
    self.book.save()
    delay(1000)
    self.book.close()



