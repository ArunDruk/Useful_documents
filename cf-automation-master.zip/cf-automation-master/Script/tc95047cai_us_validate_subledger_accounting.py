﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils
import web_utils

#This testcase is to validate subledger accounting

class tc95047cai_us_validate_subledger_accounting(Ebiz):
 global rowno, app
 
 rowno = 2
 op_log_path="C:\\TC_Logs"
 def login(self):
    self.login_user="rmaran"
    super().login()
    
 
 def action(self,book):
    app = book.Sheets.item["Invoice"]
    self.wait_until_page_loaded()
    Log.Message("Inside action...")
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" AP INVOICE PROCESSING')]")
    self.log_message_web("Click 'CAI "+self.oper_unit+" AP INVOICE PROCESSING' - Successful")
    Delay(1000)
    self.wait_until_page_loaded() 
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Invoices')]")
    self.log_message_web("Click 'Invoices' - Successful") 
    Delay(1000)
    self.wait_until_page_loaded()
    Delay(1000)  
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Entry')]")
    self.log_message_web("Click 'Entry' - Successful") 
    Delay(1000)
    self.wait_until_page_loaded()
    self.page.EvaluateXPath("//div[text()='Invoices']")[1].Click()
    self.log_message_web("Click 'Invoices' - Successful")
    delay(5000)
    web_utils.validate_security_box()
    delay(10000)
    jFrame = self.initializeJFrame()
    Delay(5000)
    form_utils.click_ok_btn(jFrame)
    p_names = ("JavaClassName","AWTComponentAccessibleName")
    p_values = ("ExtendedFrame","Invoice Workbench (CAI "+self.oper_unit+" AP INVOICE PROCESSING)")
    inv_form=jFrame.FindChildEx(p_names,p_values,60,True,120000)
    Delay(2000)
#    tool_bar_v = Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWMenuBar", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWMenu", "View mnemonic V", 2)
#    Delay(1000)
#    tool_bar_v.Click()
#    Delay(1000)
#    tool_bar_v.Keys("f") 
#    delay(3000)

    jFrame.Keys("~v")
    delay(2000)
    jFrame.Keys("f")
    delay(2000)
    
    self.log_message_oracle_form(jFrame,"Navigate to Find Invoices Form")
    p_names = ("JavaClassName","AWTComponentAccessibleName")
    p_values = ("ExtendedFrame","Find Invoices")
    find_inv_form=jFrame.FindChildEx(p_names,p_values,40,True,7000)      
    if find_inv_form.Exists:
      self.log_checkpoint_message_web("Find Invoices Form Launched Successfully")
    else:
      self.log_message_oracle_form(jFrame,"Unable to Launch Find Invoices Form") 
    Delay(1000)    
      
    pro = ("AWTComponentIndex","AWTComponentAccessibleName")
    values = (6,"Invoice: Number") 
    Delay(1000)      
    find_inv_form.FindChild(pro,values,20).Click()
    delay(1000)
    find_inv_form.FindChild(pro,values,20).SetText(app.Cells.Item[rowno,13])
    Delay(1000)
    values = (3,"Find alt i")
    Delay(1000)
    find_inv_form.FindChild(pro,values,20).Click()
    Delay(8000)  
    
 #Finding Invoice 
#    prop=["AWTComponentAccessibleName","JavaClassName"]
#    val=["Find Invoices","ExtendedFrame"]
#    par_form=jFrame.FindChild(prop,val,30)
#    par_form.Find("AWTComponentAccessibleName","Invoice: Number",10).Click()
#    par_form.Find("AWTComponentAccessibleName","Invoice: Number",10).Keys(app.Cells.Item[rowno,13])
##    jFrame.Keys("[Tab]")
##    jFrame.Keys("[Tab]")
##    jFrame.Keys("[Tab]")
##    jFrame.Keys("[Tab]")
##    jFrame.Keys("[Tab]")
##    jFrame.Keys("[Tab]")
##    jFrame.Keys("[Tab]")
##    jFrame.Keys("[Tab]")
##    jFrame.Keys("[Tab]")
##    jFrame.Keys(aqConvert.DateTimeToFormatStr(aqDateTime.Today(),"%d-%b-%Y"))
##    jFrame.Keys("[Tab]")
##    jFrame.Keys(aqConvert.DateTimeToFormatStr(aqDateTime.Today(),"%d-%b-%Y"))
#    par_form.Find("AWTComponentAccessibleName","Invoice: Dates: StartList of Values",10).SetText(aqConvert.DateTimeToFormatStr(aqDateTime.Today(),"%d-%b-%Y"))
#    par_form.Keys("[Tab]")
#    par_form.Find("AWTComponentAccessibleName","Invoice: Dates: EndList of Values",10).SetText(aqConvert.DateTimeToFormatStr(aqDateTime.Today(),"%d-%b-%Y"))
#    delay(1000) 
##    jFrame.Keys("~i")
#    par_form.FindChild("AWTComponentAccessibleName","Find alt i",10).Click()
    Delay(6000)
    p_names = ("JavaClassName","AWTComponentAccessibleName")
    p_values = ("ExtendedFrame","Invoice Workbench (CAI "+self.oper_unit+" AP INVOICE PROCESSING)")
    inv_wb_form=jFrame.FindChildEx(p_names,p_values,40,True,80000) 
        
#    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#    val=["Status",4]
#    status=inv_wb_form.FindChild(prop,val,60)
#    Log.Enabled=True
#    aqObject.CheckProperty(status,"wText",cmpIn,"Validated")
#    Log.Enabled=False
#    self.log_message_oracle_form(jFrame,"Invoice Is Validated")
       
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Accounted",5]
    acc_status=inv_wb_form.FindChild(prop,val,60)
    Log.Enabled=True
    aqObject.CheckProperty(acc_status,"wText",cmpIn,"Yes")
    Log.Enabled=False
    self.log_message_oracle_form(jFrame,"Invoice Accounted Successful")
   
 # View Subledger Accounting Entries    
    delay(1000)
    self.log_message_oracle_form(jFrame,"Query DataBase to Retrieve the SLA Details for the Invoice:")
#####    jFrame.Keys("~t")
#####    delay(1000)
#####    jFrame.Keys("[Down]")
#####    delay(1000)
#####    jFrame.Keys("[Enter]")
#####    Delay(5000)   
#####    if not Sys.Browser("iexplore").Page("https://core*epfinnp.coxautoinc.com/OA_HTML/RF.jsp?function_id=*").Exists:
######      self.relogin()
#####      Delay(5000)
#####      
#####    acc_events_page=Sys.Browser("iexplore").Page("https://core*epfinnp.coxautoinc.com/OA_HTML/RF.jsp?function_id=*")
#####    
#####    acc_events_page.Click()
#####    delay(6000)    
######    web_utils.wait_until_page_loaded(acc_events_page)
#####    acc_events_page.Find("contentText","View Journal Entries",30).Click()
#####    delay(5000)
######    web_utils.wait_until_page_loaded(acc_events_page)
#####    acc_events_page.Keys("~f")
#####    Delay(1000)
#####    acc_events_page.Keys("a")
#####    Delay(6000)  
#####    web_utils.handle_webpage_save_popup()
#####    Delay(3000)
#####    file_system_utils.create_folder(self.op_log_path)             
#####    log_path=self.op_log_path+"\\Subledger Journal Entry Output_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".html"   
#####    Delay(1000) 
#####    Sys.Browser("iexplore",2).Window("#32770", "Save Webpage", 1).FindChild("WndClass","Edit",20).SetText(log_path)
######    Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)    
#####    Delay(1000)
#####    Sys.Browser("iexplore",2).Window("#32770", "Save Webpage", 1).Keys("[Enter]")
#####    Delay(5000)
#####    Log.Enabled=True
#####    Log.File(log_path,"Subledger Journal Entry Output Page Is Attached")
#####    Log.Enabled=False        
#####    Delay(1000)
#####    prop = ("ColumnIndex","ObjectType")
#####    val = ("1","Cell")
#####    acc_events_page=Sys.Browser("iexplore").Page("https://core*epfinnp.coxautoinc.com/OA_HTML/OA.jsp?page=*")
#####    acc_events_page.Find(prop,val,30).Click()
#####    Delay(1000)
######    prop1 = ("contentText","ObjectType")
######    val1 = ("Next 10","Link")
######    acc_events_page=Sys.Browser("iexplore").Page("https://core-stage.epfinnp.coxautoinc.com/OA_HTML/OA.jsp?page=*")
######    acc_events_page.Find(prop1,val1,30).Click()
######    Delay(3000)
######    prop2 = ("ColumnIndex","ObjectType")
######    val2 = ("1","Cell")
######    acc_events_page=Sys.Browser("iexplore").Page("https://core-stage.epfinnp.coxautoinc.com/OA_HTML/OA.jsp?page=*")
######    acc_events_page.Find(prop2,val2,30).Click()
######    self.log_message_web("Subledger Journal Entry Output Page2 Is Attached")
#####    acc_events_page.Close() 
#####    web_utils.close_additional_browsers()
#####    Delay(1000)
#####    jFrame.Click()
    Delay(1000)
    dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
    user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
    pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
    inv_num = VarToStr(app.Cells.Item[rowno,13])
    dbhelper.verify_subledger_accting_information(dsn,user_id,pwd,inv_num)
    jFrame.Click()
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~o")
    Delay(1000)
#    Sys.Browser("iexplore").page("https://core-*.epfinnp.coxautoinc.com/forms/frmservlet*").Close()
    del app,jFrame,prop,val,dsn,user_id,inv_num

 def relogin(self):
      page = Sys.Browser("iexplore").page("https://core*epfinnp.coxautoinc.com/OA_HTML/AppsLocalLogin.jsp?*")
      try:                
        page.WaitProperty(self.config['login']['propname'],self.config['login']['propval'],60)
        page.Find(self.config['login']['propname'],self.config['login']['propval'],60).setText("pburugupal")
        self.log_message_web("Set User ID for Re - Login: pburugupal- Successful")       
        page.Keys("[Tab]")                
        page.Find(self.config['password']['propname'],self.config['password']['propval'],60).setText(self.testConfig['ebiz']['password']) 
        self.log_message_web("Set Password:  Successful")       
        page.Find(self.config['login_btn']['propname'],self.config['login_btn']['propval'],60).Click() 
        Delay(2000)        
        page.wait()       
      except Exception as e:
        Log.Enabled=True
        Log.Message("Caught Net:ReadTimeout Error " + e) 
        Log.Error(traceback.format_exc())    
        Log.Enabled=False                     
      self.page.Wait()
      

def sample():
  Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).FindChild("WndClass","Edit",20).SetText("sm")
