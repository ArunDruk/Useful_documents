﻿import web_utils

def main():
   Log.Message('test', 'test', pmHigher, "")
   web_utils.validate_security_box()