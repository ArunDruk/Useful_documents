﻿from gvar import dataprep as DATAPREP
import gvar 
from ebiz import *
import auto_invoice_request_set_by_customer
import database_service as MYSQL
import odm_datatype 
from odm_datatype import GENERAL_5M_DATA_SF  as GENERAL_5M_DATA_SF 
import traceback 
import tc_logs
import test_utility
import consignment_api 
from  dealers import Dealer  
import order_api 
import receipts_api
import receipts_api_queries
import Inv_api_response_validation
from payment_methods import paym_method_api_post
import auto_invoice_program_submission
import adjustments_api 
from adjustment_queries import get_asset_information as ASSET_INFO
from transaction import get_transaction_line_details_picture as GETTRXDETAIL
from buyer_lines_close_by_auction import closure as run_buyer_ordine_line_closure



class tc207316_bw_ai_man_arbitration(Ebiz):
  
  def login(self):
   self.login_user='snimma'
   super().login()

  def goto_url(self,url):
   super().goto_url(self.testConfig['ebiz']['oci_is_url'])
     
  def load_test_data(self,exclude_vin,count):
      self.__HEAD("****** CREATING SALES ORDERS *******")
      DATAPREP['env'] = BuiltIn.ParamStr(14)
      DATAPREP['auction'] = BuiltIn.ParamStr(15)
#      DATAPREP['env'] = "oci_stage"
#      DATAPREP['auction'] = "PSM1"
      self.__LOAD_ENV()
      if count == 0:
        run_buyer_ordine_line_closure()
      self.LOAD_TEST_DATA(GENERAL_5M_DATA_SF,exclude_vin)
      
  def logout(self):
    pass
    
  def end_of_test_case(self):
     self.UPDATE_TEST_DATA_STATUS('Completed')
      
  def validate_workflow(self):
    count = 0
    flag = MYSQL.validate_wrkflw_adj_buyer()
    while flag != "YES":
      delay(10000)
      flag = MYSQL.validate_wrkflw_adj_buyer()
      count+=1
      if count > 5:
        self.log_error_message("Arbitration Workflow is not Complete.......")
    tc_logs.checkpt_with_no_picture("Arbitration Workflow Completed Successfully")
    
  def validate_order_interface(self,val):
    for order_type in (gvar.dataprep['seller_order'],gvar.dataprep['buyer_order']):  
      interface_line_id = MYSQL.validate_ar_interface(order_type)   
      if (GetVarType(interface_line_id)!= VarToInt(0)and VarToInt(1)):
        self.__PRINT("Interface Line Id for Order No: "+order_type)     
        val = val+1
        
      else:
        tc_logs.checkpt_with_no_picture("Order No: "+order_type+" not available in ra interface")
#        self.log_error_message("Order No: "+order_type+" not available in ra interface")
    if val < 2:
      odm_datatype.update_status("Passed")
    return val
        
  def action(self,book):
    self.__HEAD = tc_logs.header_name  
    self.__TNAME = tc_logs.test_name
    self.__ERROR = tc_logs.error_with_no_picture
    self.LOAD_TEST_DATA = odm_datatype.load_test_data
    self.__LOAD_ENV =    gvar.load_environment_files
    self.UPDATE_TEST_DATA_STATUS = odm_datatype.update_status
    self.CREATE_CONSIGNMENT = consignment_api.create_consignment_id
    self.CREATE_ORDER  = order_api.create_order
    self.POST_ACH_PAYMENT = receipts_api.receipt_api_ach_post
    self.__PRINT = tc_logs.checkpt_with_no_picture  
    self.__FIRE_ADJ_API     = adjustments_api.fire_payload
    self.__FIRE_INV_API     = Inv_api_response_validation.verify_arb_status
    self.__FIRE_INV_API_TRX     =  Inv_api_response_validation.get_buyer_arb_trx_details
    self.__ADJ_PARAMETERS =[['adjustment_api_SFDC','buyer_call_without_adj','Buyer Withdrew','Auction Inherit']]
    app = book.Sheets.item["asset_creation"]
    tc_logs.checkpt_with_no_picture("Loading Test Data for 5M Dealer")
    
    count = 0
    ref = 0
    val = 0
    exclude_vin = []
    while val!=2: 
#      if len(exclude_vin) > 0:
##        exclude_vin = ','.join( [ "'{0}'" .format(vin)  for vin in list(map(str,exclude_vin)) ] )
#        exclude_vin = ','.join(["'{0}'".format(vin) for vin in exclude_vin])
      self.load_test_data(exclude_vin,count)     
      exclude_vin.append(gvar.dataprep['vin'])
      gvar.dataprep['floor_ag'] = "GDM"
      delay(10000)
      val = self.validate_order_interface(ref)
      count = count+1
      if count > 5:
        self.log_error_message("Tried "+VarToStr(count)+" unique test data from ODM;either Buyer/Seller Order is not available in RA_INTERFACE_ALL table...Failing Test Execution")
#        tc_logs.checkpt_with_no_picture("Tried "+VarToStr(count)+" unique test data from ODM;either Buyer/Seller Order is not available in RA_INTERFACE_ALL table..Fetching invoice directly for the spec.")
#        gvar.dataprep['seller_invoice'] == 'Y'
#        gvar.dataprep['invoice'] == 'Y'
#        exclude_vin = []
#        self.load_test_data(exclude_vin)
    if gvar.dataprep['env'] == 'oci_stage':
       self.goto_url("https://manheim-stage.epfinnp.coxautoinc.com/OA_HTML/AppsLocalLogin.jsp")
    elif gvar.dataprep['env'] == 'oci_test':
       self.goto_url("https://manheim-test.epfinnp.coxautoinc.com/OA_HTML/AppsLocalLogin.jsp")
    self.login()
    auto_invoice_program_submission.auto_invoice_concurrent_submission()
    gvar.dataprep['custom_head'] = "Adjustment API Initiation call"
    self.__FIRE_ADJ_API('adjustment_api_SFDC','initiate_call')
    for params in self.__ADJ_PARAMETERS:
      type = {'b' : 'Buyer','s': 'Seller'}[params[1][0]]  
      gvar.dataprep['custom_head'] = f"Adjustment API {type} call"
      self.__FIRE_ADJ_API(*params)
    self.__PRINT(" *** Waiting for workflow to complete *** ")
    self.validate_workflow()
    Asset_Number, Description =  MYSQL.return_asset_no_for_vin(gvar.dataprep['vin'])
    tc_logs.checkpt_with_no_picture(f"Asset Number Generated for VIN: {gvar.dataprep['vin']} - {Asset_Number}")
    app.Cells.Item[2,1] = Description
    app.Cells.Item[2,2] = Asset_Number
    self.end_of_test_case()

    
    
#def main():
#  obj =  tc207316_bw_ai_man_arbitration()
#  obj.action()    


      
