﻿from ebiz import *
import web_utils
import form_utils
import dbhelper
import file_system_utils


class tc155297_cai_us_excel_import_invoices_approval_completion(Ebiz):

 op_log_path ="C:\\TC_Logs"

 def login(self):
   self.login_user='rmaran'
   super().login()
   
 def action(self,book): 
    rowno=2 
    app = book.Sheets.item["Invoice"]
    self.log_checkpoint_message_web("Login Successful")
   # self.page.EvaluateXPath("//a[@id='AppsNavLink' and contains(text(),'Workflow User Web (New)')]")[0].Click()
#   self.page.Wait()
#   self.page.Find("idStr","N61",30).Click()
#   self.page.Wait()

    self.page.EvaluateXPath("//button[@id='NtfFullList']")[0].Click()
    self.page.wait()
    self.log_message_web("Click FullList Successful")
    Delay(5000)
    table_obj=self.page.EvaluateXPath("//table[@id='NtfWorklist:Content']")[0]    
    tot_rows=table_obj.RowCount
    
#    self.log_message_web("Total Number Of Open Notifications : " + VarToStr(tot_rows) )
    inv_num=app.Cells.Item[2,13]
    Delay(3000)
   
#    for i in range(0,VarToInt(tot_rows)-1):
    for i in range(0,VarToInt(tot_rows)):
#      subject=subject=table_obj.FindChild("name","Cell("+aqConvert.VarToStr(i)+",3)",12).contentText
      subject=table_obj.FindChild("name","Cell("+aqConvert.VarToStr(i)+",3)",12).contentText
      Delay(3000)
      Subject_message=subject.split(" ",7)[2][0:8]
      Subject_inv_num=subject.split(" ",7)[3][0:18]
      if (Subject_message=='Invoice') and (aqConvert.VarToStr(Subject_inv_num) == aqConvert.VarToStr(inv_num)):
        self.log_message_web("Invoice Approval Notification: "+ subject)
        self.page.Find("idStr","N*:NtfSubject:"+aqConvert.VarToStr(i),30).Click()
#        self.page.Fine("idStr","N24:NtfSubject:0",30).Click()
        Delay(7000)
        self.log_message_web("Found Invoice Which Requires Approval : " + VarToStr(Subject_inv_num) + " ; Click Approve next")
        Delay(5000)
        self.page.EvaluateXPath("//button[@title='Approve']")[0].Click()
        self.page.wait()
        break
