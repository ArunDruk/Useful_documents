﻿import gvar

### In this method objects for below pages have been captured ###

#PROJECT > SETUP > TEAM MEMBERS link page

def prj_setup_add_teammembers_button():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["AddProjectMembers","Button"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def prj_setup_teammembers_go_button():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["Go","Button"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def prj_setup_teammembers_currmembrs_radiobutton():
  prop_names = ["idStr","ObjectType","ObjectLabel"]
  prop_values = ["M__Ida","RadioButton","Current Members"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def prj_setup_teammembers_rettosetup_link():
  return_to_setup_link = gvar.dataprep['page'].NativeWebObject.Find("contentText","Return to Setup","A")
  return return_to_setup_link

