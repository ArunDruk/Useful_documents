﻿import gvar
import database_service as MYSQL
import tc_logs     
import traceback    
                                                
MEGADEALER_SF = 'MEGADEALER_SF'  
FISERV_SF = 'FISERV_SF'  
GENERAL_5M_DATA_SF = 'GENERAL_5M_DATA_SF' 
NG_SELLER_ORDER_SF = 'NG_SELLER_ORDER_SF'
PUBL_7M_ORDERS = 'PUBL_7M_ORDERS'
PSI_FAIL_ORDERS = 'PSI_FAIL_ORDERS' 
GET_PAYMENT_QUERY = 'GET_PAYMENT_QUERY'
GET_VIN_FOR_RMS   = 'GET_VIN_FOR_RMS'
GET_FLR_KJK_PAID_INV  = 'GET_FLR_KJK_PAID_INV'
FLR_AGNCY_NEXTGEAR = 'FLR_AGNCY_NEXTGEAR'
GET_MBC_CONSIGNOR_DATA = 'GET_MBC_CONSIGNOR_DATA'
GET_BOA_FLR_DATA  = 'GET_BOA_FLR_DATA'
GET_GMAC_FLR_DATA = 'GET_GMAC_FLR_DATA'
GET_RMS_DATA      = 'GET_RMS_DATA'
GET_TC115500_DATA = 'GET_TC115500_DATA' 
GET_DL_SHIELD_VEH_SRVC_DATA = 'GET_DL_SHIELD_VEH_SRVC_DATA'
GET_RELI_WITH_HOLD_DATA = 'GET_RELI_WITH_HOLD_DATA'
GET_PAID_BOA_AGENCY_WITH_PSI = 'GET_PAID_BOA_AGENCY_WITH_PSI'
GET_PAID_BOA_AGENCY_WITH_DS  ='GET_PAID_BOA_AGENCY_WITH_DS'
GET_FLR_KJK_ADV_AGENCY_INV  = 'KJK_FLR_PLN_ADV_AGCY_DATA'


DB_KEYS = []
_PRINT = tc_logs.checkpt_with_no_picture
__ERROR = tc_logs.error_with_no_picture

def load_test_data(data_type,exclude_vin):   
                                                                 
 try:
   def load_gvar(**kwargs):
      global DB_KEYS
      DB_KEYS = list(kwargs.keys()) 
      gvar.db_store(kwargs)
   sql = fetch_query(data_type)
   if  len(exclude_vin)== 0:
     sql += f"ORDER BY MODIFIED DESC LIMIT 1"
   else:
     exclude_vin = ','.join(["'{0}'".format(vin) for vin in exclude_vin])
     sql += f"and vin not in ({exclude_vin}) ORDER BY MODIFIED DESC LIMIT 1"
   rows = MYSQL.query_mysql(sql)
   if len(rows)==1:
     [ load_gvar(**row) for row in rows]
     update_status("Executing")
     _PRINT(f" Test VIN: {gvar.dataprep['vin']}")  
     _PRINT(f" Test consignment_ID: {gvar.dataprep['consignment_id']}")  
     _PRINT(f" Seller Order: {gvar.dataprep['seller_order']}")
     _PRINT(f" Buyer Order: {gvar.dataprep['buyer_order']}")
   else:
     _ERROR(f"No data found for datatype: {data_type}")
 except:
   __ERROR(traceback.format_exc()) 
   
def fetch_query(data_type):
  if not 'veh_sts' in gvar.dataprep: 
       gvar.dataprep['veh_sts'] = 'SF'
  return {
  'MEGADEALER_SF'       : get_mega_dealer_qry_for_sf        ,
  'FISERV_SF'           : get_fiserv_query_for_sf           ,
  'GENERAL_5M_DATA_SF'  : get_5M_orders_query_for_sf        ,
  'NG_SELLER_ORDER_SF'  : get_nextgear_orders_query_for_sf  ,
  'PUBL_7M_ORDERS'      : get_PUBL_7M_orders_query          ,
  'PSI_FAIL_ORDERS'     : get_psi_fail_order_query          ,
  'GET_PAYMENT_QUERY'   : get_payment_query                 ,
  'GET_VIN_FOR_RMS'     : get_rms_vin                       ,
  'GET_FLR_KJK_PAID_INV': get_flr_kjk_paid_inv              ,
  'GET_BOA_FLR_DATA'    : get_boa_flr_order_query           ,
  'GET_GMAC_FLR_DATA'   : get_gmac_flr_order_query          , 
  'GET_RMS_DATA'        : get_rms_data                      ,
  'GET_TC115500_DATA'   : get_TC115500_data                 ,
  'GET_DL_SHIELD_VEH_SRVC_DATA':get_dl_shield_veh_srvc_data , 
  'GET_RELI_WITH_HOLD_DATA' : get_reli_with_hold_data       , 
  'GET_PAID_BOA_AGENCY_WITH_PSI' :get_psi_boa_floor_data    ,
  'GET_PAID_BOA_AGENCY_WITH_DS' :get_psi_boa_paid_ds_data   , 
  'KJK_FLR_PLN_ADV_AGCY_DATA' : get_kjk_adv_agncy_data 
        }[data_type]()

def get_qry(testresult = None):
  if testresult is None:
     testresult = 'Passed'
  return f"""SELECT * FROM odm.global 
            WHERE system = '{gvar.config['ebiz']['system']}' 
             and test_result = '{testresult}' 
            and auction = '{gvar.dataprep['auction']}' 
            and vehicle_status = '{gvar.dataprep['veh_sts']}'"""
            
def invoice(sql):        
      if ( ('invoice' in gvar.dataprep) and 
            (gvar.dataprep['invoice'] == 'Y')): 
          sql += f""" and invoice = 'Y' """ 
      elif ( ('seller_invoice' in gvar.dataprep) and 
            (gvar.dataprep['seller_invoice'] == 'Y')): 
          sql += f""" and seller_invoice = 'Y' """ 
#      elif( ('seller_invoice','invoice' in gvar.dataprep) and 
#            ((gvar.dataprep['seller_invoice'] == 'Y')and (gvar.dataprep['invoice'] == 'Y'))): 
#          sql += f""" and invoice = 'Y' and seller_invoice = 'Y' """ 
      else:         
        sql += f""" and invoice = 'N'
                    and seller_invoice = 'N' """     
#      sql +=  " ORDER BY MODIFIED DESC LIMIT 1"
      return sql  


def update_status(status):
     global DB_KEYS
     exclude_keys = ['test_result', 'modified', 'created_on']
     sql = """UPDATE odm.global SET test_result="{}", """.format(status)
     sql += ",".join([f""" {str(key).strip()} = "{str(item).strip()}" """  
              for key, item in gvar.dataprep.items()
              if ( (key in DB_KEYS) 
                   and (key not in exclude_keys ) 
                   and (item is not None and not item == "")) ]
                    ) + f""" WHERE id = {gvar.dataprep['id']} """
     MYSQL.update_delete_mysql(sql)
     
def get_rms_vin():
  sql = f""" select * from odm.global where seller_order is null 
            and buyer_order is null and vehicle_status is null 
            and sblu is not null 
            and system = '{gvar.config['ebiz']['system']}' 
            and auction = '{gvar.dataprep['auction']}'  
            and test_result is null """
  return invoice(sql)
                 
def get_mega_dealer_qry_for_sf():
   return invoice(
   get_qry()+f""" and spec_name = 'MegaDealerOrderCreation'""")
   
def get_nextgear_orders_query_for_sf():
     return invoice(
      get_qry()+f""" and spec_name = 'NgSlrOrdCreation'""")
      
def get_fiserv_query_for_sf():
    return invoice(
      get_qry()+f""" and spec_name = 'FiservOrderCreation'""")
      
def get_5M_orders_query_for_sf():
   spec_name = {'SF':'dlrordercreation', 
        'SS':'DlrOrderCreationForSS'}[gvar.dataprep['veh_sts']]
   return invoice(
      get_qry()+f""" and spec_name = '{spec_name}' """)  
               
def get_nextgear_orders_query():
    return invoice(
      get_qry()+f""" and spec_name = 'ng_order_creation'""") 
       
def get_PUBL_7M_orders_query():
   return invoice(
      get_qry()+f""" and spec_name = 'Create_7M_PUBL_Data'""")
      
def get_psi_fail_order_query():
   return invoice(
   get_qry()+f""" and spec_name = 'DlrOrderCreation_with_psi_fail'""")

def get_boa_flr_order_query():
   return invoice(
   get_qry()+f""" and spec_name = 'BOA_FLR_PLN_ADV_AGCY_DATA' """)

def get_gmac_flr_order_query():
   return invoice(
   get_qry()+f""" and spec_name = 'GMAC_FLR_PLN_ADV_AGCY_DATA' """)

def get_payment_query():
   sql = get_qry()+f""" and seller_order is not null
            and buyer_order is not null """
   return invoice(sql)
   
def get_flr_kjk_paid_inv():
   return invoice(
   get_qry('Completed')+f""" and spec_name = 'FLR_5M_KJK_PAYMENT' and paid = 'Y' """)

def get_rms_data():
   return invoice(
   get_qry('Completed')+f""" and spec_name = 'CREATE_RMS_ORDER' and paid = 'Y' """)
   
def get_TC115500_data():
   return invoice(
   get_qry('Completed')+f""" and spec_name = 'TC115500_RUN_AUTOINVOICE_RS' """)
   
def get_dl_shield_veh_srvc_data():
   return invoice(
   get_qry('Completed')+f""" and spec_name = 'CREATE ASSURANCE ORDER' """)
   
def get_reli_with_hold_data():      
    return invoice(
       get_qry('Completed')+f""" and spec_name = 'PAID_RELI_AGENCY_WITH_HOLD' """)

def get_psi_boa_floor_data():      
    return invoice(
       get_qry('Completed')+f""" and spec_name = 'PAID_BOA_AGENCY_WITH_PSI' and paid = 'Y'  """)

def get_psi_boa_paid_ds_data():
   return invoice(
     get_qry('Completed')+f""" and spec_name = 'PAID_BOA_AGENCY_WITH_DS' and paid='Y' """)

def get_kjk_adv_agncy_data():
   return invoice(
             get_qry()+f""" and spec_name = 'KJK_FLR_PLN_ADV_AGCY_DATA' """)

    
def tes():
  exclude_vin = ['5TFHW5F10CX273872','5TFHW5F10CX273872']
  exclude_vin = (','.join(["'{0}'".format(vin) for vin in exclude_vin]))
  
  exclude_vin = ','.join(["'{0}'".format(vin) for vin in exclude_vin])
