﻿from gvar import dataprep as DATAPREP 
import tc_logs
from date_functions import __get_current_time_stampe_with_timezone 
from date_functions import __get_current_date_YYYY_MM_DD
from date_functions import __get_current_date_MM_DD
import random
 

def arb_initiate_call(case_status = None, disposition_code = None):
 return  {
            "consignmentId": DATAPREP['consignment_id'],
            "customerType": "",
            "sourceReferenceId": DATAPREP['consignment_id'],
            "dateTime": __get_current_time_stampe_with_timezone(),
            "caseStatus": "Initiated",
            "caseDisposition": "",
            "coxLocation": DATAPREP['auction'],
            "overrideFloorplanPayment": False,
            "processSecondaryAdjustment":False,
            "sourceSystem":"SalesForce ACMS"
        }
        
def arb_seller_call_without_adjustments(case_status, disposition_code):
 return {
          "consignmentId": DATAPREP['consignment_id'],
          "customerType": "SELLER",
          "sourceReferenceId": DATAPREP['consignment_id'],
          "dateTime": __get_current_date_YYYY_MM_DD(),
          "caseStatus": case_status,
          "caseDisposition": disposition_code,
          "sellerPriceAdjustAmount": None,
          "sellerExpenseLine": [],
          "coxLocation": DATAPREP['auction'],
          "coxExpenseLine": [],
          "assetExpenseResponsibleDept": "Auction CR",
          "assetExpenseType": "Policy Loss",
          "assetNotes": "test_123",
          "vehicleReturnSellerAccountNumber": None,
          "vehicleReturnLocationCode": None,
          "sourceSystem": "SalesForce ACMS"
        }

def arb_buyer_call_without_adjustments(case_status, disposition_code):
  return {
           "consignmentId": DATAPREP['consignment_id'],
           "customerType": "BUYER",
           "sourceReferenceId": DATAPREP['consignment_id'],
           "dateTime": __get_current_date_YYYY_MM_DD(),
           "caseStatus": case_status,
           "caseDisposition": disposition_code,
           "sellerPriceAdjustAmount": None,
           "sellerExpenseLine": [],
           "coxLocation": DATAPREP['auction'],
           "coxExpenseLine": [],
           "assetExpenseResponsibleDept": "Auction CR",
           "assetExpenseType": "Policy Loss",
           "assetNotes": "test_123",
           "vehicleReturnSellerAccountNumber": None,
           "vehicleReturnLocationCode": None,
           "sourceSystem": "SalesForce ACMS"
         }

def arb_buyer_call_with_adjustments(case_status, disposition_code):
  return {
  "consignmentId": DATAPREP['consignment_id'],
  "customerType": "BUYER", #Depends on Arbitration Case Status.
  "sourceReferenceId": DATAPREP['consignment_id'],
  "dateTime": __get_current_date_YYYY_MM_DD(),
  "caseStatus": case_status, #--1st Call– Initiated-2nd Call – Buyer Withdrew/Buyer Bought
  "caseDisposition": disposition_code,#--1st Call – blank-2nd Call – Seller Buyback/Auction Inherit                               
  "sellerPriceAdjustAmount": -1 *DATAPREP['sellerPriceAdjustAmount'],
  "sellerExpenseLine":[
          { "sellerExpenseAmount": -1 * DATAPREP['sellerExpenseAmount'],
            "sellerExpenseDescription":"Transportation"}
          ],#-if not giving seller adjustment just provide, "sellerExpenseLine":[]
  "coxLocation": DATAPREP['auction'],
  "coxExpenseLine": [
   {
      "coxExpenseDescription": "Recon",
      "coxExpenseRespDept": "Auction Management",
      "coxExpenseType": "Goodwill",
      "coxExpenseAmount": -round(random.uniform(10.0,300.9),2)
    }
  ],
  "overrideFloorplanPayment": False,
  "assetExpenseResponsibleDept": "Auction CR",
  "assetExpenseType": "Policy Loss",
  "assetNotes": "test_123",
  "vehicleReturnSellerAccountNumber": None,
  "vehicleReturnLocationCode": None,
  "sourceSystem": "SalesForce ACMS"
}              

def arb_buyer_call_with_non_adjustments(case_status, disposition_code):
  return {
  "consignmentId": DATAPREP['consignment_id'],
  "customerType": "BUYER", #Depends on Arbitration Case Status.
  "sourceReferenceId": DATAPREP['consignment_id'],
  "dateTime": __get_current_date_YYYY_MM_DD(),
  "caseStatus": case_status, #--1st Call– Initiated-2nd Call – Buyer Withdrew/Buyer Bought
  "caseDisposition": disposition_code,#--1st Call – blank-2nd Call – Seller Buyback/Auction Inherit                               
  "sellerPriceAdjustAmount": -1 *DATAPREP['sellerPriceAdjustAmount'],
  "sellerExpenseLine":[
          { "sellerExpenseAmount": -1 * DATAPREP['sellerExpenseAmount'],
            "sellerExpenseDescription":"Transportation"}
          ],#-if not giving seller adjustment just provide, "sellerExpenseLine":[]
  "coxLocation": DATAPREP['auction'],
  "nonReversibleLines":[{"lineNumber":DATAPREP['assurance_line_num'],"invoiceId":DATAPREP['assurance_invoice_id']}],
  "coxExpenseLine": [
   {
      "coxExpenseDescription": "Recon",
      "coxExpenseRespDept": "Auction Management",
      "coxExpenseType": "Goodwill",
      "coxExpenseAmount": -round(random.uniform(10.0,300.9),2)
    }
  ],
  "overrideFloorplanPayment": False,
  "assetExpenseResponsibleDept": "Auction CR",
  "assetExpenseType": "Policy Loss",
  "assetNotes": "test_123",
  "vehicleReturnSellerAccountNumber": None,
  "vehicleReturnLocationCode": None,
  "sourceSystem": "SalesForce ACMS"
} 

   
def arb_seller_call_with_adjustments(case_status, disposition_code):

  return {
    "consignmentId": DATAPREP['consignment_id'],
    "customerType": "SELLER", #Depends on Arbitration Case Status.
    "sourceReferenceId": DATAPREP['consignment_id'],
    "dateTime": __get_current_date_YYYY_MM_DD(),
    "caseStatus": case_status, #--Buyer Withdrew/Buyer Bought
    "caseDisposition": disposition_code,#– Seller Buyback/Auction Inherit                               
    "sellerPriceAdjustAmount":DATAPREP['sellerPriceAdjustAmount'], #-if not giving seller adjustment then provide value as null
    "sellerExpenseLine":[
          { "sellerExpenseAmount":DATAPREP['sellerExpenseAmount'],
            "sellerExpenseDescription":"Transportation"}
          ],#-if not giving seller adjustment just provide, "sellerExpenseLine":[]
    "coxLocation": DATAPREP['auction'],
    "coxExpenseLine": [],
    "overrideFloorplanPayment": False,
    "assetExpenseResponsibleDept": "Auction CR",
    "assetExpenseType": "Policy Loss",
    "assetNotes": "test_123",
    "vehicleReturnSellerAccountNumber": None,
    "vehicleReturnLocationCode": None,
    "sourceSystem": "SalesForce ACMS"
  }              

def arb_vra_initiated(case_status = None , disposition_code = None):

  return {
    "consignmentId": DATAPREP['consignment_id'],
    "customerType": None, #Depends on Arbitration Case Status.
    "sourceReferenceId": DATAPREP['consignment_id']+__get_current_date_MM_DD(),
    "dateTime": __get_current_date_YYYY_MM_DD(),
    "caseStatus": "VRA Initiated", #--Buyer Withdrew/Buyer Bought
    "caseDisposition": disposition_code,#– Seller Buyback/Auction Inherit                               
    "coxLocation": DATAPREP['auction'],
    "coxExpenseLine": [],
    "overrideFloorplanPayment": False,
    "assetExpenseResponsibleDept": None,
    "assetExpenseType": None,
    "assetNotes": None,
    "vehicleReturnSellerAccountNumber": None,
    "vehicleReturnLocationCode": None,
    "sourceSystem": "SalesForce ACMS"
  } 
  
  

def arb_vra_resolution(case_status, disposition_code):
  tc_logs.checkpt_with_no_picture(f"Inside Payload Seller Account Retrun Number {DATAPREP['seller_return_acct_number']} " )
  return {
    "consignmentId": DATAPREP['consignment_id'],
    "customerType": "BUYER", #Depends on Arbitration Case Status.
    "sourceReferenceId": DATAPREP['consignment_id']+__get_current_date_MM_DD(),
    "dateTime": __get_current_date_YYYY_MM_DD(),
    "caseStatus": case_status, #--Buyer Withdrew/Buyer Bought
    "caseDisposition": disposition_code,#– Seller Buyback/Auction Inherit                               
    "coxLocation": DATAPREP['auction'],
    "coxExpenseLine": [],
    "vehicleReturnSellerAccountNumber": DATAPREP['seller_return_acct_number'],
    "overrideFloorplanPayment": False,
    "vehicleReturnLocationCode":None,
    "assetExpenseResponsibleDept": None,
    "assetExpenseType": None,
    "assetNotes": None,
    "sourceSystem": "SalesForce ACMS"
  }




