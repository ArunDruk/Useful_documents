﻿import tc_logs

def connect_to_network_drive(localname,path):
    res = aqFileSystem.MapNetworkDrive(localname, path)
    if res != 0:
        tc_logs.error_with_no_picture(aqUtils.SysErrorMessage(res) + f" Error code is {str(res)}.")
    else:
        tc_logs.checkpt_with_no_picture(f"The connection to {path} has been established successfully.")
      
def disconnect_from_network_drive(drive):
    aqFileSystem.DisconnectNetworkDrive(drive,True)
    
def delete_file(path,ext="\\*.pdf"):
    colFiles = aqFileSystem.GetFolderInfo(path).Files
    if(colFiles!= None):
        aqFileSystem.DeleteFile(path+ext)
        tc_logs.checkpt_with_no_picture("Old files deleted successfully")

def create_folder(fldr_path):
    if not aqFileSystem.Exists(fldr_path):
        aqFileSystem.CreateFolder(fldr_path)
    
def save_output_pdf(pdf_path,wait_time = 2000):
    pdf_path = pdf_path+".pdf"
    Delay(wait_time)
    Log.File(pdf_path,"PDF saved successfully")  
