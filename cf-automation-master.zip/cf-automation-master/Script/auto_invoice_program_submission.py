﻿import login_logout_utility
import oracle_responsibility_utility
import form_utility
import tc_logs
import oracle_home_page
import gvar
import keys_utility
import auto_invoice_params
import submit_single_request_form as ssrf
import invoice_query
import web_utility
from datetime import date


def auto_invoice_concurrent_submission() :


    tc_logs.header_name("Run Auto Invoice Concurrent Program")  
    gvar.dataprep['env'] = BuiltIn.ParamStr(14)
#    gvar.dataprep['env'] = "oci_stage"
    gvar.load_environment_files()
#    login_logout_utility.oracle_login()
    oracle_responsibility_utility.ar_home_office_super_user('Run')
    jformobject = form_utility.get_java_parent_form()
    Delay(5000)
    keys_utility.press_alt_o()
    Delay(5000)
    ssrf.request_name_textfield().keys ("Autoinvoice Master Program[Tab]")
    tc_logs.checkpt_with_picture("Sucessfully entered the Program Name",pmHigher,gvar.dataprep['jformobject'])
#    set_concurrent_process_name("Autoinvoice Master Program")
    parameters_window = auto_invoice_params.autoinvoice_master_program_pramas_window()
    auto_invoice_params.invoice_source_textfield(parameters_window).keys('OM')
#    gvar.store('date',date.today().strftime("%d-%b-%Y").upper())
    gvar.store('date',aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d-%b-%Y"))
#    gvar.dataprep['sale_order_date'] = aqConvert.DateTimeToFormatStr(gvar.dataprep['date'],"%Y-%m-%d")
    date_field = auto_invoice_params.date_textfield(parameters_window)
    date_field.Click()
    date_field.Keys(gvar.dataprep['date'])
    aqUtils.Delay(1000)
    keys_utility.press_tab_n_times(11)
#    if gvar.dataprep['floor_ag'] != 'NG':
    auto_invoice_params.order_no_low(parameters_window).Click()
    auto_invoice_params.order_no_low(parameters_window).SetText(gvar.dataprep['seller_order']) 
#    auto_invoice_params.order_no_low(parameters_window).Click()
#    auto_invoice_params.order_no_low(parameters_window).SetText("131833107")
    aqUtils.Delay(1000)
    keys_utility.press_tab()
#    if gvar.dataprep['floor_ag'] != 'NG':
    auto_invoice_params.order_no_high(parameters_window).Click()
    auto_invoice_params.order_no_high(parameters_window).SetText(gvar.dataprep['buyer_order']) 
#    auto_invoice_params.order_no_high(parameters_window).Click()
#    auto_invoice_params.order_no_high(parameters_window).SetText("131833138")
    keys_utility.press_tab()
    tc_logs.checkpt_with_picture("Entered Required Parameters/order_numbers",pmHigher,gvar.dataprep['jformobject'])

#    keys_utility.press_tab()
#    keys_utility.press_tab()
    keys_utility.press_alt_o()
#    auto_invoice_params.ok_button(parameters_window)
    keys_utility.press_alt_m()
    form_utility.validate_invoice_request(jformobject)
    if gvar.dataprep['floor_ag'] != 'NG':
      vin=  gvar.dataprep['vin'] 
      consignment_id = gvar.dataprep['consignment_id']
      invoice_query.invoice_fetch_query(vin,consignment_id)
#    tc_logs.checkpt_with_no_picture('Seller Invoice:' +str(invoice_number))
    wscript=Sys.OleObject["WScript.Shell"]  
    wscript.Run("taskkill.exe /F /IM jp2launcher.exe /T")
    wscript.Run("taskkill.exe /F /IM iexplore.exe /T") 
    


def Test1():
  Aliases.explorer.wndShell_TrayWnd.ReBarWindow32.MSTaskSwWClass.MSTaskListWClass.Click(772, 24)
  Aliases.jp2launcher.Frame.FndFormsEngine0.MDIContainer6.EwtComponent5.ScrollBox4.ScrollBox_13.FormDesktopContainer2.Click(330, 108)
