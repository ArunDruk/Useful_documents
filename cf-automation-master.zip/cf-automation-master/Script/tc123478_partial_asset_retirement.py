﻿from dbhelper import *
from ebiz import *
import web_utils
import dbhelper
import file_system_utils 
import form_utils

class tc123478_partial_asset_retirement(Ebiz):
 op_log_path="C:\\Tc_Logs"

 def login(self):
   self.login_user='naggarwal'
   super().login()
   
 def action(self,book): 
   app = book.Sheets.item["Assets"] 
   rowno=2
   
   #Login to Oracle
   self.wait_until_page_loaded()    
   self.log_checkpoint_message_web("Login Successful")
   
   #Selecting the responsibility
   web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" FA ASSET TRANSACTIONS')]")
   self.log_message_web("Click 'CAI "+self.oper_unit+" FA ASSET TRANSACTION' - Successful")
   Delay(3000)
   self.page.NativeWebObject.Find("contentText","Assets","A").Click()
   self.log_message_web("Click 'Assets' - Successful")
   Delay(2000)
   self.page.wait()
   self.page.NativeWebObject.Find("contentText","Asset Workbench","A").Click()
   self.log_message_web("Click 'Asset Workbench' - Successful")
   Delay(2000)
   self.page.wait()
   
   #Handling the security pop-up and opening forms
   jFrame= self.initializeJFrame()
   Delay(3000)
   form_utils.click_ok_btn(jFrame)
   Delay(3000)
   
   #Getting Asset Number from database
   self.log_message_oracle_form(jFrame,"'Find Assets' form launched successfully")  
   dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
   user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
   pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
   asset_num = dbhelper.asset_add(dsn,user_id,pwd)
   

   #Find Assets form frame
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Find Assets","ExtendedFrame"]
   findassets_form=jFrame.FindChildEx(prop,val,60,True,60000)
   
   #Entering Asset number in Find Assets form
   prop = ["AWTComponentAccessibleName","JavaClassName"]
   val = ["Asset Number","VTextField"]
   self.log_message_oracle_form(jFrame,"In 'Find Assets' form enter 'Asset Number' next")
   findassets_form.FindChild(prop,val,10).SetText(asset_num) 
   findassets_form.Keys("[Tab]")
   app.Cells.Item[rowno,2] = asset_num 
   
   #Verifying for Asset Number textfield object existence   
#   self.verify_aqobject_chkproperty(findassets_form,"AWTComponentAccessibleName",cmpContains,"Find Assets")
   Delay(3000)
   
   #Finding the asset number
   self.log_message_oracle_form(jFrame,"In 'Find Assets' click 'Find' button next")
   prop = ["AWTComponentAccessibleName","JavaClassName"]
   val = ["Find alt i","Button"]
   findassets_form.FindChild(prop,val,20).Click()
   Delay(3000)
   
   #Assets form identification and verifying its existence
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Assets","ExtendedFrame"]
   assets_form=jFrame.FindChildEx(prop,val,60,True,60000)
   self.log_message_oracle_form( jFrame,"'Assets' form launched successfully")
   self.verify_aqobject_chkproperty(assets_form,"AWTComponentAccessibleName",cmpContains,"Assets")
   
   #Selecting Retirements button
   self.log_message_oracle_form( jFrame,"In 'Assets' form click on 'Retirements' next")
   assets_form.FindChild("AWTComponentAccessibleName","Retirements alt R",10).Click()
   Delay(2000)
   
   #Retirements form identification
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["retirements","ExtendedFrame"]   
   retirements_form=jFrame.FindChildEx(prop,val,10,True,60000)
   self.log_message_oracle_form( jFrame,"'Retirements' form launched successfully")
   Delay(2000)
   
   #Entering Bookname for the Asset in retirements form
   prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
   val=["Book RequiredList of Values","VTextField",2]      
   book = retirements_form.FindChild(prop,val,10)
   book.Click()
   book.SetText("ATG CORP")
   self.log_message_oracle_form( jFrame,"In 'Retirements' form 'Book' entered successfully ")
   Delay(5000)
   book.keys("[Tab]")
   
   #Extracting the current cost in retirements form   
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Current Cost","VTextField"]    
   Delay(2000)  
   ret_val = retirements_form.FindChild(prop,val,10).wText
   self.log_message_oracle_form( jFrame,"Current Cost of an Asset : "+VarToStr(ret_val))
   partial_amt=VarToFloat(ret_val) 

   prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
   val=["Retirement TypeList of Values","VTextField",11]    
   Delay(2000)  
   retirement_type=retirements_form.Find(prop,val,10)
   retirement_type.Click()
   retirement_type.SetText("ABANDONMENT")
   self.log_message_oracle_form( jFrame,"In 'Retirements' form 'Retirement Type' entered successfully ")


   #Entering cost retired in retirements form     
   prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
   val=["Cost Retired Required","VTextField",10]    
   Delay(2000)  
   costRet_vxt_field=retirements_form.Find(prop,val,10)
   costRet_vxt_field.Click()
   updated_amount = costRet_vxt_field.SetText(VarToInt(VarToFloat(VarToFloat(partial_amt)/2)))
   costRet_vxt_field.Keys("[Tab]")
   self.log_message_oracle_form( jFrame,"Asset Partial Retirement Amount: "+VarToStr(VarToFloat(VarToFloat(partial_amt)/2)))
   Delay(2000)
   
   #Selecting Done button in retirements form
   self.log_message_oracle_form( jFrame,"In 'Retirements' form click 'Done' next ")
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Done alt D","Button"]   
   retirements_form.FindChild(prop,val,30).Click()
   
   #Confirmation message form identification and selecting OK button
   prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
   val=["Forms FRM-40400*","FWindow",0] 
   conf_msg_form=jFrame.FindChildEx(prop,val,10,True,90000)   
   val = ["OK ALT O","PushButton",0]    
   Delay(1000)  
   conf_msg_form.FindChild(prop,val,10).Click()
   Delay(2000)
   
   #Closing Asset form
   assets_form.close()
   Delay(3000)
   
   #Selecting other->req->run in navigator form 


   menu_bar=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWComponent", "", 0).AWTObject("LWMenuBar", "", 0)
   OCR.Recognize(menu_bar).BlockByText("View").Click()
   Delay(1000)

   view_menu=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("LWPopupMenu", "", 0)
   OCR.Recognize(view_menu).BlockByText("Requests").Click()
   
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Find Requests","ExtendedFrame"]
   findreq_form=jFrame.FindChildEx(prop,val,30,True,90000)
   
   val=["Submit a New Request alt N","Button"]
   findreq_form.FindChild(prop,val,30).Click()
   
   #Identifying the submit request window and providing request name 
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Submit Request","ExtendedFrame"]
   submitrequest_form=jFrame.FindChildEx(prop,val,60,True,60000)
   submitrequest_form.Find("AWTComponentAccessibleName","Name RequiredList of Values",10).Click()
   Delay(1000)
   submitrequest_form.Find("AWTComponentAccessibleName","Name RequiredList of Values",10).SetText("Calculate Gains and Losses")
   self.log_message_oracle_form(jFrame,"Submitting Concurrent Request 'Calculate Gain and Losses' program") 
   Delay(5000)
   jFrame.Keys("[Tab]")
   Delay(2000)
   
   #Identifying the parameters frame to enter the parameters
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Parameters","FlexWindow"]
   parameters_form=jFrame.FindChildEx(prop,val,60,True,60000)
   
   book_txtfield=parameters_form.FindChild("AWTComponentAccessibleName","Book REQUIRED List Values",10)
   book_txtfield.Click()
   book_txtfield.Keys("ATG CORP")
   Delay(5000)
   jFrame.Keys("[Tab]")
   Delay(2000)
   jFrame.keys("~o")
   self.log_message_oracle_form( jFrame,"Parameters for 'Calculate Gain and Losses Program' succesfully") 
   Delay(2000)
   
   #Submit request
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Submit alt m","Button"]
   submitrequest_form.FindChild(prop,val,60).Click()
   Delay(3000)
   
   val = ["Decision Request submitted*","ChoiceBox"]
   decision_box = jFrame.FindChildEx(prop,val,60,True,12000)
#   RequestID = ''.join(x for x in decision_box.AWTComponentAccessibleName if x.isdigit())
   RequestID = aqConvert.VarToStr(''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit()))
   self.log_message_oracle_form( jFrame,"'Calculate Gain and Losses Program' submitted successfully and Request ID is "+VarToStr(RequestID))
   
   #select no
   jFrame.Keys("~n")
   Delay(2000)
   
   #Find all requests
   jFrame.Keys("~v")
   Delay(2000)
   jFrame.Keys("r")
   Delay(2000)
   
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Find Requests","ExtendedFrame"]
   find_req_form=jFrame.FindChild(prop,val,30)
   Delay(3000)

   jFrame.Keys("[Right]")
   Delay(2000) 
   jFrame.Keys("[Tab]")

   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Request ID","VTextField"]
   find_req_form.FindChild(prop,val,60).Click()
   find_req_form.FindChild(prop,val,60).SetText(RequestID)
   
   jFrame.Keys("~i")
   Delay(2000)
   
   #find request form identification
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Requests","ExtendedFrame"]
   req_form=jFrame.FindChildEx(prop,val,30,True,90000)   
   
   #verifying for request completion
   dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
   user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
   pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
   dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,RequestID)
   
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val = ["Refresh Data alt R","Button"]
   req_form.FindChild(prop,val,2000).Click()
   
   #Click on output button  
   prop = ["AWTComponentAccessibleName","JavaClassName"]
   val = ["View Output alt p","Button"]
   req_form.FindChild(prop,val,2000).Click()
   Delay(3000)
   
   output_page=Sys.Browser("iexplore").Page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
   output_page.Click()
   Delay(3000)
   
   #Save the output file and close the window
   output_page.Keys("~f")
   output_page.Keys("a")
   Delay(3000)

   file_system_utils.create_folder(self.op_log_path)             
   log_path=self.op_log_path+"\\Calculate Gains and Losses_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
   Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
   Delay(1000)
   Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
   Delay(1000)
   Log.Enabled=True
   Log.File(log_path, "Calculate Gains and Losses Report Output File Attached")
   Log.Enabled=False     
   Sys.Browser("iexplore").Page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close() 
   Delay(2000) 
   
   #Submit new request
   jFrame.Keys("~m")  
   jFrame.Keys("~o")
   
   #Asset Retirements report program
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Submit Request","ExtendedFrame"]
   submitrequest_form=jFrame.FindChildEx(prop,val,60,True,60000)
   submitrequest_form.Find("AWTComponentAccessibleName","Name RequiredList of Values",10).Click()
   Delay(1000)
   submitrequest_form.Find("AWTComponentAccessibleName","Name RequiredList of Values",10).SetText("Asset Retirements Report")
   self.log_message_oracle_form(jFrame,"Submitting Concurrent Request 'Asset Retirements Report' program") 
   Delay(5000)
   jFrame.Keys("[Tab]")
   Delay(2000)
   
   #Identifying the parameters frame to enter the parameters
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Parameters","FlexWindow"]
   parameters_form=jFrame.FindChildEx(prop,val,60,True,60000)
   book_txtfield=parameters_form.FindChild("AWTComponentAccessibleName","Book REQUIRED List Values",10)
   book_txtfield.Click()
   book_txtfield.Keys("ATG CORP")
   Delay(1000)
   parameters_form.Keys("[Tab]")
   Delay(1000)
   parameters_form.Keys("[Tab]")  
   Delay(1000)
   parameters_form.Keys(aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%b-%y").upper())
   Delay(1000)
   parameters_form.Keys("[Tab]")
   Delay(1000)
   parameters_form.Keys(aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%b-%y").upper())
   self.log_message_oracle_form( jFrame,"Parameters for 'Asset Retirements Report'- Book,Ledger Currency,From Period,To Period entered successfully")
   Delay(1000)
   val = ["OK ALT O","FormButton"]
   parameters_form.FindChild(prop,val,60).Click()
   Delay(2000)
   
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Submit alt m","Button"]
   submitrequest_form.FindChild(prop,val,60).Click()
#   self.log_message_oracle_form( jFrame,"Submitted Asset Retirements Report' Program") 
   Delay(3000)
   
   val = ["Decision Request submitted*","ChoiceBox"]
   decision_box = jFrame.FindChildEx(prop,val,60,True,12000)
#   RequestID = ''.join(x for x in decision_box.AWTComponentAccessibleName if x.isdigit())
   RequestID = aqConvert.VarToStr(''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit()))
   self.log_message_oracle_form( jFrame,"'Asset Retirements Report' submitted successfully and Request ID is "+VarToStr(RequestID))
   
   #select no
   jFrame.Keys("~n")
   Delay(2000)
   jFrame.keys("~o")
   Delay(2000)
   
   val = ["Find Requests alt i","Button"]
   req_form.FindChild(prop,val,20).Click()
   
   #verifying for request completion
    #Find all requests
   Delay(2000)
   jFrame.Keys("[Right][Left]")
   Delay(2000) 
   jFrame.Keys("[Tab]")

   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Request ID","VTextField"]
   find_req_form.FindChild(prop,val,60).Click()
   find_req_form.FindChild(prop,val,60).SetText(RequestID)
   
   jFrame.Keys("~i")
   Delay(2000)
   
   #find request form identification
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Requests","ExtendedFrame"]
   req_form=jFrame.FindChildEx(prop,val,30,True,90000)
   
   dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
   user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
   pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
   dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,RequestID)
   
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val = ["Refresh Data alt R","Button"]
   req_form.FindChild(prop,val,2000).Click()
   
   #Click on output button  
   prop = ["AWTComponentAccessibleName","JavaClassName"]
   val = ["View Output alt p","Button"]
   req_form.FindChild(prop,val,2000).Click()
   Delay(3000)
   
   #Save the output file and close the window
   output_page=Sys.Browser("iexplore").Page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
   output_page.Click()
   Delay(2000)
   output_page.Keys("~f")
   output_page.Keys("a")
   Delay(3000)
   
   file_system_utils.create_folder(self.op_log_path)             
   log_path=self.op_log_path+"\\Asset Retirements Report_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
   Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
   Delay(1000)
   Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
   Delay(1000)
   Log.Enabled=True
   Log.File(log_path, "Asset Retirements Report Report Output File Attached")
   Log.Enabled=False     
   Sys.Browser("iexplore").Page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close() 
   Delay(2000)
   req_form.Close()
   
   #Navigating back to Assets form      
#   jFrame.Click()
#   Delay(1000)
#   jFrame.Keys("[F4]")
#   Delay(1000)  
#   jFrame.Keys("[Up][Up]")   
#   Delay(1000)
#   jFrame.Keys("a")   
#   Delay(2000)     
#   jFrame.Keys("[Enter]")
#   Delay(1000)

   navigator_form = Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("ExtendedFrame", "Navigator - CAI US FA ASSET TRANSACTIONS", 4).AWTObject("LWComponent", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("FScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("DrawnPanel", "", 0).AWTObject("FormsTabPanel", "", 0).AWTObject("TabPanelSheet", "", 0).AWTObject("FScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("DrawnPanel", "", 0).AWTObject("VTList", "Function List", 0).AWTObject("ScrollBox", "", 0).AWTObject("LWDataSourceList$Content", "", 0)
   OCR.Recognize(navigator_form).BlockByText("Assets").DblClick()
   Delay(1000)
   OCR.Recognize(navigator_form).BlockByText("Asset Workbench").DblClick()   
   Delay(2000)
   
   self.log_message_oracle_form( jFrame,"Navigating to 'Find Assets' form")
   
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Find Assets","ExtendedFrame"]
   findassets_form=jFrame.FindChildEx(prop,val,60,True,60000)
   #query asset number in find assets form
   findassets_form.Find("AWTComponentAccessibleName","Asset Number",10).Click()
   findassets_form.Find("AWTComponentAccessibleName","Asset Number",10).SetText(asset_num) 
   self.log_message_oracle_form( jFrame,"In 'Find Assets' form Asset Number: "+VarToStr(asset_num)+" entered")
   Delay(5000)
   findassets_form.Keys("[Tab]")
   
   #Finding the asset number
   self.log_message_oracle_form( jFrame,"In 'Find Assets' form: Click 'Find' next")
   findassets_form.FindChild("AWTComponentAccessibleName","Find alt i",10).Click()
   Delay(3000)
   
   #Assets form identification and verifying its existence
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Assets","ExtendedFrame"]
   assets_form=jFrame.FindChildEx(prop,val,60,True,60000)
   self.log_message_oracle_form( jFrame,"'Assets' form launched successfully")
#   self.verify_aqobject_chkproperty(assets_form,"AWTComponentAccessibleName",cmpContains,"Assets")

   
   #Financial inquiry button in assets form
   self.log_message_oracle_form( jFrame,"In 'Assets' form click on 'Financial Inquiry' button next")
   assets_form=jFrame.FindChildEx(prop,val,60,True,90000)
#   self.log_message_oracle_form( jFrame,"Assets form found")     
   prop = ["AWTComponentAccessibleName","JavaClassName"]
   val = ["Financial Inquiry alt i","Button"]
   assets_form.FindChild(prop,val,2000).Click()
   Delay(3000)
   
   #Financial inquiry form identification
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["View Financial Information*","ExtendedFrame"]
   view_fin_form=jFrame.FindChildEx(prop,val,60,True,90000) 
   self.log_message_oracle_form( jFrame,"View Financial Information form launched successfully")  
   self.log_message_oracle_form( jFrame,"In 'View Financial Information' form click on 'Cost History' Tab next") 
   #Navigate to cost history and close the form   
   view_fin_form.FindChild("AWTComponentName","FormsTabPane*",20).ClickTab("Cost History")   
   self.log_message_oracle_form( jFrame,"Review Retirement Information on 'Cost History' Tab")              
   jFrame.Keys("[F4]")
   Delay(2000) 
   self.log_message_oracle_form( jFrame,"Switching Responsibility to 'CAI US FA JOB SCHEDULER' next")    
     
   #Switching Responsibility
   OCR.Recognize(menu_bar).BlockByText("File").Click()
   Delay(1000)
   jFrame.Keys("w")
   Delay(2000)

   #Switiching responsibility form identification    
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Responsibilities","FWindow"]
   resp_form=jFrame.FindChildEx(prop,val,30,True,60000)
   
   #selecting the responsibility
   resp_form.Find("AWTComponentName","LWTextField*",10).Click() 
   resp_form.Find("AWTComponentName","LWTextField*",10).keys("CAI US FA JOB SCHEDULER")
   self.verify_aqobject_chkproperty(resp_form,"AWTComponentAccessibleName",cmpContains,"Responsibilities")   
   Delay(2000)
   
   val = ["Find ALT F","PushButton"]
   resp_form.FindChild(prop,val,20).Click()
   Delay(2000) 
   
   #Navigating to submit request
   jFrame.Keys("~o")
   self.log_message_oracle_form(jFrame,"'CAI US FA JOB SCHEDULER' launched successfully and Submit New Request next")
   Delay(2000)
   jFrame.Keys("~o")
   
   #Submitting Create Accounting - Assets Program
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Submit Request","ExtendedFrame"]
   submitrequest_form=jFrame.FindChildEx(prop,val,60,True,60000)
   name = submitrequest_form.Find("AWTComponentAccessibleName","Name RequiredList of Values",20)
   name.Click()
   name.SetText("Create Accounting - Assets")
   Delay(5000)
   jFrame.Keys("[Tab]")
   Delay(2000)
   self.log_message_oracle_form(jFrame,"Submitting 'Create Accounting - Assets' Program")
   
   #Entering Parameters
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Parameters","FlexWindow"]
   parameters_form=jFrame.FindChildEx(prop,val,60,True,60000)
#   book_txtfield=parameters_form.FindChild("AWTComponentAccessibleName","Ledger REQUIRED List Values",10)
#   book_txtfield.Click()
#   book_txtfield.Keys("CAI US LEDGER")

   book_txtfield=parameters_form.FindChild("AWTComponentAccessibleName","Book Type Code REQUIRED List Values",10)
   book_txtfield.Click()
   delay(2000)
   book_txtfield.Keys("ATG CORP") 

   Delay(1000)
   parameters_form.Keys("[Tab]")
   Delay(1000)
#   parameters_form.Keys("[Tab]")
#   Delay(1000)
#   jFrame.Keys(aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d-%b-%Y"))
#   Delay(1000)
#   parameters_form.Keys("[Tab]")
#   Delay(1000)
   self.log_message_oracle_form(jFrame,"'Create Accounting - Assets' Program Parameters entered successfully")
   val = ["OK ALT O","FormButton"]
   parameters_form.FindChild(prop,val,60).Click()
   Delay(2000)
   Delay(1000)
   
   #submit
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Submit alt m","Button"]
   submitrequest_form.FindChild(prop,val,60).Click()
   self.log_message_oracle_form(jFrame,"'Create Accounting - Assets' job submitted")
   Delay(2000)
   
   val = ["Decision Request submitted*","ChoiceBox"]
   decision_box = jFrame.FindChildEx(prop,val,60,True,12000)
#   RequestID = ''.join(x for x in decision_box.AWTComponentAccessibleName if x.isdigit())
   RequestID = aqConvert.VarToStr(''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit()))
   self.log_message_oracle_form( jFrame,"'Create Accounting - Assets' program submitted successfully and Request ID is "+VarToStr(RequestID))
   
   jFrame.Keys("~n")
   Delay(2000)
   
   #Find requests
   OCR.Recognize(menu_bar).BlockByText("View").Click()
   Delay(1000)

   view_menu=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("LWPopupMenu", "", 0)
   OCR.Recognize(view_menu).BlockByText("Requests").Click()

   Delay(2000)
   jFrame.Keys("~i")
   Delay(2000)
   
# Checking in the DB for the concurrent programs completion
   dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
   user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
   pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
   dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd, aqConvert.VarToStr(RequestID)) 
   delay(3000)
    
   #Verify job completion
   #output file view, save and close the output window
   creq_id,log_path = form_utils.req_set_save_output(self,jFrame,req_form,"Journal Import",RequestID)
   web_utils.close_additional_browsers()
   
   #read the output file and save in excel
   fo=open(log_path,"r") 
   lines=fo.readlines()
   self.log_message_web("Journal Imported Batch Name is : - "+lines[17][8:33].strip())
   app.Cells.Item[rowno,1] = lines[17][8:33].strip()   
   
   #Close form
   jFrame.Click()
   Delay(1000)
   jFrame.keys("[F4]")
   Delay(2000)
   jFrame.keys("[F4]")
   Delay(2000)
   jFrame.keys("~o")
   delay(2000)
   self.close_forms(jFrame)
   delay(5000)

      
   #save book and close addition tabs in IE
   book.save()
#   Sys.Browser("iexplore").page("https://*epfinnp.coxautoinc.com/forms/frmservlet*").Close()  

     
 

     
 
