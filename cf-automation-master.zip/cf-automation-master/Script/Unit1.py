﻿import traceback
from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils
import winscp_utility



class Unit1(Ebiz):
  
 def action(self,book):     
    try:  
      Found=False 
      adoCon=ADO.CreateADOConnection()
      adoCon.ConnectionString="Provider=MSDASQL.1;Password=X6yPC6md;Persist Security Info=True;User ID=RAC_ACCNT;Data Source=OCI_DEV"
      adoCon.LoginPrompt=False
      adoCon.Open()    
      sqlQuery = "select invoice_id from ap_invoices_all where invoice_num = 'AN_INV_070119_1'"
#      sqlQuery = aqString.Format(sqlQuery,invoice_num) 
      Log.Enabled=True
      Log.Message("Executing SQL Query In Oracle Database to retrieve Item Key" +(sqlQuery)) 
      Log.Enabled=False      
      for x in range(0,60):
        rec_set=adoCon.Execute_(sqlQuery)
        rec_set.MoveFirst()
        while (not rec_set.EOF):
          Log.Enabled=True
          Log.Message(" Item Key for the Invoice: Invoice ID  "+aqConvert.FloatToStr(rec_set.Fields.Item["INVOICE_ID"].Value))        
          Log.Enabled=False
          key = (rec_set.Fields.Item["INVOICE_ID"].Value)
          Found=True
          return key
          rec_set.MoveNext()
        if Found==True:
          break        
    except Exception as e:
        Log.Enabled = True
        Log.Error("Error : - " + traceback.format_exc()) 
        Log.Enabled = False  
    finally:    
        adoCon.Close()
          
 def this_should_cause_a_merge_conflict():
    print('conflict') 
           
 def adding_a_test_method():
    print('testing')
    
 def sneha_demo_method():
    print('demo')