﻿from gvar import dataprep as  DATAPREP 
import gvar
from  database_service  import query_oracle_db as __ORACLE_DB 
import tc_logs
import odm_datatype
from workflow_queries import get_wf_status as GET_QUERY
CHECK_POINT  = tc_logs.checkpt_with_no_picture
def verify_arb_amount():
    return f""" select rcta.attribute2 as CONSIGNMENT_ID
     , rcta.attribute4  as VIN
     , rcta.attribute_category as CATEGORY
     , rctta.type as TYPE
     , sum( (SELECT amount_due_original
        FROM   ar_payment_schedules_all  apsa
         WHERE  apsa.customer_trx_id = rcta.customer_trx_id )) as TOT_AMT
      FROM    ra_customer_trx_all       rcta
           ,  ra_cust_trx_types_all    rctta
           ,  manar.man_om_consignments moca
      WHERE rcta.attribute2  = to_char(moca.consignment_id )
          AND   rcta.cust_trx_type_id = rctta.cust_trx_type_id
          AND   moca.consignment_id = '{DATAPREP['consignment_id']}'
          AND  rctta.name='US BUYER ARB' group by  rcta.attribute2
            , rcta.attribute4, rcta.attribute_category, rctta.type """
            
def verify_arb_amount_test():
    return """ select rcta.attribute2 as CONSIGNMENT_ID
     , rcta.attribute4  as VIN
     , rcta.attribute_category as CATEGORY
     , rctta.type as TYPE
     , sum( (SELECT amount_due_original
        FROM   ar_payment_schedules_all  apsa
         WHERE  apsa.customer_trx_id = rcta.customer_trx_id )) as TOT_AMT
      FROM    ra_customer_trx_all       rcta
           ,  ra_cust_trx_types_all    rctta
           ,  manar.man_om_consignments moca
      WHERE rcta.attribute2  = to_char(moca.consignment_id )
          AND   rcta.cust_trx_type_id = rctta.cust_trx_type_id
          AND   moca.consignment_id = '11800826'
          AND  rctta.name='US BUYER ARB' group by  rcta.attribute2
            , rcta.attribute4, rcta.attribute_category, rctta.type """

def qry_to_get_trx_with_attribute5():
  qry =  f"""SELECT * FROM 
        (
   		     SELECT TO_CHAR(TRX_NUMBER) INV_NUMBER, RCTA.ATTRIBUTE4 VIN, 
    		   RCTA.ATTRIBUTE2 CONSIGNMENT_ID, 
    		    (SELECT PURCHASE_LOCATION_CODE AS auction FROM MANAR.MAN_OM_Consignments moc 
    		      WHERE moc.CONSIGNMENT_ID = rcta.attribute2  ) AS AUCTION
    	     FROM RA_CUSTOMER_TRX_ALL RCTA 
    	     WHERE RCTA.attribute5 IS NOT NULL 
    	      AND RCTA.ATTRIBUTE_category  IN ( 'US ARBITRATION','US BUYER','US SELLER')                                 
    	      AND NOT EXISTS  (SELECT  ffvv.flex_value  FROM     fnd_flex_value_sets ffvs, 
            FND_FLEX_VALUES_VL ffvv
        	WHERE 1 = 1 AND     ffvs.flex_value_Set_name =  'MANAR_PAYMENT_OVERRIDE_VS'
    		              AND     ffvs.flex_value_set_id      =     ffvv.flex_value_set_id
    	              	AND     ffvv.flex_value             =     RCTA.attribute5 )
          AND  creation_date >= TRUNC(SYSDATE - 180)
          AND  NOT EXISTS ( SELECT 1 FROM MANAR.MAN_OM_CONSIGN_ADJUSTMENTS MOCA  
           WHERE  TO_CHAR(MOCA.CONSIGNMENT_ID) = RCTA.ATTRIBUTE2 )  
        ORDER BY creation_date DESC ) A 
      WHERE A.auction = '{DATAPREP['auction']}'
      FETCH FIRST ROW ONLY """
  rows = ORACLE_DB(qry)
  if (GetVarType(rows)== VarToInt(9) and len(rows) > 0 ):
        DATAPREP['vin']  = rows[0]['VIN']          
        DATAPREP['consignment_id']  = rows[0]['CONSIGNMENT_ID']
        DATAPREP['auction'] = rows[0]['AUCTION']
        CHECK_POINT(f" VIN : {DATAPREP['vin']}") 
        CHECK_POINT(f" CONSIGNMENT_ID : {DATAPREP['consignment_id']}")
        CHECK_POINT(f" AUCTION : {DATAPREP['auction']}")       
  else:
     __ERROR = tc_logs.error_with_no_picture
     __ERROR("NO records found with Attribute5 without error")

def get_asset_information():
  tc_logs.test_data("----- Get asset number and Other Details from Oracle DB -----")
  try:
    qry = f"""SELECT faa.asset_number,
                   faa.asset_type,
                   faa.tag_number,
                   faa.description,
                   FAA.SERIAL_NUMBER,
                   faa.attribute_category_code ASSET_CATEGORY
              FROM fa_additions FAA
             WHERE     FAA.tag_number ='{DATAPREP['consignment_id']}'
             AND NOT EXISTS  ( SELECT 1
                               FROM fa_retirements FAR
                               WHERE FAR.asset_id = FAA.asset_id
                               AND TRUNC (DATE_RETIRED) < TRUNC (SYSDATE)) """
    rows = ORACLE_DB(qry)
    if (GetVarType(rows) == VarToInt(9)) and len(rows)>0:
      for row in rows:
        tc_logs.checkpt_with_no_picture(f"Fixed Asset number: {row['ASSET_NUMBER']}")
        tc_logs.checkpt_with_no_picture(f"Fixed Asset Tag number: {row['TAG_NUMBER']}")
        tc_logs.checkpt_with_no_picture(f"Fixed Asset Serial number: {row['SERIAL_NUMBER']}")
        tc_logs.checkpt_with_no_picture(f"Fixed Asset Category: {row['ASSET_CATEGORY']}")
  except Exception as e:
    Log.Message(traceback.format_exc())                            

  
def reverse_trx_failed():
  qry = f"""SELECT NAME AS NODE_NAME, text_value AS ERROR_MESSAGE
         FROM wf_item_attribute_values WHERE  
          text_value LIKE '%Reverse Transaction Creation%'
          AND item_type = 'MANARBB' AND NAME = 'ERROR_NOTIF_BODY'
          AND item_key IN (SELECT consign_adjustment_id 
          FROM manar.MAN_OM_CONSIGN_ADJUSTMENTS a 
          WHERE a.consignment_id  = '{DATAPREP['consignment_id']}')"""
  rows = ORACLE_DB(qry)
  if (GetVarType(rows)== VarToInt(9) and len(rows) > 0 ):
      CHECK_POINT(f" NODE NAME   : '{rows[0]['NODE_NAME']}' ") 
      CHECK_POINT(f" ERROR VALUE : '{rows[0]['ERROR_MESSAGE']}' ")
  else:
     __ERROR = tc_logs.error_with_no_picture
     __ERROR(" MANARBB workflow didn't Failed") 

def arb_secondary_validation(item_type, item_key):
  grp_notification = False
  qry  = GET_QUERY(item_type, item_key)
  rows = ORACLE_DB(qry)
  if (GetVarType(rows)== VarToInt(9) and len(rows) > 0 ):
   for row in rows :
      CHECK_POINT(f" ACTIVITY   : '{row['ACTIVITY']}' ") 
      CHECK_POINT(f" ACTIVITY_STATUS : '{row['ACTIVITY_STATUS']}' ")
      CHECK_POINT(f" INTERNAL_WF_NAME : '{row['INTERNAL_WF_NAME']}' ")
      if row['INTERNAL_WF_NAME']== 'GROUP_NOTIFICATION' :
          grp_notification = True
          CHECK_POINT(f" Successfully Notified Group Notification ")
   if not grp_notification:
     __ERROR("Group Notification not initiated")
  else:
     __ERROR = tc_logs.error_with_no_picture
     __ERROR(" MANARBB workflow didn't get Initiated")   
       
def get_adjustment_key ():
  qry = f"""SELECT max(moca.consign_adjustment_id) CONSIGN_ADJUST_ID
            FROM   manar.man_om_consign_adjustments moca
            WHERE  moca.consignment_id = {DATAPREP['consignment_id']}"""
  rows = ORACLE_DB(qry)
  if (GetVarType(rows)== VarToInt(9) and len(rows) > 0 ):
    DATAPREP['consign_adjustment_id'] = rows[0]['CONSIGN_ADJUST_ID']
         
def get_trx_ids_adjustment():
  qry = f"""SELECT MOC.consignment_id,
       RCTA.trx_number    INVOICES,
       TO_CHAR(RCTA.trx_date,'DD-MON-YYYY')      INVOICE_DATE,
       TO_CHAR (NVL (APSA.amount_due_remaining, 0), '$9,99,99,99,990.99')
          INVOICE_BALANCE_DUE,
       TO_CHAR (NVL (APSA.amount_due_original, 0), '$9,99,99,99,990.99')
          INVOICE_BALANCE_ORIGINAL,
       HCA.account_number CUSTOMER_NUMBER,
       HCA.account_name   CUSTOMER_NAME,
       OOHA.order_number,
       OOHA.header_id,
       RCTTA.name         TRX_TYPE,
       OTTT.name          ORDER_TYPE,
       rbsa.name,
       rcta.batch_id
       FROM manar.man_om_consignments  MOC,
       ra_customer_trx_all        RCTA,
       ra_cust_trx_types_all      RCTTA,
       ar_payment_schedules_all   APSA,
       oe_order_headers_all       OOHA,
       hz_cust_accounts           HCA,
       oe_transaction_types_tl    OTTT,
       ra_batch_sources_all       rbsa
       WHERE RCTA.attribute2 = TO_CHAR (MOC.consignment_id)
       AND RCTA.interface_header_attribute1 = TO_CHAR (OOHA.order_number(+))
       AND RCTA.customer_trx_id = APSA.customer_trx_id
       AND RCTA.sold_to_customer_id = HCA.cust_account_id(+)
       AND RCTA.cust_trx_type_id = RCTTA.cust_trx_type_id
       AND OOHA.order_type_id = OTTT.transaction_type_id(+)
       AND OTTT.LANGUAGE(+) = USERENV ('LANG')
       AND moc.consignment_id = '{DATAPREP['consignment_id']}'
       AND rbsa.batch_source_id = rcta.batch_source_id
       AND rbsa.name like  '%AUTOMATION'"""
  rows = ORACLE_DB(qry)
  if (GetVarType(rows)== VarToInt(9) and len(rows) > 0 ):
      return rows
  else:
     import traceback 
     __ERROR = tc_logs.error_with_no_picture
     __ERROR("MANARBB workflow didn't Failed")
     
def get_floor_plan_status():
  tc_logs.test_data("----- Floor Plan Information from Floor Plan Table from Oracle DB -----")
  try:
    qry = f"""SELECT MAFPW.wf_stage               FLOOR_PLAN_WF_STAGE,
                     MAFPW.transaction_amount     FLOOR_PLAN_AMOUNT,
                     DECODE (MAFPW.status,'H', 'Hold' , 'U','Unwind', 'A', 'Approved')                 FLOOR_PLAN_STATUS
              FROM   manar.man_ar_flrpln_wf MAFPW
             WHERE   MAFPW.consignment_id ='{DATAPREP['consignment_id']}'  """
    rows = ORACLE_DB(qry)
    if (GetVarType(rows) == VarToInt(9)) and len(rows)>0:
      for row in rows:
        tc_logs.checkpt_with_no_picture(f"Floor Plan Current Stage:  {row['FLOOR_PLAN_WF_STAGE']}")
        tc_logs.checkpt_with_no_picture(f"Floor Plan Current Status: {row['FLOOR_PLAN_STATUS']}")
        tc_logs.checkpt_with_no_picture(f"Floor Plan Amount: {row['FLOOR_PLAN_AMOUNT']}")
  
  except Exception as e:
    Log.Message(traceback.format_exc())
    
def get_floor_trx_non_dtls():
  tc_logs.test_data("----- Floor Plan Information from Floor Plan Table from Oracle DB -----")
  try:
    tc_logs.checkpt_with_no_picture(f"Assurance Order Number  : {DATAPREP['assurance_order']}")
    qry = f"""SELECT rctla.CUSTOMER_TRX_ID     "assurance_invoice_id"
                  , rctla.line_number         "assurance_line_num"
                FROM ra_customer_trx_all rcta, ra_customer_trx_lines_all rctla
               WHERE rcta.CUSTOMER_TRX_ID  = rctla.customer_trx_id
               AND   rcta.attribute2 ='{DATAPREP['consignment_id']}'  
               AND   rcta.interface_header_attribute1 = '{DATAPREP['assurance_order']}'
               FETCH FIRST ROW ONLY """
    rows = ORACLE_DB(qry)
    if (GetVarType(rows) == VarToInt(9)) and len(rows)>0:
      for row in rows:
        tc_logs.checkpt_with_no_picture(f"Assurance Invoice Id:  {row['assurance_invoice_id']}")
        tc_logs.checkpt_with_no_picture(f"Assurance Line Num  : {row['assurance_line_num']}")
        DATAPREP['assurance_invoice_id'] = row['assurance_invoice_id']
        DATAPREP['assurance_line_num']   = row['assurance_line_num']
  
  except Exception as e:
    Log.Message(traceback.format_exc()) 
 
     
def ng_seller_fp_data():
  qry = """SELECT hca.account_number,
       HP.party_name,
       mafw.consignment_id,
       mafw.status,
       moca.vin, 
       'Floorplan Approved'   floor_plan_status, 
       moca.purchase_location_code      
  FROM hz_cust_accounts           HCA,
       hz_parties                 HP,
       manar.man_ar_flrpln_wf     MAFW,
       manar.man_om_consignments  moca
  WHERE     HCA.customer_class_code = 'FLOORPLAN AGENCY'
       AND HP.party_id = hca.party_id
       AND HCA.status = 'A'
       AND HCA.cust_account_id = MAFW.agency_account_id
       AND moca.consignment_id = mafw.consignment_id
       AND MAFW.status IN ('A')
       AND HP.PARTY_NAME LIKE '%NEXT%GEA%'
       AND EXISTS ( SELECT '1'
                    FROM ra_customer_trx_all rcta 
                    WHERE rcta.attribute_category like 'US BUYER' 
                    AND    rcta.attribute3 like 'Floor%Appro%'
                    AND    rcta.attribute2 = to_char(mafw.consignment_id)
                   )
       AND EXISTS (  SELECT  '1'
                       FROM  oe_order_headers_all ooha
                      WHERE  ooha.context like 'US ASSURANCE%'
                        AND  ooha.attribute2 = to_char(mafw.consignment_id)
                  )
       AND NOT EXISTS ( SELECT 1
                        FROM   manar.man_om_consign_adjustments moca
                        WHERE  moca.consignment_id = mafw.consignment_id )
       AND mafw.creation_date >= sysdate-365
       Fetch First 1 rows only"""

  rows = ORACLE_DB(qry)
  if (GetVarType(rows) == VarToInt(9)) and len(rows)>0:
    DATAPREP['auction'] = rows[0]['PURCHASE_LOCATION_CODE']
    DATAPREP['vin'] = rows[0]['VIN']
    DATAPREP['consignment_id'] = rows[0]['CONSIGNMENT_ID']
    CHECK_POINT(f" AUCTION   : '{DATAPREP['auction']}' ") 
    CHECK_POINT(f" VIN : '{DATAPREP['vin']}' ")
    CHECK_POINT(f" CONSIGNMENT ID   : '{DATAPREP['consignment_id']}' ") 
    return rows
  else:
     import traceback 
     __ERROR = tc_logs.error_with_no_picture
     __ERROR("No data returned. Please check query")

def get_consignment_details():
  qry = f"""SELECT  ooha.header_id
            , ooha.order_number
            , ooha.flow_status_code
            , otta.name order_type
            , ooha.open_flag
            , ooha.cancelled_flag
            , nvl(moc.sale_date , ooha.creation_date) sale_date
            , oos.name                        order_source_name
            , ooha.orig_sys_document_ref      order_source_reference
            , hca_bill.cust_account_id        bill_to_customer_id
            , hca_bill.account_number         bill_to_customer_number
            , hca_bill.account_name           bill_to_customer_name
            , hca_bill.attribute15            bill_to_group_code
            , hcsua_sold_to.cust_account_id   sold_to_customer_id
            , hcsua_sold_to.account_number    sold_to_customer_number
            , hcsua_sold_to.account_name      sold_to_customer_name
            , hcsua_sold_to.attribute15       sold_to_group_code
            , nvl( moc.purchase_location_code, ( SELECT hcasa.attribute1
                                          FROM hz_cust_acct_sites_all hcasa, hz_cust_site_uses_all hcsua
                                          WHERE hcsua.site_use_id = ooha.ship_to_org_id
                                          AND hcsua.cust_acct_site_id = hcasa.cust_acct_site_id
                                          AND hcsua.site_use_code = 'SHIP_TO'
                                          AND hcsua.status = 'A'
                                         ) ) purchase_location_code
            , jrre.attribute2        auction_num
            , jrret.resource_name    sales_rep_name
            , moc.sold_flag
            , ooha.context
            , ooha.attribute1        ods_service_order_id
            , ooha.attribute2        consignment_id
            , ooha.attribute4        vin
            , ooha.attribute15       business_unit
            , ooha.attribute16       late_fee_exempt
            , ooha.attribute12       sales_channel
            , ooha.attribute14       sales_type
            , ooha.attribute6        auction_format
            , ooha.attribute8        lease_account_nr
            , ooha.attribute13       lease
            , ooha.ATTRIBUTE7        Independent_Auction
            , ooha.ATTRIBUTE9        Operator
            , ooha.ATTRIBUTE10       third_party_remarketer
            , ooha.ATTRIBUTE11       vehicle_offsite
            , ooha.attribute20       Order_Exception_Status
            FROM   oe_order_headers_all         OOHA
            , oe_transaction_types_tl      OTTA
            , oe_order_sources             OOS
            , manar.man_om_consignments    MOC
            , jtf_rs_salesreps             JRS
            , jtf_rs_resource_extns        JRRE
            , jtf_rs_resource_extns_tl     JRRET
            , hz_cust_accounts             HCA_BILL
            , hz_cust_acct_sites_all       HCASA_BILL_TO
            , hz_cust_site_uses_all        HCSUA_BILL_TO
            , hz_cust_accounts             HCSUA_SOLD_TO
            WHERE moc.consignment_id                 = to_number(nvl(ooha.attribute2,0))
            AND    ooha.order_type_id                    = otta.transaction_type_id
            AND    ooha.order_source_id                  = oos.order_source_id
            AND   jrs.salesrep_id                        = ooha.salesrep_id
            AND   jrre.resource_id                       = jrs.resource_id
            AND   jrret.resource_id                      = jrre.resource_id
            AND   otta.language                          = USERENV ('LANG')
            AND   jrret.language                         = USERENV ('LANG')
            AND   ooha.invoice_to_org_id                 = hcsua_bill_to.site_use_id
            AND   hcsua_bill_to.cust_acct_site_id        = hcasa_bill_to.cust_acct_site_id
            AND   hcasa_bill_to.cust_account_id          = hca_bill.cust_account_id
            AND   ooha.sold_to_org_id                    = hcsua_sold_to.cust_account_id
            AND   ooha.context in ('US BUYER', 'US SELLER')
            AND   ooha.attribute2 ='{DATAPREP['consignment_id']}'      """
  rows = ORACLE_DB(qry)
  if (GetVarType(rows) == VarToInt(9)) and len(rows)>0:
    DATAPREP['buyer'] = rows[0]['BILL_TO_CUSTOMER_NUMBER']
    DATAPREP['seller'] = rows[1]['BILL_TO_CUSTOMER_NUMBER'] 
    return rows
  else:
    import traceback 
    __ERROR = tc_logs.error_with_no_picture
    __ERROR("No data returned. Please check query")
