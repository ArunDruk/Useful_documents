﻿from dbhelper import *
from ebiz import *
import web_utils
import dbhelper
import file_system_utils 

class tc97750cai_us_create_project_asset(Ebiz):
  op_log_path="C:\\Tc_Logs"

  def login(self):
     self.login_user='rmaran'
     super().login()
   
  def action(self,book): 
     global rowno
     rowno = 2
     app1 = book.Sheets.item["Requisition"]
     app = book.Sheets.item["PA-FA"] 
     
     web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" PA PROJECT CAPITALIZATION')]") 
     self.log_message_web("Click 'CAI "+self.oper_unit+" PA PROJECT CAPITALIZATION' - Successful")  
     self.wait_until_page_loaded()
     Delay(2000)
     web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Capitalization')]")
     self.log_message_web("Click 'CAPITALIZATION' - Successful")
     Delay(2000)
     self.wait_until_page_loaded() 
     web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Capital Projects')]") 
     self.log_message_web("Click ''Capital Projects' - Successful")   
     Delay(2000)
     
     self.wait_until_page_loaded()
     Delay(5000)
#     web_utils.validate_security_box()
#     Delay(2000)
     jFrame= self.initializeJFrame()
     Delay(2000)
     form_utils.click_ok_btn(jFrame)
     
     self.log_message_oracle_form( jFrame,"Find Capital Projects form launched successfully")
     Delay(4000)
     
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Find Capital Projects","ExtendedFrame"]
     findcapitalprojects_form=jFrame.FindChildEx(prop,val,60,True,90000)
     self.verify_aqobject_chkproperty(findcapitalprojects_form,"AWTComponentAccessibleName",cmpContains,"Find Capital Projects")
     
     findcapitalprojects_form.Find("AWTComponentAccessibleName","Project: NumberList of Values",10).SetText(app1.Cells.item[rowno,11])
     self.log_message_oracle_form(jFrame,"Project Number Entered in Capital Projects screen is : "+ VarToStr(app1.Cells.item[rowno,11]))
     findcapitalprojects_form.Keys("[Tab]")
     findcapitalprojects_form.Keys("[Tab]")
     Delay(3000)
     findcapitalprojects_form.Find("AWTComponentAccessibleName","Find alt i",10).Click()
     Delay(3000)
     
     self.verify_aqobject_chkproperty(findcapitalprojects_form,"AWTComponentAccessibleName",cmpContains,"Capital Projects")
     self.log_message_oracle_form(jFrame,"Capital Projects Details page launched successfully")
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Capital Projects (CAI SHARED SERVICES OU)","ExtendedFrame"]
     capitalprojects_form=jFrame.FindChildEx(prop,val,60,True,90000)
     
     prop = ["AWTComponentAccessibleName","AWTComponentIndex","JavaClassName"]
     val = ["CIP","40","VTextField"]
     cip_value = capitalprojects_form.FindChild(prop,val,30).wText
     if(VarToFloat(cip_value) <= 0.00):
       self.log_error_message(f"CIP: {cip_value}. CIP is not positive")
       
     capitalprojects_form.Find("AWTComponentAccessibleName","Assets alt A",10).Click()  
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=[" Assets*","ExtendedFrame"]
     asset_form=jFrame.FindChildEx(prop,val,60,True,40000)
     Delay(2000) 
     while not asset_form.Exists:
       Delay(2000)
       asset_form=jFrame.FindChild(prop,val,60)
     self.log_message_oracle_form(jFrame,"Assets Form launched successfully")       
     Delay(2000) 
     #self.verify_aqobject_chkproperty(asset_name,"AWTComponentAccessibleName",cmpContains,"Assets*")
     self.verify_aqobject_chkproperty(asset_form,"AWTComponentAccessibleName",cmpContains,f" Assets (CAI SHARED SERVICES OU) - {VarToStr(app1.Cells.item[rowno,11])}")
     Delay(2000)
     asset_form.Find("AWTComponentAccessibleName","Open alt O",10).Click() 
     Delay(2000)  

     self.log_message_oracle_form(jFrame,"Asset Details Form launched successfully")
     Delay(1000)
     
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Asset Details (CAI SHARED SERVICES OU)*","ExtendedFrame"]
     asset_details_form=jFrame.FindChildEx(prop,val,60,True,40000)
     #self.verify_aqobject_chkproperty(asset_name,"AWTComponentAccessibleName",cmpContains,"Asset Details (CAI SHARED SERVICES OU)*")
     self.verify_aqobject_chkproperty(asset_details_form,"AWTComponentAccessibleName",cmpContains,f"Asset Details (CAI SHARED SERVICES OU) - {VarToStr(app1.Cells.item[rowno,11])}, ")
     
     asset_name=asset_details_form.Find("AWTComponentAccessibleName", "Asset Name Required",10)
     asset_name.Click()
     ast_name="TST_Asset: "+aqConvert.DateTimeToFormatStr(aqDateTime.Time(),"%H:%M")
     asset_name.Keys(ast_name)
     self.log_message_oracle_form( jFrame,"Asset Name is : "+VarToStr(ast_name))
     Delay(2000)
     
     
     desc=asset_details_form.Find("AWTComponentAccessibleName", "Description RequiredList of Values",10)
     desc.Click()
     ast_desc="TST_Asset: "+aqConvert.DateTimeToFormatStr(aqDateTime.Time(),"%H:%M")
     desc.Keys(ast_desc)
     self.log_message_oracle_form( jFrame,"Asset Description Entered is "+VarToStr(ast_desc))
     Delay(2000)
     
     Asset_Cat=asset_details_form.Find("AWTComponentAccessibleName", "Asset CategoryList of Values",10)
     Asset_Cat.Click()
     Asset_Cat.SetText(app.cells.Item[rowno,4])
     self.log_message_oracle_form( jFrame,"Asset Category Entered is : "+ VarToStr(app.Cells.item[rowno,4]))
     Delay(2000)
     
     Asset_key=asset_details_form.Find("AWTComponentAccessibleName", "Asset KeyList of Values",10)
     Asset_key.Click()
     jFrame.keys("~o")
     Delay(2000)
     Asset_key.SetText(app.cells.Item[rowno,5])
     self.log_message_oracle_form( jFrame,"Assets Key Value Entered is : "+ VarToStr(app.Cells.item[rowno,5]))
     Delay(2000)
     
     BookList_Values=asset_details_form.Find("AWTComponentAccessibleName", "BookList of Values",10)
     BookList_Values.Click()
     BookList_Values.SetText(app.cells.Item[rowno,6])
     Delay(2000)
     self.log_message_oracle_form( jFrame,"Assets Book Entered is : "+ VarToStr(app.Cells.item[rowno,6]))
     
     Loc_Values=asset_details_form.Find("AWTComponentAccessibleName", "LocationList of Values",10)
     Loc_Values.Click()
     Loc_Values.SetText(app.cells.Item[rowno,7])
     self.log_message_oracle_form( jFrame,"Assets Location Entered is : "+ VarToStr(app.Cells.item[rowno,7]))
         
     asset_details_form.Keys("[Tab]")
     Delay(2000)
     prop = ["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
     val = ["Project Asset Type RequiredList of Values","VTextField",7]
     asset_details_form.Find(prop,val,10).SetText(app.cells.Item[rowno,8])
     asset_details_form.Find(prop,val,10).Click()  
     Delay(2000)
     self.log_message_oracle_form(jFrame,"Project Assets Value Entered is : "+ VarToStr(app.Cells.item[rowno,8])) 

     asset_details_form.Keys("[Tab]")
     Delay(2000)

     asset_details_form.Find("AWTComponentAccessibleName", "Date In Service: EstimatedList of Values",10).Click() 
     asset_details_form.Find("AWTComponentAccessibleName", "Date In Service: EstimatedList of Values",10).SetText(aqConvert.DateTimeToFormatStr(aqDateTime.Today(),"%d-%b-%Y"))
     Delay(2000)
     jFrame.Keys("[Tab]")
     jFrame.Keys("[Tab]")
     asset_details_form.Find("AWTComponentAccessibleName", "Date In Service: ActualList of Values",10).Click() 
     asset_details_form.Find("AWTComponentAccessibleName", "Date In Service: ActualList of Values",10).SetText(aqConvert.DateTimeToFormatStr(aqDateTime.Today(),"%d-%b-%Y"))
     delay(1000)

     Actual_unit=asset_details_form.Find("AWTComponentAccessibleName", "Actual Units",10)
     Actual_unit.Click()
     Actual_unit.SetText(app.cells.Item[rowno,10])
     Delay(2000)
     self.log_message_oracle_form( jFrame," Actual Units Entered is : "+ VarToStr(app.Cells.item[rowno,10])) 
     
     Depreciation_Acct=asset_details_form.Find("AWTComponentAccessibleName", "Depreciation  AccountList of Values",10)
     Depreciation_Acct.Click()
     Depreciation_Acct.SetText(app.cells.Item[rowno,11])
     self.log_message_oracle_form( jFrame," Assets Depreciation Entered is : "+ VarToStr(app.Cells.item[rowno,11]))
     Delay(4000)
     
     jFrame.keys("~f")
     Delay(2000)
     jFrame.keys("s")
     Delay(2000)
     jFrame.keys("^s")
     Delay(2000)
     jFrame.keys("~s")
     Delay(2000)
     jFrame.keys("~p")
     Delay(2000)
     self.log_message_oracle_form(jFrame,"Assets Number " +ast_name+ " assigned to a Project " +VarToStr(app1.Cells.item[rowno,11])+ "successfully")
#     jFrame.keys("^s")
#     Delay(3000)
#
#     Delay(1000)
#     jFrame.Close()
#     delay(1000)
#     jFrame.Keys("~o")

     jFrame.keys("~f")
     Delay(2000)
     jFrame.keys("s")
     Delay(2000)
     
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Assign Assets*","ExtendedFrame"]
     assign_assets_form=jFrame.FindChildEx(prop,val,60,True,20000)
     delay(2000)
     assign_assets_form.Close()
     delay(3000)
     asset_details_form.Close()
     delay(3000)
     web_utils.log_checkpoint("Create Project Asset is done successfully",500,jFrame)
     delay(2000)
     jFrame.Close()
     delay(3000)
     jFrame.Keys("~o")

     
#def test():
#
#     jFrame = Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1)
#     prop=["AWTComponentAccessibleName","JavaClassName"]
#     val=["Asset Details (CAI SHARED SERVICES OU)*","ExtendedFrame"]
#     asset_details_form=jFrame.FindChild(prop,val,60)
#     Loc_Values=asset_details_form.Find("AWTComponentAccessibleName", "LocationList of Values",10)
#     Loc_Values.Click()
#     Loc_Values.SetText("700 NE MULTNOMAH STREET.SUITE 810.PORTLAND.MULTNOMAH.OR.US")
##     self.log_message_oracle_form( jFrame,"Assets Location Entered is : "+ VarToStr(app.Cells.item[rowno,7]))    
#     asset_details_form.Keys("[Tab]")
#     Delay(2000)
#     prop = ["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
#     val = ["Project Asset Type RequiredList of Values","VTextField",7]
#
#     asset_details_form.Find(prop,val,10).SetText("As-Built")
#     asset_details_form.Find(prop,val,10).Click()
##     asset_details_form.Find("AWTComponentAccessibleName", "Project Asset Type RequiredList of Values",10).Click()
#     Delay(2000)
##     self.log_message_oracle_form( jFrame," Project Assets Value Entered is : "+ VarToStr(app.Cells.item[rowno,8])) 
##     asset_details_form.Find("AWTComponentAccessibleName", "Project Asset Type RequiredList of Values",10).Keys("[Tab]")
##     Delay(1000)
#     asset_details_form.Keys("[Tab]")
#     Delay(2000)
##     Date_inservice=asset_details_form.Find("AWTComponentAccessibleName", "Date In Service: ActualList of Values",10)
##     Date_inservice.Click()
##     Date_inservice.SetText(aqConvert.DateTimeToFormatStr(aqDateTime.Today(),"%d-%b-%Y"))
#     asset_details_form.Find("AWTComponentAccessibleName", "Date In Service: EstimatedList of Values",10).Click() 
#     asset_details_form.Find("AWTComponentAccessibleName", "Date In Service: EstimatedList of Values",10).SetText(aqConvert.DateTimeToFormatStr(aqDateTime.Today(),"%d-%b-%Y"))
#     Delay(2000)
#     jFrame.Keys("[Tab]")
#     jFrame.Keys("[Tab]")
#     asset_details_form.Find("AWTComponentAccessibleName", "Date In Service: ActualList of Values",10).Click() 
#     asset_details_form.Find("AWTComponentAccessibleName", "Date In Service: ActualList of Values",10).SetText(aqConvert.DateTimeToFormatStr(aqDateTime.Today(),"%d-%b-%Y"))
#     delay(1000)
