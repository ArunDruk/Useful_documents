﻿import dbhelper
from ebiz import *
import web_utils
import file_system_utils 
import form_utils

                        
class tc202036_us_validate_prc_nightly_request_set(Ebiz):
   op_log_path="C:\\Tc_Logs"
                        
   def login(self):
     self.login_user='pkjami'
     super().login()
     
   def goto_url(self,url):
    super().goto_url(self.testConfig['ebiz']['oci_is_url'])
                           
   def action(self,book): 
     global rowno      
     rowno = 2            
     app = book.Sheets.item["Requisition"]
     app1 = book.Sheets.item["Project"]    
     RequestID = app.Cells.item[rowno,19]
     proj_num = app1.Cells.Item[rowno,11]
     web_utils.log_checkpoint("Logged in to Oracle Applications Home Page Successfully",500,self.page)
     self.wait_until_page_loaded()       
     self.page.EvaluateXPath("//table[@id='menuContent']//div[contains(text(),'PC User')]")[0].scrollIntoView()
     self.page.EvaluateXPath("//table[@id='menuContent']//div[contains(text(),'PC User')]")[0].Click()
     web_utils.log_checkpoint("Click 'PC User' - Successful",500,self.page) 
     self.wait_until_page_loaded()
     delay(1000)
     self.page.NativeWebObject.Find("contentText","Other","A").Click()
     web_utils.log_checkpoint("Click 'Other' - Successful",500,self.page) 
     self.wait_until_page_loaded()
     delay(1000)
     self.page.Keys("[Down]")
     self.page.NativeWebObject.Find("contentText","Requests","A").scrollIntoView()
     self.page.NativeWebObject.Find("contentText","Requests","A").Click()
     web_utils.log_checkpoint("Click 'Requests' - Successful",500,self.page)
     self.wait_until_page_loaded()
     delay(1000)
     self.page.NativeWebObject.Find("contentText","Run","A").Click()
     web_utils.log_checkpoint("Click 'Run' - Successful",500,self.page)
     Delay(10000)
     web_utils.validate_security_box()
     Delay(10000)
     jFrame=self.initializeJFrame()
     Delay(3000)
     form_utils.click_ok_btn(jFrame)  
     Delay(10000)
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Submit a New Request","ExtendedFrame"]
     jFrame.FindChildEx(prop,val,40,True,90000)
     Delay(2000)
     jFrame.keys("~c")
     Delay(2000)
     jFrame.Keys("~v")
     Delay(2000)
     jFrame.Keys("r")
     Delay(2000)
     jFrame.Keys("~i")
     Delay(2000) 
     web_utils.log_checkpoint("Launched Find Requests Form Succeessfully",500,jFrame)
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Requests","ExtendedFrame"]
     req_form=jFrame.FindChildEx(prop,val,30,True,40000)  
     web_utils.log_checkpoint("Parent Request ID: "+VarToStr(RequestID),500,jFrame) 
     Delay(2000)
     self.req_set_save_output(jFrame,req_form,"PRC: Generate Cost Accounting Events",RequestID)
     Delay(1000)
     jFrame.Keys("~w") 
     Delay(2000)
     jFrame.Keys("2") 
     self.req_set_save_output(jFrame,req_form,"PRC: Distribute Supplier Cost Adjustments",RequestID)  #form_utils.req_set_save_output(self,jFrame,req_form,"PRC: Distribute Supplier Cost Adjustments",RequestID) #self.req_set_save_output(jFrame,req_form,"PRC: Distribute Supplier Cost Adjustments") 
     Delay(1000)
     jFrame.Keys("~w") 
     Delay(2000)
     jFrame.Keys("2")
     self.req_set_save_output(jFrame,req_form,"PRC: Distribute Usage and Miscellaneous Costs",RequestID)
     Delay(1000)
     
     jFrame.Keys("~w") 
     Delay(1000)
     jFrame.Keys("2")
     self.req_set_save_output(jFrame,req_form,"PRC: Distribute Labor Costs",RequestID)  
     Delay(1000)
     jFrame.Keys("~w") 
     Delay(1000)
     jFrame.Keys("2")
     self.req_set_save_output_sup_costs_intf_audt(jFrame,req_form,"AUD: Supplier Costs Interface Audit")
     Delay(1000)
     jFrame.Keys("~w") 
     Delay(1000)
     jFrame.Keys("[Down]")
     jFrame.Keys("[Down]")
     jFrame.Keys("[Down]")
     jFrame.Keys("[Down]")
     Delay(1000)
     jFrame.Keys("[Enter]")
     Delay(1000)
     jFrame.Keys("[F4]")
     Delay(3000)
     
##Commented as part of stabilization(Validation from backend instead of front end form validation)    
## Navigate to Expenditure Enquiry:

#     prop2=["AWTComponentName","JavaClassName"]
#     val2 = ["LWDataSourceList$Content224","LWDataSourceList$Content"]
##     navigator = jFrame.FindChild(prop2,val2,30)
#     navigator =  Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("ExtendedFrame", "Navigator - PC User", 4).AWTObject("LWComponent", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("FScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("DrawnPanel", "", 0).AWTObject("FormsTabPanel", "", 0).AWTObject("TabPanelSheet", "", 0).AWTObject("FScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("DrawnPanel", "", 0).AWTObject("VTList", "Function List", 0).AWTObject("ScrollBox", "", 0).AWTObject("LWDataSourceList$Content", "", 0)
#     Sys.HighlightObject(navigator)
#     OCR.Recognize(navigator).BlockByText("Expenditures").DblClick()
#     delay(1000)
#     OCR.Recognize(navigator).BlockByText("Expenditure Inquiry").DblClick()  
#     delay(1000)
#     web_utils.log_checkpoint("Closing Request Form & Navigating to Expenditures > Expenditure Inquiry > Projects",500,jFrame)
##     OCR.Recognize(navigator).BlockByText("Project").DblClick()
##     jFrame.Keys("[Down]")
##     delay(1000)
#     jFrame.Keys("[Enter]")
#
#
#     Delay(3000)
#     prop=["AWTComponentAccessibleName","JavaClassName"]
#     val=["Find Project Expenditure Items","ExtendedFrame"]
#     proj_exp_form=jFrame.FindChildEx(prop,val,30,True,40000) 
#     proj_exp_form.Find("AWTComponentAccessibleName","Project NumberList of Values",20).keys(app.Cells.item[rowno,11])
#     self.log_message_oracle_form( jFrame,"Entered Project Number in Project Expenditure Items screen : "+ VarToStr(app.Cells.item[rowno,11])) 
#     self.verify_aqobject_chkproperty(proj_exp_form,"AWTComponentAccessibleName",cmpContains,"Find Project Expenditure Items")
#     Delay(2000)
#  
#     jFrame.keys("~i")
#     val=["Project Expenditure Items","ExtendedFrame"]
#     exp_items=jFrame.FindChildEx(prop,val,30,True,40000) 
#     Sys.HighlightObject(exp_items)
#     self.log_message_oracle_form( jFrame,"View Project Expenditure Items Screen Successful")
#     Delay(5000)
#     
#     for i in range(0,3):
#         prop3 = ["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]  
#         val3 = ["Employee/Supplier","VTextField",50+i]
#         supp_emp_box = jFrame.FindChild(prop3,val3,30)
#         supplier_det = supp_emp_box.wText
#         prop = ["AWTComponentAccessibleName","JavaClassName"]
#         val = ["Item Details","ExtendedFrame"]
#         item_details = jFrame.FindChild(prop,val,30)
#         if supplier_det == "":
#             supp_emp_box.Click()
#             self.validate_cost_dist(jFrame,i)
#         else:
#             supp_emp_box.Click()
#             self.validate_cost_dist(jFrame,i)
#             delay(1000)
#             jFrame.keys("~d")
#             delay(2000)
#             jFrame.keys("a")
#             Delay(3000)
#             jFrame.keys("~o")
#             Delay(7000)
#             self.log_message_oracle_form( jFrame,"Invoice Details Verified for Supplier Expenses")
#             jFrame.Keys("~w")
#             delay(1000)
#             jFrame.Keys("3")
#             delay(1000)
#             if item_details.Exists:
#               jFrame.Keys("~c")
#         i+=1
#
##     jFrame.Close()
##     delay(3000)
##     self.log_message_oracle_form(jFrame,"Successfully applied close action - Java Forms")
##     prop = ["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
##     val = ["Caution Exit Oracle Applications?","ChoiceBox",0]
##     if jFrame.FindChild(prop,val,20).Exists:
##       self.log_message_oracle_form(jFrame,"Forms Closing Confirmation window found")
##       jFrame.Keys("~o")
##       
##     else:
##       self.log_error_message("Forms Closing Confirmation window not found")
     self.close_forms(jFrame)  
     Delay(2000)
     web_utils.close_additional_browsers()
     #Sys.Browser("iexplore").page("https://core-*.epfinnp.coxautoinc.com/forms/frmservlet*").Close()
     del app,app1,jFrame,rowno,
     
     dsn = self.testConfig['man_oracle_db']['dsn']
     user_id = self.testConfig['man_oracle_db']['userid']
     pwd = self.testConfig['man_oracle_db']['pwd']
     approval_status = dbhelper.verify_exp_batch_details_by_project(dsn,user_id,pwd,VarToStr(proj_num))
     web_utils.log_checkpoint("Cost distribution flag Validated Successfully for all expenditure items",500,'')      
                           
   def validate_cost_dist(self,jFrame,i):
         delay(1000)
         jFrame.Keys("~d")
         self.log_message_oracle_form(jFrame,"Click Item Details Button on Project Expenditure Items Screen Successful")
         delay(2000)
         prop = ["AWTComponentAccessibleName","JavaClassName"]
         val = ["Item Details","ExtendedFrame"]
         item_details = jFrame.FindChild(prop,val,30)
         Sys.HighlightObject(item_details)
         jFrame.keys("c")
         delay(1000)
         jFrame.keys("~o")
         Delay(2000)
         self.log_message_oracle_form( jFrame,"Cost Distribution Lines Displayed for line :"+VarToStr(i+1))
         jFrame.Keys("~w")
         delay(1000)
         jFrame.Keys("3")
         delay(2000)
         if item_details.Exists:
           jFrame.Keys("~c")
           
   def submit_req_set_params(self,submitrequest_form,jFrame,index_no,proj_no,tab,proj2,enddate,servdate,padate,proj3):
     prop=["AWTComponentAccessibleName","AWTComponentIndex"]
     val=["Parameters",index_no]
     submitrequest_form.FindChild(prop,val,60).Click()
     Delay(2000)   
     prop=["AWTComponentAccessibleName","JavaClassName"]
     val=["Parameters","FlexWindow"]   
     parameter_form=jFrame.FindChild(prop,val,10)
     end_date = self.get_month_end()
     if tab == 'Y':
       parameter_form.Keys("[Tab]")
       val=["Project Number List Values","FlexTextField"]
       project_no = parameter_form.FindChild(prop,val,10)
       project_no.Keys(proj_no)
     elif tab == 'S':
       val=["Project Number List Values","FlexTextField"]
       project_no = parameter_form.FindChild(prop,val,10)
       project_no.Keys(proj_no)
#     parameter_form.Keys("~o")
     if proj2 == 'Y':
        val=["From Project Number*","FlexTextField"]
        project_from = parameter_form.FindChild(prop,val,10)
        project_from.click()
        project_from.Keys("^a[Del]")
        project_from.Keys(proj_no)
        val=["To Project Number*","FlexTextField"]
        project_to = parameter_form.FindChild(prop,val,10)
        project_to.click()
        project_to.Keys("^a[Del]")
        project_to.Keys(proj_no)
#        parameter_form.Keys("~o")
     if proj3 == 'Y':
        val = ["Project Number REQUIRED*","FlexTextField"]
        project_from = parameter_form.FindChild(prop,val,10)
        project_from.click()
        project_from.Keys("^a[Del]")
        project_from.Keys(proj_no)
        val=["To Project Number*","FlexTextField"]
        project_to = parameter_form.FindChild(prop,val,10)
        project_to.click()
        project_to.Keys("^a[Del]")
        project_to.Keys(proj_no)
     if enddate == 'Y':
        val=["End Date REQUIRED*","FlexTextField"]
        end_dt = parameter_form.FindChild(prop,val,10)
        end_dt.click()
        end_dt.Keys("^a[Del]")
        end_dt.Keys(end_date)
     if servdate == 'Y':
        val=["Date Placed In Service Through*","FlexTextField"]
        serv_date = parameter_form.FindChild(prop,val,10)
        serv_date.click()
        serv_date.Keys(end_date)
     if padate == 'Y':
        val=["PA Through Date REQUIRE*","FlexTextField"]
        pa_date = parameter_form.FindChild(prop,val,10)
        pa_date.click()
        pa_date.Keys(end_date)
     parameter_form.Keys("~o")   
     Delay(1000)

                        
   def req_set_save_output(self,jFrame,req_form,srch_child_name,Preqid):
     i=20
     jFrame.Keys("~r")
     for x in range(i,100):
#US545181: Fix QA Automation: MAN STAGE - E2E_Scenario_24: Added Steps to capture Request Output from 
#Request Set containing more than 10 requests
#Action below mimics clicking Down button to go to more Requests in View Requests screen
       if i==30:
          jFrame.Keys("[Down]")
          Delay(1000)
          i =29
       else:
          jFrame.Keys("[Down]")
#US545181: Fix QA Automation: MAN STAGE - E2E_Scenario_24: End of Added Code

       prop=["AWTComponentAccessibleName","AWTComponentIndex"]
       val=["Name",i]
       childname=req_form.Find(prop,val,10)
#       child_name.Keys("[Enter]")
       childname.Click()
       child_name=childname.wText
          
#US545181: Fix QA Automation: MAN STAGE - E2E_Scenario_24: Below existing code was commented as it was not working
#       if i==29:
##          prop1=["JavaClassName","AWTComponentIndex"]
##          val1=["ContinuousButton",0]
##          drop_btn = jFrame.FindChild(prop1,val1,60)
#          drop_btn =  Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications - EBS", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("ExtendedFrame", "Requests", 26).AWTObject("LWComponent", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("FScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("DrawnPanel", "", 0).AWTObject("FScrollBox", "", 2).AWTObject("ScrollBox$1", "", 0).AWTObject("DrawnPanel", "", 0).AWTObject("LWScrollbar", "", 0).AWTObject("ContinuousButton", "", 0)
#          Delay(10000)
#          Sys.HighlightObject(drop_btn)
#          Delay(10000)
#          drop_btn.Click()
#          Delay(10000)
#          i =28
#       else:
#          jFrame.Keys("[Down]")
#US545181: Fix QA Automation: MAN STAGE - E2E_Scenario_24: End of commented code
          
       Delay(1000)
       prop=["AWTComponentAccessibleName","AWTComponentIndex"]
       val=["Phase",i+20]
       phase=req_form.Find(prop,val,10).wText 
       prop=["AWTComponentAccessibleName","AWTComponentIndex"]
       val=["Request ID",i-10]
       creqid=VarToInt(req_form.Find(prop,val,10).wText) 
#       i+=1  
       if (child_name==srch_child_name) and (creqid >= VarToInt(Preqid)) and (phase == "Completed"):
#         Delay(500)
#         req_form.Find(prop,val,10).Keys("[Enter]")
         prop=["AWTComponentAccessibleName","AWTComponentIndex"]
         val=["Name",i]
         childname=req_form.Find(prop,val,10)
         childname.Click()
         Delay(600)
         prop=["AWTComponentAccessibleName","JavaClassName"]
         val=["View Output alt p","Button"]
         output_button=req_form.FindChild(prop,val,60)
         output_button.Find("AWTComponentAccessibleName","View Output alt p").Click()         
         #jFrame.Keys("~p")    
         Delay(3000)
         output_page=Sys.Browser("iexplore").Page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")            
         output_page.Click()
         Delay(2000)
         output_page.Keys("~f")
         Delay(6000)
         output_page.Keys("a")
         Delay(6000)
         file_system_utils.create_folder(self.op_log_path)             
         log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"Is Attached_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
         Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
         Delay(1000)
         Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
         Delay(2000)
         Log.Enabled=True
         Log.File(log_path, aqConvert.VarToStr(srch_child_name)+" Program is completed and Output File Is Attached")
         Log.Enabled=False       
         Sys.Browser("iexplore").page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close()  
         Delay(2000)   
#         jFrame.Click()
         Delay(2000)
         val=["Name",20]
         req_form.Find(prop,val,10).Keys("[Enter]")
         Delay(500)
         break  
       i+=1
                        
                        
   def req_set_save_output_sup_costs_intf_audt(self,jFrame,req_form,srch_child_name):
       i=20
       found=0     
       for x in range(20,51):
         if x>29:
            jFrame.Keys("[Down]")        
            x=29
         prop=["AWTComponentAccessibleName","AWTComponentIndex"]
         val=["Name",x]
         child_name=req_form.Find(prop,val,10).wText
         req_form.Find(prop,val,10).Click()  
         if child_name == srch_child_name:
           found+=1  
         if (child_name==srch_child_name) and found==2: 
           req_form.Find(prop,val,10).Keys("[Enter]")
           Delay(1000)
           #jFrame.Keys("~p") 
           prop=["AWTComponentAccessibleName","JavaClassName"]
           val=["View Output alt p","Button"]
           output_button=req_form.FindChild(prop,val,60)
           output_button.Find("AWTComponentAccessibleName","View Output alt p").Click()     
           Delay(3000)
           output_page=Sys.Browser("iexplore").Page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
           output_page.Click()
           Delay(2000)
           output_page.Keys("~f")
           Delay(2000)
           output_page.Keys("a")
           Delay(5000)
           file_system_utils.create_folder(self.op_log_path)             
           log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"Is Attached_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
           Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
           Delay(1000)
           Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
           Delay(6000)
           Log.Enabled=True
           Log.File(log_path, "Supplier Cost Interface Audit Output File Attached")
           Log.Enabled=False    
           Sys.Browser("iexplore").page("https://core-*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close()  
           Delay(2000)   
           jFrame.Click()
           Delay(2000)
           break
                        
#   def submit_req_set_params(self,submitrequest_form,jFrame,index_no,proj_no,tab):
#       prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#       val=["Parameters",index_no]
#       submitrequest_form.FindChild(prop,val,60).Click()
#       Delay(2000)   
#       prop=["AWTComponentAccessibleName","JavaClassName"]
#       val=["Parameters","FlexWindow"]   
#       parameter_form=jFrame.FindChild(prop,val,10)
#       if tab=='Y':
#          parameter_form.Keys("[Tab]")
#       parameter_form.Keys(proj_no)
#       parameter_form.Keys("~o")
#       Delay(1000) 
#       
   def get_month_end(self):
       today = aqConvert.DateTimeToFormatStr(aqDateTime.Now(),'%d-%b-%Y')
       year = VarToInt(aqString.SubString(today,7,4)) 
       if aqString.SubString(today,3,3)== ('Mar' or 'May' or 'Jul' or 'Sep' or 'Nov'):
         end_date = '31-'+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),'%b-%Y')
         return end_date
       elif aqString.SubString(today,3,3) == 'Feb':
         if year % 4 == 0 and year % 100 != 0:
            end_date = '29-'+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),'%b-%Y')
         elif year % 100 == 0:
            end_date = '28-'+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),'%b-%Y')
         elif year % 400 ==0:
            end_date = '29-'+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),'%b-%Y')
         else:
            end_date = '28-'+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),'%b-%Y')
         return end_date 
       else:
         end_date = '30-'+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),'%b-%Y')
         return end_date 
     

     
def test():
  


  jFrame = Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1)
  prop3 = ["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]  
  val3 = ["Employee/Supplier","VTextField",51]
  supplier_det = jFrame.FindChild(prop3,val3,30).wText
  if supplier_det == "":
    Log.Message("True")
  prop1=["JavaFullClassName","AWTComponentIndex"]
  val1=["oracle.ewt.button.ContinuousButton","0"]
  drop_btn =  Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications - EBS", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("ExtendedFrame", "Requests", 26).AWTObject("LWComponent", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("FScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("DrawnPanel", "", 0).AWTObject("FScrollBox", "", 2).AWTObject("ScrollBox$1", "", 0).AWTObject("DrawnPanel", "", 0).AWTObject("LWScrollbar", "", 0).AWTObject("ContinuousButton", "", 0)
  Sys.HighlightObject(drop_btn)
  drop_btn.Click()
#   today = aqConvert.DateTimeToFormatStr(aqDateTime.Now(),'%d-%b-%Y')
#   year = VarToInt(aqString.SubString(today,7,4)) 
#   if aqString.SubString(today,3,3)== ('Mar' or 'May' or 'Jul' or 'Sep' or 'Nov'):
#     end_date = '31-'+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),'%b-%Y')
#     return end_date
#   elif aqString.SubString(today,3,3) == 'Feb':
#     if year % 4 == 0 and year % 100 != 0:
#        end_date = '29-'+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),'%b-%Y')
#     elif year % 100 == 0:
#        end_date = '28-'+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),'%b-%Y')
#     elif year % 400 ==0:
#        end_date = '29-'+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),'%b-%Y')
#     else:
#        end_date = '28-'+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),'%b-%Y')
#     return end_date 
#   else:
#     end_date = '30-'+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),'%b-%Y')
#     return end_date 
#     
#
#
#     
#
