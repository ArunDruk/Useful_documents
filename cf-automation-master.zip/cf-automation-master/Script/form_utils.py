﻿import file_system_utils
import web_utils
import gvar

def click_ok_btn(jFrame):
  delay(5000)
  prop=["AWTComponentName","JavaClassName"]
  val=["ChoiceBox*","ChoiceBox"]  
  ok_btn=jFrame.FindChildEx(prop,val,30,True,3000)
#  ok_btn=jFrame.FindChildEx(prop,val,40,True,6000)
  if ok_btn.Exists:
    ok_btn.Find("AWTComponentAccessibleName","OK ALT O",20).Click()
#    Delay(3000)
#    ok_btn.Find("AWTComponentAccessibleName","OK ALT O",40).Click()
    Delay(3200)
    if ok_btn.Exists:
      ok_btn.Find("AWTComponentAccessibleName","OK ALT O",20).Click()
#  else:
#    Log.Enabled=True
#    Log.Message("Notifications popup not found!!")
#    Log.Enabled=False      
#   
def Nav_Submit_Single_Request(self,jFrame):
   jFrame.Keys("~v")
   Delay(2000)
   jFrame.Keys("r")
   Delay(4000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Find Requests","ExtendedFrame"]
   FindRequests_form=jFrame.FindChildEx(prop,val,60,True,20000)
   self.log_message_oracle_form(FindRequests_form,"Navigation Successful: View > Request; Find Request Window Opened")
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Submit a New Request alt N","Button"]
   FindRequests_form.FindChild(prop,val,20).Click()

#   prop=["AWTComponentAccessibleName","JavaClassName"]
#   val=["Submit a New Request","ExtendedFrame"]
#   newrequest_form=jFrame.FindChild(prop,val,20)
#   self.log_message_oracle_form(newrequest_form,"Submit a New Request Button Click Successful; Submit a New Request Window Opened")
#   prop=["AWTComponentAccessibleName","JavaClassName"]
#   val=["OK alt O","Button"]
#   newrequest_form.FindChild(prop,val,20).Click()
#   Delay(2000)

  
def capture_reqid_and_save_Excel_output_singlereq(self,jFrame,op_log_path,ReportName):
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Decision","LWLabel"]
    parameters_form=jFrame.FindChild(prop,val,60)
#    self.verify_aqobject_chkproperty(parameters_form,"AWTComponentAccessibleName",cmpContains,"Decision")
    Delay(2000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Decision Request Submitted*","ChoiceBox"]
    decision_form=jFrame.FindChild(prop,val,60)
                               
    RequestID = ''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit())
    Log.Message("Request ID " + aqConvert.VarToStr(RequestID)+"generated Successfully")
    Delay(2000)
     #Click No 
    Rid =aqConvert.VarToStr(RequestID)
    self.log_message_oracle_form(jFrame,"Request Submitted Succesfully: "+ Rid )
    jFrame.Keys("~n")
    Delay(9900)       
    #click View > Requests
    jFrame.Keys("~v")
    Delay(4000)
    jFrame.Keys("r")
    Delay(4000)
    jFrame.Keys("~s")
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Requests","ExtendedFrame"]
    FindRequests_form=jFrame.FindChildEx(prop,val,60,True,20000) 
    self.log_message_oracle_form(FindRequests_form,"Navigation Successful : View > Request; Clicked Specific request;Find Request Window Opened") 
                      
    prop=["JavaClassName","AWTComponentAccessibleName"]
    val=["VTextField","Request ID"]
    FindRequests_form.FindChild(prop,val,60).Click()
    FindRequests_form.FindChild(prop,val,60).Keys(RequestID)
    Delay(2000)
     #Click Find 
    self.log_message_oracle_form(FindRequests_form ,"Request ID Entered: "+VarToStr(RequestID)+" on Find Request Window")
#    FindRequests_form.Keys("~i")
#    FindRequests_form.Keys("~i")
    FindRequests_form.Find("AWTComponentAccessibleName","Find alt i",30).Click()
    Delay(2000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,60000)
                         
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Phase",40]
    phase=req_form.Find(prop,val,10).wText 
                         
    while phase != 'Completed':
       Delay(1000)
       req_form.keys("~r")
       Delay(4000)
       phase=req_form.Find(prop,val,10).wText 
    self.log_message_oracle_form(req_form,ReportName+" Phase Completed Successfuly")
                         
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Status",50]
    request_form=jFrame.FindChild(prop,val,30)
    self.verify_aqobject_chkproperty(request_form,"wSelection",cmpContains,"Normal")
    self.log_message_oracle_form(request_form,ReportName+" Phase is 'Completed' and Status is 'Normal': Click Ouput Button")
#    request_form.Keys("~p")
#    request_form.Keys("~p")
    req_form.Find("AWTComponentAccessibleName","View Output alt p",30).Click()
    Delay(6000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Viewer Option","ExtendedFrame"]
    ViewerOption_form = jFrame.FindChildEx(prop,val,60,True,20000)
    self.log_message_oracle_form(ViewerOption_form,"Select: To: Excel and Click OK Button next")
    Delay(3000)
    ViewerOption_form.Click() 
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Ok alt O","Button"]
    ViewerOption_form.FindChild(prop,val,60).Click()
    Delay(6000)
    Saveouput = Sys.Browser("iexplore").Window("#32770", "Internet Explorer", 1)
    #self.log_message_web("SaveOutput Window Opened Successfully")
    Saveouput.Keys("~a")
    Delay(5000)
    file_system_utils.create_folder(self.op_log_path)
#                        if not aqFileSystem.Exists(op_log_path):
#                             aqFileSystem.CreateFolder(op_log_path)          
    log_path=op_log_path+"\\"+ReportName+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"_%d%b%Y_%H%M")   
    Sys.Browser("iexplore").Window("#32770", "Save As", 1).Keys(log_path)
    Delay(2000)
     #self.log_message_web("Save File")
    Sys.Browser("iexplore").Window("#32770", "Save As", 1).Keys("[Enter]")
    Delay(2000)
    Log.Enabled=True
    Log.File(log_path+".xls",ReportName+" Output File Attached")
    Log.Enabled=False
#    return RequestID                       
    return RequestID    
                     
                        

         
def capture_reqid_and_save_output_singlereq(self,jFrame,op_log_path,ReportName):
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Decision","LWLabel"]
   parameters_form=jFrame.FindChild(prop,val,60)
#   self.verify_aqobject_chkproperty(parameters_form,"AWTComponentAccessibleName",cmpContains,"Decision")
   Delay(2000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Decision Request Submitted*","ChoiceBox"]
   decision_form=jFrame.FindChild(prop,val,60)
                               
   RequestID = ''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit())
   Log.Message("Request ID " + aqConvert.VarToStr(RequestID)+"generated Successfully")
   Delay(2000)
   #Click No 
   Rid =aqConvert.VarToStr(RequestID)
   self.log_message_oracle_form(jFrame,aqConvert.VarToStr(ReportName)+" Request is submitted succesfully and RequestID is : "+ Rid )
   
   jFrame.Keys("~n")
   Delay(9900)       
    #click View > Requests
   jFrame.Keys("~v")
   Delay(4000)
   jFrame.Keys("r")
   Delay(4000)
   jFrame.Keys("~s")
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Find Requests","ExtendedFrame"]
   FindRequests_form=jFrame.FindChildEx(prop,val,60,True,20000) 
   self.log_message_oracle_form(FindRequests_form,"Navigation Successful : View > Request; Clicked Specific request;Find Request Window Opened") 
   
   Delay(2000)
   prop=["JavaClassName","AWTComponentAccessibleName"]
   val=["VTextField","Request ID"]
   FindRequests_form.FindChild(prop,val,60).Click()
   FindRequests_form.FindChild(prop,val,60).Keys(RequestID)
   Delay(2000)
  
   #Click Find 
   self.log_message_oracle_form(FindRequests_form ,"Request ID Entered: "+VarToStr(RequestID)+" on Find Request Window and include request set in stages check box is clicked ")
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Find alt i","Button"]
   FindRequests_form.FindChild(prop,val,60).Click()
   Delay(2000)
  
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Requests","ExtendedFrame"]
   req_form=jFrame.FindChild(prop,val,30)
   
   prop=["AWTComponentAccessibleName","AWTComponentIndex"]
   val=["Phase",40]
   phase=req_form.Find(prop,val,10).wText 
   
   while phase != 'Completed':
     Delay(1000)
     req_form.keys("~r")
     Delay(4000)
     phase=req_form.Find(prop,val,10).wText 
   self.log_message_oracle_form(req_form,ReportName+" Phase Completed Successfuly")
   
   prop=["AWTComponentAccessibleName","AWTComponentIndex"]
   val=["Status",50]
   request_form=jFrame.FindChild(prop,val,30)
   self.verify_aqobject_chkproperty(request_form,"wSelection",cmpContains,"Normal")
   self.log_message_oracle_form(request_form,aqConvert.VarToStr(ReportName)+" Phase is 'Completed' and Status is 'Normal': Click Ouput Button")
#   request_form.Keys("~p")
   req_form.Find("AWTComponentAccessibleName","View Output alt p",30).Click()
   Delay(3000)
   output_page=Sys.Browser("iexplore").Page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
   output_page.Click()
   Delay(2000)
   output_page.Keys("~f")
   Delay(1000)
   output_page.Keys("a")
   Delay(4000)

   file_system_utils.create_folder(self.op_log_path)             
   log_path=self.op_log_path+"\\"+aqConvert.VarToStr(ReportName.replace(":",""))+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
   Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
   Delay(1000)
   Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
   Delay(2000)
   Log.Enabled=True
#   Log.File(log_path,aqConvert.VarToStr(ReportName.replace(":",""))+ " Output File Attached")
   Log.File(log_path,aqConvert.VarToStr(ReportName)+ " Output File Attached") 
   Log.Enabled=False     
   Sys.Browser("iexplore").Page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close()
   return RequestID                       
                    
   
def req_set_save_output(self,jFrame,req_form,srch_child_name,Parentreqid):
    self.log_message_oracle_form(req_form,"Checking for Child Program "+ VarToStr(srch_child_name))
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val = ["Refresh Data alt R","Button"]
    req_form.FindChild(prop,val,2000).Click()
    i=20
    for x in range(1,180):                   
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Name",i]
        child_name=req_form.Find(prop,val,10).wText
        while child_name =="" or child_name==None :
          prop=["AWTComponentAccessibleName","JavaClassName"]
          val = ["Refresh Data alt R","Button"]
          req_form.FindChild(prop,val,2000).Click()
          Delay(3000)
          child_name=req_form.Find(prop,val,10).wText 
          
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Phase",i+20]
        phase=req_form.Find(prop,val,10).wText 
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Request ID",i-10]
        delay(1000)
        curr_req = req_form.FindChild(prop,val,30)
        delay(1000)
        creqid= aqConvert.VarToInt(curr_req.wText)
        Preqid= aqConvert.VarToInt(Parentreqid)
#        self.log_message_oracle_form(req_form,"Request ID of "+aqConvert.VarToStr(srch_child_name)+" is "+aqConvert.VarToStr(creqid))                                                
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Status",i+30]         
        status =req_form.FindChild(prop,val,60)            
        if (child_name==srch_child_name) and (creqid >= Preqid ) and (phase == "Completed"):
            self.log_message_oracle_form(req_form,aqConvert.VarToStr(srch_child_name)+" Phase Completed Successfuly")            
            self.verify_aqobject_chkproperty(status,"wText",cmpIn,"Normal,Warning")        
            status.Keys("[Enter]")
            Delay(1000)
            prop = ["AWTComponentAccessibleName","JavaClassName"]
            val = ["View Output alt p","Button"]
            req_form.FindChild(prop,val,2000).Click()    
            Delay(3000)
            output_page=self.browser.Page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
            output_page.Click()
            if gvar.dataprep['browser'] == "ie":
                Delay(5000)
                output_page.Keys("~f")
                output_page.Keys("a")
                Delay(4000)
            elif gvar.dataprep['browser'] == "chrome":
                Delay(5000)
                output_page.Keys("^s")
                Delay(4000)
            file_system_utils.create_folder(self.op_log_path)             
            log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"File"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"_%d%b%Y_%H%M")+".txt"   
#            log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name)+"File"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"_%d%b%Y_%H%M")+".txt"   
            if gvar.dataprep['browser'] == "ie":
              self.browser.Window("#32770", "Save Webpage", 1).Keys(log_path)
              Delay(1000)
              self.browser.Window("#32770", "Save Webpage", 1).Keys("[Enter]")
              Delay(2000)
            elif gvar.dataprep['browser'] == "chrome":
              self.browser.Window("#32770", "Save As", 1).Keys(log_path)
              Delay(1000)
              self.browser.Window("#32770", "Save As", 1).Keys("[Enter]")
              Delay(2000)
            Log.Enabled=True
            Log.File(log_path, aqConvert.VarToStr(srch_child_name)+" Output File Attached")            
            Log.Enabled=False     
            self.browser.Page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close()
            Filesaved = 'True'
            return creqid, log_path                  
        elif i >=29:
           Delay(20000)
           prop=["AWTComponentAccessibleName","JavaClassName"]
           val = ["Refresh Data alt R","Button"]
           req_form.FindChild(prop,val,2000).Click()

           Delay(3000)
           i=20
           val=["Name",i]
           child_name=req_form.Find(prop,val,10).wText

        else:  
           Delay(3000)
           i=i+1 
           jFrame.Keys("[Down]")
    
                        
def Capture_Requestid_and_Nav_Find_requestset(self,jFrame):
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Decision","LWLabel"]
   parameters_form=jFrame.FindChild(prop,val,60)
   self.verify_aqobject_chkproperty(parameters_form,"AWTComponentAccessibleName",cmpContains,"Decision")
   Delay(2000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Decision Request Submitted*","ChoiceBox"]
   decision_form=jFrame.FindChild(prop,val,60)
                               
   RequestID = ''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit())
   Log.Message("Request ID " + aqConvert.VarToStr(RequestID)+"generated Successfully")
   Delay(2000)
   #Click No 
   Rid =aqConvert.VarToStr(RequestID)
   self.log_message_oracle_form(jFrame,"Request Submitted Succesfully: "+ Rid )
   

   self.log_message_oracle_form( jFrame,"Click No Button Next")
   jFrame.Keys("~n")
   jFrame.Keys("~v")
   Delay(2000)
   jFrame.Keys("r")
   Delay(2000)
   self.log_message_oracle_form( jFrame,"Navigation to View > Request Successful;Click Find Next ")
   
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Find Requests","ExtendedFrame"]
   FindRequests_form=jFrame.FindChildEx(prop,val,60,True,20000) 
   FindRequests_form.Keys("~s")
   self.log_message_oracle_form(FindRequests_form," Clicked Specific request;Find Request Window Opened") 

   prop=["JavaClassName","AWTComponentAccessibleName"]
   val=["VTextField","Request ID"]
   FindRequests_form.FindChild(prop,val,60).Click()
   FindRequests_form.FindChild(prop,val,60).Keys(RequestID)
   Delay(2000)
   #Click Find 
     
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Include Request Set Stages in Query alt q","LWCheckbox"]
   FindRequests_form.FindChild(prop,val,60).Click()
   #Click Find 
   self.log_message_oracle_form(FindRequests_form ,"Request ID Entered: "+VarToStr(RequestID)+" on Find Request Window and include request set in stages check box is clicked ")
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Find alt i","Button"]
   FindRequests_form.FindChild(prop,val,60).Click()
  
   Delay(2000)
   return RequestID
   
   
#def req_set_save_log(self,jFrame,req_form,srch_child_name,Parentreqid):
#   self.log_message_oracle_form(req_form,"Checking for Child Program "+ VarToStr(srch_child_name))
#   req_form.keys("~r")
#   i=20
#   for x in range(1,180):     
#       prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#       val=["Name",i]
#       child_name=req_form.Find(prop,val,10).wText 
#       prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#       val=["Phase",i+20]
#       phase=req_form.Find(prop,val,10).wText 
#       prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#       val=["Request ID",i-10]
#       creqid=VarToInt(req_form.Find(prop,val,10).wText)
#       Preqid=VarToInt(Parentreqid)
##        self.log_message_oracle_form(req_form,"Request ID of "+aqConvert.VarToStr(srch_child_name)+" is "+aqConvert.VarToStr(creqid))                                         
#       prop=["AWTComponentAccessibleName","AWTComponentIndex"]
#       val=["Status",i+30]         
#       status =req_form.FindChild(prop,val,60)            
#       if (child_name==srch_child_name) and (creqid>=Preqid) and (phase == "Completed"):
#           self.log_message_oracle_form(req_form,srch_child_name+" phase Completed Successfuly")            
#           self.verify_aqobject_chkproperty(status,"wText",cmpContains,"Normal")        
#           status.Keys("[Enter]")
#           Delay(1000)
##           jFrame.Keys("~g") 
#           prop=["AWTComponentAccessibleName","JavaClassName","AWTComponentIndex"]
#           val=["View Log alt K","Button",15]
#           log_button = req_form.FindChild(prop,val,50)
#           log_button.Click()
##           jFrame.Keys("~k")
#           Delay(3000)
#           log_page=Sys.Browser("iexplore").Page("https://core-*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
#           Delay(1000)
##           if log_page.Exists:
##             log_button.Click()
##             req_form.keys("~k")
#           log_page.Click()
#           log_page.TextNode(0).Click()
#           Delay(1000)
#           Log.Enabled=True     
#           screenshot=log_page.PagePicture()
#           msg = (srch_child_name+" File Opened Successfully")
#           Log.Picture(screenshot,msg)
#           Log.Enabled=False
##           self.log_message_web(srch_child_name+": log file")
#           log_page.Keys("~f")
#           Delay(2000)
#           log_page.Keys("a")
#           Delay(4000)
#           file_system_utils.create_folder(self.op_log_path)             
#           log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"File"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"_%d%b%Y_%H%M")+".txt"    
#           Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
#           Delay(1000)
#           Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
#           Delay(2000)
#           Log.Enabled=True
#           Log.File(log_path, aqConvert.VarToStr(srch_child_name)+" Log File Attached")
#           Log.Enabled=False 
#           Delay(1000)    
#           log_page.Close()
#           if log_page.exists:
#            Sys.Browser("iexplore").Page("https://core-*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close()
#           Filesaved = 'True'
#           return                           
#       elif i >=29:
#          Delay(20000)
#          prop=["AWTComponentAccessibleName","JavaClassName"]
#          val = ["Refresh Data alt R","Button"]
#          req_form.FindChild(prop,val,2000).Click()
#          delay(1000)
#          req_form.keys("~r")
#   
#          Delay(3000)
#          i=20
#          val=["Name",i]
#          child_name=req_form.Find(prop,val,10).wText
#   
#       else:  
#          Delay(3000)
#          i=i+1 
#          jFrame.Keys("[Down]")


def req_set_save_log(self,jFrame,req_form,srch_child_name,Parentreqid):
    self.log_message_oracle_form(req_form,"Checking for Child Program "+ VarToStr(srch_child_name))
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val = ["Refresh Data alt R","Button"]
    req_form.FindChild(prop,val,2000).Click()
    i=20
    for x in range(1,180):                   
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Name",i]
        child_name=req_form.Find(prop,val,10).wText
        while child_name =="" or child_name==None :
          prop=["AWTComponentAccessibleName","JavaClassName"]
          val = ["Refresh Data alt R","Button"]
          req_form.FindChild(prop,val,2000).Click()
          Delay(3000)
          child_name=req_form.Find(prop,val,10).wText 
          
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Phase",i+20]
        phase=req_form.Find(prop,val,10).wText 
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Request ID",i-10]
        creqid= aqConvert.VarToInt(req_form.Find(prop,val,10).wText)
        Preqid= aqConvert.VarToInt(Parentreqid)
#        self.log_message_oracle_form(req_form,"Request ID of "+aqConvert.VarToStr(srch_child_name)+" is "+aqConvert.VarToStr(creqid))                                                
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Status",i+30]         
        status =req_form.FindChild(prop,val,60)            
        if (child_name==srch_child_name) and (creqid >= Preqid ) and (phase == "Completed"):
            self.log_message_oracle_form(req_form,aqConvert.VarToStr(srch_child_name)+" Phase Completed Successfuly")            
            self.verify_aqobject_chkproperty(status,"wText",cmpIn,"Normal,Warning")
            self.log_message_oracle_form(req_form,"Request ID of "+aqConvert.VarToStr(srch_child_name)+" is "+aqConvert.VarToStr(creqid))                                                            
            status.Keys("[Enter]")
            Delay(1000)
            prop = ["AWTComponentAccessibleName","JavaClassName"]
            val = ["View Log alt K","Button"]
            req_form.FindChild(prop,val,2000).Click()    
            Delay(3000)
            output_page=Sys.Browser("iexplore").Page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
            output_page.Click()
            Delay(5000)
            Log.Enabled=True     
            screenshot=output_page.PagePicture()
            msg = (srch_child_name+" File Opened Successfully")
            Log.Picture(screenshot,msg)
            Log.Enabled=False

            output_page.Keys("~f")
            output_page.Keys("a")
            Delay(4000)
            file_system_utils.create_folder(self.op_log_path)             
            log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"File"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"_%d%b%Y_%H%M")+".txt"    
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
            Delay(1000)
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
            Delay(2000)
            Log.Enabled=True
            Log.File(log_path, aqConvert.VarToStr(srch_child_name)+" Log File Attached")
            Log.Enabled=False     
            Sys.Browser("iexplore").Page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close()
            web_utils.close_additional_browsers()
            Filesaved = 'True'
            return creqid, log_path                  
        elif i >=29:
           Delay(20000)
           prop=["AWTComponentAccessibleName","JavaClassName"]
           val = ["Refresh Data alt R","Button"]
           req_form.FindChild(prop,val,2000).Click()


           Delay(3000)
           i=20
           val=["Name",i]
           child_name=req_form.Find(prop,val,10).wText

        else:  
           Delay(3000)
           i=i+1 
           jFrame.Keys("[Down]")
 
       
def save_output_singlereq(self,jFrame,op_log_path,ReportName,RequestID):
      Delay(1000)
      jFrame.Keys("~v")
      Delay(2000)
      jFrame.Keys("r")
      Delay(2000)
      web_utils.log_checkpoint("Navigation to View > Request Successful;Click Find Next ",500,jFrame)
#      self.log_message_oracle_form( jFrame,"Navigation to View > Request Successful;Click Find Next ") 
      prop=["AWTComponentAccessibleName","JavaClassName"]
      val=["Find Requests","ExtendedFrame"]
      FindRequests_form=jFrame.FindChildEx(prop,val,60,True,20000) 
#      web_utils.log_checkpoint("Find Request Window Opened;Clicked Specific request",500,jFrame)
#      self.log_message_oracle_form(FindRequests_form," Find Request Window Opened;Clicked Specific request") 
      prop=["JavaClassName","AWTComponentAccessibleName"]
      val=["ExtendedCheckbox","What type of Requests do you want to find? Specific Requests alt S"]
      FindRequests_form.FindChild(prop,val,60).Click()
      delay(1000)
      web_utils.log_checkpoint("Find Request Window Opened;Clicked Specific request",500,jFrame)
#      jFrame.Keys("~s")
      Delay(1000)
      prop=["JavaClassName","AWTComponentAccessibleName"]
      val=["VTextField","Request ID"]
      FindRequests_form.FindChild(prop,val,60).Click()
      FindRequests_form.FindChild(prop,val,60).Keys(RequestID)
      Delay(2000)
      
      prop=["JavaClassName","AWTComponentAccessibleName"]
      val=["LWCheckbox","Include Request Set Stages in Query alt q"]
      FindRequests_form.FindChild(prop,val,60).Click()     
      Delay(2000)
      #Click Find 
      web_utils.log_checkpoint("Request ID Entered: "+VarToStr(RequestID)+" on Find Request Window and include request set in stages check box is clicked ",500,jFrame)
#      self.log_message_oracle_form(FindRequests_form ,"Request ID Entered: "+VarToStr(RequestID)+" on Find Request Window and include request set in stages check box is clicked ")
      prop=["AWTComponentAccessibleName","JavaClassName"]
      val=["Find alt i","Button"]
      FindRequests_form.FindChild(prop,val,60).Click()
      Delay(2000)
     
      prop=["AWTComponentAccessibleName","JavaClassName"]
      val=["Requests","ExtendedFrame"]
      req_form=jFrame.FindChild(prop,val,30)
      
      prop=["AWTComponentAccessibleName","AWTComponentIndex"]
      val=["Phase",40]
      phase=req_form.Find(prop,val,10).wText 
      val=["Status",50]
      status=req_form.Find(prop,val,10).wText       
      count = 0
      while phase != 'Completed':
        Delay(1000)
        if status == 'On Hold':
          prop=["AWTComponentAccessibleName","JavaClassName"]
          val=["Remove Hold alt d","Button"]
          req_form.Find(prop,val,10).Click()
          delay(2000) 
        prop=["AWTComponentAccessibleName","JavaClassName"]
        val = ["Refresh Data alt R","Button"]
        req_form.FindChild(prop,val,2000).Click()
#        req_form.keys("~r")
        Delay(6000)
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Phase",40]
        phase=req_form.Find(prop,val,10).wText 
        if count > 200:
          self.log_error_message("Program "+VarToStr(ReportName)+" is running for more than 20 minutes; Aborting the Execution...")
        count+=1
      web_utils.log_checkpoint(aqConvert.VarToStr(ReportName)+" phase Completed Successfuly",500,jFrame)
#      self.log_message_oracle_form(req_form,aqConvert.VarToStr(ReportName)+" phase Completed Successfuly")
      
      prop=["AWTComponentAccessibleName","AWTComponentIndex"]
      val=["Status",50]
      request_form=jFrame.FindChild(prop,val,30)
#      self.verify_aqobject_chkproperty(request_form,"wSelection",cmpContains,"Normal")
      if VarToStr(request_form.wSelection) == "Normal":
       web_utils.log_checkpoint(aqConvert.VarToStr(ReportName)+" Status is Normal: Click Output Button",500,jFrame)
      elif VarToStr(request_form.wSelection) == "Warning":
        web_utils.log_checkpoint(aqConvert.VarToStr(ReportName)+" Status is Warning: Click Output Button",500,jFrame)
      else:
        self.log_error_message(aqConvert.VarToStr(ReportName)+" phase is  Complete and Status is 'Error'")
#      self.log_message_oracle_form(request_form,aqConvert.VarToStr(ReportName)+" phase is  Complete and Status is Normal: Click Output Button")
      prop=["AWTComponentAccessibleName","JavaClassName"]
      val=["Requests","ExtendedFrame"]
      req_form=jFrame.FindChild(prop,val,30)
      prop = ["AWTComponentAccessibleName","JavaClassName"]
      val = ["View Output alt p","Button"]
      req_form.FindChild(prop,val,2000).Click()    
#      request_form.Keys("~p")
      Delay(5000)
      if ReportName == "Create Accounting - Assets":
        Delay(15000) 
        web_utils.log_checkpoint("PDF Output generated Successfully",500,Sys.Browser("iexplore").BrowserWindow(0))
        Sys.Keys("!^s")
        Delay(15000) 
        log_path=self.op_log_path+"\\"+ReportName+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".pdf"
        Sys.Browser("iexplore").Window("#32770", "Save a Copy...", 1).Window("DUIViewWndClassName", "", 1).UIAObject("Explorer_Pane").Window("FloatNotifySink", "", 1).Window("ComboBox", "", 1).Keys(log_path)
        delay(1000)
        Sys.Browser("iexplore").Window("#32770", "Save a Copy...", 1).Window("DUIViewWndClassName", "", 1).UIAObject("Explorer_Pane").Window("FloatNotifySink", "", 1).Window("ComboBox", "", 1).Keys("[Enter]")
        delay(20000)
        Log.Enabled=True
#        Log.File(log_path,aqConvert.VarToStr(ReportName)+ "Output File Attached")
        Log.Enabled=False  
        delay(1000)
        Sys.Process("iexplore", 3).Window("IEFrame", "https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*", 1).Close()
      else:
        output_page=Sys.Browser("iexplore").Page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
        output_page.Click()
        Delay(3000)
        output_page.Keys("~")
        Delay(1000)
        output_page.Keys("f")
        delay(2000)
        output_page.Keys("a")
        Delay(6000)
   
        file_system_utils.create_folder(self.op_log_path)             
        log_path=self.op_log_path+"\\"+ReportName+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
        Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
        Delay(1000)
        Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
        Delay(2000)
        Log.Enabled=True
        Log.File(log_path,aqConvert.VarToStr(ReportName)+ "Output File Attached")
        Log.Enabled=False     
        delay(1000)
        Sys.Browser("iexplore").Page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close()
      delay(2000)
      req_form.Click()
      delay(1000)
      req_form.Close()
      delay(2000)
      return RequestID         
                  


def save_log_singlereq(self,jFrame,op_log_path,ReportName,RequestID):
      
      jFrame.Keys("~v")
      Delay(2000)
      jFrame.Keys("r")
      Delay(2000)
      self.log_message_oracle_form( jFrame,"Navigation to View > Request Successful;Click Find Next ")
      
      prop=["AWTComponentAccessibleName","JavaClassName"]
      val=["Find Requests","ExtendedFrame"]
      FindRequests_form=jFrame.FindChildEx(prop,val,60,True,20000) 
      self.log_message_oracle_form(FindRequests_form," Find Request Window Opened and clicked Specific request") 
      jFrame.Keys("~s")
      Delay(1000)
      prop=["JavaClassName","AWTComponentAccessibleName"]
      val=["VTextField","Request ID"]
      FindRequests_form.FindChild(prop,val,60).Click()
      FindRequests_form.FindChild(prop,val,60).Keys(RequestID)
      Delay(2000)
     
      #Click Find 
      self.log_message_oracle_form(FindRequests_form ,"Request ID Entered: "+VarToStr(RequestID)+" on Find Request Window")
      prop=["AWTComponentAccessibleName","JavaClassName"]
      val=["Find alt i","Button"]
      FindRequests_form.FindChild(prop,val,60).Click()
      Delay(2000)
     
      prop=["AWTComponentAccessibleName","JavaClassName"]
      val=["Requests","ExtendedFrame"]
      req_form=jFrame.FindChild(prop,val,30)
      
      prop=["AWTComponentAccessibleName","AWTComponentIndex"]
      val=["Phase",40]
      phase=req_form.Find(prop,val,10).wText 
      
      while phase != 'Completed':
        Delay(1000)
        req_form.keys("~r")
        Delay(4000)
        phase=req_form.Find(prop,val,10).wText 
      self.log_message_oracle_form(req_form,aqConvert.VarToStr(ReportName)+" phase Completed Successfuly")
      
      prop=["AWTComponentAccessibleName","AWTComponentIndex"]
      val=["Status",50]
      request_form=jFrame.FindChild(prop,val,30)
      self.verify_aqobject_chkproperty(request_form,"wSelection",cmpContains,"Normal")
      self.log_message_oracle_form(request_form,aqConvert.VarToStr(ReportName)+" phase is Complete and Status is Normal: Click log Button")
      prop=["AWTComponentAccessibleName","JavaClassName"]
      val=["Requests","ExtendedFrame"]
      req_form=jFrame.FindChild(prop,val,30)
      prop = ["AWTComponentAccessibleName","JavaClassName"]
      val = ["View Log alt K","Button"]
      req_form.FindChild(prop,val,2000).Click()    
      Delay(3000)
      output_page=Sys.Browser("iexplore").Page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
      output_page.Click()
      Delay(2000)
      output_page.Keys("~f")
      Delay(1000)
      output_page.Keys("a")
      Delay(5000)
   
      file_system_utils.create_folder(self.op_log_path)             
      log_path=self.op_log_path+"\\"+ReportName+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
      Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
      Delay(1000)
      Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
      Delay(2000)
      Log.Enabled=True
      Log.File(log_path,aqConvert.VarToStr(ReportName)+ " Log File Attached")
      Log.Enabled=False     
      Sys.Browser("iexplore").Page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close()
      return RequestID 






 
       
def save_output_ji(self,jFrame,op_log_path,ReportName,RequestID):
      Delay(1000)
      jFrame.Keys("~v")
      Delay(2000)
      jFrame.Keys("r")
      Delay(2000)
      web_utils.log_checkpoint("Navigation to View > Request Successful;Click Find Next ",500,jFrame)
#      self.log_message_oracle_form( jFrame,"Navigation to View > Request Successful;Click Find Next ") 
      prop=["AWTComponentAccessibleName","JavaClassName"]
      val=["Find Requests","ExtendedFrame"]
      FindRequests_form=jFrame.FindChildEx(prop,val,60,True,20000) 
      web_utils.log_checkpoint("Find Request Window Opened;Clicked Specific request",500,jFrame)
#      self.log_message_oracle_form(FindRequests_form," Find Request Window Opened;Clicked Specific request") 
      prop=["JavaClassName","AWTComponentAccessibleName"]
      val=["ExtendedCheckbox","What type of Requests do you want to find? Specific Requests alt S"]
      FindRequests_form.FindChild(prop,val,60).Click()
#      jFrame.Keys("~s")
      Delay(1000)
      prop=["JavaClassName","AWTComponentAccessibleName"]
      val=["VTextField","Request ID"]
      FindRequests_form.FindChild(prop,val,60).Click()
      FindRequests_form.FindChild(prop,val,60).Keys(RequestID)
      Delay(2000)
      
      prop=["JavaClassName","AWTComponentAccessibleName"]
      val=["LWCheckbox","Include Request Set Stages in Query alt q"]
      FindRequests_form.FindChild(prop,val,60).Click()     
      Delay(2000)
      #Click Find 
      web_utils.log_checkpoint("Request ID Entered: "+VarToStr(RequestID)+" on Find Request Window and include request set in stages check box is clicked ",500,jFrame)
#      self.log_message_oracle_form(FindRequests_form ,"Request ID Entered: "+VarToStr(RequestID)+" on Find Request Window and include request set in stages check box is clicked ")
      prop=["AWTComponentAccessibleName","JavaClassName"]
      val=["Find alt i","Button"]
      FindRequests_form.FindChild(prop,val,60).Click()
      Delay(2000)
     
      prop=["AWTComponentAccessibleName","JavaClassName"]
      val=["Requests","ExtendedFrame"]
      req_form=jFrame.FindChild(prop,val,30)
      
      prop=["AWTComponentAccessibleName","AWTComponentIndex"]
      val=["Phase",40]
      phase=req_form.Find(prop,val,10).wText 
      c = 0 
      while phase != 'Completed':
        Delay(1000)
        req_form.keys("~r")
        Delay(4000)
        c+=1
        if c >25:
          self.log_error_message("Unable to Find the Request in Completed Status")
        phase=req_form.Find(prop,val,10).wText 
      web_utils.log_checkpoint(aqConvert.VarToStr(ReportName)+" phase Completed Successfuly",500,jFrame)
#      self.log_message_oracle_form(req_form,aqConvert.VarToStr(ReportName)+" phase Completed Successfuly")
      
      prop=["AWTComponentAccessibleName","AWTComponentIndex"]
      val=["Status",50]
      request_form=jFrame.FindChild(prop,val,30)
#      self.verify_aqobject_chkproperty(request_form,"wSelection",cmpContains,"Normal")
      if VarToStr(request_form.wSelection) == "Normal":
       web_utils.log_checkpoint(aqConvert.VarToStr(ReportName)+" Status is Normal: Click Output Button",500,jFrame)
      elif VarToStr(request_form.wSelection) == "Warning":
        web_utils.log_checkpoint(aqConvert.VarToStr(ReportName)+" Status is Warning: Click Output Button",500,jFrame)
      else:
        self.log_error_message(aqConvert.VarToStr(ReportName)+" phase is  Complete and Status is 'Error'")
#      self.log_message_oracle_form(request_form,aqConvert.VarToStr(ReportName)+" phase is  Complete and Status is Normal: Click Output Button")
      prop=["AWTComponentAccessibleName","JavaClassName"]
      val=["Requests","ExtendedFrame"]
      req_form=jFrame.FindChild(prop,val,30)
      prop = ["AWTComponentAccessibleName","JavaClassName"]
      val = ["View Output alt p","Button"]
      req_form.FindChild(prop,val,2000).Click()    
#      request_form.Keys("~p")
      Delay(3000)
      output_page=Sys.Browser("iexplore").Page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
      output_page.Click()
      Delay(3000)
      output_page.Keys("~")
      Delay(1000)
      output_page.Keys("f")
      delay(2000)
      output_page.Keys("a")
      Delay(6000)
   
      file_system_utils.create_folder(self.op_log_path)             
      log_path=self.op_log_path+"\\"+ReportName+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
      Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
      Delay(1000)
      Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
      Delay(4000)
      Log.Enabled=True
      Log.File(log_path,aqConvert.VarToStr(ReportName)+ "Output File Attached")
      Log.Enabled=False     
      delay(1000)
      Sys.Browser("iexplore").Page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close()
      delay(2000)
      req_form.Click()
      delay(1000)
      req_form.Close()
      delay(2000)
      return log_path 


