﻿from dbhelper import *
from ebiz import *
import web_utils
import wcc_login_page
import wcc_home_page
import os

class capture_us_supplemental_pages(Ebiz):
  
 def login(self):
    self.login_user="devtest"
    wscript=Sys.OleObject["WScript.Shell"]
    wscript.Run("C:\\Users\\"+os.environ.get('USERNAME')+"\\AppData\\Local\\Oracle\\capture\\capture.exe")
#    "C:\\Users\\"+os.environ.get('USERNAME')+"\\Documents\\logfile.log"
    capture_client = Sys.Process("capture").WaitSwingObject("RMCLogin", "Oracle WebCenter Enterprise Capture", -1,10000)
    if capture_client.Exists:
      capture_client.FindChild("AWTComponentAccessibleName","User Name:",30).Click()
      capture_client.FindChild("AWTComponentAccessibleName","User Name:",30).Keys("devtest")
      delay(2000)
      capture_client.FindChild("AWTComponentAccessibleName","Password:",30).Click()
      capture_client.FindChild("AWTComponentAccessibleName","Password:",30).Keys("oracle123")
      delay(2000)
      capture_client.FindChild("AWTComponentAccessibleName","Server:",30).Click()
      capture_client.FindChild("AWTComponentAccessibleName","Server:",30).Keys("^a[Del]")
      capture_client.FindChild("AWTComponentAccessibleName","Server:",30).Keys("https://core-capture-dev.epfinnp.coxautoinc.com")
      delay(2000)
      capture_client.FindChild("AWTComponentAccessibleName","OK",30).Click()
    else:
      self.log_error_message("Unable to Find the CaptureClient Login")
    capture_window = Sys.Process("capture").WaitWindow("SunAwtFrame", "Oracle WebCenter Enterprise Capture - Connected to https://core-capture-dev.epfinnp.coxautoinc.com", 1,10000)
    if capture_window.Exists:
      web_utils.log_checkpoint("Able to Login to WCC Applications - Client Successfully",500,capture_window)
    else:
      self.log_error_message("Unable to Login to WCC Applications - Client")

       
 def goto_url(self,url):
  pass
   
 def logout(self):
#   self.page.wait()
  capture_window = Sys.Process("capture").WaitWindow("SunAwtFrame", "Oracle WebCenter Enterprise Capture - Connected to https://core-capture-dev.epfinnp.coxautoinc.com", 1,10000)
  signout_link = capture_window.FindChild("AWTComponentAccessibleName","Signed In As devtest",30)
#  Sys.HighlightObject(signout_link)
  signout_link.Click()
  delay(1000)
  capture_window.Keys("[Down][Down][Down][Down]")
  delay(500)
  capture_window.Keys("[Enter]")
  capture_window.Close()
#  web_utils.log_checkpoint("Completed WCI Capture Application Validation Successfully: Logging out from Applications",500,self.page)
  self.log_checkpoint_message_web("Completed WCI Capture Application Validation Successfully: Logging out from Applications")

   
 def action(self,book):
  app = book.Sheets.item["mail_wcc"]   
  cap_panel = Sys.Process("capture").SwingObject("RMCMain", "Oracle WebCenter Enterprise Capture - Connected to https://core-capture-dev.epfinnp.coxautoinc.com", 0).SwingObject("JRootPane", "", 0).SwingObject("null.layeredPane").SwingObject("null.contentPane").SwingObject("FormManagerPanel", "", 0).SwingObject("JPanel", "", 2).SwingObject("JPanel", "", 0).SwingObject("ExistingSessionPanel", "", 0).SwingObject("JPanel", "", 1)
  if cap_panel.Exists:
    cap_panel.Keys("[Enter]")
  delay(2000)
  capture_window = Sys.Process("capture").WaitWindow("SunAwtFrame", "Oracle WebCenter Enterprise Capture - Connected to https://core-capture-dev.epfinnp.coxautoinc.com", 1,10000)
  prop_names = ["JavaClassName", "AWTComponentIndex","JavaFullClassName"]
  prop_values = ["BatchEditForm$43",0,"oracle.oddc.client.BatchEditForm$43"]
  batch_list = capture_window.FindChildEx(prop_names,prop_values,30,True,90000)  
  
  count =  0 
#Enter Applications and Validate the Home Page:
  while not batch_list.Exists:
    Delay(2000)
    batch_list = capture_window.FindChildEx(prop_names,prop_values,30,True,90000)
    count = count + 1 
    if count == 10:
      self.log_error_message("Unable to Login to WCC Capture Client Application") 
  Sys.HighlightObject(capture_window.FindChildEx(prop_names,prop_values,30,True,90000))   
  web_utils.log_checkpoint("Logged in to Web Center Capture Applications Successfully",500,capture_window) 
  Delay(3000)
  prop_values = ["VetoableComboBox",0,"oracle.odc.component.VetoableComboBox"]
  delay(1000)
  location = VarToStr(app.Cells.item[2,3])[2:]
  ocr_key = aqString.SubString(location,0,2)
  capture_window.FindChildEx(prop_names,prop_values,30,True,90000).Keys(location)
  web_utils.log_checkpoint("Location has been selected successfully",500,capture_window)  
#  self.wait_until_page_loaded()
  delay(3200)
#delay until the page loads:
  delay(40000)
  OCR.Recognize(batch_list).BlockByText(ocr_key, spTopMost).Click()
  delay(2210) 
  prop_names = ["AWTComponentAccessibleName","JavaClassName","JavaFullClassName"]
  prop_values = ["Batch Name:","JTextField","javax.swing.JTextField"]
  batch_name = capture_window.FindChildEx(prop_names,prop_values,30,True,90000)
  i = 0
  while batch_name.Exists == None: 
    OCR.Recognize(batch_list).BlockByText(ocr_key, spTopMost).Click()
    i = i + 1
    if i == 4:
      self.log_error_message("Unable to Find Details for the Selected Batch")
      
  batch_name,date_time,batch_notes = self.get_batch_details()
  comp = VarToStr(app.Cells.item[2,1])
  j = 0
  while StrMatches(comp,batch_notes) != True:
     batch_list.Keys("[Down]")
     delay(2000)
     batch_name,date_time,batch_notes = self.get_batch_details()
     j = j + 1
     if j == 8:
       OCR.Recognize(batch_list).BlockByText(ocr_key, spTopMost).Click()
       batch_name,date_time,batch_notes = self.get_batch_details()
       if StrMatches(comp,batch_notes) != True:   
         self.log_error_message("Batch Not Created in WCI Capture for the email sent: Test Failed")
  app.Cells.item[2,2]=VarToStr(batch_name)
  web_utils.log_checkpoint("Verified the Batch Details Successfully",500,capture_window)
       
# Validate Document Profile and Release the Batch to WFR Form for Verification:
  batch_list.Keys("[Right][Right]")
#  self.wait_until_page_loaded()
  Delay(5000)
  prop_names = ["AWTComponentIndex","JavaClassName","JavaFullClassName"]
  prop_values = [0,"ImageViewer","oracle.odc.imageviewer.ImageViewer"]
  ImageViewer =  capture_window.FindChildEx(prop_names,prop_values,30,True,120000)
  value = ImageViewer.VisibleOnScreen
  document_no = 1
  while value == True:
#      self.wait_until_page_loaded()
      Delay(5000)
      self.validate_doc_panel(document_no)
      delay(2000)
      batch_list.Keys("[Down]")
      Delay(7000)
      document_no = document_no+1
      value = ImageViewer.VisibleOnScreen

  if value == False:
      batch_list.Keys("[Down]")
      value = ImageViewer.VisibleOnScreen
      while value == True:
        delay(2000)
        self.validate_doc_panel(document_no)
        delay(2000)
        batch_list.Keys("[Down]")
        Delay(7000)
        document_no = document_no+1
        value = ImageViewer.VisibleOnScreen
      
  web_utils.log_checkpoint("Verified and Updated the Document Profile Details Successfully: Ready to Release",500,capture_window)
  delay(1000)
  OCR.Recognize(batch_list).BlockByText(ocr_key, spTopMost).Click()
#  Delay(1000)
#  batch_list.FindID(b_id).click() 
  Delay(1000)
  release_button = capture_window.FindChild("AWTComponentAccessibleName","Release",30)
  while not release_button.Exists:
    delay(1000)
    capture_window.Keys("^~r")
    delay(1000)
    capture_window.Keys("[Down][Down][Enter]")
    delay(1000)
    release_button = capture_window.FindChild("AWTComponentAccessibleName","Release",30)
  release_button.Click()
    
    
  Delay(10000)
  self.refresh()
  web_utils.log_checkpoint("Click 'Release' button - Successfull for the batch: "+batch_name,500,capture_window)
  self.validate_batch_release(app,ocr_key)

 def get_batch_details(self):
  capture_window = Sys.Process("capture").WaitWindow("SunAwtFrame", "Oracle WebCenter Enterprise Capture - Connected to https://core-capture-dev.epfinnp.coxautoinc.com", 1,10000)
  prop_names = ["AWTComponentAccessibleName","JavaClassName","JavaFullClassName"]
  prop_values = ["Batch Name:","JTextField","javax.swing.JTextField"]
  batch_name = capture_window.FindChildEx(prop_names,prop_values,30,True,500).wText
  self.log_checkpoint_message_web("Batch Name: "+VarToStr(batch_name))
#  web_utils.log_checkpoint("Batch Name: "+batch_name,500,capture_window)
  delay(1000)
  prop_values = ["Date/Time Created:","JTextField","javax.swing.JTextField"]
  date_time = capture_window.FindChildEx(prop_names,prop_values,30,True,500).wText
#  self.log_message_web("Date Time: "+VarToStr(date_time))
  self.log_checkpoint_message_web("Date_Time: "+VarToStr(date_time))
#  web_utils.log_checkpoint("Date Time: "+date_time,500,capture_window)
  delay(1000)
#  batch_notes = wcc_home_page.batch_notes_textfield().wText
  prop_values = ["Batch Notes:","JTextArea","javax.swing.JTextArea"]
  batch_notes = capture_window.FindChildEx(prop_names,prop_values,30,True,500).wText
#  self.log_message_web("Batch_Notes: "+VarToStr(batch_notes))
  self.log_checkpoint_message_web("Batch Notes: "+VarToStr(batch_notes))
#  web_utils.log_checkpoint("Batch_Notes: "+VarToStr(batch_notes),500,capture_window)
  
  return batch_name,date_time,batch_notes
  
 def refresh(self):
   capture_window = Sys.Process("capture").WaitWindow("SunAwtFrame", "Oracle WebCenter Enterprise Capture - Connected to https://core-capture-dev.epfinnp.coxautoinc.com", 1,10000)
   prop_names = ["AWTComponentName","JavaClassName"]
   prop_values = ["btnRefreshBatches","JButton"]
   delay(1200)
   refresh_button = capture_window.FindChildEx(prop_names,prop_values,30,True,90000)
   refresh_button.Click()
   Delay(2000)
   
 def validate_batch_release(self,app,ocr_key):
    capture_window = Sys.Process("capture").WaitWindow("SunAwtFrame", "Oracle WebCenter Enterprise Capture - Connected to https://core-capture-dev.epfinnp.coxautoinc.com", 1,10000)
    prop_names = ["JavaClassName", "AWTComponentIndex","JavaFullClassName"]
    prop_values = ["BatchEditForm$43",0,"oracle.oddc.client.BatchEditForm$43"]
    batch_list = capture_window.FindChildEx(prop_names,prop_values,30,True,90000) 
    OCR.Recognize(batch_list).BlockByText(ocr_key, spTopMost).Click()
#    batch_list.FindID(b_id).click() 
    delay(2000)  
# Get Batch Details and Validate for Required Batch:
    prop_names = ["AWTComponentAccessibleName","JavaClassName","JavaFullClassName"]
    prop_values = ["Batch Name:","JTextField","javax.swing.JTextField"]
    batch_name = capture_window.FindChildEx(prop_names,prop_values,30,True,90000)
    i = 0
    while batch_name.Exists == None: 
     OCR.Recognize(batch_list).BlockByText(ocr_key, spTopMost).Click()
     i = i + 1
     if i == 4:
      self.log_error_message("Unable to Validate the Release: Test Failed")
      
    batch_name,date_time,batch_notes = self.get_batch_details_post_release()
    if batch_name == VarToStr(app.Cells.item[2,2]):
       self.log_error_message("Unable to Verify the Release for Batch : "+VarToStr(app.Cells.item[2,2])+" Batch Record Still Present - Test Failed")
    web_utils.log_checkpoint("Able to Verify the Release for :"+VarToStr(app.Cells.item[2,2])+" - Batch Record Removed from the Page",500,capture_window)
    
 def validate_doc_panel(self,document_no):
    delay(11000)
    capture_window = Sys.Process("capture").WaitWindow("SunAwtFrame", "Oracle WebCenter Enterprise Capture - Connected to https://core-capture-dev.epfinnp.coxautoinc.com", 1,10000)
    cnt = capture_window.FindAllChildren("JavaClassName","JSplitPane",60)
    combo_list=cnt[1].FindAllChildren("AWTComponentName","ComboBox.textField",40)
    prop_names = ["AWTComponentIndex","JavaClassName","JavaFullClassName"]
    prop_values = [0,"ImageViewer","oracle.odc.imageviewer.ImageViewer"]
    ImageViewer =  capture_window.FindChildEx(prop_names,prop_values,30,True,120000)
    Sys.HighlightObject(ImageViewer)
    combo_list[0].Keys("CAIAPAccountDistribution")
#    combo_list[4].Keys("SPL")
    delay(2000)
    combo_list[2].Keys("XTC")
#    Delay(1000)
#    combo_list[3].Keys("No")
#-print local
    web_utils.log_checkpoint("Verified the Document Profile Details Successfully for document no - "+IntToStr(document_no)+": Ready to Release",500,capture_window)
     
 def get_batch_details_post_release(self):
  capture_window = Sys.Process("capture").WaitWindow("SunAwtFrame", "Oracle WebCenter Enterprise Capture - Connected to https://core-capture-dev.epfinnp.coxautoinc.com", 1,10000)
  prop_names = ["AWTComponentAccessibleName","JavaClassName","JavaFullClassName"]
  prop_values = ["Batch Name:","JTextField","javax.swing.JTextField"]
  batch_name = capture_window.FindChildEx(prop_names,prop_values,30,True,500).wText
  delay(1000)
  prop_values = ["Date/Time Created:","JTextField","javax.swing.JTextField"]
  date_time = capture_window.FindChildEx(prop_names,prop_values,30,True,500).wText
  delay(1000)
  prop_values = ["Batch Notes:","JTextArea","javax.swing.JTextArea"]
  batch_notes = capture_window.FindChildEx(prop_names,prop_values,30,True,500).wText
  return batch_name,date_time,batch_notes
  
def test():

#    wscript=Sys.OleObject["WScript.Shell"]
#    wscript.Run("C:\\Users\\degantest01\\AppData\\Local\\Oracle\\capture\\capture.exe")
  location = "APINV"
  oc = aqString.SubString(location,1,3)
#  capt = Sys.Process("capture").SwingObject("RMCMain", "Oracle WebCenter Enterprise Capture - Connected to https://core-capture-dev.epfinnp.coxautoinc.com", 0)
  capture_window = Sys.Process("capture").WaitWindow("SunAwtFrame", "Oracle WebCenter Enterprise Capture - Connected to https://core-capture-dev.epfinnp.coxautoinc.com", 1,10000)
  release_button = capture_window.FindChild("AWTComponentAccessibleName","Release",30)
  while not release_button.Exists:
    delay(1000)
    capture_window.Keys("^~r")
    delay(1000)
    capture_window.Keys("[Down][Down][Enter]")
    delay(1000)
    release_button = capture_window.FindChild("AWTComponentAccessibleName","Release",30)
  release_button.Click()





#  capture_window = Sys.Process("capture").WaitWindow("SunAwtFrame", "Oracle WebCenter Enterprise Capture - Connected to https://core-capture-dev.epfinnp.coxautoinc.com", 1,10000)
  signout_link = capture_window.FindChild("AWTComponentAccessibleName","Signed In As devtest",30)
#  Sys.HighlightObject(signout_link)
  signout_link.Click()
  delay(1000)
  capture_window.Close()
  capture_window.Keys("[Down][Down][Down][Down]")
  delay(500)
  capture_window.Keys("[Enter]")
#  prop_names = ["JavaClassName", "AWTComponentIndex","JavaFullClassName"]
#  prop_values = ["VetoableComboBox",0,"oracle.odc.component.VetoableComboBox"]
#  location_text = capture_window.FindAllChildren("JavaClassName","VetoableComboBox",30)
#  prop_names = ["JavaClassName", "AWTComponentIndex","JavaFullClassName"]
#  prop_values = ["BatchEditForm$43", "0","oracle.oddc.client.BatchEditForm$43"]
#  batch_list = capture_window.FindChildEx(prop_names,prop_values,30,True,90000)
#  value = "ETS"
#  value1 = "TEST"
#  while StrMatches(value,value1)!= True:
#    value1 = OCR.Recognize(batch_list).BlockByText("ETS*").text
#    delay(2190)
#  prop_names = ["AWTComponentAccessibleName","JavaClassName","JavaFullClassName"]
#  prop_values = ["Batch Notes:","JTextArea","javax.swing.JTextArea"]
#  batch_notes = capture_window.FindChildEx(prop_names,prop_values,30,True,90000).wText
#  
#  prop_names = ["JavaClassName", "AWTComponentIndex","JavaFullClassName"]
#  prop_values = ["BatchEditForm$43", "0","oracle.oddc.client.BatchEditForm$43"]
#  Sys.HighlightObject(capture_window.FindChildEx(prop_names,prop_values,30,True,90000))
#  batch_list = capture_window.FindChildEx(prop_names,prop_values,30,True,90000)
#  OCR.Recognize(batch_list).BlockByText("APINV*", spTopMost).Click()
#  b_id = batch_list.Id
#  batch_list.FindID(b_id).click() 
#  
  cnt = capture_window.FindAllChildren("JavaClassName","JSplitPane",60)
  combo_list=cnt[1].FindAllChildren("AWTComponentName","ComboBox.textField",40)
  prop_names = ["JavaClassName", "AWTComponentIndex","JavaFullClassName"]
  prop_values = ["BatchEditForm$43", "0","oracle.oddc.client.BatchEditForm$43"]
  Sys.HighlightObject(capture_window.FindChildEx(prop_names,prop_values,30,True,90000))
  capt.FindChild()










