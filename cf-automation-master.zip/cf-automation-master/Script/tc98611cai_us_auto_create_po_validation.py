﻿from ebiz import *
import web_utils
import form_utils
import file_system_utils
import ebiz
import dbhelper


class tc98611cai_us_auto_create_po_validation(Ebiz):
  global rowno, val
  rowno = 2
  
  
  def action(self,book):
    
    self.op_log_path="C:\\TC_PO"
    
    app = book.Sheets.item["Invoice"]   
    app1 = book.Sheets.item["Requisition"]  
    self.wait_until_page_loaded()    
    self.log_checkpoint_message_web("Login Successful")    
    temp=web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" PO PROCESS PURCHASE ORDERS')]")       
    self.verify_aqobject_chkproperty(temp[0],"contentText",cmpIn,"CAI "+self.oper_unit+" PO PROCESS PURCHASE ORDERS")
    self.log_message_web("Click 'CAI "+self.oper_unit+" PO PROCESS PURCHASE ORDERS' - Successful")      
    self.wait_until_page_loaded()        
    web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Purchase Order Summary')]")       
    self.log_message_web("Click 'Purchase Order Summary' - Successful") 
    self.wait_until_page_loaded() 
    Delay(2000)
    web_utils.validate_security_box()
    Delay(20000)      
    jFrame= self.initializeJFrame()
    Delay(2000)
    form_utils.click_ok_btn(jFrame)
    Delay(3000)   
    
    #PO Oracle Form Validation: 
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Purchase Orders","ExtendedFrame"]
    po_form=jFrame.FindChildEx(prop,val,60,True,120000)
    self.verify_aqobject_chkproperty(po_form,"AWTComponentAccessibleName",cmpContains,"Find Purchase Orders")
    Delay(2000)
    po_form.Find("AWTComponentAccessibleName","SupplierList of Values",10).Click()
    po_form.Find("AWTComponentAccessibleName","SupplierList of Values",10).Keys(app1.Cells.Item[rowno,9])
    Delay(1500)
    po_form.Find("AWTComponentName","FormsTabPanel*",60).ClickTab("Date Ranges")
    Delay(3000)
    date = aqDateTime.Today()
    date1 = aqConvert.DateTimeToFormatStr(date,"%d-%b-%Y")
    date2 = aqConvert.DateTimeToFormatStr(date,"%d-%b-%Y 23:59:00")
#    Log.Message("date2 "+date2)
    Delay(1000)
    po_form.Find("AWTComponentAccessibleName","*Order*FromList of Values",30).SetText(date1)
    po_form.Keys("[Tab]")
    po_form.Find("AWTComponentAccessibleName","Order Creation Date : ToList of Values",30).SetText(date2)
    po_form.Keys("[Tab]")
    delay(2000)
    po_form.Find("AWTComponentAccessibleName","Find alt J",30).Click()
    
    #Validate PO Number and Open PO:
    val = ["Purchase Order Headers","ExtendedFrame"]
    po_hform=jFrame.FindChildEx(prop,val,60,True,120000)
    self.verify_aqobject_chkproperty(po_hform,"AWTComponentAccessibleName",cmpContains,"Purchase Order Headers")
    req = app1.Cells.Item[rowno,15]
    delay(2000)
    dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
    user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
    pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
    po_number = dbhelper.query_po_no(dsn,user_id,pwd,VarToStr(req))
#
#    po_number = dbhelper.query_po_no(VarToStr(req))

    app.Cells.Item[rowno,14] = po_number
    Delay(2000)
    i = 1
    for x in range(1,20):
      pro = ["AWTComponentAccessibleName","AWTComponentIndex"]
      val=["Number Required",i]
      po_value = po_hform.Find(pro,val,60).wText
      if StrToInt(po_number) == StrToInt(po_value):
        po_hform.Find(pro,val,60).Click()
        break
      else:
        po_hform.Keys("[Down]")
        i = i+1

    po_hform.Keys("~o")
    
    #PO Details Page Validation:
    pro = ["AWTComponentAccessibleName","JavaClassName"]
    val=["Purchase Order Summary to Purchase Orders*","ExtendedFrame"]
    po_ordForm=jFrame.FindChildEx(pro,val,60,True,120000)
    
    po_ordForm.Keys("~m")
    Delay(2000)
    po_ordForm.Find("AWTComponentAccessibleName","Terms tab page Terms tab page PaymentList of Values",50).Click()
    po_ordForm.Keys("[BS]")
    Delay(1000)
    po_ordForm.Keys("Immediate")
    Delay(1000)
    po_ordForm.Keys("[Tab]")
    Delay(3000)
    po_ordForm.Keys("^s")
    Delay(5000)
    val = ["Note You are creating a new document revision","ChoiceBox"]
    jFrame.FindChildEx(pro,val,30,True,400000)
    Delay(2000)
    po_ordForm.Keys("~o")
    Delay(5000)
    po_ordForm.Keys("~w")  
    po_ordForm.Keys("4")   
    Delay(2000)

    po_status = po_ordForm.Find("AWTComponentAccessibleName","Status",60).wText

    if po_status == "Approved":
      self.log_message_oracle_form(po_ordForm,"Purchase Order :"+po_number+" autocreated and approved")
      
    elif po_status == "Requires Reapproval":
      i = 0
      while po_status!="Approved":
        po_ordForm.Keys("~a")  
        Delay(2000)
        po_ordForm.Keys("~k")  
        Delay(4000)
        po_ordForm.FindChildEx("AWTComponentAccessibleName","Purchase Order Number",40,True,200000)
        Delay(1000)
        Log.Enabled = True
        po_ordForm.Keys("[F11]")
        Delay(2000)
        po_ordForm.Find("AWTComponentAccessibleName","Purchase Order Number",10).Click()
        Delay(1000)
    #    po_form.Find("AWTComponentAccessibleName","Purchase Order Number",10).SetText(Project.Variables.po_number)
        po_ordForm.Find("AWTComponentAccessibleName","Purchase Order Number",10).Keys(VartoInt(po_number))
        Delay(2000)
        po_ordForm.Keys("[Tab]")
        Delay(1000)
        jFrame.Keys("^[F11]")
        Log.Enabled = False
        Delay(10000)
        po_status = po_ordForm.Find("AWTComponentAccessibleName","Status",60).wText
        i = i+1
        if i == 2:
          self.log_error_message("Purchase Order: "+po_number+" is not Approved- Manual Validation Required")
    elif po_status == "Incomplete":
        Delay(1000)  
        po_form.Keys("~a") 
        self.log_message_oracle_form(po_form,"Successfully clicked on Approve button")       
        Delay(4000)    
        prop=["AWTComponentAccessibleName","JavaClassName"]
        val=["Approve Document*","ExtendedFrame"] 
        approve_doc_form=jFrame.FindChildEx(prop,val,60,True,120000) 
        Delay(2000)
        self.verify_aqobject_chkproperty(approve_doc_form,"AWTComponentAccessibleName",cmpContains,"Approve Document - "+aqConvert.VarToStr(po_number))  
        approve_doc_form.Keys("~k")    
        Delay(4000) 
        self.log_message_oracle_form(po_form,"Successfully clicked on Approve Document 'OK' button")  
    else:
      self.log_error_message("Purchase Order: "+po_number+" is not Approved- Manual Validation Required")
    Delay(3000) 
    po_form.Keys("[F4]")
    Delay(3000)
    jFrame.Keys("[F4]")
    Delay(2000)
    jFrame.Keys("~o") 
 
#    pro = ["AWTComponentIndex","JavaClassName"]
#    val=[0,"LWMenuBar"]
#    po_ord_header = jFrame.FindChildEx(pro,val,60,True,20000)
#
#    OCR.Recognize(po_ord_header).BlockByText("Inquire").Click()
#    Delay(1000)
#    po_ord_header.Keys("m")
#    self.wait_until_page_loaded() 
#    Delay(2000)
#    
#    #Create Document and Save in Local:
#    notify = Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Notification Bar", "", 1).UIAObject("Notification")
#    notify.UIAObject("Save").UIAObject(1).Click()
#
#    Delay(1000)
#    notify.Keys("[Down]")
#    Delay(1000)
#    notify.Keys("[Enter]")
#    self.wait_until_page_loaded()
#    file_system_utils.create_folder(self.op_log_path)
#        
#    file_exist=aqFileSystem.FindFiles("C:\\TC_PO\\","*.pdf") 
#    if file_exist != None:
#     aqFileSystem.DeleteFile("C:\\TC_PO\\*.pdf")    
#         
#    log_path=self.op_log_path+"\\PO_Number "+VarToStr(po_number)+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".pdf"    
#    Sys.Browser("iexplore").Window("#32770", "Save As", 1).Keys(log_path)
#    Delay(1000)
#    Sys.Browser("iexplore").Window("#32770", "Save As", 1).Keys("[Enter]")
#    Delay(2000)
#    notify.UIAObject("Close").Click()
    Delay(4000)
    Sys.Browser("iexplore").page("https://core-*.epfinnp.coxautoinc.com/forms/frmservlet*").Close()
#    self.close_forms()

