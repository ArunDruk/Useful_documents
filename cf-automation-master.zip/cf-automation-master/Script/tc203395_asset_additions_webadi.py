﻿from ebiz import *
import web_utils
import form_utils
import dbhelper
import file_system_utils
import datetime

class tc203395_asset_additions_webadi(Ebiz):

 op_log_path ="C:\\TC_Logs" 

 def login(self):
   self.login_user='pkjami'
   super().login()
 
 def goto_url(self,url):
   super().goto_url(self.testConfig['ebiz']['oci_is_url'])
   
 def action(self,book):
   app = book.Sheets.item["asset_creation"]
   count = app.UsedRange.Rows.Count
   web_utils.log_checkpoint("Login to Oracle Applications Successful",500,self.page) 
    
# Navigation to Oracle Home Page

   web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='menuContent']//div[contains(text(),'AM Super User')]") 
   self.wait_until_page_loaded()
   self.page.NativeWebObject.Find("contentText","Mass Additions","A").Click()
   web_utils.log_checkpoint("Click 'Mass Additions' - Successful",500,self.page)
   delay(2000)
   self.page.NativeWebObject.Find("contentText","Additions Integrator","A").Click()
   web_utils.log_checkpoint("Click 'Additions Integrator' - Successful",500,self.page)
   self.wait_until_page_loaded()

#Navigating to AM Super USER & Launching WebADI template

   if self.page.FindChild("contentText","Create Document",30).Exists:
     self.page.Find("idStr","Viewer",30).ClickItem("Excel 2016")
     delay(2000)
     self.page.Find("idStr","Layout",30).ClickItem("MAN Add Assets - Detailed")
     web_utils.log_checkpoint("Selecting WebADI template 'MAN Add Assets - Detailed' - Successful",500,self.page)  
   else:
     web_utils.log_error("Unable to navigate to 'Create Documents' Page")
   Delay(3000)
   self.page.FindChild("idStr","createDocument",30).Click()
   Delay(20000)  
   Sys.Browser("iexplore").BrowserWindow(0).Window("Frame Notification Bar", "", 1).UIAObject("Notification").UIAObject("Open").Click() 
   web_utils.close_excel_sign_in_window()
   xl_window=Sys.Process("EXCEL", 2).Window("XLMAIN", "Fixed Assets - Additions*", 1).Window("XLDESK", "", 1).Window("EXCEL7", "Fixed Assets - Additions*", 1)
   Delay(10000)
   Log.Enabled=True
   wnd = Sys.Desktop.ActiveWindow()
   Log.Picture(wnd, "WebADI Template has been launched for adding Asset Details (Mass Additions)", wnd.FullName)                  
   Log.Enabled=False 
   
# Enter Required Asset Addition Details:

   self.enter_asset_values(xl_window,app,count)
   Log.Enabled=True
   wnd = Sys.Desktop.ActiveWindow()
   Log.Picture(wnd, "Asset Details for Addition have been entered in WebADI successfully", wnd.FullName)                  
   Log.Enabled=False 
   if Sys.Process("EXCEL", 2).Window("XLMAIN", "Fixed Assets - Additions*", 1).Window("EXCEL2", "", 2).Window("MsoCommandBar", "Ribbon", 1).Window("MsoWorkPane", "Ribbon", 1).Window("NUIPane", "", 1).Window("NetUIHWND", "", 1).Exists:
      excel_obj=Sys.Process("EXCEL", 2).Window("XLMAIN", "Fixed Assets - Additions*", 1).Window("EXCEL2", "", 2).Window("MsoCommandBar", "Ribbon", 1).Window("MsoWorkPane", "Ribbon", 1).Window("NUIPane", "", 1).Window("NetUIHWND", "", 1)
      Sys.HighlightObject(excel_obj)
   elif  Sys.Process("EXCEL", 2).Window("XLMAIN", "Fixed Assets - Additions*", 1).Window("EXCEL2", "", 3).Window("MsoCommandBar", "Ribbon", 1).Window("MsoWorkPane", "Ribbon", 1).Window("NUIPane", "", 1).Window("NetUIHWND", "", 1).Exists:
      excel_obj=Sys.Process("EXCEL", 2).Window("XLMAIN", "Fixed Assets - Additions*", 1).Window("EXCEL2", "", 3).Window("MsoCommandBar", "Ribbon", 1).Window("MsoWorkPane", "Ribbon", 1).Window("NUIPane", "", 1).Window("NetUIHWND", "", 1)
      Sys.HighlightObject(excel_obj) 
   Delay(1730)
   excel_obj.Keys("~")
   Delay(1000)
   excel_obj.Keys("Y1")
   Delay(1432)
   oracle_menu = Sys.Process("EXCEL", 2).Window("Net UI Tool Window", "", 1).Window("NetUIHWND", "", 1)
   Sys.HighlightObject(oracle_menu) 
   Log.Enabled=True
   wnd = Sys.Desktop.ActiveWindow()
   Log.Picture(wnd, "Click Oracle menu option and select upload menu", wnd.FullName)                  
   Log.Enabled=False
   Delay(1000)
   OCR.Recognize(excel_obj).BlockByText("Upload").Click()
 
   oracle_menu.Keys("U")
   oracle_menu.Keys("P")
   Delay(4000) 

   
#Uploading Asset Details:

   upload_wnd=Sys.Process("EXCEL",2).WaitWindow("ThunderDFrame", "Create Assets Upload", 1,20000)
   if upload_wnd.Exists:
       
       Sys.Process("EXCEL",2).Window("ThunderDFrame", "Create Assets Upload", 1).Find("idStr","M__Idc",40).Click()
       delay(1000)
       self.log_message_oracle_excel_popup(upload_wnd,"Select 'Create Assets' option in the upload window")
       delay(2000)
       Sys.Process("EXCEL",2).Window("ThunderDFrame", "Create Assets Upload", 1).Find("ObjectLabel","Upload",40).Click()
       Delay(60000)
       
       if upload_wnd.Find("ObjectIdentifier","errorl_gif",40).Exists:
         self.log_message_oracle_excel_popup(upload_wnd,"Asset Addition Upload Failed!!")
         Log.Error("Asset Addition WebADI Upload Failed.") 
         Runner.Stop()                 
       else:
         Log.Enabled=True
         wnd = Sys.Desktop.ActiveWindow()
         Log.Picture(wnd, "Asset Addition WebADI Upload Passed",wnd.FullName)
         Log.Enabled=False
   delay(1000)      
   conf_msg=upload_wnd.Find("idStr","BneAsyncUploadPageConfirmation",40).contentText 
   delay(1000)
   self.log_message_oracle_excel_popup(upload_wnd,"Confirmation Message:- "+aqConvert.VarToStr(conf_msg))
   Delay(4000)            
   upload_wnd.Find("ObjectLabel","Close",20).Click() 
   post_req_id=conf_msg.split("Request ID",4)[1][1:10]
   post_rep_req_id = conf_msg.split("Request ID",4)[2][1:10]
   app.Cells.Item[2,24] =VarToStr(post_req_id)
   app.Cells.Item[2,25] =VarToStr(post_rep_req_id)
   Delay(4000) 
   xl_window.Keys("~[F4]")
   Delay(5300)
   xl_window.Keys("[Enter]")
   delay(4000)
   
# Save Template:
 
   file_system_utils.create_folder(self.op_log_path) 
     
   log_path=self.op_log_path+"\\Asset Addition Web ADI Sheet"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"_%d%b%Y_%H%M")   
   Sys.Browser("iexplore").Window("#32770", "Save As", 1).Keys(log_path)
   Delay(5000)
   Sys.Browser("iexplore").Window("#32770", "Save As", 1).Keys("[Enter]")
   Delay(2000)
   if Sys.Process("EXCEL", 2).Window("#32770", "Microsoft Excel", 1).Exists:
     Sys.Process("EXCEL", 2).Window("#32770", "Microsoft Excel", 1).Keys("[Enter]")
     delay(1000)
   Log.Enabled=True
   Log.File(log_path+".xlsm","Asset Addition WebADI Sheet with details attached for reference")
   Log.Enabled=False
   delay(2000)
   
#Navigating to AM Super User > Other Requests > Run to validate the Asset Additions Requests:
   
   self.page.Keys("[Down]")
   delay(1000)
   self.page.NativeWebObject.Find("contentText","Other","A").Click()
   web_utils.log_checkpoint("Click 'Other' - Successful",500,self.page) 
   self.wait_until_page_loaded()
   delay(1000)
   self.page.Keys("[Down]")
   self.page.NativeWebObject.Find("contentText","Requests","A").scrollIntoView()
   self.page.NativeWebObject.Find("contentText","Requests","A").Click()
   web_utils.log_checkpoint("Click 'Requests' - Successful",500,self.page)
   self.wait_until_page_loaded()
   delay(1000)
   self.page.Keys("[Down]")
   self.page.NativeWebObject.Find("contentText","Run","A").scrollIntoView()
   self.page.NativeWebObject.Find("contentText","Run","A").Click()
   web_utils.log_checkpoint("Click 'Run' - Successful",500,self.page)
   web_utils.validate_security_box()
   Delay(10000)
   jFrame=self.initializeJFrame()
   Delay(15000)
   form_utils.click_ok_btn(jFrame) 
   Delay(7000)
   jFrame.Keys("~c")
   Delay(3000)
   form_utils.save_output_singlereq(self,jFrame,self.op_log_path,"Mass Additions Post",post_req_id)
   Delay(5000)
   self.close_forms(jFrame)
   Delay(5000)
   self.page.EvaluateXpath("//li[@id='LIRequests']/a/div[2]")[0].scrollIntoView()
   self.page.EvaluateXpath("//li[@id='LIRequests']/a/div[2]")[0].Click()
   web_utils.log_checkpoint("Navigating to Requests Form to Validate Mass Additions Posting Report",500,self.page)
   web_utils.validate_security_box()
   Delay(10000)
   jFrame=self.initializeJFrame()
   Delay(20000)
   form_utils.click_ok_btn(jFrame) 
   Delay(7000)
   jFrame.Keys("~c")
   Delay(3000)
   form_utils.save_output_singlereq(self,jFrame,self.op_log_path,"Mass Additions Posting Report",post_rep_req_id)
   jFrame.Click()
   Delay(3000)
   jFrame.Keys("[F4]")
   Delay(3000)

   wscript=Sys.OleObject["WScript.Shell"]
   wscript.Run("taskkill.exe /F /IM jp2launcher.exe /T")
   Delay(3000)

# Method to Enter Asset Values in WebADI Template:

 def enter_asset_values(self,xl_window,app,count):  
   rowno=2
   i = 0
   for i in range (i,count):
     xl_window.Click()
     Delay(2000)
     cell = VarToStr("C"+VarToStr(14+i))
     xl_window.keys("^g")
     Delay(2000)
#     if gvar.dataprep['env'] == "oci_test":
     goTo_wnd=Sys.Process("EXCEL", 2).Window("bosa_sdm_XL9", "Go To", 1).Window("EDTBX", "", 1)
#     elif gvar.dataprep['env'] == "oci_stage":
#      goTo_wnd=Sys.Process("EXCEL", 2).Window("bosa_sdm_XL9", "Go To", 1).Window("RichEdit20W", "", 1)
     goTo_wnd.Click()
#     goTo_wnd.Keys("[Del]")
     goTo_wnd.Keys("[BS]")
     goTo_wnd.Keys("[BS]")
     goTo_wnd.Keys("[BS]")
     Delay(1000)
     goTo_wnd.Keys(cell)   
     Delay(1000)
     goTo_wnd.keys("[Enter]")
     Delay(1000)
     Asset_Desc = VarToStr("Test_Asset_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),'%y%m%d%H%M%S'))
     serial_no = VarTostr("Asset_SNo: "+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),'%y%m%d%H%M%S'))
     app.Cells.item[rowno+i,1] =  Asset_Desc
     xl_window.Keys(Asset_Desc)
     Delay(1000)
     xl_window.Keys("[Tab]")
     Delay(1000)
     xl_window.Keys(app.Cells.Item[rowno+i,2])
     delay(1000)
     xl_window.Keys("[Tab]")
     delay(1000)
     xl_window.Keys(app.Cells.Item[rowno+i,3])
     Delay(1000)
     xl_window.Keys("[Tab]")
     Delay(1000)
     xl_window.Keys(app.Cells.Item[rowno+i,4])
     delay(1000)
     xl_window.Keys("[Tab]")
     Delay(1000)
     xl_window.Keys(app.Cells.Item[rowno+i,5])
     Delay(1000)
     xl_window.Keys("[Tab]")
     Delay(1000)
     xl_window.Keys(app.Cells.Item[rowno+i,6])
     delay(1000)
     xl_window.Keys("[Tab]")
     delay(1000)
     xl_window.Keys(app.Cells.Item[rowno+i,7])
     Delay(1000)
     xl_window.Keys("[Tab]")
     Delay(1000)
     xl_window.Keys(app.Cells.Item[rowno+i,8])
     delay(1000)
     xl_window.Keys("[Tab]")
     Delay(1000)
     xl_window.Keys(app.Cells.Item[rowno+i,9])
     Delay(1000)
     xl_window.Keys("[Tab]")
     Delay(1000)
     xl_window.Keys(app.Cells.Item[rowno+i,10])
     delay(1000)
     xl_window.Keys("[Tab]")
     delay(1000)
     xl_window.Keys(app.Cells.Item[rowno+i,6]) 
     delay(1000)
     xl_window.Keys("[Tab]")
     delay(1000)    
     xl_window.Keys(app.Cells.Item[rowno+i,11])
     Delay(1000)
     xl_window.Keys("[Tab]")
     Delay(1000)
     xl_window.Keys(app.Cells.Item[rowno+i,12])
     delay(1000)
     xl_window.Keys("[Tab]")
     Delay(1000)
     xl_window.Keys(app.Cells.Item[rowno+i,13])
     Delay(1000)
     xl_window.Keys("[Tab]")
     Delay(1000)
     xl_window.Keys(app.Cells.Item[rowno+i,14])
     delay(1000)
     xl_window.Keys("[Tab]")
     delay(1000)
     xl_window.Keys(app.Cells.Item[rowno+i,15])
     Delay(1000)
     xl_window.Keys("[Tab]")
     Delay(1000)
     xl_window.Keys(app.Cells.Item[rowno+i,16])
     delay(1000)
     xl_window.Keys("[Tab]")
     Delay(1000)
#     xl_window.Keys(app.Cells.Item[rowno+i,17])
#     delay(1000)
#     xl_window.Keys("[Tab]")
     if i == 0:
      dis = aqConvert.DateTimeToFormatStr(aqDateTime.Now(),'%d-%b-%Y')
      asset_serv_date =  aqConvert.DateTimeToFormatStr(aqDateTime.Now(),'%d%m%y')
     else:
       previous_date = datetime.datetime.today() - datetime.timedelta(days=365) 
       dis = aqConvert.DateTimeToFormatStr(previous_date,'%d-%b-%y') 
       asset_serv_date =  aqConvert.DateTimeToFormatStr(previous_date,'%d%m%y')
     delay(1000)
     xl_window.Keys(dis)
     delay(1000)
     xl_window.Keys("[Tab]")
     delay(1000)
     xl_window.Keys(app.Cells.Item[rowno+i,18])
     delay(1000)
     xl_window.Keys("[Tab]")
     xl_window.Keys("[Tab]")
     delay(1000)
     xl_window.Keys(serial_no)
     delay(1000)
     xl_window.Keys("[Tab]")
     xl_window.Keys("[Tab]")
     xl_window.Keys("[Tab]")
     delay(1000)
     if i == 0:
      xl_window.Keys(app.Cells.Item[rowno+i,19])  
     else:
       asset_cost = VarToInt(app.Cells.Item[rowno+i,5])
       asset_life = VarToInt(app.Cells.Item[rowno+i,22])
       
       acc_deprc,ytd_deprc = self.get_depr_values(asset_cost,asset_life,asset_serv_date)
       xl_window.Keys(acc_deprc)
     delay(1000)
     xl_window.Keys("[Tab]")
     delay(1000)
     if i == 0:
      xl_window.Keys(app.Cells.Item[rowno+i,20])
     else:
      xl_window.Keys(ytd_deprc)
     delay(1000)
     xl_window.Keys("[Tab]")
     xl_window.Keys("[Tab]")
     xl_window.Keys("[Tab]")
     delay(1000)
     xl_window.Keys(app.Cells.Item[rowno+i,21])  
     delay(1000)
     xl_window.Keys("[Tab]")
     delay(1000)
     xl_window.Keys(app.Cells.Item[rowno+i,22])
     delay(1000)
     xl_window.Keys("[Tab]")
     delay(1000)
     xl_window.Keys(app.Cells.Item[rowno+i,23])
     delay(1000)
     xl_window.Keys("[Tab]")
     if i == 1:
        break

# Method to get depreciation details:       
           
 def get_depr_values(self,asset_cost,asset_life,asset_serv_date):
     
   py_month = aqString.SubString(asset_serv_date,2,2)
   py_mo_val = "%.2f" % (VarToFloat(13 - VarToInt(py_month)))
   sysdate = aqConvert.DateTimeToFormatStr(aqDateTime.Now(),'%d%m%y')
   cy_month = "%.2f" % (VarToFloat(aqString.SubString(sysdate,2,2)))
   tot_months = "%.2f" % (VarToFloat(VarToInt(py_mo_val) + VarToInt(cy_month)))
   deprc_valper_month = "%.2f"  % (VarToFloat(asset_cost/asset_life))
   acc_deprc = VarToFloat(VarToInt(deprc_valper_month) * VarToInt(tot_months))
   ytd_deprc = VarToFloat(VarToInt(deprc_valper_month) * VarToInt(cy_month))
   return acc_deprc,ytd_deprc
   
 def navigate_requests(self):
   self.page.NativeWebObject.Find("contentText","Other","A").Click()
   web_utils.log_checkpoint("Click 'Other' - Successful",500,self.page) 
   self.wait_until_page_loaded()
   delay(1000)
   self.page.Keys("[Down]")
   self.page.NativeWebObject.Find("contentText","Requests","A").scrollIntoView()
   self.page.NativeWebObject.Find("contentText","Requests","A").Click()
   web_utils.log_checkpoint("Click 'Requests' - Successful",500,self.page)
   self.wait_until_page_loaded()
   delay(1000)
   self.page.Keys("[Down]")
   self.page.NativeWebObject.Find("contentText","Run","A").scrollIntoView()
   self.page.NativeWebObject.Find("contentText","Run","A").Click()
   web_utils.log_checkpoint("Click 'Run' - Successful",500,self.page)
   web_utils.validate_security_box()
   Delay(10000)
   jFrame=self.initializeJFrame()
   Delay(15000)
   form_utils.click_ok_btn(jFrame) 
   Delay(7000)
   jFrame.Keys("~c")
   Delay(3000)
   
  
