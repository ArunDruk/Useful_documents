﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils
import web_utils


class tc172393_is_us_next_day_check_payment(Ebiz):
 global rowno, app

  
 def login(self):
    self.login_user="rmaran"
    super().login()
 
 def goto_url(self,url):
   super().goto_url(self.testConfig['ebiz']['oci_is_url'])

 def action(self,book): 
    app = book.Sheets.item["Invoice"]
    app1 = book.Sheets.item["Requisition"]
    rowno = 2  
    self.wait_until_page_loaded()
    web_utils.log_checkpoint("Logged in to Oracle Applications Home Page Successfully",500,self.page)  
    self.page.EvaluateXPath("//table[@id='menuContent']//div[contains(text(),'AP Home Office Super User')]")[0].Click() 
    web_utils.log_checkpoint("Click 'AP Home Office Super User' - Successful",500,self.page) 
    self.page.Keys("[Down]")
    self.wait_until_page_loaded()
    self.page.NativeWebObject.Find("contentText","Payments","A").Click()
    web_utils.log_checkpoint("Click 'Payments' - Successful",500,self.page) 
    self.page.Keys("[Down]")
    self.page.Keys("[Down]")
    self.wait_until_page_loaded()
    self.page.EvaluateXpath("//table[@id='respList']//div[contains(text(),'Entry')]")[2].Click() 
    self.page.NativeWebObject.Find("contentText","Entry","A").Click()
    self.page.Keys("[Down]")
    self.wait_until_page_loaded()
    self.page.EvaluateXpath("//table[@id='respList']//div[contains(text(),'Payments Manager')]")[0].Click() 
    web_utils.log_checkpoint("Click 'Payments Manager' - Successful",500,self.page)
    self.page.wait_until_page_loaded()
    
    while self.page.contentDocument.readyState != "complete":
      Delay(1000)
    cai_ap_subreq_link=self.page.Find("contentText","Submit Single Payment Process Request",30)
    cai_ap_subreq_link.Click() 
    web_utils.log_checkpoint("Click Submit Single Payment Process Request - Successful",500,self.page) 
    self.page.wait_until_page_loaded()
    Delay(3000)
    self.page.Find("idStr","CheckrunName",30).Click()
    pay_des="MAN_AP_ND_Check_Payment_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")
    self.page.Find("idStr","CheckrunName",30).Keys(pay_des)
    web_utils.log_checkpoint("Enter 'Payment Process Request Name' - Successful",500,self.page) 
    delay(2000)
    self.page.Find("idStr","TemplateName",30).Click()
    self.page.Find("idStr","TemplateName",30).Keys("WF Next Day Check")
    self.page.Keys("[Tab]")
    popup_wnd = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/OA_HTML/cabo/jsps/a.jsp*").Frame(0)
    Delay(2000) 
    popup_wnd.Find("idStr","N1:N8:0",30).Click()
    Delay(5000) 
    popup_wnd.Find("contentText","Select",30).Click()
    Delay(5000)
    self.wait_until_page_loaded()
    web_utils.log_checkpoint("Select 'Payment Template' - Successful",500,self.page) 
    delay(2000) 
    self.page.Find("idStr","Payee",30).Click()
    payee = app1.Cells.Item[rowno,9]
    self.page.Find("idStr","Payee",30).Keys(payee)
    self.page.Keys("[Tab]")
#   Below code is to select supplier from the pop-up window if exists. 
    if (Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/OA_HTML/cabo/jsps/a.jsp*").Frame(0)).Exists:
      popup_wnd = Sys.Browser("iexplore").Page("https://*.epfinnp.coxautoinc.com/OA_HTML/cabo/jsps/a.jsp*").Frame(0)
      Delay(2000) 
      popup_wnd.Find("idStr","N1:N52:0",30).Click()
      Delay(5000) 
      popup_wnd.Find("contentText","Select",30).Click()
      Delay(6000)
      self.wait_until_page_loaded()
        
    web_utils.log_checkpoint("Enter 'Payee Information' - Successful",500,self.page)
    #self.page.Keys("[Tab]")
    delay(6000)
    self.page.Find("idStr","Submit",30).Click()
    self.page.wait_until_page_loaded()
    Delay(2000)
    self.page.Find("idStr","SearchCheckrunName",30).Click()
    self.page.Find("idStr","SearchCheckrunName",30).Keys(pay_des)
    self.page.Keys("[Tab]")
    delay(2000)
    self.page.Find("contentText","Go",30).Click()
    web_utils.log_checkpoint(pay_des+" - Payment Submitted",500,self.page)
    self.page.wait_until_page_loaded()
    Delay(15000) 
    paymnt_status=self.page.EvaluateXPath("//span[@id='ResultsTable:StatusCodeDsp:0']")[0].contentText
    while paymnt_status != 'Invoices Pending Review':
      Delay(4000)
      self.page.Find("idStr","ResultsTable:Refresh:*",30).Click()
      self.page.wait_until_page_loaded()
      delay(10000)
      paymnt_status=self.page.EvaluateXPath("//span[@id='ResultsTable:StatusCodeDsp:0']")[0].contentText
    delay(2000) 
    self.page.Find("namePropStr","takeaction_enabled.gif",30).Click()
    self.page.wait_until_page_loaded()
    self.page.Find("idStr","ResubmitPsr",30).Click()
    web_utils.log_checkpoint(pay_des+" - 'Invoices Pending Review' status",500,self.page) 
    self.page.wait_until_page_loaded()
    while paymnt_status != 'Pending Proposed Payment Review':
     Delay(4000)
     self.page.Find("idStr","ResultsTable:Refresh:*",30).Click()
     self.page.wait_until_page_loaded()
     paymnt_status=self.page.EvaluateXPath("//span[@id='ResultsTable:StatusCodeDsp:0']")[0].contentText 
    self.page.wait_until_page_loaded()
    self.page.Find("namePropStr","takeaction_enabled.gif",30).Click()
    self.page.wait_until_page_loaded()
    self.page.EvaluateXPath("//button[@title='Go']")[0].Click()
    self.page.wait_until_page_loaded()
    self.page.Find("idStr","SearchCheckrunName",30).Click()
    self.page.wait_until_page_loaded()
    self.page.Find("idStr","SearchCheckrunName",30).SetText("")
    Delay(1000)
    self.page.Find("idStr","SearchCheckrunName",30).Keys(pay_des)
    Delay(1000)
    self.page.Keys("[Tab]")
    delay(2000)
    self.page.FindChildEx("contentText","Go",60,True,60000).Click()
    web_utils.log_checkpoint(pay_des+" - Pending Proposed Payment Review",500,self.page)
    self.page.wait_until_page_loaded()  
    count = 10 
    while paymnt_status != 'Confirmed':
       Delay(4000)
       self.page.Find("idStr","ResultsTable:Refresh:*",30).Click()
       self.page.wait_until_page_loaded()
       paymnt_status=self.page.EvaluateXPath("//span[@id='ResultsTable:StatusCodeDsp:0']")[0].contentText
       if (count==0):
          web_utils.log_error(pay_des+" - "+ paymnt_status)
       count = count-1
    web_utils.log_checkpoint(pay_des+" - Confirmed Payment",500,self.page)
    self.page.wait_until_page_loaded()
    dsn = self.testConfig['man_oracle_db']['dsn']
    user_id = self.testConfig['man_oracle_db']['userid']
    pwd = self.testConfig['man_oracle_db']['pwd']
    dbhelper.verify_oracle_payment_status(dsn,user_id,pwd,VarToStr(app.Cells.item[rowno,13]))
    delay(2000)
    self.page.EvaluateXpath("//table[@id = 'globalHeaderID']//a/div/img[@title = 'Home']")[0].Click()
    self.wait_until_page_loaded()


