﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils
import web_utils
import form_utils


class tc98631cai_us_import_invoces_webcenter(Ebiz):

 global inv_date,inv_num,rowno
 rowno = 2
 op_log_path="C:\\TC_Logs"

 def login(self):
    self.login_user="amalappan"
    super().login()

 def action(self,book): 
    
    app = book.Sheets.item["Invoice"]
    self.invoice_details()
    Sys.Browser("iexplore").page("https://*epfinnp.coxautoinc.com/OA_HTML/AppsLocalLogin.jsp?*").Close()
    web_utils.close_additional_browsers()

 def invoice_details(self):
# Submitting the request in Oracle
    Log.Message("Inside action...") 
    self.page.WaitProperty("contentText","CAI "+self.oper_unit+" AP INVOICE PROCESSING",6000)
#    web_utils.clk_fldr_link_by_xpath(self.page,"//a[text()='CAI "+self.oper_unit+" AP INVOICE PROCESSING']")
    #______________________________#
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" AP INVOICE PROCESSING')]")
    #______________________________#
#    cai_ap_invpro_link=self.page.Find("contentText","CAI "+self.oper_unit+" AP INVOICE PROCESSING",30)
#    self.verify_aqobject_chkproperty(cai_ap_invpro_link,"contentText",cmpIn,"CAI "+self.oper_unit+" AP INVOICE PROCESSING")
#    cai_ap_invpro_link.Click() 
    self.log_message_web("Click 'CAI "+self.oper_unit+" AP INVOICE PROCESSING' - Successful")
    delay(1000)
#    self.page.keys("[Down]")
#    cai_inv_ent_link=self.page.Find("contentText","Invoices",30)
    #______________________________#
#    utils.clk_fldr_link_by_xpath(self.page,"//a[text()='Invoices']")
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Invoices')]")
    #______________________________#
#    self.verify_aqobject_chkproperty(cai_inv_ent_link,"contentText",cmpIn,"Invoices")
#    cai_inv_ent_link.Click() 
    self.log_message_web("Click 'Invoices' - Successful")
    delay(1000)  
#    self.page.Find("contentText","Entry",30).Click()
    #______________________________#
#    web_utils.clk_fldr_link_by_xpath(self.page,"//a[text()='Entry']")
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Entry')]")
    #______________________________#
    self.log_message_web("Click 'Entry' - Successful")
    delay(1000)
    #______________________________#
#    self.page.EvaluateXPath("//a[text()='Invoices']")[1].ScrollIntoView()
#    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'Invoices')]")
    self.page.EvaluateXPath("//table[@id='respList']//div[contains(text(),'Invoices')]")[1].Click()
#    self.page.EvaluateXPath("//a[text()='Invoices']")[1].Click()
    #______________________________#
    Delay(8000)
#    self.page.Find("namePropStr","RF.jsp?function_id=1026&resp_id=50816&resp_appl_id=200&security_group_id=0&lang_code=US')",30).Click()
    jFrame=self.initializeJFrame()
    delay(8000)
    form_utils.click_ok_btn(jFrame)
    Delay(4000)
#    jFrame.Keys("~o")
#    delay(4000)
    jFrame.FindchildEx("AWTComponentAccessibleName","Invoice Workbench (CAI "+self.oper_unit+" AP INVOICE PROCESSING)",True,60000).Click()
    delay(2000)
    jFrame.Keys("[F4]")
    delay(1000)
    jFrame.keys("~y")
    delay(2000)
    jFrame.Keys("~v")
    delay(1000)
    jFrame.Keys("r")
    delay(1000)
#    jFrame.Keys("~n")
    prop=["AWTComponentAccessibleName", "AWTComponentName"]
    val=["Submit a New Request alt N", "Button44"]
    jFrame.FindChild(prop,val,30).Click()
    delay(1000)
    jFrame.Keys("~r")
    delay(1000)
#    jFrame.Keys("~o")
#    delay(1000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit Request","ExtendedFrame"]
    par_form=jFrame.FindChildEx(prop,val,60)
    Delay(2000)
    par_form.Find("AWTComponentAccessibleName","Name RequiredList of Values",30).Keys("Payables Open Interface Import")
    delay(2000)
#    par_form.Find("AWTComponentAccessibleName","Request Set RequiredList of Values",30).Click()
    par_form.Find("AWTComponentAccessibleName","Name RequiredList of Values",30).Keys("[Tab]")
    delay(2000)
    jFrame.Keys("[Tab]")
    Delay(1000)
    jFrame.Keys("WCI_INVOICE")
    Delay(1000)
#    jFrame.Keys("~o")
#    prop=["AWTComponentAccessibleName", "AWTComponentName"]
#    val=["OK ALT O", "FormButton1"]
#    jFrame.FindChild(prop,val,30).Click()

    #form_utils.click_ok_btn(jFrame)  
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Parameters","FlexWindow"]  
    ok_btn=jFrame.FindChildEx(prop,val,30,True,3000)
    if ok_btn.Exists:
     ok_btn.Find("AWTComponentAccessibleName","OK ALT O",20).Click()
    
    
     
    delay(2000) 
#    jFrame.Keys("~m")
    prop=["AWTComponentAccessibleName", "AWTComponentName"]
    val=["Submit alt m", "Button*"]
    jFrame.FindChild(prop,val,30).Click()
    delay(2000)
    RequestID = ''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit())
    Log.Message("Request ID Of  " + aqConvert.VarToStr(RequestID))
    self.log_checkpoint_message_web("Request ID Of CAI Excel Invoice Import (Report Set) is " + aqConvert.VarToStr(RequestID))    
    delay(1000)    
#    jFrame.Keys("~n")
    prop=["AWTComponentAccessibleName", "AWTComponentIndex", "AWTComponentName"]
    val=["No ALT N", "1", "FormButton6"]
    jFrame.FindChild(prop,val,30).Click()
    delay(2000)
#    jFrame.Keys("~i")
    prop=["AWTComponentAccessibleName", "AWTComponentIndex", "AWTComponentName"]
    val=["Find alt i", "3", "Button47"]
    jFrame.FindChild(prop,val,30).Click()
    delay(2000)
    
# Gathering Request ID and Output File for the "Payables Open Interface Import"   
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,60000)  
    prg_name = "Payables Open Interface Import"
    self.concurr_job_status(req_form,RequestID)
    self.log_message_oracle_form(jFrame,"Program completed successfully")
    Delay(2000)

    jFrame.Keys("[F4]")  
    Delay(2000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~s")
    Delay(1000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Find Requests","ExtendedFrame"]
#    jFrame=Sys.Browser("iexplore").SwingObject("JBufferedFrame", "*", -1, 1)
    find_req_form=jFrame.FindChildEx(prop,val,10,True,60000)
    find_req_form.Find("AWTComponentAccessibleName","Request ID",10).Click()
    Delay(1000)
    find_req_form.Find("AWTComponentAccessibleName","Request ID",10).Keys(RequestID)
    Delay(1000)
#    jFrame.Keys("~i")
    prop=["AWTComponentAccessibleName", "AWTComponentName"]
    val=["Find alt i", "Button76"]
    jFrame.FindChild(prop,val,30).Click()
    Delay(1000)
#    jFrame.Keys("~p")
    prop=["AWTComponentAccessibleName", "AWTComponentIndex", "AWTComponentName"]
    val=["View Output alt p", "11", "Button68"]
    jFrame.FindChild(prop,val,30).Click()
    Delay(2000)
    log_page=Sys.Browser("iexplore").Page("https://core-*.epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
    log_page.Click()
#    log_page.TextNode(0).Click()
#    Delay(1000)
    log_page.Keys("~f")
    Delay(1000)
    log_page.Keys("a")
    Delay(5000)  
    file_system_utils.create_folder(self.op_log_path)             
    log_path=self.op_log_path+"\\CAI Payable Open Interface-Output File_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
    Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
    Delay(1000)
    Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
    Delay(2000)
    Log.Enabled=True
    Log.File(log_path, "CAI Payables Open Interface Import Output File Attached")
    Log.Enabled=False        
    Delay(2000)
#    Sys.Browser("iexplore").page("https://*ebs.coxautoinc.com/OA_CGI/FNDWRR*").Close()
    Sys.Browser("iexplore").page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close()
    Delay(3000)
#    Sys.Browser("iexplore").page("https://*ebs.coxautoinc.com/forms/frmservlet*").Close()
    jFrame.Keys("~f")
    Delay(1000)
    jFrame.Keys("x")
    Delay(2000)
    jFrame.Keys("o")
    Delay(2000)
    self.page.Keys("^[Home]")
    Delay(2000)


 def concurr_job_status(self,req_form,RequestID): 
      job_id="false"
      phase="false"
      i=10 
#      for x in range(0,10):

      jFrame=self.initializeJFrame()
      delay(8000)
      form_utils.click_ok_btn(jFrame)
      Delay(4000)
        
      while not (job_id == RequestID and phase == "Completed"):
         
         prop=["AWTComponentAccessibleName","AWTComponentIndex"]
         val=["Request ID",i] 
  #         prop=["AWTComponentAccessibleName","AWTComponentIndex"]
  #         val=["Name",i+10]
         job_id=req_form.Find(prop,val,10).wText
         prop=["AWTComponentAccessibleName","AWTComponentIndex"]
         val=["Phase",i+30]
         phase=req_form.Find(prop,val,10).wText          
         i+=1     
         if i==13:
#           req_form.keys("~r") 
           prop=["AWTComponentAccessibleName", "AWTComponentName"]
           val=["Refresh Data alt R", "Button28"]
           jFrame.FindChild(prop,val,30).Click()
           i=10

def sample():
  jFrame=Sys.Process("jp2launcher").WaitSwingObject("JFrame", "Oracle Applications*", -1,1,90000)
  prop=["AWTComponentAccessibleName","JavaClassName"]
  val=["Parameters","FlexWindow"]  
  ok_btn=jFrame.FindChildEx(prop,val,30,True,3000)
  if ok_btn.Exists:
    ok_btn.Find("AWTComponentAccessibleName","OK ALT O",20).Click()
