﻿from dbhelper import *
from ebiz import *
import web_utils
import dbhelper
import file_system_utils 
import form_utils

class tc99685cai_us_asset_inquiry(Ebiz):
 op_log_path="C:\\Tc_Logs"

 def login(self):
   self.login_user='rmaran'
   super().login()
   
 def action(self,book): 
   app = book.Sheets.item["PA-FA"] 
   rowno=2
#   prop_names = ("innerHTML")
#   prop_values = ("Oracle Applications Home Page")
#   obj =  Sys.Browser("iexplore").Page("*").FindChild(prop_names,prop_values,30)
##   self.verify_aqobject_chkproperty(obj,"contentText",cmpContains,"Oracle Applications Home Page")

   web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" FA ASSET TRANSACTIONS')]")
   self.log_message_web("Click 'CAI "+self.oper_unit+" FA ASSET TRANSACTIONS' - Successful")
   Delay(2000)
   
   self.page.NativeWebObject.Find("contentText","Assets","A").Click()
   self.log_message_web("Click 'Assets' - Successful")
   self.page.Wait()
   
   self.page.NativeWebObject.Find("contentText","Asset Workbench","A").Click()
   self.log_message_web("Click 'Asset Workbench' - Successful")
   self.page.Wait()
   

   jFrame= self.initializeJFrame()  
   Delay(1000)
   form_utils.click_ok_btn(jFrame)
   
   Delay(4000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Find Assets","ExtendedFrame"]
   findassets_form=jFrame.FindChildEx(prop,val,60,True,90000)
   findassets_form.Find("AWTComponentAccessibleName","Asset Number",10).SetText(app.Cells.item[rowno,1])
   findassets_form.Keys("[Tab]")
   

   self.verify_aqobject_chkproperty(findassets_form,"AWTComponentAccessibleName",cmpContains,"Find Assets")
   Delay(3000)
   findassets_form.Find("AWTComponentAccessibleName","Find alt i",10).Click()
   Delay(3000)
   
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Assets","ExtendedFrame"]
   assets_form=jFrame.FindChildEx(prop,val,60,True,60000)
   self.verify_aqobject_chkproperty(assets_form,"AWTComponentAccessibleName",cmpContains,"Assets")
   
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Source Lines alt u","Button"]
   source_lines=assets_form.FindChild(prop,val,60)
   source_lines.Find("AWTComponentAccessibleName","Source Lines alt u").Click()

   Delay(2000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Source Lines","ExtendedFrame"]     
   src_lines_form=jFrame.FindChild(prop,val,30)
   self.verify_aqobject_chkproperty(src_lines_form,"AWTComponentAccessibleName",cmpContains,"Source Lines")
   
   prop=["AWTComponentAccessibleName","AWTComponentIndex"]
   val=["Invoice \nNumber",13]
   inv_no=src_lines_form.FindChild(prop,val,10).wText
   self.log_message_oracle_form(jFrame,"Invoice Number from assests source line form : "+aqConvert.VarToStr(inv_no))
   
   prop=["AWTComponentAccessibleName","AWTComponentIndex"]
   val=["Project Number",96]
   proj_no=src_lines_form.FindChild(prop,val,10).wText    
   self.log_message_oracle_form(jFrame,"project Number from assests source line form : "+aqConvert.VarToStr(proj_no))
   
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Project Details... alt P","Button"]
   project_details=src_lines_form.FindChild(prop,val,60)
   project_details.Find("AWTComponentAccessibleName","Project Details... alt P").Click()
   Delay(4000)
   self.log_message_oracle_form(jFrame,"Project Details Form Found")
   
   jFrame.Keys("[F4]")
   Delay(4000)
   jFrame.Keys("[F4]")
   Delay(3000)
   jFrame.Keys("[F4]")
   Delay(3000)
   jFrame.Keys("~o")
   Delay(2000)         
   book.save()
