﻿import gvar

def book_controls_extendedframe():
  prop_names = ["AWTComponentAccessibleName","JavaClassName"]
  prop_values = ["Book Controls","ExtendedFrame"]
  return gvar.dataprep['jformobject'].FindChildEx(prop_names,prop_values,30,True,5000)

def book_textfield(book_ctrl_wdw):
  prop_names = ["AWTComponentAccessibleName","JavaClassName"]
  prop_values = ["Book Required","VTextField"]
  return book_ctrl_wdw.FindChildEx(prop_names,prop_values,20,True,1000)
  
def current_period(book_ctrl_wdw):
  prop_names = ["AWTComponentAccessibleName","JavaClassName"]
  prop_values = ["Current Period Required*","VTextField"]
  return book_ctrl_wdw.FindChildEx(prop_names,prop_values,20,True,1000)
  
