﻿from dbhelper import *
from ebiz import *
import web_utils
import dbhelper
import file_system_utils 
import form_utils

class tc93507cai_us_post_mass_additions(Ebiz):
 op_log_path="C:\\Tc_Logs"

 def login(self):
   self.login_user='rmaran'
   super().login()
   
 def action(self,book): 
   
   app = book.Sheets.item["PA-FA"]
   rowno = 2
   
#   prop_names = ("contentText")
#   prop_values = ("Home")
#   obj =  Sys.Browser("iexplore").Page("*").FindChild(prop_names,prop_values,30)
#   self.verify_aqobject_chkproperty(obj,"contentText",cmpContains,"Home")
#   self.wait_until_page_loaded()
#   Delay(1000)
   web_utils.clk_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" FA ASSET TRANSACTIONS')]")
   Delay(2000)
   self.wait_until_page_loaded()
   Delay(2000)

   self.page.Wait()
   self.page.NativeWebObject.Find("contentText","Mass Additions","A").Click()
   self.log_message_web("Click 'Mass Additions' - Successful")
   self.wait_until_page_loaded()
   Delay(2000)
  
   
   self.page.Wait()
   self.page.NativeWebObject.Find("contentText","Post Mass Additions","A").Click()
   self.log_message_web("Click 'Post Mass Additions' - Successful")
   Delay(3000)
   self.wait_until_page_loaded()
   
   web_utils.validate_security_box()
   Delay(7000)
   jFrame= self.initializeJFrame()
   Delay(2000)
   form_utils.click_ok_btn(jFrame) 
#   jFrame.keys("~o")

   Delay(5000)
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Submit Request Set","ExtendedFrame"]
   submitrequest_form=jFrame.FindChildEx(prop,val,60,True,90000)
   self.verify_aqobject_chkproperty(submitrequest_form,"AWTComponentAccessibleName",cmpContains,"Submit Request Set")
   
   self.submit_req_set_params(submitrequest_form,jFrame,15,"ATG CORP")
   Delay(1000)
   self.submit_req_set_params(submitrequest_form,jFrame,16,"ATG CORP")
   self.log_message_oracle_form(jFrame,"Parameters Entered")
   Delay(1000)
   self.log_message_oracle_form(jFrame,"ready to Click Submit Button")
   jFrame.keys("~m")   
   Delay(2000)
   jFrame.keys("~o")
   Delay(1000)
   jFrame.Keys("~v")
   Delay(2000)
   jFrame.Keys("r")
   Delay(3000)
   jFrame.Keys("~i")
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Requests","ExtendedFrame"]
   req_form=jFrame.FindChildEx(prop,val,30,True,90000)
   self.verify_aqobject_chkproperty(req_form,"AWTComponentAccessibleName",cmpContains,"Requests")  
   job_name_child="false"
   phase_parent="false"  
   i=20
   while (job_name_child!="Mass Additions Posting Report") or (phase_parent!="Completed") :
    if i==20:
     #req_form.keys("~r") 
     req_form.FindChild("AWTComponentAccessibleName","Refresh Data alt R",10).Click()
     i=20
    Delay(2000)    
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Name",i]
    job_name_child=req_form.Find(prop,val,10).wText    
    req_form.Find(prop,val,10).Keys("[Enter]")
    Delay(2000)
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Phase",i+20]
    phase_parent=req_form.Find(prop,val,10).wText                  
#    i+=1     
   Delay(2000) 
   #req_form.keys("~p")
   req_form.FindChild("AWTComponentAccessibleName","View Output alt p",10).Click()
   Delay(3000)
   output_page=Sys.Browser("iexplore").Page("https://core-*.epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
   output_page.Click()
   Delay(2000)
   output_page.Keys("~f")
   Delay(2000)
   output_page.Keys("a")
   Delay(5000)

   file_system_utils.create_folder(self.op_log_path)             
   log_path=self.op_log_path+"\\Mass Additions Posting Report Output Is Attached_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
   Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
   Delay(1000)
   Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
   Delay(5000)
   Log.Enabled=True
   Log.File(log_path, "Mass Additions Posting Report Output File Attached")
   Log.Enabled=False        
   Sys.Browser("iexplore").Page("https://core*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close()
   web_utils.close_additional_browsers()                              
   Delay(2000)   
   fo=open(log_path,"r")  
   lines=fo.readlines()
   self.log_message_web("Asset Number: - "+lines[11][0:8].strip())
   app.Cells.Item[rowno,1] = lines[11][0:8].strip()
   Delay(1000)
   jFrame.Keys("[F4]")
   Delay(2000)
   jFrame.Keys("[F4]")
   Delay(2000)
   jFrame.Keys("~o")
   Delay(2000)
   book.save()
#   Sys.Browser("iexplore").page("https://core-*.epfinnp.coxautoinc.com/forms/frmservlet*").Close()
   
   
   
    
   
 def submit_req_set_params(self,submitrequest_form,jFrame,index_no,Book):
   prop=["AWTComponentAccessibleName","AWTComponentIndex"]
   val=["Parameters",index_no]
   submitrequest_form.FindChild(prop,val,60).Click()
   Delay(2000)   
   prop=["AWTComponentAccessibleName","JavaClassName"]
   val=["Parameters","FlexWindow"]   
   #self.verify_aqobject_chkproperty(parameters_form,"AWTComponentAccessibleName",cmpContains,"Parameters")
   parameter_form=jFrame.FindChild(prop,val,10)
   parameter_form.Keys(Book)
   parameter_form.Keys("~o")
   Delay(2000)
