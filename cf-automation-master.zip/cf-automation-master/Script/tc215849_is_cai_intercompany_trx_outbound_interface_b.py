﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils
import winscp_utility
import tc_logs
from File_Handler import File_Handler as _TXTOBJ
from text_headers import payroll_txt_file_header as _HEADERS
import web_utils
import form_utils
import datetime as dt

class tc215849_is_cai_intercompany_trx_outbound_interface_b(Ebiz):
  
  op_log_path="C:\\TC_Logs"
  
  def login(self):
      self.login_user="mfallwell"
      super().login()

 
  def action(self,book):
    web_utils.log_checkpoint("Logged into CAI Oracle Ebiz Instance Successfully",500,self.page)
    self.wait_until_page_loaded() 
    self.page.WaitProperty("contentText","CAI ALL GL JOB SCHEDULER",6000)
    cai_gl_submit_link=self.page.NativeWebObject.Find("contentText","CAI ALL GL JOB SCHEDULER","A")
    self.verify_aqobject_chkproperty(cai_gl_submit_link,"contentText",cmpIn,"CAI ALL GL JOB SCHEDULER")
    cai_gl_submit_link.Click() 
    web_utils.log_checkpoint("Click 'CAI ALL GL JOB SCHEDULER' - Successful",500,self.page)
    Delay(1000)    
    self.page.Wait()
    self.page.NativeWebObject.Find("contentText","Submit Request","A").Click()
    web_utils.log_checkpoint("Click 'Submit Request' - Successful",500,self.page)
    jFrame= self.initializeJFrame()
    Delay(10000)
    form_utils.click_ok_btn(jFrame)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit a New Request","ExtendedFrame"]
    submit_new_req_form=jFrame.FindChildEx(prop,val,60,True,90000)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["What type of request do you want to run? Request Set alt s","ExtendedCheckbox"]  
    submit_new_req_form.FindChild(prop,val,10).Click()       
    Delay(1000)
    submit_new_req_form.FindChild("AWTComponentAccessibleName","OK alt O",10).Click()
    
    
    
# Submitting "CAI Oracle GL Inbound JE Interface Request Set - IS" Request Set using CAI ALL GL JOB SCHEDULER' responsibility

    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit Request Set","ExtendedFrame"]
    par_form=jFrame.FindChild(prop,val,60)
    par_form.Find("AWTComponentAccessibleName","Request Set RequiredList of Values",30).SetText("CAI Oracle GL Inbound JE Interface Request Set - IS")
    web_utils.log_checkpoint("Request Set Name: 'CAI Oracle GL Inbound JE Interface Request Set - IS' - populated Successfully",500,jFrame)
    delay(1000)
    jFrame.Keys("[Tab]")
    delay(1000)
    par_form=jFrame.FindChild(prop,val,60)
    par_form.Find("AWTComponentAccessibleName","Submit",30).Click()
    form_utils.click_ok_btn(jFrame)    
    web_utils.log_checkpoint("Request Set Name: 'CAI Oracle GL Inbound JE Interface Request Set - IS' parameters - submitted Successfully",500,jFrame)
    delay(3000)
    RequestID = ''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit()) 
    web_utils.log_checkpoint("Request ID Of 'CAI Oracle GL Inbound JE Interface Request Set - IS'" + aqConvert.VarToStr(RequestID),500,jFrame)
    Delay(2000)
    jFrame.Keys("~n")
    dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
    user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
    pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
    dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,RequestID)
    jFrame.Click()
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~o")
    Delay(1000)
    self.close_forms(jFrame)
