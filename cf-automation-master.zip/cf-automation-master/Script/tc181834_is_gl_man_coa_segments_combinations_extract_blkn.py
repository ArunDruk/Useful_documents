﻿from ebiz import *
import file_system_utils
import form_utils
import web_utils
import dbhelper

###This testcase is to submit MAN COA Segments And Combination Extract for Blackline and capture logs###

class tc181834_is_gl_man_coa_segments_combinations_extract_blkn(Ebiz):

 op_log_path="C:\\TC_Logs"
 
 def login(self):
    self.login_user="mfallwell"
    super().login()
 
 def goto_url(self,url):
   super().goto_url(self.testConfig['ebiz']['oci_is_url'])
 
 def action(self,book):

# Login to Oracle EBIZ and select the GL SCHEDULER responsibility  
    Log.Message("Inside action...") 
    self.page.WaitProperty("contentText","GL SCHEDULER",6000)
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='menuContent']//div[contains(text(),'GL SCHEDULER')]")       
    self.page.Wait()
    self.page.NativeWebObject.Find("contentText","Requests","A").Click()
    web_utils.log_checkpoint("Click 'Requests' - Successful",500,self.page)
    delay(2000)
    self.page.NativeWebObject.Find("contentText","Run","A").Click()
    web_utils.log_checkpoint("Click 'Run' - Successful",500,self.page)
    web_utils.validate_security_box()
    Delay(15000)
    jFrame=self.initializeJFrame()
    form_utils.click_ok_btn(jFrame)  
    Delay(3000)
    
# Submitting "MAN COA Segments And Combination Extract for Blackline" Request Set using GL SCHEDULER' responsibility
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit a New Request","ExtendedFrame"]
    submit_req_form=jFrame.FindChildEx(prop,val,30,True,60000)
    submit_req_form.FindChild("AWTComponentAccessibleName","OK alt O",10).Click()
    Delay(2000)
    jFrame.Keys("MAN COA Segments And Combination Extract for Blackline")
    jFrame.Keys("[Tab]")
    delay(1000)
    web_utils.log_checkpoint("Request Set Name: 'MAN COA Segments And Combination Extract for Blackline' - populated Successfully",500,jFrame)
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit Request","ExtendedFrame"]
    submit_req_form=jFrame.FindChildEx(prop,val,30,True,60000)
    submit_req_form.FindChild("AWTComponentAccessibleName","Submit alt m",10).Click()
    web_utils.log_checkpoint("Click Submit Successful",500,jFrame)
    Delay(2000)
    jFrame.Keys("~o")
    web_utils.log_checkpoint("'MAN COA Segments And Combination Extract for Blackline' is submitted",500,jFrame)  
    RequestID = aqConvert.VarToInt(''.join(x for x in jFrame.find("AWTComponentAccessibleName","Request submitted*",100).AWTComponentAccessibleName if x.isdigit()))
    web_utils.log_checkpoint("Request ID Of 'MAN COA Segments And Combination Extract for Blackline' is " + aqConvert.VarToStr(RequestID),500,jFrame)
    Delay(2000)
    jFrame.Keys("~n")
    Delay(4000)
    jFrame.Keys("~v")
    Delay(2000)
    jFrame.Keys("r")
    Delay(2000)
    jFrame.Keys("~i")
    Delay(2000) 
    
 # Verifying in the DB for the completion of concurrent programs.
    dsn = self.testConfig['man_oracle_db']['dsn']
    user_id = self.testConfig['man_oracle_db']['userid']
    pwd = self.testConfig['man_oracle_db']['pwd']
    dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,VarToStr(RequestID))
    
# Gathering Request ID and Output File for the "MAN COA Segments And Combination Extract for Blackline Program" 
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,90000)
    self.req_set_save_log(jFrame,req_form,"MAN COA Segments And Combination Extract for Blackline",RequestID)
    Delay(2000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000)

# Gathering Request ID and Output File for the "MAN: Blackline Transfer Transaction file to Sterling (MAN:Transfer files to Sterling)"  
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,90000)
    self.req_set_save_log(jFrame,req_form,"MAN: Blackline Transfer Transaction file to Sterling (MAN:Transfer files to Sterling)",RequestID)
    Delay(1000)
    fo=open(self.log_path,"r")
    lines=fo.readlines()
    Log.Enabled=True
    Log.Message("Outbound Extract Information : - "+lines[5][0:64].strip())
    Log.Message(lines[12][0:112].strip())
    Log.Message(lines[13][0:112].strip())
    Log.Message(lines[14][0:62].strip())
    Log.Message(lines[15][0:54].strip())
    Log.Message(lines[16][0:79].strip())
    Log.Message(lines[17][0:60].strip())
    Log.Message(lines[18][0:94].strip())
    Log.Message(lines[19][0:59].strip())
    Log.Message(lines[21][0:72].strip())
    Log.Message(lines[22][0:78].strip())
    Log.Message(lines[24][0:78].strip())
    Log.Message(lines[26][0:234].strip())
    Log.Message(lines[27][0:158].strip())
    Log.Message(lines[28][0:68].strip())
    Log.Message(lines[29][0:72].strip())
    Log.Enabled=False
    Delay(2000)
    jFrame.Click()
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~o")
    Delay(1000)      



 def req_set_save_log(self,jFrame,req_form,srch_child_name,Preqid):
    web_utils.log_checkpoint("Checking for "+aqConvert.VarToStr(srch_child_name)+ " Child Program Status",500,jFrame)
    req_form.FindChild("AWTComponentAccessibleName","Refresh Data alt R",20).Click()
    i=20
    for x in range(1,180):     
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Name",i]
        child_name=req_form.Find(prop,val,10).wText 
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Phase",i+20]
        phase=req_form.Find(prop,val,10).wText 
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Request ID",i-10]
        creqid=VarToInt(req_form.Find(prop,val,10).wText)                                       
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Status",i+30]         
        status =req_form.FindChild(prop,val,60)            
        if (child_name==srch_child_name) and (creqid>=Preqid) and (phase == "Completed"):
            web_utils.log_checkpoint(aqConvert.VarToStr(srch_child_name)+" Phase Completed Successfuly",500,jFrame)                                
            status.Keys("[Enter]")
            Delay(1000)
            req_form.FindChild("AWTComponentAccessibleName","View Log alt K",20).Click()    
            Delay(4000)
            output_page=Sys.Browser("iexplore").Page("https://manheim*.epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
            output_page.Click()
            Delay(2000)
            output_page.Keys("~f")
            Delay(2000)
            output_page.Keys("a")
            Delay(5000)
            file_system_utils.create_folder(self.op_log_path)             
            self.log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"File"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"_%d%b%Y_%H%M")+".txt"    
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(self.log_path)
            Delay(1000)
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
            Delay(8000)
            Log.Enabled=True
            Log.File(self.log_path, aqConvert.VarToStr(srch_child_name)+" is Completed And Log file is attached")
            Log.Enabled=False     
            web_utils.close_additional_browsers()         
            Filesaved = 'True'
            return                           
        elif i >=29:
           Delay(15000)           
           req_form.FindChild("AWTComponentAccessibleName","Refresh Data alt R",20).Click()
           Delay(3000)
           i=20
           val=["Name",i]
           child_name=req_form.Find(prop,val,10).wText
        else:  
           Delay(2000)
           i=i+1 
