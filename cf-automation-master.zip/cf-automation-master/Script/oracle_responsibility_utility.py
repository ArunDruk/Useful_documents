﻿import oracle_home_page
import tc_logs
import gvar
import web_utility



def ar_home_office_super_user(sub_child_action,page_wait = 5000, form_wait = 20000):
    oracle_home_page.ar_home_office_super_user_link().scrollintoView()
    oracle_home_page.ar_home_office_super_user_link().Click()
#    tc_logs.checkpt_with_no_picture("Click 'AR Home Office Super User' - Successful")
    tc_logs.checkpt_with_picture("Click 'AR Home Office Super User' - Successful",pmHigher,gvar.dataprep['page'])
    if sub_child_action == 'Run':
        aqUtils.Delay(page_wait)
        oracle_home_page.control_link().scrollintoView()
        oracle_home_page.control_link().Click()
        aqUtils.Delay(page_wait)
        oracle_home_page.requests_link().scrollintoView()
        oracle_home_page.requests_link().Click()
        aqUtils.Delay(page_wait)
        oracle_home_page.control_requests_run_link().scrollintoView()
        oracle_home_page.control_requests_run_link().Click()
        aqUtils.Delay(page_wait)
#        tc_logs.checkpt_with_no_picture("Click 'Control: Requests Run' - Successful")
        tc_logs.checkpt_with_picture("Click 'Control: Requests Run' - Successful",pmHigher,gvar.dataprep['page'])
    elif sub_child_action == 'Receivables':
        aqUtils.Delay(page_wait)
        oracle_home_page.setup_link().scrollintoView()
        oracle_home_page.setup_link().Click()       
        aqUtils.Delay(page_wait)
        oracle_home_page.system_link().scrollintoView()
        oracle_home_page.system_link().Click()      
        aqUtils.Delay(page_wait)
        oracle_home_page.quickcodes_link().scrollintoView()
        oracle_home_page.quickcodes_link().Click()       
        aqUtils.Delay(page_wait)
        oracle_home_page.receivables_link().scrollintoView()
        oracle_home_page.receivables_link().Click()       
        aqUtils.Delay(page_wait)
        tc_logs.checkpt_with_no_picture("Click 'Receivables' - Successful")
    elif sub_child_action == 'Transactions':
        oracle_home_page.transactions_parent_link().Click()
        aqUtils.Delay(5000)
        oracle_home_page.transactions_child_link().Click()
        aqUtils.Delay(form_wait)
        tc_logs.checkpt_with_no_picture("Click 'Transactions' - Successful")
        aqUtils.Delay(page_wait)
        tc_logs.checkpt_with_no_picture("Click 'Transactions' - Successful")
    elif sub_child_action == 'Transaction_form':
      web_utility.find_link_by_contenttext_idstr("Transactions","N98").Click()
      aqUtils.Delay(form_wait)
    elif sub_child_action == 'Receipt_form':
        web_utility.find_link_by_contenttext_idstr("Receipts","N142").Click()
        aqUtils.Delay(form_wait)
        tc_logs.checkpt_with_no_picture("Click 'receipts' link - Successful")



def ar_home_office_super_user_old(sub_child_action):
  oracle_home_page.ar_home_office_super_user_link().Click()
  aqUtils.Delay(5000)
  tc_logs.checkpt_with_no_picture("Click 'AR Home Office Super User' - Successful")
  if sub_child_action == 'Run':
     oracle_home_page.control_requests_run_link().Click()
     aqUtils.Delay(20000)
     tc_logs.checkpt_with_no_picture("Click 'Control: Requests Run' - Successful")
  elif sub_child_action == 'Transactions':
     oracle_home_page.transactions_link()[1].Click()
     aqUtils.Delay(20000)
     tc_logs.checkpt_with_no_picture("Click 'Transactions' - Successful")
  elif sub_child_action == 'Receivables':
     oracle_home_page.receivables_link().Click()
     aqUtils.Delay(20000)
     tc_logs.checkpt_with_no_picture("Click 'Setup:System:Quickcodes:Recievables' - Successful")
    

def fixed_assets_manager(sub_child_action):
  oracle_home_page.fixed_assets_manager_link().scrollintoView()
  oracle_home_page.fixed_assets_manager_link().Click()
  aqUtils.Delay(5000)
  tc_logs.checkpt_with_no_picture("Click 'Fixed Assets Manager' - Successful")
  if sub_child_action == 'Assets':
       oracle_home_page.fixed_assets_link().Click()
       aqUtils.Delay(40000)
       tc_logs.checkpt_with_no_picture("Click 'Assets' - Successful")
  if sub_child_action == 'Asset Workbench':
     oracle_home_page.fixed_assets_link().Click()
     aqUtils.Delay(5000)
     tc_logs.checkpt_with_no_picture("Click 'Assets' - Successful")
     oracle_home_page.asset_workbench_link().Click()
     aqUtils.Delay(40000)
     tc_logs.checkpt_with_no_picture("Click 'Asset Workbench' - Successful")
  elif sub_child_action == 'Run Depreciation':
    oracle_home_page.run_depreciation_link().Click()
    aqUtils.Delay(40000)
    tc_logs.checkpt_with_no_picture("Click 'Run Depreciation' - Successful")
      
def ar_home_office_payment_approver(sub_child_action):
  oracle_home_page.ar_home_office_payment_approver_link().Click()
  aqUtils.Delay(150000)
  tc_logs.checkpt_with_no_picture("Click 'AR Home Office Payment Approver' - Successful")
  if sub_child_action == '':
    pass
  
def inventory(sub_child_action):
  oracle_home_page.inventory_link().scrollintoView()
  oracle_home_page.inventory_link().Click()
  aqUtils.Delay(5000)
  tc_logs.checkpt_with_picture("Click 'Inventory' - Successful","",gvar.dataprep['page'])
  if sub_child_action == 'Master Items':
    oracle_home_page.items_link().Click()
    oracle_home_page.master_items_link().Click()
    aqUtils.Delay(20000)
    tc_logs.checkpt_with_no_picture("Click 'Master Items' - Successful")
    
def order_management_super_user(sub_child_action):
    oracle_home_page.order_management_super_user_link().scrollintoView()
    oracle_home_page.order_management_super_user_link().Click()
    aqUtils.Delay(5000)
    tc_logs.checkpt_with_picture("Click 'Order Management Super User' - Successful","",gvar.dataprep['page'])
    if sub_child_action == 'Sales Orders':
       oracle_home_page.sales_orders_return_link().scrollintoView()
       oracle_home_page.sales_orders_return_link().Click()
       aqUtils.Delay(5000)
       oracle_home_page.sales_orders_link().scrollintoView()
       oracle_home_page.sales_orders_link().Click()
       aqUtils.Delay(20000)
       tc_logs.checkpt_with_no_picture("Click 'Sales Orders' - Successful")
    elif sub_child_action == 'Salespersons':
         oracle_home_page.salespersons_link().Click()
         aqUtils.Delay(20000)
         tc_logs.checkpt_with_picture("Click 'Salespersons' - Successful","",gvar.dataprep['jformobject'])

  
