﻿import gvar

### In this method objects for below pages have been captured ###

#PROJECT > SETUP Home page 

def prj_setup_page_tab():
  setup_tab = gvar.dataprep['page'].NativeWebObject.Find("contentText","Setup","A")
  return setup_tab 
  

def prj_setup_prj_name_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["ProjectName","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def prj_setup_long_name_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["LongName","Textarea"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
  

def prj_setup_org_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["CarryingOutOrgName","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def prj_setup_prj_type_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["ProjectType","Select"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def prj_setup_status_button():
  prop_names = ["contentText","ObjectType","idStr"]
  prop_values = ["Change Status","Button","ProjectStatusChange"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def prj_setup_funding_apprvl_status_dropdown():
  prop_names = ["ObjectType","idStr"]
  prop_values = ["Select","FundApprvlStatus"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def prj_setup_description_textarea():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["Description","Textarea"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
  

def prj_setup_no_radiobutton():
  prop_names = ["ObjectLabel","ObjectType","idStr"]
  prop_values = ["No","RadioButton","M__Id"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def prj_setup_yes_radiobutton():
  prop_names = ["ObjectLabel","ObjectType","idStr"]
  prop_values = ["Yes","RadioButton","M__Ida"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
  

def prj_setup_access_level_dropdown():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["AccessLevel","Select"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
  

def prj_setup_priority_dropdown():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["Priority","Select"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def prj_setup_city_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["City","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def prj_setup_state_region_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["StateRegion__xc_0","Panel"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def prj_setup_country_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["CountryName","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def prj_setup_target_start_date_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["N125:StartDate:1","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def prj_setup_target_finish_date_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["N125:FinishDate:1","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
  

def prj_setup_trx_start_date_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["N125:StartDate:2","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def prj_setup_trx_finish_date_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["N125:FinishDate:2","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)
  

def prj_setup_classifications_link():
  classifications = gvar.dataprep['page'].NativeWebObject.Find("contentText","CAI Additional Project Information","A")
  return classifications
  

def prj_setup_resource_brkdwn_link():
  resource_breakdown_structures = gvar.dataprep['page'].NativeWebObject.Find("contentText","Resource Breakdown Structures","A")
  return resource_breakdown_structures


def prj_setup_team_members_link():
  prj_setup_team_members = gvar.dataprep['page'].NativeWebObject.Find("contentText","Team Members","A")
  return prj_setup_team_members


def prj_setup_cai_addnl_prj_info_link():
  prj_setup_cai_addnl_prj_info_link = gvar.dataprep['page'].NativeWebObject.Find("contentText","CAI Additional Project Information","A")
  return prj_setup_cai_addnl_prj_info_link

  
def prj_directory_page_link():
  prop_names = ["idStr","contentText","ObjectType"]
  prop_values = ["PA_PRM_ALL_MEMB_SUBTAB","Directory","Link"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

