﻿from ebiz import *
import web_utils

#Author:            Prabhakaran Rajendran
# class defined for this action/function and will be called from driverchain(execute() method)
class tc26190cai_us_create_service_procurement_req(Ebiz): 
  global rowno, RowCount, rel, txnum, app

  # Overrite login function 
  def login(self):
    self.login_user="emackay1"
    super().login()

  
# this method will be called from base class() in the framework  
# action method to call all sub functions(methods)

  def action(self,book): 
      rowno=2
      rel=2
      req=0
      app = book.Sheets.item["Requisition"]
      RowCount = app.UsedRange.Rows.Count
      txnum = VarToInt(app.cells.Item[rowno,1])      
      while rowno<(RowCount+1):
         Log.Enabled=True 
         Log.Message("Creating Requisition No:"+IntToStr(req+1))
         Log.Enabled=False 
         self.navigate_iproc(rowno)
         rowno = self.nc_request(txnum,rowno,app)
         self.req_info(app,rowno)
         self.get_reqno(rowno,app)
         rowno=rowno+1
         rel=rel+1
         txnum=txnum+1
         req+=1
      book.save()
      del app,txnum,RowCount,rel,rowno
  #method to navigate 'iprocurement non catalog requisition' entry page
  def navigate_iproc(self,rowno):    
    Delay(4000)
    if rowno ==2:
      self.page.wait()
      self.page.EvaluateXPath("//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" iPROC USER')]")[0].scrollIntoView() 
      Delay(2000)
      self.page.EvaluateXPath("//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" iPROC USER')]")[0].Click() 
      Delay(2000)
    self.wait_until_page_loaded()
    self.page.EvaluateXPath("//table[@id='respList']//div[contains(text(),'iProcurement Home Page')]")[0].Click() 
    Delay(2000)
    self.wait_until_page_loaded()
    self.page.EvaluateXpath("//a[@id='ICXPOR_NONCATALOG']")[0].Click()
    self.wait_until_page_loaded()
    
  #method to fill in details for the requisition and add to cart for checkout            
  def nc_request(self,txnum,rowno,app): 
    
    self.wait_until_page_loaded()      
    obj=self.page.Find("contentText","Non-Catalog Request",50)
    if obj.Exists:
      self.log_checkpoint_message_web("Non-Catalog Page Launched Successfully-Validated the Page Header: Non-Catalog Request")
    else:
      self.log_error_message("Unable to Launch Non-Catalog Form")
                  
    while (VarToStr(app.Cells.Item[rowno, 1])== IntToStr(txnum)):
      Delay(1000)
      req1 = self.page.EvaluateXpath("//table[@id='InfoTableLayout']//select[@id = 'ItemType']")[0]
      req1.ClickItem("Services.I can provide description, rate and quantity")
      Delay(1000)
      req2 = self.page.EvaluateXpath("//table[@id='InfoTableLayout']//textarea[@id = 'ItemDescription']")[0]
      req2.Keys("TST_REQ: "+aqConvert.DateTimeToFormatStr(aqDateTime.Time(),"%H:%M:%S"))
      Delay(1000)
      req3 = self.page.EvaluateXpath("//table[@id='InfoTableLayout']//input[@id = 'Category']")[0]
      req3.SetText(app.Cells.Item[rowno,4])
      Delay(1000)
      req4 = self.page.EvaluateXpath("//table[@id='InfoTableLayout']//input[@id = 'Quantity']")[0]
      req4.SetText(app.Cells.Item[rowno,5])
      Delay(1000)
      req5 = self.page.EvaluateXpath("//table[@id='InfoTableLayout']//input[@id = 'UnitOfMeasureTl']")[0]
      req5.SetText(app.Cells.Item[rowno,6])
      Delay(1000)
      req6 = self.page.EvaluateXpath("//table[@id='InfoTableLayout']//input[@id = 'RatePerUnit']")[0]
      req6.SetText(app.Cells.Item[rowno,7])
      Delay(1000)
      req7 = self.page.EvaluateXpath("//table[@id='InfoTableLayout']//input[@id = 'SupplierOnNonCat']")[0]
      req7.SetText(app.Cells.Item[rowno,9])
      self.page.Keys("[Tab]")
      delay(6000)        
      if (self.browser.WaitPage("*SupplierOnNonCa*",10000)).Exists:        
        table_obj=self.browser.page("*SupplierOnNonCa*").EvaluateXPath("//table[@class='xc6']")[0]
        tot_rows=table_obj.rows.length
        exp_sup_name=app.Cells.Item[rowno,10]
        for i in range(1,tot_rows):
          sup_site = self.browser.page("*SupplierOnNonCa*").Find("idStr","N1:TableSupplierSite:"+aqConvert.VarToStr(i-1),30).contentText
          if (sup_site == exp_sup_name):
            self.browser.page("*SupplierOnNonCa*").Find("idStr","N1:N8:"+aqConvert.VarToStr(i-1),30).Click()
            delay(2000)
            self.wait_until_page_loaded()
            self.browser.page("*SupplierOnNonCa*").Find("contentText","Select",30).Click()
            self.wait_until_page_loaded()
            break    
                  
      Delay(1000)
      self.log_message_web("Requisition Form Details (Item/Desc/Unit/Price/Supplier/Site) are entered")
      Delay(1000)
      self.page.EvaluateXpath("//table[@id='PageButtonBarRN']//button[@id='AddToCart']")[0].Click()
      delay(2000)
      self.wait_until_page_loaded()
      cart = self.page.Find("idStr","PopupCheckout",50)
      if cart.Exists:
        self.log_checkpoint_message_web("Iteration: " +IntToStr(rowno-1)+ " Item Successfully added to cart for check out: Validated the Shopping Cart for Items")
      else:
        self.log_error_message("Unable to Find Items in Cart")
      self.wait_until_page_loaded()
      self.page.EvaluateXpath("//table[@id='PageButtonBarRN']//button[@id='ClearAll']")[0].Click()
      rowno=rowno+1

    self.wait_until_page_loaded()
    self.page.EvaluateXpath("//table[@id='ShoppingCartContRN']//button[@id='PopupCheckout']")[0].HoverMouse()
    delay(1000)
    self.page.EvaluateXpath("//table[@id='ShoppingCartContRN']//button[@id='PopupCheckout']")[0].Click()
    self.wait_until_page_loaded()
#    self.page.EvaluateXpath("//table[@id='PageActionButtonsRN_uixr']//button[@id='Checkout_uixr']")[0].Click()
#    self.wait_until_page_loaded()
    rowno=rowno-1
    return rowno


  #method to feed in 'need by date' and to submit the requisition        
#  def req_info(self,app,rowno):
#      Delay(2000)
#      fut_date = aqDateTime.AddDays(aqDateTime.Now(),3)
#      fut_date1 = aqConvert.DateTimeToFormatStr(fut_date,"%d-%b-%Y %H:%M:%S")
#      Delay(2000)  
#      self.wait_until_page_loaded()    
#      obj=self.page.Find("idStr","NeedByDate",50)
#      if obj.Exists:
#        self.log_checkpoint_message_web("Requisition Information Page Launched Successfully:Validated the Fields for Requisition Form")
#      else:
#        self.log_error_message("Unable to Launch Requisition Information Form")
#      
#      self.page.Find("idStr","NeedByDate",20).Click()
#      Delay(1000)
#      self.page.Find("idStr","NeedByDate",20).Keys(fut_date1)
#      Delay(2000)
#      self.page.Find("idStr","ProjectOnSummaryExpense",20).Click()
#      Delay(1000)
#      self.page.Find("idStr","ProjectOnSummaryExpense",20).Keys(app.Cells.Item[rowno,11])
##      Delay(1000)
#      self.page.Keys("[Tab]")
#      self.page.Keys("[Tab]")
#      Delay(1000)
#      self.page.FindChildEx("idStr","TaskExpense",40,True,10000).Click()
#      self.page.FindChildEx("idStr","TaskExpense",40,True,10000).Keys(app.Cells.Item[rowno,12])
#      Delay(1000)
#      self.page.Keys("[Tab]")
#      self.page.Keys("[Tab]")
#      Delay(1000)
#      self.page.FindChildEx("idStr","ExpenditureTypeOnSummary",40,True,10000).Click()
#      Delay(1000)
#      self.page.FindChildEx("idStr","ExpenditureTypeOnSummary",40,True,10000).Keys(app.Cells.Item[rowno,13])
#      Delay(1000)
#      self.page.Keys("[Tab]")
#      self.page.Keys("[Tab]")
#      self.page.FindChildEx("idStr","ExpenditureOrg",40,True,10000).Click()
#      Delay(1000)
#      self.page.FindChildEx("idStr","ExpenditureOrg",40,True,10000).Keys(app.Cells.Item[rowno,14])
#      Delay(1000)
#      self.page.Keys("[Tab]")
#      Delay(2000)
#      currentDate = aqDateTime.Today()
#      currentDate1 = aqConvert.DateTimeToFormatStr(currentDate,"%d-%b-%Y %H:%M:%S")
#      self.page.Find("idStr","ExpenditureItemDate",30).Click()
#      Delay(1000)
#      self.page.Find("idStr","ExpenditureItemDate",30).Keys(currentDate1)
#      Delay(5000)
#      self.wait_until_page_loaded()
#      self.log_message_web("Project details entered")
#      delay(1000)
#      pro_names=("ObjectLabel","ObjectType","ObjectIdentifier")
#      pro_values=("Next","Button","0")
#      self.page.Find(pro_names,pro_values,30).Click()      
#      Delay(10000)
#      self.wait_until_page_loaded()
#      self.page.EvaluateXPath("//table[@id='PageActionButtonsBar']/tbody/tr//td/button[@title='Next']")[0].Click()      
#      delay(2000)
#      self.wait_until_page_loaded()
#      Delay(2000)
#      self.page.EvaluateXPath("//table[@id='PageActionButtonsRN_uixr']//button[@id='SubmitButton_uixr']")[0].Click()
##      self.log_message_web("Requisition submitted successfully") 
#      Delay(2000)
#      self.wait_until_page_loaded()

  def req_info(self,app,rowno):
      
          fut_date = aqDateTime.AddDays(aqDateTime.Now(),3)
          fut_date1 = aqConvert.DateTimeToFormatStr(fut_date,"%d-%b-%Y %H:%M:%S")
          Delay(2000) 
          currentDate = aqDateTime.Today()
          currentDate1 = aqConvert.DateTimeToFormatStr(currentDate,"%d-%b-%Y %H:%M:%S") 
          self.wait_until_page_loaded()   
          cart_box = self.page.FindChildEx("idStr","popupShoppingCartPopup",60,True, 40000)
          Delay(2000) 
    #      obj=self.page.Find("idStr","NeedByDate",50)
          if cart_box.Exists:
            self.log_checkpoint_message_web("Requisition Information Popup Launched Successfully")
          else:
            self.log_error_message("Unable to Launch Requisition Information PopUp")      
    
          Sys.HighlightObject(cart_box)
          Delay(1000)
          cart_box.FindChildEx("idStr","ReqSummaryHideShow__xc_",50,True,30000).Click()
          Delay(1000)
          cart_box.EvaluateXpath("//table[@id = 'BillingLabeledFieldLayout']//input[@id='ProjectOnSummaryExpense']")[1].Click()
          Delay(1000)
          cart_box.EvaluateXpath("//table[@id = 'BillingLabeledFieldLayout']//input[@id='ProjectOnSummaryExpense']")[1].Keys(app.Cells.item[rowno,11])
          cart_box.Keys("[Tab]")
          cart_box.Keys("[Tab]")
          Delay(1000)
          cart_box.EvaluateXpath("//table[@id = 'BillingLabeledFieldLayout']//input[@id='TaskExpense']")[1].Keys(app.Cells.item[rowno,12])
          Delay(1000)
          cart_box.Keys("[Tab]")
          cart_box.Keys("[Tab]")
          Delay(1000)
          cart_box.EvaluateXpath("//table[@id = 'BillingLabeledFieldLayout']//input[@id='ExpenditureTypeOnSummary']")[1].Keys(app.Cells.item[rowno,13])
          Delay(1000)
          cart_box.Keys("[Tab]")
          cart_box.Keys("[Tab]")
          Delay(1000)
          cart_box.EvaluateXpath("//table[@id = 'BillingLabeledFieldLayout']//input[@id='ExpenditureOrg']")[0].Keys(app.Cells.item[rowno,14])
          Delay(1000) 
          cart_box.Keys("[Tab]")
          cart_box.Keys("[Tab]")
          Delay(1000)
          cart_box.EvaluateXpath("//table[@id = 'BillingLabeledFieldLayout']//input[@id='ExpenditureItemDate']")[0].Keys(currentDate1)
          Delay(2000)
          cart_box.FindChild("idStr","NeedByDate",20).Click()
          Delay(1000)
          cart_box.FindChild("idStr","NeedByDate",20).Keys(fut_date1)
          Delay(4000)
          self.wait_until_page_loaded()
          self.log_message_web("Project details entered")
          delay(1000)
          cart_box.Find("idStr","ShoppingPopupSubmit",30).Click()
    
          Delay(2000)
          self.wait_until_page_loaded()

     
  #method to submit and to write the requisition details to Excel    
  def get_reqno(self,rowno,app):
      self.wait_until_page_loaded()      
      obj=self.page.Find("idStr","ApproverText",50)
      if obj.Exists:
        self.log_checkpoint_message_web("Requisition No. Generated Successfully: Validated and Captured the Req.number")
      else:
        self.log_message_web("Unable to Complete Creating Non-Catalog Requisition")
      
      Rno = self.page.Find("idStr","ApproverText",30).contentText
      Delay(1000)
      Rno1 = aqString.SubString(Rno,12,5)
      self.log_message_web("Non-Catalog Requisition:" + Rno1)      
      delay(1000)    
      app.Cells.Item[rowno,15] = Rno1
      Delay(2000)      
      self.page.Find("contentText","Home",20).Click()
      self.wait_until_page_loaded()




    
#def sample():
##      
#      page=Sys.Browser("iexplore").Page("*")
###      Sys.Highlightobject(Sys.Browser("iexplore").Page("*").EvaluateXPath("//select[@id='ItemType']")[0]) 
#      Sys.Browser("iexplore").Page("*").EvaluateXPath("//select[@name='ItemType']")[0].ClickItem("Services billed by quantity")     
###      page.Find("idStr","ItemType",30).ClickItem('Services billed by quantity')
#      page.Keys("[Tab][Tab]")
#      page.Keys("test")
#      page.Keys("[Tab]")
#      delay(1000)
#      page.Keys("AUTO PARTS.AIR CONDITIONING AUTO PARTS.AIR CONDITIONING - AFTER MARKET.CLIENT")
##      delay(1000)
##      Sys.Browser("iexplore").Page("*").EvaluateXPath("//table[@id='ItemInfoLabelRN']//textarea[@id='ItemDescription']")[0].Click()
##      Sys.Browser("iexplore").Page("*").EvaluateXPath("//table[@id='ItemInfoLabelRN']//textarea[@id='ItemDescription']")[0].SetText("test1")
##      Sys.Browser("iexplore").Page("*").Find("idStr","ItemDescription",20).Click()
##      delay(1000)
##      Sys.Browser("iexplore").Page("*").Find("idStr","ItemDescription",20).Keys("test1")
#      delay(1000)
#      Sys.Browser("iexplore").Page("*").Find("idStr","Category",20).Click()
#      delay(1000)
#      Sys.Browser("iexplore").Page("*").Find("idStr","Category",20).Keys("test")
      
      




