from ebiz import *

class ie_clear_cache(Ebiz):
  
    def login(self):
       pass
       
         
    def logout(self):
      pass    
          
    def action(self,book):
      if gvar.dataprep['browser'] == 'ie':
        wscript=Sys.OleObject["WScript.Shell"]
        wscript.Run("RunDll32.exe InetCpl.cpl,ClearMyTracksByProcess 8")
        Delay(3000)
        wscript.Run("RunDll32.exe InetCpl.cpl,ClearMyTracksByProcess 255")
        Delay(3000)
        wscript.Run("RunDll32.exe InetCpl.cpl,ClearMyTracksByProcess 1")
        Delay(3000)
        wscript.Run("RunDll32.exe InetCpl.cpl,ClearMyTracksByProcess 2")
        Delay(3000)
        wscript.Run("RunDll32.exe InetCpl.cpl,ClearMyTracksByProcess 16")
        Delay(3000)
        wscript.Run("RunDll32.exe InetCpl.cpl,ClearMyTracksByProcess 32")
        Delay(3000)
        Log.Enabled=True
        Log.Message("IE Browser History cleared successfully!","")
        Log.Enabled=False
        self.page.Close()
        delay(2000)
        jFrame=Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1)
        if (Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).Exists):
           Log.Enabled=True
           Sys.HighlightObject(jFrame)
           jFrame.Close()
           delay(2000)
           jFrame.Keys("~o")
           delay(4000)
           Log.Message("Succesfully closed existing Java Form")
           Log.Enabled=False
      elif gvar.dataprep['browser'] == 'chrome':
        aqFile.Delete("%LOCALAPPDATA%\\Google\\Chrome\\User Data\\Default\\History")
        aqFile.Delete("%LOCALAPPDATA%\\Google\\Chrome\\User Data\\Default\\Cache")
        aqFile.Delete("%LOCALAPPDATA%\\Google\\Chrome\\User Data\\Default\\Cookies")
        Log.Enabled=True
        Log.Message("Chrome Browser History cleared successfully!","")
        Log.Enabled=False  
      self.page.Close()    
