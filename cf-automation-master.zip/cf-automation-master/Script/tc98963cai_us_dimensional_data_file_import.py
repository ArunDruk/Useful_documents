﻿#from dbhelper import *
from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils
import winscp_utility
import web_utils


# Author: Udayashankar  Malay
# The script is completely revamped because of different responsibility, request set, file structure and parameters: Request set - CAI I29 Telecome invoice interface

class tc98963cai_us_dimensional_data_file_import(Ebiz):
 
 global inv_date,inv_num,rowno
 rowno = 2
 op_log_path="C:\\TC_Logs"
 dd_files="C:\\Dimensional_Data_Files"
 
 def login(self):
    self.login_user="amalappan"
    super().login()
 
 def action(self,book):     
    app = book.Sheets.item["Invoice"]
    self.invoice_details(book) #Uncomment later
    self.file_add_winscp(app) 
    self.capture_request_id_journal_import(app)
# Modifying cai_excel_invoice_import_report_set.csv file 
 def invoice_details(self,book):
   app = book.Sheets.item["Invoice"]
   app1 = Sys.OleObject["Excel.Application"]
   Delay(1000)
   book = app1.Workbooks.Open(Project.Path+"\\DataSheets\\Oracle-AP-Other\\DIMENSION_DATA_ATG_INV_20190924.csv")
   app1.Visible = "True"
   
#   web_utils.close_excel_sign_in_window()
#   delay(2000)

   delay(4000)
   sign_in_excel_obj=Sys.Process("EXCEL").Window("NUIDialog", "Sign in to set up Office", 1)
   Sys.HighlightObject(sign_in_excel_obj)
    #  sign_in_excel_obj.Click()
   delay(2000)  
   if (Sys.Process("EXCEL").Window("NUIDialog", "Sign in to set up Office", 1).Exists):
    delay(2000)
#    Sys.HighlightObject(sign_in_excel_obj)
    Log.Enabled=True
    wnd = Sys.Desktop.ActiveWindow()
    Log.Picture(wnd, "'Excel Sign-in Window'",wnd.FullName)
    Sys.Process("EXCEL").Window("NUIDialog", "Sign in to set up Office", 1).Close()    
    Log.Message("Successfully Closed the Microsoft Excel Sign-in Window")
    Log.Enabled=False 
    delay(2000)
    
   app1.DisplayAlerts= 0
   app1 = book.Sheets.item["DIMENSION_DATA_ATG_INV_20190924"]
   rowno = 2
   self.inv_num = "DD_INV: "+aqConvert.DateTimeToFormatStr(aqDateTime.Time(),"%H:%M:%S")
   for i in range(0,1):
     app1.Cells.Item[rowno+i,1] = "DD_INV: "+aqConvert.DateTimeToFormatStr(aqDateTime.Time(),"%H:%M:%S")#self.inv_num
     app.Cells.Item[2,13] = app1.Cells.Item[rowno+i,1] 
     delay(2000)
     i = i+1 
  
   self.inv_date = aqDateTime.Today()
   app1.Cells.Item[rowno,2] = self.inv_date
   file_system_utils.create_folder(self.dd_files)
   book.SaveAs("C:\\Dimensional_Data_Files\\DIMENSION_DATA_ATG_INV_20190924.csv")
   book.close()
   log_path = ("C:\\Dimensional_Data_Files\\DIMENSION_DATA_ATG_INV_20190924.csv")
   Log.Enabled=True
   Log.File(log_path, "CAI Dimensional Data Inv File Attached")
   Log.Enabled=False    

# Placing cai_excel_invoice_import_report_set.csv file in /DAUT2I/incoming/ATG_OU/AP_XLS_INV_UPLOAD folder
 def file_add_winscp(self,app):
   # uncomment the below later
    Stored_session = "dim_data@mftstg.manheim.com"
#    Stored_session = "opc@stage-fin-iad1-ebsapp1.private.stagefin.oraclevcn.com"
    local_dir = "C:\\Dimensional_Data_Files"    
    remote_dir =  self.testConfig['winscp']['cai_remote_dir']
#    remote_dir =  "//Outbox//TAUTRI"
    upload_file_name = "DIMENSION_DATA_ATG_INV_20190924.csv"
    winscp_utility.upload_file(Stored_session,local_dir,remote_dir,upload_file_name)
    Log.Enabled=True       
    Log.Message("DIMENSION_DATA_ATG_INV_20190924.csv file placed in the AP_XLS_INV_UPLOAD directory")           
    Log.Enabled=False

# Submitting the cai_excel_invoice_import_report_set in Oracle
    Log.Message("Inside action...") 
    
    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI "+self.oper_unit+" AP JOB SCHEDULER')]")
    self.log_message_web("Click 'CAI "+self.oper_unit+" JOB SCHEDULER' - Successful")
    delay(1000)
#    self.page.keys("[Down]")
    self.wait_until_page_loaded()
    self.page.NativeWebObject.Find("contentText","Submit Request","A").Click()
   
    delay(2000) 
#    self.page.wait_until_load()
    web_utils.validate_security_box()
    delay(2000)
    jFrame=self.initializeJFrame()
    delay(2000)
    form_utils.click_ok_btn(jFrame)
    delay(2000)

    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["*Request Set alt s","ExtendedCheckbox"]
    jFrame.Find(prop,val,30).Click()
    Delay(3000)
    #jFrame.Find(prop,val,30).Keys("~o")
    #form_utils.click_ok_btn(jFrame)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit a New Request","ExtendedFrame"]
    jFrame.Find(prop,val,30).Click()

    prop1=["AWTComponentAccessibleName","JavaClassName"]
    val1=["OK alt O","Button"]
    jFrame.FindChildEx(prop,val,60,True,60000).Find(prop1,val1,30).Click()
 
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit Request Set","ExtendedFrame"]
    par_form=jFrame.FindChildEx(prop,val,60,True,60000)
    par_form.Find("AWTComponentAccessibleName","Request Set RequiredList of Values",30).SetText("CAI I29 Telecom Invoice Interface Request Set")# Updated to SetText
    delay(1000)
    par_form.Find("AWTComponentAccessibleName","Request Set RequiredList of Values",30).Click()
    par_form.Find("AWTComponentAccessibleName","Request Set RequiredList of Values",30).Keys("[Tab]")
    delay(1000)
    jFrame.Keys("[Tab]")
    jFrame.Keys("[Tab]")
    Delay(2000)
#    jFrame.Keys("DIMENSION_DATA_ATG_INV_20190924.csv.gpg")
    jFrame.Keys("~o")
    delay(1000) 
    
    par_form.Find("wText","CAI File Decrypt Program",30).Click()
    jFrame.Keys("[Tab]")
    jFrame.Keys("[Tab]")
    jFrame.Keys("Y")
    jFrame.Keys("~o")    
    
   
    delay(1000)
    #par_form.Find("wText","CAI Payables Invoice Import",30).Click() - CAI Global Data Loader for Legacy
    par_form.Find("wText","CAI Global Data Loader for Legacy",30).Click()
    jFrame.Keys("[Tab]")
    jFrame.Keys("[Tab]")
    jFrame.Keys("~o")    
  
    par_form.Find("wText","Payables Open Interface Import",30).Click()
    jFrame.Keys("[Tab]")
    jFrame.Keys("[Tab]")
    jFrame.Keys("~o") 
    delay(1000)
    #jFrame.Keys("~m")
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit","Button"]
    submit_button=jFrame.FindChildEx(prop,val,60,True,60000)    
    submit_button.Click()    
    RequestID = ''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit())
    Log.Message("Request ID Of  " + aqConvert.VarToStr(RequestID))
    app.Cells.Item[2,21] = VarToStr(RequestID)
#    self.log_checkpoint_message_web("Request ID Of CAI Excel Invoice Import (Report Set) is " + aqConvert.VarToStr(RequestID))  
    self.log_checkpoint_message_web("Request ID Of 'CAI I29 Telecom Invoice Interface Request Set' is " + aqConvert.VarToStr(RequestID))    
    delay(1000)    
    jFrame.Keys("~n")
    delay(1000)
    #jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(5000)
    
 # Verifying in the DB for the completion of the concurrent programs   
#    dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
#    user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
#    pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
#    dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,VarToStr(RequestID)) 
    delay(200000)
    
    
    # Gathering Request ID and Output File for the "CAI Payables Invoice Import Program" 

    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,90000)
    self.req_set_save_log(jFrame,req_form,"Payables Open Interface Import",RequestID)
    jFrame.Click()
    Delay(2000)
     
    
    
       
    
 def capture_request_id_journal_import(self,app):
    jFrame=self.initializeJFrame()
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,60000)  
    job_name="false"
    phase="false"
    i=20
    while (job_name!="Journal Import") or (phase!="Completed"):
     prop=["AWTComponentAccessibleName","AWTComponentIndex"]
     val=["Name",i]
     job_name=req_form.Find(prop,val,10).wText
     prop=["AWTComponentAccessibleName","AWTComponentIndex"]
     val=["Phase",i+20]
     phase=req_form.Find(prop,val,10).wText
     prop=["AWTComponentAccessibleName","AWTComponentIndex"]
     val=["Status",i+30]
     status=req_form.Find(prop,val,10)       
     i+=1     
     if i==28:
       prop=["AWTComponentAccessibleName","JavaClassName"]
       val = ["Refresh Data alt R","Button"]
       req_form.FindChild(prop,val,2000).Click() 
       i=20
    Log.Enabled=True
    aqObject.CheckProperty(status,"wText",cmpIn,"Normal,Warning")
    Log.Enabled=False
    self.log_message_oracle_form(req_form,"Job Name "+aqConvert.VarToStr(job_name))
    self.log_message_oracle_form(req_form,"Phase of Journal Import Program "+aqConvert.VarToStr(phase))   
    prop=["AWTComponentAccessibleName","AWTComponentIndex"]
    val=["Request ID",i-11]
    req_id=req_form.Find(prop,val,10).wText
    
    app.Cells.item[rowno,20] = req_id
    self.log_message_oracle_form(req_form,"Request ID of Journal Import Program "+aqConvert.VarToStr(req_id)) 
    self.close_forms(jFrame) 
#    jFrame.Keys("[F4]")
#    Delay(1000)
#    jFrame.Keys("[F4]")
#    Delay(1000)
#    jFrame.Keys("~o")
#    Delay(1000)
#    Sys.Browser("iexplore").page("https://*ebs.coxautoinc.com/forms/frmservlet*").Close()

    



 def req_set_save_log(self,jFrame,req_form,srch_child_name,Preqid):
    self.log_message_oracle_form(req_form,"Checking for Child Program")
    req_form.FindChild("AWTComponentAccessibleName","Refresh Data alt R",20).Click()
    i=20
    for x in range(1,180):    
#        if i>29:
#          jFrame.Keys("[Down]")        
#          i=29
     
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Name",i]
        child_name=req_form.Find(prop,val,10).wText 
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Phase",i+20]
        phase=req_form.Find(prop,val,10).wText 
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Request ID",i-10]
        creqid= aqConvert.VarToInt(req_form.Find(prop,val,10).wText)
#        self.log_message_oracle_form(req_form,"Request ID of "+aqConvert.VarToStr(srch_child_name)+" is "+aqConvert.VarToStr(creqid))                                         
        prop=["AWTComponentAccessibleName","AWTComponentIndex"]
        val=["Status",i+30]         
        status =req_form.FindChild(prop,val,60)            
        if (child_name==srch_child_name) and (creqid>=VarToInt(Preqid)) and (phase == "Completed"):
            self.log_message_oracle_form(req_form,"phase Completed Successfuly")            
#            self.verify_aqobject_chkproperty(status,"wText",cmpContains,"Normal")        
            status.Keys("[Enter]")
            Delay(1000)
#            jFrame.Keys("~g")  
            #req_form.FindChild("AWTComponentAccessibleName","View Log alt K",20).Click()    
            req_form.FindChild("AWTComponentAccessibleName","View Output alt p",20).Click()    
            Delay(3000)
            output_page=Sys.Browser("iexplore").Page("https://core*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.*")
            output_page.Click()
            Delay(2000)
            output_page.Keys("~f")
            Delay(2000)
            output_page.Keys("a")
            Delay(5000)
            file_system_utils.create_folder(self.op_log_path)             
            log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"File"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"_%d%b%Y_%H%M")+".txt"    
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
            Delay(1000)
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
            Delay(2000)
            Log.Enabled=True
            Log.File(log_path, aqConvert.VarToStr(srch_child_name)+" Log File Attached")
            Log.Enabled=False     
            #Sys.Browser("iexplore").Page("https://core*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.*").Close()
            Filesaved = 'True'
            web_utils.close_additional_browsers()
            Filesaved = 'True'
            return                           
        elif i >=28:
           Delay(20000)
#           req_form.keys("~r")
           req_form.FindChild("AWTComponentAccessibleName","Refresh Data alt R",20).Click()
           Delay(3000)
           i=20
           val=["Name",i]
           child_name=req_form.Find(prop,val,10).wText

        else:  
           Delay(3000)
           i=i+1 
           jFrame.Keys("[Down]")
           
#def sample():
#  
#  jFrame=Sys.Process("jp2launcher").WaitSwingObject("JFrame", "Oracle Applications*", -1,1,90000)
#  prop=["AWTComponentAccessibleName","JavaClassName"]
#  val=["Submit a New Request","ExtendedFrame"]
#  jFrame.Find(prop,val,30).Click()
#
#  prop1=["AWTComponentAccessibleName","JavaClassName"]
#  val1=["OK alt O","Button"]
#  jFrame.FindChildEx(prop,val,60,True,60000).Find(prop1,val1,30).Click()
  
  