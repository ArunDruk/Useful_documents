﻿import gvar
from  database_service  import query_oracle_db as __ORACLE_DB 
from gvar import dataprep as DATAPREP
import tc_logs
import odm_datatype


def get_flr_kjk_payment_id_query():
   return  f""" SELECT 'B:' 
    || TO_CHAR(( SELECT cust_account_id agency_id FROM hz_cust_accounts a WHERE a.account_number = '12000092' )) 
	  || ':' 
	  || TO_CHAR(( SELECT cust_account_id dealer_id FROM hz_cust_accounts a WHERE a.account_number = '{DATAPREP['buyer']}' )) PAYMENT_ID
    FROM  dual """
   

def get_payment_method_id_for_check():
   sqlQuery = f""" SELECT rm.receipt_method_id || '.' || account.ext_bank_account_id PAYMENT_METHOD_ID,
                     decode(rm.name, 'ACH Bank Transfer', 'ACH', rm.name) PAYMENT_METHOD_TYPE,
                     party.party_name paymentmethodname,
                     account.masked_bank_account_num paymentmethodaccount,
                     NULL paymentmethodavailableamount,
                     NULL floatContractAllowed,
                     NULL agencyDealerNumber,
                     NULL customerNumber
                FROM ar_receipt_methods      rm,
                     ar_receipt_classes      rc,
                     iby_ext_bank_accounts   account,
                     iby_pmt_instr_uses_all  acc_instr,
                     iby_external_payers_all ext_payer,
                     hz_parties              party,
                     hz_cust_accounts_all hz
               WHERE rc.receipt_class_id = rm.receipt_class_id
                 AND rm.start_date <= trunc(SYSDATE)
                 AND nvl(rm.end_date, trunc(SYSDATE)) >= trunc(SYSDATE)
                 AND account.ext_bank_account_id = acc_instr.instrument_id
                 AND acc_instr.instrument_type = 'BANKACCOUNT'
                 AND acc_instr.payment_function = 'CUSTOMER_PAYMENT'
                 AND acc_instr.payment_flow = 'FUNDS_CAPTURE'
                 AND account.attribute8 = 'APPROVED'
                 AND trunc(acc_instr.start_date) <= trunc(SYSDATE)
                 AND trunc(nvl(acc_instr.end_date, SYSDATE + 1)) > trunc(SYSDATE)
                 AND acc_instr.ext_pmt_party_id = ext_payer.ext_payer_id  
                 AND ext_payer.cust_account_id = hz.cust_account_id
                 AND party.party_id = account.bank_id
                 AND ext_payer.acct_site_use_id IS NULL
                 AND rm.attribute2='CHECK'
                 AND hz.account_number='{DATAPREP['buyer_bill_to']}'
                 FETCH FIRST ROW ONLY
                 """ 
   rows = __ORACLE_DB(sqlQuery)
   if (GetVarType(rows)== VarToInt(9)and len(rows)> 0):
        DATAPREP['payment_method_id'] = rows[0]['PAYMENT_METHOD_ID']
        DATAPREP['payment_type'] =  rows[0]['PAYMENT_METHOD_TYPE']
   else:
       tc_logs.error_with_no_picture(f" Payment method id not found for Buyer: {DATAPREP['buyer']} ")           
       odm_datatype.update_status('Failed')


def get_trx_query():
   sql = f""" SELECT 'ORDER'  SOURCE
                       , TO_CHAR(ooha.header_id) INVOICE_NUMBER 
                        , ooha.creation_date 
            , TO_CHAR((( SELECT SUM (oola.unit_selling_price * 
                    (CASE WHEN oola.LINE_CATEGORY_CODE ='RETURN' THEN -1*oola.ORDERED_QUANTITY ELSE oola.ORDERED_QUANTITY END) ) 
                            order_total_amount
                  FROM   oe_order_lines_all oola
                  WHERE  oola.header_id = ooha.header_id
                ) - (SELECT
                      nvl(SUM(amount_applied),0)
                    FROM
                        ar_receivable_applications_all araa
                    WHERE
                        araa.attribute1 = TO_CHAR(ooha.order_number)
                        AND   araa.org_id = ooha.org_id
                        AND   araa.display = 'Y'
                      ) )) AMT_DUE_REMAINING
            FROM   oe_order_headers_all   ooha
            WHERE   1=1
            AND    ooha.order_number={gvar.dataprep['buyer_order']}
            AND    NOT EXISTS ( SELECT '1'
                    FROM   ra_customer_trx_all rcta
                    WHERE  rcta.INTERFACE_HEADER_ATTRIBUTE1 = to_char(ooha.order_number)
                    AND    rcta.interface_header_context = 'ORDER ENTRY'
                  )                  
        UNION ALL
          SELECT 'INVOICE' SOURCE
              ,TO_CHAR(rcta.customer_trx_id) INVOICE_NUMBER 
              , ooha.creation_date CREATION_DATE
              ,TO_CHAR(apsa.amount_due_remaining) AMT_DUE_REMAINING
          FROM   oe_order_headers_all ooha
            ,ra_customer_trx_all  rcta
            ,ar_payment_schedules_all apsa
      WHERE  1=1
      AND   to_char(ooha.ORDER_NUMBER)    = rcta.INTERFACE_HEADER_ATTRIBUTE1
      AND   rcta.interface_header_context = 'ORDER ENTRY'
      AND   rcta.customer_trx_id = apsa.customer_trx_id
      AND   ooha.order_number={gvar.dataprep['buyer_order']}"""
   Log.Message(sql)
   return sql
   
def get_ach_trx_query():
   sql = f""" 
 SELECT
	*
  FROM
	(
	
	SELECT
		'ORDER' SOURCE,
		moc.consignment_id,
		ooha.order_number,
		ooha.header_id,
		hca_bill.account_number seller_number,
		ooha.context,
		ooha.attribute4 vin,
		ooha.creation_date,
		oola.flow_status_code,
		( ( SUM( ( (oola.ordered_quantity) * oola.unit_selling_price) + NVL(oola.tax_value, 0) ) OVER( PARTITION BY ooha.header_id ) ) - (
		SELECT
			NVL(SUM(amount_applied), 0)
		FROM
			ar_receivable_applications_all araa
		WHERE
			araa.attribute1 = TO_CHAR(ooha.order_number)
			AND araa.org_id = ooha.org_id
			AND araa.display = 'Y' ) ) AMT_DUE_REMAINING,
			oola.ordered_item
	FROM
		oe_order_headers_all ooha,
		oe_order_lines_all oola,
		manar.man_om_consignments moc,
		hz_cust_site_uses_all hcsua_bill_to,
		hz_cust_acct_sites_all hcasa_bill_to,
		hz_cust_accounts_all hca_bill
	WHERE
		1 = 1
		AND ooha.context = 'US BUYER'
		AND ooha.order_number NOT IN (
		SELECT
			interface_header_attribute1
		FROM
			ra_customer_trx_all
		WHERE
			interface_header_attribute1 IS NOT NULL
			AND interface_header_context = 'ORDER ENTRY' )
		AND ooha.header_id = oola.header_id
		AND oola.flow_status_code <> 'ENTERED'
		AND oola.flow_status_code <> 'BOOKED'
		AND ooha.attribute2 = moc.consignment_id
		AND moc.title_status_code IS NULL
		AND ooha.attribute20 IS NULL
		AND ooha.attribute5 IS NULL
		AND ooha.invoice_to_org_id = hcsua_bill_to.site_use_id
		AND hcsua_bill_to.cust_acct_site_id = hcasa_bill_to.cust_acct_site_id
		AND hcasa_bill_to.cust_account_id = hca_bill.cust_account_id
		AND ooha.attribute3 IS NULL
		AND hca_bill.account_number = '{gvar.dataprep['buyer']}'
		AND ooha.attribute4 = '{gvar.dataprep['vin']}'
		AND ( hca_bill.cust_account_id = hca_bill.cust_account_id
		OR ooha.sold_to_org_id = hca_bill.cust_account_id ) 
		
		) 
WHERE
	AMT_DUE_REMAINING <> 0
	AND ordered_item = 'V'
ORDER BY
	creation_date DESC FETCH FIRST ROW ONLY"""
   
   Log.Message(sql)
   return sql
   
def get_pmt_method_id(payment_type):
    sql = f"""SELECT rm.receipt_method_id || '.' || account.ext_bank_account_id paymentmethodid,
                     decode(rm.name, 'ACH Bank Transfer', 'ACH', rm.name) paymentmethodtype,
                     party.party_name paymentmethodname,
                     account.masked_bank_account_num paymentmethodaccount,
                     NULL paymentmethodavailableamount,
                     NULL floatContractAllowed,--6D
                     NULL agencyDealerNumber, --21D
                     NULL customerNumber--32D
                FROM ar_receipt_methods      rm,
                     ar_receipt_classes      rc,
                     iby_ext_bank_accounts   account,
                     iby_pmt_instr_uses_all  acc_instr,
                     iby_external_payers_all ext_payer,
                     hz_parties              party,
                     hz_cust_accounts_all hz
               WHERE rc.receipt_class_id = rm.receipt_class_id
                 AND rm.start_date <= trunc(SYSDATE)
                 AND nvl(rm.end_date, trunc(SYSDATE)) >= trunc(SYSDATE)
                 AND account.ext_bank_account_id = acc_instr.instrument_id
                 AND acc_instr.instrument_type = 'BANKACCOUNT'
                 AND acc_instr.payment_function = 'CUSTOMER_PAYMENT'
                 AND acc_instr.payment_flow = 'FUNDS_CAPTURE'
                 AND trunc(acc_instr.start_date) <= trunc(SYSDATE)
                 AND trunc(nvl(acc_instr.end_date, SYSDATE + 1)) > trunc(SYSDATE)
                 AND acc_instr.ext_pmt_party_id = ext_payer.ext_payer_id    
                 AND ext_payer.cust_account_id = hz.cust_account_id
                 AND party.party_id = account.bank_id
                 AND ext_payer.acct_site_use_id IS NULL
                 AND rm.attribute2='{payment_type}'
                 AND hz.account_number='{gvar.dataprep['buyer']}'
                 FETCH FIRST ROW ONLY"""
    Log.Message(sql)
    return sql
   
