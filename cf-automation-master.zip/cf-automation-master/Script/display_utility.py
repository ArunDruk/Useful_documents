﻿     
import traceback

from ebiz import *


class display_utility(Ebiz):
  
    def login(self):
       pass
       
    def logout(self):
      pass  
      

    def action(self,book):
      self.SetDisplay(1920,1080,32)
      self.LogDisplayProperties()
      
    def SetDisplay(self,x, y, d):
      dm = Win32API.DevMode()
      if 0 < Win32API.EnumDisplaySettings(0,-1,dm):
        dm.dmPelsWidth = x
        dm.dmPelsHeight = y
        dm.dmBitsPerPel = d
        
        res = Win32API.ChangeDisplaySettings(dm,0)
        if res == DISP_CHANGE_BADMODE:
          Log.Enabled = True
          Log.Error("A call to the ChangeDisplaySettings() function failed in the " + "SetDisplay() function.","The specified graphics mode (screen resolution: " + str(x) + "*" +
                        str(y) + "; color depth: " + str(d) + " bits per pixel) is not supported.",                  pmLower)
        return res
        
      
      else:
        dwLastError = Win32API.GetLastError()
        Log.Error("A call to the EnumDisplaySettings() failed in the " +"SetDisplay() function.","System error code: " + str(dwLastError) + " (" + str( Utilities.SysErrorMessage(dwLastError)) + ")", pmLower);
        return -1
        Log.Enabled = False
        
    def LogDisplayProperties(self):
      dm = Win32API.DEVMODE()
      if 0 < Win32API.EnumDisplaySettings(0, -1,dm):
        Log.Enabled = True
        Log.AppendFolder("Current display settings")
        Log.Message("Width: " + str(dm.dmPelsWidth))
        Log.Message("Height: " + str(dm.dmPelsHeight))
        Log.Message("Bits: " + str(dm.dmBitsPerPel))
        Log.PopLogFolder()
        Log.Enabled = False
