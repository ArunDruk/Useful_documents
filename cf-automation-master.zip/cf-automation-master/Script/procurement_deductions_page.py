﻿import gvar

### In this method objects for below pages have been captured ###

#PROCUREMENT > DEDUCTIONS PAGE

################################# Search  Deductions #################################################


def procurement_deductions_page_link():
  prop_names = ["contentText","idStr","ObjectType"]
  prop_values = ["Deductions","PA_DEDUCTIONS","Link"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def supp_name_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["SupplierName","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def supp_site_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["SupplierSite","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def po_num_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["PONumber","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def deduction_number_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["DedReqNum","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def debit_memo_number_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["DebitMemoNum","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def change_doc_number_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["ChangeDocNum","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def doc_status_dropdown():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["DocStatus","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def deductions_from_date_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["DRFromDate","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def deductions_to_date_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["DRToDate","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


  
def debit_memo_fromdate_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["DMFromDate","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


def debit_memo_todate_textfeild():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["DMToDate","Textbox"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def srch_deductions_go_button():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["GoBtn","Button"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

  
def srch_deductions_clear_button():
  prop_names = ["idStr","ObjectType"]
  prop_values = ["GoBtn","Button"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)

########################################### Deductions ######################################################

def create_deductions_button():
  prop_names = ["idStr","ObjectType","ObjectLabel"]
  prop_values = ["CreateDedBtn","Button","Create Deduction"]
  return gvar.dataprep['page'].FindChildEx(prop_names,prop_values,50,True,20000)


