﻿#Author:            Sandeep Kowtha
#TestCaseID:        TC84513
#UserStoryID:       US192329
#Reviewed_By:       Syed Hussain


from driverchain import *
from journals_post import *


class driver(Driverchain):
  global classarr
  
  def __init__(self):    
    global test_env
    self.test_env="tmnh2i"
    self.classarr=["journals_post()"]     
    super().__init__(self.classarr)
    
    
def main():  
  cobj=driver().run()
