﻿from base import *
from driverchain import *
from ebiz import *
import test_utility
import gvar
import tc_logs



class Driver(Driverchain):
  global classarr,env
  
  def __init__(self):
    global test_env, sheet_obj, book     
    app = Sys.OleObject["Excel.Application"]
    Delay(1000)
    self.book = app.Workbooks.Open(Project.Path+"\\datasheets\\E2E\\E2E_003.xls")          
    app.Visible = "True"    
    self.test_env=BuiltIn.ParamStr(14)
    self.oper_unit=BuiltIn.ParamStr(15)
    self.classarr=["ie_clear_cache()","tc85181cai_us_project_creation()","tc98618cai_us_create_catalog_req()","tc93547cai_us_approve_non_catalog_req()","ie_clear_cache()","tc98611cai_us_auto_create_po_validation_1()","tc16319cai_us_ReceivePoItems()","tc260160cai_us_ReturnReceipt()","ie_clear_cache()","tc84510cai_us_create_manual_ap_invoice_match()","tc93849cai_us_create_accounting()","tc98616cai_us_ap_invoices_initiate_approval()","ie_clear_cache()","tc95047cai_us_validate_subledger_accounting()","tc95046cai_us_domestic_ach_payment()","ie_clear_cache()","tc93850cai_us_journal_validation()","ie_clear_cache()","tc97359cai_us_cai_pa_nightly_request_set()","ie_clear_cache()","tc97750cai_us_create_project_asset()","ie_clear_cache()","tc93484cai_us_prc_generate_asset_lines_for_a_single_project()","tc93485cai_us_prc_interface_assets_to_oracle_assets()","ie_clear_cache()","tc93507cai_us_post_mass_additions()","tc99685cai_us_asset_inquiry()","ie_clear_cache()","tc97761cai_us_asset_tieback()"]       
    super().__init__(self.classarr)
    	
  def close_excel(self):    
    self.book.save()
    delay(1000)
    self.book.close()
	
	
### Added utilities in the main method for Rally TestComplete API Integration (Pushing to GIT in TOGGLE:OFF mode)###
    	
def main():
  try:
    #gvar.dataprep['env'] = 'oci_stage'
    obj=Driver()
    test_utility.start_test(__name__.center(70,'*'),'Core Financials - CF','CAI E2E','123055','CAI E2E - OCI Stage') 
    cobj = obj.run()
    print('evoke test_utility')
  except:
    gvar.dataprep['verdict'] = 'Fail'
    tc_logs.header_name('Test Failed - traceback shown below')       
    tc_logs.error_with_no_picture(traceback.format_exc(),'')       
    print('evoke test_utility')
  finally:
    test_utility.end_test()
    obj.close_excel()
