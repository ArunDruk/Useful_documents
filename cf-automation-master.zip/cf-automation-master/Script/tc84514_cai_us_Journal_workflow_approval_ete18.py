﻿from ebiz import *
import web_utils
import form_utils
import dbhelper
import file_system_utils


class tc84514_cai_us_Journal_workflow_approval_ete18(Ebiz):

 op_log_path ="C:\\TC_Logs"

 def login(self):
   self.login_user='Bbristow'
   super().login()
   
 def action(self,book): 
    if ProjectSuite.Variables.currency =="USD": 
      app = book.Sheets.item["JournalWebAdi_USD"]
    elif ProjectSuite.Variables.currency=="CAD":
      app = book.Sheets.item["JournalWebAdi_CAD"]
    self.page.Wait()
    self.log_checkpoint_message_web("Login Successful")
   # self.page.EvaluateXPath("//a[@id='AppsNavLink' and contains(text(),'Workflow User Web (New)')]")[0].Click()
#    self.page.Wait()
#    self.page.Find("idStr","N61",30).Click()
#    self.page.Wait()

    self.page.EvaluateXPath("//button[@id='NtfFullList']")[0].Click()
    self.page.wait()
    self.log_message_web("Click FullList Successful")
    Delay(5000)
    table_obj=self.page.EvaluateXPath("//table[@id='NtfWorklist:Content']")[0]    
    tot_rows=table_obj.RowCount
    
    self.log_message_web("Total Number Of Open Notifications : " + VarToStr(tot_rows) )
    #expected_jrnl_name="Journal batch Test_Journal_168 19-FEB-2019 20:17:19 requires your approval."
    req_id=app.Cells.Item[2,14]
    Delay(3000)
   
    for i in range(0,VarToInt(tot_rows)-1):
      subject=subject=table_obj.FindChild("name","Cell("+aqConvert.VarToStr(i)+",3)",10).contentText
      Delay(3000)
      Subject_message=subject.split(" ",7)[2][0:11]
      Subject_req_id=subject.split(" ",7)[5][0:9]
      if (Subject_message=='Spreadsheet') and (VarToInt(Subject_req_id) == req_id):
        self.log_message_web("Journal Name: "+ subject)
        self.page.Find("idStr","N*:NtfSubject:"+aqConvert.VarToStr(i),30).Click()
        Delay(3000)
        self.log_message_web("Found request ID : " + VarToStr(Subject_req_id) + " ; Click Approve next")
        Delay(3000)
        self.page.EvaluateXPath("//button[@title='Approve']")[0].Click()
        self.page.wait()
        break

    
