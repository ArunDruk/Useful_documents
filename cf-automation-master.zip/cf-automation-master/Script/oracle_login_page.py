﻿import gvar

def username_textfield():
   prop = ["idStr","ObjectLabel"]
   val = ["usernameField","User Name"]
   return gvar.dataprep['page'].FindChild(prop,val,5000) 
  
def password_textfield():
   prop = ["idStr","ObjectLabel"]
   val = ["passwordField","Password"]
   return gvar.dataprep['page'].FindChild(prop,val,5000) 
  
def login_button():
   prop = ["contentText","ObjectType"]
   val = ["Log In","Button"]
   return gvar.dataprep['page'].FindChild(prop,val,5000) 
   
def cancel_button():
   prop = ["contentText","ObjectType"]
   val = ["Cancel","Button"]
   return gvar.dataprep['page'].FindChild(prop,val,5000) 
