﻿import tc_logs
import odm_datatype
import gvar
import api_utility

__print = tc_logs.checkpt_with_no_picture
__Error = tc_logs.error_with_no_picture
__HEAD  = tc_logs.header_name

def verify_title_status(status):
    query = inv_api_consignmentID_and_accountNumber()
    response = api_utility.get("invapi",query)
    validate_title_details_response(response,status)

def verify_psi_status(status):
    query = inv_api_consignmentID_and_accountNumber()
    response = api_utility.get("invapi",query)
    validate_PSI_details_response(response,status)

def verify_arb_status(status,adjustment_type=None):
    gvar.dataprep['custom_head'] = "Invoice API ARB TAGS STATUS CHECK"  
    query = inv_api_consignmentID_and_accountNumber()
    response = api_utility.get("invapi",query)
    validate_arb_details_response(response,status,adjustment_type)
    
def verify_arb_dl_shield_status(status):
    gvar.dataprep['custom_head'] = "INVOICE API DEALSHIELD STATUS TAGS CHECK"  
    query = inv_api_consignmentID_and_accountNumber()
    response = api_utility.get("invapi",query)
    validate_arb_dealshield_status(response,status)


def inv_api_consignmentID_and_accountNumber():
    customerAccountNumber= "customerAccountNumber="+gvar.dataprep['buyer']
    consignmentId= "consignmentId="+gvar.dataprep['consignment_id']
    outputExpansions="outputExpansions="+"CONSIGNMENT HEADER,CONSIGNMENT DETAILS,INVOICE HEADER,INVOICE DETAILS"
    ampersand = '&'
    questionmark = '?'
    return questionmark+customerAccountNumber+ampersand+consignmentId+ampersand+outputExpansions
    
def inv_api_consignmentID_and_seller():
    customerAccountNumber= "customerAccountNumber="+gvar.dataprep['seller']
    consignmentId= "consignmentId="+gvar.dataprep['consignment_id']
    outputExpansions="outputExpansions="+"CONSIGNMENT HEADER,CONSIGNMENT DETAILS,INVOICE HEADER,INVOICE DETAILS"
    ampersand = '&'
    questionmark = '?'
    return questionmark+customerAccountNumber+ampersand+consignmentId+ampersand+outputExpansions

def get_trx_details():
  gvar.dataprep['custom_head'] = "Invoice API Buyer side transactions"  
  verify_arb_transaction(
      api_utility.get("invapi", inv_api_consignmentID_and_accountNumber()))
  
  gvar.dataprep['custom_head'] = "Invoice API Seller side transactions"        
  verify_arb_transaction(
      api_utility.get("invapi", inv_api_consignmentID_and_seller()))    
  
def get_buyer_arb_trx_details(): 
   	  
     verify_arb_transaction(
      api_utility.get("invapi", inv_api_consignmentID_and_accountNumber()))

def get_seller_arb_trx_details(): 
   	  
    verify_arb_transaction(
      api_utility.get("invapi", inv_api_consignmentID_and_seller()))

def validate_title_details_response(response,status):    
    if response['customer']['consignments']:
       consignments = response['customer']['consignments']
    else:
       tc_logs.error_with_no_picture(f"Invoice API Response - Consignments didn't found") 
       odm_datatype.update_status('Failed')     
    if type(consignments) == list:
        for index,item in enumerate(consignments):
            validate_title_rules(status, item['consignmentDetails']['titleDetails'])
    else:
            validate_title_rules(status, consignments['consignmentDetails']['titleDetails'])

def validate_title_rules(status, titles):
    MATCHED   =  {'sellerTitleStatus':'RECEIVED', 'buyerTitleStatus':'ABSENT'}
    VALIDATED =  {'sellerTitleStatus':'VALIDATED','buyerTitleStatus':'PRESENT'}
    if status.upper() == 'MATCHED':
        rs = MATCHED
    else:
        rs = VALIDATED
    if (status.upper() == titles['systemTitleStatus'].upper()):
        __print(f"Invoice API status: '{status}' Matched with ConsignmentID status") 
    else:
        odm_datatype.update_status('Failed')
        __print(f"Invoice API status: {status} didn't Matched with ConsignmentID status {item['consignmentDetails']['titleDetails']['systemTitleStatus']}")
    if  (rs['sellerTitleStatus'].upper() == titles['sellerTitleStatus'].upper()):
         __print(f"Invoice API sellerTitleStatus value: '{rs['sellerTitleStatus']}' Matched with ConsignmentID: '{titles['sellerTitleStatus']}'") 
    else:
         odm_datatype.update_status('Failed')
         __Error(f"Invoice API sellerTitleStatus value: '{rs['sellerTitleStatus']}' didn't Matched with ConsignmentID: '{titles['sellerTitleStatus']}'") 
    if  (rs['buyerTitleStatus'].upper() == titles['buyerTitleStatus'].upper()):
         __print(f"Invoice API buyerTitleStatus value: '{rs['buyerTitleStatus']}' Matched with ConsignmentID: '{titles['buyerTitleStatus']}'") 
    else:
         odm_datatype.update_status('Failed')
         __Error(f"Invoice API buyerTitleStatus value: '{rs['buyerTitleStatus']}' didn't Matched with ConsignmentID: '{titles['buyerTitleStatus']}'") 

def validate_PSI_details_response(response,status):    
    if response['customer']['consignments']:
       consignments = response['customer']['consignments']
    else:
       __Error(f"Invoice API Response - Consignments didn't found") 
       odm_datatype.update_status('Failed')     
    if type(consignments) == list:
        for index,item in enumerate(consignments):
            validate_psi_rules(status, item['consignmentDetails']['postSaleInspectionOrder'])
    else:
            validate_psi_rules(status, consignments['consignmentDetails']['postSaleInspectionOrder'])
            
def validate_psi_rules(status,inv_psi_response):
    if (status.upper() == inv_psi_response['psiStatus'].upper()):
        __print(f"Invoice API PSI status: '{status}' Matched with ConsignmentID PSI status") 
    else:
        __Error(f"Invoice API PSI status: 'CANCEL' Matched with ConsignmentID PSI status")
        
def validate_arb_details_response(response,status,adjustment_type):    
    if response['customer']['consignments']:
       consignments = response['customer']['consignments']
    else:
       __Error(f"Invoice API Response - Consignments didn't found") 
       odm_datatype.update_status('Failed')     
    if type(consignments) == list:
        for index,item in enumerate(consignments):
            validate_arb_rules(status, item['consignmentDetails']['arbitrationDetails'],adjustment_type )
    else:
            validate_arb_rules(status, consignments['consignmentDetails']['arbitrationDetails'],adjustment_type)
            
def validate_arb_rules(status,inv_arb_response,adjustment_type):
    Error = False 
    if (status.upper() == inv_arb_response['arbitrationStatus'].upper()):
        __print(f"Invoice API ARB status: '{status}' Matched") 
    else:
        __Error(f"Invoice API ARB status: '{status}' Not Matched")       
    if ( status.upper() != 'INITIATED'):
        if  ( inv_arb_response['arbitrationAdjustmentType'] ==  adjustment_type):    
          __print(f"Invoice API CONSIGNMENT ARB status: '{adjustment_type}' Matched") 
        else:
          __Error(f"Invoice API CONSIGNMENT ARB status: '{adjustment_type}' didn't Matched with Response")
          
def validate_arb_dealshield_status(response,status):
    if response['customer']['consignments']:
       consignments = response['customer']['consignments']
    else:
       __Error(f"Invoice API Response - Consignments didn't found")
       odm_datatype.update_status('Failed')    
   
    if type(consignments) == list:
        for index,item in enumerate(consignments):
            if item['consignmentDetails']['arbitrationDetails']['dealShieldReturnStatus'] == status:
               tc_logs.checkpt_with_no_picture(f"Dealshield arbitration status : {status} ")
    else:
       if consignments['consignmentDetails']['arbitrationDetails']['dealShieldReturnStatus'] == status:
         tc_logs.checkpt_with_no_picture(f"Dealshield arbitration status : {status} ")  
                  
def inv_api_consignmentID_and_accountNumber2():
     customerAccountNumber= "customerAccountNumber=5228533"
     consignmentId= "consignmentId=11707648"
     outputExpansions="outputExpansions="+"CONSIGNMENT HEADER,CONSIGNMENT DETAILS,INVOICE HEADER,INVOICE DETAILS"
     ampersand = '&'
     questionmark = '?'
     return questionmark+customerAccountNumber+ampersand+consignmentId+ampersand+outputExpansions
     
def verify_arb_transaction(response):
     
    if response['customer']['consignments']:
       consignments = response['customer']['consignments']
    else:
       __Error(f"Invoice API Response - Consignments didn't found") 
       odm_datatype.update_status('Failed')  
    iterate_consignments =  [ validate_trx_details(item['invoices'])
                  for index,item in enumerate(consignments)]  
    iterate_consignments if type(consignments) == list else validate_trx_details(consignments['invoices'])

              
def validate_trx_details(invoices):
    
    include_inv_heads = [ 'invoiceSource','invoiceType','invoiceNumber',
       'invoiceDate','invoiceClass','invoiceLocation',
       'totalAmount','dueAmount','paymentHold','paymentHoldReason',
       'soldToCustomerAccountNumber','billToCustomerAccountNumber',
       'invoiceRepresentativeAccountNumber']

    print_details = lambda invoice : {
     __print(f"{tag} : {details} ")
       for tag ,details in invoice.items() 
     if (tag != 'invoiceDetails' and tag in include_inv_heads)}
    
    def loop_invoice_data(invoice):
     __HEAD(f" **** Invoice {invoice['invoiceNumber']} header deatils **** ")
     print_details(invoice)
     
    iterate_invoices = [ loop_invoice_data(invoice) 
           for index, invoice in enumerate(invoices)] 
    iterate_invoices if type(invoices) == list else loop_invoice_data(invoices)

      
        
        
        
   
