﻿from gmail import *
import tc_logs
import gvar

class capture_invoice_via_email(Gmail):
                        
  def action(self,book):
    #creating variable to check for multiple invoices
    wci_folder="C:\\WCI_files"
    src_folder=Project.Path+"DataSheets\\WCI\\"
    files = {}
    filepath = {}
    
    #Opening the excel Sheet and copying the subject to excel 
    app = book.Sheets.item["mail_wcc"]   
    subject = "TestEmailBatch : "+aqConvert.DateTimeToFormatStr(aqDateTime.Time(),"%H:%M:%S")
    tc_logs.msg_with_picture("Email Subject: "+subject)
    app.Cells.item[2,1]=VarToStr(subject)
    
    #getting the to_address from excel
    if gvar.dataprep['env'] == "oci_stage":
      to_address = VarToStr(app.Cells.item[2,6])
    elif gvar.dataprep['env'] == "oci_test":
      to_address = VarToStr(app.Cells.item[4,6])
    
    #get the filename from excel(for multiple invoices, we are currently testing for 2 invoices - so there are 2 files)
    files['file_name1'] = VarToStr(app.Cells.item[2,4])
    files['file_name2'] = VarToStr(app.Cells.item[2,5])       
    
    #copy file to local folder,attach and send email to create batch in capture
    for key in files:
      if(files[key]!=''):
         filepath[key] = Gmail.place_file_to_localfolder(files[key],wci_folder,src_folder) 
    Gmail.compose_email_wci(files,filepath,to_address,subject)   
         
