﻿from dbhelper import *
from ebiz import *
import dbhelper
import file_system_utils
import winscp_utility


###This testcase is to place the IS to CAI .txt file in the GL inbound directory using WINSCP### 
###and submit is_to_cai_gl_interface request set and capture logs and post the journal which got imported into CAI EBIZ###

class tc99120cai_is_to_cai_gl_interface(Ebiz):

 op_log_path="C:\\TC_Logs"
 is_gl_jrnl_files="C:\\IS_GL_JRNL_Files"

 def login(self):
    self.login_user="mfallwell"
    super().login()

 def action(self,book):
    global jrnl_imp_pro, files 
    self.files = "ISGL_INTERCOMP_CAI_AUG-2020_20200828152705_02.txt"
    self.place_files_local()
    self.add_is_journal_details() 
    self.place_is_jrnl_file_winscp()
    
 def place_files_local(self):
    file_system_utils.create_folder(self.is_gl_jrnl_files)
    file_exist=aqFileSystem.FindFiles("C:\\IS_GL_JRNL_Files\\",self.files) #"ISGL_INTERCOMP_CAI_2019.txt")
    if file_exist != None:
     aqFileSystem.DeleteFile("C:\\IS_GL_JRNL_Files\\" + self.files)
    aqFileSystem.CopyFile(Project.Path+"DataSheets\\Oracle-GL-Journal\\"+self.files, "C:\\IS_GL_JRNL_Files\\"+self.files)
    log_path = ("C:\\IS_GL_JRNL_Files\\"+self.files)
    Log.Enabled=True
    Log.File(log_path, "IStoCAI Import File Attached")
    Log.Enabled=False 

### Modifying ISGL_INTERCOMP_CAI_2019.txt file 
 def add_is_journal_details(self):
    import re
    from datetime import datetime
    
    path = "C:\\IS_GL_JRNL_Files\\"+self.files #ISGL_INTERCOMP_CAI_2019.txt"       
    gl_date=str(datetime.now().strftime("%d-%b-%Y")).upper()
    inv_date=str(datetime.now().strftime("%d-%b-%y")).upper()
    mon_yr=str(datetime.now().strftime("%b-%y")).upper()
    jrnl_des=datetime.now().strftime("%M%S") 
    
    Read_lines=[]
    Write_lines=[]
    with open(path,'r') as fr:
        Read_lines=fr.readlines()
        for line in Read_lines:
            mon_yr_modified=re.sub(r'AUG-20',mon_yr,line)
            gl_date_modified_str=re.sub(r'\d{2}-[A-Z]{3}-\d{4}',gl_date,mon_yr_modified)
#            inv_date_modified=re.sub(r'\d{2}-[A-Z]{3}-\d{2}',inv_date,gl_date_modified_str)
            inv_date_modified=re.sub(r'Invoice\sDate:\s\d{2}-[A-Z]{3}-\d{2}',"Invoice Date: "+inv_date,gl_date_modified_str)
#            mon_yr_modified=re.sub(r'AUG-20',mon_yr,inv_date_modified)
            jrnl_des_modified = re.sub(r'105782376', "10578"+jrnl_des, inv_date_modified)
            Write_lines.append(jrnl_des_modified)
           
    
    with open(path,'w') as fw:
        fw.writelines(Write_lines)    

# Placing ISGL_INTERCOMP_CAI_2019.txt file in //DAUT2I//incoming//ATG_OU//GL_JE_BALANCES_INTF

 def place_is_jrnl_file_winscp(self):
    Stored_session = "man_oracle@mftstg.manheim.com" 
#    Stored_session = "opc@stage-fin-iad1-ebsapp1.private.stagefin.oraclevcn.com" #"j_autr@ftpnonprodautr.oracleoutsourcing.com"
    local_dir = "C:\\IS_GL_JRNL_Files"
    remote_dir =  self.testConfig['winscp']['remote_dir'] 
#    remote_dir =  "//Outbox//TAUTRI"
#    remote_dir =  self.testConfig['winscp']['cai_remote_dir'] 
    upload_file_name = self.files #ISGL_INTERCOMP_CAI_2019.txt"
    winscp_utility.upload_file(Stored_session,local_dir,remote_dir,upload_file_name)
    Log.Enabled=True       
    Log.Message(self.files+" file placed in the GL_JE_BALANCES_INTF directory")           
    Log.Enabled=False

# Login to Oracle EBIZ and select the responsibility
  
    self.page.WaitProperty("contentText","CAI ALL GL JOB SCHEDULER",6000)
    cai_gl_submit_link=self.page.NativeWebObject.Find("contentText","CAI ALL GL JOB SCHEDULER","A")
    self.verify_aqobject_chkproperty(cai_gl_submit_link,"contentText",cmpIn,"CAI ALL GL JOB SCHEDULER")
    cai_gl_submit_link.Click() 
    self.log_message_web("Click 'CAI ALL GL JOB SCHEDULER' - Successful") 
    Delay(1000)  
         
    self.page.Wait()
    self.page.NativeWebObject.Find("contentText","Submit Request","A").Click()
    self.log_message_web("Click 'Submit Request' - Successful") 
    
    jFrame= self.initializeJFrame()
    Delay(10000)

    form_utils.click_ok_btn(jFrame)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit a New Request","ExtendedFrame"]
    submit_new_req_form=jFrame.FindChildEx(prop,val,60,True,90000)
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["What type of request do you want to run? Request Set alt s","ExtendedCheckbox"]  
    submit_new_req_form.FindChild(prop,val,10).Click()       
    Delay(1000)
    submit_new_req_form.FindChild("AWTComponentAccessibleName","OK alt O",10).Click()
    
# Submitting "CAI Oracle GL Inbound JE Interface Request Set - IS" Request Set using CAI ALL GL JOB SCHEDULER' responsibility
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit Request Set","ExtendedFrame"]
    par_form=jFrame.FindChild(prop,val,60)
    par_form.Find("AWTComponentAccessibleName","Request Set RequiredList of Values",30).SetText("CAI Oracle GL Inbound JE Interface Request Set - IS")
    delay(1000)
    
    jFrame.Keys("[Tab]")
    delay(1000)
    
    par_form=jFrame.FindChild(prop,val,60)
    par_form.Find("AWTComponentAccessibleName","Submit",30).Click()
    form_utils.click_ok_btn(jFrame)    
    self.log_message_oracle_form(jFrame,"CAI Oracle GL Inbound JE Interface Request Set - IS Submitted")   
    delay(3000)
    
    RequestID = aqConvert.VarToInt(''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit()))
    Log.Message("Request ID Of  " + aqConvert.VarToStr(RequestID))
    self.log_checkpoint_message_web("Request ID Of CAI Oracle GL Inbound JE Interface Request Set - IS " + aqConvert.VarToStr(RequestID))
    Delay(2000)
    jFrame.Keys("~n")
    
    dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
    user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
    pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
    dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,VarToStr(RequestID)) 
    
    Delay(5000)
    jFrame.Keys("~v")
    Delay(1000)
    jFrame.Keys("r")
    Delay(1000)
    jFrame.Keys("~i")
    Delay(1000) 
    
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,90000) 
    
# Gathering Request ID and Output File for the "CAI Inbound Global File Validation Program" 
    self.req_set_save_log(jFrame,req_form,"CAI Inbound Global File Validation Program",RequestID,type = "Inbound")

# Gathering Request ID and Output File for the "CAI Oracle IS GL Preprocessor Program" 
    self.req_set_save_output(jFrame,req_form,"CAI Oracle IS GL Preprocessor Program",RequestID)
    
# Gathering Request ID and Output File for the "CAI Oracle GL Inbound JE Interface Program"    
    self.req_set_save_output(jFrame,req_form,"CAI Oracle GL Inbound JE Interface Program",RequestID) 

# Gathering Request ID and Output File for the "Journal Import Program" 
    Delay(5000)
    creqid = self.req_set_save_output(jFrame,req_form,"Journal Import",RequestID)
    
    prop = ["AWTComponentAccessibleName","JavaClassName"]
    val = ["Submit a New Request alt m","Button"]
    req_form.FindChild(prop,val,30).Click()
    
# Submitting "Program - Automatic Posting" Request Set using CAI ALL GL JOB SCHEDULER' responsibility
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Submit Request","ExtendedFrame"]
    par_form=jFrame.FindChildEx(prop,val,60,True,90000)
    par_form.Find("AWTComponentAccessibleName","Name RequiredList of Values",30).SetText("Program - Automatic Posting")
    delay(1000)
    
    jFrame.Keys("[Tab]")
    delay(2000)
    jFrame.Keys("CAUTO GL JEs AUTO-POST")
    delay(1000)
    jFrame.Keys("~o")
    delay(2000)
    
    par_form.FindChild("AWTComponentAccessibleName","Submit alt m",10).Click()
    Delay(1000)
    self.log_message_oracle_form(jFrame,"Program - Automatic Posting is Submitted")   
    
    RequestID = aqConvert.VarToInt(''.join(x for x in jFrame.find("AWTComponentAccessibleName","Decision Request submitted*",100).AWTComponentAccessibleName if x.isdigit()))
    Delay(2000)
    jFrame.Keys("~n")
    
    dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
    user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
    pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
    dbhelper.vfy_oracle_concurrent_job_status(dsn,user_id,pwd,VarToStr(RequestID)) 
    
    Delay(5000)
    
# Gathering Request ID and Output File for the "CAI Oracle GL Inbound JE Interface Program"   
    prop=["AWTComponentAccessibleName","JavaClassName"]
    val=["Requests","ExtendedFrame"]
    req_form=jFrame.FindChildEx(prop,val,30,True,90000)  
    self.req_set_save_output(jFrame,req_form,"Program - Automatic Posting",RequestID) 
    
# Gathering Request ID and Output File for the "Journal Import Program" 
    self.req_set_save_output(jFrame,req_form,"Posting: Single Ledger",RequestID)  
      
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("[F4]")
    Delay(1000)
    jFrame.Keys("~o")
    Delay(1000)
    
# Post from CAI CAI ALL GL JOURNAL PROCESSING Responsibility

    web_utils.clk_fldr_link_by_xpath(self.page,"//table[@id='respList']//div[contains(text(),'CAI ALL GL JOURNAL PROCESSING')]")
    self.log_message_web("Click 'CAI ALL GL JOURNAL PROCESSING' - Successful")
    Delay(3000)
    self.page.EvaluateXpath("//table[@id='respList']//div[text()='Enter Journals']")[0].Click()
    self.log_message_web("Click 'Enter Journals'- Successful")
    
    web_utils.validate_security_box()
    Delay(20000)
    jFrame=self.initializeJFrame()
    Delay(8000)
    
    form_utils.click_ok_btn(jFrame)
    
    dsn = self.dbconfig[self.testConfig['ebiz']['env']]['dsn']
    user_id = self.dbconfig[self.testConfig['ebiz']['env']]['userid']
    pwd = self.dbconfig[self.testConfig['ebiz']['env']]['pwd']
    journal_names = get_journal_name_from_batchname(dsn,user_id,pwd,"%"+VarTostr(creqid))
    
    for journal_name in journal_names:
      dbhelper.verify_journal_details(dsn,user_id,pwd,journal_name)
      
      prop=["AWTComponentAccessibleName","JavaClassName"]
      val=["Find Journals","ExtendedFrame"]
      fnd_jrnl=jFrame.FindChildEx(prop,val,60,True,90000)
      fnd_jrnl.Find("AWTComponentAccessibleName","JournalList of Values",10).Click()
      fnd_jrnl.Find("AWTComponentAccessibleName","JournalList of Values",10).Keys(journal_name)
      delay(1000) 
      jFrame.Keys("~i")
      self.log_message_oracle_form(jFrame,journal_name+": Find Journal Successful")
      delay(8000)  
      jFrame.Keys("~u")
      delay(4000) 
      prop=["AWTComponentAccessibleName","JavaClassName"]
      val=["Journals (CAI ALL LEDGERS)*","ExtendedFrame"]
      jrnls=jFrame.FindChildEx(prop,val,60,True,60000)
      jrnls.FindChild("AWTComponentName","FormsTabPanel*",60).ClickTab("Other Information")
      prop=["AWTComponentAccessibleName","AWTComponentIndex"]
      val=["Status: Approval",2]
      jrnl_appr_val = jFrame.FindChild(prop,val,60)
      jrnl_appr_status=jrnl_appr_val.wText  
      self.log_message_oracle_form(jFrame,"Journal Approval Status: "+jrnl_appr_status)   
      prop=["AWTComponentAccessibleName","AWTComponentIndex"]
      val=["Status: Posting",0]
      jrnl_val = jFrame.FindChild(prop,val,60)
      jrnl_status=jrnl_val.wText  
      self.log_message_oracle_form(jFrame,"Journal Status: "+jrnl_status)   
      Log.Enabled=True
      aqObject.CheckProperty(jrnl_val,"wText",cmpIn,"Posted")
      Log.Enabled=False
      self.log_message_oracle_form(jFrame,journal_name+" Journal is Posted")
      delay(4000) 
      jrnls.FindChild("AWTComponentName","FormsTabPanel*",60).ClickTab("Lines")
      delay(4000) 
      prop=["AWTComponentAccessibleName","JavaClassName"]
      val=["Journals (CAI ALL LEDGERS)*","ExtendedFrame"]
      jrnls=jFrame.FindChildEx(prop,val,30,True,60000)
      prop=["JavaClassName","AWTComponentIndex"]
      val=["LWScrollbar","0"]
      down_button=jrnls.FindChildEx(prop,val,30,True,60000)
      for i in range(0,10):
        prop=["JavaClassName","AWTComponentIndex"]
        val=["ContinuousButton","0"]
        down_button.Find(prop,val,20).Click()
      self.log_message_oracle_form(jFrame,"Journal lines Captured")       
      delay(4000)
      jrnls.Close()
      delay(4000)
      prop=["JavaClassName","AWTComponentAccessibleName"]
      val=["ExtendedFrame","Enter Journals (CAI ALL LEDGERS)"]
      jFrame.FindChildEx(prop,val,20,True,10000).Close()
      delay(2000)
      navigator_form = Sys.Process("jp2launcher").SwingObject("JFrame", "Oracle Applications*", -1, 1).SwingObject("FndFormsEngine0").AWTObject("MDIContainer", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("ScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("FormDesktopContainer", "", 0).AWTObject("ExtendedFrame", "Navigator - *", 4).AWTObject("LWComponent", "", 0).AWTObject("EwtComponent", "", 0).AWTObject("FScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("DrawnPanel", "", 0).AWTObject("FormsTabPanel", "", 0).AWTObject("TabPanelSheet", "", 0).AWTObject("FScrollBox", "", 0).AWTObject("ScrollBox$1", "", 0).AWTObject("DrawnPanel", "", 0).AWTObject("VTList", "Function List", 0).AWTObject("ScrollBox", "", 0).AWTObject("LWDataSourceList$Content", "", 0)
      OCR.Recognize(navigator_form).BlockByText("Enter Journals").DblClick()
      Delay(2000)
        
    jFrame.Close()
    Delay(1000)
    jFrame.Keys("~o")
    Delay(1000)
    
 def req_set_save_output(self,jFrame,req_form,srch_child_name,Preqid):
       
       prop=["AWTComponentAccessibleName","JavaClassName"]
       val = ["Refresh Data alt R","Button"]
       req_form.FindChild(prop,val,2000).Click()
       
       Delay(5000)
       
       for x in range(20,51):
         
         if x>29:
           jFrame.Keys("[Down]")        
           x=29
                      
         prop=["AWTComponentAccessibleName","AWTComponentIndex"]
         val=["Phase",x+20]
         phase=req_form.Find(prop,val,10).wText 
         
         prop=["AWTComponentAccessibleName","AWTComponentIndex"]
         val=["Request ID",x-10]
         creqid= aqConvert.VarToInt(req_form.Find(prop,val,10).wText)
         
         prop=["AWTComponentAccessibleName","AWTComponentIndex"]
         val=["Name",x]
         child_name=req_form.Find(prop,val,10).wText
         req_form.Find(prop,val,10).Click()
         
         prop=["AWTComponentAccessibleName","AWTComponentIndex"]
         val=["Status",x+30]         
         status =req_form.FindChild(prop,val,60) 
         
         if (child_name==srch_child_name) and (creqid>=Preqid) and (phase == "Completed"): 
           
           self.log_message_oracle_form(req_form,aqConvert.VarToStr(srch_child_name)+" Phase Completed Successfuly")            
           self.verify_aqobject_chkproperty(status,"wText",cmpIn,"Normal,Warning")
           self.log_message_oracle_form(req_form,"Request ID of "+aqConvert.VarToStr(srch_child_name)+" is "+aqConvert.VarToStr(creqid))
           req_form.Find(prop,val,10).Keys("[Enter]")
           Delay(1000)
           prop=["AWTComponentAccessibleName","JavaClassName"]
           val=["View Output alt p","Button"]
           output_button=req_form.FindChild(prop,val,60)
           output_button.Find("AWTComponentAccessibleName","View Output alt p").Click()     
           Delay(3000)
           output_page=Sys.Browser("iexplore").Page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
           output_page.Click()
           Delay(2000)
           output_page.Keys("~f")
           Delay(2000)
           output_page.Keys("a")
           Delay(5000)
           file_system_utils.create_folder(self.op_log_path)             
           log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"Is Attached_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
           Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
           Delay(1000)
           Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
           Delay(6000)
           Log.Enabled=True
           Log.File(log_path, aqConvert.VarToStr(srch_child_name)+" Output File Attached")
           Log.Enabled=False    
           Sys.Browser("iexplore").page("https://core-*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close() 
           web_utils.close_additional_browsers() 
           Delay(2000)   
           jFrame.Click()
           Delay(2000)
           return creqid
           
 def req_set_save_log(self,jFrame,req_form,srch_child_name,Preqid,type=""):
    
        prop=["AWTComponentAccessibleName","JavaClassName"]
        val = ["Refresh Data alt R","Button"]
        req_form.FindChild(prop,val,2000).Click() 
         
        for x in range(20,51):
          
          if x>29:
            jFrame.Keys("[Down]")        
            x=29
                        
          prop=["AWTComponentAccessibleName","AWTComponentIndex"]
          val=["Phase",x+20]
          phase=req_form.Find(prop,val,10).wText
           
          prop=["AWTComponentAccessibleName","AWTComponentIndex"]
          val=["Request ID",x-10]
          creqid= aqConvert.VarToInt(req_form.Find(prop,val,10).wText)
          
          prop=["AWTComponentAccessibleName","AWTComponentIndex"]
          val=["Name",x]
          child_name=req_form.Find(prop,val,10).wText
          req_form.Find(prop,val,10).Click()
            
          prop=["AWTComponentAccessibleName","AWTComponentIndex"]
          val=["Status",x+30]         
          status =req_form.FindChild(prop,val,60)
          
          if (child_name==srch_child_name) and (creqid>=Preqid) and (phase == "Completed"): 
            
            self.log_message_oracle_form(req_form,aqConvert.VarToStr(srch_child_name)+" Phase Completed Successfuly")            
            self.verify_aqobject_chkproperty(status,"wText",cmpIn,"Normal,Warning")
            self.log_message_oracle_form(req_form,"Request ID of "+aqConvert.VarToStr(srch_child_name)+" is "+aqConvert.VarToStr(creqid))
            req_form.Find(prop,val,10).Keys("[Enter]")
            Delay(1000)
            
            prop=["AWTComponentAccessibleName","JavaClassName"]
            val=["View Log alt K","Button"]
            log_button=req_form.FindChild(prop,val,60)
            log_button.Click()     
            Delay(3000)
            output_page=Sys.Browser("iexplore").Page("https://*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*")
            output_page.Click()
            Log.Enabled=True
            wnd = Sys.Desktop.ActiveWindow()
            Log.Picture(wnd, f"WinScp File Location path: {type}", wnd.FullName)                 
            Log.Enabled=False
            Delay(2000)
            output_page.Keys("~f")
            Delay(2000)
            output_page.Keys("a")
            Delay(5000)
            file_system_utils.create_folder(self.op_log_path)             
            log_path=self.op_log_path+"\\"+aqConvert.VarToStr(srch_child_name.replace(":",""))+"Is Attached_"+aqConvert.DateTimeToFormatStr(aqDateTime.Now(),"%d_%b_%Y_%H_%M_%S")+".txt"    
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys(log_path)
            Delay(1000)
            Sys.Browser("iexplore").Window("#32770", "Save Webpage", 1).Keys("[Enter]")
            Delay(6000)
            Log.Enabled=True
            Log.File(log_path, aqConvert.VarToStr(srch_child_name)+" Log File Attached")
            Log.Enabled=False    
            Sys.Browser("iexplore").page("https://core-*epfinnp.coxautoinc.com/OA_CGI/FNDWRR.exe?*").Close()  
            web_utils.close_additional_browsers()
            Delay(2000)   
            jFrame.Click()
            Delay(2000)
            return creqid


