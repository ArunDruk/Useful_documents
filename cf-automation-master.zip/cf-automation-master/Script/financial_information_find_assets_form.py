﻿import gvar

def assetnumber_textfield():
  prop_names = ["AWTComponentAccessibleName","AWTComponentName"]
  prop_values = ["Asset Number","VTextField449"]
  return gvar.dataprep['jformobject'].Find(prop_names,prop_values,100)

