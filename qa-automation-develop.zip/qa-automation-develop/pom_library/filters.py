import logging
import time

from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait

from locators import filter_locators
from pom_library.helper_methods import HelperMethods
from .pom_base import PomBase

LOGGER = logging.getLogger(__name__)


class Filters(HelperMethods):
    def __init__(self, driver):
        self.driver = driver

        PomBase.__init__(self, self.driver)
        self.actions = ActionChains(driver)
        self.wait = WebDriverWait(driver, 30)

    def is_global_filter_expanded(self):
        return self.get_element_attribute(
            "data-status", (By.XPATH, filter_locators.global_filter)
        ) == "expanded"

    def is_quick_filter_expanded(self):
        return self.get_element_attribute(
            "data-status", (By.XPATH, filter_locators.quick_filter)
        ) == "expanded"

    def click_on_dynamic_filter(self):
        """click  on the dynamic filter on the console page"""
        LOGGER.info("Click on  add dynamic filter ........")
        dynamic_filter_locator = filter_locators.click_on_dynamic_filter
        self.click_on_element(
            (By.XPATH, dynamic_filter_locator),
            timeout=5,
            message="failed to click on dyna,ic filters button",
        )


    def select_priority_filter_from_drop_down(self):
        """
        This method help to select the priority option
        """
        LOGGER.info(".....Select priority from the dynamic filter .........")
        self.click_on_element(
            (By.XPATH, filter_locators.priority),
            timeout=5,
            message="failed to select the priority",
        )


    def click_on_selected_dynamic_filter(self):
        """This method helps to click on the selected filters options"""
        try:
            time.sleep(1)
            LOGGER.info("......click on selected dynamic filters ...........")

            self.click_on_element(
                (By.XPATH, filter_locators.dynamic_filter),
                timeout=5,
                message="failed to select dynamic filter button",
            )
        except:
            LOGGER.info("No dynamic filter is applied ")



    def check_if_global_filter_applied(self):
        """Click on global filter on the console page page"""

        filter: str = self.get_element_text_or_value(
            (By.XPATH, filter_locators.global_filter),
            timeout=5,
            message="failed to get filter name ",
        )
        if filter != "Filter":
            LOGGER.info("filter is applied")
            return True
        else:
            LOGGER.info("filter is not applied ")
            return False

    def click_on_global_filter(self):
        """Click on global filter on the console page page"""
        LOGGER.info("........clicking on global filter...........")
        if self.is_global_filter_expanded():
            return
        self.click_on_element(
            (By.XPATH, filter_locators.global_filter),
            message="Failed to open global filter popup",
        )

    def check_if_dynamic_filter_applied(self):
        """This method helps to  check if dynamic filter is applied"""
        try:
            add_filter_button_in_dynamic_filter = self.wait.until(
                EC.visibility_of_element_located(
                    (By.XPATH, filter_locators.add_a_filter)
                )
            ).is_displayed()
            if add_filter_button_in_dynamic_filter:
                LOGGER.info("add dynamic filter button is filters")
                return True

        except:
            LOGGER.info("add dynamic filters button is not displayed .some filters applied ")
            return False

    def get_count_of_number_of_dynamic_filter(self):
        """This method helps to get the count of dynamic filter"""
        count_of_dynamic_filter_applied = self.driver.find_elements(
            By.XPATH, filter_locators.dynamic_filter
        )
        return count_of_dynamic_filter_applied

    def click_on_deselect_button_in_dynamic_filter_option_applied(self):
        """This method helps to click on deselect dynamic filter option is applied"""
        LOGGER.info("........Click on deselected button.........")

        self.click_on_element(
            (By.XPATH, filter_locators.deselect_dynamic_filter_applied),
            timeout=5,
            message="failed to click on deselect button", )

    def click_on_add_filter(self):
        """select the add dynamic filter option on the filter drop down"""
        LOGGER.info(".........Click on add button ........")

        self.click_on_element(
            (By.XPATH, filter_locators.add_dynamic_filter),
            timeout=5,
            message="failed to click on deselect button", )


    def check_the_presence_of_selected_tab(self):
        """this method check for the presence of the selected tab present
         when some filter is selected in filter pop up"""
        try:
            select_filter = filter_locators.option_selected_dynamic
            filters_options_present = self.wait.until(
                EC.visibility_of_element_located((By.XPATH, select_filter))
            ).is_displayed()

            if filters_options_present:
                return True
        except:
            LOGGER.info("No option are selected so selected tab is not present")
            return False

    def validate_the_dynamic_filter_pop_up(self):
        """check for the dynamic filter pop up displayed
        on click on the dynamic filter in console page"""
        LOGGER.info(".......validating dynamic filter pop up is displayed ........")
        pop_up_display = self.driver.find_element(
            By.XPATH, 
            filter_locators.dynamic_filter_pop_up
        ).is_displayed()

        if pop_up_display:
            LOGGER.info("Dynamic filter pop is display")
            return True
        else:
            LOGGER.info("Dynamic filter pop up is not display")
            return False

    def get_text_of_priority_filter_option(self):
        """This method helps to get text of the filter"""
        filter : str = self.get_element_text_or_value(
            (By.XPATH, filter_locators.check_of_filter_option_present),
            timeout=5,
            message="failed to get text of priority option ",
        )
        LOGGER.info(f"{filter}  is selected")
        return filter

    def click_on_first_option_from_dynamic_filter_applied(self):
        """This method helps to click on the first option from the dynamic filter applied"""
        select_filter = filter_locators.click_on_first_option_in_filters
        self.click_on_element(
            (By.XPATH, select_filter),
            timeout=5,
            message="failed to click on first option from dynamic filter ",
        )

    def click_on_apply_filter_in_selected(self):

        """Click on the add filter option from the drop down of the dynamic filters"""
        LOGGER.info(".......clicking on apply filter .......... ")
        self.click_on_element(
            (By.XPATH, filter_locators.apply_filter),
            timeout=5,
            message="failed to click on apply button after selected",
        )

    def deselect_dynamic_filter(self):
        """click on the deselect dynamic filter option"""
        try:
            LOGGER.info(" clicking on_deselect dynamic filters")
            self.click_on_element(
                (By.CSS_SELECTOR, filter_locators.deselect_dynamic_filter),
                message=f"failed to clicked",
            )
            LOGGER.info(" deselected dynamic filters")
        except:
            LOGGER.info("No check box are selected ")

    def click_on_save_button(self):
        """Click on the  save button"""
        try:
            LOGGER.info("clicking on save button")
            self.click_on_element(
                (By.XPATH, filter_locators.save_button),
                timeout=5,
                message="failed to click on apply button after selected",
            )

        except:
            pass

    def validate_scope_filter_drop_down(self):
        """checks for the scope filter drop down  after clicking on scope filter tab"""
        try:
            time.sleep(1)
            scope_element = self.wait.until(
                EC.visibility_of_element_located(
                    (By.XPATH, filter_locators.scope_filters_drop_down)
                )
            ).is_displayed()

            if scope_element:
                LOGGER.info("Scope filter drop down is displayed")
                return True
        except:
            LOGGER.info("scope filter is not displayed ")
            return False

    def close_global_filter_dropdown(self):
        if self.validate_scope_filter_drop_down():
            LOGGER.info("Global Filter dropdown is active")
            self.click_on_element(
                (By.XPATH,filter_locators.global_filter),
                timeout=5,
                message="failed to click on apply button after selected",
            )

            LOGGER.info("Clicking on GLOBAL filter to close it")
        else:
            pass

    def select_global_filter_from_dropdown(self, filter_names):
        """select the filters based on the option given in the filter name in the console page"""
        time.sleep(1)
        LOGGER.info(f"click on {filter_names} name in global filter")
        filter_from_drop_down = filter_locators.filter_from_global_dropdown.replace(
            "eventName", filter_names
        )
        self.click_on_element(
            (By.XPATH, filter_from_drop_down),
            timeout=5,
            message="failed to click on apply button after selected",
        )


    def search_agents_in_global_filter(self, agent_name):
        """This method helps to search the agents name in the search box
        ---------------
        agent_name : name of the agents which need to be search"""

        self.pass_value_to_element(
            agent_name,
            (By.XPATH, filter_locators.search_global_filter),
            message="Failed to enter note text in case note editor",
        )
    def check_the_presence_of_agents_in_global_search(self):
        """This method helps to check agents or customer in global search"""
        try:
            time.sleep(10)
            search_agents_locator = self.wait.until(
                EC.visibility_of_element_located(
                    (By.XPATH, filter_locators.first_agents)
                )
            ).is_displayed()
            if search_agents_locator:
                LOGGER.info("search result is displayed")
                return True

        except:
            LOGGER.info("search agents is not displayed ")
            return False

    def select_check_box_from_agent_filter(self):
        """Click on the check box in agents filters"""
        check_agents = filter_locators.first_agents
        self.click_on_element(
            (By.XPATH, check_agents),
            timeout=5,
            message="failed to check the agents from the agents list",
        )

    def check_the_presence_of_tool_tip(self):
        try:
            tool_tip_status = self.wait.until(
                EC.element_to_be_clickable((By.XPATH, filter_locators.tool_tip_display))
            ).is_displayed()
            if tool_tip_status:
                LOGGER.info("Tool_tip is displayed")
                return True
        except:
            LOGGER.info("failed to display tip tool or value is not selected")
            return False
    def agents_name_in_agents_filter(self):
        """this method helps to get text of  the agents name
        --------------
        return
        agents_elements : return the agents name"""

        agents_name = filter_locators.first_agents
        agents_name_in_filter: str = self.get_element_text_or_value(
            (By.XPATH, agents_name),
            timeout=5,
            message="failed to get agents name in filter ",
        )

        LOGGER.info(f"agent name in filter is {agents_name_in_filter} ")
        return agents_name_in_filter

    def click_on_agents_filter_checkbox(self,agents_name):
        """Method waits for  the visibility of checkbox for agents filter and then clicks it"""

        LOGGER.info("click on agents filter check box in filters ")
        self.click_on_element(
            (By.XPATH, filter_locators.checkbox_agents_filter.replace("agents",agents_name)),
            timeout=5,
            message="failed to click on check box in agents filters",
        )
    def click_on_customer_filter_checkbox(self,customer_name):
        """Method waits for the visibility of the checkbox for customer filter and then clicks it"""
        LOGGER.info(f"clicking on {customer_name} ")
        self.click_on_element(
            (By.XPATH, filter_locators.checkbox_customer_filter.replace("customer",customer_name)),
            timeout=5,
            message="failed to click on check box in customer filters",
        )
    def click_on_quick_filter_to_expand_the_drop_down_list(self):
        """This code will click on the quick filter and expand it to see the available options"""
        LOGGER.info("clicking on quick filter in global filter")
        if not self.is_global_filter_expanded() and self.is_quick_filter_expanded():
            return
        self.click_on_element(
            (By.XPATH, filter_locators.quick_filter),
            message="Failed to expand Quick filter in global filter popup"
        )

    def click_on_close_icon_of_selected_tab_to_clear_selection_client(self):
        """This method when called will clear out all the selected option inside a filter"""
        self.click_on_element(
            (By.XPATH, filter_locators.selected_content_close_btn_client),
            timeout=15,
            message="failed to click on close icon in agents",
        )

    def click_on_close_icon_of_selected_tab_to_clear_selection_agents(self):
        """This method when called will clear out all the selected option inside a filter"""
        self.click_on_element(
            (By.XPATH,  filter_locators.selected_content_close_btn_agent),
            timeout=5,
            message="failed to click on close icon",
        )
    def check_if_agent_filter_is_applied(self,agents_name):
        """This method checks if the agents filter is already selected"""
        status = self.driver.find_element(
            By.XPATH, 
            filter_locators.checked_agent_btn.replace("agents",agents_name)
        ).get_attribute("data-status")
        return status

    def check_if_customer_filter_is_applied(self,customer_name):
        """This method checks if the customer filter is already selected"""
        c_status = self.driver.find_element(
            By.XPATH, 
            filter_locators.checked_client_btn
        ).get_attribute("data-status")
        return c_status

    def get_on_agents_name_in_filters(self):
        """This method helps to get the agents name from the filters drop down"""
        LOGGER.info(" get agents filter  name from the filters in the instance ")

        agents_name: str = self.get_element_text_or_value(
            (By.XPATH, filter_locators.agents_name_in_filters),
            timeout=5,
            message="failed to get agents name from filter",
        )

        LOGGER.info(f"agents  filter name is  {agents_name}")
        return agents_name

    def verify_customer_or_agents_is_selected_or_not(self):
        """This method verify the customer or agents is selected or not"""
        try:
            selected_case = self.driver.find_element(By.XPATH, filter_locators.selected_display).is_displayed()
            if selected_case:
                LOGGER.info(" selected tab is displayed")

                return True
        except:
            LOGGER.info(" selected tab is  not displayed")
            return False

    def get_text_of_selected_customer_and_agents(self):
        """This method helps to get the text how many agents or selected"""
        selected_agent_customer_name: str = self.get_element_text_or_value(
            (By.XPATH, filter_locators.selected_display),
            timeout=5,
            message="failed to get selected agent name and customer name",
        )
        return selected_agent_customer_name

    def get_on_customer_name_in_filters(self):
        """This method helps to get the customer name from the filters drop down"""
        LOGGER.info("Getting customer filter name  from the filters in this instance")

        customer_name: str = self.get_element_text_or_value(
            (By.XPATH, filter_locators.customer_name_in_filters),
            timeout=5,
            message="failed to get selected agent name and customer name",
        )
        LOGGER.info(f"customer filter name is {customer_name} ")
        return customer_name

    def check_the_presence_of_filter_options_in_pop_up(self):
        """This method check the presence of filter option in pop up"""
        try:
            LOGGER.info(".......checking for filter option is present on pop up")
            time.sleep(2)
            check_the_presence_of_option_in_filter = filter_locators.check_of_filter_option_present
            filters_options_present = self.wait.until(
                EC.visibility_of_element_located((By.XPATH, check_the_presence_of_option_in_filter))
            ).is_displayed()

            if filters_options_present:
                return True
        except:
            LOGGER.info("No option are selected so selected tab is not present")
            return False

    def click_on__apply_filter_in_agents_and_customer_search_pop_up(self):
        """Click on the apply filter in agents and customer filter search pop up"""
        LOGGER.info(".......clicking on apply filter .......... ")
        self.click_on_element(
            (By.XPATH, filter_locators.scope_apply_filter),
            timeout=5,
            message="failed to click on apply button",
        )

    def click_on_fav_tab_in_client_filter(self):
        """Click on fav tab in client filter"""
        LOGGER.info(".......clicking  fav tab in client filter  .......... ")
        self.click_on_element(
            (By.XPATH, filter_locators.fav_tab_in_customer_filter),
            message="failed to click on fav tab client filter ",
        )

    def get_number_of_fav_client_present_in_customer_filter(self):
        """this method helps to get number of fav client present in customer filter"""
        time.sleep(2)
        LOGGER.info("This method helps to check number client in fav tab")
        get_number_fav_client = self.driver.find_elements(By.XPATH, filter_locators.
                                        client_name_in_fav_tab_in_customer_filter   )
        return get_number_fav_client


    def click_on_user_menu_icon(self):
        """This method helps to click on qa account button and preference tab"""
        LOGGER.info(".......clicking  qa account button  .......... ")
        self.click_on_element(
            (By.XPATH, filter_locators.qa_account),
            message="failed to click on  qa account button ",
        )

        self.click_on_element(
            (By.XPATH, filter_locators.preferences_tab),
            message="failed to click preference tab ",
        )

    def get_number_of_fav_client_present_in_preference_tab(self):

        """this method helps to get number of fav client present in customer filter"""
        time.sleep(2)
        get_number_fav_client = self.driver.find_elements(By.XPATH, filter_locators.
                                                fav_client_in_preferences_tab   )
        return get_number_fav_client

    def select_first_client_in_fav_client_filter(self):
        """This helps to select first client in fav client filter tab"""
        LOGGER.info(".......selecting first client from client filter .......... ")
        self.click_on_element(
            (By.XPATH, filter_locators.client_name_in_fav_tab_in_customer_filter),
            message="failed to client on in fav client filter  ",
        )

    def check_for_first_client_in_fav_client_filter_is_selected(self):
        """This method to check for first client in fav client filter is selected or not"""
        LOGGER.info(".......check for is selected first client from client filter .......... ")
        check_box_status = self.driver.find_element(
            By.XPATH, 
            filter_locators.first_client_in_client_filter_fav
        ).get_attribute("data-status")
        return check_box_status

    def click_on_close_icon_in_case_feild_to_deselected_field(self):
        """This method helps click on close icon """
        LOGGER.info("........Click on close icon to deselected the case field........")

        self.click_on_element(
            (By.XPATH, filter_locators.deselect_dynamic_filter_applied),
            message="failed to click on deselect button in case field")

    def click_on_apply_scope_button_in_case_field(self):
        """This method helps click on apply scope button """
        LOGGER.info("........Click on apply scope button in case field........")

        self.click_on_element(
            (By.XPATH, filter_locators.apply_scope_in_case_field),
            message="failed to click apply scope button" )

    def click_on_age_section_select_all_button_in_case_field(self):
        """This method helps click on age section select all button in case field """
        LOGGER.info("........click on age section select all button in case field.......")
        self.click_on_element(
            (By.XPATH, filter_locators.click_on_select_all_button_in_age),
            message="failed to click on age section select all button in case field")

    def click_on_case_filed_name_in_case_field(self,case_field):
        """This method helps click on age section in case  """
        LOGGER.info("........click on age section button  in case field........")
        self.click_on_element(
            (By.XPATH, filter_locators.click_on_case_field.replace("text_placehoder",case_field)),
            message="failed to click on age section button  in case field")

    def check_for_on_age_section_is_expanded_or_not(self):
        """This method helps  check whether age section is expanded or not """
        LOGGER.info("........check for age section is expanded or not........")
        age_expanded=self.is_element_visible(
            (By.XPATH, filter_locators.to_check_age_is_expand))
        if age_expanded:
            return True
        else:
            return False

    def click_on_reset_all_button_in_case_field(self):
        """Click on the reset all  button in case_field"""
        LOGGER.info("........click on reset all button  in case field........")
        self.click_on_element(
            (By.XPATH, filter_locators.reset_all_button),
            message="click_on_rest_all_button",
        )
    def click_on_close_icon_in_preference_pop_up (self):
        """This method helps click on close icon """
        LOGGER.info("........Click on close icon to in preference pop up........")

        self.click_on_element(
            (By.XPATH, filter_locators.close_icon_in_preference ),
            message="failed to click on close button in preference icon")


    def remove_dynamic_filter_if_applied(self):
        dynamic_filter_applied = self.get_count_of_number_of_dynamic_filter()
        LOGGER.info(len(dynamic_filter_applied))
        for i in dynamic_filter_applied:
            self.click_on_selected_dynamic_filter()
            filter_options = self.check_the_presence_of_selected_tab()
            if filter_options:
                self.click_on_deselect_button_in_dynamic_filter_option_applied()
                self.click_on_apply_filter_in_selected()

        self.click_on_dynamic_filter()
        self.deselect_dynamic_filter()
        self.click_on_save_button()
        time.sleep(2)
        self.driver.refresh()

    def get_on_case_filed_name_in_filters(self):
        """This method helps to get the case filed from the filters drop down"""
        LOGGER.info("Getting case field name  from the filters in this instance")

        case_field: str = self.get_element_text_or_value(
            (By.XPATH, filter_locators.case_field_name_in_filters),
            timeout=5,
            message="failed to get selected case field name",
        )
        LOGGER.info(f"case field name is {case_field} ")
        return case_field


