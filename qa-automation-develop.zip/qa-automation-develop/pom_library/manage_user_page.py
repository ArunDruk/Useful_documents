"""This module is  focuses on  creating reusable method the manage user   """

import logging
import time

from locators import manage_user_locator as mul
from pom_library.helper_methods import HelperMethods
from selenium.webdriver.common.by import By
LOGGER = logging.getLogger(__name__)



class ManageUser(HelperMethods):
    """
    This Page has all the actions which can be verified and performed in the manage user page and which directly affects
    the other modules of the dashboard.
    """

    # declaring the driver to use it in overall page
    def __init__(self, driver):
        super().__init__(driver)



    def search_for_user_in_search_box(self,user_name):
        """This method helps to search for user in search box in manage user page  """
        LOGGER.info("searching of user name in search test box ..........")

        self.pass_value_to_element(
            user_name,
            (By.XPATH, mul.search_user_textbox_in_manage_user_page_xpath),
              message="search the user name in search box")


    def check_for_toggle_is_on_or_off(self):

        """This method helps to checks for toggle is on or off"""
        try:
            LOGGER.info("Checking for toggle is on or ff")
            case_review=self.driver.find_element(By.XPATH, mul.case_review_toggle_on_xpath).is_displayed()
            if case_review:
                LOGGER.info(" case review toggle is on")
                return True
        except:
            LOGGER.info("case review toggle is off")
            return False

    def click_on_toggle_to_off_state(self):
        """ This  method  helps  to toggle to on state """

        self.javascript_click_on_element((By.XPATH, mul.click_on_forward_arrow),
                                         message="failed to off the toggle button "
                                         )
        time.sleep(1)
        self.javascript_click_on_element((By.XPATH,mul.case_review_toggle_on_xpath),
                              message="failed to on the toggle button "
                              )

    def click_on_tabs_in_manage_user(self,tab):
        """This method helps to click on manage user page"""

        LOGGER.info(f"checking on {tab} in manage user page")
        self.click_on_element((By.XPATH, mul.tab_on_manage_user.replace("tab",tab.value)),
                                         message=f"failed to click  on {tab} ")

    def click_on_toggle_to_on_state(self):
        """ This  method  helps  to toggle to on state """

        self.javascript_click_on_element((By.XPATH,mul.case_review_toggle_off_xpath),
                              message="failed to off the toggle button "
                              )

    def case_review_on_and_off_toggle(self):

        self.click_on_toggle_to_off_state()
        time.sleep(1)
        toggle_status_should_on = self.check_for_toggle_is_on_or_off()
        assert toggle_status_should_on is False, "failed to on the case review toggle"
        self.click_on_toggle_to_on_state()
        time.sleep(1)
        toggle_status_should_on = self.check_for_toggle_is_on_or_off()
        return toggle_status_should_on

