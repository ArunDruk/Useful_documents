"""This module is  focuses on  creating reusable method the Customer board page  """
__author__ = "Neha Jha"
__copyright__ = "Copyright (C) 2021 SupportLogic"

import logging
import time
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait
import utils
import constants
from locators import customer_board_locator
from pom_library.pom_base import PomBase
from pom_library.helper_methods import HelperMethods
LOGGER = logging.getLogger(__name__)


class CustomerBoardPage(HelperMethods):
    """
    This class has all the actions that can be done in customer board  page
    """

    # declaring the driver to use it in overall page
    def __init__(self, driver):
        self.driver = driver
        PomBase.__init__(self, self.driver)
        self.actions = ActionChains(driver)
        self.wait = WebDriverWait(driver, 60)

    def check_list_present_customer_board(self):
        """ This method helps to check if list is present in the customer board list"""

        list_present_dashboard = self.wait.until(
            EC.visibility_of_element_located((By.XPATH, customer_board_locator.customer_list))
        ).is_displayed()
        if list_present_dashboard:
            LOGGER.info("list is displayed on customer board dashboard")
            return True
        else:
            LOGGER.info("list is displayed on customer board dashboard")
            return False

    def click_vertical_dots_list(self):
        """This method helps to click on the vertical  dots on the list"""

        self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, customer_board_locator.vertical_dots_on_list)
            )
        ).click()

    def click_on_download_csv(self):
        """This method helps to click on the download csv option in vertical dots menu"""

        download_csv = self.wait.until(
            EC.element_to_be_clickable((By.XPATH, customer_board_locator.download_csv))
        )
        self.driver.execute_script("arguments[0].click();", download_csv)

    def click_on_delete_list(self):
        """This method helps to click on the delete list option in vertical dots menu"""

        delete_list = self.wait.until(
            EC.element_to_be_clickable((By.XPATH, customer_board_locator.delete_list))
        )
        self.driver.execute_script("arguments[0].click();", delete_list)

    def click_on_edit_list(self):
        """This method helps to click on the edit  list option in vertical dots menu"""

        edit_list = self.wait.until(
            EC.element_to_be_clickable((By.XPATH, customer_board_locator.edit_list))
        )
        self.driver.execute_script("arguments[0].click();", edit_list)

    def click_plus_button(self):
        """This method helps to click on  + button to create a new list"""

        self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, customer_board_locator.create_new_list)
            )
        ).click()

    def click_on_add_button(self):
        """This method helps to click on  add button in the pop up"""
        LOGGER.info("clicking on add button")
        self.wait.until(
            EC.element_to_be_clickable((By.XPATH, customer_board_locator.add_button))
        ).click()

    def click_on_expand_button(self):
        """This method helps to click on  expand button to  expand list """

        self.wait.until(
            EC.element_to_be_clickable((By.XPATH, customer_board_locator.expand_list))
        ).click()

    def get_number_of_list_present_on_dashboard(self):
        """This method helps to get the text of number of list present on the dash board"""
        list_present_on_dashboard = self.driver.find_elements(
            By.XPATH, customer_board_locator.list_present_on_dashboard
        )
        no_of_list = len(list_present_on_dashboard)
        LOGGER.info(f"list present on the dash board {no_of_list}")
        return no_of_list

    def click_delete_button_on_delete_pop_up(self):
        """This method helps to click on delete button on the pop up of the list"""
        self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, customer_board_locator.delete_on_delete_pop_up)
            )
        ).click()

    def check_present_choose_list_pop_up(self):
        """ This method helps to check present of choose list pop up displayed on click on plus button """

        list_present_dashboard = self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, customer_board_locator.choose_list_pop_up)
            )
        ).is_displayed()
        if list_present_dashboard:
            LOGGER.info(
                " Choose the lists you’d like to add to your board is displayed  "
            )
            return True
        else:
            LOGGER.info(
                "Choose the lists you’d like to add to your board is not  displayed "
            )
            return False

    def click_likely_to_be_escalated(self):
        """This method helps to click on likely to be escalated on the choose list pop up displayed """
        self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, customer_board_locator.likely_to_be_escalated_cases)
            )
        ).click()

    def click_on_customer_field(self):
        """This method helps to click on the customer field"""
        self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, customer_board_locator.customer_field)
            )
        ).click()

    def check_present_filter_by_list_pop_up(self):
        """ This method helps to check present of filter by list pop up is displayed """

        list_present_dashboard = self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, customer_board_locator.choose_list_pop_up)
            )
        ).is_displayed()
        if list_present_dashboard:
            LOGGER.info("filter by pop is displayed")
            return True
        else:
            LOGGER.info("filter by pop up is not displayed")
            return False

    def check_present_drop_down_on_click_vertical_dots(self):
        """ This method helps to check present of drop down on clicking vertical dots """

        list_present_dashboard = self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, customer_board_locator.vertical_dots_list)
            )
        ).is_displayed()
        if list_present_dashboard:
            LOGGER.info(
                " drop down menu is displayed on click the verticals dots is displayed  "
            )
            return True
        else:
            LOGGER.info(
                "drop down menu is displayed on click the verticals dots is not displayed "
            )
            return False

    def click_on_creation_date(self):
        """This method helps to click on creation data on the filter"""
        self.wait.until(
            EC.element_to_be_clickable((By.XPATH, customer_board_locator.creation_date))
        ).click()

    def click_on_one_year_option_in_creation_data(self):
        """This method helps to click on one year option in creation list"""
        self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, customer_board_locator.one_year_option)
            )
        ).click()

    def click_on_apply_changes(self):
        """This method helps to click on apply changes button"""
        self.wait.until(
            EC.element_to_be_clickable((By.XPATH, customer_board_locator.apply_changes))
        ).click()

    def click_on_filter(self):
        """This method helps to click on filter button"""
        self.wait.until(
            EC.element_to_be_clickable((By.XPATH, customer_board_locator.filter_button))
        ).click()

    def check_present_single_list(self):
        """ This method helps to check present of list pop up displayed on click on expand  button """

        list_present_dashboard = self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, customer_board_locator.choose_list_pop_up)
            )
        ).is_displayed()
        if list_present_dashboard:
            LOGGER.info(" single list is displayed on dashboard  ")
            return True
        else:
            LOGGER.info("single list is not displayed on dashboard ")
            return False

    def click_on_switch_sort_direction(self):
        """This method helps to click on switch sort direction"""
        switch_direction = self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, customer_board_locator.switch_sort_direction)
            )
        )
        self.driver.execute_script("arguments[0].click();", switch_direction)

    def get_number_cases_present_on_customer_board_list(self):
        """This method helps to get total cases present """
        LOGGER.info("Get number of cases present ............")
        total_cases = self.get_element_text_or_value(
                (By.XPATH, customer_board_locator.total_cases),
                timeout=15,
                message="case count present on dashboard ",
            )

        cases_count = total_cases.split()
        count = cases_count[0]
        LOGGER.info(f"cases are {count} ")
        return count

    def click_on_cross_button(self):
        """This method helps to click on switch sort direction"""
        cross_button = self.wait.until(
            EC.element_to_be_clickable((By.XPATH, customer_board_locator.cross_button))
        )
        self.driver.execute_script("arguments[0].click();", cross_button)

    def click_on_add_note_icon(self):
        """This method helps to click on add note icon"""
        self.wait.until(
            EC.element_to_be_clickable((By.XPATH, customer_board_locator.add_note_icon))
        ).click()

    def click_on_add_a_note(self):
        """This method helps to click on add note  to added a notes """
        try:
            add_note_icon = self.wait.until(
                EC.element_to_be_clickable(
                    (By.XPATH, customer_board_locator.add_a_notes)
                )
            )
            self.driver.execute_script("arguments[0].click();", add_note_icon)
        except:
            add_note_icon = self.wait.until(
                EC.element_to_be_clickable(
                    (By.XPATH, customer_board_locator.add_new_notes)
                )
            )
            self.driver.execute_script("arguments[0].click();", add_note_icon)

    def add_text_in_notes(self, notes):
        """This method helps to text in the notes text box
        -----------
        Parameters
        notes =  text to be added in notes
        """

        text = self.wait.until(
            EC.element_to_be_clickable((By.XPATH, customer_board_locator.add_notes))
        )
        text.send_keys(notes)

    def check_the_client_present_in_list(self):
        try:
            """This method helps to check the client present  in the first list"""
            client_present_list = self.wait.until(
                EC.element_to_be_clickable(
                    (By.XPATH, customer_board_locator.first_list_first_client)
                )
            ).is_displayed()
            if client_present_list:
                LOGGER.info(" client present in the list  ")
                return True

        except:
            LOGGER.info("No client present in list")
            return False

    def click_on_edit_icon_in_notes(self):
        """This method helps to click on edit icon in notes"""
        mouse_hover = self.wait.until(
            EC.element_to_be_clickable((By.XPATH, customer_board_locator.notes_title))
        )
        self.actions.move_to_element(mouse_hover).perform()
        edit_icon = self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, customer_board_locator.edit_icon_notes)
            )
        )
        self.actions.move_to_element(edit_icon).click().perform()

    def click_on_delete_icon_in_notes(self):
        """This method helps to click on delete icon in notes"""
        mouse_hover = self.wait.until(
            EC.element_to_be_clickable((By.XPATH, customer_board_locator.notes_title))
        )
        self.actions.move_to_element(mouse_hover).perform()

        delete_icon = self.wait.until(
            EC.element_to_be_clickable((By.XPATH, customer_board_locator.delete_icon))
        )
        self.actions.move_to_element(delete_icon).click().perform()

    def click_on_save_button_in_notes(self):
        """This method helps to click on save button in notes pop up"""
        save_button = self.wait.until(
            EC.element_to_be_clickable((By.XPATH, customer_board_locator.save_button))
        )
        self.driver.execute_script("arguments[0].click();", save_button)

    def click_on_production_issue(self):
        """This method helps to click  on  client with production issue """
        self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, customer_board_locator.client_with_production_issue)
            )
        ).click()

    def click_on_time_period(self):
        """This method helps on click on time period while creating list"""
        self.wait.until(
            EC.element_to_be_clickable((By.XPATH, customer_board_locator.time_period))
        ).click()

    def click_on_client_showing_time_in_list(self):
        """This method helps on click on showing time in list """
        self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, customer_board_locator.time_period_in_list)
            )
        ).click()

    def get_list_name(self):
        """This method helps to get the list name present on the dash board  """
        list_name = self.wait.until(
            EC.element_to_be_clickable((By.XPATH, customer_board_locator.list_name))
        ).text
        LOGGER.info(f"heading of list is {list_name}")
        return list_name

    def get_number_of_notes_present(self):
        """This method helps to get the number of notes present in the notes pop up """
        try:
            add_new_notes = self.wait.until(
                EC.element_to_be_clickable(
                    (By.XPATH, customer_board_locator.add_a_notes)
                )
            ).is_displayed()
            if add_new_notes:
                add_notes = self.wait.until(
                    EC.element_to_be_clickable(
                        (By.XPATH, customer_board_locator.notes_list)
                    )
                ).is_displayed()
                if add_notes:
                    notes_present_for_particular_client = self.driver.find_elements(
                        By.XPATH, customer_board_locator.notes_list
                    )
                    no_of_notes = len(notes_present_for_particular_client)
                    LOGGER.info(f"No of notes present is {no_of_notes}")
                    return no_of_notes
                else:
                    return 0

        except:
            notes_present_for_particular_client = self.driver.find_elements(
                By.XPATH, customer_board_locator.notes_list
            )
            no_of_notes = len(notes_present_for_particular_client)
            LOGGER.info(f"Number  of notes present  is {no_of_notes}")
            return no_of_notes

    def click_on_last_six_month_option_in_time_period_menu(self):
        """This method helps on click on last six month option from the time period drop down"""

        last_six_month = self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, customer_board_locator.last_six_month_option)
            )
        )
        self.driver.execute_script("arguments[0].click();", last_six_month)

    def click_on_all_time_in_time_period_menu(self):
        """This method helps on click on all time option from the time period drop down"""
        all_time = self.wait.until(
            EC.element_to_be_clickable((By.XPATH, customer_board_locator.all_time))
        )
        self.driver.execute_script("arguments[0].click();", all_time)

    def click_on_client_present_in_list(self):
        """This method helps to click on client present  in the list"""
        self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, customer_board_locator.first_client_list)
            )
        ).click()

    def get_text_first_client_name_in_list(self):
        """This method helps to get the text of the client name which present first on the list"""
        client_name = self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, customer_board_locator.first_client_list)
            )
        ).text
        split_name_of_client  =client_name.split("\n")
        client_name_in_list = split_name_of_client[0]
        LOGGER.info(f"first client name  on the list is  {client_name_in_list}")
        return client_name_in_list



    def click_on_client_ranked_by_case_volume(self):
        """This method helps to click  on  client ranked by ticket volume"""
        self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, customer_board_locator.ranked_by_case_volume)
            )
        ).click()

    def get_text_showing_time_in_list(self):
        """This method helps to get the text of time period option"""
        time_period = self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, customer_board_locator.time_period_in_list)
            )
        ).text
        LOGGER.info(f"showing time in list is  {time_period}")
        return time_period

    def get_likely_to_be_escalated_cases_count_in_profile(self):
        """ This method helps to get the likely to be escalated case count"""

        cases = self.get_element_text_or_value(
            (By.XPATH,  customer_board_locator.likely_to_be_escalated_in_profile), timeout=30,
            message=" failed to get the case count",
        )
        LOGGER.info(f" likely to be escalated cases  are {cases}")
        return cases

    def click_on_cross_button_notes(self):
        """This method helps to click  on  client ranked by ticket volume"""
        self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, customer_board_locator.cross_button_notes)
            )
        ).click()

    def edit_text_in_notes(self, edit_notes):
        """This method helps to  add text in the notes text box to edit notes
        -----------
        Parameters
        notes =  text to be added in notes
        """

        text = self.wait.until(
            EC.element_to_be_clickable((By.XPATH, customer_board_locator.edit_notes))
        )
        text.send_keys(edit_notes)

    def get_notes_title(self):
        """This method helps to get the notes name present on the notes """
        notes_title = self.wait.until(
            EC.element_to_be_clickable((By.XPATH, customer_board_locator.notes_title))
        ).text
        LOGGER.info(f"note title is {notes_title}")
        return notes_title



    def check_if_add_notes_pop_up(self):
        try:
            add_note_pop_up = self.wait.until(
                EC.visibility_of_element_located((By.XPATH, customer_board_locator.add_note_pop_up))
            ).is_displayed()
            if add_note_pop_up:
                LOGGER.info(" add note pop up is displayed ")
                return True

        except:
            LOGGER.info("add note pop up is not displayed")
            return False

    def create_list_name(self,name):
        text = self.wait.until(
            EC.element_to_be_clickable((By.XPATH, customer_board_locator.creating_list_name)
        ))

        text.send_keys(name)

    def delete_list(self):
        """This method helps to get the text of number of list present on the dash board"""
        number_of_list=self.get_number_of_list_present_on_dashboard()

        for i in range(number_of_list):
            list_present_on_dashboard = self.driver.find_element(
                By.XPATH, customer_board_locator.list_name_number_list_present_on_dashboard
            ).text
            if "QA_CB" in list_present_on_dashboard:
                self.click_vertical_dots_list()
                drop_down_menu = self.check_present_drop_down_on_click_vertical_dots()
                assert drop_down_menu, "failed to display drop down menu"
                self.click_on_delete_list()
                self.click_delete_button_on_delete_pop_up()

    def create_new_list_using_Likely_to_be_Escalated(self):

        list_present_on_dashboard_before_creating_new_list = (
            self.get_number_of_list_present_on_dashboard()
        )
        self.click_plus_button()
        choose_list_you_like_add_pop_up = self.check_present_choose_list_pop_up()
        assert (
            choose_list_you_like_add_pop_up
        ), "choose list you like to add pop up is failed to displayed "
        self.click_likely_to_be_escalated()

        list_name_CB = utils.generate_test_run_id(constants.CUSTOMER_BOARD_RUN_ID_PREFIX)
        self.create_list_name(list_name_CB)
        self.click_on_add_button()
        list_present_on_dashboard_after_creating_new_list = (
            self.get_number_of_list_present_on_dashboard()
        )
        list_present_on_dashboard = (
                list_present_on_dashboard_before_creating_new_list + 1
        )
        assert (
                list_present_on_dashboard
                == list_present_on_dashboard_after_creating_new_list
        ), "failed to create list in customer board"

    def check_presence_of_welcome_page(self):
        """This method helps to check for the presence of welcome page"""
        try :
            welcome_page =  self.wait.until(
                EC.visibility_of_element_located((By.XPATH, customer_board_locator.standard_list))
            ).is_displayed()
            if welcome_page :
                self.wait.until(
                    EC.element_to_be_clickable((By.XPATH, customer_board_locator.standard_list))
                ).click()
        except:
            pass



    def click_on_cancel_button(self):
        """This helps to click on cancel button in add your list pop up buttn"""
        LOGGER.info(".......clicking on cancel button .......... ")
        self.click_on_element(
            (By.XPATH, customer_board_locator.cancel_button),
            message="failed to client on in fav client filter  ",
        )

    def get_name_of_first_list_on_dashboard(self):
        """This method helps to get name for first list"""
        return self.get_element_text_or_value(
            (By.XPATH, customer_board_locator.list_name_number_list_present_on_dashboard),
            message="failed to get name for first list on the dash board",

        ).strip()

    def click_ranked_by_health_assessment(self):
        """This method helps to click on likely to be escalated on the choose list pop up displayed """

        LOGGER.info(".......clicking on ranked  health assessment .......... ")
        self.mouse_click_on_element(
            (By.XPATH, customer_board_locator.ranked_by_health_assessment),
            message="failed to click on health assessment button ",
        )



    def click_on_health_assessment(self):
        """This method helps to click on health assessment"""
        LOGGER.info(".......clicking on health assessment .......... ")
        self.click_on_element(
            (By.XPATH, customer_board_locator.health_assessment),
            message="failed to click on health assessment button ",
        )

    def select_the_health_assessment_filter_by_pop_up(self,value):
        """This method helps to click on health assessment"""
        LOGGER.info(".......clicking on health assessment .......... ")
        self.click_on_element(
            (By.XPATH, customer_board_locator.health_assessment_mark.replace("text_place_holder",value)))



    def get_name_first_customer_name_in_list(self):

        global_name=self.get_element_text_or_value(
            (By.XPATH, customer_board_locator.customer_name_in_customer_list)
        )
        return global_name



    def check_cases_is_present_on_first_list(self):
        cases = self.is_element_visible((By.XPATH, customer_board_locator.customer_name_in_customer_list))
        if cases:
            good_customer_name = self.get_element_text_or_value(
                (By.XPATH, customer_board_locator.customer_name_in_customer_list)
            )

            return good_customer_name

        else:
            return False

           

    def click_on_create_custom_list_on_start_page(self):
        """This method helps to click on create custom list"""
        self.click_on_element(
            (By.XPATH, customer_board_locator.custom_list ),
            message="failed to click on create custom list ",
        )

    def click_on_standard_list_on_start_page(self):
        """This method helps to click on standard list"""
        self.click_on_element(
            (By.XPATH, customer_board_locator.standard_list),
            message="failed to click on standard list",
        )


