"""This module is  focuses on  creating reusable method the CaseEvaluation Page """
__author__ = "Neha Jha"
__copyright__ = "Copyright (C) 2021 SupportLogic"

import logging

import time
from selenium.webdriver.common.action_chains import ActionChains
from locators import ace_locator as ace, customer_board_locator
from pom_library.helper_methods import HelperMethods
from selenium.common.exceptions import TimeoutException as TOE
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

LOGGER = logging.getLogger(__name__)


class CaseEvaluation(HelperMethods):
    """
    This class has all the actions that can be done in alerts page

    """

    # declaring the driver to use it in overall page
    def __init__(self, driver):
        super().__init__(driver)
        self.actions = ActionChains(driver)
        self.wait = WebDriverWait(driver, 120)

    def click_add_note_icon(self):
        """This method helps to click on add note icon """

        self.click_on_element(
            (By.XPATH, ace.add_note_icon),
            timeout=5,
        )
        LOGGER.info(f"about to click on the add note icon ")

    def get_id_of_first_case(self):
        """This method helps to get the id of the first case which is present on the left  """
        try:
            case_id = self.wait.until(
                EC.visibility_of_element_located(
                    (By.XPATH, ace.id_of_first_case_in_list)
                )
            ).text
            LOGGER.info(f"{case_id} present on the first case ")

            return case_id
        except:
            LOGGER.info(
                "Oops, we couldn’t find that case Please check the case number!"
            )
            return False

    def search_id_in_search_bar(self, case_id):
        """this method helps to pass the case id on the search bar"""
        self.pass_value_to_element(
            (case_id),
            (By.XPATH, ace.search_bar),
            message="Failed to enter text in search bar",
        )
        LOGGER.info("about to search the case id on the search bar")

    def click_on_edit_icon_in_notes(self):
        """This method helps to click on edit icon in notes"""
        mouse_hover = self.wait.until(
            EC.element_to_be_clickable((By.XPATH, customer_board_locator.notes_title))
        )
        self.actions.move_to_element(mouse_hover).perform()
        edit_icon = self.wait.until(
            EC.element_to_be_clickable((By.XPATH, ace.edit_icon_notes))
        )
        self.actions.move_to_element(edit_icon).click().perform()

    def click_on_first_interaction_in_list(self):
        """this method helps to click on the first interaction"""
        self.click_on_element(
            (By.XPATH, ace.first_interaction_in_list),
            timeout=5,
            message="failed to click on first interaction  ",
        )

    def click_on_first_interaction_sub_items(self):
        """This method helps to click on the first interaction sub interaction"""
        self.click_on_element(
            (By.XPATH, ace.first_interaction_first_sub_item),
            timeout=5,
            message="failed to click on first interaction sub items ",
        )

    def get_text_first_interaction_sub_item(self):
        """This method helps to get interaction of the first interaction"""
        filters_interaction_sub_items = self.get_element_text_or_value(
            (By.XPATH, ace.first_interaction_first_sub_item)
        )
        return filters_interaction_sub_items

    def hover_over_first_interaction_in_green(self):
        interaction = self.driver.find_element(By.XPATH, ace.interaction_in_green)

        self.actions.move_to_element(interaction).perform()

    def get_text_of_first_interaction_text(self):
        current_slide = self.driver.find_element(
            By.XPATH,
            ace.interaction_in_green
        ).get_attribute("data-interaction")
        return current_slide

    def click_on_disagree_with_label(self):
        self.click_on_element(
            (By.XPATH, ace.disagree_with_label),
            timeout=5,
            message="failed to click on first interaction  ",
        )

    def hover_over_note_icon(self):
        interaction = self.driver.find_element(By.XPATH, ace.add_note_icon)

        self.actions.move_to_element(interaction).perform()

    def check_for_the_interaction_underline_in_green(self, interaction_text):
        time.sleep(2)
        interaction = ace.interaction_underline_in_green.replace(
            "TEXT_PLACEHOLDER", interaction_text
        )
        interaction_data = self.wait.until(
            EC.visibility_of_element_located(
                (By.XPATH,interaction)
            )
        ).is_displayed()
        if interaction_data:
            return True
        else:
            return False

    def hover_over_interaction_which_underline(self, interaction_text):
        interaction = ace.interaction_underline_in_green.replace(
            "TEXT_PLACEHOLDER", interaction_text
        )
        interaction_data = self.wait.until(
            EC.visibility_of_element_located((By.XPATH, interaction))
        )
        self.actions.move_to_element(interaction_data).perform()

    def disagree_and_remove_feedback_pop_up(self):
        try:
            unassigned_cases = self.wait.until(
                EC.visibility_of_element_located(
                    (By.XPATH, ace.interaction_disagree_and_remove_feedback_pop_up)
                )
            ).is_displayed()
            if unassigned_cases:
                return True

        except:
            return False

    def check_for_the_interaction_in_green_color(self, interaction_text):
        time.sleep(2)
        interaction = ace.interaction_green_color.replace(
            "TEXT_PLACEHOLDER", interaction_text
        )
        interaction_data = self.wait.until(
            EC.visibility_of_element_located((By.XPATH, interaction))
        ).is_displayed()
        if interaction_data:
            return True
        else:
            return False

    def click_on_undo_button(self):
        self.click_on_element(
            (By.XPATH, ace.undo_button),
            timeout=15,
            message="failed to click on first interaction  ",
        )

    def click_on_csv_recently_viewed(self):
        """This method helps to click CSv recently view  """

        LOGGER.info(f"Clicking on recommended view calendar ")
        self.click_on_element(
            (By.XPATH, ace.csv_in_recently_reviewed),
            timeout=30,
            message="failed to click on CSV of recently viewed",
        )

    def get_number_case_present_in_recently_review(self):
        """This method helps to get number os case present on recently review"""
        recently_review = self.get_element_text_or_value(
            (By.XPATH, ace.recently_review_cases)
        )
        return recently_review

    def click_on_case_list(self):
        """This method helps to click on first case list in recommended for review"""
        self.click_on_element(
            (By.XPATH, ace.recommended_for_review_case_list),
            timeout=30,
            message="failed to click on first case list in recommended for review",
        )

    def get_number_case_present_in_recommended_view(self):
        """This method helps to get number os case present on recommended review"""
        number_of_case_in_recommended_view = self.get_element_text_or_value(
            (By.XPATH, ace.recommended_for_review_case)
        )
        return number_of_case_in_recommended_view

    def click_on_group_by_filter_in_recently_reviewed(self):
        """This method helps to recently reviewed """
        self.click_on_element(
            (By.XPATH, ace.group_by_filter_in_recently_reviewed),
            timeout=5,
            message="failed to click on filter in recently reviewed",
        )

    def get_text_of_filter_applied_on_recently_reviewed(self):
        """This method helps  get text filter applied on recently reviewed"""
        option_applied = self.get_element_text_or_value(
            (By.XPATH, ace.group_by_filter_in_recently_reviewed)
        )
        return option_applied

    def click_on_agents_option_in_group_by_filter(self):
        """This  method helps to click on  agents option in group """
        self.click_on_element(
            (By.XPATH, ace.agent_option_in_group_by_filter_in_recently_review),
            timeout=5,
            message="failed to click on  option group by filter dropdown",
        )

    def click_on_time_option_in_group_by_filter(self):
        """ click on  time option in group filter"""
        self.click_on_element(
            (By.XPATH, ace.time_option_in_group_by_filter_in_recently_review),
            timeout=5,
            message="failed to click on time option on group filter""",

        )

    def get_first_agent_name_or_date_time_group_by(self):
        agent_name = self.get_element_text_or_value((By.XPATH,ace.agent_name_on_group_by))
        return agent_name

    def click_on_first_case_in_recently_reviewed(self):
        self.click_on_element(
            (By.XPATH, ace.first_case_in_recently_reviewed),
            timeout=5,
            message="failed to click on group by filter dropdown",

        )

    def open_or_close_tab(self):
        """This method helps to open or close tabs in ace page"""
        tabs = self.wait.until(
            EC.presence_of_all_elements_located((By.XPATH, ace.tab_names))
        )
        for tab in tabs:
            tab.click()
            LOGGER.info(f"{tab.text} tab clicked")
            time.sleep(2)

    def check_for_tab_is_expand_state(self):
        """This method helps to check that tab is in expand state"""
        tabs = self.driver.find_elements(By.XPATH, ace.case_list_container_in_view)
        tab_count = 0
        for i in tabs:
            if i.is_displayed():
                LOGGER.info(f"{i.text} tab opened")
                tab_count += 1
                return True
            else:
                return False

    def check_for_tab_is_in_collapse_view(self):
        """This method helps to check that tab is in collapse view"""
        tabs = self.driver.find_elements(
            By.XPATH, 
            ace.case_list_container_is_collapse_view
        )
        tab_count = 0
        for i in tabs:
            if i.is_displayed():
                LOGGER.info(f"{i.text} tab closed")
                tab_count += 1
                return True
            else:
                return False

    def click_edit_evaluation_criteria_icon(self):
        """This method helps to click the edit evaluation button """
        self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, ace.edit_evaluation_criteria)
            )
        ).click()

    def click_create_new_button(self):
        """This method helps to click Create new button """
        try:
            self.wait.until(
                EC.element_to_be_clickable(
                    (By.XPATH, ace.currenttab_createnew_button)
                    )
                ).click()
        except:
            pass
            LOGGER.info("Unable to find create new draft button")

    def draft_message_text(self):
        """This method helps to verify the draft text message """
        draft_text = self.is_element_visible(
            (By.XPATH, ace.draft_message),
            timeout=5,
        )
        if draft_text:
            return True
        else:
            return False

    def click_goto_draft(self):
        """This method helps to click the Goto draft button """
        self.click_on_element(
            (By.XPATH, ace.gotodraft_button),
            timeout=10,
            message="Unable to find the Goto button",
        )


    def click_on_agent_filter_tab_in_ace_page(self):
        self.mouse_click_on_element(
            (By.XPATH,
             ace.agent_filter_in_ace),
            message=" click on agent filter tab name",
        )

    def display_recent_draft(self):
        """This method helps to verify the display of the latest/recently created draft  """
        recent_draft = self.is_element_visible(
            (By.XPATH, ace.recentdraft),
            timeout=10,
        )
        if recent_draft:
            return True
        else:
            return False

    def click_recent_draft(self):
        """This method helps to click/select the latest/recently created draft  """
        self.click_on_element(
            (By.XPATH, ace.recentdraft),
            timeout=5)

    def click_edit_draft(self):
        """This method helps to click the edit evaluation button """
        self.click_on_element(
            (By.XPATH, ace.draftedit_button),
            timeout=5,
            message="Unable to find the Edit button in draft page"
        )

    def click_five_scale(self):
        """This method helps to click the five scale button"""
        try:
            self.click_on_element(
                    (By.XPATH, ace.fivescale),
                    timeout=5
                )
        except:
            pass
            LOGGER.info("5 scale button not enabled/clickable")


    def click_three_scale(self):
        """This method helps to click the three scale button"""
        try:
            self.click_on_element(
                    (By.XPATH, ace.threescale),
                    timeout=5
                )
        except:
            pass
            LOGGER.info("3 scale button not enabled/clickable")

    def click_newcategory(self):
        """This method helps to add new category  """
        self.click_on_element(
            (By.XPATH, ace.newcategory),
            timeout=5,
            message="Unable to find the new category button"
        )

    def category_placeholder(self):
        """This method helps to verify the placeholder of category """
        category_text = self.is_element_visible(
            (By.XPATH, ace.category_placeholder),
            timeout=5,
        )
        if category_text:
            return True
        else:
            return False

    def item_placeholder(self):
        """This method helps to verify the item placeholder message"""
        item_text = self.is_element_visible(
            (By.XPATH, ace.item_placeholder),
            timeout=5,
        )
        if item_text:
            return True
        else:
            return False

    def description_placeholder(self):
        """This method helps to verify the description placeholder message"""
        description_text = self.is_element_visible(
            (By.XPATH, ace.description_placeholder),
            timeout=5,
        )
        if description_text:
            return True
        else:
            return False

    def add_button_enabled(self):
        """This method helps to verify the add button is disabled"""
        add_button_state = self.is_element_enabled(
            (By.XPATH, ace.add_button),
            timeout=5,
        )
        if add_button_state:
            return True
        else:
            return False

    def click_finish_editing(self):
        """This method helps to click finish editing """
        self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, ace.finish_editing)
            )
        ).click()

    def publish_button_enabled(self):
        """This method helps to verify the publish button is disabled"""
        publish_button_state = self.is_element_enabled(
            (By.XPATH, ace.publish),
            timeout=5,
        )
        if publish_button_state:
            return True
        else:
            return False

    def enter_first_category_name(self,first_category_name):
        """this method helps to enter category name"""
        category_name = self.wait.until(
            EC.element_to_be_clickable((By.XPATH,ace.category_placeholder))
        )
        category_name.send_keys(first_category_name)

    def ace_checklist_header(self):
        """This method helps to verify the placeholder of category """
        category_text = self.is_element_visible(
            (By.XPATH, ace.checklist_header),
            timeout=5,
        )
        if category_text:
            return True
        else:
            return False

    def enter_item_name(self,item_name):
        """this method helps to enter category name"""
        category_name = self.wait.until(
            EC.element_to_be_clickable((By.XPATH,ace.item_placeholder))
        )
        category_name.send_keys(item_name)

    def enter_item_description(self, item_description):
        """this method helps to enter category name"""
        category_name = self.wait.until(
            EC.element_to_be_clickable((By.XPATH, ace.description_placeholder))
        )
        category_name.send_keys(item_description)

    def display_poor_rating(self):
        """This method helps to verify the display of the poor rating"""
        poor_rating = self.is_element_visible(
            (By.XPATH, ace.poor_rating),
            timeout=5,
        )
        if poor_rating:
            return True
        else:
            return False

    def display_bad_rating(self):
        """This method helps to verify the display of the poor rating"""
        bad_rating = self.is_element_visible(
            (By.XPATH, ace.bad_rating),
            timeout=5,
        )
        if bad_rating:
            return True
        else:
            return False

    def display_neutral_rating(self):
        """This method helps to verify the display of the poor rating"""
        neutral_rating = self.is_element_visible(
            (By.XPATH, ace.neutral_rating),
            timeout=5,
        )
        if neutral_rating:
            return True
        else:
            return False

    def display_good_rating(self):
        """This method helps to verify the display of the poor rating"""
        good_rating = self.is_element_visible(
            (By.XPATH, ace.good_rating),
            timeout=5,
        )
        if good_rating:
            return True
        else:
            return False

    def display_great_rating(self):
        """This method helps to verify the display of the poor rating"""
        great_rating = self.is_element_visible(
            (By.XPATH, ace.great_rating),
            timeout=5,
        )
        if great_rating:
            return True
        else:
            return False

    def click_add_button(self):
        """This method helps to click on add button"""
        self.click_on_element(
            (By.XPATH, ace.add_button),
            timeout=5,
            message="Unable to click on add button"
        )

    def click_publish_button(self):
        """This method helps to click on Publish button"""
        self.click_on_element(
            (By.XPATH, ace.publish),
            timeout=5,
            message="Unable to click on publish button"
        )

    def display_publish_message_first_line(self):
        """This method helps to verify the display of correct message in publish window"""
        first_line = self.is_element_visible(
            (By.XPATH, ace.publish_message_first_line),
            timeout=5,
        )
        if first_line:
            return True
        else:
            return False

    def display_publish_message_second_line(self):
        """This method helps to verify the display of correct message in publish window"""
        second_line = self.is_element_visible(
            (By.XPATH, ace.publish_message_second_line),
            timeout=5,
        )
        if second_line:
            return True
        else:
            return False

    def click_publish_ok(self):
        """This method helps to click PUBLISH button publish confirmation modal window"""
        self.click_on_element(
            (By.XPATH, ace.publish_ok),
            timeout=5,
            message="Unable to click on PUBLISH button publish confirmation modal window"
        )

    def click_publish_cancel(self):
        """This method helps to click CANCEL button publish confirmation modal window"""
        self.click_on_element(
            (By.XPATH, ace.publish_cancel),
            timeout=5,
            message="Unable to click on CANCEL button publish confirmation modal window"
        )

    def click_current_tab(self):
        """This method helps to navigate to current tab"""
        self.click_on_element(
            (By.XPATH, ace.current_tab),
            timeout=5,
            message="Unable to navigate to current tab"
        )

    def click_back_to_evaluation(self):
        """This method helps to click BACK TO EVALUATION button"""
        self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, ace.back_to_evaluation)
            )
        ).click()


    def click_first_case(self):
        """This method helps to click on first case under recommended column """
        self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, ace.first_case)
            )
        ).click()

    def click_new_sh(self):
        """This method helps to switch to support SH 3.0"""
        self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, ace.new_support_hub)
            )
        ).click()

    def display_new_sh_prompt(self):
        """This method helps to display of new support 3.0 prompt """
        new_sh = self.is_element_visible(
            (By.XPATH, ace.new_support_hub),
            timeout=10,
        )
        if new_sh:
            return True
        else:
            return False

    def click_start_review(self):
        """This method helps to click on START REVIEW button """
        self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, ace.start_review)
            )
        ).click()

    def display_publish_ok(self):
        """This method helps to verify the display of publish button in publish confirmation window"""
        publish_ok = self.is_element_visible(
            (By.XPATH, ace.publish_ok),
            timeout=10,
        )
        if publish_ok:
            return True
        else:
            return False

    def display_publish_cancel(self):
        """This method helps to verify the display of CANCEL button in publish confirmation window"""
        publish_cancel = self.is_element_visible(
            (By.XPATH, ace.publish_cancel),
            timeout=10,
        )
        if publish_cancel:
            return True
        else:
            return False

    def display_first_category(self):
        """This method helps to verify the display of first category in current tab"""
        first_category_name= self.is_element_visible(
            (By.XPATH, ace.first_category_name),
            timeout=10,
        )
        if first_category_name:
            return True
        else:
            return False

    def display_first_item_first_category(self):
        """This method helps to verify the display of first item under first category in current tab"""
        first_item_first_category= self.is_element_visible(
            (By.XPATH, ace.first_item_first_category),
            timeout=10,
        )
        if first_item_first_category:
            return True
        else:
            return False

    def display_first_description_first_item_first_category(self):
        """This method helps to verify the display of description of first item under first category in current tab"""
        first_description_first_item_first_category = self.is_element_visible(
            (By.XPATH, ace.first_description_first_item_first_category),
            timeout=10,
        )
        if first_description_first_item_first_category:
            return True
        else:
            return False

    def display_latest_draft(self):
        """This method helps to verify the display of the latest draft"""
        latest_draft = self.is_element_visible(
            (By.XPATH, ace.latest_draft),
            timeout=10,
        )
        if latest_draft:
            return True
        else:
            return False

    def select_latest_draft(self):
        """This method helps to select the latest draft"""
        self.click_on_element(
            (By.XPATH, ace.latest_draft),
            timeout=5,
            message="Unable to select the latest draft"
        )

    def click_delete_button_draft_page(self):
        """This method helps to delete the selected draft"""
        self.click_on_element(
            (By.XPATH,ace.draftdelete_button),
            timeout=5,
            message = "Unable to find/click Delete button"
        )

    def click_draft_tab(self):
        """This method helps to navigate to draft tab"""
        self.click_on_element(
            (By.XPATH, ace.draft_tab),
            timeout=5,
            message="Unable to navigate to draft tab"
        )
