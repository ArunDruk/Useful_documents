""" This test scenario focuses on checking the escalations page """
from __future__ import annotations

__author__ = "Sutapa Ganguly, Praveen Nagajothi"

import logging
import time
from typing import Optional, Union

from selenium.common.exceptions import (
    ElementNotVisibleException, StaleElementReferenceException,
)
from selenium.webdriver import ActionChains, Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait

import utils
from enums import (
    ActiveEscalationsSortOptions, EscalationRequestsSortOptions, EscalationState,
    LTESortOptions, ResolvedEscalationsSortOptions,
)
from locators import (
    escalations_management_locators,
    escalations_management_locators as eml, support_hub_locators as shl
)
from pom_library.api_keywords import ApiKeywords
from pom_library.helper_methods import HelperMethods

LOGGER: logging.Logger = logging.getLogger(__name__)


class EscalationsManagementPage(HelperMethods, ApiKeywords):
    def traverse_to_escalations_page(self):
        """This method allow users to traverse to the escalations page so that the
        user can perform the rest actions"""
        try:
            time.sleep(2)
            escalation_page_section = self.driver.find_element(
                By.XPATH, 
                escalations_management_locators.escalations_page
            )
            actions = ActionChains(self.driver)
            actions.move_to_element(escalation_page_section).click().perform()
        except StaleElementReferenceException:
            assert False

    def check_if_main_page_loads_data(self):
        """This method checks whether the data loads in the whole escalations page"""
        try:
            element = self.driver.find_element(
                By.XPATH, 
                escalations_management_locators.escalations_page_loader
            )
            time.sleep(1)
            result = element.is_displayed()
            return result

        except Exception:
            return False

    def check_if_escalations_page_likely_tobe_escalated_columns_contents_loader_loads_data(
        self,
    ):
        """
        This method checks whether the Likely to be escalated column is throwing
        error and no tickets are visible to user or not.
        """

        try:
            time.sleep(2)
            element = self.driver.find_element(
                By.XPATH, 
                escalations_management_locators.likely_tobe_escalated_content_loading_spinner_locator
            )
            print(element)
            time.sleep(2)
            print(element.is_displayed())
            time.sleep(2)
            wait = WebDriverWait(self.driver, 5)
            wait.until(EC.invisibility_of_element_located(element))

            print(element.is_displayed())
            return element.is_displayed()
        except Exception:
            return False

    def get_the_dynamic_filters_selected(self):
        """This method checks which dynamic filter is selected"""
        e = self.driver.find_elements(
            By.XPATH, 
            "//div[@data-testid='common-popupFilter-loader']"
        ).text
        for i in e:
            print(e[i])

        return e

    def check_if_escalations_page_escalation_request_columns_contents_loader_loads_data(
        self,
    ):
        """
        This method checks whether the escalation request column is throwing error and no tickets are visible to user
        or not.
        """
        try:
            element = self.driver.find_element(
                By.XPATH, 
                escalations_management_locators.escalation_request_content_loading_spinner_locator
            )
            time.sleep(1)
            result = element.is_displayed()
            return result

        except Exception:
            return False

    def check_if_escalations_page_escalated_today_columns_contents_loader_loads_data(
        self,
    ):
        """
        This method checks whether the escalated today column is throwing error and no tickets are visible to user or
        not.
        """
        try:
            element = self.driver.find_element(
                By.XPATH, 
                escalations_management_locators.escalated_today_content_loading_spinner_locator
            )
            time.sleep(1)
            result = element.is_displayed()
            return result

        except Exception:
            return False

    def check_if_escalations_page_active_escalations_columns_contents_loader_loads_data(
        self,
    ):
        """
        This method checks whether the active escalation column is throwing error and no tickets are visible to user or
        not.
        """
        try:
            element = self.driver.find_element(
                By.XPATH, 
                escalations_management_locators.active_escalation_content_loading_spinner_locator
            )
            time.sleep(1)
            result = element.is_displayed()
            return result

        except Exception:
            return False

    def check_if_escalations_page_resolved_columns_contents_loader_loads_data(self):
        """
        This method checks whether the resolved escalations column is throwing error
        and no tickets are visible to user or not.
        """
        try:
            element = self.driver.find_element(
                By.XPATH, 
                escalations_management_locators.resolved_content_loading_spinner_locators
            )
            time.sleep(1)
            result = element.is_displayed()
            return result

        except Exception:
            return False

    def check_if_escalations_page_likely_tobe_escalated_header_contents_loader_loads_data(
        self,
    ):
        """This method checks the header loader loads in order to view details in
        likely to be escalated column"""
        try:
            element = self.driver.find_element(
                By.XPATH, 
                escalations_management_locators.likely_tobe_escalated_header_loading_spinner_locator
            )
            time.sleep(1)
            result = element.is_displayed()
            return result

        except Exception:
            return False

    def check_if_escalations_page_escalation_request_header_contents_loader_loads_data(
        self,
    ):
        """This method checks the header loader loads in order to view details in
        escalation request column"""
        try:
            element = self.driver.find_element(
                By.XPATH, 
                escalations_management_locators.escalation_request_header_loading_spinner_locator
            )
            time.sleep(1)
            result = element.is_displayed()
            return result

        except Exception:
            return False

    def check_if_escalations_page_escalated_today_header_contents_loader_loads_data(
        self,
    ):
        """This method checks the header loader loads in order to view details in
        escalated today column"""
        try:
            element = self.driver.find_element(
                By.XPATH, 
                escalations_management_locators.escalated_today_header_loading_spinner_locator
            )
            time.sleep(1)
            result = element.is_displayed()
            return result

        except Exception:
            return False

    def check_if_escalations_page_active_escalations_header_contents_loader_loads_data(
        self,
    ):
        """This method checks the header loader loads in order to view details in
        active escalation column"""
        try:
            element = self.driver.find_element(
                By.XPATH, 
                escalations_management_locators.active_escalation_header_loading_spinner_locator
            )
            time.sleep(1)
            result = element.is_displayed()
            return result

        except Exception:
            return False

    def check_if_escalations_page_resolved_header_contents_loader_loads_data(self):
        """This method checks the header loader loads in order to view details in
        escalations resolved column"""
        try:
            element = self.driver.find_element(
                By.XPATH, 
                escalations_management_locators.resolved_header_loading_spinner_locators
            )
            time.sleep(1)
            result = element.is_displayed()
            return result

        except Exception:
            return False

    def check_if_error_message_is_present_in_likely_tobe_escalated_column(self):
        """This method focus on checking whether the data loads in likely to be
        escalated column"""
        try:
            element = self.driver.find_element(
                By.XPATH, 
                escalations_management_locators.error_message_likely_tobe_escalated_column
            )
            time.sleep(1)
            result = element.is_displayed()
            return result

        except Exception:
            return False

    def check_if_error_message_is_present_in_escalations_request_column(self):
        """This method focus on checking whether the data loads in likely to be
        escalated column"""
        try:
            element = self.driver.find_element(
                By.XPATH, 
                escalations_management_locators.error_message_escalation_request_column
            )
            time.sleep(1)
            result = element.is_displayed()
            return result

        except Exception:
            return False

    def check_if_error_message_is_present_in_escalated_today_column(self):
        """This method focus on checking whether the data loads in likely to be
        escalated column"""
        try:
            element = self.driver.find_element(
                By.XPATH, 
                escalations_management_locators.error_message_escalated_today_column
            )
            time.sleep(1)
            result = element.is_displayed()
            return result

        except Exception:
            return False

    def check_if_error_message_is_present_in_active_escalations_column(self):
        """This method focus on checking whether the data loads in likely to be
        escalated column"""
        try:
            element = self.driver.find_element(
                By.XPATH, 
                escalations_management_locators.error_message_active_escalation_column
            )
            time.sleep(1)
            result = element.is_displayed()
            return result

        except Exception:
            return False

    def check_if_error_message_is_present_in_resolved_escalations_column(self):
        """This method focus on checking whether the data loads in likely to be
        escalated column"""
        try:
            element = self.driver.find_element(
                By.XPATH, 
                escalations_management_locators.error_message_resolved_column
            )
            time.sleep(1)
            result = element.is_displayed()
            return result

        except Exception:
            return False

    def get_the_list_of_lt_be_column(self):
        """This method will return the list of all the ticket present inside the LTBE
        column"""
        list_texts = []
        list_lt_be = self.driver.find_elements(
            By.XPATH, 
            escalations_management_locators.lt_be_column_list
        )
        for listName in list_lt_be:
            list_texts = listName.text

        split_list = list_texts.split()
        return split_list

    def get_the_list_of_escalations_request_column(self):
        """This method will return the list of all the ticket present inside the
        escalations request column"""
        list_texts = []
        list_lt_be = self.driver.find_elements(
            By.XPATH, 
            escalations_management_locators.escalation_request_col_list
        )
        for listName in list_lt_be:
            list_texts = listName.text

        split_list = list_texts.split()
        return split_list

    def get_the_list_of_escalated_today_column(self):
        """This method will return the list of all the ticket present inside the
        escalated today column"""
        list_texts = []
        list_lt_be = self.driver.find_elements(
            By.XPATH, 
            escalations_management_locators.escalations_today_col_list
        )
        for listName in list_lt_be:
            list_texts = listName.text

        split_list = list_texts.split()
        return split_list

    def get_the_list_of_active_escalations_column(self):
        """This method will return the list of all the ticket present inside the
        active escalations column"""
        list_texts = []
        list_lt_be = self.driver.find_elements(
            By.XPATH, 
            escalations_management_locators.active_escalations_col_list
        )
        for listName in list_lt_be:
            list_texts = listName.text

        split_list = list_texts.split()
        return split_list

    def get_the_list_of_resolved_escalations_column(self):
        """This method will return the list of all the ticket present inside the
        resolved escalations column"""
        list_texts = []
        list_lt_be = self.driver.find_elements(
            By.XPATH, 
            escalations_management_locators.resolved_col_list
        )
        for listName in list_lt_be:
            list_texts = listName.text

        split_list = list_texts.split()
        return split_list

    def perform_drag_and_drop_from_lt_be_column_to_escalated_today_column(
        self, ticket_no
    ):
        """This method focuses on performing drag and drop from ltbe column to
        Escalated today column"""
        time.sleep(5)
        ticket_first_in_queue = self.driver.find_element(
            By.XPATH, 
            escalations_management_locators.ticket_drag_lt_be_queue + ticket_no + "']"
        )
        time.sleep(5)
        target_drop_column = self.driver.find_element(
            By.XPATH, 
            escalations_management_locators.escalations_today_col_list
        )
        time.sleep(5)
        ActionChains(self.driver).move_to_element(ticket_first_in_queue).click_and_hold(
            ticket_first_in_queue
        ).move_by_offset(6, -104).move_to_element(
            target_drop_column
        ).release().perform()
        time.sleep(5)

    def close_the_popup_after_performing_drag_and_drop(self):
        """This method focuses on closing the popup which comes after performing drag and drop from LTBE column to
        escalated today column
        """
        time.sleep(2)
        self.driver.find_element(
            By.XPATH, 
            escalations_management_locators.close_toggle_after_drag_and_drop_popup_comes
        ).click()
        self.driver.refresh()
        time.sleep(5)

    def move_to_resolved_col(self):
        """This method focuses on scrolling till the resolved column is visible for
        further actions"""
        element_col = self.driver.find_element(
            By.XPATH, 
            escalations_management_locators.resolved_col_list
        )
        ActionChains(self.driver).move_to_element(element_col).perform()

    def perform_the_functionality_of_drag_and_drop_with_first_case_active_escalations_to_resolved(
        self, ticket_number
    ):
        """This test script will check that always the first ticket is performing drag and drop in the escalations
        page from escalated today column to resolved column"""
        try:
            ticket_in_active_column = self.driver.find_element(
                By.XPATH, 
                escalations_management_locators.tickets_active_escalations_queue
                + ticket_number
                + "']"
            )
            # TODO: make the locators more robust when there is no ticket details
            #  fetched
            time.sleep(5)
            target_drop_column = self.driver.find_element(
                By.XPATH, 
                escalations_management_locators.resolved_col_list
            )
            time.sleep(5)
            ActionChains(self.driver).move_to_element(
                ticket_in_active_column
            ).click_and_hold(ticket_in_active_column).move_by_offset(
                6, -120
            ).move_to_element(
                target_drop_column
            ).release().perform()
            time.sleep(5)
            self.driver.refresh()
            time.sleep(5)
        except StaleElementReferenceException:
            assert False

    def perform_the_functionality_of_drag_and_drop_with_first_case_escalated_today_to_resolved(
        self, ticket_numbers
    ):
        """This test script will check that always the first ticket is performing drag and drop in the escalations
        page from escalated today column to resolved column"""
        try:
            ticket_escalated_today = self.driver.find_element(
                By.XPATH, 
                escalations_management_locators.escalations_today_col_list
                + ticket_numbers
                + "']"
            )
            time.sleep(5)
            target_drop_column = self.driver.find_element(
                By.XPATH, 
                escalations_management_locators.resolved_col_list
            )
            time.sleep(5)
            ActionChains(self.driver).move_to_element(target_drop_column).perform()
            time.sleep(5)
            ActionChains(self.driver).move_to_element(
                ticket_escalated_today
            ).click_and_hold(ticket_escalated_today).move_by_offset(
                6, -120
            ).move_to_element(
                target_drop_column
            ).release().perform()
            time.sleep(5)
            self.driver.refresh()
            time.sleep(100)
        except StaleElementReferenceException:
            assert False

    def perform_drag_and_drop_from_escalation_request_column_to_escalated_today_column(
        self, ticket_no
    ):
        """This method focuses on performing drag and drop from escalations request
        column to Escalated today column"""
        time.sleep(5)
        ticket_first_in_queue = self.driver.find_element(
            By.XPATH, 
            escalations_management_locators.escalation_request_queue.format(
                ticket=ticket_no
            )
        )
        time.sleep(5)
        target_drop_column = self.driver.find_element(
            By.XPATH, 
            escalations_management_locators.escalations_today_col_list
        )
        time.sleep(5)
        ActionChains(self.driver).move_to_element(ticket_first_in_queue).click_and_hold(
            ticket_first_in_queue
        ).move_by_offset(6, -104).move_to_element(
            target_drop_column
        ).release().perform()
        time.sleep(5)

    def get_escalation_count_from_column_header(self, state: EscalationState) -> str:
        """
        Get the case count from the given column. Works only on board aka kanban view.

        Parameters
        ----------
        state: EscalationState
            Enum representation of the column testid

        Returns
        -------
        str
            Case count
        """
        LOGGER.info(f"Getting the {state.value} count..")

        locator: str = eml.case_count_in_header_css.format(state=state.value)
        count: str = self.driver.find_element(By.CSS_SELECTOR, locator).text
        LOGGER.info(f"Cases under {state.value}: {count}")
        return count

    def calendar_selection_return_text(self):
        """This method will return the selection what is visible in the UI"""
        element = self.driver.find_element(
            By.XPATH, 
            escalations_management_locators.calendar_visible_option
        )
        return element.text

    def wait_till_the_important_elements_loads(self):
        """The test case should wait till important elements gets loaded completely"""
        element = self.driver.find_element(
            By.XPATH, 
            escalations_management_locators.calendar_visible_option
        )
        wait = WebDriverWait(self.driver, 30)
        wait.until(EC.visibility_of(element))
        self.check_if_escalations_page_active_escalations_columns_contents_loader_loads_data()

    def check_if_the_LTBE_list_is_collapsed(self):
        """This method checks if the active list is collpsed"""
        try:
            element = self.driver.find_element(
                By.XPATH, 
                escalations_management_locators.lt_be_list_expanded
            )
            wait = WebDriverWait(self.driver, 10)
            wait.until(EC.visibility_of(element))
            return True
        except Exception as e:
            return False

    def check_if_the_escalated_today_list_is_collapsed(self):
        """This method checks if the active list is collpsed"""
        try:
            element = self.driver.find_element(
                By.XPATH, 
                escalations_management_locators.escalated_today_list_expanded
            )
            wait = WebDriverWait(self.driver, 10)
            wait.until(EC.visibility_of(element))
            return True
        except Exception as e:
            return False

    def check_if_the_active_list_is_collapsed(self):
        """This method checks if the active list is collpsed"""
        try:
            element = self.driver.find_element(
                By.XPATH, 
                escalations_management_locators.active_list_expanded
            )
            wait = WebDriverWait(self.driver, 10)
            wait.until(EC.visibility_of(element))
            return True
        except Exception as e:
            return False

    def check_if_the_resolved_list_is_collapsed(self):
        """This method focuses to check if resolved list is collapsed"""
        try:
            element = self.driver.find_element(
                By.XPATH, 
                escalations_management_locators.resolved_list_expanded
            )
            wait = WebDriverWait(self.driver, 10)
            wait.until(EC.visibility_of(element))
            return True
        except Exception as e:
            return False

    def click_on_collapsed_lt_be_list_to_expand(self):
        """click on header to expand the list"""
        ele = self.driver.find_element(
            By.XPATH, 
            escalations_management_locators.lt_be_list_to_be_clicked
        )
        ele.click()

    def click_on_collapsed_escalated_today_be_list_to_expand(self):
        """click on header to expand the list"""
        ele = self.driver.find_element(
            By.XPATH, 
            escalations_management_locators.escalated_today_list_to_be_clicked
        )
        ele.click()

    def click_on_collapsed_resolved_list_to_expand(self):
        """This method focuses on expand the list"""
        ele = self.driver.find_element(
            By.XPATH, 
            escalations_management_locators.resolved_list_to_be_clicked
        )
        ele.click()

    def click_on_collapsed_active_list_to_expand(self):
        """click on header to expand the list"""
        ele = self.driver.find_element(
            By.XPATH, 
            escalations_management_locators.active_list_to_be_clicked
        )
        ele.click()

    def check_if_date_picker_is_visible(self):
        """This method searches for the calendar dae picker icon present in the
        escalation module"""
        date_picker_icon = self.driver.find_element(
            By.XPATH, 
            escalations_management_locators.calendar_visible_option
        )
        if not date_picker_icon.is_displayed():
            raise ElementNotVisibleException(
                "Calendar icon is not visible - Please check"
            )
        else:
            return True

    def click_on_calendar_icon(self):
        """This method performs click action on calendar icon"""
        date_picker_icon = self.driver.find_element(
            By.XPATH, 
            escalations_management_locators.calendar_visible_option
        )
        date_picker_icon.click()

    def check_calendar_popup_modal_is_visible(self):
        """This method checks if the modal is visible or not"""
        calendar_popover = self.driver.find_element(
            By.XPATH, 
            escalations_management_locators.calendar_modal_popover
        )
        if not calendar_popover.is_displayed():
            raise ElementNotVisibleException(
                "Calendar modal popover is not visible - Please check"
            )
        else:
            return True

    def check_for_likely_to_be_escalated_present(self):
        """This method helps to check likely to be escalated header is present"""

        LOGGER.info("Checking for likely to be escalated present.")
        return self.is_element_visible(
            (By.XPATH, escalations_management_locators.likely_to_be_escalated_header),
            timeout=30,
        )

    def check_for_escalation_request_is_present(self):
        """This method helps to check escalation request header is present"""

        LOGGER.info("Checking escalation present..")
        return self.is_element_visible(
            (By.XPATH, escalations_management_locators.escalation_request_header),
            timeout=30,
        )

    def check_for_active_escalation_present_or_not(self):
        """This method helps to check active escalation header is present"""

        LOGGER.info("Checking active escalation present ...")
        return self.is_element_visible(
            (By.XPATH, escalations_management_locators.active_escalation_header),
            timeout=30,
        )

    def check_for_resolved_is_present(self):
        """This method helps to check resolved header is present"""

        LOGGER.info("Checking resolved present or not...")
        return self.is_element_visible(
            (By.XPATH, escalations_management_locators.resolved_escalation_header),
            timeout=30,
        )

    def switch_to_board_view(self) -> None:
        self.click_on_element((By.CSS_SELECTOR, eml.board_view_layout_switcher_css))

    def switch_to_list_view(self) -> None:
        self.click_on_element((By.CSS_SELECTOR, eml.list_view_layout_switcher_css))

    def is_escalation_board_expanded(self, state: EscalationState) -> bool:
        locator: str = eml.escalations_container_css.format(state=state.value)
        case_container: WebElement = self.driver.find_element(By.CSS_SELECTOR, locator)
        return case_container.get_attribute("data-status") == "expanded"

    def expand_board_view(self, state: EscalationState) -> None:
        if self.is_escalation_board_expanded(state):
            return

        if state in [
            EscalationState.SNOOZED,
            EscalationState.DISMISSED,
            EscalationState.ACCEPTED,
        ]:
            locator: str = eml.hidden_escalation_board_button_css.format(
                state=state.value
            )
            self.click_on_element((By.CSS_SELECTOR, locator))
            return

        locator: str = eml.escalations_container_css.format(state=state.value)
        self.click_on_element((By.CSS_SELECTOR, locator))

    def get_case_id_from_first_case_card(self, state: EscalationState) -> Optional[str]:
        if self.get_escalation_count_from_column_header(state) == "0":
            return
        locator: str = eml.escalations_case_card_css.format(state=state.value)
        case_card: WebElement = self.driver.find_element(By.CSS_SELECTOR, locator)
        return case_card.get_attribute("data-testid").split("-")[-1]

    def click_first_active_escalation_case_note_button(self) -> None:
        self.hover_on_element((By.CSS_SELECTOR, eml.active_escalations_css))
        self.click_on_element((By.CSS_SELECTOR, eml.active_escalations_note_button_css))

    def enter_note_in_first_active_escalation_case(self, note: str) -> None:
        self.pass_value_to_element(
            (note, Keys.ENTER),
            (By.CSS_SELECTOR, shl.escalation_note_textarea_css),
            message="Escalation note textarea is not visible or present",
        )

    def decline_first_escalation_request_case(self) -> None:
        case_card_locator: str = eml.escalations_case_card_css.format(
            state=EscalationState.ESCALATION_REQUESTS.value
        )
        self.hover_on_element((By.CSS_SELECTOR, case_card_locator))
        self.click_on_element(
            (By.CSS_SELECTOR, eml.escalation_request_decline_button_css)
        )

    def undo_snoozed_declined_accepted_cases(
        self, state: EscalationState, case_id: str = None
    ) -> None:
        case_card_locator: str = eml.escalations_case_card_css.format(state=state.value)
        if case_id:
            case_card_locator = eml.escalations_case_card_with_id_css.format(
                state=state.value, id=case_id
            )
        self.hover_on_element((By.CSS_SELECTOR, case_card_locator))
        self.click_on_element((By.CSS_SELECTOR, eml.undo_button_css))

    def get_list_view_column_names(self) -> list[str]:
        column_headers = self.driver.find_elements(
            By.CSS_SELECTOR, eml.list_view_column_header_css
        )
        return [header.text for header in column_headers]

    def click_add_field_plus_button(self) -> None:
        self.click_on_element((By.CSS_SELECTOR, eml.add_field_plus_button_css))

    def get_field_names_from_add_field_popover(self) -> list[str]:
        field_names = self.driver.find_elements(
            By.CSS_SELECTOR, eml.add_field_popover_option_label_css
        )
        return [field_name.text for field_name in field_names]

    def select_fields_in_add_field_popover(self, field_name: str | list[str]) -> None:
        options: list[str] = field_name
        if isinstance(field_name, str):
            options = [field_name]

        for option in options:
            locator = eml.add_field_popover_option_checkbox_css.format(option=option)
            if (
                self.driver.find_element(By.CSS_SELECTOR, locator).get_attribute(
                    "data-status"
                )
                == "checked"
            ):
                return
            locator = eml.add_field_popover_options_css.format(option=option)
            self.click_on_element((By.CSS_SELECTOR, locator))

    def deselect_fields_in_add_field_popover(self, field_name: str | list[str]) -> None:
        options: list[str] = field_name
        if isinstance(field_name, str):
            options = [field_name]

        for option in options:
            locator = eml.add_field_popover_option_checkbox_css.format(option=option)
            if (
                self.driver.find_element(By.CSS_SELECTOR, locator).get_attribute(
                    "data-status"
                )
                == "unchecked"
            ):
                return
            locator = eml.add_field_popover_options_css.format(option=option)
            self.click_on_element((By.CSS_SELECTOR, locator))

    def get_current_sort_by_value(self, state: EscalationState):
        dropdown_locator = eml.escalations_container_sort_by_css.format(
            state=state.value
        )
        return self.get_element_text_or_value((By.CSS_SELECTOR, dropdown_locator))

    def sort_by(
        self,
        state: EscalationState,
        option: Union[
            str,
            ActiveEscalationsSortOptions,
            EscalationRequestsSortOptions,
            LTESortOptions,
            ResolvedEscalationsSortOptions,
        ],
    ) -> None:
        option = option if isinstance(option, str) else option.value
        LOGGER.info(f"Sorting {state.name.title()} by {option}..")
        dropdown_locator = eml.escalations_container_sort_by_css.format(
            state=state.value
        )
        self.click_on_element((By.CSS_SELECTOR, dropdown_locator))
        time.sleep(0.2)
        options_locator = eml.escalation_container_sort_by_option.format(
            state=state.value, option=option
        )
        self.click_on_element((By.XPATH, options_locator))

    def verify_sort_by_oldest_case(self, state: EscalationState) -> bool:
        create_date_locator = eml.case_card_create_date_css.format(state=state.value)
        date_elements = self.driver.find_elements(By.CSS_SELECTOR, create_date_locator)
        creation_dates = [elem.text for elem in date_elements]
        LOGGER.info(f"Oldest case values from UI: {creation_dates}")
        return creation_dates == utils.sort_time_phrases(creation_dates, True)

    def verify_sort_by_most_lte(self, state: EscalationState) -> bool:
        prediction_scores = self.get_escalation_prediction_scores()
        sorted_entries = sorted(
            prediction_scores, key=lambda entry: entry["prediction_score"], reverse=True
        )
        case_ids_from_api = [entry["sl_case_id"] for entry in sorted_entries]
        case_card_locator = eml.escalations_case_card_css.format(state=state.value)
        case_cards = self.driver.find_elements(By.CSS_SELECTOR, case_card_locator)
        case_ids_from_ui = [
            case_card.get_attribute("data-testid").split("-")[-1]
            for case_card in case_cards
        ]
        return all([int(case_id) in case_ids_from_api for case_id in case_ids_from_ui])

    def verify_sort_by_most_recent_response(self, state: EscalationState) -> bool:
        last_response_locator = eml.case_card_last_response_time.format(
            state=state.value
        )
        lr_elements = self.driver.find_elements(By.XPATH, last_response_locator)
        last_response_times = [
            element.text.replace("Outbound, ", "").replace("Inbound, ", "")
            for element in lr_elements
        ]
        LOGGER.info(f"Last response times from UI: {last_response_times}")
        return last_response_times == utils.sort_time_phrases(last_response_times)

    def verify_sort_by_lowest_sentiment(self, state: EscalationState) -> bool:
        sentiment_score_locator = eml.case_card_sentiment_score_css.format(
            state=state.value
        )
        elements = self.driver.find_elements(By.CSS_SELECTOR, sentiment_score_locator)
        sentiment_scores = [elem.text for elem in elements]
        LOGGER.info(f"Sentiment scores from UI: {sentiment_scores}")
        return sentiment_scores == sorted(sentiment_scores, key=int)

    def verify_sort_by_highest_attention(self, state: EscalationState) -> bool:
        attention_score_locator = eml.case_card_attention_score_css.format(
            state=state.value
        )
        elements = self.driver.find_elements(By.CSS_SELECTOR, attention_score_locator)
        attention_scores = [elem.text for elem in elements]
        LOGGER.info(f"Attention scores from UI: {attention_scores}")
        return attention_scores == sorted(attention_scores, key=int, reverse=True)

    def verify_sort_by_highest_priority(self, state: EscalationState) -> bool:
        priority_locator = eml.case_card_priority_css.format(state=state.value)
        elements = self.driver.find_elements(By.CSS_SELECTOR, priority_locator)
        priorities = [elem.text for elem in elements]
        LOGGER.info(f"Case priority from UI: {priorities}")
        sort_order = {"Urgent": 0, "High": 1, "Medium": 2, "Low": 3}
        sorted_priorities = sorted(priorities, key=lambda x: sort_order[x])
        return priorities == sorted_priorities

    def verify_sort_by_most_recent_request(self, state: EscalationState) -> bool:
        case_card_locator = eml.escalations_case_card_css.format(state=state.value)
        case_cards = self.driver.find_elements(By.CSS_SELECTOR, case_card_locator)
        er_times = []
        for case_card in case_cards:
            case_card.click()
            locator = (By.XPATH, shl.escalation_request_label_time)
            er_times.append(self.get_element_text_or_value(locator))
            self.click_on_element((By.CSS_SELECTOR, shl.close_support_hub_button_css))
        LOGGER.info(f"Escalation Request times: {er_times}")
        return er_times == utils.sort_time_phrases(er_times)

    def verify_sort_by_most_recent_escalation(self, state: EscalationState) -> bool:
        locator = eml.case_card_in_escalated_state.format(state=state.value)
        elements = self.driver.find_elements(By.XPATH, locator)
        escalated_times = [elem.text for elem in elements]
        LOGGER.info(f"In Escalated State times from UI: {escalated_times}")
        return escalated_times == utils.sort_time_phrases(escalated_times)

    def verify_sort_by_closed_date(self, state: EscalationState) -> bool:
        closed_date_locator = eml.case_card_closed_date.format(state=state.value)
        elements = self.driver.find_elements(By.XPATH, closed_date_locator)
        closed_dates = [elem.text for elem in elements]
        LOGGER.info(f"Closed dates from UI: {closed_dates}")
        return closed_dates == utils.sort_time_phrases(closed_dates)
