"""This test scenario focuses on checking the console page . This test case inherit the console_page to perform the
test in the console page"""
__copyright__ = "Copyright (C) 2020 SupportLogic"

import logging
import time

from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait

from enums import ConsolePageTabs
from locators import console_page_locators, oldlocators, settings_locators
from pom_library.helper_methods import HelperMethods
from .pom_base import PomBase

LOGGER = logging.getLogger(__name__)


class ConsolePage(HelperMethods):
    """
    This class has all the actions that can be done in console page.
    """

    # declaring the driver to use it in overall page
    def __init__(self, driver):
        self.driver = driver

        PomBase.__init__(self, self.driver)
        self.actions = ActionChains(driver)
        self.wait = WebDriverWait(driver, 30)

    def check_if_control_centre_button_is_present(self):
        """ This method focuses to check if the control centre is visible in the dashboard"""
        try:
            element = self.driver.find_element(
                By.XPATH, 
                settings_locators.control_centre_button_id
            )
            wait = WebDriverWait(self.driver, 5)
            wait.until(EC.visibility_of_element_located(element))

            actions = ActionChains(self.driver)
            actions.move_to_element(element)
            if element.is_displayed():
                return True

        except Exception:
            return False

    def click_in_the_control_centre_button(self):
        """
        This method helps to traverse to control centre button in settings page.
        """

        control_button = self.driver.find_element(
            By.ID, 
            settings_locators.control_centre_button_id
        )
        self.actions.move_to_element(control_button).click().perform()
        LOGGER.info(
            "Clicking on the Control center button on Navbar"
        )

    def click_on_the_clickable_text_settings(self):
        """This method help to  click on the console page in the settings"""

        setting_element = self.driver.find_element(
            By.XPATH, 
            settings_locators.settings_clickable_text_xpath
        )
        self.actions.move_to_element(setting_element).click().perform()
        LOGGER.info(
            "'settings clickable text in control centre list' element not found :: check locators page \n the "
            "console_page code to check if it needs wait "
        )

    def check_time_filter_today_is_enabled(self):
        """This method help to check whether is enable in setting """
        time_filter_locator = self.driver.find_element(
            By.XPATH, 
            oldlocators.time_filters_today
        )
        enable = time_filter_locator.is_displayed()
        LOGGER.info(enable)
        if enable:
            LOGGER.info(
                "The today filter is selected/invisible in settings> console page"
            )
            return True
        else:
            LOGGER.info(
                "The today filter is not selected/visible in settings > console page"
            )
            return False

    # Method focuses on clicking on the console page in dashboard:
    def click_on_console_page_in_dashboard(self):
        """
        Click on the console tab on the nav bar to displayed console page

        """
        self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, console_page_locators.console_section_dashboard)
            )
        ).click()

    # Method focuses on checking whether today time filter is present in the page
    def check_if_time_filter_in_console_dashboard(self):
        """
        Click on the Filters in the console page and  Check for  Selected elements is displayed on filters
            ----------
        """

        time_filter_locator = console_page_locators.click_on_time_filter
        status = self.wait.until(
            EC.visibility_of_element_located((By.XPATH, time_filter_locator))
        ).is_displayed()

        if status:
            LOGGER.info(f"time filter is displayed")
            return True

        else:
            LOGGER.info(f" time filter is not displayed")
            return False

    def get_time_filter_in_console(self):
        """This method helps to get time filter """
        time_filter = self.wait.until(
            EC.visibility_of_element_located(
                (By.XPATH, console_page_locators.click_on_time_filter)
            )
        ).text
        LOGGER.info(f"{time_filter}  is displayed on time filter ")
        return time_filter

    def click_time_filter_drop_down(self):
        """This method help to click on time filter drop down"""

        time_filter_locator = console_page_locators.click_on_time_filter
        time_filter_element = self.driver.find_element(By.XPATH, time_filter_locator)

        self.actions.move_to_element(time_filter_element).click().perform()

    def select_filter_in_console(self, dropdown_filter):
        """
        Select Filter  from the  days selection drop down
        ----------
        parameter
         console filter: option of the filter  (Today,Since yesterday ,Last 7 year)
        """

        select_filter_locator = console_page_locators.filter_select.replace(
            "TEXT_PLACEHOLDER", dropdown_filter
        )
        self.wait.until(
            EC.element_to_be_clickable((By.XPATH, select_filter_locator))
        ).click()

    def validate_cards_based_on_filter_new_case(self, dropdown_filter):
        """
        Check that new case card data is loaded based on the filters
            ----------
            parameter
                Drop down: option of the filter  (Today,Since yesterday )

        """

        new_cases = {
            "Today": [
                " yesterday",
            ],
            "Since yesterday": [
                " previous days",
                " Same as yesterday",
            ],
        }
        new_cases_cards = console_page_locators.new_case_card

        new_case_validation = new_cases[dropdown_filter]

        status = self.wait.until(
            EC.visibility_of_element_located((By.XPATH, new_cases_cards))
        ).text
        result = "".join([i for i in status if not i.isdigit()])
        for  i in new_case_validation:
            if i in result:
                LOGGER.info(f"{dropdown_filter} data is loaded ")
                return True
            else:
                LOGGER.info(f"{dropdown_filter} data is not  loaded ")
                return False

    def validate_cards_based_on_filter_new_case_7_days(self):
        """
        Checks for data is loaded based on the time filter options
            ----------
        """
        new_cases = " previous 7 days"

        new_cases_cards = console_page_locators.new_case_card

        status = self.wait.until(
            EC.element_to_be_clickable((By.XPATH, new_cases_cards))
        ).text

        new_card = status.split("the")
        time_filter = new_card[1]

        if time_filter in new_cases:
            LOGGER.info("New case data is loaded")
            return True
        else:
            LOGGER.info("New case data is not  loaded")
            return False







    def click_on_any_case_in_unassigned_list(self):
        """ Click  on the any case in Unassigned new case  in the console page"""
        time.sleep(2)
        cards = self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, console_page_locators.assigned_case_from_list)
            )
        )
        self.actions.move_to_element(cards).click().perform()


    def validate_support_hub_reporter(self):
        """
        checks for support hub reporter field is displayed

        """

        reporters = self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, console_page_locators.reporter_support_hub)
            )
        ).is_displayed()

        if reporters:
            LOGGER.info(f"reporter in support hub is display")
            return True
        else:
            LOGGER.info("reporter in support hub is  not display")
            return False

    def validate_support_hub_agents(self):
        """
        checks for support hub agents field is displayed

        """

        agents = self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, console_page_locators.agents_support_hub_assigned)
            )
        ).is_displayed()

        if agents:
            LOGGER.info("Agents in support hub is display")
            return True
        else:
            LOGGER.info("Agents in support hub  not is display")
            return False

    def validate_support_hub_agents_unassigned(self):
        """
        checks for   support hub unassigned field is displayed

        """

        reporters = self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, console_page_locators.agents_support_hub_assigned)
            )
        ).is_displayed()

        if reporters:
            LOGGER.info("Agents in support hub is display")
            return True
        else:
            LOGGER.info("Agents in support hub  not is display")
            return False

    def validate_support_hub_agents_open_for(self):

        """
        checks for  support hub agent field is displayed

        """
        open_for = self.wait.until(
            EC.element_to_be_clickable((By.XPATH, console_page_locators.open_for))
        ).is_displayed()

        if open_for:
            LOGGER.info("Open for  in support hub is display")
            return True
        else:
            LOGGER.info("Open for support hub is display")
            return False

    def validate_support_hub_history(self):

        """
        checks for support hub case history  field is displayed
        """
        history = self.wait.until(
            EC.element_to_be_clickable((By.XPATH, console_page_locators.case_history))
        ).is_displayed()

        if history:
            LOGGER.info("Case history  in support hub is display")
            return True
        else:
            LOGGER.info(" Case history support hub is display")
            return False



    def click_on_apply_filter(self):
        """Click on the add filter option from the drop down of the dynamic filters """
        apply_filter = console_page_locators.add_dynamic_filter
        self.wait.until(EC.element_to_be_clickable((By.XPATH, apply_filter))).click()

    def validate_the_dynamic_selected_pop_up(self):
        """  click on the dynamic filter and validating pop up displayed based on that """

        pop_up_display = self.driver.find_element(
            By.XPATH, 
            console_page_locators.dynamic_selected_pop_up
        ).is_displayed()

        if pop_up_display:
            LOGGER.info("Dynamic filter pop is display")
            return True
        else:
            LOGGER.info("Dynamic filter pop up is not display")
            return False

    def select_cards_data_validation(self, card):
        """ Validate  negative page is loaded  on clicking negative cards"""

        cards_data_validation = self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, console_page_locators.positive_sentiments_validation)
            )
        ).is_displayed()

        if cards_data_validation:
            LOGGER.info(f" {card} card data is displayed")
            return True
        else:
            LOGGER.info(f"{card} card data is  not displayed")
            return False

    def new_case_cards_data_validation(self, card):
        """   This method help to validate  new data loaded  on clicking new case card"""

        cards_data_validation = self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, console_page_locators.new_case_data_validation)
            )
        ).is_displayed()

        if cards_data_validation:
            LOGGER.info(f" {card} card data is displayed")
            return True
        else:
            LOGGER.info(f"{card} card data is  not displayed")
            return False

    def service_compliance_cards_data_validation(self, card):
        """   This method help to validate  service compliance loaded  on clicking service compliance card"""
        time.sleep(2)
        cards_data_validation = self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, console_page_locators.services_page_data_validation)
            )
        ).is_displayed()

        if cards_data_validation:
            LOGGER.info(f" {card} card data is displayed")
            return True
        else:
            LOGGER.info(f"{card} card data is  not displayed")
            return False

    def get_text_priority_support_hub(self):
        """Checks for the priorities in support hub  """

        support_hub_element = self.driver.find_element(
            By.XPATH, 
            console_page_locators.priority_in_support_hub
        ).text

        return support_hub_element

    def click_on_any_case_in_assigned_backlog(self):
        """Clicks on  bar graph in assigned  cases """
        try:
            self.wait.until(
                EC.element_to_be_clickable(
                    (By.CSS_SELECTOR, console_page_locators.assigned_cases_backlog)
                )
            ).click()
            case_list_in_first_respond = self.driver.find_element(
                By.XPATH, 
                console_page_locators.list_cases_first_respond_time
            ).is_displayed()
            if case_list_in_first_respond:
                self.driver.find_element(
                    By.XPATH, 
                    console_page_locators.list_cases_first_respond_time
                ).click()

        except:
            LOGGER.info(
                "already support hub is displayed or there is no presence of backlog cases in assigned list "
            )

    def click_on_assigned_this_period(self):
        """Clicks on  bar graph in assigned cases  this period """
        try:
            self.wait.until(
                EC.element_to_be_clickable(
                    (By.CSS_SELECTOR, console_page_locators.assigned_case_this_period)
                )
            ).click()

            case_list_in_first_respond = self.wait.until(
                EC.visibility_of_element_located(
                    (By.XPATH, console_page_locators.list_cases_first_respond_time)
                )
            ).is_displayed()
            if case_list_in_first_respond:
                self.click_on_element(
                    (By.XPATH, console_page_locators.list_cases_first_respond_time),
                    timeout=30,
                    message="failed to click on the from case from the list ",

                )
        except:
            LOGGER.info("already support hub is displayed")

    def click_on_assigned_case(self):
        """ Clicks on the any case in assigned case """
        try:
            self.wait.until(
                EC.element_to_be_clickable(
                    (By.XPATH, console_page_locators.assigned_case_from_list)
                )
            ).click()
            LOGGER.info("Click on Assigned case ")
        except:
            LOGGER.warning("no cases on list")

    def validate_assigned_case_list(self):
        """click on th assigned graph in new cases and list of case appears
        validate the list of case displayed"""

        assigned_element = self.driver.find_element(
            By.XPATH, 
            console_page_locators.validate_assigned_list
        ).is_displayed()
        if assigned_element:
            LOGGER.info("Assigned case list is displayed")
            return True
        else:
            LOGGER.info("Assigned case list is not  displayed")
            return False



    def click_on_to_open_support_hub_in_cards(self):
        """Click on  first card to open support hub in positive sentiment
        and negative sentiments and need attention"""
        time.sleep(2)
        data_display = self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, console_page_locators.support_hub_in_negative)
            )
        )
        self.actions.move_to_element(data_display).click().perform()

    def click_on_service_graph_and_list(self):
        """click on the service compliance graph and list and if one cases is present in first respond time
        support hub is display or list of cases is present in support hub it check for list and click on the first cases
        from the list"""
        try:
            time.sleep(2)
            first_respond_time = self.wait.until(
                EC.element_to_be_clickable(
                    (By.XPATH, console_page_locators.service_compliance_first_respond)
                )
            )
            self.actions.move_to_element(first_respond_time).click().perform()

            case_list_in_first_respond = self.wait.until(
                EC.visibility_of_element_located(
                    (By.XPATH, console_page_locators.list_cases_first_respond_time)
                )
            ).is_displayed()
            if case_list_in_first_respond:
                self.click_on_element(
                    (By.XPATH, console_page_locators.list_cases_first_respond_time),
                    timeout=30,
                    message="failed to click on the from case from the list ",

                )
        except:
            LOGGER.info("clicked on support  hub ")

    def click_on_profile(self):
        """Click on the profile name"""

        self.wait.until(
            EC.element_to_be_clickable((By.XPATH, console_page_locators.user_profile))
        ).click()
        LOGGER.info("Clicked on user profile")

    def click_on_log_out(self):
        """ This method helps to click on the logout method """

        self.wait.until(
            EC.element_to_be_clickable((By.XPATH, console_page_locators.log_out))
        ).click()
        LOGGER.info("Clicked on log out button")

    def check_for_console_dashboard_display_data(self):
        """This method helps to check for data display on console page or not"""
        try:
            time.sleep(2)
            console_page_data_present = self.wait.until(
                EC.visibility_of_element_located(
                    (By.XPATH, console_page_locators.new_case)
                )
            ).is_displayed()
            if console_page_data_present:
                LOGGER.info("Data present on the console page ")
                return True
        except:
            LOGGER.info("Data present is not  console page ")
            return False

    def check_the_presence_of_cases_unassigned_cases(self):
        """ Click  on the any case is present Unassigned new case  in the console page"""
        try:
            unassigned_cases = self.wait.until(
                EC.element_to_be_clickable(
                    (By.XPATH, console_page_locators.assigned_case_from_list)
                )
            ).is_displayed()
            if unassigned_cases:
                return True

        except:
            return False

    def click_on_(self):
        """ This method helps to click on the logout method """

        self.wait.until(
            EC.element_to_be_clickable((By.XPATH, console_page_locators.log_out))
        ).click()
        LOGGER.info("Clicked on log out button")

    def click_on_tab(self, tab_name: ConsolePageTabs):
        tab_name = tab_name.value.replace("_", "+")
        self.driver.get(f"{self.base_url}/support/console?tab={tab_name}")
        self.wait.until(
            EC.visibility_of_element_located((By.XPATH, console_page_locators.tabs))
        )

    def click_on_assigned_cases_tab_status_button(self):
        """This method helps to click on status  button in assigned cases  """
        self.click_on_element(
            (By.XPATH, console_page_locators.assigned_case_tab_status_drop_down),
            timeout=5,
            message="failed to click on the status in case distribution tab",
        )

    def click_on_case_distribution_status_button(self):
        """This method helps to click on status  button in case distribution  """
        self.click_on_element(
            (By.XPATH, console_page_locators.case_distribution_tab_status_drop_down),
            timeout=5,
            message="failed to click on the status in case distribution tab",
        )

    def get_text_of_current_status_in_assigned_case_tab(self):
        """This method helps to get the current status in assigned tab"""
        status_assigned_case_tab = self.get_element_text_or_value(
            (By.XPATH, console_page_locators.assigned_case_tab_status_drop_down)
        )
        return status_assigned_case_tab

    def get_text_of_current_status_in_case_distribution_tab(self):
        """ This method helps to get the current status in case distribution"""

        current_status_distribution_tab = self.get_element_text_or_value(
            (By.XPATH, console_page_locators.case_distribution_tab_status_drop_down)
        )
        return current_status_distribution_tab

    def select_status_in_assigned_tab(self,status):
        """select open or close status in  from status from down in assigned tab"""
        select_status = console_page_locators.assigned_case_select_status_in_dropdown.replace(
            "TEXT_PLACEHOLDER", status
        )
        self.click_on_element(
            (By.XPATH, select_status),
            timeout=5,
            message="failed to select the status from status drop down ",
        )

    def select_status_in_case_distribution_tab(self,status):
        """select open or close status in  from status from down in assigned tab"""
        select_status = console_page_locators.select_status_in_dropdown_case_distribution.replace(
            "TEXT_PLACEHOLDER", status
        )
        self.click_on_element(
            (By.XPATH, select_status),
            timeout=5,
            message="failed to select the status from status drop down ",
        )

    def click_on_case_distribution_tab_bar_chart_case(self):
        """Clicks on  bar graph in assigned  cases """
        try:
            LOGGER.info("click on first bar chart in case distribution tab ")
            self.wait.until(
                EC.element_to_be_clickable(
                    (By.CSS_SELECTOR, console_page_locators.case_distribution_tab_case)
                )
            ).click()
            case_list_in_first_respond = self.wait.until(
                            EC.visibility_of_element_located(
                                (By.XPATH, console_page_locators.list_cases_first_respond_time)
                            )
            ).is_displayed()
            if case_list_in_first_respond:
                self.click_on_element(
                    (By.XPATH, console_page_locators.list_cases_first_respond_time),
                    timeout=30,
                    message="failed to select the status from status drop down ",

                )
        except:
            LOGGER.warning(
               "No data is founded in case distribution tab  "
            )
    def get_text_expand_or_collapse_toggle_on_sentiments_tab(self):
        """ get text of expand and collapse toggle status """
        status_of_sentiments_tab = self.get_element_text_or_value(
            (By.XPATH, console_page_locators.expand_all_in_sentiments_tab)
        )
        return status_of_sentiments_tab


    def click_on_expand_collapse_toggle_on_sentiments(self):
        """ click on the expand and collapse toggle """
        self.click_on_element(
            (By.XPATH, console_page_locators.expand_all_in_sentiments_tab),
            timeout=5,
            message="failed to click on expand and collapse toggle ",
        )

    def click_on_grouped_by_on_tabs(self):
        """click on group by drop down on negative ,positive and need attention group by """
        self.click_on_element(
            (By.XPATH, console_page_locators.group_by_filter),
            timeout=5,
            message="failed to click on the group by  ",
        )

    def select_filter_from_grouped_by(self,filter_name):
        """ select the filter  from the group by"""
        self.click_on_element(
            (By.XPATH, console_page_locators.grouped_by_dropdown_option.replace("Filter", filter_name.value)),
            message=f"select the select {filter_name}"
        )

    def click_on_assigned_or_unassigned_bar_in_case_distribution_if_enable(self,bar_option):
        """click on assigned or unassigned bar in case distribution"""
        bar_enable=self.is_element_enabled((By.XPATH, console_page_locators.unassigned_or_assigned_bar_case_distribution.replace("chart_bar_option", bar_option.value)))
        if bar_enable :

            self.click_on_element(
                (By.XPATH, console_page_locators.unassigned_or_assigned_bar_case_distribution.replace("chart_bar_option", bar_option.value))

            )

    def check_the_presence_of_bar_chart_graph_in_case_distribution(self):
        """This method helps to check THE present of bar chart in case distribution"""
        try:
            bar_chart_in_case_distribution=self.wait.until(
                EC.visibility_of_element_located(
                    (By.CSS_SELECTOR, console_page_locators.case_distribution_tab_case)
                )).is_displayed()
            if bar_chart_in_case_distribution:
                return True

        except:
            return False


    def click_on_all_queues_filter_in_unassigned_tab(self):
        """this method helps to click on the all queue filter in unassigned tab"""
        self.click_on_element(
            (By.XPATH, console_page_locators.all_queues_in_unassigned_tab),
            timeout=5,
            message="failed to click on all queue filter ",
        )
    def select_first_enable_option_in_all_queue_unassigned_tab(self):
        """this method helps to select the first enable option from the all queque filter"""
        self.click_on_element(
            (By.XPATH, console_page_locators.first_option_in_all_queue_unassigned_tab),
            timeout=5,
            message="failed to click on case evaluation details ",
        )
    def get_text_of_first_option_in_all_queues(self):
        """this method helps to get the first option in all filter """
        agents_name =self.get_element_text_or_value(
            (By.XPATH, console_page_locators.first_option_in_all_queue_unassigned_tab)
        )
        return agents_name

    def check_for_presence_case_cards_in_tabs(self):
        """Click on  first card to open support hub in positive sentiment
        and negative sentiments and need attention"""
        try:
            time.sleep(2)
            data_display = self.wait.until(
                EC.visibility_of_element_located(
                    (By.XPATH, console_page_locators.support_hub_in_negative)
                )
            ).is_displayed()
            if data_display :
                return  True
        except:
                  return False

    def get_text_of_assigned_cases_in_assigned_case_tab(self):
        """get the text number of assigned method present near the assigned case tab"""
        status_assigned_case_tab = self.get_element_text_or_value(
            (By.XPATH, console_page_locators.no_of_assigned_cases_present_on_assigned_cases_tab)
        )
        return status_assigned_case_tab


    def get_text_agents_in_unassigned_cases(self):
        """
        check for the  support hub  to  get text of reporters
        """

        status_assigned_case_tab = self.get_element_text_or_value(
            (By.XPATH, console_page_locators.agents_support_hub_assigned)
        )
        return status_assigned_case_tab

    def click_on_switch_sort_in_unassigned_tab(self):
        """this method helps to click on switch sort method """
        self.click_on_element(
            (By.XPATH, console_page_locators.switch_sort_in_unassigned_tab),
            timeout=20,
            message="failed to click on switch button ",
        )


    def check_card_present_under_likely_to_escalated_card(self):
        """This method helps to check the number of card present under the current LTBE TAB"""
        number_of_cards_present_likely_escalate = self.driver.find_element(
            By.XPATH, console_page_locators.likely_to_be_cards_cards
        ).is_displayed()
        return number_of_cards_present_likely_escalate


    def click_on_likely_to_escalated_card(self):
        """This method helps to click on first card in likely to escalated """
        self.mouse_click_on_element(
            (By.XPATH, console_page_locators.likely_to_be_cards_cards),
            timeout=50,
            message="likely to be escalated card ",
        )

    def validate_cards_based_on_filter_negative_tab_footer(self, ):
        """This method helps to validate negative tab footer card  """
        LOGGER.info("validating negative card based on time filter")
        negative_card_footer = self.get_element_text_or_value(
            (By.XPATH, console_page_locators.negative_sentiment_card_validation),
            message="failed to fetch the footer text in positive card  ",
        ).strip()
        if "previous 7 days" in negative_card_footer :
            LOGGER.info(" negative  card footer data is loaded based on time filter")
            return True
        else:
            LOGGER.info("negative  card footer data is loaded based on time filter")
            return False

    def validate_cards_based_on_filter_positive_card_footer(self):
        """This method helps to validate  positive filter card"""
        LOGGER.info("""validating positive card footer .....""")

        positive_card_footer=self.get_element_text_or_value(
            (By.XPATH, console_page_locators.positive_sentiment_cards_validation),
            message="failed to fetch the footer text in positive card  ",
        ).strip()
        if "previous 7 days" in positive_card_footer:
            LOGGER.info("positive card footer is matched the time filter")
            return True
        else:
            LOGGER.info("positive card footer is not match with time filter")
            return False

    def validate_service_compliance_based_on_last_7_days_time_filter(self):
        """This method helps to validate  service compliance footer"""
        LOGGER.info("validating service compliance footer .....")
        service_compliance_case_created = self.get_element_text_or_value(
            (By.XPATH, console_page_locators.service_compliance_time_filter_validation),
            message="failed to fetch the footer text in service compliance",
        ).strip()
        if "last 7 days" in service_compliance_case_created:
            LOGGER.info(" cases got filter based on time filter")
            return True
        else:
            LOGGER.info("cases not filter based on time filter")
            return False

    def validate_need_attention_based_on_last_7_days_time_filter(self):
        """This method helps to validate  need attention card"""
        LOGGER.info("validating need attention footer..........")
        return self.is_element_visible(
            (By.XPATH, console_page_locators.need_attentions_time_filter_validation )
        )
    def get_first_case_id_in_unassigned_tab(self):
        """This method helps to click on case id in unassigned tab"""
        LOGGER.info("This method helps to get case id from unassigned tab")
        case_id = self.get_element_text_or_value(
            (By.XPATH, console_page_locators.first_case_first_case_id)
        )
        LOGGER.info(f"{case_id} of first case in assigned tab")
        return case_id

    def checking_visibility_of_bar_graph_on_escalation_tab(self):
        """ This method helps to check the visibility of bar graph   escalation tab"""
        LOGGER.info("checking for visibility  of bar graph on escalation tab")
        return self.is_element_visible(
            (
                By.XPATH,
                console_page_locators.bar_graph_on_escalation_tab
            ))

    def check_for_presence_of_likely_to_be_escalated_banner_in_support_hub(self):
        """This method helps to check for the presence of likely to be escalated banner"""
        LOGGER.info("likely to be escalated banner in support hub")
        return self.is_element_visible(
            (By.XPATH, console_page_locators.likely_to_be_cards_banner_support_hub))

    def click_on_check_button_likely_to_be_escalated_support_hub(self):
        """This method helps to click on check button of likely to be escalated banner"""
        LOGGER.info("check button in likely to be escalated banner in support hub")
        self.click_on_element(
            (By.XPATH, console_page_locators.check_button_on_likely_to_be_escalated_support_hub),
            message="likely to be escalated card  check button ",
        )

    def click_on_undo_button_likely_to_be_escalated_support_hub(self):
        """This method helps to click on undo button of likely to be escalated banner"""
        LOGGER.info("undo button in likely to be escalated banner in support hub")
        self.click_on_element(
            (By.XPATH, console_page_locators.undo_button_likely_escalated_case),
            message="likely to be escalated card  undo button ",
        )

    def check_for_presence_of_check_button_in_likely_to_be_escalated(self):
        LOGGER.info("check for presence of check button in likely escalated in support hub")
        if self.is_element_visible(
            (By.XPATH, console_page_locators.check_button_on_likely_to_be_escalated_support_hub )):
            return True
        else:
            return False

    def check_for_you_took_care_of_it_text_in_likely_escalated_banner(self):
        """This method helps to check that you took care of it text is displayed
        in likely to be escalated banner support hub  once clicking on check button"""
        LOGGER.info("you took care of it text is displayed after click on  check button")
        return self.is_element_visible(
            (By.XPATH, console_page_locators.likely_to_be_cards_banner_support_hub))

    def check_the_presence_of_few_second_ago_in_first_escalation_tab(self):
        LOGGER.info("check for presence of on few second ago in the escalation tab")
        return self.is_element_visible(
            (By.XPATH, console_page_locators.few_second_ago_on_first_tab))

