"""This module is  focuses on  creating reusable method the Agents management page  """
__author__ = "Neha Jha"
__copyright__ = "Copyright (C) 2021 SupportLogic"

import logging
import time

from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from pom_library.pom_base import PomBase
from locators import customer_management_locator, agents_management_locator
from pom_library.helper_methods import HelperMethods

LOGGER = logging.getLogger(__name__)


class CustomerManagementPage(HelperMethods):
    """
    This class has all the actions that can be done in customer  page
    """

    # declaring the driver to use it in overall page
    def __init__(self, driver):
        self.driver = driver
        PomBase.__init__(self, self.driver)
        self.actions = ActionChains(driver)
        self.wait = WebDriverWait(driver, 60)




    def get_text_search_result(self):
        """ This method helps to get the text of the agent name from the  search result"""


        customer_name=self.get_element_text_or_value(
            (By.XPATH,customer_management_locator.agents_name_search_result),timeout=10,
            message="agent name is not visible",
        )
        LOGGER.info(f"agent name in search result : {customer_name}")
        return customer_name


    def get_text_profile_customer(self):
        """ This method helps to get the text of agents name in profile page"""
        LOGGER.info(".......Fetching the customer name from customer insight profile .......")
        customer_name = self.get_element_text_or_value(
            (By.XPATH, customer_management_locator.agents_name_profile), timeout=30,
            message="agent name is not visible",
        )
        LOGGER.info(f" customer name in the customer insight profile is{customer_name}")
        return customer_name


    def get_case_count_on_tabs(self, tab_name):
        """ This method helps to get the backlog cases"""
        case_count = self.get_element_text_or_value(
            (By.XPATH, customer_management_locator.get_case_count_on_tabs.format(tab_name=tab_name.value)),
            message=f"Failed to get case count {tab_name.value}",
        )
        LOGGER.info(f"case count on {tab_name} is {case_count}")
        return case_count

    def check_present_cases_open_tab(self):
        """This method helps to checks for  cases is present in
        open tab  click on the open cases to check the support hub is displayed or not """
        try:
            check_for_first_cased_in_open_tab= self.wait.until(
                EC.visibility_of_element_located(
                    (By.XPATH, customer_management_locator.open_cases)
                )
            ).is_displayed()
            if check_for_first_cased_in_open_tab:
               self.click_on_element((By.XPATH, customer_management_locator.open_cases),
                                      timeout=10,
                                      message="failed to click on first case in open cases tab")
               return True
        except :

            LOGGER.info("NO cases in open tab")
            return False

    def click_individual_reporter(self):
        """ This method help to click on the individual reporter in search page """
        LOGGER.info("clicking on individual reporter ...........")

        self.click_on_element((By.XPATH, customer_management_locator.individual_reporter),
                              timeout=5,
                              message="failed to click on individual reporter")

    def click_individual_accounts(self):
        """This method help to click on the individual account on the search page"""
        LOGGER.info("clicking on individual accounts ...........")
        self.click_on_element((By.XPATH,customer_management_locator.individual_account),
            timeout=5,
        message="failed to click on individual account")

    def validate_profile_added_favorites(self):
        """This method helps to check whether profile is already to the favorites list or not """
        try:
            LOGGER.info(" Validate  that  customer is already added to favorite or not ")
            self.wait.until(
                EC.visibility_of_element_located(
                    (By.XPATH, customer_management_locator.favorite_star)
                )
            ).is_displayed()
            return True
        except :
            LOGGER.info("Customer  is not added to the favorites list")
            return False

    def click_favorites_agents_profile(self, agents_name):
        """This method helps to click on the favorites agents in favorites page
        ----------
        Parameters : name of the agents which is selected favorites"""
        LOGGER.info("clicking on the customer in fav list ................")
        favorites_profile = customer_management_locator.favorites_list.replace(
            "TEXT_PLACEHOLDER", agents_name
        )

        self.javascript_click_on_element((By.XPATH,
                               favorites_profile),
                              timeout=30,
                              message="failed to click on favorites agents")


    def click_virtual_group_agents(self):
        """ This method helps to click on the agents name from virtual group on expand """
        LOGGER.info("clicking on virtual group agents expand ........")
        time.sleep(1)
        self.javascript_click_on_element((By.XPATH,
         customer_management_locator.first_agents_name_on_expand_virtual_group),
                            timeout=30,
                message="failed to click on favorites agents")

    def get_text_virtual_group_agents(self):
        """ This method helps to get agents name from virtual group after expanding"""
        virtual_group = self.get_element_text_or_value(
            (By.XPATH,customer_management_locator.first_agents_name_on_expand_virtual_group), timeout=30,
            message="virtual group is not displayed",
        )
        LOGGER.info(f"virtual group name is {virtual_group}")
        return virtual_group

    def get_text_virtual_group_profile_name(self):
        """ This method helps to get agents name from the profile  in virtual account page"""

        virtual_group = self.get_element_text_or_value(
            (By.XPATH,  customer_management_locator.virtual_group_profile), timeout=30,
            message="virtual group is not displayed",
        )

        LOGGER.info(f"virtual group name is {virtual_group}")
        return virtual_group

    def check_if_agents_present_search_result(self):
        """This method helps to check the agents is presents in search result or not"""
        try:
            LOGGER.info("checking for customer is present on the search result.....")
            search_result = self.wait.until(
                EC.visibility_of_element_located(
                    (By.XPATH, agents_management_locator.search_result_agents)
                )
            ).is_displayed()
            if search_result:
                LOGGER.info("client is present on the search result")
                return True

        except Exception:
            LOGGER.info("No client is founded in search result")
            return False

    def click_add_favorites(self):
        """This method helps to click on the star icon to add or remove  the agents in favorites list"""
        LOGGER.info("clicking on star icon in customer profile")

        self.click_on_element((By.XPATH,
                 customer_management_locator.add_favorites_profile),
                                         timeout=30,
                                         message="failed to click on favorites agents")
    def virtual_account_group_data(self):
        try:
            """This method checks for virtual account and group data is loaded or not"""
            self.driver.find_element(
                By.XPATH, 
                customer_management_locator.virtual_group_account_data
            ).is_displayed()
            return True

        except Exception:
            LOGGER.info("No data displayed in virtual data page ")
            return False

    def virtual_account_pop_up_close(self):
        """This method helps to click on virtual account pop up close"""

        try:
            self.javascript_click_on_element((By.XPATH,
                    customer_management_locator.cross_button_in_virtual_account_pop_up),
                timeout=5,
                 message="failed to click on favorites agents")
        except:
            pass

    def click_on_tab(self, tab_name):
        """Click on the given content tab"""
        LOGGER.info(f"...clicking on  {tab_name} ....")
        time.sleep(2)
        self.click_on_element((By.XPATH,
            customer_management_locator.click_on_tabs.format(tab_name=tab_name.value)),
            timeout=30,
            message=f"failed to click on {tab_name}")

    def checks_for_customer_profile_displayed_or_not(self):
        """This method helps to check for customer insight page have any case or not"""
        try:
           LOGGER.info(".....Checking for customer insight page have  any date or not.....")
           customer_profile=self.wait.until(
               EC.visibility_of_element_located(
                   (By.XPATH, customer_management_locator.agents_name_profile)
               )
           ).is_displayed()
           if customer_profile:
               LOGGER.info("customer insight page have case on it")
               return True

        except Exception:
            LOGGER.info("customer insight page not have any data on it ")
            return False

    def search_customers(self, customer_name):
        """This method helps to search the agents name in the search box
        ---------------
        agent_name : name of the agents which need to be search"""
        LOGGER.info(f".........searching {customer_name} in customer page in search box.........")
        self.pass_value_to_element(
            customer_name, (By.XPATH, customer_management_locator.search_input)
        )

    def check_search_result(self):
        """This method helps to check search result box  is displayed or not"""
        LOGGER.info("checking for search result  box is displayed ")
        search_result_locator = self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, customer_management_locator.search_header)
            )
        ).is_displayed()
        if search_result_locator:
            LOGGER.info("Search result box  is displayed")
            return True
        else:
            LOGGER.info("Search result box is not displayed")
            return False

    def get_most_recently_search_customer_name(self):
        """This method helps to fetch most recently search customer name"""

        LOGGER.info("Fetching mostly recently search customer name........ ")

        customer_name = self.get_element_text_or_value(
            (By.XPATH, customer_management_locator.recent_search_in_customer_insight), timeout=10,
            message="mostily recently search customer id not visible",
        )
        LOGGER.info(f"recently search customer name : {customer_name}")
        return customer_name

    def click_on_recently_search_customer_name(self):
        """This method helps to
        click on_recently search customer name"""
        LOGGER.info("clicking on recently search customer name ")
        self.click_on_element((By.XPATH,
            customer_management_locator.recent_search_in_customer_insight),
            timeout=5,
            message="failed to click on recently search customer name")

    def get_number_of_notes_count_in_customer_insight(self):
        """This method helps to click on notes
        count in the customer insight page"""

        LOGGER.info("fetching the customer notes count ")
        count_of_customer_notes=self.get_element_text_or_value((By.XPATH,
            customer_management_locator.customer_insight_notes_count),
            timeout=5,
            message="failed to fetch the customer notes ")
        return count_of_customer_notes


    def add_customer_notes_in_customer_insight_page(self,notes):
        """This method helps us to add customer note in  customer insight page """
        LOGGER.info("Adding  note to the  customer ........")

        text = self.wait.until(
            EC.element_to_be_clickable((By.XPATH, customer_management_locator.add_notes_text_area))
        )
        text.send_keys(notes)


    def checks_for_customer_is_present_in_fav_list(self, agents_name):
        """This method helps to  checks for customer is present on the fav list or not
        ----------
        Parameters : name of the customer name which is selected favorites"""
        try:
            time.sleep(2)
            favorites_profile = customer_management_locator.favorites_list.replace(
                "TEXT_PLACEHOLDER", agents_name
            )
            fav_customer=self.driver.find_element(
                By.XPATH, 
                favorites_profile
            ).is_displayed()
            if fav_customer:
                return  True
        except NoSuchElementException:
            return False


    def checks_for_customer_profile_have_fav_button_or_not(self):
        """This method helps to checks for  star button is displayed or not in customer profile  """
        try:
            LOGGER.info(" checking for star button is displayed ................  ")
            self.driver.find_element(
                By.XPATH, 
                customer_management_locator.add_favorites_profile
            ).is_displayed()


            return True
        except NoSuchElementException :
            LOGGER.info("customer not have star button")
            return False

    def checks_for_add_notes_text_box_displayed_or_not_in_customer_profile(self):
        """This method helps to checks for   notes is displayed or not in customer profile  """
        try:
            LOGGER.info(" checking for add notes is displayed ................  ")
            add_notes_text_box=self.wait.until(
                EC.visibility_of_element_located(
                    (By.XPATH, customer_management_locator.add_notes_text_area)
                )
            ).is_displayed()
            if add_notes_text_box:
                return True
        except :
            LOGGER.info("Customer   do not have text area")
            return False


    def check_favorites_agents_is_displayed(self, agents_name):
        """This method helps to click on the favorites agents in favorites page
        ----------
        Parameters : name of the agents which is selected favorites"""
        LOGGER.info("checking  on the customer in fav list ................")
        favorites_profile = customer_management_locator.favorites_list.replace(
            "TEXT_PLACEHOLDER", agents_name
        )
        try:
            fav_profile = self.wait.until(
                EC.visibility_of_element_located(
                    (By.XPATH, favorites_profile)
                )
            ).is_displayed()
            if fav_profile :
                return True

        except:
            LOGGER.info("account is not added to fav")
            return False


    def check_present_cases_recently_closed_tab(self):
        """This method helps to checks for  cases is present in
        open tab  click on the open cases to check the support hub is displayed or not """
        try:
            open_cases = self.wait.until(
                EC.visibility_of_element_located(
                    (By.XPATH, customer_management_locator.open_cases)
                )
            ).is_displayed()
            if open_cases:
               self.click_on_element((By.XPATH, customer_management_locator.open_cases),
                                      timeout=10,
                                      message="failed to click on first case in open cases tab")
               return True
        except :

            LOGGER.info("NO cases in open and close tab")
            return False

    def click_recently_closed_tab(self):
        """ This method help to click on the recently closed tab in overview """
        LOGGER.info("clicking on recently closed tab...........")

        self.click_on_element((By.XPATH, customer_management_locator.recently_closed_tab_in_overview),
                              timeout=30,
                              message="failed to click on recently closed tab in overview")

    def click_on_back_to_fav_customer_page(self):
        """ This method help to click on fav customer button  """
        LOGGER.info("clicking on back to favorites customer button ...........")

        self.click_on_element((By.XPATH, customer_management_locator.back_to_Favorite_Customers_in_favorites_page ),
                              timeout=30,
                              message="failed to click on back to fav customer pager")

    def click_open_tab_in_overview(self):
        """ This method help to click on the open in overview """
        LOGGER.info("clicking on open  tab...........")

        self.click_on_element((By.XPATH, customer_management_locator.open_tab_in_overview),
                              timeout=30,
                              message="failed to click on open in overview")

    def check_present_of_open_tab_in_overview_tab(self):
        """This method helps to Check for the present of open tab on overview cases"""
        LOGGER.info("Check for the present of open tab on overview cases")
        open_tab = self.is_element_visible((By.XPATH, customer_management_locator.open_tab_in_overview))
        if open_tab:
            LOGGER.info("open tab is present in over view tab")
            return True
        else:
            LOGGER.info("open tab is present is  overview tab")
            return False

    def check_present_of_recently_close_tab_in_overview_tab(self):
        """This method helps to Check for the present of recently close tab on overview cases """
        LOGGER.info("Check for the present of recently close tab on overview cases")
        recently_closed = self.is_element_visible((By.XPATH, customer_management_locator.recently_closed_tab_in_overview))
        if recently_closed:
            LOGGER.info("recently close is present in over view tab")
            return True
        else:
            LOGGER.info("recently close is present is overview tab")
            return False

    def check_present_of_recent_cases_in_overview_tab(self):
        """This method helps to Check for the present of recent cases tab on overview cases """
        LOGGER.info("Check for the present of recently close tab on overview cases")
        recent_cases = self.is_element_visible((By.XPATH, customer_management_locator.recent_case) )
        if recent_cases:
            LOGGER.info("recent cases is present in over view tab")
            return True
        else:
            LOGGER.info("recent cases is present is closed overview tab")
            return False

    def click_on_new_case_sections_first_column_in_the_customer_favourites_table(self):
        """ This method help to click first tab in new case section"""
        LOGGER.info("clicking on first tab in new case section .....")
        self.click_on_element((By.XPATH, customer_management_locator.click_on_first_tab_new_cases_section_in_fav),
                              timeout=30,
                              message="failed to click on first tab in new case section")

    def click_on_first_case_from_list_of_cases_display_on_click_on_new_case_sections(self):
        """ This method help to click first case from list pf cases"""
        LOGGER.info("clicking on first case from list of cases")
        self.click_on_element((By.XPATH, customer_management_locator.click_on_first_case_from_the_list_of_cases),
                              timeout=30,
                              message="failed to click on first case from case list pop up")

    def click_on_sort_button_in_overview(self):
        LOGGER.info("clicking on sort button in overview")
        self.click_on_element((By.XPATH, customer_management_locator.sort_button_in_overview),
                              timeout=30,
                              message="clicking on sort button in over view page")

    def get_first_case_id_in_overview_tabs(self):
        """ This method helps to first case id present on over view tabs"""
        LOGGER.info("....... get first case id in over view tabs .......")
        customer_name = self.get_element_text_or_value(
            (By.XPATH, customer_management_locator.get_first_case_id_overview_tabs), timeout=30,
            message="get first overview  case count",
        )
        return customer_name
    def get_number_of_count_present_on_overview_tabs(self):
        """ This method helps get number of count present on overview tabs"""
        LOGGER.info("....... get first case count of cases.......")
        case_count = self.driver.find_elements(
            By.XPATH, customer_management_locator.get_number_of_case_present_in_overview_tabs
        )
        return case_count

    def get_number_of_day_before_ticket_is_created(self):
        """This method get the number of days before ticket is created """
        ticket_open_for = self.get_element_text_or_value(
            (By.XPATH, customer_management_locator.created_ticket_open_for), timeout=40,
            message="number of day ticket is open for",
        )
        LOGGER.info(ticket_open_for)

        return ticket_open_for

    def click_on_first_chart_section_vertical_dots(self):
        """ This method help to click on region section vertical dots"""
        LOGGER.info("clicking on regions section verticals dots ")
        self.click_on_element((By.XPATH, customer_management_locator.click_on_chart_section_vertical_dots_overview_tab),
                              timeout=30,
                              message="failed to click on  chart section verticals dots")
        self.click_on_element((By.XPATH, customer_management_locator.export_button),
                             timeout=30,
                             message="failed to click on  export download button")

