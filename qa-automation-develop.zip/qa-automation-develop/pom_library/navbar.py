"""This page contains all the reusable methods. All methods in this page are user-type
irrespective."""
__author__ = "Praveen Nagajothi"
__copyright__ = "Copyright (C) 2021 SupportLogic"

import logging
from typing import Union

from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support import expected_conditions as ec

from enums import ControlCenterMenuItem, NavbarItem
from locators import common_locators as cl
from locators import navbar_locators as nl
from pom_library.helper_methods import HelperMethods

LOGGER: logging.Logger = logging.getLogger(__name__)


class Navbar(HelperMethods):
    def is_navbar_minimized(self) -> bool:
        """
        Checks the visibility state of the left navigation bar

        Returns
        -------
            True when navbar is collapsed
        """
        toggle_button: WebElement = self.driver.find_element(
            By.CSS_SELECTOR, nl.navbar_visibility_toggle_css
        )
        if toggle_button.get_attribute("data-state") == "expanded":
            return False
        else:
            return True

    def toggle_navbar_visibility(
        self, minimize: bool = False, silent: bool = False
    ) -> None:
        """
        Clicks the arrow button in the navbar to minimize or expand the navbar.

        Parameters
        ----------
        minimize: bool, optional
            collapses the navbar when set to True (default is False)
        silent: bool, optional
            turns off logging when set to True (default is False)
        """
        log_level: int = logging.WARNING if silent else logging.INFO
        logging.getLogger().setLevel(log_level)
        LOGGER.info("Toggling navbar visibility..")

        # exit the function if actual & expected state are the same
        if self.is_navbar_minimized() is minimize:
            return

        self.click_on_element(
            (By.CSS_SELECTOR, nl.navbar_visibility_toggle_css),
            message="Navbar toggle button is either not visible or enabled",
        )
        logging.getLogger().setLevel(logging.INFO)

    def has_control_center_enabled(self) -> bool:
        """
        Check if current user has access to control center

        Returns
        _______
            True if control center is displayed
        """
        self.wait.until(
            ec.visibility_of_element_located((By.CSS_SELECTOR, cl.user_menu_icon_css))
        )
        return self.is_element_visible((By.CSS_SELECTOR, nl.control_center_button_css))

    def click_control_center(self) -> None:
        """Clicks the control center in the navbar to reveal the options popup."""
        if not self.has_control_center_enabled():
            raise Exception("Control center is not enabled")

        self.click_on_element(
            (By.CSS_SELECTOR, nl.control_center_button_css),
            message="Control center is either not enabled or visible",
        )

    def has_navbar_module(
        self, page_name: Union[NavbarItem, ControlCenterMenuItem]
    ) -> bool:
        """
        Check if current user has access to the given module in the navbar.

        This method works for all the modules present in the navbar and the control
        center menu items

        Parameters
        ----------
        page_name: NavbarItem | ControlCenterMenuItem
            Enum representation of the navbar page display text

        Returns
        -------
            True if module/control center item is accessible
        """
        self.wait.until(
            ec.visibility_of_element_located((By.CSS_SELECTOR, cl.user_menu_icon_css))
        )

        locator: str = nl.navbar_item_css.format(page_name=page_name.value)
        if isinstance(page_name, ControlCenterMenuItem):
            locator = nl.control_center_item_css.format(name=page_name.value)
            self.click_control_center()

        return self.is_element_visible((By.CSS_SELECTOR, locator))

    def navigate_to_navbar_page(self, page_name: NavbarItem) -> str:
        """
        Navigate to the given module from the navbar (only if it is not the currently
        active page).

        Parameters
        __________
        page_name: NavbarItem
            Enum representation of the navbar page

        Returns
        _______
        str
            url of the expected page
        """
        LOGGER.info(f"Navigating to {page_name.name} page..")

        if not self.has_navbar_module(page_name):
            raise Exception(f"{page_name.name} is not present or visible")

        locator: str = nl.navbar_item_css.format(page_name=page_name.value)
        navbar_element: WebElement = self.driver.find_element(By.CSS_SELECTOR, locator)

        # check if current selected page is same as expected
        if navbar_element.get_attribute("aria-current"):
            return self.driver.current_url

        self.click_on_element((By.CSS_SELECTOR, locator))
        return self.driver.current_url

    def navigate_to_control_center_item(self, menu_item: ControlCenterMenuItem) -> str:
        """
        Navigate to the given module from the control center (only if it is not the
        currently active page).

        Parameters
        __________
        menu_item: ControlCenterMenuItem
            Enum representation of the navbar page

        Returns
        _______
        str
            url of the expected page
        """
        LOGGER.info(f"Navigating to {menu_item.name} page..")

        if not self.has_navbar_module(menu_item):
            raise Exception(f"{menu_item.name} is not present or visible")

        locator: str = nl.control_center_item_css.format(name=menu_item.value)
        cc_menu_item: WebElement = self.driver.find_element(By.CSS_SELECTOR, locator)

        # check if current selected page is same as expected
        if cc_menu_item.get_attribute("aria-current"):
            return self.driver.current_url

        self.click_on_element((By.CSS_SELECTOR, locator))
        return self.driver.current_url
