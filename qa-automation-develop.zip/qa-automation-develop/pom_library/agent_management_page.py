"""This module is  focuses on  creating reusable method the Agents management page  """
__author__ = "Neha Jha"
__copyright__ = "Copyright (C) 2021 SupportLogic"

import logging
import time

from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait

from locators import agents_management_locator, oldlocators
from pom_library.helper_methods import HelperMethods
from pom_library.pom_base import PomBase

LOGGER = logging.getLogger(__name__)


class AgentsPage(HelperMethods):
    """
    This class has all the actions that can be done in Agents page
    """

    # declaring the driver to use it in overall page
    def __init__(self, driver):
        self.driver = driver

        PomBase.__init__(self, self.driver)
        self.actions = ActionChains(driver)
        self.wait = WebDriverWait(driver, 60)

    def click_support_engineer(self):
        """ This method helps to click on support engineer in nav bar"""
        time.sleep(2)
        support_engineer_locator = self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, agents_management_locator.support_engineer_nav_bar)
            )
        )

        self.driver.execute_script("arguments[0].click();", support_engineer_locator)

    def search_agents(self, agent_name):
        """This method helps to search the agents name in the search box
        ---------------
        agent_name : name of the agents which need to be search"""
        LOGGER.info(f".........searching {agent_name} in customer page in search box.........{agents_management_locator.search_input}")
        self.pass_value_to_element(
            agent_name, (By.XPATH, agents_management_locator.search_input)
        )

    def check_search_result(self):
        """This method helps to check search result box  is displayed or not"""
        LOGGER.info("checking for search result  box is displayed ")
        search_result_locator = self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, agents_management_locator.search_header)
            )
        ).is_displayed()
        if search_result_locator:
            LOGGER.info("Search result box  is displayed")
            return True
        else:
            LOGGER.info("Search result box is not displayed")
            return False

    def click_agents_search_result(self):
        """ This method helps to click on the agent name  from the search result """
        LOGGER.info(".....clicking on first customer from the search result")
        support_engineer_locator = self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, agents_management_locator.search_result_agents)
            )
        )
        self.driver.execute_script("arguments[0].click();", support_engineer_locator)

    def click_search_button(self):
        """ This method helps to click on the search button  in agents pages"""
        search_button_locator = self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, agents_management_locator.search_support_engineer)
            )
        )
        self.actions.move_to_element(search_button_locator).click().perform()

    def check_agents_support_hub(self):
        """This method helps to check agent support hub is displayed  or not  on click agents  name """
        search_result_locator = self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, agents_management_locator.agents_data)
            )
        ).is_displayed()
        if search_result_locator:
            LOGGER.info("Search result is displayed")
            return True
        else:
            LOGGER.info("Search result is not displayed")
            return False

    def click_virtual_team(self):
        """ This method helps to click virtual team on the nav bar """
        virtual_team_locator = self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, agents_management_locator.virtual_team)
            )
        )
        self.driver.execute_script("arguments[0].click();", virtual_team_locator)

    def click_virtual_team_expand(self):
        """This method helps to click virtual team expand arrow to display  list of virtual org"""
        virtual_team_locator = self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, agents_management_locator.virtual_team_expand)
            )
        )
        self.actions.move_to_element(virtual_team_locator).click().perform()

    def click_virtual_agents(self):
        """This method helps to click on agents in virtual team """
        virtual_agents_locator = self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, agents_management_locator.virtual_team_agent)
            )
        )
        self.driver.execute_script("arguments[0].click();", virtual_agents_locator)

    def check_search_page_loaded(self):
        """This method helps to check for search page is loaded  or not when search button is click on the nav bar"""

        search_agents_locator = self.wait.until(
            EC.visibility_of_element_located((By.XPATH, agents_management_locator.search_box))
        ).is_displayed()
        if search_agents_locator:
            LOGGER.info("Search agents page is loaded")
            return True
        else:
            LOGGER.info("Search agents page is not loaded")
            return False

    def check_agents_profile(self):
        """This method helps to checks for agents profile is loaded  """
        time.sleep(2)
        search_agents_locator = self.wait.until(
            EC.visibility_of_element_located(
                (By.XPATH, agents_management_locator.agents_profile)
            )
        ).is_displayed()
        if search_agents_locator:
            LOGGER.info("agent profile is loaded ")
            return True
        else:
            LOGGER.info("agents profile  is not loaded")
            return False

    def get_first_case_id_in_list(self):
        """This method helps to get text of the case id in backlog"""
        id_support_hub = self.wait.until(
            EC.element_to_be_clickable((By.XPATH, agents_management_locator.support_id))
        ).text
        LOGGER.info(f"{id_support_hub}  is displayed on list ")
        return id_support_hub

    def check_if_agents_present_search_result(self):
        """This method helps to check the agents is presents in search result or not"""
        try:

            search_results = self.wait.until(
                EC.element_to_be_clickable(
                    (By.XPATH, agents_management_locator.search_result_agents)
                )
            )
            if search_results.is_displayed():
                return True

        except Exception:
            LOGGER.info("No client is founded in search result")
            return False

    def validate_search_result(self, agent_name):
        """ This method helps to validate  search result is displayed or not based on the search input """

        self.search_agents(agent_name)
        result = self.check_search_result()
        if result:
            LOGGER.info("Search result is displayed ")
        else:
            LOGGER.info("Search result is not displayed")
        agents_search_result = self.check_if_agents_present_search_result()
        if agents_search_result:
            self.click_agents_search_result()
            support_hub = self.check_agents_profile()
            if support_hub:
                LOGGER.info("agent profile is loaded ")
                return True
            else:
                LOGGER.info("agents profile  is not loaded")
                return False
        else:
            LOGGER.info("No cases founded in backlog")
            return False

    def click_search_icon(self):
        """ This method helps to click on search button in agents page """
        support_engineer_locator = self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, agents_management_locator.search_support_engineer)
            )
        )
        self.driver.execute_script("arguments[0].click();", support_engineer_locator)

    def click_individual_agents(self):
        """ This method helps to click on the individual agents on the search result"""
        support_engineer_locator = self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, agents_management_locator.individual_agent)
            )
        )
        self.driver.execute_script("arguments[0].click();", support_engineer_locator)

    def validate_support_engineer_page(self):
        """ This method  helps to validate that support engineer page is loaded or not """

        support_engineer_page = self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, agents_management_locator.search_support_engineer)
            )
        ).is_displayed()
        if support_engineer_page:
            LOGGER.info("Support engineer page is loaded")
            return True
        else:
            LOGGER.info("Support engineer page is not loaded")
            return False



    def get_case_count_on_tabs(self,tab_name):
        """ This method helps to get the backlog cases"""
        case_count=self.get_element_text_or_value(
            (By.XPATH, agents_management_locator.case_count_on_tabs.format(tab_name=tab_name.value)),
            message=f"Failed to click on {tab_name.value}",
            )
        LOGGER.info(f"case count on {tab_name} is {case_count}")
        return case_count
    def click_on_back_button(self):
        """This method helps to click on the back button in search page"""
        try:
            self.mouse_click_on_element(
                (By.XPATH,
                 agents_management_locator.back_button),
                message=" click on save delete or cancel button", )
        except:
            logging.info("search bar is already display")

    def get_text_of_first_virtual_team_name(self):
        """This method helps to get the text the of the first virtual team"""

        virtual_team_name = self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, agents_management_locator.first_virtual_team_name_in_virtual_team_module)
            )
        ).text
        LOGGER.info(f" first virtual team name is {virtual_team_name}")
        return virtual_team_name

    def get_count_of_virtual_team_virtual_org_present_on_virtual_team(self):
        """This method helps to  get the count of virtual team and virtual org"""

        try:
            list_virtual_team_present_on_dashboard = self.driver.find_elements(
                By.XPATH, agents_management_locator.virtual_team_and_virtual_count)
            no_of_list = len(list_virtual_team_present_on_dashboard)
            LOGGER.info(f"virtual team present on the dash board {no_of_list}")
            return no_of_list
        except:
            return  0
    def click_on_create_virtual_team(self):
        """This method helps to click on create the virtual team """
        create_virtual_team= self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, agents_management_locator.click_on_virtual_team)
            )
        )
        self.driver.execute_script("arguments[0].click();", create_virtual_team)

    def click_on_global_team(self):
        """This method helps to click on the global team"""
        global_team = self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, agents_management_locator.global_team)
            )
        )
        self.driver.execute_script("arguments[0].click();", global_team)

    def enter_virtual_account_name_text_box(self,vt_name):
        """This method helps to enter new virtual  account name in the text box"""
        virtual_account_name = self.driver.find_element(
            By.XPATH,
            oldlocators.input_box_to_pass_va_name_id
        )
        virtual_account_name.send_keys(vt_name)

    def click_on_next_button(self):
       """
        This method helps to click on the next button
       Returns
       -------

       """
       self.driver.find_element(
           By.XPATH,
           oldlocators.next_button_va_creation_xpath
       ).click()

    def search_agents_while_creating_virtual_team(self):
        """This method helps to search the agents while creating virtual team"""
        self.driver.find_element(
            By.XPATH,
            agents_management_locator.search_agents_while_creating_virtual_team
        ).send_keys("a")

    def select_two_agents_while_creating_virtual_team(self):
        """ This method helps to click on the two agents in the virtual teams"""
        my_elem_a = self.driver.find_element(By.XPATH, agents_management_locator.first_agents_while_creating_virtual_team)
        my_elem_b = self.driver.find_element(By.XPATH, agents_management_locator.second_agents_creating_virtual_team)
        ActionChains(self.driver).click(my_elem_a).perform()
        ActionChains(self.driver).click(my_elem_b).perform()

    def click_on_create_button(self):
        """This method helps to create button"""
        self.driver.find_element(
            By.XPATH, 
            oldlocators.create_button_va_xpath
        ).click()

    def hover_over_vt_click_on_delete_icon(self):
        """This method helps to mouse over the first virtual team and click on the delete icon"""
        virtual_team = self.wait.until(
            EC.visibility_of_element_located(
                (By.XPATH, agents_management_locator.first_virtual_team_name_in_virtual_team_module)
            )
        )
        self.actions.move_to_element(virtual_team).perform()
        delete_button = self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, agents_management_locator.delete_icon_virtual_team)
            )
        )
        self.driver.execute_script("arguments[0].click();", delete_button)

    def click_on_delete_button_delete_pop_up(self):
        """This method helps to click on the delete button on delete pop up"""
        self.driver.find_element(
            By.XPATH, 
            agents_management_locator.delete_button_on_delete_pop_up
        ).click()

    def validate_agents_is_favorites_or_not(self):
        """This method helps to check whether profile is already to the favorites list or not """
        try:
            self.driver.find_element(
                By.XPATH, 
                agents_management_locator.favorites_star_in_yellow
            ).is_displayed()
            LOGGER.info("already added to the favorites ")
            return True
        except NoSuchElementException:
            return False

    def click_on_favorites_star(self):
        """This method clicks on Favorite star """
        self.click_on_element(
            (By.XPATH, agents_management_locator.click_on_favorites_star),
            timeout=5,
            message="failed to click on favorite star",
        )


    def get_agent_name_in_agents_profile(self):
        """This method helps to get the agents name in the agents profile"""
        agents_name = self.get_element_text_or_value(
            (By.XPATH, agents_management_locator.agent_name_in_agent_insights)
        )
        return agents_name

    def click_favorite_icon_module(self):
        """ This method helps to click on  favorites button module button in agents page """
        support_engineer_locator = self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, agents_management_locator.favorite_module_in_agents_page )
            )
        )
        self.driver.execute_script("arguments[0].click();", support_engineer_locator)

    def validate_particular_favorite_agents_is_present_in_favorites_module(self, agents_name):
        """This method helps to click on the favorites agents in favorites page
        ----------
        Parameters : name of the agents which is selected favorites"""
        try:
            favorites_profile = agents_management_locator.favorites_agents_name_in_list.replace(
                "TEXT_PLACEHOLDER", agents_name
            )
            favorites_agents = self.wait.until(
                EC.visibility_of_element_located((By.XPATH, favorites_profile))
            ).is_displayed()
            if favorites_agents:
                return True
        except:
            return False


    def click_on_tab(self,tab_name):
        """Click on the given content tab"""
        self.mouse_click_on_element(
            (By.XPATH, agents_management_locator.click_on_tabs.format(tab_name=tab_name.value)),
            message=f"Failed to click on {tab_name.value}",
            )

    def click_on_first_agents_view_profile_button(self):
        """This method helps to click on view button of first agents in fav section"""
        self.click_on_element(
            (By.XPATH, agents_management_locator.first_agents_view_profile_button),
            message="failed to click first agents view button",
        )

    def get_first_agent_name_in_fav_section(self):
        """This method helps to get first  the agents name in the fav section"""
        agents_name = self.get_element_text_or_value(
            (By.XPATH, agents_management_locator.first_fav_agent_profile_name)
        )
        return agents_name


    def search_virtual_teams(self,virtual_team_name):
        """search the virtual team in search result"""
        self.pass_value_to_element(
            virtual_team_name,
            (By.XPATH, agents_management_locator.search_virtual_team ),
            message="failed to search virtual team name",
        )

    def click_on_first_virtual_team_in_virtual_team_dashboard_expand(self):
        """This method helps to click on first virtual team  to expand """
        self.click_on_element(
            (By.XPATH, agents_management_locator.click_on_expand_button_first_virtual_teams),
            message="failed to click on first expand button",
        )

    def get_number_of_agents_name_present_present_in_first_virtual_team(self):
        """This method helps to get number of agents name present the """
        agents_name_in_virtual_team = []
        get_number_agents_name_present_in_dashboard = self.driver.find_elements(By.XPATH, agents_management_locator.
                                                                                         agents_name_on_expanding_first_virtual_teams)
        for i in get_number_agents_name_present_in_dashboard:
            case_list_name = i.text
            agents_name_in_virtual_team.append(case_list_name)
        return agents_name_in_virtual_team

    def click_on_particular_agent_name_in_virtual_team(self,agent_name):
        """This method helps to click on the particular agent name in virtual teams"""
        self.click_on_element(
            (By.XPATH, agents_management_locator.click_on_particular_agent_in_virtual_team_on_expand_state.replace("agents_name",agent_name)),
            message="failed to click on first expand button",
        )


    def validate_whether_particular_virtual_team_is_set_in_dashboard(self,agent_name):
        my_team=self.is_element_visible(
            (By.XPATH,
             agents_management_locator.validate_whether_particular_virtual_team_is_set_in_dashboard.replace("agents_name",
                                                                                                         agent_name)),
            )
        if my_team:
            LOGGER.info(f"{agent_name} is selected in my dash board" )
            return True
        else :
            LOGGER.info(f"{agent_name} is not selected in my dash board")
            return False

    def click_on_select_dashboard_icon_of_virtual_team(self,agent_name):
        """This method helps to click on the particular agent name in virtual teams"""
        LOGGER.info("hover over first virtual team first virtual account")

        self.hover_on_element((By.XPATH,agents_management_locator.virtual_team_name.replace("agents_name",agent_name)))
        self.javascript_click_on_element(
            (By.XPATH, agents_management_locator.set_virtual_team_in_dashboard_button.replace("agents_name",agent_name)),
            message=" failed to set virtual team icon",
        )



    def click_on_delete_vt(self):
        """This method helps to click on first virtual team  to expand """
        self.click_on_element(
            (By.XPATH, agents_management_locator.virtual_delete_vt),
            message="failed to click  on delete virtual delete",
        )

    def validate_you_have_not_chosen_your_team_yet_banner_in_vt_module(self):
        """This method is to check for banner in virtual team is displayed or not"""
        my_team=self.is_element_visible(
            (By.XPATH,
             agents_management_locator.vt_banner))
        if my_team:
            LOGGER.info("you have not chosen your team yet banner in vt module is displayed" )
            return True
        else :
            LOGGER.info("you have not chosen your team yet banner in vt module is not displayed")
            return False

    def click_on_personal_team(self):
        """This method helps to click on the primary team"""
        self.click_on_element(
            (By.XPATH, agents_management_locator.primary_team),
            message="failed to click on primary team",
        )

    def click_go_to_my_dashboard_button_pop_up(self):
        """This method helps to click on the go to my dashboard button in go to my dash board pop up """
        self.click_on_element(
            (By.XPATH, agents_management_locator.go_to_my_dash_board),
            message="failed to click on go to my dashboard button in ",
        )
    def cross_icon_on_go_to_my_dashboard_pop_up(self):
        """This method helps to click on the cross icon go to my dashboard button in go to my dash board pop up """
        self.click_on_element(
            (By.XPATH, agents_management_locator.cross_icon_on_go_to_my_dash_board_pop_up),
            message="failed to click on cross icon go to my dash board icon",
        )

    def search_on_agents_on_fav(self,search_text):
        """This method helps to search text in agents fav section"""
        self.pass_value_to_element(
            search_text,
            (By.XPATH, agents_management_locator.search_box_in_fav),
        )

    def get_first_name_from_the_search_result_in_fav_modules(self):
        """This method helps to get the first name from the search result which is enable"""
        agents_name = self.get_element_text_or_value(
            (By.XPATH, agents_management_locator.search_result_fav_section)
        )
        return agents_name

    def click_on_first_name_the_search_result_in_fav_modules_to_add_fav(self):
        """This method helps to click on first name in the search result """
        self.click_on_element(
            (By.XPATH, agents_management_locator.search_result_fav_section ),
            message="failed to click on first name from search text",
        )


    def double_click_on_date_in_out_of_office_calendar(self,today_date):
        """This method help to double click on date  in out of office calendar """
        select_date_on_calendar = self.driver.find_element(
            By.XPATH, 
            agents_management_locator.calendar_date.replace("date",str(today_date))
        )

        self.actions.double_click(select_date_on_calendar).perform()

    def selecting_the_reason_option_of_out_of_office(self, reason):
        """This method helps to click on the particular agent name in virtual teams"""
        self.click_on_element(
            (By.XPATH,
             agents_management_locator.option_to_select_in_out_of_office_pop_up.replace("option", reason)),
            message="failed to select reason in out of office ")
    def click_on_save_delete_cancel_option_button(self,option):
        """This method helps to click on the particular agent name in virtual teams"""
        self.click_on_element(
            (By.XPATH,
             agents_management_locator.save.replace("option",option)),
            message=" click on save delete or cancel button",)

    def hover_over_date_in_out_of_office_calendar(self,today_date):
        """This method hover over today date to display tool tip"""
        self.hover_on_element((By.XPATH, agents_management_locator.calendar_date.replace("date",str(today_date))))

    def validate_whether_red_dot_is_displayed_on_date(self, date):
        """This method helps to verify that red dots displayed or not"""
        LOGGER.info("checks for  red dots display on today date")
        red_dot_on_date = self.is_element_visible(
            (By.XPATH,
             agents_management_locator.red_dot_on_date.replace("date", str(date))),
        )
        if red_dot_on_date:
            return True
        else:
            return False

    def single_click_on_date_in_out_of_office_calendar(self, today_date):
        """This method help to single  click on date  in out of office calendar """
        LOGGER.info("single click on date in out of office")
        for i in range(5):
            time.sleep(1)
            self.mouse_click_on_element(
                (By.XPATH,
                 agents_management_locator.calendar_date.replace("date", str(today_date))),
                message=" clicking on date in  out of office calendar")
