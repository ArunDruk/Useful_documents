"""
A collection of reusable methods that perform specific actions on the case assignment
page
"""
from __future__ import annotations

__author__ = "Praveen Nagajothi"
__copyright__ = "Copyright (C) 2022 SupportLogic"

import logging

from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webelement import WebElement

from enums import DeleteShift, ShiftOccurrence
from locators import shift_calendar_locators as scl
from pom_library.helper_methods import HelperMethods

LOGGER: logging.Logger = logging.getLogger(__name__)


class ShiftCalendar(HelperMethods):
    def go_to_shift_assignment_page(self) -> None:
        LOGGER.info("Navigating to shift assignment page..")
        self.click_on_element(
            (By.CSS_SELECTOR, scl.settings_button_css),
            message="Failed to click on settings button in ICA",
        )

    def go_back_to_case_assignment_page(self) -> None:
        LOGGER.info("Navigating back to case assignment page..")
        self.click_on_element(
            (By.CSS_SELECTOR, scl.back_to_case_assignment_css),
            message="Failed to go back to the case assignment page",
        )

    def open_add_new_shift_popup(self) -> None:
        LOGGER.info("Opening add new shift popup..")
        self.click_on_element(
            (By.CSS_SELECTOR, scl.add_new_shift_button_css),
            message="Failed to open Add new shift popup",
        )

    def click_cancel_button(self) -> None:
        LOGGER.info("Clicking on Cancel button in Add shift popup..")
        self.click_on_element(
            (By.CSS_SELECTOR, scl.cancel_button_css),
            message="Failed to click Cancel button in Add shift popup",
        )

    def click_create_button(self) -> None:
        LOGGER.info("Clicking on Create button in Add shift popup..")
        self.click_on_element(
            (By.CSS_SELECTOR, scl.create_button_css),
            message="Failed to click Create button in Add shift popup",
        )

    def click_save_button(self) -> None:
        LOGGER.info("Clicking on Save button in Edit shift popup..")
        self.click_on_element(
            (By.CSS_SELECTOR, scl.save_button_css),
            message="Failed to click Save button in Add shift popup",
        )

    def enter_shift_name(self, shift_name: str) -> None:
        LOGGER.info(f"Entering `{shift_name}` in new shift name textbox..")
        self.pass_value_to_element(
            shift_name,
            (By.CSS_SELECTOR, scl.shift_name_textbox_css),
            message="Failed to enter shift name",
        )

    def change_default_assignment_hour(self, from_: str = None, to: str = None) -> None:
        if from_:
            LOGGER.info(f"Entering {from_} in assignment hours From textbox..")
            self.pass_value_to_element(
                from_, (By.CSS_SELECTOR, scl.assignment_hours_from_textbox_css)
            )
        if to:
            LOGGER.info(f"Entering {to} in assignment hours To textbox..")
            self.pass_value_to_element(
                to, (By.CSS_SELECTOR, scl.assignment_hours_to_textbox_css)
            )

    def change_default_working_hours(self, from_: str = None, to: str = None) -> None:
        if from_:
            LOGGER.info(f"Entering {from_} in working hours From textbox..")
            self.pass_value_to_element(
                from_, (By.CSS_SELECTOR, scl.working_hours_from_textbox_css)
            )
        if to:
            LOGGER.info(f"Entering {to} in working hours To textbox..")
            self.pass_value_to_element(
                to, (By.CSS_SELECTOR, scl.working_hours_to_textbox_css)
            )

    def check_assignment_hour_customize_checkbox(self) -> None:
        LOGGER.info("Checking assignment hours customize checkbox..")
        element: WebElement = self.driver.find_element(
            By.CSS_SELECTOR, scl.customize_assignment_hour_checkbox_input_css
        )
        if element.get_attribute("data-status") == "checked":
            return
        self.click_on_element(
            (By.CSS_SELECTOR, scl.customize_assignment_hour_checkbox_css),
            message="Failed to check assignment hours customize checkbox",
        )

    def check_working_hour_customize_checkbox(self) -> None:
        LOGGER.info("Checking working hours customize checkbox..")
        element: WebElement = self.driver.find_element(
            By.CSS_SELECTOR, scl.customize_working_hour_checkbox_input_css
        )
        if element.get_attribute("data-status") == "checked":
            return
        self.click_on_element(
            (By.CSS_SELECTOR, scl.customize_working_hour_checkbox_css),
            message="Failed to check working hours customize checkbox",
        )

    def change_custom_assignment_hour_by_day(
        self, day_time: dict[ShiftOccurrence, tuple[str, str]], slot: int = 0
    ) -> None:
        for weekday, time_ in day_time.items():
            LOGGER.info(f"Changing assignment hour of {weekday.name} to {time_}..")
            from_, to = time_
            day: str = weekday.name.lower()
            from_field_locator: str = (
                scl.assignment_hours_custom_from_textbox_css.format(day=day, slot=slot)
            )
            to_field_locator: str = scl.assignment_hours_custom_to_textbox_css.format(
                day=day, slot=slot
            )
            self.pass_value_to_element(from_, (By.CSS_SELECTOR, from_field_locator))
            self.pass_value_to_element(to, (By.CSS_SELECTOR, to_field_locator))

    def change_custom_working_hour_by_day(
        self, day_time: dict[ShiftOccurrence, tuple[str, str]], slot: int = 0
    ) -> None:
        for weekday, time_ in day_time.items():
            LOGGER.info(f"Changing working hour of {weekday.name} to {time_}..")
            from_, to = time_
            day: str = weekday.name.lower()
            from_field_locator: str = scl.working_hours_custom_from_textbox_css.format(
                day=day, slot=slot
            )
            to_field_locator: str = scl.working_hours_custom_to_textbox_css.format(
                day=day, slot=slot
            )
            self.pass_value_to_element(from_, (By.CSS_SELECTOR, from_field_locator))
            self.pass_value_to_element(to, (By.CSS_SELECTOR, to_field_locator))

    def add_time_slot_to_assignment_hours(
        self, day: ShiftOccurrence, num_of_slots: int
    ) -> None:
        LOGGER.info(f"Add {num_of_slots} assignment hour slots to {day.name}..")
        for slot in range(num_of_slots):
            plus_button_locator: str = scl.assignment_hours_add_slot_button_css.format(
                day=day.name.lower(), slot=slot
            )
            self.click_on_element((By.CSS_SELECTOR, plus_button_locator))

    def add_time_slot_to_working_hours(
        self, day: ShiftOccurrence, num_of_slots: int
    ) -> None:
        LOGGER.info(f"Add {num_of_slots} working hour slots to {day.name}..")
        for slot in range(num_of_slots):
            plus_button_locator: str = scl.working_hours_add_slot_button_css.format(
                day=day.name.lower(), slot=slot
            )
            self.click_on_element((By.CSS_SELECTOR, plus_button_locator))

    def remove_time_slot_from_assignment_hours(
        self, day: ShiftOccurrence, index_of_slot_to_remove: int
    ) -> None:
        LOGGER.info(
            f"Removing {index_of_slot_to_remove} assignment hour slot from {day.name}.."
        )
        to_field_locator: str = scl.assignment_hours_remove_slot_button_css.format(
            day=day.name.lower(), slot=index_of_slot_to_remove
        )
        remove_btn_locator: str = scl.assignment_hours_remove_slot_button_css.format(
            day=day.name.lower(), slot=index_of_slot_to_remove
        )
        self.hover_on_element((By.CSS_SELECTOR, to_field_locator))
        self.click_on_element((By.CSS_SELECTOR, remove_btn_locator))

    def remove_time_slot_from_working_hours(
        self, day: ShiftOccurrence, index_of_slot_to_remove: int
    ) -> None:
        LOGGER.info(
            f"Removing {index_of_slot_to_remove} working hour slot from {day.name}.."
        )
        to_field_locator: str = scl.working_hours_custom_to_textbox_css.format(
            day=day.name.lower(), slot=index_of_slot_to_remove
        )
        remove_btn_locator: str = scl.working_hours_remove_slot_button_css.format(
            day=day.name.lower(), slot=index_of_slot_to_remove
        )
        self.hover_on_element((By.CSS_SELECTOR, to_field_locator))
        self.click_on_element((By.CSS_SELECTOR, remove_btn_locator))

    def check_does_not_repeat_checkbox(self) -> None:
        LOGGER.info("Checking 'Does not repeat' checkbox..")
        element: WebElement = self.driver.find_element(
            By.CSS_SELECTOR, scl.does_not_repeat_checkbox_input_css
        )
        if element.get_attribute("data-status") == "checked":
            return
        self.click_on_element(
            (By.CSS_SELECTOR, scl.does_not_repeat_checkbox_css),
            message="Failed to check 'Does not repeat' checkbox",
        )

    def uncheck_does_not_repeat_checkbox(self) -> None:
        LOGGER.info("Unchecking 'Does not repeat' checkbox..")
        element: WebElement = self.driver.find_element(
            By.CSS_SELECTOR, scl.does_not_repeat_checkbox_input_css
        )
        if element.get_attribute("data-status") == "unchecked":
            return
        self.click_on_element(
            (By.CSS_SELECTOR, scl.does_not_repeat_checkbox_css),
            message="Failed to uncheck 'Does not repeat' checkbox",
        )

    def is_occurrence_selected(self, day: ShiftOccurrence) -> bool:
        LOGGER.info(f"Checking occurrence {day.name} selection state..")
        occurrence_state: str = self.get_element_attribute(
            "data-status",
            (By.CSS_SELECTOR, scl.occurrence_weekday_css.format(day=day.value)),
            message=f"Failed to get `data-status` value of {day.name}",
        )
        return occurrence_state == "checked"

    def select_occurrence(
        self, weekdays: ShiftOccurrence | tuple[ShiftOccurrence, ...]
    ) -> None:
        days = weekdays
        if isinstance(weekdays, ShiftOccurrence):
            days = (weekdays,)
        LOGGER.info(f"Selecting occurrences {[day.name for day in days]}..")
        for day in days:
            if self.is_occurrence_selected(day):
                continue
            self.click_on_element(
                (By.CSS_SELECTOR, scl.occurrence_weekday_css.format(day=day.value)),
                message=f"Failed to select occurrence {day.name}",
            )

    def deselect_occurrence(
        self, weekdays: ShiftOccurrence | tuple[ShiftOccurrence, ...]
    ) -> None:
        days = weekdays
        if isinstance(weekdays, ShiftOccurrence):
            days = (weekdays,)
        LOGGER.info(f"Deselecting occurrences {[day.name for day in days]}..")
        for day in days:
            if not self.is_occurrence_selected(day):
                continue
            self.click_on_element(
                (By.CSS_SELECTOR, scl.occurrence_weekday_css.format(day=day.value)),
                message=f"Failed to deselect occurrence {day.name}",
            )

    def hover_on_shift_bar(self, shift_name: str) -> None:
        LOGGER.info(f"Hovering on '{shift_name}' assignment bar..")
        shift_bar_locator: str = scl.individual_shift_bar_css.format(
            shift_name=shift_name
        )
        self.scroll_into_view((By.CSS_SELECTOR, shift_bar_locator))
        self.hover_on_element((By.CSS_SELECTOR, shift_bar_locator))

    def click_on_shift_bar(self, shift_name: str) -> None:
        LOGGER.info(f"Clicking '{shift_name}' assignment bar..")
        shift_bar_locator: str = scl.individual_shift_bar_css.format(
            shift_name=shift_name
        )
        self.click_on_element((By.CSS_SELECTOR, shift_bar_locator))

    def click_shift_details_tooltip_edit_button(self) -> None:
        LOGGER.info("Clicking edit button in shift details tooltip..")
        self.mouse_click_on_element(
            (By.CSS_SELECTOR, scl.details_tooltip_edit_button_css),
            message="Failed to click Edit button in shift details tooltip",
        )

    def click_shift_details_tooltip_delete_button(self) -> None:
        LOGGER.info("Clicking delete button in shift preview popup..")
        self.mouse_click_on_element(
            (By.CSS_SELECTOR, scl.details_tooltip_delete_button_css),
            message="Failed to click Delete button in shift details tooltip",
        )

    def click_edit_popup_delete_button(self) -> None:
        LOGGER.info("Clicking Delete button in edit shift popup..")
        self.click_on_element(
            (By.CSS_SELECTOR, scl.delete_button_css),
            message="Failed to click Delete button in edit shift popup",
        )

    def click_delete_popup_cancel_button(self) -> None:
        LOGGER.info("Clicking Cancel button in edit shift popup..")
        self.click_on_element(
            (By.CSS_SELECTOR, scl.delete_dialog_cancel_button_css),
            message="Failed to click Cancel button in edit shift popup",
        )

    def click_delete_popup_delete_button(self) -> None:
        LOGGER.info("Clicking Delete button in delete shift popup..")
        self.click_on_element(
            (By.CSS_SELECTOR, scl.delete_dialog_delete_button_css),
            message="Failed to click Delete button in delete shift popup",
        )

    def click_delete_popup_radio_button(self, option: DeleteShift) -> None:
        LOGGER.info(f"Selecting {option.name} option in delete shift popup..")
        radio_button_locator: str = scl.delete_dialog_option_radio_button_css.format(
            option=option.value
        )
        self.click_on_element(
            (By.CSS_SELECTOR, radio_button_locator),
            message=f"Failed to select {option.value} option in delete shift popup",
        )

    def has_shift(self, shift_name: str) -> bool:
        LOGGER.info("")
        shift_bar_locator: str = scl.individual_shift_bar_css.format(
            shift_name=shift_name
        )
        try:
            return bool(self.driver.find_element(By.CSS_SELECTOR, shift_bar_locator))
        except NoSuchElementException:
            return False
