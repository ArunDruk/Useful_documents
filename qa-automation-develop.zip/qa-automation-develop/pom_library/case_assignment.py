"""A collection of reusable methods that perform specific actions on the case assignment page"""
__author__ = "Praveen Nagajothi"
__copyright__ = "Copyright (C) 2021 SupportLogic"

import logging
import random

from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webelement import WebElement

from enums import CaseAssignmentTabs
from locators import case_assignment_locators as cal
from pom_library.helper_methods import HelperMethods

LOGGER: logging.Logger = logging.getLogger(__name__)


class CaseAssignment(HelperMethods):
    def switch_to_tab(self, tab_name: CaseAssignmentTabs) -> None:
        """
        Switch between the tabs in the case list section.

        Parameters
        ----------
        tab_name: CaseAssignmentTabs
            partial testid of the destination tab
        """
        LOGGER.info(f"Switching to tab {tab_name}..")
        self.click_on_element(
            (By.CSS_SELECTOR, cal.case_list_tab_css.format(tab_name=tab_name.value)),
            message=f"{tab_name.name} tab is either not enabled or visible",
        )

    def check_visibility_of_case_list(self) -> bool:
        """
        Check whether the case list section is present and visible by checking the case
        cards.

        Returns
        -------
        bool
            True if case list section is visible
        """
        LOGGER.info("Checking for presence of case list..")
        return self.is_element_visible((By.CSS_SELECTOR, cal.case_cards_in_list_css))

    def get_random_case_card(self) -> WebElement:
        """
        Finds and returns a random case card from the case list section.

        Returns
        -------
        WebElement
            Random case card
        """
        LOGGER.info("Getting random case card..")
        case_cards: list[WebElement] = self.driver.find_elements(
            By.CSS_SELECTOR, cal.case_cards_in_list_css
        )
        random_card: WebElement = random.choice(case_cards)
        return random_card

    def click_on_first_case_card(self) -> None:
        """Clicks on the first case card in the current selected tab"""
        LOGGER.info("Clicking on case card from list..")
        self.click_on_element(
            (By.CSS_SELECTOR, cal.case_cards_in_list_css),
            message="Case card is either not visible or disabled"
        )

    def get_customer_name_from_selected_card(self) -> str:
        LOGGER.info("Getting customer name from selected card..")
        customer_name: str = self.get_element_text_or_value(
            (By.CSS_SELECTOR, cal.selected_card_customer_name_css),
            message="Customer name is not visible or present"
        )
        LOGGER.info(f"Customer name in card: {customer_name}")
        return customer_name

    def get_case_id_from_selected_card(self) -> str:
        LOGGER.info("Getting case id from selected card..")
        customer_name: str = self.get_element_text_or_value(
            (By.CSS_SELECTOR, cal.selected_card_case_id_css),
            message="Case ID is not visible or present"
        )
        LOGGER.info(f"Case ID in card: {customer_name}")
        return customer_name

    def get_case_subject_from_selected_card(self) -> str:
        LOGGER.info("Getting case subject from selected card..")
        customer_name: str = self.get_element_text_or_value(
            (By.CSS_SELECTOR, cal.selected_card_case_subject_css),
            message="Case subject is not visible or present"
        )
        LOGGER.info(f"Case subject in card: {customer_name}")
        return customer_name

    def get_case_priority_from_selected_card(self) -> str:
        LOGGER.info("Getting case priority from selected card..")
        customer_name: str = self.get_element_text_or_value(
            (By.CSS_SELECTOR, cal.selected_card_case_priority_css),
            message="Case priority is not visible or present"
        )
        LOGGER.info(f"Case priority in card: {customer_name}")
        return customer_name

    def get_customer_name_from_summary(self) -> str:
        LOGGER.info("Getting customer name from summary view..")
        customer_name: str = self.get_element_text_or_value(
            (By.CSS_SELECTOR, cal.summary_view_customer_name_css),
            message="Customer name is not visible or present"
        )
        LOGGER.info(f"Customer name in summary: {customer_name}")
        return customer_name

    def get_case_id_from_summary(self) -> str:
        LOGGER.info("Getting case id from summary view..")
        customer_name: str = self.get_element_text_or_value(
            (By.CSS_SELECTOR, cal.summary_view_case_id_css),
            message="Case ID element is not visible or present"
        )
        LOGGER.info(f"Case ID in summary: {customer_name}")
        return customer_name

    def get_case_subject_from_summary(self) -> str:
        LOGGER.info("Getting case subject from summary view..")
        customer_name: str = self.get_element_text_or_value(
            (By.CSS_SELECTOR, cal.summary_view_case_title_css),
            message="Case subject element is not visible or present"
        )
        LOGGER.info(f"Case subject in summary: {customer_name}")
        return customer_name

    def get_case_priority_from_summary(self) -> str:
        LOGGER.info("Getting case priority from summary view..")
        customer_name: str = self.get_element_text_or_value(
            (By.CSS_SELECTOR, cal.summary_view_case_priority_css),
            message="Case priority element is not visible or present"
        )
        LOGGER.info(f"Case priority in summary: {customer_name}")
        return customer_name
