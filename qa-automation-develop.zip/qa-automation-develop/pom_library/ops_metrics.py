"""
A collection of reusable methods that perform specific actions on the Ops Metrics page.
"""
from __future__ import annotations

__author__ = "Praveen Nagajothi"
__copyright__ = "Copyright (C) 2021 SupportLogic"

import logging
import time

from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support import expected_conditions as ec

from enums import (
    ChartStatusFilter, ChartTypes, EfficiencySubTabs, GroupByCustomFields,
    GroupByStandardFields, OpsMetricsType, SlaSubTabs,
)
from locators import ops_metrics_locators as oml
from pom_library.helper_methods import HelperMethods

LOGGER: logging.Logger = logging.getLogger(__name__)


class OpsMetricsPage(HelperMethods):
    def navigate_to_section_card(self, section_name: OpsMetricsType) -> None:
        """
        Navigate to a section available in the operational metrics overview page

        Parameters
        ----------
        section_name: OpsMetricsType
            Name of the section to navigate to
        """
        section_card = oml.overview_section_card_css.format(section=section_name.value)
        if self.is_element_visible(
            (By.CSS_SELECTOR, oml.overview_card_view_details_button_css)
        ):
            section_card = f"{section_card} {oml.overview_card_view_details_button_css}"
        self.click_on_element(
            (By.CSS_SELECTOR, section_card),
            message=f"{section_name.value} section is either not visible or disabled",
        )

    def navigate_to_section_tab(self, section_name: OpsMetricsType) -> None:
        """
        Navigate to a section available in the operational metrics details page

        Parameters
        ----------
        section_name: OpsMetricsType
            Name of the section to navigate to
        """
        section_card = oml.details_section_tab_css.format(section=section_name.value)
        self.click_on_element(
            (By.CSS_SELECTOR, section_card),
            message=f"{section_name.value} section is either not visible or disabled",
        )

    def go_to_overview_page(self):
        LOGGER.info("Navigating back to overview page..")
        self.click_on_element(
            (By.CSS_SELECTOR, oml.back_to_overview_css),
            message="Failed to click back to overview button",
        )

    def get_current_section_name(self) -> str:
        """
        Fetches the name of the section that is currently selected in the details view.

        Returns
        _______
        str
            Name of section in focus
        """
        return self.get_element_text_or_value(
            (By.CSS_SELECTOR, oml.section_in_focus_css),
            message="Failed to get active section name",
        )

    def get_active_escalation_count(self) -> str:
        """Gets the count of active escalations from efficiency tab"""
        count: WebElement = self.wait.until(
            ec.visibility_of_element_located((By.XPATH, oml.active_escalations_count)),
            message="Active escalation count text is not visible",
        )
        return count.text

    def switch_to_sub_tab(self, tab_name: SlaSubTabs | EfficiencySubTabs):
        LOGGER.info(f"Switching to sub tab {tab_name.value}..")
        self.click_on_element(
            (By.CSS_SELECTOR, oml.section_sub_tabs_css.format(tab_name=tab_name.value))
        )

    def get_current_selected_sub_tab(self):
        LOGGER.info("Getting current selected sub tab name..")
        return self.get_element_text_or_value(
            (By.CSS_SELECTOR, oml.current_selected_sub_tab_css),
            message="Failed to get current selected sub tab text",
        )

    def get_current_chart_filter(self, chart_name: str):
        LOGGER.info(f"Getting selected filter by value for {chart_name} chart..")
        dropdown = oml.chart_filter_dropdown_css.format(chart_name=chart_name)
        return self.get_element_text_or_value(
            (By.CSS_SELECTOR, dropdown),
            message=f"Failed to get selected filter value for {chart_name}",
        )

    def reset_to_default_charts(self):
        LOGGER.info("Resetting to default charts..")
        self.click_on_element(
            (By.CSS_SELECTOR, oml.reset_to_default_charts_css),
            message="Failed to reset to default charts",
        )
        self.wait.until(
            ec.visibility_of_element_located((By.CSS_SELECTOR, oml.chart_name_css))
        )

    def get_available_chart_names(self):
        try:
            elements: list[WebElement] = self.driver.find_elements(
                By.CSS_SELECTOR, oml.chart_name_css
            )
            return [element.text for element in elements]
        except NoSuchElementException:
            return []

    def filter_chart_by_status(self, chart_name: str, status: ChartStatusFilter):
        if self.get_current_chart_filter(chart_name) == status.value:
            return

        dropdown: str = oml.chart_filter_dropdown_css.format(chart_name=chart_name)
        self.click_on_element(
            (By.CSS_SELECTOR, dropdown),
            message=f"Failed to click {chart_name} chart filter dropdown",
        )
        time.sleep(0.5)
        menu_option: str = oml.chart_filter_options_css.format(
            chart_name=chart_name, option=status.value
        )
        self.click_on_element(
            (By.CSS_SELECTOR, menu_option),
            message=f"Failed to click {status.value} in {chart_name} dropdown",
        )

    def open_chart_menu(self, chart_name: str):
        if not chart_name.lower().startswith("backlog"):
            dropdown_locator = oml.chart_filter_dropdown_css.format(
                chart_name=chart_name
            )
            self.scroll_into_view((By.CSS_SELECTOR, dropdown_locator))
            self.hover_on_element((By.CSS_SELECTOR, dropdown_locator))
        else:
            chart_name_locator = oml.chart_name.format(chart_name=chart_name)
            self.scroll_into_view((By.XPATH, chart_name_locator))
            self.hover_on_element((By.XPATH, chart_name_locator))
        self.click_on_element((By.XPATH, oml.chart_menu.format(chart_name=chart_name)))

    def edit_chart(self, chart_name: str):
        self.open_chart_menu(chart_name)
        self.click_on_element(
            (By.CSS_SELECTOR, oml.edit_chart_css.format(chart_name=chart_name)),
            message="Failed to click chart edit button",
        )

    def delete_chart(self, chart_name: str):
        self.open_chart_menu(chart_name)
        self.click_on_element(
            (By.CSS_SELECTOR, oml.delete_chart_css.format(chart_name=chart_name)),
            message="Failed to click chart delete button",
        )

    def open_add_chart_popover(self):
        LOGGER.info("Opening add new chart popover..")
        self.click_on_element(
            (By.CSS_SELECTOR, oml.add_chart_button_css),
            message="Failed to click on add chart button",
        )

    def group_cases_by(self, group_by: GroupByCustomFields | GroupByStandardFields):
        text: str = group_by.value
        LOGGER.info(f"Selecting '{text}' as case group by value..")

        locator = oml.add_chart_standard_field_item_css.format(field=text)
        if isinstance(group_by, GroupByCustomFields):
            locator = oml.add_chart_custom_field_item_css.format(field=text)
        self.click_on_element(
            (By.CSS_SELECTOR, locator),
            message=f"Failed to select '{text}' as group by option",
        )

    def switch_to_add_chart_custom_tab(self):
        LOGGER.info("Switching to Add chart popover custom tab..")
        self.click_on_element((By.CSS_SELECTOR, oml.add_chart_custom_tab_css))

    def switch_to_add_chart_general_tab(self):
        LOGGER.info("Switching to Add chart popover general tab..")
        self.click_on_element((By.CSS_SELECTOR, oml.add_chart_general_tab_css))

    def choose_chart_type(self, type_: ChartTypes):
        text: str = type_.value
        LOGGER.info(f"Choosing {text} as chart type..")
        locator = oml.add_chart_popover_choose_type_css.format(type=text)
        if oml.add_chart_disabled_chart_type_css in self.get_element_attribute(
            "class", (By.CSS_SELECTOR, locator)
        ):
            raise Exception(f"A chart with type {text} already exists")
        self.click_on_element(
            (By.CSS_SELECTOR, locator), message=f"Failed to choose {text} as chart type"
        )

    def save_new_chart(self):
        self.click_on_element(
            (By.CSS_SELECTOR, oml.add_chart_submit_button_css),
            message="Failed to click add button in new chart popover",
        )

    def add_sla_chart(
        self,
        group_by: GroupByCustomFields | GroupByStandardFields,
        chart_type: ChartTypes,
        arrange_by: str = None
    ):
        LOGGER.info(f"Add new {self.get_current_selected_sub_tab()} chart")
        self.open_add_chart_popover()
        self.group_cases_by(group_by)
        self.choose_chart_type(chart_type)
        if arrange_by and chart_type is ChartTypes.VERTICAL:
            option_type = oml.group_or_arrange_cases_by_options.format(value=arrange_by)
            self.click_on_element(
                (By.XPATH, option_type),
                message=f"Failed to select {arrange_by} as arrange by option",
            )
        self.save_new_chart()

    def add_custom_efficiency_chart(
        self,
        group_by: GroupByCustomFields | GroupByStandardFields,
        chart_type: ChartTypes,
    ):
        LOGGER.info(f"Add new {self.get_current_selected_sub_tab()} chart")
        self.open_add_chart_popover()
        self.group_cases_by(group_by)
        self.choose_chart_type(chart_type)
        self.save_new_chart()

    def add_general_efficiency_chart(self, chart_name: str, is_trendline: bool = False):
        LOGGER.info(
            f"Adding {chart_name} chart in " f"{self.get_current_selected_sub_tab()}.."
        )

        chart_name = chart_name.replace(" ", "_").lower()
        _type = ChartTypes.TREND.value if is_trendline else ChartTypes.VERTICAL.value
        locator = oml.add_chart_general_type_css.format(
            chart_name=chart_name, type=_type
        )
        self.open_add_chart_popover()
        if self.is_element_visible(
            (By.CSS_SELECTOR, oml.add_chart_general_tab_css), timeout=3
        ):
            self.switch_to_add_chart_general_tab()
        self.click_on_element(
            (By.CSS_SELECTOR, locator),
            message=f"Failed to select {chart_name} in add chart popover",
        )
        self.save_new_chart()

    def add_client_experience_chart(self, chart_name: str, chart_type: ChartTypes):
        LOGGER.info(f"Adding {chart_name} chart in Client Experience section..")
        chart_name = chart_name.replace(" ", "_").lower()
        locator = By.CSS_SELECTOR, oml.add_chart_choose_name_css.format(
            chart_name=chart_name
        )
        self.open_add_chart_popover()
        self.click_on_element(
            locator, message=f"Failed to select {chart_name} in add chart popover",
        )
        self.choose_chart_type(chart_type)
        self.save_new_chart()

    def delete_all_existing_charts(self):
        LOGGER.info("Deleting all existing user added charts..")
        chart_names: list[str] = self.get_available_chart_names()
        LOGGER.info(chart_names)
        if not chart_names:
            return None
        for name in chart_names:
            self.delete_chart(name)

    def click_settings_in_overview_card(self, section_name: OpsMetricsType) -> None:
        card_locator: str = oml.overview_section_card_css.format(
            section=section_name.value
        )
        settings_button_locator: str = oml.overview_section_settings_css.format(
            section=section_name.value
        )

        self.hover_on_element((By.CSS_SELECTOR, card_locator))
        self.click_on_element((By.CSS_SELECTOR, settings_button_locator))

    def switch_sla_default_chart_to_trendline(self, chart_name: str):
        self.click_on_element((By.XPATH, oml.default_chart_menu))
        menu_option_locator = oml.sla_show_trend_chart_css.format(chart_name=chart_name)
        self.click_on_element((By.CSS_SELECTOR, menu_option_locator))

    def switch_sla_default_chart_to_donut(self, chart_name: str):
        self.click_on_element((By.XPATH, oml.default_chart_menu))
        menu_option_locator = oml.sla_show_donut_chart_css.format(chart_name=chart_name)
        self.click_on_element((By.CSS_SELECTOR, menu_option_locator))

    def get_chart_id(self, chart_name: str) -> str:
        """
        Fetches the chart's `data-id` attribute value

        Parameters
        ----------
        chart_name: str
            Name of the chart whose id should be fetched

        Returns
        -------
        str
            data-id value of the given chart name
        """
        LOGGER.info(f"Getting {chart_name} chart data-id..")
        return self.driver.find_element(
            By.XPATH, oml.chart_id.format(chart_name=chart_name)
        ).get_attribute("data-id")

    def export_default_chart(
        self, chart_name, only_csv: bool = False, only_image: bool = False
    ):
        csv_checkbox_locator = oml.export_csv_option_checkbox_css.format(
            chart_name=chart_name
        )
        img_checkbox_locator = oml.export_image_option_checkbox_css.format(
            chart_name=chart_name
        )
        csv_checkbox_state = self.driver.find_element(
            By.CSS_SELECTOR, csv_checkbox_locator
        ).get_attribute("data-status")
        image_checkbox_state = self.driver.find_element(
            By.CSS_SELECTOR, img_checkbox_locator
        ).get_attribute("data-status")

        if (only_image and csv_checkbox_state == "checked") or (
            only_csv and csv_checkbox_state == "unchecked"
        ):
            locator = oml.export_csv_option_css.format(chart_name=chart_name)
            self.click_on_element((By.CSS_SELECTOR, locator))
        if (only_csv and image_checkbox_state == "checked") or (
            only_image and image_checkbox_state == "unchecked"
        ):
            locator = oml.export_image_option_css.format(chart_name=chart_name)
            self.click_on_element((By.CSS_SELECTOR, locator))

        export_btn_locator = oml.export_button_css.format(chart_name=chart_name)
        self.click_on_element((By.CSS_SELECTOR, export_btn_locator))
