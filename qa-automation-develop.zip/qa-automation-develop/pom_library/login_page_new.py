"""
A collection of reusable methods that perform specific actions on the sign in page.
"""

import logging

from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webdriver import WebDriver

from locators import login_page_locators as lp
from pom_library.helper_methods import HelperMethods

LOGGER: logging.Logger = logging.getLogger(__name__)


class LoginPage(HelperMethods):
    def __init__(self, driver: WebDriver) -> None:
        super().__init__(driver, auto_login=False)

    def choose_email_sign_in(self) -> None:
        """Selects email as the sign in option"""
        LOGGER.info("Choosing email sign in option..")
        self.click_on_element(
            (By.ID, lp.email_sign_in_option_id),
            message="Failed to click on 'sign in via email' link",
        )

    def enter_username(self, username: str) -> None:
        """
        Enters value into the email field

        Parameters
        ----------
        username: str
            account username or email id
        """
        LOGGER.info(f"Entering '{username}' in email field..")
        self.pass_value_to_element(
            username,
            (By.ID, lp.email_textbox_id),
            message="Failed to populate email field",
        )

    def enter_password(self, password: str) -> None:
        """
        Enters value into the password field

        Parameters
        ----------
        password: str
            account password for the given username
        """
        LOGGER.info(f"Entering '{'*' * len(password)}' in password field..")
        self.pass_value_to_element(
            password,
            (By.ID, lp.password_textbox_id),
            message="Failed to populate password field",
        )

    def click_sign_in_button(self) -> None:
        """Clicks the sign-in button"""
        LOGGER.info("Clicking 'sign in' button..")
        self.click_on_element(
            (By.ID, lp.sign_in_button_id), message="Failed to click 'sign in' button"
        )

    def login_with_email(self, username: str, password: str) -> None:
        """
        Log in to the application via email using the provided username & password
        values.

        Parameters
        ----------
        username: str
            account username or email id
        password: str
            account password for the given username
        """
        LOGGER.info("Signing in via email in progress..")

        self.choose_email_sign_in()
        self.enter_username(username)
        self.enter_password(password)
        self.click_sign_in_button()
