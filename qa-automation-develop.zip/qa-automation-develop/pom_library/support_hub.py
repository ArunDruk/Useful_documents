"""
A collection of reusable methods that perform specific actions on the SupportHub modal
window.
None of these methods in this file will not work on the SupportHub page.
"""
__author__ = "Praveen Nagajothi"
__copyright__ = "Copyright (C) 2021 SupportLogic"

import logging
import time
from typing import Union

from selenium.common.exceptions import ElementNotVisibleException, TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support import expected_conditions as ec

from enums import CasePriority, CaseStatus
from locators import support_hub_locators as shl
from pom_library.helper_methods import HelperMethods

LOGGER: logging.Logger = logging.getLogger(__name__)


class SupportHub(HelperMethods):
    def check_visibility_of_support_hub(self) -> bool:
        """
        Checks for visibility of support hub modal window. Visibility means that the
        element is not only displayed but also has a height and width that is greater
        than 0.

        Returns
        -------
        bool
            True if support hub is visible
        """
        LOGGER.info("Checking support hub visibility...")
        return self.is_element_visible(
            (By.CSS_SELECTOR, shl.support_hub_modal_window_css)
        )

    def close_support_hub_window(self) -> None:
        """Close the support hub modal window. For this method to work properly, the
        support hub needs to be open and visible."""
        LOGGER.info("Closing the support hub modal window...")
        self.click_on_element(
            (By.CSS_SELECTOR, shl.close_support_hub_button_css),
            message="Support hub close button is either not visible or enabled.",
        )

    def open_case_in_salesforce(self) -> None:
        """Open case in salesforce from SupportHub modal window"""
        LOGGER.info("Opening case in salesforce..")
        self.click_on_element(
            (By.CSS_SELECTOR, shl.open_in_salesforce_css),
            message="Open in Salesforce button is not visible or enabled",
        )

    def copy_case_url(self) -> None:
        """Copy the case URL for current open case in SupportHub"""
        LOGGER.info("Copying case URL..")
        self.click_on_element(
            (By.CSS_SELECTOR, shl.copy_url_button_css),
            message="Copy URL button is not visible or enabled",
        )

    def get_customer_name(self) -> str:
        """Get the customer name from case displayed in SupportHub modal window"""
        LOGGER.info("Getting customer name..")
        return self.get_element_text_or_value(
            (By.CSS_SELECTOR, shl.customer_name_css),
            message="Customer name element is not visible or present",
        ).strip()

    def get_case_id(self) -> str:
        """Get the case id from case displayed in SupportHub modal window"""
        LOGGER.info("Getting Case ID..")
        return self.get_element_text_or_value(
            (By.CSS_SELECTOR, shl.case_id_css),
            message="Case ID element is not visible or present",
        ).strip()

    def get_case_title(self) -> str:
        """Get the case title from SupportHub modal window"""
        LOGGER.info("Getting case title..")
        return self.get_element_text_or_value(
            (By.CSS_SELECTOR, shl.case_subject_css),
            message="Case Title element is not visible or present",
        ).strip()

    def get_reporter_name(self) -> str:
        """Get the reporter name from SupportHub modal window"""
        LOGGER.info("Getting case owner..")
        return self.get_element_text_or_value(
            (By.CSS_SELECTOR, shl.reporter_name_css),
            message="Reporter Name element is not visible or present",
        ).strip()

    def get_agent_name(self) -> str:
        """Get the current assigned agent name from SupportHub modal window"""
        LOGGER.info("Getting assigned agent..")
        return self.get_element_text_or_value(
            (By.CSS_SELECTOR, shl.case_owner_name_css),
            message="Agent Name element is not visible or present",
        ).strip()

    def get_agent_icon_text(self) -> str:
        """Get the initials in round icon of current assigned agent from SupportHub
        modal window"""
        LOGGER.info("Getting initials of assigned agent from round icon..")
        return self.get_element_text_or_value(
            (By.CSS_SELECTOR, shl.case_owner_icon_text_css),
            message="Agent Round Icon is not visible or present",
        )[:2].strip()

    def get_case_status(self) -> str:
        """Get the current case status from SupportHub modal window"""
        LOGGER.info("Getting case status..")
        return self.get_element_text_or_value(
            (By.CSS_SELECTOR, shl.current_case_status_css), timeout=30,
            message="Case status pill is not visible or present",
        ).strip()

    def get_case_priority(self) -> str:
        """Get the current case priority from SupportHub modal window"""
        LOGGER.info("Getting case priority..")
        return self.get_element_text_or_value(
            (By.CSS_SELECTOR, shl.current_case_priority_css),
            message="Case priority pill is not visible or present",
        ).strip()

    def is_favorite_client(self) -> bool:
        """An expectation for checking that a client is marked as favorite or not from
        SupportHub modal window"""
        LOGGER.info("Checking client favorite status..")
        star: WebElement = self.driver.find_element(
            By.CSS_SELECTOR, shl.favorite_client_button_css
        )
        return star.get_attribute("data-status") == "checked"

    def mark_as_favorite(self) -> None:
        """Add a client as favorite from SupportHub modal window"""
        LOGGER.info("Marking client as favorite..")
        if self.is_favorite_client():
            LOGGER.info("Client is already marked as favorite")
            return
        self.click_on_element(
            (By.CSS_SELECTOR, shl.favorite_client_button_css),
            message="The favorite button is not visible or enabled",
        )

    def mark_as_not_favorite(self) -> None:
        """Remove a client as favorite from SupportHub modal window"""
        LOGGER.info("Marking client as not favorite..")
        if not self.is_favorite_client():
            LOGGER.info("Client is already not favorite")
            return
        self.click_on_element(
            (By.CSS_SELECTOR, shl.favorite_client_button_css),
            message="The favorite button is not visible or enabled",
        )

    def assign_new_agent(self, agent_name: str) -> str:
        """
        Assign a new agent to the case opened in SupportHub modal window.

        Parameters
        ----------
        agent_name: str
            Name of the agent to search for & assign

        Returns
        -------
        str
            Empty if given agent is invalid, else the assigned agents' name.
        """
        LOGGER.info("Assigning new agent..")
        LOGGER.info("Clicking on current agent name..")
        self.click_on_element(
            (By.CSS_SELECTOR, shl.case_owner_name_css),
            timeout=10,
            message="Failed to click on agent name",
        )

        LOGGER.info(f"Searching for agent '{agent_name}'..")
        if self.is_element_visible((By.CSS_SELECTOR, shl.case_owner_search_tab_css)):
            self.click_on_element((By.CSS_SELECTOR, shl.case_owner_search_tab_css))

        self.pass_value_to_element(
            agent_name,
            (By.CSS_SELECTOR, shl.agent_search_box_css),
            message="Agent search textbox is not visible",
        )

        if self.is_element_visible(
            (By.CSS_SELECTOR, shl.agent_search_no_results_css), timeout=5
        ):
            LOGGER.info(f"No results found for agent '{agent_name}'")
            return ""
        first_agent_suggestion: str = self.get_element_text_or_value(
            (By.XPATH, shl.agent_search_suggestion_list_item),
            timeout=5,
            message="Agent search suggestions is either not visible or present",
        ).strip()
        if self.get_agent_name() not in first_agent_suggestion:
            self.click_on_element(
                (By.XPATH, shl.agent_search_suggestion_list_item), timeout=10
            )
            self.click_on_element((By.XPATH, shl.agent_search_suggestion_assign_button))
        return first_agent_suggestion

    def edit_case_priority(self, priority: CasePriority) -> None:
        """
        Change case priority from SupportHub modal window

        Parameters
        ----------
        priority: CasePriority
            An enum representation of the expected priority
        """
        LOGGER.info("Changing case priority..")
        if self.get_case_priority() == priority.value:
            LOGGER.info(f"Case priority is already '{priority.value}'")
            return

        self.click_on_element(
            (By.CSS_SELECTOR, shl.edit_case_priority_css),
            message="Case priority pill is not visible or present",
        )

        self.click_on_element(
            (By.CSS_SELECTOR, shl.case_field_dropdown_css),
            message="Failed to trigger case priority dropdown",
        )

        locator: str = shl.case_field_options_css.format(option=priority.value)
        self.click_on_element(
            (By.CSS_SELECTOR, locator),
            message=f"Failed to select '{priority.value}' from case priority",
        )

        self.click_on_element(
            (By.CSS_SELECTOR, shl.case_field_save_button_css),
            message="Failed to save case priority",
        )

        self.wait.until(
            ec.text_to_be_present_in_element(
                (By.CSS_SELECTOR, shl.current_case_priority_css), priority.value
            )
        )

    def edit_case_status(self, status: CaseStatus) -> None:
        """
        Change case status from SupportHub modal window

        Parameters
        ----------
        status: CaseStatus
            An enum representation of the expected status
        """
        LOGGER.info("Changing case status..")
        if self.get_case_status() == status.value:
            LOGGER.info(f"Case status is already '{status.value}'")
            return

        self.click_on_element(
            (By.CSS_SELECTOR, shl.edit_case_status_css),
            message="Case status pill is not visible or present",
        )

        self.get_element_when_visible(
            (By.CSS_SELECTOR, shl.case_status_options_popover_css),
            message="Case Status options popup is not displayed",
        )

        locator: str = shl.case_status_options_css.format(case_status=status.value)
        self.click_on_element(
            (By.CSS_SELECTOR, locator),
            message=f"Failed to select '{status.value}' from case status",
        )
        self.wait.until(
            ec.text_to_be_present_in_element(
                (By.CSS_SELECTOR, shl.current_case_status_css), status.value
            )
        )

    def click_sentiment_label_and_get_trigger_text(self) -> str:
        """Clicks on the sentiment label in the SupportHub body and returns the text
        that triggered the sentiment."""
        LOGGER.info("Clicking on sentiment label..")
        label: WebElement = self.get_element_when_visible(
            (By.CSS_SELECTOR, shl.sentiment_label_css),
            message="Sentiment label element is not visible or present",
        )
        label.click()
        label_text: str = label.text.split("\n")[0]

        LOGGER.info(f"Getting sentiment trigger text below label '{label_text}'..")
        return self.get_element_text_or_value(
            (By.CSS_SELECTOR, shl.labelled_sentiment_css),
            message="Failed to get Sentiment trigger text",
        ).strip()

    def search_conversation_for(self, search_text: str) -> None:
        """Performs a search for the given search text in the case comments"""
        LOGGER.info(f"Searching conversation for '{search_text}'..")
        self.click_on_element(
            (By.CSS_SELECTOR, shl.conversation_search_box_css),
            message="Failed to click on conversation search box",
        )
        time.sleep(1)  # wait for textbox to expand
        self.pass_value_to_element(
            search_text,
            (By.CSS_SELECTOR, shl.conversation_search_input_css),
            message="Failed to enter value in conversation search box",
        )

    def get_search_result_text_from_case_comments(self, search_text: str) -> str:
        """Returns the highlighted text from the case comment, when a case comment
        search is performed."""
        LOGGER.info("Getting highlighted text from case comments..")
        # return empty string if no result is found for search text
        if not self.is_element_visible(
            (By.CSS_SELECTOR, shl.conversation_search_results_css), timeout=5
        ):
            LOGGER.info(f"No results found for '{search_text}' in case comments")
            return ""
        result_text: str = self.get_element_text_or_value(
            (By.CSS_SELECTOR, shl.conversation_search_results_css),
            message="failed to get search text from case comment",
        )
        LOGGER.info(f"'{search_text}' is found in case comments")
        return result_text

    def open_case_share_popover(self) -> None:
        """Opens the case share popover from the share case button"""
        LOGGER.info("Opening case share popover..")
        self.click_on_element(
            (By.CSS_SELECTOR, shl.share_button_outer_css),
            message="Failed to click outer share case button",
        )

    def close_case_share_popover(self) -> None:
        self.click_on_element((By.CSS_SELECTOR, shl.close_share_case_popover_css))

    def enter_share_case_email_address(self, email_id: str) -> None:
        """Enters the given email address in the share case popover"""
        LOGGER.info("Entering email id to share case to..")
        # clicks the email icon
        self.click_on_element(
            (By.CSS_SELECTOR, shl.share_via_email_button_css),
            timeout=5,
            message="Failed to choose email in share case popover",
        )
        textbox = self.driver.find_element(By.CSS_SELECTOR, shl.email_input_box_css)
        textbox.send_keys(Keys.BACKSPACE)
        textbox.send_keys(email_id)
        time.sleep(0.5)
        textbox.send_keys(Keys.ENTER)

    def validate_share_case_email_address(self) -> bool:
        """Check whether the email address entered in share case popover is a valid
        one"""
        LOGGER.info("Validating share case email id..")
        # raise exception if entered email is not valid
        is_invalid: bool = self.is_element_visible(
            (By.CSS_SELECTOR, shl.case_share_invalid_email_error_css), timeout=3
        )
        return is_invalid

    def share_case_via_email(self, email_id: str, reason: str = "") -> None:
        """
        Share the case open in SupportHub modal window to the given email address.

        Parameters
        ----------
        email_id: str
            Email ID of the person receiving access to the case
        reason: str, optional
            An optional reason for sharing the case
        """
        LOGGER.info("Sharing case via email..")
        self.open_case_share_popover()
        self.enter_share_case_email_address(email_id)

        if self.validate_share_case_email_address():
            raise Exception("Entered email address is not valid")

        if reason:
            LOGGER.info("Entering reason for sharing case..")
            self.pass_value_to_element(
                reason,
                (By.CSS_SELECTOR, shl.share_reason_textarea_css),
                message="Failed to enter share reason",
            )

        self.click_on_element(
            (By.CSS_SELECTOR, shl.share_button_inner_css),
            message="Failed to click on share button in case share popover",
        )

    def is_case_shared(self) -> bool:
        """Checks if the case is shared with anyone by checking the 'Shared with' data
        in the SupportHub window."""
        LOGGER.info("Checking 'shared with' info is visible in SupportHub modal..")
        return self.is_element_visible((By.CSS_SELECTOR, shl.shared_with_check_css))

    def get_client_notes_count_in_support_hub(self, silent: bool = False) -> int:
        """Get the count of client notes present next to the add client note icon from
        the SupportHub window"""
        log_level: int = logging.WARNING if silent else logging.INFO
        logging.getLogger().setLevel(log_level)
        LOGGER.info("Getting count of available client notes..")
        if not self.is_element_visible(
            (By.CSS_SELECTOR, shl.client_notes_count_css), timeout=3
        ):
            return 0
        count_text: str = self.get_element_text_or_value(
            (By.CSS_SELECTOR, shl.client_notes_count_css)
        )
        LOGGER.info(f"{count_text} client notes found")
        logging.getLogger().setLevel(logging.INFO)
        return int(count_text)

    def open_add_client_note_popover(self) -> None:
        """Opens the client note popover from the SupportHub window"""
        if not self.is_element_visible(
            (By.CSS_SELECTOR, shl.client_notes_popover_css), timeout=3
        ):
            LOGGER.info("Opening client note popover..")
            self.click_on_element(
                (By.CSS_SELECTOR, shl.add_client_note_css),
                message="SupportHub Add Client note button is not visible or disabled",
            )

    def close_client_note_popover(self) -> None:
        """Closes the client note popover from the SupportHub window"""
        if self.is_element_visible(
            (By.CSS_SELECTOR, shl.client_notes_popover_css), timeout=3
        ):
            LOGGER.info("Closing client note popover..")
            self.click_on_element(
                (By.CSS_SELECTOR, shl.close_client_note_popover_css),
                message="Failed to close client note popover",
            )

    def check_client_notes_visibility(self) -> bool:
        """Check for presence of any note in the client note popover"""
        LOGGER.info("Checking for client notes..")
        if not self.get_client_notes_count_in_support_hub(silent=True):
            LOGGER.warning("No client note is added yet")
            return True
        return self.is_element_visible((By.CSS_SELECTOR, shl.client_note_text_css))

    def click_add_new_client_note_button(self) -> None:
        """Clicks on the add client note button that opens editor textarea"""
        LOGGER.info("Clicking add new client note button..")
        if not self.is_element_visible((By.CSS_SELECTOR, shl.client_note_textarea_css)):
            self.click_on_element(
                (By.CSS_SELECTOR, shl.add_new_client_note_css),
                timeout=5,
                message="Add client note button click failed",
            )

    def enter_client_note_text(self, note: str) -> None:
        """
        Enter a value into the client note textarea

        Parameters
        __________
        note: str
            Text to be added as client note
        """
        LOGGER.info("Entering note in client note editor textrea..")
        self.pass_value_to_element(
            note,
            (By.CSS_SELECTOR, shl.client_note_textarea_css),
            message="Failed to enter value in client note textbox",
        )

    def save_client_note(self) -> None:
        """Clicks on the add/save button when adding a new note or edit existing ones
        in the client note popover"""
        LOGGER.info("Saving new client note..")
        self.click_on_element(
            (By.CSS_SELECTOR, shl.save_client_note_css),
            timeout=5,
            message="Save client note button click failed",
        )

    def check_visibility_of_given_client_note(self, note_text: str) -> bool:
        """
        Checks for the visibility of the given note in the client note popover

        Parameters
        __________
        note_text: str
            client note text
        """
        LOGGER.info(f"Checking for visibility of client note '{note_text}'..")
        return self.is_element_visible(
            (By.XPATH, shl.new_client_note_text.format(note=note_text)), timeout=5
        )

    def wait_for_new_client_note_to_appear(self, note: str) -> None:
        """
        Wait for the given client note to appear in the client note popover

        Parameters
        __________
        note: str
            client note text
        """
        LOGGER.info(f"Waiting for '{note}' to appear in client note list..")
        if not self.is_element_visible(
            (By.XPATH, shl.new_client_note_text.format(note=note)), timeout=10
        ):
            raise ElementNotVisibleException(
                f"Newly added client note ({note}) is not visible"
            )

    def wait_for_new_client_note_to_disappear(self, note: str) -> None:
        """
        Wait for the given client note to disappear from the client note popover
        after deleting

        Parameters
        __________
        note: str
            client note text
        """
        LOGGER.info(f"Waiting for '{note}' to disappear from client note list..")
        self.wait.until_not(
            ec.text_to_be_present_in_element(
                (By.XPATH, shl.client_note_text_generic), note
            ),
            message=f"Client note {note} did not disappear",
        )

    def cancel_adding_new_client_note(self) -> None:
        """Clicks on the cancel button in the client note editor"""
        LOGGER.info("Canceling addition of new client note..")
        self.click_on_element(
            (By.CSS_SELECTOR, shl.cancel_new_client_note_css),
            message="Cancel client note button click failed",
        )

    def get_client_note_text(self) -> str:
        """Get the first client note text from the client note popover"""
        LOGGER.info("Getting text from client note..")
        if not self.get_client_notes_count_in_support_hub():
            LOGGER.info("No client note found")
            return ""
        return self.get_element_text_or_value(
            (By.CSS_SELECTOR, shl.client_note_text_css),
            message="Failed to get client note text",
        )

    def get_client_note_time(self) -> str:
        """Get the time of addition from the first client note in the client note
        popover"""
        LOGGER.info("Getting added time from client note..")
        if not self.get_client_notes_count_in_support_hub():
            LOGGER.info("No client note found")
            return ""
        return self.get_element_text_or_value(
            (By.CSS_SELECTOR, shl.client_note_time_css),
            message="Failed to get client note added time",
        )

    def hover_over_client_note(self, note: str) -> None:
        """Moves the mouse to the given client note text"""
        self.hover_on_element(
            (By.XPATH, shl.new_client_note_text.format(note=note)),
            message="Failed to hover over given client note",
        )

    def edit_client_note(self, original_note: str, new_note: str) -> None:
        """
        Edit the value of an existing client note. Edit option is available only for
        notes added by the current user.

        Parameters
        ----------
        original_note: str
        new_note: str
            New string value that replaces the existing client note
        """
        LOGGER.info("Editing client note..")
        self.hover_over_client_note(original_note)
        self.mouse_click_on_element(
            (By.CSS_SELECTOR, shl.edit_client_note_css),
            message="Edit client note button click failed",
        )
        existing_note = self.get_element_text_or_value(
            (By.CSS_SELECTOR, shl.client_note_textarea_css)
        )
        if existing_note != new_note:
            self.enter_client_note_text(new_note)
        self.save_client_note()

    def delete_client_note(self, note: str) -> None:
        """Delete an existing client note. Delete option is available only for
        notes added by the current user."""
        LOGGER.info("Deleting client note..")
        self.hover_over_client_note(note)
        self.mouse_click_on_element(
            (By.CSS_SELECTOR, shl.delete_client_note_css),
            message="Failed to delete client note",
        )

    def is_case_escalated(self) -> bool:
        """
        Check the escalation status of the case open in SupportHub window.

        Returns
        -------
        bool
            True if case is escalated
        """
        LOGGER.info("Checking case escalation status..")
        is_escalated: bool = self.is_element_visible(
            (By.CSS_SELECTOR, shl.case_history_escalation_label_css), timeout=3
        )
        if is_escalated:
            LOGGER.info("Case is escalated")
        else:
            LOGGER.info("Case is not escalated")
        return is_escalated

    def add_new_escalation_note(self, note: str) -> None:
        """
        Adds a new escalation note.

        Parameters
        ----------
        note: str
            Value to be added as escalation note
        """
        LOGGER.info("Adding new escalation note..")
        LOGGER.info("Clicking add escalation note button..")
        self.click_on_element(
            (By.CSS_SELECTOR, shl.add_escalation_note_button_css),
            message="Add escalation note button click failed",
        )
        try:
            self.click_on_element(
                (By.CSS_SELECTOR, shl.add_fresh_escalation_note_css),
                timeout=3,
            )
        except TimeoutException:
            pass
        LOGGER.info("Entering escalation note text..")
        self.pass_value_to_element(
            (note, Keys.ENTER),
            (By.CSS_SELECTOR, shl.escalation_note_textarea_css),
            message="Escalation note textarea is not visible or present",
        )

    def wait_for_new_escalation_note_to_be_added(self, note: str) -> None:
        """Waits till the given note is visible in the escalation note popover"""
        LOGGER.info(f"Waiting for '{note}' to appear in escalation notes list..")
        if not self.is_element_visible(
            (By.XPATH, shl.escalation_note_with_text.format(note=note)), timeout=5
        ):
            raise ElementNotVisibleException(
                "Newly added escalation note {note} is not visible"
            )

    def get_escalation_note_text(self) -> str:
        """Get the value of the first note in the escalation note popover"""
        LOGGER.info("Getting text from last added escalation note..")
        return self.get_element_text_or_value(
            (By.CSS_SELECTOR, shl.escalation_note_text_css),
            message="Failed to get escalation note text",
        )

    def click_add_case_note_button(self) -> None:
        """Click on the add case note button"""
        LOGGER.info("Opening add case note editor..")
        self.click_on_element(
            (By.CSS_SELECTOR, shl.add_case_note_button_css),
            timeout=5,
            message="Failed to open private case note editor",
        )

    def click_reply_client_button(self) -> None:
        """Click on the add case note button"""
        LOGGER.info("Opening reply to client editor..")
        self.click_on_element(
            (By.CSS_SELECTOR, shl.reply_to_client_button_css),
            timeout=5,
            message="Failed to open public case note editor",
        )

    def add_cc_bcc_to_new_case_note(
        self, email: Union[str, tuple[str]], is_cc: bool = True
    ) -> None:
        """
        Add an email as CC or BCC to the case note based on the is_cc flag.

        Parameters
        ----------
        email: str
            Email address to add as CC or BCC
        is_cc: bool
            Enters email as CC if True
        """
        field_name: str = "CC" if is_cc else "BCC"

        def type_email(cc_email: str):
            textbox_locator: str = (
                shl.add_cc_textbox_css if is_cc else shl.add_bcc_textbox_css
            )
            self.pass_value_to_element(
                (cc_email, Keys.ENTER),
                (By.CSS_SELECTOR, textbox_locator),
                message=f"Failed to enter text in {field_name} field",
            )

        LOGGER.info(f"Adding {field_name} email to new case note..")
        locator: str = shl.add_cc_button_css if is_cc else shl.add_bcc_button_css
        self.click_on_element(
            (By.CSS_SELECTOR, locator),
            timeout=10,
            message=f"Failed to click on {field_name} button in case note editor",
        )

        if isinstance(email, tuple):
            for mail in email:
                type_email(mail)
        else:
            type_email(email)

    def add_new_case_note(
        self,
        note: str,
        cc_email: Union[str, tuple[str]] = "",
        bcc_email: Union[str, tuple[str]] = "",
        make_public: bool = False,
    ) -> None:
        """
        Add a new case note in the SupportHub modal window.

        Parameters
        ----------
        note: str
            Value to be entered the case note editor
        cc_email: Union[str, Sequence[str]], optional
            One or multiple email addresses to add in the CC field (default is empty)
        bcc_email: Union[str, Sequence[str]], optional
            One or multiple email addresses to add in the BCC field (default is empty)
        make_public: bool
            Determines case note visibility. True is Public (default is False)
        """
        if make_public:
            LOGGER.info("Adding new public case note..")
            self.click_reply_client_button()
        else:
            LOGGER.info("Adding new private case note..")
            self.click_add_case_note_button()

        if not self.is_element_visible(
            (By.CSS_SELECTOR, shl.case_note_editor_textarea_css), timeout=3
        ):
            raise Exception("Case note editor is not visible")

        if cc_email:
            self.add_cc_bcc_to_new_case_note(cc_email)

        if bcc_email:
            self.add_cc_bcc_to_new_case_note(bcc_email, is_cc=False)

        LOGGER.info("Entering value in case note textarea..")
        self.pass_value_to_element(
            note,
            (By.CSS_SELECTOR, shl.case_note_editor_textarea_css),
            message="Failed to enter note text in case note editor",
        )

        LOGGER.info("Saving new case note..")
        self.click_on_element(
            (By.CSS_SELECTOR, shl.save_new_case_note_css),
            timeout=5,
            message="Failed to click save/send button in case note editor",
        )

        LOGGER.info("Waiting for case note to reflect in case comments..")
        self.wait.until(
            ec.text_to_be_present_in_element(
                (By.CSS_SELECTOR, shl.case_comments_text_css), text_=note
            ),
            message="Newly added case note is not updated as a case comment",
        )

    def check_for_reporter_name_display_in_tool_tip(self):
        """This method checks for reporter  name is displayed in reporter tooltip"""
        reporter_name = self.is_element_visible(
            (By.XPATH, shl.reporter_name_in_reporter_tool_tip_xpath)
        ), "failed ti displayed reporter name tool tip "
        if reporter_name:
            return True
        else:
            return False

    def check_for_reporter_email_display_in_tool_tip(self):
        """This method checks for reporter  email is displayed in reporter tooltip"""
        reporter_email = self.is_element_visible(
            (By.XPATH, shl.reporter_email_in_reporter_tool_tip_xpath)
        ), "failed ti displayed reporter email tool tip "
        if reporter_email:
            return True
        else:
            return False

    def check_for_report_active_hours_display_in_tooltip(self):
        """This method checks for active hours is displayed in reporter tooltip"""
        reporter_active_hours = self.is_element_visible(
            (By.XPATH, shl.reporter_email_in_reporter_tool_tip_xpath)
        ), "failed to display reporter active hours tool tip "
        if reporter_active_hours:
            return True
        else:
            return False

    def click_on_customer_name(self):
        """Click on the add case note button"""
        LOGGER.info("click on customer name in support hub..")
        self.click_on_element(
            (By.CSS_SELECTOR, shl.customer_name_css),
            timeout=5,
            message=" clicking on customer name in support hub",
        )

    def click_on_case_status_button(self):
        """This method helps to click on case status button"""
        self.click_on_element(
            (By.CSS_SELECTOR, shl.edit_case_status_css),
            message="Case status pill is not visible or present",
        )

    def check_for_case_status_tool_tip(self):
        """This method helps to check for  case status tool tips """
        LOGGER.info("checking for case status tool tips..")
        return self.get_element_when_visible(
            (By.XPATH, shl.case_status_tool_tip),
            message="Case Status tool tip",
        )
      
    def check_for_agents_name_present_on_case_owner_tool_tip(self,case_owner_name):
        """This method checks for case owner present on tool tips """

        case_owner_name_tool_tip = self.is_element_visible((By.XPATH,
                                 shl.case_owner_name_in_tooltip.replace("TEXT_PLACE_HOLDER",case_owner_name)))
        if case_owner_name_tool_tip :
            return True
        else:
            return False

    def acknowledge_first_sentiment_found(self):
        self.hover_on_element((By.CSS_SELECTOR, shl.case_sentiment_card_css))
        self.click_on_element((By.CSS_SELECTOR, shl.acknowledge_sentiment_button_css))

    def get_acknowledged_sentiment_button_text(self):
        return self.get_element_text_or_value(
            (By.XPATH, shl.acknowledged_sentiment_label)
        )

    def remove_acknowledgment(self):
        self.hover_on_element((By.CSS_SELECTOR, shl.case_sentiment_card_css))
        self.hover_on_element((By.XPATH, shl.acknowledged_sentiment_label))
        self.click_on_element((By.CSS_SELECTOR, shl.acknowledge_sentiment_button_css))
