"""This module is  focuses on  creating reusable method the alerts page  """
__author__ = "Neha Jha"
__copyright__ = "Copyright (C) 2021 SupportLogic"

import logging
import time

from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.keys import Keys

import constants
import utils
from locators import alerts_locator
from pom_library.helper_methods import HelperMethods
from pom_library.pom_base import PomBase

LOGGER = logging.getLogger(__name__)


class Alerts(HelperMethods):
    """
    This class has all the actions that can be done in alerts page

    """

    # declaring the driver to use it in overall page
    def __init__(self, driver):
        self.driver = driver

        PomBase.__init__(self, self.driver)
        self.actions = ActionChains(driver)
        self.wait = WebDriverWait(driver, 60)

    def click_alerts_nav_bar(self):
        """ This method helps to click on alerts  in nav bar"""

        alerts_nav_bar = self.wait.until(
            EC.element_to_be_clickable((By.XPATH, alerts_locator.alerts_nav_bar))
        )
        self.driver.execute_script("arguments[0].click();", alerts_nav_bar)



    def check_present_new_alerts_button(self):
        """This method helps to checks present  of new alerts button in alerts list"""

        new_alerts_button_locator = self.driver.find_element(
            By.XPATH, 
            alerts_locator.new_alerts
        ).is_displayed()
        if new_alerts_button_locator:
            LOGGER.info("new alerts button is displayed ")
            return True
        else:
            LOGGER.info("new alerts button is not displayed")
            return False

    def check_present_alerts(self):
        """This method helps to checks present  of alerts present in the left side of column """

        try:
            check_for_alerts_present = self.driver.find_element(
                By.XPATH, 
                alerts_locator.alerts_present_in_dashboard
            ).is_displayed()
            if check_for_alerts_present:
                LOGGER.info("alerts present on the dash board ")
                return True
        except:
            LOGGER.info("alerts not present on the dash board")
            return False

    def check_present_alert_condition(self):
        """This method helps to checks present  of alerts condition"""
        try:
            alerts_condition_locator=self.is_element_visible(
                (By.XPATH, alerts_locator.alerts_condition),
            )
            if alerts_condition_locator:
                LOGGER.info(" alerts condition is displayed")
                return True
        except:
            LOGGER.info("alerts condition is not displayed displayed")
            return False

    def check_present_notification_method(self):
        """This method helps to checks present  notification method"""

        notification_method_locator = self.driver.find_element(
            By.XPATH, 
            alerts_locator.alerts_definition
        ).is_displayed()
        if notification_method_locator:
            LOGGER.info(" alerts definition is displayed")
            return True
        else:
            LOGGER.info(" alerts definition is not  displayed")
            return False

    def click_new_alerts_button(self):
        """This method helps to click on new alerts button"""
        new_alerts = self.wait.until(
            EC.element_to_be_clickable((By.XPATH, alerts_locator.new_alerts))
        )
        self.driver.execute_script("arguments[0].click();", new_alerts)

    def check_presents_alerts_name_in_definition(self):
        """This method helps to check the alerts name is present in definition  """
        alerts_name = self.driver.find_element(
            By.XPATH, 
            alerts_locator.alerts_name_definition
        ).is_displayed()
        if alerts_name:
            LOGGER.info(" alerts name is displayed in definition")
            return True
        else:
            LOGGER.info(" alerts name is not displayed in definition")
            return False

    def get_text_definition_alerts_name(self):
        """ This method helps to get the text alerts name from definition"""

        alerts_name = self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, alerts_locator.alerts_name_definition)
            )
        ).text
        LOGGER.info(f" alerts name  in definition is {alerts_name }")
        return alerts_name

    def click_alert_copy(self):
        """This method helps to click on the alerts copy to copy the alerts"""
        self.driver.find_element(By.XPATH, alerts_locator.alerts_copy).click()

    def click_alerts_conditions(self):
        """This method helps to click on alerts condition options"""
        self.driver.find_element(
            By.XPATH, 
            alerts_locator.alerts_condition_option
        ).click()

    def double_click_to_add_sentiment(self):
        """This method helps to double click to added sentiments"""
        condition_drop_down = self.driver.find_element(
            By.XPATH, 
            alerts_locator.condition_drop_down
        )

        self.actions.double_click(condition_drop_down).perform()

    def get_text_sentiment_alerts_condition(self):
        """This method helps to get the text sentiment """
        sentiment_option = self.wait.until(
            EC.element_to_be_clickable((By.XPATH, alerts_locator.condition_drop_down))
        ).text
        LOGGER.info(f" sentiment selected  is {sentiment_option}")
        return sentiment_option

    def get_text_sentiment_alerts_definition(self):
        """This method helps to get the text sentiment """
        sentiments = self.driver.find_element(
            By.XPATH, 
            alerts_locator.sentiments_alerts_definition
        ).text

        LOGGER.info(f" sentiments display in definition  is {sentiments}")
        return sentiments

    def drag_drop_sentiments(self):
        """This method helps to drag and drop sentiments from alerts condition to alerts defination"""

        sentiments_alerts_condition = self.driver.find_element(
            By.XPATH, 
            alerts_locator.condition_drop_down
        )

        condition_sentiments = self.wait.until(
            EC.visibility_of_element_located(
                (By.XPATH, alerts_locator.drag_drop_definition)
            )
        )

        self.actions.click_and_hold(sentiments_alerts_condition).move_to_element(
            condition_sentiments
        ).release().perform()

    def click_alert_delete(self):
        """This method helps to click on the alerts delete"""
        self.driver.find_element(By.XPATH, alerts_locator.alerts_delete).click()

    def click_delete_on_delete_pop(self):
        """This method helps to click on the delete button in alerts delete pop up"""
        self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, alerts_locator.delete_alerts_delete_pop_up)
            )
        ).click()

    def click_mute_alerts_definition(self):
        """This method helps to click on alerts mute definition"""

        self.wait.until(
            EC.element_to_be_clickable((By.XPATH, alerts_locator.alerts_mute))
        ).click()

    def checks_for_alerts_unmute(self):
        """This method helps to checks for alerts is unmute or not in alerts definition"""
        try:
            unmute_alerts = self.wait.until(
                EC.element_to_be_clickable((By.XPATH, alerts_locator.alerts_un_mute))
            )
            if unmute_alerts:
                LOGGER.info(" alerts is unmuted")
                return True
        except Exception:
            return False

    def remove_sentiments(self):
        """This method help to remove the sentiments"""
        sentiments = self.driver.find_element(
            By.XPATH, 
            alerts_locator.sentiments_alerts_definition
        )
        self.actions.move_to_element(sentiments).click().perform()
        self.wait.until(
            EC.element_to_be_clickable((By.XPATH, alerts_locator.remove_sentiments))
        ).click()

    def checks_for_un_mute_alerts_list(self):
        """This method helps to check for un muted in  alerts list"""
        try:
            un_mute_alerts = self.wait.until(
                EC.element_to_be_clickable(
                    (By.XPATH, alerts_locator.un_mute_alerts_list)
                )
            )
            if un_mute_alerts:
                LOGGER.info(" alerts is unmuted")
                return True

        except Exception:
            return False

    def click_mute_alerts_list(self):
        """This method helps to click on the mute alerts button in mute condition"""
        self.wait.until(
            EC.element_to_be_clickable((By.XPATH, alerts_locator.mute_alerts_list))
        ).click()

    def click_unmute_alerts_list(self):
        """This method helps to click on the un mute in alerts  list"""
        self.wait.until(
            EC.element_to_be_clickable((By.XPATH, alerts_locator.un_mute_alerts_list))
        ).click()

    def check_present_expand_list(self):
        """This method helps to checks present of expand list box in alerts definition"""

        expand_list_box = self.driver.find_element(
            By.XPATH, 
            alerts_locator.expand_list_box
        ).is_displayed()
        if expand_list_box:
            LOGGER.info(" expand list box displayed in alerts definition")
            return True
        else:
            LOGGER.info(" expand list box displayed is not alerts definition")
            return False

    def get_count_of_alerts(self):
        """This method helps to get the count of alerts"""
        alerts_present_on_dashboard = self.driver.find_elements(
            By.XPATH, alerts_locator.alerts_present_in_dashboard
        )
        no_of_alerts = len(alerts_present_on_dashboard)
        LOGGER.info(f"alerts present on the dash board {no_of_alerts}")
        return no_of_alerts



    def click_on_alerts_present_on_left_menu(self):
        """This method helps to click on the un mute in alerts list"""
        self.wait.until(
            EC.element_to_be_clickable((By.XPATH, alerts_locator.alerts_present_in_dashboard))
        ).click()

    def create_new_alerts(self):
        new_alerts = self.check_present_new_alerts_button()
        assert new_alerts, "failed to displayed new alerts button"
        number_of_alerts_present_before = self.get_count_of_alerts()
        self.click_new_alerts_button()
        alert_name = utils.generate_test_run_id(constants.ALERTS_NAME_RUN_ID_PREFIX)
        self.enter_new_alert_name(alert_name)
        number_of_alerts = number_of_alerts_present_before + 1
        number_of_alerts_present_after = self.get_count_of_alerts()
        assert (
                number_of_alerts == number_of_alerts_present_after
        ), "failed to create new alerts"
        return alert_name

    def enter_new_alert_name(self, AlertName):
        """This method helps to create a name for alerts list"""
        alert_name_edit = self.wait.until(EC.element_to_be_clickable(
            (By.XPATH, alerts_locator.alerts_name_edit)))
        alert_name_edit.click()

        alert_name = self.wait.until(EC.presence_of_element_located(
            (By.XPATH, alerts_locator.alerts_name_input_field)))

        self.driver.execute_script("arguments[0].value ='';", alert_name)
        alert_name.send_keys(AlertName)
        alert_name.send_keys(Keys.ENTER)

    def get_number_of_alerts_present_on_dashboard(self):
        """This method helps to get the number of alerts present in dashboard"""

        alerts_present_on_dashboard = self.driver.find_elements(
            By.XPATH, alerts_locator.alerts_present_in_dashboard
        )
        return alerts_present_on_dashboard


    def alerts_delete(self):
        """This method helps to delete the alert which has QA_AL in alerts name    """

        number_of_alerts_present_before = self.get_number_of_alerts_present_on_dashboard()
        for i in number_of_alerts_present_before:
            alerts_names = i.text
            if "QA_AL" in alerts_names:
                i.click()
                self.click_alert_delete()
                time.sleep(2)
                self.click_delete_on_delete_pop()
                LOGGER.info(f"{alerts_names} is deleted")
                time.sleep(2)


    def click_on_condition_undo_button(self):
        """This method helps to click on condition undo button"""

        LOGGER.info("clicking on condition undo button")
        self.click_on_element(
            (By.XPATH, alerts_locator.condition_undo_button),
            message="failed to click on condition undo button",
        )


    def validating_alert_condition_present_on_alert_or_not(self):
        """This method helps to alert condition present or not"""
        try:
            first_sentiment_condition_on_alerts = self.driver.find_element(
            By.XPATH, 
            alerts_locator.sentiments_alerts_definition
        )
            if first_sentiment_condition_on_alerts :
                LOGGER.info(" sentiments condition is displayed on alerts")
                return True
        except:
            LOGGER.info(" sentiments condition is not displayed on alerts")
            return False

    def click_on_notification_undo_button(self):
        """This method helps to click on notification undo button"""
        LOGGER.info("clicking on notification undo button")
        self.click_on_element(
            (By.XPATH, alerts_locator.notification_undo_button),
            message="failed to click on notification undo button",
        )


    def remove_first_email_in_notification_method(self):
        """This method help to remove first email in notification method"""
        sentiments = self.driver.find_element(
            By.XPATH, 
            alerts_locator.click_on_first_email_account
        )
        time.sleep(1)
        self.actions.move_to_element(sentiments).perform()
        self.mouse_click_on_element(
            (By.XPATH, alerts_locator.remove_email_account),
            message="failed to remove to email notification account",
        )

    def validate_email_is_displayed_notification_method(self):
        """This method helps to click on notification undo button"""
        try:
            email_displayed_notification_module = self.driver.find_element(
                By.XPATH, 
                alerts_locator.click_on_first_email_account
            ).is_displayed()
            if email_displayed_notification_module:
                LOGGER.info("email displayed on notification method")
                return True
        except:
            LOGGER.info("email displayed is not notification method ")
            return False


    def get_data_status_email_check_box_in_send_alert_me(self):
        """This method whether email check box status """
        status = self.driver.find_element(
          By.XPATH, 
          alerts_locator.data_status_of_email_check_box
        ).get_attribute("data-status")
        return status

    def get_data_status_send_alert_me_check_box(self):
        """This method get data status sent me check box   """
        status = self.driver.find_element(
          By.XPATH, 
          alerts_locator.send_me_alert_check_box_data_status
        ).get_attribute("data-status")
        return status

    def click_on_email_check_box_in_send_alert_me_drop_down(self):
        """This method click on email check box """
        self.click_on_element(
            (By.XPATH,alerts_locator.check_email_box_send_me_alert),
            message="failed to click on email check box ",
        )

    def click_on_send_alert_me_drop_down_menu(self):
        self.click_on_element(
            (By.XPATH, alerts_locator.send_me_alert_drop_down),
            message="failed to click on sent me drop down menu ",
        )

    def check_for_visibility_of_condition_undo_button(self):
        """This method helps to check for presence of undo button"""

        LOGGER.info("check for presence of undo button")
        return self.is_element_visible(
            (By.XPATH, alerts_locator.condition_undo_button),

        )

    def send_back_slash_in_payload_section(self):
        """This  method helps to send the message back slash in payload section"""
        LOGGER.info("send back slash message on payload section")
        time.sleep(2)
        self.driver.find_element(By.CSS_SELECTOR, alerts_locator.payload_search_message).click()
        self.wait.until(EC.presence_of_element_located(
                (By.CSS_SELECTOR, alerts_locator.payload_search_message)))


        self.actions.send_keys("/").perform()

        self.actions.send_keys(Keys.ENTER).perform()


    def check_for_message_pay_load_section_have_sentiments_condition(self):
        """This method helps to check for message  have sentiments condition"""
        sentiments_condition_message_section = self.is_element_visible((By.XPATH,
                                                                    alerts_locator.payload_message_sentiments))
        if sentiments_condition_message_section:
            LOGGER.info(" sentiments condition is displayed in message section")
            return True
        else:
            LOGGER.info("sentiments condition is displayed in not message section")
            return False



    def click_on_expand_and_collapse_condition_sentiments(self):
        """This method helps to click on expand and collapse button"""
        LOGGER.info("click on expand and collapse button")

        self.mouse_click_on_element(
            (By.XPATH, alerts_locator.expand_and_collapse_button),
            message="click on expand and collapse button",
        )
    def check_present_alert_condition_expand_state_or_collapse_state(self):
        """This method helps to checks present  of alerts condition expand or collapse state"""

        alerts_condition_locator = self.is_element_visible(
            (By.XPATH, alerts_locator.collapse_state_of_alert_condition),
        )
        if alerts_condition_locator:
            LOGGER.info(" alerts condition is displayed")
            return True
        else:
            LOGGER.info("alert condition drop down is not displayed")
            return False

    def click_on_undo_button_in_payload_section(self):
        """This method helps to click on undo button in payload section"""
        self.mouse_click_on_element(
            (By.XPATH, alerts_locator.payload_section_undo_button),
            message="This helps helps to click on undo button" )

    def click_on_last_activity_in_alert_condition_sentiments(self):
        """This method helps to click on last activity in alerts button"""
        LOGGER.info("click on last activity in alerts alert condition")

        self.mouse_click_on_element(
            (By.XPATH, alerts_locator.last_activity_state_in_alert_condition),
            message="click on last activity in alert condition ",
        )

    def double_click_to_added_last_activity_inbound(self):
        """This method helps to double click to added sentiments"""
        condition_drop_down = self.driver.find_element(
            By.XPATH, 
            alerts_locator.last_case_activity_sentiments_inbound
        )

        self.actions.double_click(condition_drop_down).perform()


    def check_for_error_message_is_displayed_last_activity_inbound(self):
        LOGGER.info("check for presence of error message in last activity in bound")
        return self.is_element_visible(
            (By.XPATH, alerts_locator.error_message_last_case_activity_is_left_blank),

        )

    def click_on_notification_drop_down(self):
        LOGGER.info("clicking on notification drop down")
        self.mouse_click_on_element(
            (By.XPATH, alerts_locator.notification_drop_down),
            message="click on last activity in alert condition ",
        )

    def click_on_slack_button_in_drop_down(self):
        LOGGER.info("clicking on slack button in drop down")
        self.mouse_click_on_element(
            (By.XPATH, alerts_locator.select_slack_in_drop_down),
            message="click on slack button in drop down ",
        )

    def check_of_status_on_slack_is_selected_or_not(self):
        status = self.driver.find_element(
            By.XPATH, 
            alerts_locator.data_status_of_slack_check_or_not
        ).get_attribute("data-status")
        return status

    def check_for_error_message_is_displayed_when_slack_is_not_configured(self):
        LOGGER.info("check for presence of error message is not displayed" )
        slack_workspace_is_not_connected_sl= self.is_element_visible(
            (By.XPATH, alerts_locator.condition_undo_button),)
        if slack_workspace_is_not_connected_sl:
            return True
        else:
            return False


