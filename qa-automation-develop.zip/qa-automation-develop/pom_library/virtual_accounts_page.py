"""This Page has all the actions that can be performed in the respective fields/ locators. This page will be
called by those methods which wants to use the values to perform some tests in the Virtual Accounts Page."""
import time

from selenium.common.exceptions import ElementClickInterceptedException
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
import logging

from selenium.webdriver.common.keys import Keys

import constants
import utils
from locators import oldlocators,virtual_account_locator
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

from pom_library.helper_methods import HelperMethods
LOGGER = logging.getLogger(__name__)


class VirtualAccountsPage(HelperMethods):
    # declaring the driver to use it in overall page
    def __init__(self, driver):
        super().__init__(driver)
        self.driver = driver

    def fetch_the_title_of_the_page(self):
        # fetching the title of the page
        title_of_page = self.driver.title
        return title_of_page

    def fetch_the_url_of_the_page(self):
        # fetching the url of the page
        current_url = self.driver.current_url
        return current_url

    def check_the_page_is_visible(self):
        # This method checks if the page is visible in the whole dashboard.
        try:
            element = self.driver.find_element(
                By.XPATH, 
                oldlocators.virtual_account_page_id
            )
            actions = ActionChains(self.driver)
            actions.move_to_element(element)
            assert element.is_displayed()
            print("VA is visible in the dashboard")
        except Exception:
            assert False

    def check_click_on_page_is_working(self):
        try:
            element = self.driver.find_element(
                By.XPATH, 
                oldlocators.virtual_account_page_id
            )
            element.click()
            time.sleep(5)
        except Exception:
            assert False

    def check_if_the_page_loaded_successfully(self):
        # This method checks whether the page has loaded with all its expected content and that no type error is
        #          caught
        try:
            element1 = self.driver.find_element(
                By.XPATH, 
                oldlocators.create_a_virtual_account_xpath
            )
            assert element1.is_displayed()
            element2 = self.driver.find_element(
                By.XPATH, 
                oldlocators.create_a_virtual_group_xpath
            )
            assert element2.is_displayed()
            element3 = self.driver.find_element(
                By.XPATH, 
                oldlocators.content_vg_page_xpath
            )
            assert element3.is_displayed()
            element4 = self.driver.find_element(
                By.XPATH, 
                oldlocators.content_va_page_xpath
            )
            assert element4.is_displayed()
        except Exception:
            assert False


    def get_text_first_virtual_account_name(self):
        """ This method helps to get text from the first topic drop down """
        first_virtual_group_name = self.wait.until(
            EC.visibility_of_element_located((By.XPATH, virtual_account_locator.first_virtual_account_group_name))
        ).text
        LOGGER.info(
            f"{first_virtual_group_name} is selected in first section from drop down  "
        )
        return first_virtual_group_name

    def name_already_existing_error_message_is_displayed(self):
        try:
            client_present_list = self.wait.until(
                EC.visibility_of_element_located(
                    (By.XPATH, virtual_account_locator.error_message_on_providing_existing_name)
                )
            ).is_displayed()
            if client_present_list:
                LOGGER.info(" virtual team is displayed")
                return True

        except:
            LOGGER.info(" virtual team is not displayed")
            return False

    def check_the_next_button_is_enable(self):
        """This method helps us check whether the next button is enable or not
        Returns
        --------- bool val"""
        next_button=self.driver.find_element(
            By.XPATH, 
            oldlocators.next_button_va_creation_xpath
        ).is_enabled()
        return next_button

    def check_the_create_is_enable(self):
        """ this method helps to check that  create button is enable or not"""
        create_button = self.driver.find_element(
            By.XPATH, 
            oldlocators.create_button_va_xpath
        ).is_enabled()
        return create_button

    def click_on_create_virtual_group(self):
        """This method helps to click on the  create virtual group button"""
        time.sleep(2)

        virtual_group = self.driver.find_element(
            By.XPATH, 
            oldlocators.create_a_virtual_group_xpath
        )
        self.driver.execute_script("arguments[0].scrollIntoView(true);", virtual_group)
        self.driver.execute_script("arguments[0].click();", virtual_group)

    def click_on_next_button(self):
        """This method helps to click on the next button """
        time.sleep(1)
        self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, virtual_account_locator.next_button)
            )
        ).click()

    def search_virtual_account_in_virtual_group(self,agent):
        """This method helps to search the virtual account in the virtual group """
        self.driver.find_element(
            By.XPATH, 
            virtual_account_locator.search_in_virtual_group
        ).send_keys(agent)

    def select_first_virtual_account_or_agents(self):
        """this method helps to select yhe first virtual account or agents"""
        # my_elem_a = self.driver.find_element(By.XPATH, oldlocators.list_selection_1)
        #
        # ActionChains(self.driver).click(my_elem_a).perform()
        self.click_on_element(
            (By.XPATH, oldlocators.list_selection_1),
            message=f"failed to click on  first agents"
        )

    def select_second_virtual_account_or_agents(self):
        """ This method helps to select the select virtual account or agents"""

        self.click_on_element(
            (By.XPATH, oldlocators.list_selection_2),
            message=f"failed to click on  second agents"
        )

    def click_on_create_button(self):
        """This method helps to click on the create button"""
        self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, virtual_account_locator.create_button)
            )
        ).click()

    def click_on_create_virtual_account(self):
        """This method helps to click on the  create the virtual account"""
        virtual_account = self.driver.find_element(
            By.XPATH, 
            oldlocators.create_a_virtual_account_xpath
        )
        self.driver.execute_script("arguments[0].scrollIntoView(true);", virtual_account)
        self.driver.execute_script("arguments[0].click();", virtual_account)

    def click_on_global_account(self):
        """This method helps to click on the global account"""
        self.driver.find_element(
            By.XPATH, 
            oldlocators.global_virtual_account_box_xpath
        ).click()

    def create_name_for_global_account(self, va_name):
        """ This method helps to enter the name in the create global name account"""
        virtual_account_name = self.driver.find_element(
            By.XPATH, 
            oldlocators.input_box_to_pass_va_name_id
        )
        virtual_account_name.send_keys(va_name)

    def search_agents_in_virtual_account(self):
        """This method helps to search the data in the search box """
        self.driver.find_element(
            By.XPATH, 
            oldlocators.search_customer_box_xpath
        ).send_keys("a")

    def click_on_global_group(self):
        """This method helps to click on the global account"""
        self.driver.find_element(
            By.XPATH, 
            virtual_account_locator.global_group
        ).click()


    def get_number_of_virtual_group_present_on_dashboard(self):
        """This method helps to get the text of number of virtual account  present on the dash board"""
        list_present_on_dashboard = self.driver.find_elements(
            By.XPATH, virtual_account_locator.list_of_virtual_group_present
        )
        no_of_list = len(list_present_on_dashboard)
        LOGGER.info(f"virtual group present on dash board {no_of_list}")
        return no_of_list

    def click_on_delete_first_virtual_group(self,va_name):
        """This method helps to  delete the virtual account or group"""

        self.driver.find_element(
            By.XPATH, 
            virtual_account_locator.delete_first_virtual_group.replace("TEXT_PLACEHOLDER", va_name)
        ).click()

    def click_on_delete_button_on_pop_up(self):
        """This method helps to click on the delete button"""
        self.driver.find_element(
            By.XPATH, 
            virtual_account_locator.delete_pop_up
        ).click()

    def get_number_of_agent_or_account_on_expanding_virtual(self):
        """This method helps to get the number of agent or account present  on expanding  virtual group or agents"""
        list_present_on_dashboard = self.driver.find_elements(
            By.XPATH, virtual_account_locator.get_number_on_agents_on_expanding_virtual_group
        )
        no_of_list = len(list_present_on_dashboard)
        LOGGER.info(f"list present on the dash board {no_of_list}")
        return no_of_list

    def click_on_edit_virtual_group(self,va_name):
        """This method helps to click edit button virtual group"""
        self.driver.find_element(
            By.XPATH, 
            virtual_account_locator.edit_first_virtual_group.replace("TEXT_PLACEHOLDER", va_name)
        ).click()

    def click_on_first_vg(self):
        """This method helps  virtual group"""
        LOGGER.info("click on first virtual group ")

        self.click_on_element(
            (By.XPATH, virtual_account_locator.first_virtual_group_name),
            timeout=30,
        )


    def get_virtual_group_name(self):
        """This method helps to get the virtual group name"""
        first_virtual_group_name = self.wait.until(
            EC.visibility_of_element_located((By.XPATH, virtual_account_locator.first_virtual_group_name))
        ).text
        LOGGER.info(
            f"{first_virtual_group_name} is selected in first section from drop down  "
        )
        return first_virtual_group_name

    def click_on_save_button(self):
        """This method helps to click on the virtual """
        self.click_on_element(
            (By.XPATH, virtual_account_locator.save_button),
            timeout=10,
        )
        LOGGER.info(f"about to click on save button ")

    def click_on_virtual_group_remove_icon_in_edit_virtual_group(self):
        """This method helps to remove the virtual account or agent from the virtual group or account in edit state """
        self.click_on_element(
            (By.XPATH, virtual_account_locator.remove_agents_from_virtual_group),
            timeout=5,
        )
        LOGGER.info(f"about to click on save button ")

    def get_number_of_virtual_account_present_on_dashboard(self):
        """This method helps to get the text of number of virtual account  present on the dash board"""
        list_present_on_dashboard = self.driver.find_elements(
            By.XPATH, virtual_account_locator.list_of_virtual_account_present
        )
        no_of_list = len(list_present_on_dashboard)
        LOGGER.info(f"virtual group present on dash board {no_of_list}")
        return no_of_list

    def click_virtual_virtual_group_name_expand(self):
        """This method helps to click virtual team expand arrow to display  list of virtual org"""
        LOGGER.warning("clicking on first expand button in virtual group ... ")
        virtual_team_locator = self.wait.until(
                EC.element_to_be_clickable(
                    (By.XPATH, virtual_account_locator.first_virtual_group_expand)
                )
            )
        self.actions.move_to_element(virtual_team_locator).click().perform()

    def click_on_close_expand_virtual_group(self):
        """This method helps to click virtual team close expand virtual group """
        virtual_team_locator = self.wait.until(
                EC.element_to_be_clickable(
                    (By.XPATH, virtual_account_locator.un_expand_first_virtual_group)
                )
            )
        self.actions.move_to_element(virtual_team_locator).click().perform()


    def check_for_virtual_account_or_group_present_or_not(self, va_name):
        """This method helps to check whether a virtual account is created or not"""
        try:
            time.sleep(3)
            va_name_list = self.driver.find_element(
                By.XPATH, 
                virtual_account_locator.va_name_title.replace('TEXT_PLACEHOLDER', va_name)
            )
            LOGGER.info(va_name_list.text)
            self.driver.execute_script("arguments[0].scrollIntoView(true);", va_name_list)
            if va_name_list.is_displayed():
                LOGGER.info(f"{va_name } is present in list")
                return True
        except:
            LOGGER.info(f"{va_name} virtual account or group is not  present  ")
            return False

    def create_virtual_account(self):
        """This method helps to create virtual account"""
        self.click_on_create_virtual_account()
        self.click_on_global_account()
        va_name = utils.generate_test_run_id(constants.VA_GLOBAL_RUN_ID_PREFIX)
        self.create_name_for_global_account(va_name)
        self.click_on_next_button()
        self.search_agents_in_virtual_account()
        self.select_first_virtual_account_or_agents()
        self.select_second_virtual_account_or_agents()
        self.click_on_create_button()
        return va_name

    def create_virtual_group(self):
        """This method helps to create the virtual group"""
        self.click_on_create_virtual_group()
        self.click_on_global_group()
        va_name = utils.generate_test_run_id(constants.VA_GLOBAL_RUN_ID_PREFIX)
        self.create_name_for_global_account(va_name)
        self.click_on_next_button()
        self.search_virtual_account_in_virtual_group(agent="a")
        self.select_first_virtual_account_or_agents()
        self.select_second_virtual_account_or_agents()
        self.click_on_create_button()
        return va_name


    def check_the_number_of_virtual_account_or_agents_present(self):
        """ this method helps  check number of virtual account or list is created"""
        number_of_virtual_account = self.driver.find_element(By.XPATH, virtual_account_locator.virtual_account_search_result)
        return number_of_virtual_account

    def edit_virtual_group_name(self,va_name):
        """This method helps to edit virtual account and group name in edit list"""
        self.click_on_element((By.XPATH,virtual_account_locator.pencil_icon_on_virtual_group)
                              ,message="failed to click on pencil icon",timeout=5)
        virtual_account_name = self.driver.find_element(
            By.XPATH, 
            virtual_account_locator.edit_name_virtual_account_group
        )
        virtual_account_name.send_keys(va_name)

    def delete_virtual_account(self):
        virtual_account = self.driver.find_elements(
            By.XPATH, 
            virtual_account_locator.virtual_account_name)
        for va_name in virtual_account:
            qa_va_name = va_name.text
            if "VA Global" in qa_va_name:

                name=self.driver.find_element(By.XPATH, virtual_account_locator.va_name_title.replace("TEXT_PLACEHOLDER",qa_va_name))
                self.driver.execute_script("arguments[0].scrollIntoView(true);", name)
                self.click_on_delete_first_virtual_group(qa_va_name)
                self.click_on_delete_button_on_pop_up()
                time.sleep(5)
                # this method helps to check that  is deleted
                assert self.check_for_virtual_account_or_group_present_or_not(
                    qa_va_name) is False, "failed to delete virtual group"



