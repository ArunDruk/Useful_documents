"""
This file has reusables for the actions in the settings page.
WARNING: Any changes made to the settings module will affect all the users.
"""
import logging
import time

from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.by import By

from enums import SettingsSectionUrlSuffix
from locators import settings_locators
from pom_library import console_page
from pom_library.helper_methods import HelperMethods

LOGGER = logging.getLogger(__name__)


class SettingsPage(HelperMethods):
    """
    This Page has all the actions which can be verified and performed in the settings module and which directly affects
    the other modules of the dashboard.
    """

    def go_to_settings_section(self, section_url_suffix: SettingsSectionUrlSuffix) -> None:
        if section_url_suffix.value in self.driver.current_url:
            return
        self.driver.get(self.base_url + section_url_suffix.value)

    def check_if_settings_page_is_present_in_dashboard(self):
        """ This method checks that the settings module is present in the dashboard """
        try:
            page = console_page.ConsolePage(self.driver)
            page.click_in_the_control_centre_button()
            if self.driver.find_element(
                By.XPATH, settings_locators.settings_clickable_text_xpath
            ).is_displayed():
                LOGGER.info("Yes the settings module is visible")
                return True

            else:
                LOGGER.info("No, the settings module is not visible")
                return False

        except Exception:
            return False

    def click_production_edition_sl_admins(self):
        """
        This method helps to click on the product edition section present in settings module. This section controls which
         all pages will be visible in the dashboard or whose access will be restricted based on sales team decisions.

        """
        try:
            time.sleep(5)
            self.driver.find_element(
                By.XPATH, settings_locators.production_edition_section_xpath
            ).click()
        except NoSuchElementException:
            assert False

    def check_which_edition_builder_is_enabled(self):
        """
        This method helps to check which edition builder is enabled in the dashboard.

        """
        try:
            time.sleep(2)
            standard_edition = self.driver.find_element(
                By.XPATH, settings_locators.production_edition_standard_version_xpath
            )
            standard_edition_selection_status = standard_edition.is_selected()
            time.sleep(2)
            print(standard_edition_selection_status)
            time.sleep(2)
            pro_edition = self.driver.find_element(
                By.XPATH, settings_locators.production_edition_pro_version_xpath
            )
            pro_edition_selection_status = pro_edition.is_selected()
            time.sleep(2)
            print(pro_edition_selection_status)
            time.sleep(2)
            enterprise_edition = self.driver.find_element(
                By.XPATH, settings_locators.production_edition_enterprise_version_xpath
            )
            enterprise_edition_selection_status = enterprise_edition.is_selected()
            time.sleep(2)
            print(enterprise_edition_selection_status)
            time.sleep(2)
            custom_edition = self.driver.find_element(
                By.XPATH, settings_locators.production_edition_custom_version_xpath
            )
            time.sleep(2)
            custom_edition_selection_status = custom_edition.is_selected()
            print(custom_edition_selection_status)
            if standard_edition_selection_status is True:
                return "standard edition is selected"

            elif pro_edition_selection_status is True:
                return "Pro edition is selected"

            elif enterprise_edition_selection_status is True:
                return "Enterprise version is selected"

            elif custom_edition_selection_status is True:
                return "custom edition is selected"

        except NoSuchElementException:
            assert False

    def get_text_first_case_field_name_in_show_in_filter(self):
        """This method helps to get the text of sort by filter on """
        get_first_case_field_name = self.get_element_text_or_value(
            (By.XPATH, settings_locators.get_field_name)
        )
        return get_first_case_field_name

    def check_for_case_field_toggle_enable_or_not(self,case_field_name):
        """This method helps to checks for toggle enable or disable case field """
        if self.is_element_visible((By.XPATH, settings_locators.first_case_filed_toggle_enable_or_disable.replace("text_placeholder", case_field_name)), timeout=30):
            return True
        else:
            return False

