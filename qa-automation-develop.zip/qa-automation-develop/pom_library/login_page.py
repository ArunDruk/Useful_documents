"""This Page has all the actions that can be performed in the respective fields/ locators. This page will be
called by those methods which wants to use the values to perform some tests in the login page."""
import logging
import os
import time
from typing import Any, Union

from enums import UserType
from locators import oldlocators
from pom_library import settings_page, console_page
from pom_library.pom_base import PomBase
from pom_library.settings_page import SettingsPage

LOGGER = logging.getLogger(__name__)


class LoginPage(PomBase):
    """ This class has all the actions needed to test the login and user type"""

    # declaring the driver to use it in overall page
    def __init__(self, driver):
        self.driver = driver
        PomBase.__init__(self, self.driver)

    # This method focuses on clicking the clickable text sign-in-via-email and can be used when the user wants to do
    # normal login.
    def click_on_sign_in_email_text(self):
        """ This method clicks on the username text field for email/password authentication"""
        self.driver.find_element(By.ID, oldlocators.sign_in_via_email).click()

    # Verify the title loads after successful login
    def get_current_url_of_the_page_after_login(self):
        """ This method focuses to get the page's current url and return the same whenever used"""
        time.sleep(
            15
        )  # This time is given so that the main url can load and the code can detect the url
        get_url = (
            self.driver.current_url
        )  # fetches the current url of the system and return it to the code
        # where it is used.
        return get_url

    # Pass the values in the email field when the login is normal.
    def pass_input_to_email_field(self, username):
        self.driver.find_element(By.ID, oldlocators.email_user).send_keys(username)

    # Pass the password value for normal login
    def pass_password_to_password_field(self, password):
        self.driver.find_element(By.ID, oldlocators.password_user).send_keys(password)

    # Click on the sign-in button after filling email and password.
    def click_on_sign_in(self):
        self.driver.find_element(
            By.XPATH, 
            oldlocators.login_button_sign_in_via_email
        ).click()

    def identify_current_user_type(self):
        """ This methods checks the type of user based on the value received in $SL_USER """
        try:
            LOGGER.info(
                "Method starts execution for >identify_the_user_Logging_in_the_system "
            )
            email_set = os.getenv("SL_USER")  # Fetching the SL_USER email details
            # LOGGER.info(email_set)
            domain_email: Union[str, Any] = email_set[
                email_set.index("@") + 1 :
            ]  # Fetching the domain name from the SL_USER data
            # LOGGER.info(domain_email)
            console = console_page.ConsolePage(self.driver)
            settings = settings_page.SettingsPage(self.driver)

            control_centre_is_present = (
                console.check_if_control_centre_button_is_present()
            )
            if not control_centre_is_present:
                return UserType.NORMAL

            # settings page is accessible or not to determine whether it is ADMIN or NORMAL user
            settings_is_visible = (
                settings.check_if_settings_page_is_present_in_dashboard()
            )
            if settings_is_visible and "@supportlogic.io" in domain_email:
                return UserType.SL_ADMIN
            elif settings_is_visible:
                return UserType.ADMIN
            else:
                return UserType.NORMAL
        except Exception:
            LOGGER.info("The environment variable is not set > $SL_USER")
            return "No Val for $SL_USER"
