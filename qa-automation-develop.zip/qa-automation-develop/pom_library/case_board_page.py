"""
A collection of test scenarios for the Case Board page
"""
__author__ = "Jacob Mathew"
__copyright__ = "Copyright (C) 2021 SupportLogic"

import logging
import time
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from random import randint
import utils
import constants
from pom_library. helper_methods import HelperMethods
from locators import caseboard_locators
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait

LOGGER: logging.Logger = logging.getLogger(__name__)


class CaseBoardPage(HelperMethods):
    def __init__(self, driver):
        self.driver = driver
        self.wait = WebDriverWait(driver, 60)



    def click_case_page_from_menubar(self):
        """
        This function will click on the Case Board menu in the Navbar
        """
        case_board_menu = WebDriverWait(self.driver, 10).until(
            EC.visibility_of_element_located(
                (By.XPATH, caseboard_locators.case_board_page_menu_id)
            )
        )
        LOGGER.info("Clicking on the Caseboard menu from Navbar")
        case_board_menu.click()

    def if_welcome_page_click_default_lists_set(self):
        """
        Click on the `Default lists set` button on the Case board welcome page
        """
        try:
            welcome_page_button = self.driver.find_element(
                By.XPATH, 
                caseboard_locators.default_lists_button
            )
            if welcome_page_button.is_displayed() and welcome_page_button.is_enabled():
                welcome_page_button.click()
                WebDriverWait(self.driver, 5).until(
                    EC.visibility_of_element_located(
                        (By.XPATH, caseboard_locators.add_case_list_button)
                    )
                )
            else:
                raise Exception(
                    "No welcome page buttons displayed. So not a welcome page"
                )

        except NoSuchElementException:
            pass

    def count_case_lists_in_caseboard(self):
        list_present_on_dashboard = self.driver.find_elements(
            By.XPATH, caseboard_locators.case_lists
        )
        no_of_list = len(list_present_on_dashboard)
        LOGGER.info(f"list present on the dash board {no_of_list}")
        return no_of_list

    def click_on_add_case_list_button(self):
        """
        Function to click on the Add Case List Button
        """
        add_case_list_button = WebDriverWait(self.driver, 30).until(
            EC.visibility_of_element_located(
                (By.XPATH, caseboard_locators.add_case_list_button)
            )
        )
        LOGGER.info("Clicking on Add Caselist floating button")
        add_case_list_button.click()

    def check_if_add_case_list_modal_opens(self):
        """
        This will return a boolean value to see if `Add Case List`
        modal window is appearing or not.
        :return: Boolean
        """
        add_case_list_modal_appearing = self.driver.find_element(
            By.XPATH, 
            caseboard_locators.cancel_button_on_add_case_list_modal
        ).is_displayed()
        if add_case_list_modal_appearing:
            return True
        else:
            return False

    def add_new_name_for_list(self):
        """
        To give a name to the new list or while editing the list name.
        """
        new_case_list_name = utils.generate_test_run_id(
            constants.case_board_list_name_prefix
        )
        LOGGER.info("Key board input of the case list name")
        self.driver.find_element(
            By.XPATH, 
            caseboard_locators.name_field_for_new_case_list
        ).send_keys(new_case_list_name)
        return new_case_list_name

    def edit_name_for_list(self, edit_text):
        """
        Add a string to the already existing case list name
        """
        LOGGER.info(f"Adding {edit_text} to the Case list's original title")
        self.driver.find_element(
            By.XPATH, 
            caseboard_locators.name_field_for_new_case_list
        ).send_keys(edit_text)

    def check_if_next_button_is_not_enabled(self):
        """
        check if the Next button in the case list creation modal is NOT enabled.
        :return:Boolean
        """
        next_button = self.driver.find_element(
            By.XPATH, 
            caseboard_locators.next_button_on_add_case_list_modal
        )
        next_button_flag = next_button.get_property("disabled")
        if next_button_flag:
            return True
        else:
            print("NEXT Button is Enabled before entering a list name- ERROR")
            return False

    def check_if_next_button_is_enabled(self):
        """
        check if the Next button in the case list creation modal is enabled.
        :return:Boolean
        """
        next_button_is_enabled = self.driver.find_element(
            By.XPATH, 
            caseboard_locators.next_button_on_add_case_list_modal
        ).is_enabled
        if next_button_is_enabled:
            return True
        else:
            print("NEXT Button is NOT Enabled after entering a case list name- ERROR")
            return False

    def click_next_button(self):
        """
        Clicking on the `Next` Button in the case list creation flow
        after passing a name to the case list.
        """
        LOGGER.info("Clicking on NEXT button on the add case list modal")
        self.driver.find_element(
            By.XPATH, 
            caseboard_locators.next_button_on_add_case_list_modal
        ).click()

    def click_cancel_button(self):
        """
        Clicking on the `Cancel` button to come out of the
        case list creation flow.
        """
        LOGGER.info("Clicking on CANCEL button on the add case list modal")
        self.driver.find_element(
            By.XPATH, 
            caseboard_locators.cancel_button_on_add_case_list_modal
        ).click()

    def click_back_button(self):
        """
        After adding a name to case list - user clicks next.
        If user has to go back to the earlier step click on this back button
        """
        LOGGER.info("Clicking on BACK button on the add case list modal")
        self.driver.find_element(
            By.XPATH, 
            caseboard_locators.back_button_on_add_case_list_modal
        ).click()

    def select_a_random_list_choice(self):
        """
        Select a random choice from the radio buttons available for
        the selection of type of the list.
        """
        list_options = self.driver.find_elements(
            By.XPATH, 
            caseboard_locators.radio_buttons_for_case_ranking
        )
        radio_button_to_be_selected = randint(1, len(list_options))
        # Clicking on a random radio button to select a list type
        LOGGER.info("Selecting a random Ranking option on the add case list modal")
        radio_button_to_be_clicked = self.driver.find_element(
            By.XPATH, 
            "("
            + caseboard_locators.radio_buttons_for_case_ranking
            + ")"
            + "["
            + str(radio_button_to_be_selected)
            + "]"
        )
        self.driver.execute_script("arguments[0].click();", radio_button_to_be_clicked)

    def check_if_create_button_enabled(self):
        """
        Check if the create button is enabled in the create case list modal window.
        :return: Boolean
        """
        create_button_is_enabled = self.driver.find_element(
            By.XPATH, 
            caseboard_locators.create_button_on_add_case_list_modal
        ).is_enabled
        if create_button_is_enabled:
            return True
        else:
            return False

    def check_if_create_button_is_not_enabled(self):
        """
        Check the create button is NOT enabled in the create case list modal window.
        :return: Boolean
        """
        create_button = self.driver.find_element(
            By.XPATH, 
            caseboard_locators.create_button_on_add_case_list_modal
        )
        create_button_enabled_flag = create_button.get_property("disabled")
        if create_button_enabled_flag:
            return True
        else:
            return False

    def click_create_button(self):
        """
        Click on the `Create` button for the creation of a case list.
        """
        LOGGER.info("Clicking on CREATE button on the add case list modal")
        self.driver.find_element(
            By.XPATH, 
            caseboard_locators.create_button_on_add_case_list_modal
        ).click()

    def check_name_of_first_case_list(
        self, list_name=caseboard_locators.new_case_list_name
    ):
        """
        Checking if the case list got created or not after clicking CREATE button
        :return: Boolean value
        """
        first_case_list_name_container = self.driver.find_element(
            By.XPATH, 
            caseboard_locators.first_case_list_name_container
        )
        name_of_first_list = first_case_list_name_container.text
        if name_of_first_list == list_name:
            """
            The newly created list always resides on the 1st position.
            If the name of 1st list in case board and the list_name
            are same -> prove the new list got created successfully
            """
            return True
        else:
            return False

    def get_title_of_case_list(self, list_position):
        """
        Returns case list title of the position is known
        """
        list_element = (
            caseboard_locators.case_list_name_container + "[" + str(list_position) + "]"
        )
        WebDriverWait(self.driver, 3).until(
            EC.visibility_of_element_located((By.XPATH, list_element))
        )
        case_list_name_container = self.driver.find_element(By.XPATH, list_element)
        title_of_case_list = case_list_name_container.text
        return title_of_case_list

    def click_case_list_option_vertical_dots(self):
        """
        To click on the vertical dots on the top of case list newly created
        """
        button_to_be_selected = self.driver.find_element(
            By.XPATH, 
            caseboard_locators.case_list_options_vertical_dots_of_first_list
        )
        LOGGER.info("Clicking on the Options(Vertical Dots) on first case list")
        button_to_be_selected.click()

    def click_options_button_on_nth_list(self, list_position=1):
        """
        Clicking on the Options(Vertical Dots) on nth Case list
        """
        LOGGER.info(
            f"Clicking on the Options(Vertical Dots) on case list positioned at {list_position}"
        )
        self.driver.find_element(
            By.XPATH, 
            caseboard_locators.case_list_options_button_on_nth_list
            + "["
            + str(list_position)
            + "]"
        ).click()

    def click_edit_list_button(self):
        """
        Click on the Edit list button in the Options dropdown
        """
        edit_list_button = self.driver.find_element(
            By.XPATH, 
            caseboard_locators.edit_option_in_options_dropdown
        )
        LOGGER.info("Clicking on the EDIT LIST choice from options dropdown")
        self.driver.execute_script("arguments[0].click();", edit_list_button)

    def click_delete_list_button(self):
        """
        Click on the Delete list button in the Options dropdown
        """
        delete_list_button = self.driver.find_element(
            By.XPATH, 
            caseboard_locators.delete_list_in_options_dropdown
        )
        LOGGER.info("Clicking on the DELETE LIST choice from options dropdown")
        self.driver.execute_script("arguments[0].click();", delete_list_button)

    def click_edit_list_option(self):
        """
        For clicking on the Edit list button and to go into
        the EDIT CASE LIST Logic flow.
        """
        LOGGER.info("Clicking on the Options(Vertical Dots) on first case list")
        self.driver.find_element(
            By.XPATH, 
            caseboard_locators.case_list_options_vertical_dots_of_first_list
        ).click()
        LOGGER.info("Clicking on the EDIT LIST choice from options dropdown")
        self.driver.find_element(
            By.XPATH, 
            caseboard_locators.edit_option_in_options_dropdown
        ).click()

    def click_apply_change_button_in_edit_flow(self):
        """
        Function to click on the `Apply Change` button in the Edit List modal
        """
        LOGGER.info("Clicking on the APPLY CHANGE button on edit case list modal.")
        self.driver.find_element(
            By.XPATH, 
            caseboard_locators.apply_change_button_in_edit_case_list_modal
        ).click()

    def open_delete_case_list_modal_of_first_case_list(self):
        """
        This function will delete the first case list in the page.
        """
        self.driver.find_element(
            By.XPATH, 
            caseboard_locators.case_list_options_vertical_dots_of_first_list
        ).click()
        self.driver.find_element(
            By.XPATH, 
            caseboard_locators.delete_list_in_options_dropdown
        ).click()

    def click_delete_in_delete_modal(self):
        """
        This function will click on the delete button on the Delete modal
        """
        delete_button = self.driver.find_element(
            By.XPATH, 
            caseboard_locators.delete_button_in_delete_modal
        )
        delete_button.click()
        WebDriverWait(self.driver, 2).until(
            EC.invisibility_of_element_located(
                (By.XPATH, caseboard_locators.delete_button_in_delete_modal)
            )
        )

    def check_if_delete_modal_open(self):
        """
        This function will check if the delete modal is opened/closed
        """
        delete_modal_open_boolean = self.driver.find_element(
            By.XPATH, 
            caseboard_locators.delete_button_image
        ).is_displayed()
        # if delete modal is Displayed means cancel operation failed.
        return delete_modal_open_boolean

    def click_on_expand_view_button_under_an_arbitrary_list(self, list_position):
        """
        Click on the expanded view button under a case list to check expanded view
        """
        action = ActionChains(self.driver)
        expand_button = self.driver.find_element(
            By.XPATH, 
            "("
            + caseboard_locators.case_list_expand_button
            + ")["
            + str(list_position)
            + "]"
        )
        LOGGER.info(
            f"Clicking on expand view button under a case list positioned at {list_position}"
        )
        action.move_to_element(expand_button).click()

    def click_on_expand_button_on_first_case_list(self):
        """
        This function will click on the Expand button on the first case list
        """
        expand_button = self.driver.find_element(
            By.XPATH, 
            caseboard_locators.first_case_list_expand_button
        )
        LOGGER.info("Clicking on expand view button under first case list.")
        self.driver.execute_script("arguments[0].click();", expand_button)

    def check_if_case_list_expanded(self):
        """
        Function used for asserting the case list expanded view is active.
        """
        LOGGER.info("Checking if Case list Expanded")
        case_list_expanded_boolean = self.driver.find_element(
            By.XPATH, 
            caseboard_locators.case_list_expanded_modal
        ).is_displayed()
        return case_list_expanded_boolean

    def click_on_close_expand_view_button(self):
        """
        Click on the close button to exit expanded view
        """
        LOGGER.info("Clicking on Close expand view button of a case list.")
        cross_button = self.wait.until(
            EC.element_to_be_clickable((By.XPATH, caseboard_locators.case_list_expand_view_close_button))
        )
        self.driver.execute_script("arguments[0].click();", cross_button)

    def check_if_expanded_case_list_closed(self):
        """
        Will check if the expand view - Close button is_displayed()
        if true -> Case list closing failed
        else -> Case list successfully closed.
        """
        self.driver.implicitly_wait(1)
        LOGGER.info("Checking if Expanded view is closed")
        expanded_case_list_close_button = WebDriverWait(self.driver, 20).until(
            EC.invisibility_of_element_located(
                (By.XPATH, caseboard_locators.case_list_expand_view_close_button)
            )
        )
        return expanded_case_list_close_button

    def delete_all_case_lists_in_caseboard(self):
        """
        This function will delete all the existing case lists in case board
        """
        count_of_lists = self.count_case_lists_in_caseboard()
        while count_of_lists > 0:
            count_of_lists = count_of_lists - 1
            self.open_delete_case_list_modal_of_first_case_list()
            self.click_delete_in_delete_modal()

    def custom_list_creation(self):
        """
        This function will create a case list using the Custom List creation
        flow from the welcome page/ empty state view of Case board
        """
        create_custom_list_button = self.driver.find_element(
            By.XPATH, 
            caseboard_locators.custom_lists_button
        )
        LOGGER.info("Clicking on CUSTOM List button from Case board Welcome page")
        create_custom_list_button.click()
        self.add_new_name_for_list()
        self.click_next_button()
        self.select_a_random_list_choice()
        self.click_create_button()
        WebDriverWait(self.driver, 3).until(
            EC.presence_of_element_located(
                (By.XPATH, caseboard_locators.first_case_list_name_container)
            )
        )

    def default_case_lists_creation(self):
        """
        This function will create the 8 default lists from the Welcome page.
        """
        default_list_button = self.driver.find_element(
            By.XPATH, 
            caseboard_locators.default_lists_button
        )
        LOGGER.info("Clicking on DEFAULT List button from Case board Welcome page")
        default_list_button.click()
        WebDriverWait(self.driver, 10).until(
            EC.presence_of_element_located(
                (By.XPATH, caseboard_locators.first_case_list_name_container)
            )
        )

    def click_on_a_case_to_open_supporthub(self):
        single_case = self.driver.find_element(
            By.XPATH, 
            caseboard_locators.single_case_in_a_list
        )
        single_case.click()

    def if_cancelling_case_list_creation_succeed(self):
        add_case_list_modal_appearing = self.driver.find_elements(
            By.XPATH, 
            caseboard_locators.cancel_button_on_add_case_list_modal
        )
        if len(add_case_list_modal_appearing) > 0:
            return False
        else:
            return True

    def click_cancel_button_on_delete_modal(self):
        """
        Clicking on the Cancel button on Delete modal to cancel delete action
        """
        cancel_button_on_delete_modal = self.driver.find_element(
            By.XPATH, 
            caseboard_locators.cancel_button_in_delete_modal
        )
        LOGGER.info("Clicking on Cancel button on Delete Modal")
        self.driver.execute_script(
            "arguments[0].click();", cancel_button_on_delete_modal
        )

    def check_if_delete_modal_is_closed(self):
        delete_button = self.driver.find_elements(
            By.XPATH, 
            caseboard_locators.delete_button_in_delete_modal
        )
        if len(delete_button) > 0:
            return False
        else:
            return True

    def check_for_presence_of_list_on_dashboard(self):
        try:
            client_present_list = self.wait.until(
                EC.visibility_of_element_located(
                    (By.XPATH, caseboard_locators.case_lists)
                )
            ).is_displayed()
            if client_present_list:
                LOGGER.info(" list present on case board")
                return True

        except:
            LOGGER.info("  list present is not case board")
            return False


    def click_on_switch_sort_button(self):
        """This method helps to click on click on switch sort button  """

        self.click_on_element(
            (By.XPATH, caseboard_locators.switch_sort_xpath),
            message="failed to click on switch sort",
        )

    def get_first_list_first_case_id(self):
        """This method helps to click on first list first case id"""
        return self.get_element_text_or_value(
            (By.XPATH, caseboard_locators.first_list_first_case_id),
            message="failed to get first list first case id",
        ).strip()


    def fetch_sentiments_score_in_sentiments_list(self):
        """This method helps to fetch the sentiments score from sentiments list"""
        list_data = []
        count_sentiments = self.driver.find_elements(
            By.XPATH,caseboard_locators.sentiment_score_in_sentiments_list
        )
        for i in count_sentiments:

            list_data.append(i.text)
        return list_data

    def click_on_sentiment_score_radio_button(self):
        """This method helps to click on sentiments ecore radio button  """

        self.click_on_element(
            (By.XPATH, caseboard_locators.sentiment_score_radio_button),
            message="failed to click on sentiment score ",
        )

    def check_for_visibility_of_rank_cases_by_pop_up(self):
        """This method helps to display rank cases by pop up"""
        return self.is_element_visible((By.XPATH, caseboard_locators.rank_by_case_pop_up))

    def click_on_attention_score_radio_button(self):
        """This method helps to click on attention score radio button  """

        self.click_on_element(
            (By.XPATH, caseboard_locators.attention_score_radio_button),
            message="failed to click on attention score ",
        )

    def click_on_download_csv_method(self):
        """This method helps to click on down load csv"""
        self.click_on_element(
            (By.XPATH, caseboard_locators.download_csv),
            message="failed to click on download csv",
        )

