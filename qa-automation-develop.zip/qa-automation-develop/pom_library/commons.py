"""
This page contains the reusable methods for functionalities that are shared across the
application.

All methods on this page are user-type irrespective.
"""
from __future__ import annotations

__author__ = "Praveen Nagajothi"
__copyright__ = "Copyright (C) 2021 SupportLogic"

import logging

from selenium.common.exceptions import (
    ElementNotVisibleException, NoSuchElementException,
)
from selenium.webdriver import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support import expected_conditions as ec

from enums import NavbarItem, UserMenuOption
from locators import common_locators as cl
from pom_library.helper_methods import HelperMethods

LOGGER: logging.Logger = logging.getLogger(__name__)


class Commons(HelperMethods):
    def wait_for_loader_to_disappear(self) -> None:
        """
        Waits for the colorful page load animation to disappear

        Returns
        -------
        bool
            True on the disappearance of loader animation
        """
        LOGGER.info("Waiting for the page load animation to disappear..")
        self.wait.until_not(
            ec.visibility_of_element_located(
                (By.CSS_SELECTOR, cl.animated_loader_large_css)
            ),
            message="Page data did not load within 30 seconds.",
        )

    def start_module_onboarding(self) -> None:
        """
        This method is for handling the onboard screen, if it is encountered.

        Please note that this method only handles the first step of onboarding.

        If there are further steps involved, create methods for them and use together
        with this method.
        """
        LOGGER.info("Onboarding in progress..")
        try:
            start_button: WebElement = self.driver.find_element(
                By.XPATH, cl.start_onboarding_button
            )
            if not (start_button.is_displayed() and start_button.is_enabled()):
                raise ElementNotVisibleException(
                    "Start button is not present or enabled in onboard page."
                )
            start_button.click()
        except NoSuchElementException:
            pass

    def search_globally_for(self, search_text: str) -> None:
        """
        Searches for the given text in the global search functionality present in
        the header.

        The search text must be at least 2 characters.

        Parameters
        ----------
        search_text: int or str
            A string value to be searched.
        """
        LOGGER.info(f"searching globally for: '{search_text}'")
        if len(search_text.strip()) < 2:
            raise ValueError("Search text is too short")

        LOGGER.info("Clicking on global search icon..")
        self.javascript_click_on_element(
            (By.CSS_SELECTOR, cl.search_icon_css),
            message="Failed to click the search icon",
        )

        LOGGER.info(f"Typing '{search_text}' in global search textbox..")
        self.pass_value_to_element(
            search_text,
            (By.CSS_SELECTOR, cl.search_input_box_css),
            message="search textbox is not visible or present",
        )

        if self.is_element_visible((By.XPATH, cl.no_results), timeout=3):
            raise ValueError(f"No results found for case title: '{search_text}'")

        self.click_on_element(
            (By.CSS_SELECTOR, cl.search_results_css),
            timeout=10,
            message=f"Failed to click on search results for '{search_text}'",
        )

    def go_to_user_menu_option(self, option: UserMenuOption) -> None:
        self.click_on_element((By.CSS_SELECTOR, cl.user_menu_icon_css))
        self.click_on_element(
            (By.CSS_SELECTOR, cl.user_menu_option_css.format(option=option.value))
        )

    def click_preference_favorite_customers(self) -> None:
        self.click_on_element((By.CSS_SELECTOR, cl.preference_favorite_customers_css))

    def search_in_preference_favorite_customers(self, search_text: str) -> None:
        self.pass_value_to_element(
            (search_text, Keys.TAB),
            (By.CSS_SELECTOR, cl.preference_fav_customers_search_css),
        )

    def close_user_preference_popup(self) -> None:
        self.click_on_element((By.XPATH, cl.preference_popup_close_btn))

    def click_preference_favorite_support_engineer(self) -> None:
        """This method helps to click on  fav support engineer"""
        self.click_on_element((By.XPATH, cl.preference_fav_support_engineer_xpath))

    def search_in_preference_favorite_support_engineer(self,search_text):
        """This method helps to search agent name in fav support engineer"""
        self.pass_value_to_element(
            search_text,
            (By.XPATH, cl.preference_fav_search_item_xpath),
        )

    def check_for_agent_is_present_in_preference_support_engineer(self,agents):
        """This method helps to check for agents is preference of support engineer"""
        if self.is_element_visible((By.XPATH, cl.agents_in_fav_tab.replace("agents_name",agents)), timeout=30):
           return True
        else:
           return False

    def reset_onboarding(self, modules: NavbarItem | list[NavbarItem]):
        if isinstance(modules, NavbarItem):
            pages = f"['{modules.value}']"
        else:
            pages = str([module.value for module in modules])
        script = """
            (() => {
                const pages = """ + pages + """;
                for (let pageName of pages) {
                    window.resetOnboarding(pageName);
                }
            })();
        """
        self.driver.execute_script(script)
