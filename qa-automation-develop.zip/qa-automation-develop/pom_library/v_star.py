"""A collection of reusables that perform specific actions on the V* modules"""

__author__ = "Praveen Nagajothi"
__copyright__ = "Copyright (C) 2022 SupportLogic"

import time

from selenium.webdriver import Keys
from selenium.webdriver.common.by import By

from enums import VStarType
from locators import v_star_locators as vsl
from pom_library.api_keywords import ApiKeywords
from pom_library.helper_methods import HelperMethods


class VStar(HelperMethods, ApiKeywords):
    def search_virtual_team(self, name: str) -> None:
        self.pass_value_to_element(
            name,
            (By.CSS_SELECTOR, vsl.search_virtual_team_textbox_css),
            message=f"Failed to search for {name}",
        )

    def search_virtual_account(self, name: str) -> None:
        self.pass_value_to_element(
            name,
            (By.CSS_SELECTOR, vsl.search_virtual_account_textbox_css),
            message=f"Failed to search for {name}",
        )

    def click_create_virtual_org_button(self) -> None:
        """Clicks on the `Create a Virtual Org` button"""
        self.click_on_element((By.CSS_SELECTOR, vsl.create_virtual_org_button_css))

    def click_create_virtual_team_button(self) -> None:
        """Clicks on the `Create a Virtual Team` button"""
        self.click_on_element((By.CSS_SELECTOR, vsl.create_virtual_team_button_css))

    def click_create_virtual_group_button(self) -> None:
        """Clicks on the `Create a Virtual Group` button"""
        self.click_on_element((By.CSS_SELECTOR, vsl.create_virtual_group_button_css))

    def click_create_virtual_account_button(self) -> None:
        """Clicks on the `Create a Virtual Account` button"""
        self.click_on_element((By.CSS_SELECTOR, vsl.create_virtual_account_button_css))

    def choose_new_v_star_type(self, _type: VStarType) -> None:
        locator: str = vsl.choose_type_button_css.format(type=_type.value)
        self.click_on_element((By.CSS_SELECTOR, locator))

    def enter_new_v_star_name(self, name: str) -> None:
        self.pass_value_to_element(name, (By.CSS_SELECTOR, vsl.create_name_textbox_css))

    def click_next_button(self) -> None:
        self.click_on_element((By.CSS_SELECTOR, vsl.next_button_css))

    def search_for_item_in_v_star_creation(self, search_text: str) -> None:
        self.pass_value_to_element(search_text, (By.CSS_SELECTOR, vsl.search_box_css))

    def select_item_from_result(self) -> None:
        self.click_on_element((By.CSS_SELECTOR, vsl.search_result_item_css))

    def click_create_button(self) -> None:
        self.click_on_element((By.CSS_SELECTOR, vsl.create_button_css))

    def get_virtual_group_names(self) -> list[str]:
        v_groups = self.driver.find_elements(
            By.XPATH, vsl.virtual_group_list_item + vsl.virtual_star_item_name
        )
        return [group.text for group in v_groups]

    def get_virtual_account_names(self) -> list[str]:
        v_accounts = self.driver.find_elements(
            By.XPATH, vsl.virtual_account_list_item + vsl.virtual_star_item_name
        )
        return [account.text for account in v_accounts]

    def click_save_button(self) -> None:
        self.click_on_element((By.XPATH, vsl.virtual_star_save_button))

    def click_cancel_button(self) -> None:
        self.click_on_element((By.XPATH, vsl.virtual_star_cancel_button))

    def click_virtual_org_edit_button(self, name: str) -> None:
        vo_locator = (
            vsl.custom_virtual_star_item_name.format(name=name)
            + vsl.virtual_org_list_item
        )
        self.hover_on_element((By.XPATH, vo_locator))
        self.click_on_element((By.XPATH, vo_locator + vsl.virtual_star_edit_button))

    def click_virtual_team_edit_button(self, name: str) -> None:
        vt_locator = (
            vsl.custom_virtual_star_item_name.format(name=name)
            + vsl.virtual_team_list_item
        )
        self.hover_on_element((By.XPATH, vt_locator))
        self.click_on_element((By.XPATH, vt_locator + vsl.virtual_star_edit_button))

    def click_virtual_group_edit_button(self, name: str) -> None:
        vg_locator = (
            vsl.custom_virtual_star_item_name.format(name=name)
            + vsl.virtual_group_list_item
        )
        self.hover_on_element((By.XPATH, vg_locator))
        self.click_on_element((By.XPATH, vg_locator + vsl.virtual_star_edit_button))

    def click_virtual_account_edit_button(self, name: str) -> None:
        va_locator = (
            vsl.custom_virtual_star_item_name.format(name=name)
            + vsl.virtual_account_list_item
        )
        self.hover_on_element((By.XPATH, va_locator))
        self.click_on_element((By.XPATH, va_locator + vsl.virtual_star_edit_button))

    def edit_existing_or_cloned_v_star_name(
        self, current_name: str, new_name: str
    ) -> None:
        locator = vsl.virtual_star_edit_name_text.format(name=current_name)
        self.click_on_element((By.XPATH, locator))

        element = self.driver.find_element(
            By.CSS_SELECTOR, vsl.edit_existing_va_name_textbox_css
        )
        element.send_keys(Keys.DELETE)
        element.send_keys(new_name)

    def click_virtual_org_clone_button(self, name: str) -> None:
        vo_locator = (
            vsl.custom_virtual_star_item_name.format(name=name)
            + vsl.virtual_org_list_item
        )
        self.hover_on_element((By.XPATH, vo_locator))
        self.click_on_element((By.XPATH, vo_locator + vsl.virtual_star_clone_button))

    def click_virtual_team_clone_button(self, name: str) -> None:
        vt_locator = (
            vsl.custom_virtual_star_item_name.format(name=name)
            + vsl.virtual_team_list_item
        )
        self.hover_on_element((By.XPATH, vt_locator))
        self.click_on_element((By.XPATH, vt_locator + vsl.virtual_star_clone_button))

    def click_virtual_group_clone_button(self, name: str) -> None:
        vg_locator = (
            vsl.custom_virtual_star_item_name.format(name=name)
            + vsl.virtual_group_list_item
        )
        self.hover_on_element((By.XPATH, vg_locator))
        self.click_on_element((By.XPATH, vg_locator + vsl.virtual_star_clone_button))

    def click_virtual_account_clone_button(self, name: str) -> None:
        va_locator = (
            vsl.custom_virtual_star_item_name.format(name=name)
            + vsl.virtual_account_list_item
        )
        self.hover_on_element((By.XPATH, va_locator))
        self.click_on_element((By.XPATH, va_locator + vsl.virtual_star_clone_button))

    def click_virtual_org_delete_button(self, name: str) -> None:
        vo_locator = (
            vsl.custom_virtual_star_item_name.format(name=name)
            + vsl.virtual_org_list_item
        )
        self.hover_on_element((By.XPATH, vo_locator))
        self.click_on_element((By.XPATH, vo_locator + vsl.virtual_star_delete_button))

    def click_virtual_team_delete_button(self, name: str) -> None:
        vt_locator = (
            vsl.custom_virtual_star_item_name.format(name=name)
            + vsl.virtual_team_list_item
        )
        self.hover_on_element((By.XPATH, vt_locator))
        self.click_on_element((By.XPATH, vt_locator + vsl.virtual_star_delete_button))

    def click_virtual_group_delete_button(self, name: str) -> None:
        vg_locator = (
            vsl.custom_virtual_star_item_name.format(name=name)
            + vsl.virtual_group_list_item
        )
        self.hover_on_element((By.XPATH, vg_locator))
        self.click_on_element((By.XPATH, vg_locator + vsl.virtual_star_delete_button))

    def click_virtual_account_delete_button(self, name: str) -> None:
        va_locator = (
            vsl.custom_virtual_star_item_name.format(name=name)
            + vsl.virtual_account_list_item
        )
        self.hover_on_element((By.XPATH, va_locator))
        self.click_on_element((By.XPATH, va_locator + vsl.virtual_star_delete_button))

    def click_delete_confirmation_button(self) -> None:
        self.click_on_element((By.XPATH, vsl.delete_confirmation_button))

    def create_global_virtual_account(self, va_name: str, customers: list[str]) -> None:
        self.click_create_virtual_account_button()
        self.choose_new_v_star_type(VStarType.GLOBAL_ACCOUNT)
        self.enter_new_v_star_name(va_name)
        self.click_next_button()
        for customer in customers:
            self.search_for_item_in_v_star_creation(customer)
            time.sleep(1)
            self.select_item_from_result()
        self.click_create_button()

    def create_global_virtual_team(self, vt_name: str, agents: list[str]) -> None:
        self.click_create_virtual_team_button()
        self.choose_new_v_star_type(VStarType.GLOBAL_TEAM)
        self.enter_new_v_star_name(vt_name)
        self.click_next_button()
        for agent in agents:
            self.search_for_item_in_v_star_creation(agent)
            time.sleep(1)
            self.select_item_from_result()
        self.click_create_button()
