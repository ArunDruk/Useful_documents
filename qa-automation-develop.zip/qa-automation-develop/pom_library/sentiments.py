"""A collection of reusable methods that perform specific actions on the sentiment
page"""
__author__ = "Praveen Nagajothi"
__copyright__ = "Copyright (C) 2021 SupportLogic"

import datetime as dt
import logging
import random

from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support import expected_conditions as ec

import constants
from enums import CaseStatusFilter, SentimentGroup, SentimentMessageType
from locators import sentiments_locators as sl
from pom_library.helper_methods import HelperMethods

LOGGER: logging.Logger = logging.getLogger(__name__)


class Sentiments(HelperMethods):
    def __include_filter(
        self, message_type: SentimentMessageType, state: bool = True
    ) -> bool:
        """
        A private method that filters the sentiments based on given message type.

        If state is False, the given message type filter is removed (only if it is
        selected).

        Parameters
        ----------
        message_type: SentimentMessageType
            An Enum representation of the Message Type
        state: bool, Optional
            Value to select or deselect the filter

        Returns
        -------
        bool
            True if the given message type filter's selection state equals the given
            state parameter.
        """
        input_checkbox: WebElement = self.driver.find_element(
            By.NAME, message_type.value
        )
        message_filter: WebElement = self.driver.find_element(
            By.CSS_SELECTOR, sl.message_type_filter_css.format(type=message_type.value)
        )

        if input_checkbox.is_selected() is not state:
            message_filter.click()

        input_checkbox: WebElement = self.driver.find_element(
            By.NAME, message_type.value
        )
        return self.wait.until(
            ec.element_selection_state_to_be(input_checkbox, state),
            message=f"Cannot get selection state of {message_type.value} checkbox",
        )

    def is_sentiment_filter_selected(self, sentiment_group: SentimentGroup) -> bool:
        """
        Checks if sentiment filter is selected

        Parameters
        ----------
        sentiment_group: SentimentGroup
            A enum representation of the sentiment legend filter that needs to be checked

        Returns
        -------
        bool
            True if legend filter is applied
        """
        filter_btn_locator: str = sl.sentiment_filter_css.format(
            group=sentiment_group.value
        )
        data_status: str = self.get_element_attribute(
            "data-status", (By.CSS_SELECTOR, filter_btn_locator)
        )
        return data_status == "checked"

    def __sentiment_group_filter(
        self, sentiment_group: SentimentGroup, state: bool = True
    ) -> None:
        """
        A private method that filters the sentiments displayed on the heat wave plot
        based on the major sentiment group.

        If state is False, the given sentiment filter is removed (only if it's selected)

        Parameters
        ----------
        sentiment_group: SentimentGroup
            An Enum representation of the Sentiment
        state: bool, Optional
            Value to select or deselect the filter

        Returns
        -------
        bool
            True if the given sentiment filter's selection state equals the given state
            parameter.
        """
        if (
            self.get_count_from_sentiment_filter(sentiment_group) == "0"
            or self.is_sentiment_filter_selected(sentiment_group) is state
        ):
            return

        filter_btn_locator: str = sl.sentiment_filter_css.format(
            group=sentiment_group.value
        )
        self.click_on_element(
            (By.CSS_SELECTOR, filter_btn_locator),
            message=f"Failed to click {sentiment_group.value} sentiment filter button",
        )

    def filter_by_case_status(self, status: CaseStatusFilter) -> str:
        """
        Filters cases by the given status i.e, All, Open or Closed.

        Parameters
        ----------
        status: CaseStatusFilter
            An Enum representing the case status that needs to selected.

        Returns
        -------
        str
            Display text of selected case status filter
        """
        LOGGER.info(f"Filtering case status by {status.value}...")
        self.click_on_element(
            (By.CSS_SELECTOR, sl.case_status_filter_css.format(status=status.value)),
            message=f"{status.value} filter button is either not visible or enabled.",
        )

        return self.get_element_text_or_value(
            (By.CSS_SELECTOR, sl.selected_case_status_css),
            message="selected status is not visible.",
        )

    def get_total_sentiment_count(self) -> str:
        """
        Fetch the total sentiment count text displayed in the sentiments page.

        Returns
        -------
        str
            Total sentiment count
        """
        LOGGER.info("Retrieving the total sentiment count message...")
        return self.get_element_text_or_value(
            (By.CSS_SELECTOR, sl.total_sentiments_count_css),
            message="Sentiment count text is not displayed.",
        ).split()[0]

    def get_count_from_sentiment_filter(self, sentiment_group: SentimentGroup) -> str:
        """
        Fetch the count of the given sentiment type from the sentiment filter button.

        Parameters
        ----------
        sentiment_group: SentimentGroup
            An Enum representation of the Sentiment.

        Returns
        -------
        str
            Sentiment Count
        """
        group: str = sentiment_group.value
        LOGGER.info(f"Retrieving count from {group} sentiment filter button..")

        sentiment_count: str = self.get_element_text_or_value(
            (By.CSS_SELECTOR, sl.sentiment_filter_count_css.format(group=group)),
            message=f"Failed to get count from {group} filter",
        )
        LOGGER.info(f"{sentiment_count} sentiments of type {group} found")
        return sentiment_count

    def include_sentiment_by_message_type(
        self, message_type: SentimentMessageType
    ) -> bool:
        """
        Select a message type from the include filter i.e, Incoming, Outgoing and/or
        Case notes.

        Parameters
        ----------
        message_type
            An Enum representation of the Message Type

        Returns
        -------
        bool
            True if expected filter is selected
        """
        LOGGER.info(f"Selecting {message_type.value} from include filter...")
        return self.__include_filter(message_type)

    def exclude_sentiment_by_message_type(
        self, message_type: SentimentMessageType
    ) -> bool:
        """
        Deselect a message type from the include filter i.e, Incoming, Outgoing and/or
        Case notes.

        Parameters
        ----------
        message_type
            An Enum representation of the Message Type

        Returns
        -------
        bool
            True if expected filter is not selected
        """
        LOGGER.info(f"Deselecting {message_type.value} from include filter...")
        return self.__include_filter(message_type, False)

    def include_sentiment_by_group(self, sentiment_group: SentimentGroup) -> None:
        """
        Select a sentiment type from the sentiment filter i.e, Negative, Positive and/or
        Feedback.

        Parameters
        ----------
        sentiment_group
            An Enum representation of the Sentiment Group

        Returns
        -------
        bool
            True if expected filter is selected
        """
        LOGGER.info(f"Selecting {sentiment_group.value} from sentiment filter...")
        self.__sentiment_group_filter(sentiment_group)

    def exclude_sentiment_by_group(self, sentiment_group: SentimentGroup) -> None:
        """
        Deselect a sentiment type from the sentiment filter i.e, Negative, Positive
        and/or Feedback.

        Parameters
        ----------
        sentiment_group
            An Enum representation of the Sentiment Group

        Returns
        -------
        bool
            True if expected filter is not selected
        """
        LOGGER.info(f"Deselecting {sentiment_group.value} from sentiment filter...")
        self.__sentiment_group_filter(sentiment_group, False)

    def scroll_graph_to_previous_month(self) -> None:
        """This method clicks the left slider arrow on top of the sentiments chart"""
        self.click_on_element(
            (By.CSS_SELECTOR, sl.sentiment_graph_left_slider_css),
            message="Failed to click graph left slider button",
        )

    def scroll_graph_to_next_month(self) -> None:
        """This method clicks the right slider arrow on top of the sentiments chart"""
        self.click_on_element(
            (By.CSS_SELECTOR, sl.sentiment_graph_right_slider_css),
            message="Failed to click graph right slider button",
        )

    def get_random_sentiment_tile(self, randomize: bool = True) -> WebElement:
        """
        Finds and returns a random tile from the sentiment heat wave plot based on the
        value of randomize flag (default is True).

        If randomize is False, then a previously generated random value is used as the
        tile index.

        Parameters
        __________
        randomize: bool, Optional
            Flag to turn randomization on or off.

        Returns
        -------
        WebElement
            Random Sentiment Tile element.
        """
        LOGGER.info("Finding a random sentiment tile...")
        random_index: int = constants.random_sentiment_tile_index
        if randomize:
            total_count = int(self.get_total_sentiment_count())
            LOGGER.info(f"{total_count} sentiments found")
            random_index = constants.random_sentiment_tile_index = random.randint(
                1, total_count + 1
            )

        LOGGER.info(f"Random sentiment tile index: {random_index}")
        return self.get_element_when_visible(
            (By.CSS_SELECTOR, sl.sentiment_tile_css.format(index=random_index)),
            message="Sentiment tile is not visible",
        )

    def check_presence_of_sentiment_graph(self) -> bool:
        """
        Checks if the heat wave sentiment graph is loaded and displayed in the
        sentiments page.

        Returns
        -------
        bool
            True if heat wave plot is present and visible
        """
        LOGGER.info("Checking for presence of sentiment heatwave plot...")
        if self.is_element_visible(
            (By.CSS_SELECTOR, sl.sentiment_tile_css.format(index=1))
        ):
            LOGGER.info("Heatwave plot is present with sentiment tiles loaded.")
            return True
        elif self.is_element_visible((By.XPATH, sl.no_sentiments_found_banner)):
            LOGGER.warning("Heatwave plot is present with no sentiments available.")
            return True
        else:
            LOGGER.error("Heatwave graph is not visible")
            return False

    def hover_over_sentiment_tile(self, sentiment_tile: WebElement) -> None:
        """
        Performs mouse over operation on the given sentiment tile element.

        Parameters
        ----------
        sentiment_tile: WebElement
            Heat wave plot sentiment tile
        """
        LOGGER.info(f"Hovering over a random sentiment tile...")
        self.actions.move_to_element(sentiment_tile).perform()

    def click_on_sentiment_tile(self, sentiment_tile: WebElement) -> None:
        """
        Performs mouse click operation on the given sentiment tile element.

        Parameters
        ----------
        sentiment_tile: WebElement
            Heat wave plot sentiment tile
        """
        LOGGER.info(f"Clicking on a random sentiment tile...")
        self.actions.move_to_element(sentiment_tile).click().perform()

    def check_visibility_of_sentiment_details_tooltip(self) -> bool:
        """
        Checks for visibility of sentiment details tooltip that is shown on hover.
        Visibility means that the element is not only displayed but also has a height
        and width that is greater than 0.

        Returns
        -------
        bool
            True if details tooltip is visible
        """
        LOGGER.info("Checking sentiment details tooltip visibility...")
        if not self.is_element_visible((By.CSS_SELECTOR, sl.sentiment_tooltip_css)):
            LOGGER.error("Tooltip is not displayed within 30 seconds")
            return False

        case_id = self.get_element_text_or_value(
            (By.CSS_SELECTOR, sl.sentiment_tooltip_case_id_css),
            message="Case ID is not displayed within 30 seconds.",
        )
        LOGGER.info(f"Showing sentiment details of {case_id} in heatwave graph.")
        return True

    def get_start_date_value(self) -> str:
        LOGGER.info("Getting start date value..")
        return self.get_element_text_or_value(
            (By.CSS_SELECTOR, sl.start_date_css),
            message="Failed to get start date text",
        )

    def get_end_date_value(self) -> str:
        LOGGER.info("Getting end date value..")
        return self.get_element_text_or_value(
            (By.CSS_SELECTOR, sl.end_date_css), message="Failed to get end date text"
        )

    def open_date_picker(self) -> None:
        """Opens the date picker by clicking on the start date value"""
        LOGGER.info("Opening start date picker...")
        self.click_on_element(
            (By.CSS_SELECTOR, sl.start_date_css),
            message="Start date element is either not visible or enabled.",
        )

    def apply_date_filter(self) -> None:
        """Clicks the apply button in the date picker popover"""
        LOGGER.info("Clicking Apply button in date filter..")
        self.click_on_element(
            (By.CSS_SELECTOR, sl.apply_start_date_btn_css),
            message="Apply button click failed",
        )

    def select_start_date(self, start_date: dt.date) -> None:
        """
        Selects the start date from the date picker. For this method to work the date
        picker widget needs to open and visible.

        Parameters
        ----------
        start_date: dt.date
            Start date value to be selected as a dt.date object
        """
        start_date_string: str = start_date.strftime("%b %-d, %Y")
        LOGGER.info(f"Selecting {start_date_string} as start date...")
        if (start_date - dt.date.today()).days > 0:
            raise ValueError(f"Cannot select future dates {start_date_string}.")

        expected_month_year: str = start_date.strftime("%B %Y")
        while True:
            if expected_month_year == self.get_element_text_or_value(
                (By.CSS_SELECTOR, sl.current_visible_month_css),
                message="Current selected month is not visible in start date picker",
            ):
                break
            # move backward button
            self.driver.find_element(
                By.CSS_SELECTOR, sl.go_to_previous_month_css
            ).click()

        # day element
        self.driver.find_element(
            By.CSS_SELECTOR, sl.select_day_css.format(date=start_date.day)
        ).click()

    def reset_start_date(self) -> None:
        """
        Resets the currently selected date filter by clicking the reset button. For this
        method to work the date picker widget needs to open and visible.
        """
        LOGGER.info("Resetting start date filter...")
        self.click_on_element(
            (By.CSS_SELECTOR, sl.reset_date_filter_css),
            message="Reset start date button is either not visible or enabled.",
        )
