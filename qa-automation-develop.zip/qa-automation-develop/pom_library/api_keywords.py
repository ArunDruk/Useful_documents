import json
from typing import Union

import api_data
import api_endpoints
from enums import ModuleState, NavbarItem
from pom_library.pom_base import PomBase


class ApiKeywords(PomBase):
    def get_product_edition(self):
        settings = self.get_data_from_sl_api(api_endpoints.company_settings)
        return settings["activeCompanySettings"]["product_edition"]

    def set_product_edition_standard(self):
        self.post_data_to_sl_api(
            api_endpoints.company_settings, api_data.product_edition_standard
        )

    def set_product_edition_pro(self):
        self.post_data_to_sl_api(
            api_endpoints.company_settings, api_data.product_edition_pro
        )

    def set_product_edition_enterprise(self):
        self.post_data_to_sl_api(
            api_endpoints.company_settings, api_data.product_edition_enterprise
        )

    def set_product_edition_custom(self):
        self.post_data_to_sl_api(
            api_endpoints.company_settings, api_data.product_edition_custom
        )

    def edit_module_state(self, module: dict[NavbarItem, ModuleState]):
        self.post_data_to_sl_api(
            api_endpoints.company_settings,
            api_data.edit_custom_prod_edition_module_state(module)
        )

    def get_client_names(self, size: int = 1, with_least_cases: bool = False):
        response = self.post_data_to_sl_api(
            api_endpoints.customer_search.format(size=size),
            api_data.customer_search(with_least_cases),
        )
        return [entry["name"] for entry in response]

    def get_agent_details(self, size: int = 1, with_least_cases: bool = False):
        case_count_by_agent_id: dict = self.post_data_to_sl_api(
            api_endpoints.case_count_by_agent, api_data.case_count_by_agent_id
        )
        # sort case count in ascending/descending order based on with_least_cases param
        case_count_by_agent_id = dict(
            sorted(
                case_count_by_agent_id.items(),
                key=lambda item: item[1],
                reverse=not with_least_cases,
            )
        )
        # get only the agent id's
        agent_ids = list(case_count_by_agent_id.keys())
        response = self.post_data_to_sl_api(
            api_endpoints.agent_search, api_data.agent_search(agent_ids[:size])
        )
        # add the ticket count to respective agents
        [
            entry.update({"num_tickets": case_count_by_agent_id[entry["id"]]})
            for entry in response
        ]
        return response

    def get_agent_names(self, size: int = 1, with_least_cases: bool = False):
        details = self.get_agent_details(size, with_least_cases)
        return [detail["sl_name"] for detail in details]

    def get_escalation_prediction_scores(self):
        return self.get_data_from_sl_api(api_endpoints.escalation_prediction)

    def get_active_escalations_case_fields(self) -> list[str]:
        company_settings = self.get_data_from_sl_api(api_endpoints.company_settings)
        case_fields: dict = company_settings["activeCompanySettings"]["case_field_repo"]

        active_fields = []
        for field in case_fields.values():
            if field.get("escalations_page"):
                active_fields.append(field["title"])

        return active_fields

    def get_case_summary(self, case_ids: Union[str, list[str]]):
        size = 1 if isinstance(case_ids, str) else len(case_ids)
        endpoint = api_endpoints.case_summary.format(size=size)
        return self.post_data_to_sl_api(endpoint, api_data.case_summary(case_ids))

    def has_manage_shift_permission(self) -> bool:
        profile_data = self.get_data_from_sl_api(api_endpoints.user_profile)
        permissions: list[str] = profile_data["permissions"]
        return "can_manage_shifts" in permissions

    def get_active_dashboard_pages(self) -> list[str]:
        company_settings = self.get_data_from_sl_api(api_endpoints.company_settings)
        pages: dict = (
            company_settings["activeCompanySettings"]["dashboard_restrictions"]["pages"]
        )
        return [key for key, value in pages.items() if value]

    def query_vgroup(self) -> list[dict]:
        endpoint = "/api/v2/group/search?page_number=0&page_size=100"
        request_body = {
            "selected": ["id", "name", "gtype", "created_by"],
            "ordering": [{"column": "created_at", "direction": "desc"}],
            "predicates": [],
        }
        return self.post_data_to_sl_api(endpoint, json.dumps(request_body))

    def delete_vgroup(self, vgroup_id: str) -> None:
        endpoint = f"/api/v2/group/{vgroup_id}"
        return self.delete_data_with_sl_api(endpoint)
