"""This module is  focuses on  creating reusable method the topics page   """
__author__ = "Neha jha "
__copyright__ = "Copyright (C) 2021 SupportLogic"

import logging


from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from pom_library.pom_base import PomBase
from locators import topics_locators
from pom_library.helper_methods import HelperMethods
LOGGER = logging.getLogger(__name__)


class TopicsPage(HelperMethods):
    """
    This class has all the actions that can be done in Topic page page
    """

    # declaring the driver to use it in overall page
    def __init__(self, driver):
        self.driver = driver
        PomBase.__init__(self, self.driver)
        self.actions = ActionChains(driver)
        self.wait = WebDriverWait(driver, 60)

    def click_topics(self):
        """ This method helps to click on Topics in nav bar"""
        support_engineer_locator = self.wait.until(
            EC.element_to_be_clickable((By.XPATH, topics_locators.topics_nav_bar))
        )
        self.actions.move_to_element(support_engineer_locator).click().perform()

    def click_on_topic_section(self):
        """ This method helps to click on topic to select the topic from the list of option """
        self.mouse_click_on_element(
            (By.XPATH, topics_locators.topics_selection_first),
            timeout=5,
            message="failed to click on first topic section ",
        )


    def check_visibility_first_section_drop_down(self):
        """This method helps to check for visibility of first  section drop down"""

        first_section_drop_down= self.is_element_visible(
            (By.XPATH,  topics_locators.topics_selection_first_list)
        )
        return first_section_drop_down

    def click_on_second_topic_section(self):
        """ This method helps to click on second topic selection to select the topic from the list of option """

        self.wait.until(
            EC.element_to_be_clickable(
                (By.XPATH, topics_locators.topics_selection_second)
            )
        ).click()

    def check_visibility_second_section_drop_down(self):
        """This method helps to validate drop down which displayed on clicking second topic section"""
        topics_first_section_locator = self.driver.find_element(
            By.XPATH, 
            topics_locators.topics_selection_second_list
        ).is_displayed()

        if topics_first_section_locator:
            LOGGER.info("Second topic drop down is displayed")
            return True
        else:
            LOGGER.info("second topic drop down is not displayed")
            return False




    def click_tabs(self, tab):
        """ This method helps to click on tabs which is presents on the second section"""
        tab_locator = topics_locators.conversation.replace("TEXT_PLACEHOLDER", tab)
        conversation = self.wait.until(
            EC.element_to_be_clickable((By.XPATH, tab_locator))
        )
        self.actions.move_to_element(conversation).click().perform()

    def get_name_graph(self):
        """ This method helps to get the name of graph """
        graph_name = self.wait.until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, topics_locators.graph_name))
        ).text
        if graph_name == "First Response Time (days)":
            name_of_graph="First Response Time"
            LOGGER.info(f" graph name is {name_of_graph} ")
            return name_of_graph
        LOGGER.info(f" graph name is {graph_name} ")
        return graph_name

    def check_visibility_graph(self):
        """ THIS method helps checks for the visibility of graph"""
        graph_locator = self.driver.find_element(
            By.CSS, 
            topics_locators.graph_name
        ).is_displayed()
        if graph_locator:
            LOGGER.info("Graph is displayed")
            return True
        else:
            LOGGER.info("Graph is not displayed")
            return False

    def click_export_csv(self):
        """ This method helps to click on the export csv """
        Export_csv = self.wait.until(
            EC.element_to_be_clickable((By.XPATH, topics_locators.export_csv))
        )
        self.actions.move_to_element(Export_csv).click().perform()

    def click_apply(self):
        """ This method helps to click on apply button in locator """
        Apply_locator = self.wait.until(
            EC.element_to_be_clickable((By.XPATH, topics_locators.apply_calendar))
        )

        self.actions.move_to_element(Apply_locator).click().perform()

    def select_first_topic_section(self):
        """ This method helps to selected the topic from the first section """
        select_topic = self.wait.until(
            EC.element_to_be_clickable((By.XPATH, topics_locators.topic_selection))
        )
        self.driver.execute_script("arguments[0].click();", select_topic)

    def select_second_topic_section(self):
        """ This method helps to selected the topic from the second section """
        select_topic = self.wait.until(
            EC.element_to_be_clickable((By.XPATH, topics_locators.second_input_list))
        )
        self.driver.execute_script("arguments[0].click();", select_topic)

    def get_group_by_filter_name_from_first_topic_list(self):
        """ This method helps to get text from the first topic drop down """
        topics_first_section_locator = self.wait.until(
            EC.element_to_be_clickable((By.XPATH, topics_locators.topic_selection))
        ).text
        LOGGER.info(
            f"{topics_first_section_locator} is selected in first section from drop down  "
        )
        return topics_first_section_locator

    def get_text_second_topic_selected(self):
        """ This method helps to get text from the second topic drop down  """
        topics_second_section_locator = self.wait.until(
            EC.element_to_be_clickable((By.XPATH, topics_locators.second_input_list))
        ).text
        LOGGER.info(
            f"{topics_second_section_locator} is selected in first section from drop down  "
        )
        return topics_second_section_locator

    def get_group_by_option_selected_in_primary_topic(self):
        """ This method helps to get the selected topic name   """

        filter_applied = self.get_element_text_or_value(
            (By.XPATH, topics_locators.first_topic_search_in_group_by),get_value =True
        )
        LOGGER.info(f"{filter_applied} is selected in first section of topic  ")
        return filter_applied


    def selected_second_topic(self):
        """ This method helps to validate that selected topic is displayed   """
        selected_second_topic = self.driver.find_element(
            By.XPATH, 
            topics_locators.topics_selection_second
        ).is_displayed()
        if selected_second_topic:
            return True
        else:
            return False

    def validate_case_list_graph(self):
        """This method helps to validate case list is displayed or not"""
        case_list_locator = self.driver.find_element(
            By.XPATH, 
            topics_locators.case_list_graph
        ).is_displayed()
        if case_list_locator:
            LOGGER.info("case list graph is displayed")
            return True
        else:
            LOGGER.info("case list graph is not displayed")
            return False

    def validate_keyword_graph(self):
        """This method helps to validate keyword graph is displayed or not"""
        keyword_locator = self.driver.find_element(
            By.XPATH, 
            topics_locators.keyword_graph
        ).is_displayed()

        if keyword_locator:
            LOGGER.info("Keyword graph is displayed")
            return True
        else:
            LOGGER.info("Keyword graph is  not displayed")
            return False





    def validate_topics_page(self):
        """ This method helps to validate the topic page is displayed or not"""
        topic_page_locator = self.driver.find_element(
            By.XPATH, 
            topics_locators.topic_page
        ).is_displayed()
        if topic_page_locator:
            LOGGER.info("Topic page is displayed")
            return True
        else:
            LOGGER.info("Topic page  is not displayed")
            return False

    def get_text_case(self):
        """This method to get the number of cases"""
        cases = self.wait.until(
            EC.presence_of_element_located((By.XPATH, topics_locators.case_value))
        ).text
        LOGGER.info(f"{cases} Cases is present  ")
        return cases

    def get_text_client_count(self):
        """This method to get the number of client """
        cases = self.wait.until(
            EC.visibility_of_element_located((By.XPATH, topics_locators.client_count))
        ).text
        LOGGER.info(f"{cases} Client is present  ")
        return cases

    def validate_case_and_client_count_in_second_topic_section(self):
        """This method helps to validate case greater than 0 or not """
        cases = self.get_text_case()
        client_count = self.get_text_client_count()
        if cases == "0" and client_count == "0":
            LOGGER.info("zero cases is present")
            return False
        else:
            LOGGER.info("More than Zero cases is present  ")
            return True

    def get_case_count_after_selecting_first_topic(self):
        """This method to get the number of cases"""
        cases = self.wait.until(
            EC.visibility_of_element_located(
                (By.XPATH, topics_locators.case_count_after_selecting_first_topic)
            )
        ).text
        count = cases.split("cases")

        case_count = count[0]
        LOGGER.info(f"{case_count} Cases is present  ")
        return case_count

    def get_count_agent_after_selecting_first_topic(self):
        """This method to get the number of agents"""
        cases = self.wait.until(
            EC.visibility_of_element_located(
                (By.XPATH, topics_locators.agents_count_after_selecting_first_topic)
            )
        ).text

        LOGGER.info(f"{cases} agents is present  ")
        return cases

    def get_count_client_after_selecting_first_topic(self):
        cases = self.wait.until(
            EC.visibility_of_element_located(
                (By.XPATH, topics_locators.client_count_after_selecting_first_topic)
            )
        ).text

        LOGGER.info(f"{cases} client is present  ")
        return cases

    def check_for_data_present_in_topic_page(self):
        client = self.get_count_client_after_selecting_first_topic()
        agents = self.get_count_agent_after_selecting_first_topic()
        case = self.get_case_count_after_selecting_first_topic()

        if client == "0" and agents == "0" and case == "0 ":
            LOGGER.info("topics page have no  data")
            return False
        else:
            LOGGER.info("topic page have data")
            return True


    def click_case_list_graph(self):
        """ This method helps to click on  case list tabs which is presents on the second section"""

        conversation = self.wait.until(
            EC.element_to_be_clickable((By.XPATH,topics_locators.case_list_button ))
        )
        self.actions.move_to_element(conversation).click().perform()

    def click_on_sort_by_filter_button(self):
       """This method helps to click on the sort filter """
       LOGGER.info("click on sort by filter button")
       self.mouse_click_on_element(
            (By.XPATH, topics_locators.sort_by_filter),
            timeout=20,
            message="failed to click on sort by filter  ",
        )

    def get_text_of_sort_by_filter_applied(self):
        """This method helps to get the text of sort by filter on """
        filter_applied = self.get_element_text_or_value(
            (By.XPATH, topics_locators.sort_by_filter)
        )
        return filter_applied

    def select_filter_based_on_sort_by_option(self,filter_name):
        """This method helps to select the sort by filter option  """
        LOGGER.info("selecting filter based on sort by option")
        self.click_on_element(
            (By.XPATH, topics_locators.sort_by_filter_option.replace("TEXT_PLACEHOLDER", filter_name.value)),
            message=f"select the select {filter_name}"
        )

    def get_number_cases_display_on_cards(self):
        """This method get number of cases on the card and  check whether its on descending order or not"""
        number_of_case = []
        case_on_cards= self.driver.find_elements(By.XPATH, topics_locators.number_of_cases_display_in_cards)
        for cases in case_on_cards:
            case_count=cases.text
            get_case_count_after_removing_character  = "".join([i for i in case_count if  i.isdigit()])
            data =int(get_case_count_after_removing_character)
            number_of_case.append(data)
        sort_list = sorted(number_of_case,reverse=True)
        if sort_list == number_of_case:
            return True
        else:
            return False

    def get_sort_by_filter_text_option(self):
        """This method get the option present on the sort by filter menu"""

        filter_option = []
        sort_by_filter = self.driver.find_elements(By.XPATH, topics_locators.sort_by_list_option)
        for option in sort_by_filter:
            sort_by_filter = option.text
            filter_option.append(sort_by_filter)
        return filter_option


    def check_for_second_topic_group_by_option_is_greyed_out(self,option):
        """This method helps to check for second topic option is greyed out or not """
        LOGGER.info("checking for selected topic is grey out in second topic")
        return self.is_element_visible(
            (By.XPATH,  topics_locators.second_topic_group_by_option_greyed_out.replace("option",option))
        )

    def search_for_filter_name_in_first_topic_section(self,filter_name):
        """This method helps to search the group by filter name in first topic section """
        LOGGER.info("searching data in first topic section")
        self.pass_value_to_element(
            filter_name,
            (By.XPATH, topics_locators.first_topic_search_in_group_by),
            message="failed to search filter name",
        )

    def get_text_of_primary_group_by_down_drop_menu_option_available(self):
        """This method helps to get the option in primary topic section"""
        filter_option = []
        first_group_by_filter = self.driver.find_elements(By.XPATH, topics_locators.first_topic_group_by_list_option )
        for option in first_group_by_filter:
            filter_name = option.text
            filter_option.append(filter_name)

        return filter_option


    def get_text_of_secondary_group_by_down_drop_menu_option_avaiable(self):
        """This method helps to get the option in secondary  topic section"""
        filter_option = []
        second_group_by_filter = self.driver.find_elements(By.XPATH, topics_locators.second_topic_group_by_option)
        for option in second_group_by_filter:
            filter_name = option.text
            filter_option.append(filter_name)

        return filter_option


    def search_for_filter_name_in_second_topic_section(self,filter_name):
        """This method helps to search the group by filter name in first topic section """
        LOGGER.info("searching data in second topic section")
        self.pass_value_to_element(
            filter_name,
            (By.XPATH, topics_locators.second_topic_search_in_group_by),
            message="failed to search filter name",
        )

    def check_visibility_of_sort_by_filter_drop_down_menu(self):
        """ This method helps to checks for sort by filter menu"""
        return self.is_element_visible(
            (
                By.XPATH,
                topics_locators.sort_by_filter_drop_down_menu
            ))

