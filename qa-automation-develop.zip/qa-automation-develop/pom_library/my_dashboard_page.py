"""This module is  focuses on  creating reusable method the my dashboard """
__author__ = "Neha Jha"
__copyright__ = "Copyright (C) 2021 SupportLogic"
import logging
import time
import utils
import constants
from selenium.webdriver.common.action_chains import ActionChains

from enums import AgentManagementTabs
from locators import my_dashboard_locator as mdl
from pom_library.commons import Commons
from pom_library.helper_methods import HelperMethods
from pom_library import  agent_management_page
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

LOGGER = logging.getLogger(__name__)


class MyDashboard(HelperMethods):
    def __init__(self, driver):
        super().__init__(driver)
        self.actions = ActionChains(driver)
        self.wait = WebDriverWait(driver, 60)

    def click_on_plus_button(self):
        """This method helps to click on the + icon present on the dashboard"""

        self.javascript_click_on_element(
            (By.XPATH, mdl.plus_button),
            timeout=5,
            message="failed to click on the plus button"

        )

    def click_on_case_list_option(self):
        """This method helps to click on the case list option present """

        self.click_on_element(
            (By.XPATH, mdl.case_list),
            timeout=5,
            message="failed to click on the case list",
        )

    def click_on_next_button(self):
        """This method helps to click on the next button """
        self.click_on_element(
            (By.XPATH, mdl.next_button),
            timeout=5,
            message="failed to click on the next button",
        )

    def click_on_negative_sentiments_in_card_list(self):
        """This method helps to click on the first option present in card list"""
        self.click_on_element(
            (By.XPATH, mdl.negative_sentiments_in_add_case_list),
            timeout=5,
            message="failed to click on first option in the  add case list",
        )

    def click_on_add_button(self):
        """This method helps to click on add button while create a new list"""

        self.click_on_element(
            (By.XPATH, mdl.add_button),
            timeout=5,
            message="failed to click on the add button",
        )

    def get_number_of_list_present_on_dashboard(self):
        """This method helps to get the text of number of list present on the dash board"""
        list_present_on_dashboard = self.driver.find_elements(
            By.XPATH, mdl.no_of_case_list_present_on_dashboard
        )
        no_of_list = len(list_present_on_dashboard)
        LOGGER.info(f"list present on the dash board {no_of_list}")
        return no_of_list

    def click_on_case_tile(self):
        """This method helps to click on case tile"""
        self.click_on_element(
            (By.XPATH, mdl.case_tile),
            timeout=5,
            message="failed to click on the case list",
        )

    def click_on_first_option_in_add_case_tile(self):
        """This method helps to click on the first option in  case title"""
        self.click_on_element(
            (By.XPATH, mdl.first_option_in_case_tile),
            timeout=5,
            message="failed to click on the first option in the case tile",
        )

    def get_number_of_tile_present_on_dashboard(self):
        """This method helps to get the text of number of list present on the dash board"""
        list_present_on_dashboard = self.driver.find_elements(
            By.XPATH, mdl.no_of_case_tile_present_on_dashboard
        )
        no_of_list = len(list_present_on_dashboard)
        LOGGER.info(f"list present on the dash board {no_of_list}")
        return no_of_list

    def click_on_vertical_dots_of_case_list(self, name):
        """This method helps to click on the verticals dots of  case list"""


        case_name = self.driver.find_element(By.XPATH, mdl.vertical_dots_of_case_list.replace('TEXT_PLACEHOLDER', name))
        self.driver.execute_script('arguments[0].scrollIntoView(true);', case_name)
        time.sleep(2)
        self.click_on_element(
            (By.XPATH,  mdl.vertical_dots_of_case_list.replace('TEXT_PLACEHOLDER', name)),
            timeout=5,
            message="failed to click on the delete button on verticals dots",
            )

    def click_on_delete_button_case_list(self):
        """This method helps to click on the delete button on the vertical button """
        self.click_on_element(
            (By.XPATH, mdl.delete_case_list),
            timeout=5,
            message="failed to click on the delete button on verticals dots",
        )

    def check_the_present_of_case_list_in_dash_board(self):
        """ This method helps to check the present case list"""
        try:
            client_present_list = self.wait.until(
                EC.element_to_be_clickable(
                    (By.XPATH, mdl.case_list_in_dashboard)
                )
            ).is_displayed()
            if client_present_list:
                LOGGER.info(" Case list presence in dash board")
                return True

        except:
            LOGGER.info(" Case list presence in the dash board ")
            return False

    def click_on_edit_case_list(self):
        """This method helps to click on the edit case list in the vertical drop down """
        self.mouse_click_on_element(
            (By.XPATH, mdl.edit_case_list),
            timeout=5,
            message="failed to click on edit case list",
        )
    def click_on_about_miss_sla_in_card_list(self):
        """This method helps to click on the about to miss SLA"""
        self.click_on_element(
            (By.XPATH, mdl.about_to_miss_sla_in_add_case_list),
            timeout=5,
            message="failed to click on ABOUT TO MISS SLA",
        )

    def welcome_page_title(self):
        """This method helps to click on the welcome page title """
        welcome_page_title = self.get_element_text_or_value(
            (By.XPATH, mdl.welcome_page_title)
        )
        return welcome_page_title

    def click_on_first_virtual_team_in_welcome_page(self,):
        """This method helps to click on the first virtual team on the welcome page"""

        self.click_on_element(
                (By.XPATH, mdl.first_virtual_team_present_on_welcome_page),
                timeout=5,
                message="failed to on virtual team in welcome page",
            )
    def get_first_virtual_team_name(self):
        first_virtual_team=self.get_element_text_or_value(
                (By.XPATH, mdl.first_virtual_team_present_on_welcome_page),
                timeout=5,
                message="failed to on virtual team in welcome page",
            )
        return first_virtual_team

    def check_for_the_virtual_team(self):
        """This method helps to check for the virtual team container is displayed  in my dashboard page with
        selected virtual team name and cases"""
        virtual_team = self.wait.until(
                EC.visibility_of_element_located(
                    (By.XPATH, mdl.vt_team_selected)
                )
            ).is_displayed()
        if virtual_team:
            LOGGER.info(" virtual team is displayed")
            return True
        else:
            return False

    def get_text_first_case_id_in_case_list(self):
        """This method helps to get the first case id in the case list """
        case_id = self.get_element_text_or_value(
                    (By.XPATH, mdl.first_case_id_in_case_list)
                )
        return case_id


    def click_on_first_case_in_case_list(self):
        """this method helps to click on the first case which is present on the case list"""
        self.click_on_element(
            (By.XPATH, mdl.first_case),
            timeout=5,
            message="failed to first case in case list ",
        )

    def click_on_first_case_in_case_tile(self):
        """THIS method helps to click on the fist case in the case tile"""

        self.click_on_element(
            (By.XPATH, mdl.case_tile_first_case),
            timeout=5,
            message="failed to first case in the case tile",
        )
    def get_text_of_case_id_in_case_tile(self):
        """This method helps to get the case id from the case tile """
        time.sleep(1)
        case_id = self.get_element_text_or_value(
            (By.XPATH, mdl.first_case_id_on_case_tile),timeout=30,
        )
        return case_id

    def click_on_first_tickets_in_case_tile(self):
        """THIS method helps to click on first ticket on the case tile"""
        self.click_on_element(
            (By.XPATH, mdl.ticket_in_case_tile),
            timeout=5,
            message="failed to first ticket in the case tile",
        )
    def click_on_vertical_dots_of_virtual_team(self):
        """This method helps to click on the verticals dots in the virtual teams"""
        self.click_on_element(
            (By.XPATH, mdl.virtual_team_vertical_dots),
            timeout=5,
            message="failed to verticals dots",
        )
    def click_on_edit_team_of_virtual_team(self):
        """This method helps to click on edit teams in virtual teams"""
        self.click_on_element(
            (By.XPATH, mdl.edit_team),
            timeout=5,
            message="failed to edit team button",
        )
    def get_number_virtual_team_present_on_dashboard(self):
        """This method helps get number virtual team present  on the dashboard """

        list_of_virtual_team_present_on_dashboard = self.driver.find_elements(
            By.XPATH, mdl.list_of_virtual_team
        )
        no_of_list = len(list_of_virtual_team_present_on_dashboard)
        LOGGER.info(f"list present on the dash board {no_of_list}")
        return no_of_list


    def click_on_save_button(self):
        """THIS method helps to click on the save button present on """
        self.click_on_element(
            (By.XPATH, mdl.save_button),
            timeout=5,
            message="failed to save button",
        )

    def get_text_of_virtual_team(self):
        """This method helps to get the text of the virtual teams  which is selected or lighted"""
        virtual_team_name = self.get_element_text_or_value(
            (By.XPATH, mdl.virtual_team_name_which_is_highlighted)
        )
        return virtual_team_name

    def get_virtual_team_name_in_my_dashboard(self):
        """This method helps to get the name of the virtual team name in the dashboard """
        virtual_team_name_in_dashboard = self.get_element_text_or_value(
            (By.XPATH, mdl.virtual_team_name_in_my_dashboard)
        )
        return virtual_team_name_in_dashboard

    def edit_name_in_edit_list(self, edit_name):
        """This method helps to  add text in the notes text box to edit notes
        -----------
        Parameters
        names =  text to be added in notes
        """

        text = self.wait.until(
            EC.element_to_be_clickable((By.XPATH,mdl.name_in_edit_list))
        )

        text.send_keys(edit_name)

    def get_edit_name_from_edit_list(self):
        """This method helps to get name of the edit list of the page"""
        edit_name_in_list = self.get_element_text_or_value(
            (By.XPATH, mdl.name_in_edit_list),get_value=True
        )
        return edit_name_in_list

    def get_case_list_name_after_edit(self,name):
        """This method helps to get case list name after edit """
        case_list_name = self.get_element_text_or_value(
            (By.XPATH, mdl.first_list_name.replace("TEXT_PLACEHOLDER",name))
        )
        return case_list_name

    def check_for_the_welcome_page_is_displayed(self):
        """This method helps to check for the welcome page is displayed or not"""
        try:
            client_present_list = self.wait.until(
                EC.visibility_of_element_located(
                    (By.XPATH, mdl.welcome_page_title)
                )
            ).is_displayed()
            if client_present_list:
                LOGGER.info(" welcome page is displayed")
                return True

        except:
            LOGGER.info(" welcome page on my dashboard is not displayed ")
            return False

    def click_on_cross_button_on_add_a_card_pop_up(self):
        """ This  method helps to click on the cross button add new card pop up  """

        try:
             self.wait.until(
                EC.element_to_be_clickable(
                    (By.XPATH, mdl.cross_button_on_add_card_pop_up)
                )
            ).click()
        except:
            pass

    def get_number_of_lists_and_tiles_present_on_dashboard(self):
        """This method helps to get the number of case list and tile present on the dash board"""
        list_present_on_dashboard = self.driver.find_elements(
            By.XPATH, mdl.number_of_case_list)
        return list_present_on_dashboard

    def enter_card_name(self, CaseListName):
        """This method helps to enter t"""
        card_name = self.driver.find_element(By.XPATH, mdl.case_list_name_input)
        card_name.clear()
        card_name.send_keys(CaseListName)

    def create_case_list(self):
        """This method helps to create the case list"""
        case_list_present_case_list = self.get_number_of_list_present_on_dashboard()
        self.click_on_plus_button()
        self.click_on_case_list_option()
        self.click_on_next_button()
        db_name = utils.generate_test_run_id(constants.DASH_BOARD_RUN_ID_PREFIX)
        self.enter_card_name(db_name)
        self.click_on_negative_sentiments_in_card_list()
        self.click_on_add_button()
        excepted_list_present = case_list_present_case_list + 1
        time.sleep(2)
        actual_list_created_after_creating = self.get_number_of_list_present_on_dashboard()
        assert excepted_list_present == actual_list_created_after_creating, "failed to create the case list"
        return db_name

    def delete_list_and_tile_on_dash_board(self):
        """This helps to delete the Case list and tiles which start with QA"""
        number_of_case_list_before_deletion = self.get_number_of_lists_and_tiles_present_on_dashboard()
        for i in number_of_case_list_before_deletion:

            case_list_name = i.text
            case_list = case_list_name.split('\n')
            if "QA_DB" in case_list_name:
                self.click_on_vertical_dots_of_case_list(case_list[0])
                time.sleep(2)
                self.click_on_delete_button_case_list()
                LOGGER.info("Case list and tile deleted ")
                time.sleep(2)

    def create_case_tile(self):
        """This helps helps to create the case tile"""
        case_list_present_before_creating_new_case_list = self.get_number_of_tile_present_on_dashboard()
        self.click_on_plus_button()
        self.click_on_case_tile()
        self.click_on_next_button()
        db_name = utils.generate_test_run_id(constants.DASH_BOARD_RUN_ID_PREFIX)
        self.enter_card_name(db_name)
        self.click_on_first_option_in_add_case_tile()
        self.click_on_add_button()
        excepted_list_present = case_list_present_before_creating_new_case_list + 1
        time.sleep(2)
        actual_list_created_after_creating = self.get_number_of_tile_present_on_dashboard()
        assert excepted_list_present == actual_list_created_after_creating, "failed to create the case tile"

    def click_on_second_virtual_team_in_welcome_page(self, ):
        """This method helps to click on the first virtual team on the welcome page"""

        self.click_on_element(
            (By.XPATH, mdl.second_virtual_team_present_on_welcome_page),
            timeout=5,
            message="failed to on virtual team in welcome page",
        )
    def get_second_virtual_team_name_in_welcome_page(self, ):
        """This method helps to click on the first virtual team on the welcome page"""

        second_virtual_team=self.get_element_text_or_value(
            (By.XPATH, mdl.second_virtual_team_present_on_welcome_page),
            timeout=5,
            message="failed to get  second virtual_team_name",
        )
        return second_virtual_team

    def get_case_count_first_tickets_in_case_tile(self):
        """ this method helps to get case count """
        case_count=self.get_element_text_or_value(
            (By.XPATH, mdl.ticket_in_case_tile),
            timeout=5,
            message="failed to get case count ",
        )
        return case_count

    def check_the_present_of_case_in_case_list(self):
        """This helps helps to check the present of case in the case list"""
        try:
            check_present_case = self.wait.until(
                EC.visibility_of_element_located(
                    (By.XPATH, mdl.first_case_id_in_case_list)
                )
            ).is_displayed()
            if check_present_case:
                return  True
        except:
            return False

    def get_number_of_virtual_present_on_dashboard(self):
        """This method get number of virtual  team present on dashboard"""
        LOGGER.info("get number of virtual team present on dash board")
        list_present_on_dashboard = self.driver.find_elements(
            By.XPATH, mdl.agents_name_in_dashboard)
        return list_present_on_dashboard

    def get_number_of_virtual_link_present_on_dashboard(self):
        """This method get number of virtual  team present on dashboard"""
        LOGGER.info("get number of virtual link  present on dashboard")
        list_present_on_dashboard = self.driver.find_elements(
            By.XPATH, mdl.click_on_agent_link_near_agent_name)
        return list_present_on_dashboard

    def get_number_of_agents_name_present_in_dashboard(self):
        """This method get name of virtual _team present on dash board"""
        LOGGER.info("get number of agents name present in agents dashboard")
        agent_name_in_dashboard = []
        get_number_agents_name_present_in_dashboard = self.get_number_of_virtual_present_on_dashboard()
        for i in get_number_agents_name_present_in_dashboard:
            case_list_name = i.text
            agent_name_in_dashboard .append(case_list_name)
        return agent_name_in_dashboard

    def click_on_first_agents_link_on_dash_board(self):
        """This method helps to click on first agents link the dashboard"""
        LOGGER.info("hover over first agents in the dashboard")
        hover_over_first_agent_name=self.wait.until(EC.presence_of_element_located(
            (By.XPATH, mdl.agents_name_in_dashboard)))
        LOGGER.info("click on first agents link")
        self.actions.move_to_element(hover_over_first_agent_name).perform()
        self.mouse_click_on_element(
            (By.XPATH, mdl.click_on_agent_link_near_agent_name),
            message="failed to click on the agents link",
        )

    def get_case_count_of_first_agents_in_dashboard(self):
        """ this method helps to get case count of first agents in dashboard """
        LOGGER.info("hover over first virtual team first virtual account")
        hover_over_first_agent_name = self.wait.until(EC.presence_of_element_located(
            (By.XPATH, mdl.agents_name_in_dashboard)))

        LOGGER.info("get first agent case count in dashboard")
        self.actions.move_to_element(hover_over_first_agent_name).perform()
        case_count = self.get_element_text_or_value(
            (By.XPATH, mdl.get_first_agents_case_number_in_dashboard_page),
             message="failed to get case count ",
        )
        return case_count

    def click_number_of_agents_link(self):
        agents = agent_management_page.AgentsPage(self.driver)
        commons = Commons(self.driver)
        case_count = []
        link =self.get_number_of_virtual_link_present_on_dashboard()
        for i in link:
            LOGGER.info("clicking on agents link ")
            self.actions.move_to_element(i).click().perform()
            window_handles = self.driver.window_handles
            self.driver.switch_to.window(window_handles[1])
            try:
                commons.wait_for_loader_to_disappear()
                check_for_agents_profile_is_displayed = agents.check_agents_profile()
                if check_for_agents_profile_is_displayed is False:
                   case_count.append(0)
                else:
                    backlog_cases = agents.get_case_count_on_tabs(AgentManagementTabs.BACKLOG)
                    case_count.append(backlog_cases)
                self.driver.close()
                self.driver.switch_to.window(window_handles[0])
            except:
                self.driver.close()
                self.driver.switch_to.window(window_handles[0])
        return case_count

    def click_on_cancel_button(self):
        """THIS method helps to click on the cancel button present on  add card"""
        self.click_on_element(
            (By.XPATH, mdl.cancel_button),
            timeout=5,
            message="failed to cancel button",
        )

    def click_on_back_button(self):
        """This method helps to click on the back button """
        self.click_on_element(
            (By.XPATH, mdl.back_button),
            timeout=5,
            message="failed to click on the back button",
        )