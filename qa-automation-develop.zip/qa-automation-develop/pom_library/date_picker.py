"""
A collection of reusable methods that perform specific actions on the date picker widget
"""
__author__ = "Praveen Nagajothi"
__copyright__ = "Copyright (C) 2021 SupportLogic"

import logging
from datetime import date

from selenium.webdriver.common.by import By

from enums import QuarterOptions
from locators import date_picker_locators as dpl
from pom_library.helper_methods import HelperMethods

LOGGER: logging.Logger = logging.getLogger(__name__)


class DatePicker(HelperMethods):
    def is_date_picker_visible(self):
        """Check if the date picker is displayed"""
        LOGGER.info("Checking visibility of date picker..")
        return self.is_element_visible((By.CSS_SELECTOR, dpl.date_picker_toggle_css))

    def get_applied_date_filter(self) -> str:
        """Fetch the value displayed in the date picker button"""
        LOGGER.info("Getting current selected date filter..")
        return self.get_element_text_or_value(
            (By.CSS_SELECTOR, dpl.date_picker_toggle_css),
            message="Failed to get display text from date picker button",
        )

    def open_date_picker(self) -> None:
        """Opens the date picker popup"""
        LOGGER.info("Opening date picker..")
        self.click_on_element(
            (By.CSS_SELECTOR, dpl.date_picker_toggle_css),
            message="Failed to toggle open the date picker popup",
        )

    def apply_selected_date_filter(self) -> None:
        """
        Clicks on the apply button in the date picker popup. Only works when the new
        date filter selected is different than the current selected, otherwise raises an
        exception.
        """
        LOGGER.info("Clicking on date picker apply button..")
        self.click_on_element(
            (By.CSS_SELECTOR, dpl.date_picker_apply_btn_css),
            message="Failed to apply selected date filter",
        )

    def cancel_date_filter_selection(self) -> None:
        """Clicks on the date picker cancel button. This also closes the date picker
        popup"""
        LOGGER.info("Clicking on date picker cancel button..")
        self.click_on_element(
            (By.CSS_SELECTOR, dpl.date_picker_cancel_btn_css),
            message="Failed to cancel selected date filter",
        )

    def select_custom_date_range(self, from_date: date, to_date: date) -> None:
        """
        Enters the passed date objects as string values in the date filter from and
        to fields

        Parameters
        ----------
        from_date: date
            Starting date from which you want the tickets to be shown
        to_date: date
            End date till which the tickets will be shown for
        """
        from_date_string: str = from_date.strftime("%m/%d/%y")
        to_date_string: str = to_date.strftime("%m/%d/%y")

        LOGGER.info(f"Entering {from_date_string} in date filter From field..")
        self.pass_value_to_element(
            from_date_string,
            (By.CSS_SELECTOR, dpl.date_picker_from_field_css),
            message="Failed to enter value in date picker From field",
        )

        LOGGER.info(f"Entering {to_date_string} in date filter To field..")
        self.pass_value_to_element(
            to_date_string,
            (By.CSS_SELECTOR, dpl.date_picker_to_field_css),
            message="Failed to enter value in date picker To field",
        )

    def select_right_now_shortcut(self) -> None:
        """Click on the 'This month' date picker shortcut"""
        LOGGER.info("Selecting 'This month' date picker shortcut..")
        self.click_on_element(
            (By.CSS_SELECTOR, dpl.right_now_shortcut_css),
            message="Failed to click 'Right now' date picker shortcut",
        )

    def select_this_month_shortcut(self) -> None:
        """Click on the 'This month' date picker shortcut"""
        LOGGER.info("Selecting 'This month' date picker shortcut..")
        self.click_on_element(
            (By.CSS_SELECTOR, dpl.this_month_shortcut_css),
            message="Failed to click 'This month' date picker shortcut",
        )

    def select_year_to_date_shortcut(self) -> None:
        """Clicks on the 'Year to date' date picker shortcut"""
        LOGGER.info("Selecting 'Year to date' date picker shortcut..")
        self.click_on_element(
            (By.CSS_SELECTOR, dpl.year_to_date_shortcut_css),
            message="Failed to click 'Year to date' date picker shortcut",
        )

    def select_last_n_months_shortcut(self, months: int = None) -> None:
        """
        Clicks the last month date picker shortcut. The range of months to be selected
        can be changed by passing in an available option as an argument to this method.
        The default value is the previously selected choice.

        Parameters
        ----------
        months: int, optional
            Range of months. Available options: 1, 3, 6, 9
        """
        LOGGER.info("Selecting 'Last month' date picker shortcut..")
        self.click_on_element(
            (By.CSS_SELECTOR, dpl.last_month_shortcut_css),
            message="Failed to click 'Last month' date picker shortcut",
        )

        if months:
            option: str = dpl.last_month_shortcut_dropdown_options_css.format(months=months)
            self.click_on_element(
                (By.CSS_SELECTOR, option),
                message=f"Failed to click {months} in last month shortcut dropdown",
            )

    def select_quarter_shortcut(
        self, quarter: QuarterOptions = None, year: str = None
    ) -> None:
        """
        Clicks the quarter date picker shortcut. You can select the required quarter and
        the year by passing them as an argument to this method. The default value for
        both is what was previously selected.

        Parameters
        ----------
        quarter: QuarterOptions, optional
            quarter for which you want the tickets to be shown
        year: str, optional
            the required year
        """
        LOGGER.info("Selecting quarter date picker shortcut..")
        self.click_on_element(
            (By.CSS_SELECTOR, dpl.quarter_shortcut_css),
            message="Failed to click quarter date picker shortcut",
        )

        if quarter:
            self.click_on_element(
                (By.CSS_SELECTOR, dpl.quarter_shortcut_1st_dropdown_css),
                message="Failed to toggle first dropdown in quarter shortcut",
            )
            option = dpl.quarter_shortcut_dropdown_options_css.format(value=quarter)
            self.click_on_element(
                (By.CSS_SELECTOR, option),
                message=f"Failed to click {quarter} in first dropdown options",
            )

        if year:
            self.click_on_element(
                (By.CSS_SELECTOR, dpl.quarter_shortcut_2nd_dropdown_css),
                message="Failed to toggle second dropdown in quarter shortcut",
            )
            option: str = dpl.quarter_shortcut_dropdown_options_css.format(value=year)
            self.click_on_element(
                (By.CSS_SELECTOR, option),
                message=f"Failed to click {year} in second dropdown options",
            )

    def click_on_move_forward_arrow_button(self):
        """This method helps to click on move forward arrow button"""
        LOGGER.info("Clicking move forward arrow button in date picker ..")
        self.click_on_element(
            (By.XPATH, dpl.move_forward_arrow_button),
            message="Failed to click on move forward arrow button",
        )

    def get_month_name_on_calendar(self):
        """This method helps to get the month name from the second (to) calendar"""

        month_name = self.get_element_text_or_value(
            (By.XPATH, dpl.month_name_on_calendar)
        )
        return month_name

    # shift calendar date picker shortcuts
    def select_last_week_shortcut(self):
        """Click on the 'Last week' date picker shortcut"""
        LOGGER.info("Selecting 'Last week' date picker shortcut..")
        self.click_on_element(
            (By.CSS_SELECTOR, dpl.last_week_shortcut_css),
            message="Failed to click 'Last week' date picker shortcut",
        )

    def select_this_week_shortcut(self):
        """Click on the 'This week' date picker shortcut"""
        LOGGER.info("Selecting 'This week' date picker shortcut..")
        self.click_on_element(
            (By.CSS_SELECTOR, dpl.this_week_shortcut_css),
            message="Failed to click 'This week' date picker shortcut",
        )

    def select_next_week_shortcut(self):
        """Click on the 'Next week' date picker shortcut"""
        LOGGER.info("Selecting 'Next week' date picker shortcut..")
        self.click_on_element(
            (By.CSS_SELECTOR, dpl.next_week_shortcut_css),
            message="Failed to click 'Next week' date picker shortcut",
        )
