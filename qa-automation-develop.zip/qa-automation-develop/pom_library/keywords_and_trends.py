"""
A collection of reusable methods that perform specific actions on the Keywords and
Trends page.
"""
__author__ = "Praveen Nagajothi"
__copyright__ = "Copyright (C) 2021 SupportLogic"

import logging
import time
from typing import Literal

from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.remote.webdriver import WebDriver
from selenium.webdriver.remote.webelement import WebElement

import utils
from enums import TrendsGroupByOptions, TrendsPageContentTabs
from locators import keyword_and_trends_locators as ktl
from locators import support_hub_locators as shl
from pom_library.helper_methods import HelperMethods

LOGGER: logging.Logger = logging.getLogger(__name__)


class KeywordsAndTrends(HelperMethods):
    def __init__(self, driver: WebDriver) -> None:
        super().__init__(driver)

    def get_search_box_text(self) -> list[str]:
        """Get the text displayed in the search box"""
        LOGGER.info("Getting text from search box..")
        if not self.is_element_visible((By.CSS_SELECTOR, ktl.search_box_pills_css)):
            return []

        search_keyword_pills: list[
            WebElement
        ] = self.driver.find_elements(By.CSS_SELECTOR, ktl.search_box_pills_css)
        search_text: list[str] = [
            search_keyword_pill.text for search_keyword_pill in search_keyword_pills
        ]
        return search_text

    def get_applied_search_keywords(self) -> list[str]:
        """Get the search conditions shown next to the graph title when applied"""
        LOGGER.info("Getting applied search keywords from graph title..")
        if not self.is_element_visible(
            (By.CSS_SELECTOR, ktl.applied_search_condition_css)
        ):
            return []

        applied_keyword_pills: list[
            WebElement
        ] = self.driver.find_elements(By.CSS_SELECTOR, ktl.applied_search_condition_css)
        applied_search_keywords: list[str] = [
            search_keyword_pill.text for search_keyword_pill in applied_keyword_pills
        ]
        return applied_search_keywords

    def search_using_condition(self, condition: Literal["all", "any"], *args) -> None:
        """
        Search tickets for All or Any of the conditions passed.

        Parameters
        ----------
        condition: String literal
            Accepts one of two conditions, all or any.
        """
        LOGGER.info(f"Searching tickets using {condition} condition..")
        # clear search box if not empty
        if self.get_search_box_text():
            self.driver.find_element(By.CSS_SELECTOR, ktl.clear_search_box_css).click()

        condition_locator: tuple[str, str] = (By.XPATH, ktl.search_using_and)
        if condition == "any":
            condition_locator = (By.XPATH, ktl.search_using_or)

        self.click_on_element((By.CSS_SELECTOR, ktl.search_box_placeholder_css))
        self.click_on_element(condition_locator)  # select search and/or condition

        # enter text in input field one by one
        self.actions.move_to_element(
            self.driver.find_element(By.CSS_SELECTOR, ktl.search_box_input_field_css)
        )
        for arg in args:
            time.sleep(0.2)
            self.driver.find_element(
                By.CSS_SELECTOR, ktl.search_box_input_field_css
            ).send_keys(arg, Keys.ENTER)
        self.driver.find_element(
            By.CSS_SELECTOR, ktl.search_box_input_field_css
        ).send_keys(Keys.ENTER)

    def get_selected_group_by_value(self) -> str:
        """Get the current displayed value from the group by dropdown selector"""
        LOGGER.info("Getting selected group by value..")
        return self.get_element_text_or_value(
            (By.CSS_SELECTOR, ktl.group_by_dropdown_css),
            message="Failed to get selected group by value",
        )

    def group_by(self, option: TrendsGroupByOptions) -> None:
        """
        Groups the tickets by the given option

        Parameters
        ----------
        option: TrendsPageContentTabs
            value to select in the group by dropdown
        """
        LOGGER.info(f"Grouping tickets by {option.value}..")
        self.click_on_element(
            (By.CSS_SELECTOR, ktl.group_by_dropdown_css),
            message="Failed to open group by dropdown",
        )
        self.click_on_element(
            (By.CSS_SELECTOR, ktl.group_by_options_css.format(option=option.value))
        )

    def validate_xaxis_date_label(self, expected_label: str) -> bool:
        """Fetches the labels displayed in the xaxis of the graph and validates with
        the expected value"""
        LOGGER.info(f"Comparing {expected_label} against labels in xaxis..")
        labels: str = self.get_element_text_or_value(
            (By.CSS_SELECTOR, ktl.graph_xaxis_labels_css),
            message="Failed to get date labels from graph x-axis",
        )
        return utils.validate_values_in(
            "Selected date", expected_label, "Date in graph x-axis", labels
        )

    def click_on_tab(self, tab_name: TrendsPageContentTabs) -> None:
        """Click on the given content tab"""
        LOGGER.info(f"Clicking on {tab_name.name} tab..")
        self.mouse_click_on_element(
            (By.CSS_SELECTOR, ktl.tab_cards_css.format(tab_name=tab_name.value)),
            message=f"Failed to click on {tab_name.value}",
        )

    def check_presence_of_content_tabs(self, tab_name):
        """Method checks if the content tab is enabled/ present for trends page and is clickable
         for further actions

        Parameters
        ----------
        tab_name : TrendsPageContentTabs
          Enum representation of the navbar page display text

        Returns
        -------
        Content tab name if the content tab is enabled or present, false otherwise
        """
        try:
            LOGGER.info("Entering to check presence of content tabs")
            tab_element: str = ktl.content_tabs.format(tab_name=tab_name.value)
            LOGGER.info(tab_element)
            content_tab_element = self.driver.find_element(By.XPATH, tab_element)
            LOGGER.info("Printing overview element :")
            LOGGER.info(content_tab_element)
            ActionChains(self.driver).move_to_element(content_tab_element).perform()
            LOGGER.info("returning result")
            if content_tab_element.is_displayed():
                LOGGER.info("Element is displayed")
                return True
            else:
                return False
        except Exception:
            return "not enabled"

    def traverse_to_content_tabs(self, tab_name: TrendsPageContentTabs):
        """This method will click on the tab's name that will be passed as parameter"""
        try:
            LOGGER.setLevel(logging.INFO)
            LOGGER.info(tab_name.value)
            content_tab_locator = self.driver.find_element(By.XPATH, 
                ktl.content_tabs.format(tab_name=tab_name.value)
            )
            LOGGER.info(content_tab_locator)
            # First check if content tab is enabled:
            # LOGGER.info(self.check_presence_of_content_tabs(tab_name))
            # LOGGER.info("Came out from check presence of tabs")
            if not self.check_presence_of_content_tabs(tab_name) is False:
                # If enabled check if the tab is in view to perform click action:
                LOGGER.info("Since True entered the loop")
                if not content_tab_locator.is_displayed():
                    # scroll to that element and then click for further action:
                    ActionChains(self.driver).move_to_element(
                        content_tab_locator
                    ).click().perform()

                else:
                    LOGGER.info("Already content tab is visible so clicking on it")
                    content_tab_locator.click()
        except NoSuchElementException:
            return False

    def check_if_no_ticket_state_is_shown(self) -> bool:
        """
        returns
        __________
        Boolean value true or False based on if the message is displayed or not
        """
        try:
            if self.driver.find_element(By.XPATH, ktl.no_filter_msg).is_displayed():
                LOGGER.debug(msg="Check the content tab")
                return True

        except Exception:
            return False

    def check_which_sentiment_signal_is_selected(self) -> str:
        """

        Returns
        -------
        True if the sentiment signal is selected
        False if the sentiment signal is not wholly selected
        """
        LOGGER.info("Starting {check_which_sentiment_signal_is_selected}")
        get_signal = self.driver.find_element(By.XPATH, ktl.signal_btn)
        LOGGER.info(get_signal.text)
        return get_signal.text

    def click_tickets_present_in_content_sentiment_tabs(
        self, tab_name: TrendsPageContentTabs
    ):
        """This will click on tickets present in sentiments content tabs to validate its opening in supporthub
        Will exclude Overview and Escalations tab as they have different UI and it has charts.
        """
        try:
            if tab_name.value not in [
                TrendsPageContentTabs.OVERVIEW.value,
                TrendsPageContentTabs.ESCALATIONS.value,
            ]:
                ticket_ele = self.driver.find_element(By.XPATH, ktl.tickets_cards)
                ActionChains(self.driver).move_to_element(ticket_ele).click(
                    ticket_ele
                ).perform()
                case_id = self.get_element_text_or_value(
                    (By.CSS_SELECTOR, shl.case_id_css)
                )
                return case_id
            else:
                return "Not in desired tab"

        except Exception:
            return "Not in desired tab"

    def click_on_graph_content_tabs(self, tab_name: TrendsPageContentTabs) -> str:
        """Xyz"""
        try:
            if tab_name.value in [
                TrendsPageContentTabs.OVERVIEW.value,
                TrendsPageContentTabs.ESCALATIONS.value,
            ]:
                self.graph_list_count(tab_name)
                self.click_on_element((By.CSS_SELECTOR, ktl.pie_chart_css))
                case_id: str = self.get_element_text_or_value(
                    (By.CSS_SELECTOR, ktl.sentiment_cards_case_id_css)
                )
                self.click_on_element((By.CSS_SELECTOR, ktl.tickets_card_in_popup_css))
                return case_id
            else:
                return "Not in desired tab"

        except Exception:
            return "Not in desired tab"

    def graph_list_count(self, tab_name: TrendsPageContentTabs):
        """xyz"""
        try:
            if tab_name.value in [
                TrendsPageContentTabs.OVERVIEW.value,
                TrendsPageContentTabs.ESCALATIONS.value,
            ]:
                list_l = self.driver.find_element(By.XPATH, ktl.graph_list_h3).text
                co_li = self.driver.find_elements(
                    By.CSS_SELECTOR, ktl.pie_chart_css
                ).text
                LOGGER.info(list_l)
                LOGGER.info(co_li)
                return list_l

            else:
                return "No graphs present"
        except Exception:
            return "No graph present"

    def get_displayed_case_count(self) -> str:
        """Fetch the case count displayed below the trends search bar"""
        return self.get_element_text_or_value(
            (By.CSS_SELECTOR, ktl.displayed_case_count_css),
            message="Failed to get case count under trends search"
        )

    def open_graph_menu(self) -> None:
        """Clicks on the 3 dots next in the trends graph"""
        LOGGER.info("Opening graph menu popover..")
        self.click_on_element((By.CSS_SELECTOR, ktl.graph_menu_css))

    def export_chart_as_csv(self) -> None:
        """Selects CSV as export option in the graph menu. If Image type is selected,
        it is deselected"""
        LOGGER.info("Exporting chart as CSV..")
        if self.driver.find_element(
            By.CSS_SELECTOR, ktl.graph_menu_export_as_image_checkbox_css
        ).is_selected():
            self.click_on_element((By.CSS_SELECTOR, ktl.graph_menu_export_as_image_css))

        if not self.driver.find_element(
            By.CSS_SELECTOR, ktl.graph_menu_export_as_csv_checkbox_css
        ).is_selected():
            self.click_on_element((By.CSS_SELECTOR, ktl.graph_menu_export_as_csv_css))
        self.click_on_element((By.CSS_SELECTOR, ktl.graph_menu_export_button_css))

    def get_displayed_case_count_on_tab(self, tab_name: TrendsPageContentTabs):
        """Fetch the case count displayed on the trends page content tab"""
        return self.get_element_text_or_value(
            (By.XPATH, ktl.tab_case_count.format(tab_name=tab_name.value)),
            message="Failed to get case count under trends search"
        )
