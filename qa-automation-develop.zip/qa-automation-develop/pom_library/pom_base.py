"""This file is for all things that the POM pages will have in common"""
__author__ = "Gary Murry"
__copyright__ = "Copyright (C) 2020 SupportLogic"

import os
import pathlib
import platform
import urllib.parse
from typing import Any

import pytest
import requests
from selenium.webdriver.remote.webdriver import WebDriver

import constants


class PomBase:
    """
    A base class for POM objects to inherit from.

    Methods
    -------
    do_login()
        This logs the user in to SL_URL with the SL_USER and SL_PWD
    get_get_page_title()
        Returns the title of the current page
    get_data_from_sl_api()
        Fetches data from the given SupportLogic API endpoint
    """

    def __init__(self, driver: WebDriver, auto_login: bool = True) -> None:
        """Init the base class.

        Parameters
        ----------
        driver: WebDriver
            Set this to the current driver instance.
        auto_login : bool, optional
            Set this to False if you are testing the login flow. (default = True)
        """
        self.driver: WebDriver = driver
        self.username: str = os.getenv("SL_USER")
        self.password: str = os.getenv("SL_PWD")

        # Get the URL of the SUT
        self.base_url: str = os.getenv("SL_URL", default=constants.default_url)
        self.base_url = self.base_url.removesuffix("/")
        if not self.base_url.startswith("https://"):
            self.base_url = "https://" + self.base_url

        # Check if this is a fresh browser start
        if "data:," in self.driver.current_url:
            self.driver.get(self.base_url)

        if not (self.username and self.password):
            env_var: str = "SL_PWD" if self.username else "SL_USER"
            pytest.skip(f"The environment variable {env_var} needs to be set.")

        if auto_login:
            self.do_login()

    def do_login(self) -> None:
        """
        Allows for the tests to be ran without the login test suite. It works by hitting
        the login flow's API's through a dummy page the QE controls. It should work even
        if UI for the login page changes, as long as the API remains.
        """
        # Check if we are already logged in
        if "identity" not in self.driver.current_url:
            return
        # Figure out where we are running from, so we can find the login HTML
        base_path = pathlib.Path(__file__)
        file_prefix: str = "file:///" if platform.system() != "Windows" else ""
        self.driver.get(
            f"{file_prefix}{base_path.parent.parent}/assets/SeleniumTestStart.html"
        )

        self.driver.find_element(value="email").send_keys(self.username)
        self.driver.find_element(value="passwd").send_keys(self.password)
        self.driver.find_element(value="url").send_keys(self.base_url)

        # This allows us to switch the target URL for the login process
        switch_url_script: str = (
            f"""document.dummyLogin.action = '{self.base_url + "/login/local"}';"""
        )

        self.driver.execute_script(switch_url_script)
        self.driver.find_element(value="starttestbutton").click()

    def get_page_title(self) -> str:
        """Returns the title of the current page"""
        return self.driver.title

    def __connect_with_sl_api(
        self,
        method: str,
        api_endpoint: str,
        request_body: Any = None,
        username: str = os.getenv("SL_USER"),
        password: str = os.getenv("SL_PWD"),
    ):
        with requests.Session() as session:
            # Login into SupportLogic using email and password
            login_url: str = f"{self.base_url}/login/local"
            headers: dict = {"content-type": "application/x-www-form-urlencoded"}
            params: dict = {"email": username, "passwd": password}
            session.post(
                login_url, headers=headers, data=urllib.parse.urlencode(params)
            )
            # Pass the session cookies as header with the GET request
            cookies: dict = session.cookies.get_dict()
            header_string: str = "; ".join(
                [f"{key}={val}" for key, val in cookies.items()]
            )
            headers: dict = {
                "content-type": "application/json",
                "Cookie": header_string,
            }

            return requests.request(
                method, self.base_url + api_endpoint, data=request_body, headers=headers
            ).json()

    def get_data_from_sl_api(
        self,
        api_endpoint: str,
        username: str = os.getenv("SL_USER"),
        password: str = os.getenv("SL_PWD"),
    ) -> Any:
        """
        This method makes a GET call to the given SupportLogic API endpoint with the
        request body (if any) and returns the response.

        Parameters
        __________
        api_endpoint: str
            the URL suffix to send & receive information from
        username: str
            username to be used for API authentication (uses system wide default)
        password: str
            password to be used for API authentication, corresponding to the given
            username (uses system wide default)

        Returns
        _______
        dict
            API response body
        """
        return self.__connect_with_sl_api(
            "GET", api_endpoint, username=username, password=password
        )

    def post_data_to_sl_api(
        self,
        api_endpoint: str,
        request_body: Any = None,
        username: str = os.getenv("SL_USER"),
        password: str = os.getenv("SL_PWD"),
    ) -> Any:
        """
        This method makes a POST call to the given SupportLogic API endpoint with the
        request body (if any) and returns the response.

        Parameters
        __________
        api_endpoint: str
            the URL suffix to send & receive information from
        request_body: Any
            data to send along with the API request call
        username: str
            username to be used for API authentication (uses system wide default)
        password: str
            password to be used for API authentication, corresponding to the given
            username (uses system wide default)

        Returns
        _______
        dict
            API response body
        """
        return self.__connect_with_sl_api(
            "POST", api_endpoint, request_body, username, password
        )

    def delete_data_with_sl_api(self,api_endpoint: str):
        return self.__connect_with_sl_api("DELETE", api_endpoint)
