"""This module is  focuses on  creating reusable method the ahs page  """
__author__ = "Neha Jha"
__copyright__ = "Copyright (C) 2021 SupportLogic"

import time
import logging
from selenium.webdriver import Keys

from pom_library.pom_base import PomBase
from pom_library.helper_methods import HelperMethods
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from locators import ahs_locator
LOGGER: logging.Logger = logging.getLogger(__name__)

class AhsPage(HelperMethods):

    def __init__(self, driver):
        super().__init__(driver)
        self.actions = ActionChains(driver)
        self.wait = WebDriverWait(driver, 20)



    def check_for_edit_button_is_present_or_not(self):
        """This is method check for edit button is display or not"""
        LOGGER.info("check for edit button is displayed or not")
        return self.is_element_visible(
            (
                By.XPATH,
                ahs_locator.edit_button
            ))

    def click_on_edit_button(self):
        """This method click on edit button"""
        LOGGER.info("clicking on edit button")
        self.click_on_element(
            (By.XPATH, ahs_locator.edit_button),
            timeout=5,
            message="failed to click on edit button",
        )

    def hover_on_agree_icon(self):
        """This is method to hover on agree icon"""
        LOGGER.info("hover over agree icon ")
        self.hover_on_element(
            (By.XPATH, ahs_locator.ahs_agree_health_assessment),
            message="Failed to hover over agree health assessment",
        )

    def hover_on_disagree_icon(self):
        """This is method to hover on disagree icon"""
        LOGGER.info("hover over disagree icon ")
        self.hover_on_element(
            (By.XPATH, ahs_locator.ahs_disagree_health_assessment),
            message="Failed to hover over disagree health assessment",
        )

    def click_on_agree_button_health_assessment(self):
        """This is method to  click on agree thumbs up  """
        LOGGER.info("click on agree thumbs up")
        self.javascript_click_on_element(
            (By.XPATH, ahs_locator.ahs_agree_health_assessment),
            message="failed to click on  agree button health assessment",
        )
    def click_on_disagree_button_health_assessment(self):
        """This is method to  click on disagree thumbs down button  """

        LOGGER.info("click on disagree thumbs up")
        self.javascript_click_on_element(
            (By.XPATH, ahs_locator.ahs_disagree_health_assessment),
            message="failed to click on  disagree button health assessment",
        )

    def click_on_cancel_button(self):
        """This method helps to click on cancel button """
        LOGGER.info("click on cancel")
        self.click_on_element(
            (By.XPATH, ahs_locator.cancel_button),
            message="failed to click on cancel button",
        )

    def click_on_save_button(self):
        """This method helps to click on save button """
        LOGGER.info("click on save button")
        self.click_on_element(
            (By.XPATH, ahs_locator.save_button),
            message="failed to click on cancel button",
        )

    def adding_comment_in_the_comment_section_of_gud_customer(self,comment):
        """This method helps to  add comment in  the comment section"""
        LOGGER.info("adding comment in comment section")
        self.pass_value_to_element(
            comment,
            (By.XPATH, ahs_locator.comment_area),
            message="failed to added comment in the comment area",

        )

    def check_for_the_presence_of_thumbs_down(self):
        """This method helps to  checks for the presence of thumbs down"""
        return self.is_element_visible(
            (
                By.XPATH,
                ahs_locator.ahs_disagree_health_assessment
            ))

    def check_for_the_presence_of_thumbs_up(self):
        """This method helps to  checks for the presence of thumbs down"""
        return self.is_element_visible(
            (
                By.XPATH,
                ahs_locator.ahs_agree_health_assessment
            ))


    def click_on_fair_button(self):
        """This method helps to click on fair button """
        LOGGER.info("clicking on fair radio button")
        self.click_on_element(
            (By.XPATH, ahs_locator.fair),
            message="failed to click on fair button",
        )

    def get_assessment_text_near_edit_button(self):
        text: str = self.get_element_text_or_value(
            (By.XPATH, ahs_locator.assessment_text),
            timeout=20,
            message="failed to get assessment text near edit button",
        )
        return text

    def click_on_bad_button(self):
        """This method helps to click on fair button """
        LOGGER.info("clicking on bad radio button")
        self.click_on_element(
            (By.XPATH, ahs_locator.bad),

            message="failed to click on bad button",
        )

    def check_for_the_presence_ahs_panel(self):
        """This method helps to  checks for the presence of thumbs down"""
        return self.is_element_visible(
            (
                By.XPATH,
                ahs_locator.ahs_panel
            ))

    def check_for_feedback_form_is_present_or_not(self):
        """This is method check for feedback form is present or not"""
        LOGGER.info("check for the feed back form is present or not")
        return self.is_element_visible(
            (
                By.XPATH,
                ahs_locator.feedback_form
            ))

    def click_on_disagree_button_escalation_option(self,escalated_option):
        """This method helps to click on  text_place_holder """
        LOGGER.info(f"click on {escalated_option} in escalation module")
        self.click_on_element(
            (By.XPATH, ahs_locator.disagree_escalation_option.replace("text_place_holder",escalated_option)),
            message=f"failed to click on {escalated_option} button",
        )

    def check_for_the_presence_ahs_panel(self):
        """This method helps to  checks for the presence of thumbs down"""
        return self.is_element_visible(
            (
                By.XPATH,
                ahs_locator.ahs_panel
            ))
    def click_on_good_button(self):
        """This method helps to click on bad button """
        LOGGER.info("clicking on bad radio button")
        self.click_on_element(
            (By.XPATH, ahs_locator.good),
            message="failed to click on fair button",
        )


    def click_on_good_button(self):
        """This method helps to click on bad button """
        LOGGER.info("clicking on bad radio button")
        self.click_on_element(
            (By.XPATH, ahs_locator.good),
            message="failed to click on fair button",
        )


    def get_ahs_health_score(self):
        good_ahs_score = self.get_element_text_or_value(
            (By.XPATH, ahs_locator.ahs_score_chat)
        )
        return good_ahs_score

    def check_present_of_thump_down_and_present_of_thumbs_up(self):
        try:
            thumps_up_and_thumps_down = self.wait.until(
                EC.visibility_of_element_located(
                    (By.XPATH, ahs_locator.ahs_thumbs_down_and_thumb_up)
                )
            ).is_displayed()
            if thumps_up_and_thumps_down:
                LOGGER.info("thumps up and thumps down button is not displayed ")
                return False

        except Exception:
            LOGGER.info("thumps up and thumps down button is displayed ")

            return True


