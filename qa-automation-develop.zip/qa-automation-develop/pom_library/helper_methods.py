"""This file contains methods that wrap specific actions"""
from __future__ import annotations

__author__ = "Praveen Nagajothi"
__copyright__ = "Copyright (C) 2021 SupportLogic"

from typing import Any

from selenium.common.exceptions import (
    ElementClickInterceptedException, StaleElementReferenceException, TimeoutException,
)
from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webdriver import WebDriver
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.support.wait import WebDriverWait

from constants import EXPLICIT_WAIT_TIME
from pom_library.pom_base import PomBase


class HelperMethods(PomBase):
    def __init__(self, driver: WebDriver, auto_login: bool = True) -> None:
        super().__init__(driver, auto_login)
        self.actions: ActionChains = ActionChains(driver)
        self.wait: WebDriverWait = WebDriverWait(
            driver,
            EXPLICIT_WAIT_TIME,
            ignored_exceptions=StaleElementReferenceException,
        )

    def validate_url(self, target_url: str) -> bool:
        """
        Checks the success state of the login operation by checking for the target
        text in current url.

        Parameters
        __________
        target_url: str
            expected URL to check against current URL.

        Returns
        -------
        bool
            True when the target url matches, False otherwise.
        """
        try:
            return self.wait.until(ec.url_contains(target_url))
        except TimeoutException:
            return False

    def __element_click(
        self,
        locator: tuple[str, str],
        timeout: int = 30,
        message: str = "",
        javascript: bool = False,
        mouse_click: bool = False,
    ) -> None:
        """
        A private method that performs various types of click operations based on the
        flags (default is a normal click).

        If both javascript and mouse_click flags are True, the javascript flag takes
        precedence.

        Parameters
        ----------
        locator: tuple[str, str]
            A tuple defining the locator type & actual element locator
        timeout: int, optional
            Number of seconds to wait before timing out (default is 30)
        message: str, optional
            Message to display on timing out (default is empty)
        javascript: bool, optional
            Flag enabling javascript click (default is False)
        mouse_click: bool, optional
            Flag enabling mouse click (default is False)
        """
        ignored_exceptions: tuple = (
            StaleElementReferenceException,
            ElementClickInterceptedException,
        )
        wait = WebDriverWait(
            self.driver, timeout, ignored_exceptions=ignored_exceptions
        )
        element: WebElement = wait.until(
            ec.element_to_be_clickable(locator), message=message
        )
        self.driver.execute_script(
            "arguments[0].scrollIntoView({block: 'center'});", element
        )
        if javascript:
            self.driver.execute_script("arguments[0].click();", element)
        elif mouse_click:
            self.actions.move_to_element(element).click().perform()
        else:
            element.click()

    def get_element_when_visible(
        self, locator: tuple[str, str], timeout: int = 30, message: str = ""
    ) -> WebElement:
        """
        Get element represented by given locator once it is located and visible.

        Parameters
        ----------
        locator: tuple[str, str]
            A tuple defining the locator type & actual element locator.
        timeout: int, optional
            Number of seconds to wait before timing out (default is 30).
        message: str, optional
            Message to display on timing out (default is empty).
        """
        wait = WebDriverWait(
            self.driver, timeout, ignored_exceptions=StaleElementReferenceException
        )
        return wait.until(ec.visibility_of_element_located(locator), message=message)

    def is_element_enabled(self, locator: tuple[str, str], timeout: int = 15) -> bool:
        """
        An Expectation for checking an element is visible and enabled.

        Parameters
        ----------
        locator: tuple[str, str]
            A tuple defining the locator type & actual element locator.
        timeout: int, optional
            Number of seconds to wait before timing out (default is 15).
        """
        try:
            return self.get_element_when_visible(locator, timeout=timeout).is_enabled()
        except TimeoutException:
            return False

    def is_element_visible(self, locator: tuple[str, str], timeout: int = 30) -> bool:
        """
        An Expectation for checking an element is present in the DOM and visible.

        Parameters
        ----------
        locator: tuple[str, str]
            A tuple defining the locator type & actual element locator.
        timeout: int, optional
            Number of seconds to wait before timing out (default is 15).
        """
        try:
            return self.get_element_when_visible(
                locator, timeout=timeout
            ).is_displayed()
        except TimeoutException:
            return False

    def click_on_element(
        self, locator: tuple[str, str], timeout: int = 30, message: str = ""
    ) -> None:
        """
        Performs a normal click on the element represented by given locator, once it
        is visible and enabled.

        Parameters
        ----------
        locator: tuple[str, str]
            A tuple defining the locator type & actual element locator.
        timeout: int, optional
            Number of seconds to wait before timing out (default is 30).
        message: str, optional
            Message to display on timing out (default is empty).
        """
        self.__element_click(locator, timeout=timeout, message=message)

    def mouse_click_on_element(
        self, locator: tuple[str, str], timeout: int = 30, message: str = ""
    ) -> None:
        """
        Performs a mouse click on the element represented by given locator, once it
        is visible and enabled.

        Parameters
        ----------
        locator: tuple[str, str]
            A tuple defining the locator type & actual element locator.
        timeout: int, optional
            Number of seconds to wait before timing out (default is 30).
        message: str, optional
            Message to display on timing out (default is empty).
        """
        self.__element_click(
            locator, timeout=timeout, message=message, mouse_click=True
        )

    def javascript_click_on_element(
        self, locator: tuple[str, str], timeout: int = 30, message: str = ""
    ) -> None:
        """
        Performs a javascript click on the element represented by given locator, once it
        is visible and enabled.

        Parameters
        ----------
        locator: tuple[str, str]
            A tuple defining the locator type & actual element locator.
        timeout: int, optional
            Number of seconds to wait before timing out (default is 30).
        message: str, optional
            Message to display on timing out (default is empty).
        """
        self.__element_click(locator, timeout=timeout, message=message, javascript=True)

    def get_element_attribute(
        self,
        attribute_name: str,
        locator: tuple[str, str],
        timeout: int = 15,
        message: str = "",
    ) -> str:
        """
        Gets the given attribute value of the element.

        Parameters
        ----------
        attribute_name: str
            Name of the attribute value to be fetched
        locator: tuple[str, str]
            A tuple defining the locator type & actual element locator.
        timeout: int, optional
            Number of seconds to wait before timing out (default is 15).
        message: str, optional
            Message to display on timing out (default is empty).
        """
        element: WebElement = self.get_element_when_visible(
            locator, timeout=timeout, message=message
        )
        return element.get_attribute(attribute_name)

    def get_element_text_or_value(
        self,
        locator: tuple[str, str],
        timeout: int = 15,
        message: str = "",
        get_value: bool = False,
    ) -> str:
        """
        Gets the display text of the element, if get_value is False (default).

        If get_value flag is set to true, it takes precedence, and the value attribute
        content is returned.

        Parameters
        ----------
        locator: tuple[str, str]
            A tuple defining the locator type & actual element locator.
        timeout: int, optional
            Number of seconds to wait before timing out (default is 15).
        message: str, optional
            Message to display on timing out (default is empty).
        get_value: bool, optional
        """
        element: WebElement = self.get_element_when_visible(
            locator, timeout=timeout, message=message
        )
        if get_value:
            return element.get_attribute("value")
        return element.text

    def pass_value_to_element(
        self, value: Any, locator: tuple[str, str], message: str = ""
    ) -> None:
        """
        Send value as input to the element represented by the given locator.

        Parameters
        ----------
        value: Any
            Simple string values, key events or file paths
        locator: tuple[str, str]
            A tuple defining the locator type & actual element locator.
        message: str, optional
            Message to display on timing out (default is empty).
        """
        element = self.get_element_when_visible(locator, timeout=30, message=message)
        element.clear()
        element.send_keys(value)

    def select_if_unselected(self, by: str, locator: str) -> None:
        suffix = "//input" if by is By.XPATH else " input"
        tmp_locator = locator + suffix if "input" not in locator else locator
        if (
            self.driver.find_element(by, tmp_locator).get_attribute("data-status")
            == "unchecked"
        ):
            self.driver.find_element(by, locator).click()

    def unselect_if_selected(self, by: str, locator: str) -> None:
        suffix = "//input" if by is By.XPATH else " input"
        tmp_locator = locator + suffix if "input" not in locator else locator
        if (
            self.driver.find_element(by, tmp_locator).get_attribute("data-status")
            == "checked"
        ):
            self.driver.find_element(by, locator).click()

    def hover_on_element(self, locator: tuple[str, str], message: str = "") -> None:
        """
        Simulates mouse hover action on the element represented by the given locator.

        Parameters
        ----------
        locator: tuple[str, str]
            A tuple defining the locator type & actual element locator.
        message: str, optional
            Message to display on timing out (default is empty).
        """
        element: WebElement = self.get_element_when_visible(
            locator, timeout=30, message=message
        )
        self.actions.move_to_element(element).perform()

    def get_label_settings(self) -> dict:
        """
        A method to fetch the details of the Label Settings from /api/users/profile.
        This method will return the value of label settings as a dict.
        """
        settings_data = self.get_data_from_sl_api("/api/users/profile")
        return settings_data["companySettings"]["support"]["custom_names_repo"]

    def get_company_profile_json_data(self) -> dict:
        return self.get_data_from_sl_api("/api/profiles/all")

    def has_sla_enabled(self) -> bool:
        settings_data = self.get_data_from_sl_api("/api/users/profile")
        company_settings = settings_data["companySettings"]["support"]
        return company_settings["service_compliance_settings"]["sla_enabled"]

    def scroll_into_view(self, mark: WebElement | tuple[str, str]) -> None:
        """
        Scrolls the component into the center of the screen

        Parameters
        ----------
        mark: tuple or WebElement
            The actual WebElement (or) a tuple defining the locator type & value that
            represents the WebElement
        """
        element = mark
        if isinstance(mark, tuple):
            element = self.driver.find_element(*mark)
        self.driver.execute_script(
            "arguments[0].scrollIntoView({block: 'center'});", element
        )
