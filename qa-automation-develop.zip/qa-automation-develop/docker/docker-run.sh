#!/usr/bin/env sh

# Let the command given at runtime specify what to run
exec "$@"
