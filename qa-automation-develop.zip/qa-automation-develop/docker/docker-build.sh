#!/usr/bin/env bash

# Run '$ PUSH=true ./docker-build.sh' to push image after building
PUSH=${PUSH:-false}
TAG=${TAG:-latest}
PROJECT=${PROJECT:-kansas-dev-189520}

CUR_DIR=$(basename $(pwd))
BASE_NAME=gcr.io/$PROJECT/qa
IMAGE_NAME=$BASE_NAME:$TAG
if [ $CUR_DIR == 'qa-automation' ]; then
    docker build . -t $IMAGE_NAME
elif [ $CUR_DIR == 'docker' ]; then
    docker build ../. -t $IMAGE_NAME
else
    # Being lazy and just forcing the script to be ran from two possible places.
    echo '*** Error: Do not recognize current working directory. Run script from base `sl` or `sl/deployment/docker`. ***'
    exit 1
fi

BUILD_RESULT=$?
if [ $BUILD_RESULT -ne 0 ]; then
    echo
    echo '*** Error: Failed to build. ***'
    echo
    exit $BUILD_RESULT
fi

IMAGES_TO_PUSH=($IMAGE_NAME)

if [ ! -z "$GITHUB_SHA" ]; then
    SHA_NAME=$BASE_NAME:"$GITHUB_SHA"
    docker image tag $IMAGE_NAME $SHA_NAME
    TAG_RESULT=$?
    if [ $TAG_RESULT -ne 0 ]; then
        echo
        echo '*** Error: Failed to tag with github sha. ***'
        echo
        exit $TAG_RESULT
    fi

    IMAGES_TO_PUSH+=($SHA_NAME)
fi

if [ $PUSH == true ]; then
    for image in ${IMAGES_TO_PUSH[@]}; do
        docker push $image
        PUSH_RESULT=$?
        if [ $PUSH_RESULT -ne 0 ]; then
            echo
            echo "*** Error: Failed to push image: $image. ***"
            echo
            exit $PUSH_RESULT
        fi
    done
fi
