"""This file defines enumerations that are shared across the project"""

from enum import Enum


class UserType(Enum):
    """This is an enumeration where all the values of User Types are stored"""

    ADMIN = 1
    NORMAL = 2
    SL_ADMIN = 3


class NavbarItem(Enum):
    """id attribute values for icons of all the pages in the navbar"""

    CONSOLE = "console"
    CASE_BOARD = "cases"
    ALERTS = "alerts"
    OPS_METRICS = "metrics"
    TRENDS = "trends"
    TOPICS = "topics"
    SENTIMENT = "sentiments"
    AGENTS = "agents"
    VIRTUAL_TEAMS = "virtualTeams"
    CUSTOMER_INSIGHTS = "customerInsights"
    FAVORITES = "customerFavorites"
    VIRTUAL_ACCOUNTS = "virtualAccounts"
    CUSTOMER_BOARD = "customerBoard"
    ESCALATIONS = "escalations"
    CASE_ASSIGNMENT = "caseAssignment"
    CASE_EVALUATION = "caseEvaluation"
    MY_DASHBOARD = "summary"
    MY_CASES_OLD = "myCases"
    MY_CASES_NEW = "agentBacklog"
    SUBSCRIPTIONS = "agentSubscriptions"


class ControlCenterMenuItem(Enum):
    """id attribute values for icons of menu items in the control center"""

    MANAGE_USERS = "manageUsers"
    USER_ENGAGEMENT = "userEngagement"
    SETTINGS = "settings"


class CaseStatusFilter(Enum):
    """partial testid for case status filter options"""

    ALL = "all"
    OPEN = "open"
    CLOSED = "closed"


class SentimentMessageType(Enum):
    """partial testid for Include filter in sentiment page"""

    INCOMING = "isIncoming"
    OUTGOING = "isOutgoing"
    CASE_NOTES = "isCaseNote"


class SentimentGroup(Enum):
    """partial testid for Sentiment filter in sentiment page"""

    NEGATIVE = "negative"
    POSITIVE = "positive"
    FEEDBACK = "product feedback"


class OpsMetricsType(Enum):
    """partial testid values of categories in OpsMetrics page"""

    SLA = "sla"
    EFFICIENCY = "efficiency"
    CUSTOMER_EXP = "customer_experience"


class EscalationState(Enum):
    """partial test id values for containers in Escalation - Kanban view"""

    LTE = "escalationPredictions"
    ESCALATION_REQUESTS = "escalationRequests"
    ACTIVE_ESCALATIONS = "activeEscalations"
    RESOLVED = "resolvedEscalations"
    ACCEPTED = "acknowledgedTickets"
    DISMISSED = "dismissedPredictions"
    SNOOZED = "snoozedPredictions"


class CasePriority(Enum):
    """Possible list of Case Priority values"""

    LOW = "Low"
    MEDIUM = "Medium"
    HIGH = "High"
    URGENT = "Urgent"


class CaseStatus(Enum):
    """Possible list of Case Status values"""

    CLOSED = "Closed"
    ESCALATED = "Escalated"
    IN_PROGRESS = "In Progress"
    NEW = "New"
    PENDING = "Pending"
    RESEARCHING = "Researching"
    SOL_PROPOSED = "Solution Proposed"
    SOL_SANCTIONED = "Solution Sanctioned"


class SlaSubTabs(Enum):
    """partial testid values of sub-tabs in Ops Metrics - SLA section"""

    FIRST_RESP = "first_response"
    FOLLOW_UP = "follow_up"
    CASE_RESOLUTION = "case_resolution"


class EfficiencySubTabs(Enum):
    """partial testid values of sub-tabs in Ops Metrics - Efficiency section"""

    ESCALATIONS = "escalations"
    BACKLOG = "backlog"
    CASE_ACTIVITY = "case_activity"


class ChartTypes(Enum):
    """
    partial testid values of chart types in Add/Edit chart popover of OpsMetrics page
    """

    VERTICAL = "vertical_bar"
    TREND = "trendline"
    DONUT = "pie"
    HORIZONTAL = "horizontal_bar"


class ChartStatusFilter(Enum):
    """Display text of status grouping dropdown options in OpsMetrics page charts"""

    CLOSED = "Closed"
    CREATED = "Created"
    OPEN = "in the Open State"
    ESCALATED = "Escalated"
    ACTIVITY = "with Inbound/Outbound activity"


class GroupByStandardFields(Enum):
    """partial testid values of standard group by options in add/edit chart popover"""

    PRIORITY = "priority"
    STATUS = "status"


class GroupByCustomFields(Enum):
    """partial testid values of custom group by options in add/edit chart popover"""

    PRODUCT = "product"
    RESOLUTION = "resolution"
    SEVERITY = "severity"


class ConsolePageTabs(Enum):
    """partial testid values of console page tabs"""

    NEW_TICKETS = "Tickets"
    NEED_ATTENTION = "Need_attention"
    SERVICE_COMPLIANCE = "Service_Compliance"
    NEGATIVE_SENTIMENTS = "Negative_Sentiments"
    POSITIVE_SENTIMENTS = "Positive_Sentiments"
    ESCALATIONS = "Escalations"


class CaseDistributionBar(Enum):
    """ case distribution tab in New cases --- bar option"""

    ASSIGNED = "Assigned"
    UNASSIGNED = "Unassigned"


class TopicSortByFilter(Enum):
    """ Topic page  sort by option"""

    NUMBER_OF_CASES = "Number of cases"
    PERCENTAGE_CHANGE = "% Change"


class TrendsPageContentTabs(Enum):
    """The sentiments content tab's name present in trends page is listed here"""

    OVERVIEW = "tickets"
    ESCALATIONS = "escalations"
    NEGATIVE_SENTIMENTS = "negative_sentiments"
    ESCALATIONS_REQUEST = "escalation_requests"
    CRITICAL_ISSUE = "critical_issues"
    PRODUCTION_ISSUES = "production_issues"
    POSITIVE_SENTIMENTS = "positive_sentiments"
    PRODUCT_FEEDBACK = "product_feedback"
    CHURN_RISK = "competitive_threats"
    FEATURE_REQUEST = "feature_requests"


class SentimentSignalTrendsButton(Enum):
    """Predefined selections available for sentiment signal button"""

    NO_SIGNAL = "No Signals"
    PARTIAL_SIGNAL = "Partial Signals"
    ALL_SIGNAL = "All Signals"
    INBOUND_SIGNAL = "Inbound Signals"
    OUTBOUND_SIGNAL = "Outbound Signals"


class TrendsGroupByOptions(Enum):
    """partial test id values of group by options in trends page"""

    PRIORITY = "sl_priority"
    PRODUCT = "sl_product_c"
    STATUS = "sl_status"
    PLATFORM = "sl_platform_c"
    OP_SYS = "sl_op_sys_c"
    RESOLUTION = "sl_resolution_c"
    TYPE = "sl_l1_category"
    DELETED = "is_deleted"
    VERSION = "sl_version_c"
    ESCALATED = "sl_is_escalated"
    SEVERITY = "sl_severity_c"
    NPS = "sl_nps_score"
    PROBLEM_TYPE = "problem_type_c"
    CSAT = "sl_csat_score"
    REGION = "sl_region_c"
    GROUP_NAME = "sl_group_name"
    CASE_OWNER = "sl_assignee_name"


class QuarterOptions(Enum):
    """partial test id values of quarter options in the date picker shortcut"""

    FIRST_Q = "q1"
    SECOND_Q = "q2"
    THIRD_Q = "q3"
    FOURTH_Q = "q4"


class AgentManagementTabs(Enum):
    """partial testid values for tabs on agents Management page"""
    CLOSED_CASES = "closed_cases"
    ESCALATIONS = "escalations"
    NEGATIVE_SENTIMENTS = "negative_sentiments"
    POSITIVE_SENTIMENTS = "positive_sentiments"
    ENG_ISSUES = "engineering_issues"
    BACKLOG = "backlog"
    NEED_ATTENTION = "need_attention"


class CustomerManagementTabs(Enum):
    """Tabs on customer Managements page"""
    OVERVIEW = "overview"
    ESCALATION = "escalations"


class CaseAssignmentTabs(Enum):
    """partial test id values of tabs in ICA module"""

    UNASSIGNED = "unassigned"
    ASSIGNED_TODAY = "assigned_today"


class ManageUser(Enum):
    """Tabs on Manage user page"""
    SL_USER = "SL Users"
    USER = "Users"


class ModuleState(Enum):
    ENABLED = True
    DISABLED = False
    LOCKED = None


class VStarType(Enum):
    """partial test id values of V* types in create V* flow"""

    GLOBAL_ORG = "global_org"
    PERSONAL_ORG = "personal_org"
    GLOBAL_TEAM = "global_team"
    PERSONAL_TEAM = "personal_team"
    GLOBAL_GROUP = "global_group"
    PERSONAL_GROUP = "personal_group"
    GLOBAL_ACCOUNT = "global_account"
    PERSONAL_ACCOUNT = "personal_account"


class UserMenuOption(Enum):
    PREFERENCES = "preferences"
    VIEW_AS = "viewAs"
    EDIT_PROFILE = "profileEdit"
    ABOUT_SL = "aboutProduct"
    LOGOUT = "logout"


class SettingsSectionUrlSuffix(Enum):
    SITE_DEFAULTS = "/support/settings/defaults"
    USER_PROFILES = "/support/settings/user_profiles"
    SCOPE = "/support/settings/scope"
    FIELDS = "/support/settings/fields"
    CASE_ASSIGNMENT = "/support/settings/case_assignment"
    TARGET_CASE_METRICS = "/support/settings/target_case_metrics"
    SUPPORT_HUB = "/support/settings/support_hub"
    ALERTS_NOTIFICATIONS = "/support/settings/notifications"
    SENTIMENT_FEED = "/support/settings/sentiment_feed"
    INTEGRATIONS = "/support/settings/integrations"
    MY_CASES = "/support/settings/agent-backlog"
    CONSOLE = "/support/settings/console"
    AGENTS_INSIGHTS = "/support/settings/agents"
    CUSTOMER_INSIGHTS = "/support/settings/customer_insights"
    TRENDS = "/support/settings/trends"
    TOPICS = "/support/settings/topics"
    ALERTS_BUILDER = "/support/settings/alerts"
    ASSIGNMENT_QUEUES = "/support/settings/assignment_queues"
    AUTHENTICATION = "/support/settings/authentication"
    CACHE_SETTINGS = "/support/settings/cache_settings"
    DASHBOARDS = "/support/settings/dashboards"
    DEBUG_SETTINGS = "/support/settings/debug_settings"
    ESCALATIONS = "/support/settings/escalations"
    EVALUATIONS = "/support/settings/evaluations"
    LIVE_UPDATES = "/support/settings/live_updates"
    OPS_METRICS = "/support/settings/metrics"
    PRODUCT_EDITION = "/support/settings/product_edition"
    SENTIMENT = "/support/settings/sentiment"
    SIGNALS_ONTOLOGY = "/support/settings/signals_ontology"
    SWARMING_USER = "/support/settings/swarming_users"
    USER_ENGAGEMENT = "/support/settings/user-engagement"


class LTESortOptions(Enum):
    """Display text for the options in the Likely to Escalate sort by dropdown"""

    OLDEST_CASE = "Oldest case"
    MOST_LTE = "Most likely to escalate"
    MOST_RECENT_RESPONSE = "Most recent response"
    LOWEST_SENTIMENT = "Lowest case sentiment"
    HIGHEST_ATTENTION = "Highest attention needed"


class EscalationRequestsSortOptions(Enum):
    """Display text for the options in the Escalation Requests sort by dropdown"""

    OLDEST_CASE = "Oldest case"
    HIGHEST_PRIORITY = "Highest case priority"
    MOST_RECENT_REQUEST = "Most recent request"
    MOST_RECENT_RESPONSE = "Most recent response"
    LOWEST_SENTIMENT = "Lowest case sentiment"
    HIGHEST_ATTENTION = "Highest attention needed"


class ActiveEscalationsSortOptions(Enum):
    """Display text for the options in the Active Escalations sort by dropdown"""

    OLDEST_CASE = "Oldest case"
    HIGHEST_PRIORITY = "Highest case priority"
    MOST_RECENT_RESPONSE = "Most recent response"
    MOST_RECENT_ESCALATION = "Most recent escalation"
    LOWEST_SENTIMENT = "Lowest case sentiment"
    HIGHEST_ATTENTION = "Highest attention needed"


class ResolvedEscalationsSortOptions(Enum):
    """Display text for the options in the Resolved sort by dropdown"""

    OLDEST_CASE = "Oldest case"
    CLOSED_DATE = "Closed Date"
    LOWEST_SENTIMENT = "Lowest case sentiment"
    HIGHEST_ATTENTION = "Highest attention needed"


class ShiftOccurrence(Enum):
    """partial test id values of weekday elements in Add/Edit shift popup"""

    MON = "m"
    TUE = "t"
    WED = "w"
    THU = "th"
    FRI = "f"
    SAT = "sa"
    SUN = "su"


class DeleteShift(Enum):
    """partial test id values of options elements in Delete shift popup"""

    TODAY = "today"
    TODAY_AND_FOLLOWING = "today_and_following"
    DELETE_ENTIRELY = "delete"
