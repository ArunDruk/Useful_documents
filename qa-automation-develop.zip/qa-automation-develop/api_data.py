import json
from typing import Union

from enums import ModuleState, NavbarItem

product_edition_standard = json.dumps(
    {
        "settings": {
            "product_edition": "PRODUCT_EDITION_STANDARD",
            "product_edition_settings": None,
            "dashboard_restrictions": {
                "pages": {
                    "agentBacklog": False,
                    "agentSubscriptions": False,
                    "agents": False,
                    "alerts": False,
                    "caseAssignment": False,
                    "caseEvaluation": False,
                    "cases": True,
                    "console": True,
                    "customerBoard": False,
                    "customerFavorites": False,
                    "customerInsights": False,
                    "escalations": False,
                    "metrics": True,
                    "myCases": False,
                    "sentiments": True,
                    "summary": True,
                    "topics": True,
                    "trends": True,
                    "virtualAccounts": False,
                    "virtualTeams": False,
                }
            },
        },
        "replace": False,
        "keys": ["product_edition"],
    }
)

product_edition_pro = json.dumps(
    {
        "settings": {
            "product_edition": "PRODUCT_EDITION_PRO",
            "product_edition_settings": None,
            "dashboard_restrictions": {
                "pages": {
                    "agentBacklog": False,
                    "agentSubscriptions": False,
                    "agents": True,
                    "alerts": True,
                    "caseAssignment": True,
                    "caseEvaluation": False,
                    "cases": True,
                    "console": True,
                    "customerBoard": True,
                    "customerFavorites": True,
                    "customerInsights": True,
                    "escalations": True,
                    "metrics": True,
                    "myCases": False,
                    "sentiments": True,
                    "summary": True,
                    "topics": True,
                    "trends": True,
                    "virtualAccounts": True,
                    "virtualTeams": True,
                }
            },
        },
        "replace": False,
        "keys": ["product_edition"],
    }
)

product_edition_enterprise = product_edition_custom = json.dumps(
    {
        "settings": {
            "product_edition": "PRODUCT_EDITION_ENTERPRISE",
            "product_edition_settings": None,
            "dashboard_restrictions": {
                "pages": {
                    "agentBacklog": True,
                    "agentSubscriptions": True,
                    "agents": True,
                    "alerts": True,
                    "caseAssignment": True,
                    "caseEvaluation": True,
                    "cases": True,
                    "console": True,
                    "customerBoard": True,
                    "customerFavorites": True,
                    "customerInsights": True,
                    "escalations": True,
                    "metrics": True,
                    "myCases": True,
                    "sentiments": True,
                    "summary": True,
                    "topics": True,
                    "trends": True,
                    "virtualAccounts": True,
                    "virtualTeams": True,
                }
            },
        },
        "replace": False,
        "keys": ["product_edition"],
    }
)

case_count_by_agent_id = json.dumps(
    {
        "table": "case_summary",
        "column": "sl_assignee_id",
        "operation": "count",
        "target_column": "id",
        "predicates": [{"column": "sl_assignee_id", "op": "not_null"}],
    }
)


def edit_custom_prod_edition_module_state(module: dict[NavbarItem, ModuleState]):
    pages = {module_name.value: state.value for module_name, state in module.items()}
    requests_body = {
        "settings": {
            "product_edition": "PRODUCT_EDITION_CUSTOM",
            "product_edition_settings": None,
            "dashboard_restrictions": {
                "pages": pages
            },
        },
        "replace": False,
        "keys": ["product_edition"],
    }
    return json.dumps(requests_body)


def customer_search(with_least_cases: bool = False):
    sort_direction = "desc" if not with_least_cases else "asc"
    request_body = {
        "selected": ["name"],
        "predicates": [{"column": "cases_total_num", "op": ">=", "value": "1"}],
        "ordering": [{"column": "cases_total_num", "direction": sort_direction}],
        "record_types": ["individual_account"],
    }
    return json.dumps(request_body)


def agent_search(agent_ids: list[str]):
    request_body = {
        "user_ids": {"ids": agent_ids},
        "selected": [
            "id",
            "s_id",
            "sl_name",
            "sl_email",
            "sl_active_hours_predicted",
            "sl_created_at",
            "sl_user_is_valid_assignee",
        ],
        "ordering": [],
    }
    return json.dumps(request_body)


def case_summary(case_ids: Union[str, list[str]]):
    case_ids = "|".join(case_ids) if isinstance(case_ids, list) else case_ids
    request_body = {
        "selected": [
            "id",
            "sl_case_id",
            "sl_priority",
            "sl_status",
            "sl_assignee_id",
            "sl_assignee_name",
            "sl_account_id",
            "sl_account_name",
            "sl_requester_name",
            "sl_requester_id",
            "sl_requester_email",
            "sl_created_at",
            "sl_open_time_ms",
            "sl_engineering_issues",
            "sl_last_outbound_ms",
            "sl_escalated_at_last",
            "sl_is_closed",
            "sl_closed_at",
            "sl_most_recent_comment",
            "sl_most_recent_comment_is_ib",
            "sl_most_recent_inbound",
            "sl_most_recent_outbound",
            "sl_is_predicted_to_escalate",
            "sl_custom_fields"
        ],
        "predicates": [
            {
                "column": "sl_case_id",
                "op": "in",
                "value": case_ids
            }
        ],
        "ordering": [
            {
                "column": "id",
                "direction": "asc"
            }
        ]
    }
    return json.dumps(request_body)
