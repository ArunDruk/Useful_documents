"""This module contains all the constant variables that are used across the entire
codebase"""
__copyright__ = "Copyright (C) 2021 SupportLogic"

from typing import Any, Dict, List

import pytest

version_test_run: str = "2.3"

# Specify the name of the browsers against which the tests should be executed
browser_names: str = "chrome"

# The URL of the product instance where the tests will be performed by default. To
# execute the tests in a different instance, say DOS, override this value by setting
# the environment variable 'SL_URL'.
default_url: str = "https://foundry.supportlogic.io/"

# timeout used in global wait object definition
EXPLICIT_WAIT_TIME = 15

# Title of all pages
title_of_va: str = "SupportLogic - Virtual Accounts"

# Expected Url of all pages
url_expectations: Dict[str, str] = {
    "expected_url_va": "support/virtual-accounts",
    "expected_url_console_page": "support/console",
    "expected_url_cases_board_page": "support/cases",
    "expected_url_alerts_page": "support/alerts",
    "expected_url_operational_metrics_page": "support/metrics",
    "expected_url_trends_page": "support/trends",
    "expected_url_topics_page": "support/topics",
    "expected_url_sentiments_page": "support/sentiment",
    "expected_url_agents_favourites_page": "support/agents/favorites",
    "expected_url_agents_virtual_teams_page": "support/virtual-teams",
    "expected_url_customer_insight_page": "support/customer-insights",
    "expected_url_customer_favourites_page": "support/favorite-customers",
    "expected_url_escalations_page": "support/escalations",
    "expected_url_case_assignment_page": "support/case-assignment",
    "expected_url_settings_authentications_page": "support/settings/authentication",
    "expected_url_settings_dashboard_page": "support/settings/dashboards",
}

home_page_url: List[str] = ["https://foundry.supportlogic.io/support/agents/search"]

# Location to save the execution results for each instance.
report_dir: str = ""

# A common run id for each session. The value is set when a new test run id is generated
run_id: str = ""

# Iterator is used to overcome name duplicating error for batch run.
iterator: int = 1

# Prefix for new VA names
VA_GLOBAL_RUN_ID_PREFIX: str = "VA Global"
VT_GLOBAL_RUN_ID_PREFIX: str = "VT Global"
CUSTOMER_BOARD_RUN_ID_PREFIX ="QA_CB"
ALERTS_NAME_RUN_ID_PREFIX ="QA_AL"
DASH_BOARD_RUN_ID_PREFIX ="QA_DB"

# Prefix for a new case list
case_board_list_name_prefix: str = "NEW_CASE_LIST"

# A random number to select a sentiment tile from the heatwave plot in sentiments page
random_sentiment_tile_index: int = 1

"""markers shortcuts"""

# Pytest marker for test authored by praveen nagajothi
author_praveen_nj: Any = pytest.mark.praveen_nj

# Pytest marker for test authored by gary murry
author_gary_murry: Any = pytest.mark.gary_murry

# Pytest marker for test authored by neha jha
author_neha_jha: Any = pytest.mark.neha_jha

# Pytest marker for test authored by jacob mathew
author_jake_mat: Any = pytest.mark.jake_mat

# Pytest marker for test authored by sutapa ganguly
author_sutapa_g: Any = pytest.mark.sutapa_g

# Pytest marker for test authored by vignesh k
author_vignesh_k: Any = pytest.mark.vignesh_k

# Pytest marker for test authored by nalini govindaraj
author_nalini_govindaraj: Any = pytest.mark.nalini_govindaraj

# Pytest marker to mark sanity tests
sanity_test: Any = pytest.mark.sanity

# Pytest marker to mark regression tests
regression_test: Any = pytest.mark.regression

# Pytest marker to skip tests
skip_test: Any = pytest.mark.skip

# Pytest marker for tests that can only be ran for SLAdmins
sl_admin_users_test: Any = pytest.mark.sl_admin_users

# Pytest marker for tests that can only be ran for admins
admin_users_test: Any = pytest.mark.admin_users

# Pytest marker for tests that can only be ran for normal users (Everyone)
normal_users_test: Any = pytest.mark.normal_users

# Pytest marker for tests that can only be ran for swarm users
swarm_users_test: Any = pytest.mark.swarm_users

# Pytest marker for tests that depends on the SFDC user account
sfdc_test: Any = pytest.mark.sfdc
