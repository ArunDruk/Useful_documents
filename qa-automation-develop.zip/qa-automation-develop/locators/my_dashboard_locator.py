"""This module contains the locators which are used in My dash board"""




no_of_case_list_present_on_dashboard ="//div[contains(@class,'styles__Container-sc-19pmpbf-0')]"


no_of_case_tile_present_on_dashboard="//div[contains(@class,'styles__Container-sc-de3xw8-0')]"
vertical_dots_of_case_list= "//div[contains(text(),'TEXT_PLACEHOLDER')]//preceding-sibling::div//div[contains(@class,'ContextMenu__Trigger-sc-1dzej2g-3')]"
delete_case_list="//div[contains(@class,'ContextMenu__Popup-sc-1dzej2g-4 jxJqpP')]//div[@mode='delete']"
case_list_in_dashboard="(//div[@class='sharedStyles__Card-sc-101gp8h-0 styles__Container-sc-19pmpbf-0 fBTGRF'])[1]"
edit_case_list="(//div[contains(@class,'jxJqpP')]//div[contains(@class,'styles__CardMenuItem-sc-1g3itd-5')])[1]"
about_to_miss_sla_in_add_case_list="//div[contains(@class,'styles__OptionsItemContent')]//strong[text()='about to miss SLA']"
welcome_page_title="//div[contains(@class,'styles__Title-sc-djup1-3')]"
first_virtual_team_present_on_welcome_page="(//div[contains(@class,'styles__TeamsListIte')])[1]"
second_virtual_team_present_on_welcome_page="(//div[contains(@class,'styles__TeamsListIte')])[2]"
vt_team_selected="//div[contains(@class,'sharedStyles__Card-sc-101gp8h-0 styles__Container-sc-bvn9n7-0')]"
first_case_id_in_case_list="((//div[contains(@class,'sharedStyles__Card-sc-101gp8h-0 styles__Container-sc-19pmpbf-0 ')])[1]//span[@class='FCz2-LucAE1GSFNYvw4l3'])[1]"
first_case="((//div[contains(@class,'sharedStyles__Card-sc-101gp8h-0 styles__Container-sc-19pmpbf-0 ')])[1]//div[@class='_3nzVHYtOBTMKLieWFF6Uxa'])[1]"
case_id_on_support_hub="//div[@data-testid='supportHub-caseHeader-caseNumber']"
ticket_in_case_tile="(//div[contains(@class,'styles__CasesNumber-sc-144g1b7-1')])[1]"
first_case_id_on_case_tile="(//span[@class='tkgV1mpPEVHhmgRJ57NVY'])[1]"
case_tile_first_case="(//div[@class='ReactVirtualized__Grid__innerScrollContainer']//div[@class='_3Pw7LpevE3FUAW7arCQak2'])[1]"
virtual_team_vertical_dots="(//div[contains(@class,'ContextMenu__Trigger-sc-1dzej2g-3')])[1]"
edit_team="//div[text()='Edit team']"
list_of_virtual_team="//div[contains(@class,'styles__TeamsListItem-sc-djup1-7')]"
save_button="//div[text()='Save']"
virtual_team_name_in_my_dashboard="//div[contains(@class,'styles__Name-sc-bvn9n7-1')]"
virtual_team_name_which_is_highlighted="//div[@class='styles__TeamsListItem-sc-djup1-7 gDfpLn']//div//div[@class='_1RZFLstJ_MSq2-Riva77G6']"
name_in_edit_list="//input[contains(@class,'CardName__Input')]"
first_list_name="//div[contains(text(),'TEXT_PLACEHOLDER')]"

number_of_case_list = '//div[contains(@class,"styles__CardContainer-sc-1g3itd-2") and position()>1]//div[contains(@class,"sharedStyles__CardName")]'

# dashboard
agents_name_in_dashboard = "//div[contains(@class,'styles__AgentsList')]//div[contains(@class,'styles__Name')]"
click_on_agent_link_near_agent_name = "//a[contains(@class,'styles__AgentLink')]"
get_first_agents_case_number_in_dashboard_page = "//div[contains(@class,'styles__CasesNumber')][1]"

# tile and list add card pop up
plus_button ="//div[@data-testid='caseBoard--floating-action-button']"
next_button="//div[text()='Next']"
negative_sentiments_in_add_case_list ="//div[contains(@class,'styles__OptionsItemContent')]//strong[text()='Negative Sentiments']"
add_button="//div[text()='Add']"
case_list="//div[@data-testid='myDashBoard-createCard-case_list-cardItem']"
case_tile="//div[@data-testid='myDashBoard-createCard-tile-cardItem']"
first_option_in_case_tile = "(//span[@class='zsSyTBFa6nAteYLqTrPTS'])[1]"
case_list_name_input= case_tile_name_input = '//input[@placeholder="Enter name" or contains(@class,"CardName__Input")]'
cross_button_on_add_card_pop_up="//div[contains(@class,'sharedStyles__CloseButtonWrapper')]"
cancel_button = "//div[text()='Cancel']"
back_button = "//button[@data-testid='myDashboard-createCardModal-caseListEditor-backBtn']"