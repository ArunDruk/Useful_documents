"""This page has the locators for all the elements in the navbar"""

# css-selectors
navbar_visibility_toggle_css = "div[data-testid=layout-navigation-toggle]"
navbar_item_css = "a[data-testid=layout-navigation-module-item--{page_name}]"

control_center_button_css = "div[data-testid='layout-navigation-control-center']"
control_center_item_css = "a[data-testid=layout-navigation-control-center--{name}]"
