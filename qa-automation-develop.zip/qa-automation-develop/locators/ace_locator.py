"""This module contains the locators which are used in ACE locator"""


add_note_icon = "//button[@class='styles__Button-ut5osz-0 KUuQh']"
id_of_first_case_in_list = "(//span[text()='Recommended for review']//ancestor::div[contains(@class,'CollapsibleSidebar')]//following-sibling::div[contains(@class,'ACESidebar')]//span[contains(@class,'styles__CaseId')])[1]"
search_bar = "//input[@placeholder='Search case number' or @class='SearchInput__Input-g6h43n-1 ghHwMY']"


edit_icon_notes = "(//div/*[name()='svg' and @data-icon='edit-light' and @class='imio8ohrteDaFCBvsS0TY'])[1]"
filter_drop_down = "//div[@class='FilterContainer__Menu-sc-9jctqg-0 eohwfk']"
first_interaction_in_list = (
    "(//div[@class='CaseInteractions__ListItemHeader-sc-1qflx2p-6 nbnPw'])[1]"
)
first_interaction_first_sub_item = (
    "(//div[@class='CaseInteractions__ListItemSubItem-sc-1qflx2p-8 KGKnw'])[1]"
)
interaction_in_green = "(//mark[@class='shared__Mark-jubz95-11 gpOycF'])[1]"
disagree_with_label = "//span[text()='Disagree with this label']"
interaction_underline_in_green = "//mark[@class='shared__Mark-jubz95-11 fOdEcj' and @data-interaction='TEXT_PLACEHOLDER']"
remove_feedback = "//span[text()='Remove feedback']"
interaction_disagree_and_remove_feedback_pop_up = (
    "//div[@class='InteractionPreviewPopup__Container-iimlx7-0 kOZqfc']"
)
interaction_green_color = "//mark[@class='shared__Mark-jubz95-11 gpOycF' and @data-interaction='TEXT_PLACEHOLDER']"
undo_button = "//span[text()='Undo']"


recommended_for_review_case_list = "//span[text()='Recommended for review']//ancestor::div[contains(@class,'CollapsibleSidebar__Container')]//div[contains(@class,'styles__Container-sc-1o3v1sd-5')]"
csv_in_recently_reviewed = (
    "//div[@class='CollapsibleSidebar__ActionWrapper-sc-18f6ple-1 gXNDkl']"
)
recently_review_cases = "(//span[text()='Recently reviewed']//ancestor::div[contains(@class,'CollapsibleSidebar__Container')]//span)[2]"
recommended_for_review_case = "(//span[text()='Recommended for review']//ancestor::div[contains(@class,'CollapsibleSidebar__Container')]//span)[2]"
group_by_filter_in_recently_reviewed = (
    "//div[contains(@class,'ACEReviewList__HeaderDropdownContaine')]//span"
)
time_option_in_group_by_filter_in_recently_review = (
    "//div[@data-testid='caseEvaluation-sideBar-review_list-dropdown-option-Time']"
)
filter_drop_down ="//div[@class='FilterContainer__Menu-sc-9jctqg-0 eohwfk']"
first_interaction_in_list ="(//div[@class='CaseInteractions__ListItemHeader-sc-1qflx2p-6 nbnPw'])[1]"
first_interaction_first_sub_item ="(//div[@class='CaseInteractions__ListItemSubItem-sc-1qflx2p-8 KGKnw'])[1]"
interaction_in_green="(//mark[@class='shared__Mark-jubz95-11 gpOycF'])[1]"
disagree_with_label="//span[text()='Disagree with this label']"
interaction_underline_in_green="//mark[@class='shared__Mark-jubz95-11 fOdEcj' and @data-interaction='TEXT_PLACEHOLDER']"
remove_feedback ="//span[text()='Remove feedback']"
interaction_disagree_and_remove_feedback_pop_up="//div[@class='InteractionPreviewPopup__Container-iimlx7-0 kOZqfc']"
interaction_green_color="//mark[@class='shared__Mark-jubz95-11 gpOycF' and @data-interaction='TEXT_PLACEHOLDER']"
undo_button="//span[text()='Undo']"
recommended_for_review_case_list = "//div[contains(@data-testid,'caseEvaluation-list-container-recommended')]"
csv_in_recently_reviewed ="//div[@class='CollapsibleSidebar__ActionWrapper-sc-18f6ple-1 gXNDkl']"
recently_review_cases ="(//div[@data-testid='caseEvaluation-collapsibleSidebar-title-Recently_reviewed']//following::div[contains(@class,'CalendarFilter__CalendarWrapper')]//span)[1]"
recommended_for_review_case="(//div[@data-testid='caseEvaluation-collapsibleSidebar-title-Recommended']//following::div[contains(@class,'CalendarFilter__CalendarWrapper')]//span)[1]"
group_by_filter_in_recently_reviewed ="//div[contains(@class,'ACEReviewList__HeaderDropdownContaine')]//span"
time_option_in_group_by_filter_in_recently_review ="//div[@data-testid='caseEvaluation-sideBar-review_list-dropdown-option-Time']"
agent_option_in_group_by_filter_in_recently_review = "//div[@data-testid='caseEvaluation-sideBar-review_list-dropdown-option-_agent_capitalize_']"
agent_name_on_group_by = "(//span[text()='Recently reviewed']//ancestor::div[contains(@class,'CollapsibleSidebar__Container')]//div[contains(@class,'CaseListBase__GroupHeader-sc')]//span)[1]"
first_case_in_recently_reviewed = "//span[text()='Recently reviewed']//ancestor::div[contains(@class,'CollapsibleSidebar__Container')]//div[contains(@class,'styles__Container-sc-1o3v1sd-5')]"

tab_names = "//div[contains(@data-testid,'caseEvaluation-collapsibleSidebar')]"
case_list_container_in_view = "//div[contains(@class,'hWZOkc')]"
case_list_container_is_collapse_view ="//div[contains(@class,'jNzdlh')]"
tab_names = "//div[contains(@class, 'CollapsibleSidebar__Header-sc-18f6ple-3')]"
case_list_container_in_view = "//div[contains(@class,'gsaLAP')]"
case_list_container_is_collapse_view = "//div[contains(@class,'iesBfK')]"

# ace 1.o

start_review_button_xpath ="//button[@data-testid='ace__caseReviewContainer__startReview']"
categories_section_expand_collapse_state ="//div[text()='Categories']//small"
categories_header = "//div[contains(@class,'shared__CategoryHeader')]"
check_for_categories_collapse_state = "//div[contains(@class,'shared__CategoryHeader')]//div[text()='Not reviewed']"
click_on_first_categories_header = "//div[contains(@class,'shared__CategoryHeader')]//div[1]"
agent_filter_in_ace = "//div[contains(@class,'AgentFilterWrapper')]"
welcome_page_text_element = "#app_wrapper div[class*=__Description]"

#ACE Checklist page
#Below locators are related to features in ACE KANBAN View
edit_evaluation_criteria = "//div[@class='PageLayoutContainer__SettingsButton-sc-aglg47-2 beCDWd']"
first_case = "//div[@class='styles__Container-sc-1qttj1b-6 fCHNRR CaseListBase__CaseItemSHWrapper-sc-1c0cr6p-0 cGydRQ'][1]"

#Tab is ace checklist page
current_tab="//div[@class='TabNav__Item-sc-3oljxm-1 cppovT' and contains(text(),'Current')]"
draft_tab="//div[@class='TabNav__Item-sc-3oljxm-1 cppovT' and contains(text(),'Drafts')]"
previous_version_tab="//div[@class='TabNav__Item-sc-3oljxm-1 cppovT' and contains(text(),'Previous Versions')]"
back_to_evaluation="//div[@class='BoardSettingsPage__BackButton-sc-qnfz6f-0 hcRUDQ']" #and contains(text(),'Back to Evaluations')]"
checklist_header = "//h1[@class='BoardSettingsPage__Title-sc-qnfz6f-2 gaHgLd' and contains(text(),'Evaluation Checklist')]"

#elements is current tab
currenttab_edit_button = "//button[@class='Button-sc-1gpil4u-0 jEuWyQ btn btn-default' and contains(text(),'Edit')]"
currenttab_duplicate_button = "//button[@class='Button-sc-1gpil4u-0 jEuWyQ btn btn-default' and contains(text(),'Duplicate')]"
currenttab_createnew_button = "//button[@class='Button-sc-1gpil4u-0 jEuWyQ btn btn-default' and contains(text(),'Create new')]"
first_category_name="//div[@class='shared__CategoryHeader-sc-1moi1co-16 jknLjB' and contains(string(),'testing_category')]"
first_item_first_category="//div[@class='shared__ChecklistItemHeader-sc-1moi1co-14 bsEmIw' and contains(text(),'testing_item_1')]"
first_description_first_item_first_category="//div[@class='shared__ChecklistItemSubHeader-sc-1moi1co-15 jOMMYd' and contains(text(),'testing description')] "

#Draft Page
draft_message = "//div[@class ='ModalMessage__Message-sc-wz6xmz-1 ktYnLO' and contains(text(),'A new evaluation checklist has been created in Drafts.')]"
gotodraft_button = "//button[@class = 'Button-sc-1gpil4u-0 jEuWyQ btn btn-default' and contains(text(),'Go to Drafts')]"
recentdraft = "//div[@class ='ReviewTemplateListItem__Description-sc-54sngm-2 ctlOMl'] // time[contains(text(),'a few seconds')]"
latest_draft ="//div[@class='ReviewTemplateListItem__Container-sc-54sngm-0 cUeXYW'][1]"
threescale = "//button[@data-testid='ace__reviewTemplateEditor__ratingControl__3']"
fivescale = "//button[@data-testid='ace__reviewTemplateEditor__ratingControl__5']"
fivescale_selected="//button[@class='styles__Button-sc-2l9d00-1 jucTqM' and  contains(text(),'5-scale')]"
threescale_selected="//button[@class='styles__Button-sc-2l9d00-1 jucTqM' and  contains(text(),'3-scale')]"
draftedit_button = "//button[@class='Button-sc-1gpil4u-0 jEuWyQ btn btn-default' and contains(text(),'Edit')]"
draftdelete_button = "//button[@class='Button-sc-1gpil4u-0 jEuWyQ btn btn-default' and contains(text(),'Delete')]"
newcategory = "//div[@class='CircularIconButton__CircularButton-sc-1fnvbht-0 cPpQfr']"
category_placeholder = "//input[@class='shared__SubtleInput-sc-1moi1co-0 bEbJol' and @placeholder='Define a category by which you are evaluating the case']"
category_field_text = (
    "//input[contains(@placeholder,'Define a category by which you are evaluating the')]"
)
item_placeholder = "//input[@class='ChecklistItem__Input-sc-yuofb3-3 icvuAP' and @placeholder='Enter an evaluation criterion that represents this category']"
description_placeholder = "//textarea[@class='ChecklistItem__Textarea-sc-yuofb3-4 bynklo' and @placeholder='Criterion description (optional)']"
add_button = "//button[@class='Button-sc-1gpil4u-0 jRAfsj btn btn-default' and contains(text(),'Add')]"
finish_editing ="//button[@class='Button-sc-1gpil4u-0 jRAfsj btn btn-default' and contains(text(),'Finish editing')]"
publish = "//button[@class='Button-sc-1gpil4u-0 jRAfsj btn btn-default' and contains(text(),'Publish')]"
publish_message_first_line = "//div[@class ='ModalMessage__Message-sc-wz6xmz-1 ktYnLO']//strong[contains(text(),'This checklist will replace the current one')]"
publish_message_second_line ="//div[@class ='ModalMessage__Message-sc-wz6xmz-1 ktYnLO' and contains(text(),'Are you sure you want to publish this')]"
publish_cancel = "//button[@class='Button-sc-1gpil4u-0 fWNbLT btn btn-default' and contains(text(),'Cancel')]"
publish_ok = "//div[@class='_3XF84LfNUleGY_nIXUoivF']//button[@class='Button-sc-1gpil4u-0 jRAfsj btn btn-default' and contains(text(),'Publish')]"

#Below locators are related to ratings
poor_rating = "//div[@data-testid='supportHub-caseComment-caseReview-rating-Poor']"
bad_rating = "//div[@data-testid='supportHub-caseComment-caseReview-rating-Bad']"
neutral_rating = "//div[@data-testid='supportHub-caseComment-caseReview-rating-Neutral']"
good_rating = "//div[@data-testid='supportHub-caseComment-caseReview-rating-Good']"
great_rating="//div[@data-testid='supportHub-caseComment-caseReview-rating-Great']"

#locators in support hub
start_review="//button[@class='styles__Button-sc-ut5osz-0 gTwnTo']//span[contains(text(),'Start review')]"
new_support_hub="//button[@class='styles__PrimaryButton-sc-1rjloyi-7 gZKHFa' and contains(text(),'go')]"




cancel_button_checklist = "//button[.='Cancel']"
cancel_button_editor = "//button[@data-testid = 'ace__reviewTemplateEditor__cancel']"
items_present_in_checklist = (
    "//div[@class='CategoryItem__CategoryNameWrapper-sc-3tfupc-0 layjTY']"
)
