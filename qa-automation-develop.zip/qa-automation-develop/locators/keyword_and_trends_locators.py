"""This page has the locators for elements in the keywords and trends page"""

# css selectors
search_box_css = "div#trends--search--select"
search_box_placeholder_css = search_box_css + " div.Select__placeholder"
search_box_input_field_css = search_box_css + " input"
search_box_pills_css = search_box_css + " span.LIPM3ArT7-KMYFUhU8QlO"
clear_search_box_css = search_box_css + " div.Select__clear-indicator"
applied_search_condition_css = "div._2TeCYjJIp0Zjt9WBOZkYIc span.LIPM3ArT7-KMYFUhU8QlO"

group_by_dropdown_css = "div[data-testid=trends--group-by--popup-trigger]"
group_by_options_css = "div[data-testid=trends--group-by--option--{option}]"

displayed_case_count_css = "[class^=HeaderKPI__Count]"

graph_previous_date_period_arrow_css = "div[data-testid=trends--previous-date-period]"
graph_next_date_period_arrow_css = "div[data-testid=trends--next-date-period]"

graph_title_text_css = "._202NwhYCRrIwWrZ8ZQQ65i"
main_graph_plot_css = "div._2ptiOTeQql7DIY1ghgk0g5 rect.highcharts-plot-background"
graph_menu_css = "div._1L-c6DpFjdsDE5PA_WbmoH"

graph_menu_export_button_css = "[data-testid='Trends by Status--exporter--export-btn']"
graph_menu_export_as_csv_css = "[data-testid='Trends by Status--exporter--option--csv']"
graph_menu_export_as_csv_checkbox_css = "[data-testid='Trends by Status--exporter--option--csv'] input"
graph_menu_export_as_image_css = "[data-testid='Trends by Status--exporter--option--image']"
graph_menu_export_as_image_checkbox_css = "[data-testid='Trends by Status--exporter--option--image'] input"

floating_draggable_graph_details_css = "div._2WiBleGly_mNDDeLOa9WWK"
floating_draggable_graph_title_css = (
    floating_draggable_graph_details_css + " div._1WIsS4NHD6FricMmEjQ_au"
)
graph_tooltip_date_text_css = (
    "div._2ptiOTeQql7DIY1ghgk0g5 div.highcharts-tooltip span._1XAtSj1F2jtHqZAyAxV5BF"
)
graph_tooltip_stats_css = (
    "div._2ptiOTeQql7DIY1ghgk0g5 div.highcharts-tooltip span li._2QY1grJHMYJHA2xpXahOF3"
)
graph_xaxis_labels_css = "div._2ptiOTeQql7DIY1ghgk0g5 g.highcharts-xaxis-labels"

tab_titles_css = "div.Jo50CEQzmsbmvWQBsOT6g"
tab_cards_css = "div[data-testid=trends--tabs--option--{tab_name}]"
left_tab_slider_css = "div[data-testid=trends--tabs--slide-to-left]"
right_tab_slider_css = "div[data-testid=trends--tabs--slide-to-right]"

top_entities_barchart_points_css = "div._2Mk3blLJGUCEeVaXHtIBUD rect.highcharts-point"
top_entities_barchart_count_css = (
    "div._2Mk3blLJGUCEeVaXHtIBUD g.highcharts-bar-series tspan"
)

pie_chart_css = "g.highcharts-pie-series > path[fill^='#']"
pie_chart_tooltip_css = "div.hc-custom-tickets-tooltip"
tickets_popup_css = "div.ticketsPopup"
tickets_card_in_popup_css = tickets_popup_css + " div._34NUNh8mCMqJna1x_qVylf"
ticket_id_css = tickets_card_in_popup_css + " span.tkgV1mpPEVHhmgRJ57NVY"

sentiment_cards_css = "div._3njG1BDdHEnpln0mk1rWzx"
sentiment_cards_case_id_css = sentiment_cards_css + " span._2SYhC0rfnKSZPbRvSyQrm6"

# xpath

search_using_and = "//div[contains(text(), 'all')]/parent::div"
search_using_or = "//div[contains(text(), 'any')]/parent::div"

top_entities_data = (
    "//span[text()='Top Entities']/ancestor::div[@class='_2Mk3blLJGUCEeVaXHtIBUD']"
)
""" This is the locator file for trends page """
# Identify the trends page and traverse
page_click = "//div[@href='/support/trends']"

# content tab locator:
content_tabs = "//div[@data-testid='trends--tabs--option--{tab_name}']"

# No tickets in the filter:
no_filter_msg = "//div[@class='IuKjSdpagbN3w5tV-ozyX']"

# Sentiment signal button
signal_btn = "//span[@class='_1uJjPXc9lp4GNPnwNqzVzM']::before"

# Tickets cards for sentiment tabs:
tickets_cards = "(//div[@class='P_yEIZmr9pYDpVboY_wqV'])[1]"

# Graphs in overview tabs
graph_list = "//div[@class='_1iM937TLXw4xP-8MbHnvyv']"
graph_list_h3 = "//div[@class='_1iM937TLXw4xP-8MbHnvyv']//following::h3[@class='_2MBgHENFDBuDZ7DpFHTfxu']"

tab_case_count="(//div[@data-testid='trends--tabs--option--{tab_name}']//div[@class='_1R1GcUEMG9JoeCQpOq6ab3']//div)[2]"