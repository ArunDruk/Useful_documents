click_on_dynamic_filter = (
    "//div[@data-testid='filters-dynamicFilters-addAFilter']"
)
dynamic_filter = "//div[@data-testid='common-popupFilter-btn']"
add_dynamic_filter = "//button[contains(text(),'Add dynamic filter')]"
selected_option_dynamic = (
    "//span[@class ='_3PymLU5_Vx6ciR3fPM3gjG' or contains(text(),'Category Testings')]"
)

option_selected_dynamic = (
    "//span[contains(@data-testid,'global-filter--selected')]"
)

apply_filter = "//div[@data-testid='dynamicFilter--apply']"
scope_apply_filter ="//button[@data-testid='filters-scoreFilters-searchOptionFilter-applyFilterBtn']"
quick_filter = "//div[@data-testid='filters-scoreFilters-quickFilterBtn']"
global_filter = "//div[@data-testid='layout-header-filter-toggle']"
global_filter_dropdown = "//div[@class=`styles__StyledDropdown-x2wtp3-3 dfKksO`]"

filter_from_global_dropdown = "//span[contains(text(), 'eventName')]"

apply_filter_global = "//button[contains(text(),'Apply filter')]"

dynamic_filter_pop_up = "//div[@class='_3XF84LfNUleGY_nIXUoivF']"
dynamic_selected_pop_up = "//div[@class='_2peDW6KSyVRuwvr8LwuEUV']"

deselect_dynamic_filter = (
    "div.styles__StyledFiltersDropWrapper-sc-38d0do-20"
)

deselect_dynamic_filter_applied = "//span[contains(@data-testid,'clear')]"
dynamic = "//div[@data-testid='common-popupFilter-btn']"
save_button = "//button[text()='Save']"


tool_tip_display = (
    "//div[@data-popper-placement='bottom-end']//div[@class='styles__Container-sc-1nosxfb-0 "
    "byfmbG']//div[@data-list-wrapper='true' and @class='styles__ListWrapper-sc-1nosxfb-1 igOHCY'] "
)

priority = "//label[@data-testid='dynamicFilter--sl_priority--label']"
scope_filters_drop_down = "//div[contains(@class,'styles__StyledDropdown')]"
first_agents = (
    "(//span[contains(@class,'VirtEntityOptionItem__Label')])[1]"
)
search_global_filter = (
    "//input[contains(@placeholder,'Search out of')]")

checkbox_agents_filter = (
    "//span[text()='agents']/../preceding-sibling::div"
)
agents_filter = "_1fhJ1aWrCaIE7EG9bGKOxm"
checkbox_customer_filter = (
    "//span[text()='customer']/../preceding-sibling::div"
)
selected_content_close_btn_client = (
    "//div[@data-testid='global-filter--selected--sl_account_id--clear']"
)
selected_content_close_btn_agent = (
    "//div[@data-testid='global-filter--selected--sl_assignee_id--clear']"
)
checked_agent_btn = (
    "//span[text()='agents']/../preceding-sibling::div/label/input"
)
checked_client_btn = ("//span[text()='Customers']/../preceding-sibling::div/label/input"

)
agents_name_in_filters = "(//span[contains(@class,'styles__QuickFilterItemLabel')])[2]//span[1]"
customer_name_in_filters ="(//span[contains(@class,'styles__QuickFilterItemLabel')])[1]//span[1]"
case_field_name_in_filters ="(//span[contains(@class,'styles__QuickFilterItemLabel')])[3]//span[1]"
selected_display = "//div[contains(@data-testid,'global-filter--selected')]"
check_of_filter_option_present ="//ul[contains(@class,'QtQ7g5vBYAhcu6kusPngi')]//li[1]//span//following-sibling::span[@class='_394LIe4fu4bC0T-vIzKq-0']"
click_on_first_option_in_filters = "//ul[contains(@class,'QtQ7g5vBYAhcu6kusPngi')]//li[1]//span"
add_a_filter ="//span[text()='Add a filter']"

fav_tab_in_customer_filter ="//div[text()='Favorites' and @aria-expanded='false']"
client_name_in_fav_tab_in_customer_filter ="//div[contains(@class,'VirtEntityOptionItem__LabelWrapper')]"

qa_account ="//a[@data-testid='layout-header-userMenu']//span//div"
preferences_tab = "//a[@data-testid='layout-header-userMenu-preferences']"
fav_client_in_preferences_tab ="//div[@class='_1d7NYyBOyjeB4ZP18qcSgx']"
first_client_in_client_filter_fav ="(//input[contains(@data-testid,'animated-checkbox')])[1]"
#case field
apply_scope_in_case_field ="//button[@data-testid='filters-caseField-scoreFilters-Apply_scope-btn']"
click_on_case_field = check_for_case_field_name ="//div[text()='text_placehoder']"
click_on_select_all_button_in_age ="(//span[text()='Select all'])[1]"
to_check_age_is_expand ="//button[contains(@class,' LIxWkpr6AVc1nGkxGY0nQ')]/following::div[text()='Age']"
reset_all_button = "//button[@data-testid='filters-caseField-scoreFilters-resetBtn']"
close_icon_in_preference ="//button[@class='_1mUbl7I6JjBr1-3t4HOTEp']"
select_first_option_on_expand_case_field_section ="(//li[@class='_23-a7Gwp0if9YyKNngGAIS'])[1]//span"
