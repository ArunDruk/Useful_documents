"""This module contains the locators which are used in console page automation"""
# console page locators:
console_section_dashboard = "//div[@id='console']"
click_on_time_filter = "//div[@data-testid='consolePage-filters-timeFilter']"
filter_select = "//span[text()='TEXT_PLACEHOLDER']"
scope_filters_list_of_elements = "//div[@class='_3I8kxV4hbpLxQ4ueLqTZLA']"
new_case_card = "//div[@class='_2iZgxhizf0zdsOr4nLNKcj _2HBuOfHRm957zNrifp7O3C _23xKhlmtznNUAD9jL3zWq1']//div[@class='Eo1MQ4Q8VE4QKAMGAVmji']"
positive_sentiment_cards_validation = "//div[@data-testid='consolePage-tabsSlider-tab-Positive_Sentiments']//div[@class='Eo1MQ4Q8VE4QKAMGAVmji']"
negative_sentiment_card_validation = "//div[@data-testid='consolePage-tabsSlider-tab-Negative_Sentiments']//div[@class='Eo1MQ4Q8VE4QKAMGAVmji']"
any_case_in_unassigned = "(//div[@class='_3Pw7LpevE3FUAW7arCQak2'])[1]"
support_hub_custom = "//a[@class='_1iuAsV_oq-h3H7ODl-kVp8']"
reporter_support_hub = "//span[@class='IkAvIKMQLY6vGsxPqi37o']"
agents_support_hub_assigned = "//div[@data-testid='supportHub-caseOwnerSelect-caseOwnerName']"
agents_support_hub_unassigned = "//div[@class='_3DTnxahi_JD6aLWcXhJn7L']"
notify_agents = "//span[contains(text(),'Notify ')]"
add_case_note = "//span[contains(text(),'Add case note')]"
add_public = "//span[contains(text(),'Add public comment')]"
open_for = "//div[@class='_2VM21mOKmbmoydlF614zTt']"

dynamic_filter_selected = (
    "//div/*[name()='svg' and @class='styles__StyledSliders-sc-38d0do-2 fDjoSp']"
)
dynamic_filter = "//div[@data-testid='common-popupFilter-btn']"
select_filter = "//span[contains(text(),'TEXT_PLACEHOLDER')]"
case_history = "//div[contains(text(),'Case History')]"
add_dynamic_filter = "//button[contains(text(),'Add dynamic filter')]"
selected_option_dynamic = (
    "//span[@class ='_3PymLU5_Vx6ciR3fPM3gjG' or contains(text(),'Category Testings')]"
)

option_selected_dynamic = "(//ul[@class='_2nnPOzrDypVwzJmyMHuThd QtQ7g5vBYAhcu6kusPngi']//span[@class='_394LIe4fu4bC0T-vIzKq-0'])[1]"
apply_filter = "//div[text()='Apply filter']"
cases_on_top = "//div[@class='_2_2Rxcz66A6W5qy9GWWeN1']"
global_filter = "//span[@class='styles__FilterBtnLabel-x2wtp3-17 eWsTfF']"

filter_from_global_dropdown = "//span[@class='styles__QuickFilterItemLabel-x2wtp3-25 hqqkYs']//span[text()='TEXT_PLACEHOLDER']"
apply_filter_global = "//button[contains(text(),'Apply filter')]"
service_compliance_time_filter_validation = "//p[@class='_1kNyzbPL36IJ388iQiHLmk']"
need_attentions_time_filter_validation = "//span[text()='6 Days Ago']"
no_case_today_page = "//div[@class='_28nkHz0DBBOjeh-UcEKuz1']"
negative_sentiment_cards = "//div[@data-index='2']"
positive_sentiment_cards = "//div[@data-index='4']"
service_compliance_card = "//div[@data-index='1']"
need_attentions_cards = "//div[@data-index='3']"
new_case = "//div[@data-index='0']"
agents_filter_button = (
    "(//button[@class='_2TwO_G91GJ5rUGgteFKcLn _2PEftLDURTIo6H3P3szqc1'])[1]"
)
selected_display = (
    "//div[@class='SearchOptionsFilter__SelectedItemsContainer-sc-8fn4dp-4 UORSQ']"
)
tool_tip_display = "//div[@data-popper-placement='bottom-end']//div[@class='styles__Container-sc-1nosxfb-0 byfmbG']//div[@data-list-wrapper='true' and @class='styles__ListWrapper-sc-1nosxfb-1 igOHCY']"
deselect_check_box = "//*[local-name()='svg' and @class='SelectedOptions__ResetIcon-sc-1g8q83l-2 cYOYYn']"
unassigned = "//div[@class='_2r7PONglhD3sOeD38GBFWc']"
new_case_validation = "//div[@class='_3xZuEMtS39buV7Qb4V3Q9Q _2mgGJbNlTMXqBn8Ci_R7Fd']"
negative_sentiment_validation = "//div[@class='_1bpBLbJyy5e29OuYMw1TwJ']"
positive_sentiments_validation = "//div[@class='_2z4USa48AGy9mK5BLy8TL-']"
services_page_data_validation = (
    "//div[@class='_2ybD9Tq7gdzDTgHYvE681n _3iXA1sZuya2qvhT08jrkXv']"
)

new_case_data_validation = "//div[@class='_2ybD9Tq7gdzDTgHYvE681n _3iXA1sZuya2qvhT08jrkXv _1DqFApC-jzoXB-WgIwvIde']"
need_attentions_validation = "//div[@class='_2z4USa48AGy9mK5BLy8TL-']"  # TO DO
support_hub_display = "//div[@data-testid='supportHub-SHContainer']"
dynamic_filter_pop_up = "//div[@class='_3XF84LfNUleGY_nIXUoivF']"
dynamic_selected_pop_up = "//div[@class='_2peDW6KSyVRuwvr8LwuEUV']"
priority_in_support_hub = "//div[@data-testid='supportHub-caseField-priority']"
agents_check_box = "(//div[@class='_1kcpgYRxH7e78FXl7mnh5S'])[2]//li[@class='_1n5ZAv0fH_2Z2fGRtTTMYG'][1]"
get_name_filter = "(//div[@class='VirtEntityOptionItem__LabelWrapper-sc-1m5546l-2 kZPMWB']//span[@class='VirtEntityOptionItem__Label-sc-1m5546l-3 bhBA-Dh'])[1]"
scope_filters_drop_down = "//div[@class='styles__StyledDropdown-x2wtp3-3 dfKksO']"

agents_check_box3 = (
    "(//div[@class='VirtEntityOptionItem__LabelWrapper-sc-1m5546l-2 kZPMWB'])[2]"
)
agents_check_box2 = (
    "(//div[@class='VirtEntityOptionItem__LabelWrapper-sc-1m5546l-2 kZPMWB'])[3]"
)
agents_check_box4 = (
    "(//div[@class='VirtEntityOptionItem__LabelWrapper-sc-1m5546l-2 kZPMWB'])[4]"
)
agents_check_box5 = (
    "(//div[@class='VirtEntityOptionItem__LabelWrapper-sc-1m5546l-2 kZPMWB'])[5]"
)
agents_check_box6 = (
    "(//div[@class='VirtEntityOptionItem__LabelWrapper-sc-1m5546l-2 kZPMWB'])[6]"
)
agents_check_box7 = (
    "(//div[@class='VirtEntityOptionItem__LabelWrapper-sc-1m5546l-2 kZPMWB'])[7]"
)
agents_check_box8 = (
    "(//div[@class='VirtEntityOptionItem__LabelWrapper-sc-1m5546l-2 kZPMWB'])[8]"
)
agents_check_box9 = (
    "(//div[@class='VirtEntityOptionItem__LabelWrapper-sc-1m5546l-2 kZPMWB'])[9]"
)
agents_check_box10 = (
    "(//div[@class='VirtEntityOptionItem__LabelWrapper-sc-1m5546l-2 kZPMWB'])[10]"
)


card_display = "//div[@class='pTnwf2ho80Fdc1Yz5S5vX']"
assigned_case_this_period = "rect[class='highcharts-point'][fill='#8362a2']"
assigned_cases_backlog = "rect[class='highcharts-point'][fill='#cde0e7']"
zero_cases = "//div[@class='_28nkHz0DBBOjeh-UcEKuz1']"
validate_assigned_list = (
    "//div[@class='_34NUNh8mCMqJna1x_qVylf _3q6hvL9ShqgDuViaOkqS4F']"
)

assigned_case_from_list = "(//div[@data-testid='common-caseList-sideListItem'])[1]"

service_compliance_first_respond = "(//div[@class='chartTitleMain'])[1]"


support_hub_in_negative = "(//div[@class='HPUXDGpXadt9X8P8QZdQG'])[1]"

user_profile = "//div[@class='_2uyFZ7G6G2T-4Gtgcxfm3s _2J42tT0K-bxzW1KC4nTPMF QOkJ2Wl5yIUHYIreGnQpD']"
log_out = "//span[contains(text(),'Log Out')]"
login_validation = "//div[@class='support-logic-container']"
save_button = "//button[text()='Save']"
search_global_filter = (
    "//input[@type='text'  and @class='styles__Input-sc-1dm3xjt-2 dfoiMC']"
)
list_cases_first_respond_time = "(//div[@class='_14N5SFjBZmvmr6k7hxcROl']//span[@class='_68IEnwourP-cec_a77KGz'])[1]"
first_agents = (
    "(//div[@class='VirtEntityOptionItem__LabelWrapper-sc-1m5546l-2 kZPMWB'])[1]"
)
deselect_dynamic_filter = "//*[local-name()='svg' and @data-icon='cross' and @class='styles__StyledCloseIcon-sc-38d0do-8 dzTKuo']"
deselect_dynamic_filter_applied = "//span[@class='_3G9ebXKNmVUn0gb9amR1-W']"
dynamic = "//div[@data-testid='common-popupFilter-btn']"
tabs = "//div[contains(@data-testid, 'consolePage-tabsSlider-tab-')]"
tab_cards = "//div[@data-testid='consolePage-tabsSlider-tab-{tab_name}']"
tabs_with_placeholder = tabs + "//div[text()='No Cases']"
left_slider_arrow = "//div[contains(@class, 'UIsP11KzMZ8aDAu_R27C')]"
right_slider_arrow = "//div[contains(@class, '_3hSjK7avq8O7BGDtL5O06g')]"

assigned_case_tab_status_drop_down= "//div[@class='_361Wp_DWlkWQg45JStr82S']//div[@class='_3xUxtin2bc4T96gulhdq5g']"
case_distribution_tab_status_drop_down="//div[@class='_6rPVjHt2bLrAhZDVLlYfx']//div[@class='_3xUxtin2bc4T96gulhdq5g']"
assigned_case_select_status_in_dropdown="//div[@class='_361Wp_DWlkWQg45JStr82S']//span[text()='TEXT_PLACEHOLDER']"
select_status_in_dropdown_case_distribution ="//div[@class='_6rPVjHt2bLrAhZDVLlYfx']//span[text()='TEXT_PLACEHOLDER']"
case_distribution_tab_case="rect[class='highcharts-point'][fill='#e7e9eb']"
expand_all_in_sentiments_tab ="//div[@class='B66ikID8OIVQs0B7oNTBY']"
group_by_filter = "//div[@data-testid='sentimentsFeed-lightFilter-groupBy-btn']"
grouped_by_dropdown_option = "//span[text()='Filter']"
unassigned_or_assigned_bar_case_distribution = "//div[text()='chart_bar_option']"
all_queues_in_unassigned_tab ="//div[@class='_2H0k0_TP5XNRZob-Pf-S4C']//div[@class='_2TBAUP0T8eRHnC6gKGIVzb']"
first_option_in_all_queue_unassigned_tab="//div[@class='_1U1hO_RXY4_Y7isyTTrcWV _1RVqZ3jdDINjQBQEZPwAm9 _39wsYw9Wz_86EelplxLeUQ _1iJhga0JS5nzw3i0EKsOP- _36Io3kv7HB-_nWp3WV_I96 Vdx7m4oMO4wSJoNcrHO-S']//div[@class='NFulHzm7gS4AioX2p0HPD']//span[@class='_21G6t7OQKIpI0BwINt0XTW']"
no_of_assigned_cases_present_on_assigned_cases_tab="//b[@class='_3qY0OBro-auUnXGxxQv36h']"
support_hub_model_window_status="//div[contains(@data-testid,'supportHub-caseStatusTag')]"
switch_sort_in_unassigned_tab ="//button[@class='_1bZRFzqf2Z-2BW1TwGobM0']"
likely_to_be_cards_cards="(//div[contains(@class,'LtbeBaseCard__Container')])[1]"

#unassigned tab
first_case_first_case_id = "//span[@data-testid='common-caseList-defaultItem-cardId']"


#escalation
escalation_card_check ="(//button[@class='styles__Container-sc-f64l9j-0 jRwRpf'])[1]"
bar_graph_on_escalation_tab ="(//div[contains(@class,'LtbeBaseCard__Container')])[1]//table"
likely_to_be_cards_banner_support_hub ="//div[contains(@class,'PredictionBanner')]"
check_button_on_likely_to_be_escalated_support_hub ="//div[contains(@class,'PredictionBanner')]//button//*[contains(@class,'shared__AckIcon')]"
undo_button_likely_escalated_case ="//div[contains(@class,'PredictionBanner')]//a[text()='undo']"
you_took_care_of_it_in_likely_escalated_banner ="//span[text()='You took care of it']"
few_second_ago_on_first_tab ="(//span[text()='a few seconds ago'])[1]"

# tooltip appears only on case cards not on support hub
console_negative_case_card_share_button = (
    "//div[@data-testid='support-hub.share-button-outer']"
)
share_button_tooltip = console_negative_case_card_share_button + "//div[text()='Share']"

share_button_icon_css = "div[data-testid$='share-button-outer'] svg[data-icon=share-2]"
service_compliance_missed_target_chart_section_css = "path.highcharts-color-1"
case_list_card_css = "div[data-testid=common-caseList-sideListItem]"

expand_all_button = "//div[text()='Expand All']"
