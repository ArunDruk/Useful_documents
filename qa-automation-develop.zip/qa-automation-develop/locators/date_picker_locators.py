"""This page has all the locators for the elements in the calendar widget"""

# css-selectors
date_picker_toggle_css = "div[data-testid=globalDateRangePicker-trigger] > button"
date_picker_apply_btn_css = "button[data-testid=globalDateRangePicker-ApplyButton]"
date_picker_cancel_btn_css = "button[data-testid=globalDateRangePicker-CancelButton]"

from_calendar = "div.DayPicker:nth-child(1)"
to_calendar = "div.DayPicker:nth-child(2)"
from_calendar_current_month_css = from_calendar + " div.CalendarMonth[data-visible=true] div[class*=MonthContainer]"
to_calendar_current_month_css = to_calendar + " div.CalendarMonth[data-visible=true] div[class*=MonthContainer]"
from_calendar_go_to_previous_month_css = from_calendar + " div[data-testid=globalDateRangePicker-NavButtonPrev]"
to_calendar_go_to_previous_month_css = to_calendar + " div[data-testid=globalDateRangePicker-NavButtonPrev]"
from_calendar_go_to_next_month_css = from_calendar + " div[data-testid=globalDateRangePicker-NavButtonNext]"
to_calendar_go_to_next_month_css = to_calendar + " div[data-testid=globalDateRangePicker-NavButtonNext]"

date_picker_from_field_css = "input[data-testid=globalDateRangePicker-FromDateInput]"
date_picker_to_field_css = "input[data-testid=globalDateRangePicker-ToDateInput]"
right_now_shortcut_css = "div[data-testid=globalDateRangePicker-Shortcut-all_time]"
this_month_shortcut_css = "div[data-testid=globalDateRangePicker-Shortcut-this_month]"
year_to_date_shortcut_css = "div[data-testid=globalDateRangePicker-Shortcut-year_to_date]"

last_month_shortcut_css = "div[data-testid=globalDateRangePicker-Shortcut-last_month]"
last_month_shortcut_dropdown_css = (
    "div[data-testid=globalDateRangePicker-Dropdown-last-month] > div > div > div"
)
last_month_shortcut_dropdown_options_css = "div[data-testid=globalDateRangePicker-last-monthOption-{months}]"

quarter_shortcut_css = "div[data-testid=globalDateRangePicker-Shortcut-quarter]"
quarter_shortcut_1st_dropdown_css = (
    "div[data-testid=globalDateRangePicker-Dropdown-quarterFirst] > div > div > div"
)
quarter_shortcut_2nd_dropdown_css = (
    "div[data-testid=globalDateRangePicker-Dropdown-quarterSecond] > div > div > div"
)
quarter_shortcut_dropdown_options_css = "div[data-testid=globalDateRangePicker-quarterOption-{value}]"

move_forward_arrow_button = "(//div[@aria-label='Move forward to switch to the next month.'])[2]"
month_name_on_calendar ="(//div[@data-visible='true']//div[@data-testid='common-dropdown-btn']//div//div)[2]"

# shift calendar date picker elements
previous_month_button_css = " #app_wrapper [class*=DayPickerNavigation_leftButton]"
next_month_button_css = " #app_wrapper [class*=DayPickerNavigation_rightButton]"
selected_week_start_date_css = "td.CalendarDay__selected_start"
selected_week_end_date_css = "td.CalendarDay__selected_end"
week_rows_css = "div.CalendarMonth[data-visible=true] td"

last_week_shortcut_css = "div[data-testid=globalDateRangePicker-Shortcut-past_week]"
this_week_shortcut_css = "div[data-testid=globalDateRangePicker-Shortcut-current_week]"
next_week_shortcut_css = "div[data-testid=globalDateRangePicker-Shortcut-next_week]"
