"""This module is a repository for all the locators present in manage user page that are used in the whole project/product
 and will be used by all pages """

search_user_textbox_in_manage_user_page_xpath = "//input[@placeholder='Search users']"

case_review_toggle_off_xpath ="//div[contains(@class,'_rOoX _28WAzxEDzxc5hg7kFhOukE')][4]//div[contains(@class,'bcrqvN')]"
case_review_toggle_on_xpath= "//div[contains(@class,'_rOoX _28WAzxEDzxc5hg7kFhOukE')][4]//div[contains(@class,'bTyARG')]"
tab_on_manage_user="//div[text()='tab']"
click_on_forward_arrow = "//div[@class='AlMEmTkzOJvIGFZrUMrJl _1mOdRNJirf_lS-LdbeglCn']"