"""This page has the locators for elements in the shift calendar page"""

# xpath
assign_agents_button_above_shift_bar = (
    "//div[contains(text(), '{shift_name}')]/following-sibling::div[.='Assign Agents!']"
)

shift_bar_by_date = (
    "//*[contains(text(), '{date}')]/../following-sibling::div"
    "//div[@data-testid='{shift_name}']"
)

# shift calendar
app_content_body_css = ".content-wrapper"
settings_button_css = "[data-testid=caseAssignmentPage-SettingsBtn]"
back_to_case_assignment_css = "[data-testid=caseAssignmentPage-GoBack-Btn]"
shift_hours_tab_css = "[data-testid=agentShift--detailsTab--shift_hours]"
add_new_shift_button_css = (
    "[data-testid='agentAssignmentShift-shiftDialog-addShiftButton']"
)

shift_name_textbox_css = "[data-testid=agentShift--formDetails--textinput_name]"
assignment_hours_from_textbox_css = "[data-testid$=assignmenthour_textinput_from]"
assignment_hours_to_textbox_css = "[data-testid$=assignmenthour_textinput_to]"
customize_assignment_hour_checkbox_input_css = (
    "input[data-testid*=isCustomizingAssignmentHours]"
)
customize_assignment_hour_checkbox_css = (
    f"{customize_assignment_hour_checkbox_input_css} + label"
)
assignment_hours_custom_from_textbox_css = "[data-testid$=assignmenthour_{day}_from_{slot}]"
assignment_hours_custom_to_textbox_css = "[data-testid$=assignmenthour_{day}_to_{slot}]"
assignment_hours_add_slot_button_css = "[data-testid$=assignmenthour_{day}_addtimeblockbtn_{slot}]"
assignment_hours_remove_slot_button_css = "[data-testid$=assignmenthour_{day}_removetimeblockbtn_{slot}]"

working_hours_from_textbox_css = "[data-testid$=workinghours_textinput_from]"
working_hours_to_textbox_css = "[data-testid$=workinghours_textinput_to]"
customize_working_hour_checkbox_input_css = (
    "input[data-testid*=isCustomizingWorkingHours]"
)
customize_working_hour_checkbox_css = (
    f"{customize_working_hour_checkbox_input_css} + label"
)
working_hours_custom_from_textbox_css = "[data-testid$=workinghours_{day}_from_{slot}]"
working_hours_custom_to_textbox_css = "[data-testid$=workinghours_{day}_to_{slot}]"
working_hours_add_slot_button_css = "[data-testid$=workinghours_{day}_addtimeblockbtn_{slot}]"
working_hours_remove_slot_button_css = "[data-testid$=workinghours_{day}_removetimeblockbtn_{slot}]"

occurrence_weekday_css = "[data-testid=agentShift--formDetails--weekday_{day}]"
does_not_repeat_checkbox_input_css = "input[data-testid*='Does not repeat']"
does_not_repeat_checkbox_css = f"{does_not_repeat_checkbox_input_css} + label"
delete_button_css = "[data-testid=agentShift--formDetails--delete_btn]"
cancel_button_css = "[data-testid=agentShift--formDetails--cancel_btn]"
create_button_css = "[data-testid=agentShift--formDetails--create_btn]"
save_button_css = "[data-testid=agentShift--formDetails--save_btn]"

individual_shift_bar_css = "[data-testid='{shift_name}']"
visible_shift_details_tooltip_css = "div[class*=show][data-id=tooltip]"
details_tooltip_edit_button_css = "[data-testid=agentShiftDetails-edit-btn]"
details_tooltip_delete_button_css = "[data-testid=agentShiftDetails-delete-btn]"

delete_dialog_cancel_button_css = "[data-testid$=deleteShiftDialog-cancelButton]"
delete_dialog_delete_button_css = "[data-testid$=deleteShiftDialog-deleteButton]"
delete_dialog_option_radio_button_css = "[data-testid$=deleteDialog--{option}_radiobtn]"

assignment_hours_details_assign_agents_popup_css = "div[class*=BlockHours]:nth-child(1)"
working_hours_details_assign_agents_popup_css = "div[class*=BlockHours]:nth-child(2)"
assign_agent_cancel_button_css = "[data-testid=agentAssignmentShift-assignModal-backCancelButton]"
