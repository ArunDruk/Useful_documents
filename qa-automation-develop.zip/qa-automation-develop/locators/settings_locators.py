"""This module is a repository for all the locators present in settings page that are used in the whole project/product
 and will be used by all pages """

# Settings page:
control_centre_button_id = "gear"
settings_clickable_text_xpath = "//span[text()='Settings']"
console_section_support_operations_xpath = "(//span[.='Console'])[2]"
production_edition_section_xpath = (
    "//div[@data-testid='settings-sidebar-productEdition-item']"
)
production_edition_standard_version_xpath = (
    "//div[@data-testid='product-edition-preset-standard']"
)
production_edition_pro_version_xpath = (
    "//div[@data-testid='product-edition-preset-pro']"
)
production_edition_enterprise_version_xpath = (
    "//div[@data-testid='product-edition-preset-pro']"
)
production_edition_custom_version_xpath = (
    "//div[@data-testid='product-edition-preset-custom']"
)
product_edition_selected_one_xpath = (
    "//div[@class='_2JTHnyMox7ZfEobMJgEyd8 _3BTidymAdnFN1Cvvifzbfx "
    "_2_CeiScJG568RIGYUsA1ls _2S5O41uwDHBhUp2DwV2Nu7 _3DS0kihCU-TkPjzuw9iaGz'] "
)

set_default_team_button = "//button[text()='Set a default team']"
set_default_team_popup_search_css = "input[placeholder='Search for virtual teams']"
set_default_team_popup_search_result = (
    "//*[text()='{vt_name}']/ancestor::div[@data-list='true']/div"
)
case_assignment_default_team_text = "//div[text()='Default Team']"
popup_remove_button = "//*[text()='Remove']"

# css-selectors
current_default_team_css = "div.tOrjb"
current_default_team_x_icon_css = current_default_team_css + " svg[class*=RemoveIcon]"



get_field_name ="//div[@class='_2jVaPckKE4WkjOF_Jgxeck Ez2kdfqqe6NVzd432YjJs']//following-sibling::div//div[@data-testid='undefined-editableText-name'][1]"
first_case_filed_toggle_enable_or_disable ="//div[@class='styles__Element-sc-x3yu45-0 bTyARG']//ancestor::div//div[text()='text_placeholder']"