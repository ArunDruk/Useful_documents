"""This module has the locators for elements in V* modules"""

# xpath

virtual_star_item_name = "//div[@class='_1RZFLstJ_MSq2-Riva77G6']"
custom_virtual_star_item_name = "//div[starts-with(text(), '{name}')]"

virtual_star_edit_button = "//div[contains(@data-testid, 'edit')]"
virtual_star_clone_button = "//div[contains(@data-testid, 'clone')]"
virtual_star_delete_button = "//div[contains(@data-testid, 'delete')]"
virtual_star_collapse_button = "//div[contains(@class, 'CollapseBtn')]"

virtual_star_cancel_button = "//button[text()='Cancel']"
virtual_star_save_button = "//button[text()='Save']"

virtual_org_list_item = "//ancestor::div[@data-testid='virtualAccounts-virtual_teams_group-listItem']"
virtual_team_list_item = "//ancestor::div[@data-testid='virtualAccounts-virtual_team-listItem']"
virtual_group_list_item = "//ancestor::div[@data-testid='virtualAccounts-logical_group-listItem']"
virtual_account_list_item = "//ancestor::div[@data-testid='virtualAccounts-customer_group-listItem']"

virtual_star_edit_name_text = (
    custom_virtual_star_item_name + "/ancestor::div[contains(@class, 'LabelWrapper')]"
)
delete_confirmation_button = "//button[text()='Delete']"
delete_popup_default_team_warning_text = (
    "//*[text()='Please note - this group is used as a Default Team for ICA."
    " More details in Settings > Case Assignment.']"
)

# css-selectors
search_virtual_team_textbox_css = "input[data-testid=virtualAccounts-groupList-virtual_team-searchInput]"
search_virtual_account_textbox_css = "input[data-testid=virtualAccounts-groupList-customer_group-searchInput]"

create_virtual_team_button_css = "button[data-testid=virtualAccounts-groupList-virtual_team-createButton]"
create_virtual_org_button_css = "button[data-testid=virtualAccounts-groupList-virtual_teams_group-createButton]"
create_virtual_group_button_css = "button[data-testid=virtualAccounts-groupList-logical_group-createButton]"
create_virtual_account_button_css = "button[data-testid=virtualAccounts-groupList-customer_group-createButton]"

next_button_css = create_button_css = "button[data-testid=virtualAccounts-createAccount-submitButton]"
cancel_button_css = "button[data-testid=virtualAccounts-createAccount-backCancelButton]"
choose_type_button_css = "div[data-testid=virtualAccounts-chooseAccountType-{type}]"
create_name_textbox_css = "input[data-testid=virtualAccounts-nameInput-searchInput]"
name_error_message = create_name_textbox_css + " + div[data-type=error-wrapper]"

edit_existing_va_name_textbox_css = "input#virt-entity-name"

search_box_css = "input[data-testid=virtualAccounts-searchBox-searchInput]"
search_result_item_css = "div[data-testid=virtualAccounts-searchList-resultItem]"
