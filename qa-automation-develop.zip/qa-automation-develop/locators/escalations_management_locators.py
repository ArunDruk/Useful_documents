"""This module contains the locators which are used in escalations page automation"""
# Likely to be escalated section case with ticket id as provided in the constants page
escalations_page = "//div[@id='escalationsManagement']"
ticket_drag_lt_be_queue = (
    "//div[@data-testid='escalation-card-list-escalationPredictions-"
)
tickets_active_escalations_queue = (
    "//div[@data-testid='escalation-card-list-activeEscalations-"
)
escalation_request_queue = (
    "//div[@data-testid='escalation-card-list-escalationRequests-{ticket}']"
)
close_toggle_after_drag_and_drop_popup_comes = "//div[@class='_16UEJ5gvTXgMP1JN69iiC3']"
# The first ticket xpath from the escalated today column:
ticket_present_in_escalated_today_column = (
    "//div[data-testid='escalation-card-list-newActiveEscalations"
)
resolved_list = "//div[@ata-testid='escalation-list-container-resolvedEscalations']"
# Escalations page main loader:
escalations_page_loader = "//div[@data-testid='page-loader-escalations']"

# Check if the list is collapsed or expanded:
lt_be_list_expanded = "//div[@class='_13fONrLvuockdk-PgC58fw _1pVJSChY6BkGFVxiD2l3u6']"
lt_be_list_to_be_clicked = "//span[.='Likely to be escalated']//parent::div"
escalated_today_list_expanded = (
    "//div[@class='_13fONrLvuockdk-PgC58fw eQp0F3L438OPNQQfr958c']"
)
escalated_today_list_to_be_clicked = "//span[.='Escalated Today']//parent::div"
active_list_expanded = "//div[@class='_13fONrLvuockdk-PgC58fw _1u2PSKkB-MPi2aUO2qTd0Z']"
active_list_to_be_clicked = "//span[.='Active Escalations']//parent::div"
resolved_list_expanded = (
    "//div[@class='_13fONrLvuockdk-PgC58fw _1y9uxgNiLzPXj0efrcg-PA']"
)
resolved_list_to_be_clicked = "//span[.='Resolved']//parent::div"
# Loading spinners for each column's content locator list:
likely_tobe_escalated_content_loading_spinner_locator = (
    "//div[@data-testid='escalation-list-header-loader-escalation" "Predictions']"
)
escalation_request_content_loading_spinner_locator = (
    "//div[@data-testid='escalation-list-header-loader-escalation" "Requests']"
)
escalated_today_content_loading_spinner_locator = (
    "//div[@data-testid='escalation-list-header-loader-newActive" "Escalations']"
)
active_escalation_content_loading_spinner_locator = (
    "//div[@data-testid='escalation-list-header-loader-active" "Escalations']"
)
resolved_content_loading_spinner_locators = (
    "//div[@data-testid='escalation-list-header-loader-resolvedEscalations']"
)

# Loading spinners for each column's header:
likely_tobe_escalated_header_loading_spinner_locator = (
    "//div[@data-testid='escalation-list-content-loader-escalation" "Predictions']"
)
escalation_request_header_loading_spinner_locator = (
    "//div[@data-testid='escalation-list-content-loader-escalation" "Requests']"
)
escalated_today_header_loading_spinner_locator = (
    "//div[@data-testid='escalation-list-content-loader-newActive" "Escalations']"
)
active_escalation_header_loading_spinner_locator = (
    "//div[@data-testid='escalation-list-content-loader-active" "Escalations']"
)
resolved_header_loading_spinner_locators = (
    "//div[@data-testid='escalation-list-content-loader-resolvedEscalations']"
)

# When data fails to load in each column then error message is shown.
# The below are the locators for error message
error_message_likely_tobe_escalated_column = (
    "//span[@data-testid='escalation-list-content-error-escalationPredictions']"
)
error_message_escalation_request_column = (
    "//span[@data-testid='escalation-list-content-error-escalationRequests']"
)
error_message_escalated_today_column = (
    "//span[@data-testid='escalation-list-content-error-newActiveEscalations']"
)
error_message_active_escalation_column = (
    "//span[@data-testid='escalation-list-content-error-activeEscalations']"
)
error_message_resolved_column = (
    "//span[@data-testid='escalation-list-content-error-resolvedEscalations']"
)
x = "//div[@data-testid='dynamic-filters-container']"

# List of all the columns:
lt_be_column_list = (
    "//div[@data-testid='escalation-list-container-escalationPredictions']"
)
escalation_request_col_list = (
    "//div[@data-testid='escalation-list-container-escalationRequests']"
)
escalations_today_col_list = (
    "//div[@data-testid='escalation-list-container-newActiveEscalations']"
)
active_escalations_col_list = (
    "//div[@data-testid='escalation-list-container-activeEscalations']"
)
resolved_col_list = (
    "//div[@data-testid='escalation-list-container-resolvedEscalations']"
)

# pass the escalation column header as value
escalations_count_board_view = (
    "//span[text()='{escalation_state}']/preceding-sibling::span"
)
escalations_count_list_view = (
    "//span[text()='{escalation_state}']/following-sibling::span"
)

escalations_count_header_loader = (
    "/div[contains(@data-testid,'escalation-list-header-loader')]"
)

# Calendar Date picker Locators:
calendar_visible_option = "//div[@data-testid='globalDateRangePicker-trigger']"
calendar_modal_popover = "//div[starts-with(@class, 'DateRangePicker__Popover')]"

# container header in escalation
likely_to_be_escalated_header = "//div[@data-testid='escalation-list-header-escalationPredictions']"
escalation_request_header = "//div[@data-testid='escalation-list-header-escalationRequests']"
active_escalation_header = "//div[@data-testid='escalation-list-header-activeEscalations']"
resolved_escalation_header = "//div[@data-testid='escalation-list-header-resolvedEscalations']"

escalation_container_sort_by_option = (
    "//div[contains(@data-testid, '{state}')]//*[text()='{option}']/parent::div"
)
escalation_case_card = "//div[contains(@data-testid, 'card-list-{state}')]"
case_card_last_response_time = (
    escalation_case_card
    + "//span[contains(text(), 'Last response')]/following-sibling::span"
)
case_card_in_escalated_state = (
    escalation_case_card
    + "//span[contains(text(), 'In escalated state')]/following-sibling::span"
)
case_card_closed_date = (
    escalation_case_card + "//span[contains(text(), 'Closed')]/following-sibling::span"
)

add_field_plus_button_tooltip = "//div[text()='Add a field']"

# css-selectors

active_escalations_css = "div[data-testid^=escalation-card-list-activeEscalations]"
active_escalations_note_button_css = "[data-testid=escalationCard-notes-btn-activeEscalations]"

board_view_layout_switcher_css = (
    "button[data-testid=escalationsPage-layoutSwitcher-boardView]"
)
list_view_layout_switcher_css = (
    "button[data-testid=escalationsPage-layoutSwitcher-listView]"
)

escalations_container_css = "[data-testid=escalation-list-container-{state}]"
# for snoozed, dismissed and accepted column buttons
hidden_escalation_board_button_css = escalations_container_css + " + div > div"

escalations_container_header_css = "[data-testid=escalation-list-header-{state}]"
case_count_in_header_css = escalations_container_header_css + " span"
escalations_container_sort_by_css = (
    escalations_container_css + " [data-testid=common-dropdown-btn]"
)
escalations_container_sort_by_popup_css = (
    escalations_container_css + " ul._2aa1vapzx54uYEruF5uHOD"
)
escalations_case_card_css = "[data-testid^=escalation-card-list-{state}]"
escalations_case_card_with_id_css = "[data-testid^=escalation-card-list-{state}-{id}]"

case_card_create_date_css = (
    escalations_case_card_css + " div[class^=IconStat__Container]"
)
case_card_sentiment_score_css = (
    escalations_case_card_css + " div.sYCoIqj6_68L0VrUscvKR:nth-child(1)"
)
case_card_attention_score_css = (
    escalations_case_card_css + " div.sYCoIqj6_68L0VrUscvKR:nth-child(2)"
)
case_card_priority_css = escalations_case_card_css + " div[class^=FieldPill]"

escalation_request_decline_button_css = (
    "div[class^=EscRequestBaseCard__Actions] button:not([class*=Undo])"
)
# pair with case card with id locator to work
undo_button_css = "button[class*=Undo]"

list_view_column_header_css = "div[role=columnheader]:not([data-sticky-td])"

add_field_plus_button_css = "div[class^=ColumnsEditor__Trigger]"
add_field_popover_option_checkbox_css = "[data-testid^='animated-checkbox-default-group-{option}']"
add_field_popover_options_css = add_field_popover_option_checkbox_css + " + label"
add_field_popover_option_label_css = "[data-testid^=animated-checkbox-default-group] + label"
