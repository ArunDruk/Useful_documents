"""This page has the locators for elements in the SupportHub modal window"""

# # # # # # # # # # # # # # # # # # # #  xpath  # # # # # # # # # # # # # # # # # # # #
client_note_text_generic = "//div[contains(@data-testid, 'noteText')]"
new_client_note_text = "//div[contains(@data-testid, 'noteText') and text()='{note}']"
share_email_suggestions = "//div[text()='{email}' and @class='_78jvtqpJMjzGgKCYhz9DJ']"

escalation_note_with_text = "//p[text()='{note}']"
private_case_note_icon = (
    "//div[starts-with(@class, 'CaseComment__Body') and contains(text(), '{case_note}')]"
    "/div[starts-with(@class, 'CaseComment__ConnerIcon')]"
)

label_tab = "//button[text()='Label']"
label_selector = (
    "//span[@class='_1MJPguNqjM7ASTFSOQpVqZ' and text()='{label_name}']/parent::a"
)
change_sentiment_label_menu_option = "//li[text()='Change label']"
labelled_sentiment_with_text = """//mark[text()="{trigger_text}"]"""
escalation_request_label_time = (
    "//div[@label='Escalation Request']"
    "/ancestor::div[@data-testid='supportHub-sentiment-card']//time"
)

no_sentiments_found_text = "//div[contains(text(), 'No Sentiments')]"
acknowledged_sentiment_label = "//*[@data-testid='supportHub-sentiment-acknowledge']/preceding-sibling::div"

case_owner_name_in_tooltip ="//span[text()='TEXT_PLACE_HOLDER']"
case_owner_active_hours_in_tooltip ="//span[text()='TEXT_PLACE_HOLDER']//following::div"

reporter_tool_tip_xpath = "//div[contains(@class,'CaseReporter__Popover')]"
reporter_name_in_reporter_tool_tip_xpath = "//div[contains(@class,'CaseReporter__NameWrapper')]"
reporter_email_in_reporter_tool_tip_xpath = "//div[contains(@class,'CaseReporter__EmailWrapper')]"
reporter_active_hours_in_reporter_tool_tip_xpath = "//div[contains(@class,'CaseReporter__ActiveHoursWrapper')]"
number_of_cases_in_tool_tips_xpath = "//div[@class='_3rXGIVOJV2oEFdrhNjABq8']//span"
case_status_tool_tip = "//*[text()='Edit case status']"
case_priority_tooltip = "//*[starts-with(text(), 'Edit Priority')]"
case_owner_icon ="//div[@data-testid='supportHub-caseOwnerSelect-ownerContainer']//span"

# # # # # # # # # # # # # # # # # #  css-selectors  # # # # # # # # # # # # # # # # # #
support_hub_modal_window_css = "div[data-testid=supportHub-SHContainer]"

# works only on modal window version of support hub
close_support_hub_button_css = support_hub_modal_window_css + " div[data-testid$=closeDialog]"
open_in_salesforce_css = support_hub_modal_window_css + " div[data-testid$=openNewTab]"
copy_url_button_css = support_hub_modal_window_css + " div[data-testid$=copyURL]"

customer_name_css = "div[data-testid=supportHub-caseCustomer-CustomerName]"

add_client_note_css = "button[data-testid=supportHub-caseCustomerNotes-NotesTrigger]"
client_notes_count_css = "div[data-testid='support-hub.customer-notes-flag'] span.customer-notes__trigger__amount"
client_notes_popover_css = "div#case-customer-notes-popover"
add_new_client_note_css = (
    "button[data-testid=supportHub-caseCustomerNotes-addNewNotesButton], "
    "button[data-testid=supportHub-caseCustomerNotesEmpty-addNewNotesButton]"
)
save_new_client_note_css = "button[data-testid=supportHub-caseCustomerNotes-AddNewNote]"
save_edit_note_css = "button[data-testid=supportHub-caseCustomerNotes-SaveEditNote]"
save_client_note_css = save_new_client_note_css + ", " + save_edit_note_css
cancel_new_client_note_css = "button[data-testid=supportHub-caseCustomerNotes-cancelAddNewNote]"
close_client_note_popover_css = "span[data-testid=supportHub-caseCustomerNotes-closeNoteIcon]"
client_note_textarea_css = (
    "textarea[data-testid=supportHub-caseCustomerNotes-notesInput], "
    "textarea[data-testid=supportHub-caseCustomerNotes-EditNoteTextarea]"
)

client_note_agent_icon_css = "div[data-testid=supportHub-caseCustomerNotes-userAvatar]"
client_note_text_css = "div[data-testid^=supportHub-CaseCustomerNotes][data-testid$=noteText]"
client_note_time_css = "div[data-testid^=supportHub-CaseCustomerNotes][data-testid$=noteDate]"
edit_client_note_css = "div[data-testid=supportHub-caseCustomerNotes-editNoteIcon]"
delete_client_note_css = "div[data-testid=supportHub-caseCustomerNotes-deleteNoteIcon]"

reporter_name_css = "div[data-testid=supportHub-caseHeader-caseReporterName]"
case_owner_name_css = "div[data-testid=supportHub-caseOwnerSelect-caseOwnerName]"
case_owner_icon_text_css = "div[data-testid=supportHub-caseOwnerSelect-ownerContainer]"

case_owner_search_tab_css = "span[data-testid=supportHub-caseOwnerSelect-ica-searchTab]"
agent_search_no_results_css = "div._3qKgcLurkB7HRNbA6dwdYm"
agent_search_box_css = "input[data-testid=supportHub-caseOwnerSelect-searchInput]"
# agent_search_suggestion_list_item_css = "div[data-testid=supportHub-caseOwnerSelect-optionsItem]"
agent_search_suggestion_list_item = (
    "//div[@data-testid='supportHub-caseOwnerSelect-searchWrap']"
    "/following::div[@role='rowgroup']/div"
)
agent_search_suggestion_assign_button = (
    "//div[@data-testid='supportHub-caseOwnerSelect-searchWrap']"
    "/following::div[@role='rowgroup']//div[text()='Assign']"
)

favorite_client_button_css = "button[data-testid=supportHub-caseCustomer-favoriteCaseTrigger]"
case_id_css = "div[data-testid=supportHub-caseHeader-caseNumber]"
case_subject_css = "div[data-testid=supportHub-caseHeader-caseSubject]"

current_case_priority_css = edit_case_priority_css = "div[data-testid=supportHub-caseField-priority]"
case_field_dropdown_css = "div[data-testid=supportHub-customField-dropdownCurrentOption]"
case_field_options_css = "div[data-testid='supportHub-CustomFieldDropdown--{option}']"
case_field_save_button_css = "button[data-testid=supportHub-editableField-saveButton]"
case_field_cancel_button_css = "button[data-testid=supportHub-editableField-cancelButton]"
case_field_overflow_css = "div[data-testid=supportHub-caseFieldContainer-overflowTrigger]"
case_field_overflow_popover_css = "div[data-testid=supportHub-caseFieldContainer-overflowPopover]"

current_case_status_css = edit_case_status_css = "div[data-testid^=supportHub-caseStatusTag]"
case_status_options_popover_css = "div._3AKvmGJUscj5JrHjJAmZBU"
case_status_options_css = case_status_options_popover_css + " div[data-option='{case_status}']"

share_case_outer_css = support_hub_modal_window_css + " div[data-testid$='share-button-outer']"
share_button_icon_css = share_case_outer_css + " svg[data-icon=share-2]"
share_button_edit_icon_css = share_case_outer_css + " svg[data-icon='edit-light']"

share_button_outer_css = "button[data-testid=supportHub-caseShare-trigger]"
share_case_popover_css = "div#case-share-popover"
email_input_box_css = "input[data-testid$='shareWithInput']"
share_reason_textarea_css = "textarea[data-testid$=caseShare-addMessageInput]"
share_button_inner_css = "button[data-testid$='share-button-inner']"
close_share_case_popover_css = share_case_popover_css + " svg[data-icon=cross]"

share_via_slack_button_css = "div[data-testid$='SlackInputTab']"
share_via_teams_button_css = "div[data-testid$='MS_TeamsInputTab']"
share_via_email_button_css = "div[data-testid$='EmailInputTab']"

case_share_invalid_email_error_css = share_case_popover_css + " div._14pBFkqkSNTcfNWxo_H7MX"
shared_with_check_css = share_case_popover_css + " svg[data-icon=check]"

case_history_escalation_label_css = "div[data-testid=supportHub-escalationStatusIndicator-escalationLabel]"
add_escalation_note_button_css = (
    "button[data-testid=supportHub-caseEscalationNotes-addNoteButton]"
)
add_fresh_escalation_note_css = (
    "button[data-testid=supportHub-escalationNoteDialog-addEscalationNoteButton]"
)  # 'Add an escalation note' button in escalation note dialog
escalation_note_textarea_css = (
    "textarea[data-testid=supportHub-escalationNoteDialog-editNoteInput]"
)
escalation_note_text_css = "p._3SBRawNPXsR6mZUqQoHp1x"

support_body_section_css = "div#support_hub_widget_scroll_container"

case_sentiment_card_css = "[data-testid=supportHub-sentiment-card]"
sentiment_label_css = "div[data-testid=supportHub-sentiment-Label]"
sentiment_label_menu_css = "div[class^=SentimentLabel__IconWrapper]"
labelled_sentiment_css = "div[class^=SentimentCard__Text]"
acknowledge_sentiment_button_css = "[data-testid=supportHub-sentiment-acknowledge]"

conversation_search_box_css = "div[data-testid=supportHub-caseComments-searchContainer]"
conversation_search_input_css = "input[data-testid=supportHub-caseComments-searchInput]"
conversation_search_no_result_css = "span._3dw9bfvqGGiXGFMn8lXpVZ"
conversation_search_results_css = "mark[class^=shared__Mark][data-search-result]"

add_case_note_button_css = "button[data-testid=supportHub-caseCommentForm-addCaseNoteButton]"
reply_to_client_button_css = "button[data-testid=supportHub-caseCommentForm-replyToClientButton]"
add_cc_button_css = "button[data-testid=supportHub-caseCommentForm-CCButton]"
add_bcc_button_css = "button[data-testid=supportHub-caseCommentForm-BCCButton]"
add_cc_textbox_css = "input[data-testid=supportHub-caseCommentForm-CCContainerInput]"
add_bcc_textbox_css = "input[data-testid=supportHub-caseCommentForm-BCCContainerInput]"
case_note_editor_textarea_css = "textarea[data-testid=supportHub-caseCommentForm-addNewCaseNoteInput]"
cancel_adding_new_case_note_css = "button[data-testid=supportHub-caseCommentForm-cancelButton]"
save_new_case_note_css = "button[data-testid=supportHub-caseCommentForm-saveSendButton]"

case_comments_css = support_body_section_css + " article[id^='case_comment']"
case_comments_text_css = "div[class^=CaseComment__Body]"
case_comments_marked_text_css = "[data-testid=supportHub-caseTimeline-caseComment-markedText]"
highlighted_text_css = case_comments_text_css + " span._3fNuUSRG4H52ZQHAq8Ps1R"

favorites_tooltip_css = "div[data-testid=supportHub-caseCustomer-favoriteCaseTooltip]"

notify_agent_button_css = "button[data-testid=supportHub-caseCommentForm-notifyButton]"

add_label_button_css = "[data-testid=supportHub-caseTimeline-caseComment-addLabel]"
add_label_list_header_css = "div[class*=SignalPopup__ListHeader]"
add_label_signal_option_css = "div[class*=SignalPopup__CheckboxItem]"
add_label_apply_button_css = "[data-testid=supportHub-apply-labelling-button]"
add_label_clear_button_css = "[data-testid=supportHub-caseTimeLine-signalPopup-clearButton]"
