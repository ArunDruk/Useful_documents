"""
This module contains the identifiers of the case board page.
"""

new_case_list_name = "A New List"

# Case board general variables.
case_board_page_title_prefix = "SupportLogic - "
case_board_page_url = "/support/cases"

# Case Board Page's links.
case_board_page_menu = "//a[@data-testid='layout-navigation-module-item--cases']"
case_board_page_menu_id = "//div[@id='cases']"


# Case Board page Empty State
welcome_message_in_case_board = (
    "//div[@class='styles__WelcomeTitle-sc-1uh5fff-3 jKEJkY']"
)
default_lists_button = "//button[text()='Default lists set']"
custom_lists_button = "//button[text()='Create custom list']"

# Dynamic filter tool
dynamic_filter_tool = "//div[@class='styles__Container-sc-38d0do-0 hdShJt']"

# Add a new case list flow locators
add_case_list_button = "//span[@data-testid='caseBoard--floating-action-button']"
name_field_for_new_case_list = "//input[@placeholder='Enter a list name']"
next_button_on_add_case_list_modal = "//button[contains(text(), 'Next')]"
cancel_button_on_add_case_list_modal = "//button[contains(text(), 'Cancel')]"
back_button_on_add_case_list_modal = (
    "//button[@class='styles__BackButton-sc-1dhiqqo-1 cBnRaC']"
)
radio_buttons_for_case_ranking = (
    "//div[@class='_2JTHnyMox7ZfEobMJgEyd8 _2_CeiScJG568RIGYUsA1ls']"
)
create_button_on_add_case_list_modal = "//button[contains(text(), 'Create')]"
first_case_list_name_container = "(//div[@class='_1pCn3JSUEXWZA3Ade2DxZn'])[1]"
case_list_name_container = "(//div[@class='_1pCn3JSUEXWZA3Ade2DxZn'])"
sentiment_score_radio_button ="//div[@data-radio-button='true']//following-sibling::div[1]//span[text()='Sentiment Score']"
attention_score_radio_button = "//div[@data-radio-button='true']//following-sibling::div[1]//span[text()='Attention Score']"
single_selection_radio_button ="//div[@class='_2JTHnyMox7ZfEobMJgEyd8 _3BTidymAdnFN1Cvvifzbfx _2_CeiScJG568RIGYUsA1ls']"
# Case List options locators
case_list_options_vertical_dots_of_first_list = (
    "//div[@data-testid='caseBoard--list--menu'][1]"
)
case_list_options_button_on_nth_list = "(//div[@data-testid='caseBoard--list--menu'])"
case_list_options_vertical_dots = "//div[@data-testid='caseBoard--list--menu']"
edit_option_in_options_dropdown = "//div[contains(text(), 'Edit list')]"
delete_list_in_options_dropdown = "//div[contains(text(), 'Delete list')]"
first_list_first_case_id =  "(//div[@data-testid='caseBoard--list--item'])[1]//span[1]"
rank_by_case_pop_up ="//div[text()='Rank cases by']"
# Edit Case List work flow modal locators
apply_change_button_in_edit_case_list_modal = (
    "//button[contains(text(), 'Apply changes')]"
)

# Delete case list Modal Locators
delete_button_in_delete_modal = "//button[contains(text(), 'Delete')]"
cancel_button_in_delete_modal = "//button[contains(text(), 'Cancel')]"
delete_button_image = "//div[@class='_3rx0i5M5-QNjg_LyS4rAa0']"

# Case List expanded view / collapse view
case_list_expand_button = "//span[@data-testid='caseBoard--list--expand']"
case_list_expand_view_close_button = "//div[@class='_2WbFPzmDB7D0Iax5Y0UN7I']"
case_list_expanded_modal = "//div[@class='_3c4qvcdzXQqGQa0PKF2AIx']"
first_case_list_expand_button = "(//span[@data-testid='caseBoard--list--expand'])[1]"

# Case Board page contents
case_lists_content_section = "//div[@id='open-cases-tab-content']"
add_case_list_modal = "//div[@data-testid='caseBoard--list--expand']"
case_lists = "//div[@class='_35Ajy5-6hF9u5UYiCUQntI']"
single_case_in_a_list = "//div[@class='_3K75FhGEjEOUDSGXPFQEYB']"
check_for_presence_list_in_case_board = "//div[@data-list-title]"

#switch sort
switch_sort_xpath ="//div[@data-testid='caseBoard--list--menu--switch-sort-direction']"


sentiment_score_in_sentiments_list = "(//div[@data-list-title])[1]//div[@class='sYCoIqj6_68L0VrUscvKR']"
download_csv  ="//div[text()='Download CSV']"
