"""Unsorted Locators"""
# - Please adjust the old locators in the right locator page while creating new locators pages


# Sign-in Page Locators:
sign_in_via_email = "sign-in-email"
email_user = "inputEmail"
password_user = "inputPassword"
login_button_sign_in_via_email = "//button[.='Sign in']"
back_button = "//a[.='Back']"

# Console settings page locators:
time_filters_today = "//span[text()='Today']//ancestor::div[contains(@class,'styles__Container')]//*[@data-icon='eye-visible']"
eye_icon_today_time_filter = "//svg[@data-icon= 'eye-visible']"

# case board page locators:
case_board_page_menu = "cases"

# CUSTOMER MANAGEMENT PAGE
# Customer- Insight Page
# Favourites Page
# Virtual Account Page
virtual_account_page_id = (
    "//span[text()='Virtual Accounts']"  # This is a id locator > By the help of this can enter the page
)
create_a_virtual_account_xpath = "//button[.= 'Create a Virtual Account']"
create_a_virtual_group_xpath = "//button[.='Create a Virtual Group']"
content_vg_page_xpath = "(//div[contains(@class ,'styles__Description-sc-1ojjgzg-4')])[1]"
content_va_page_xpath = "(//div[contains(@class ,'styles__Description-sc-1ojjgzg-4')])[2]"
global_virtual_account_box_xpath = "//div[.='Global Account']"
personal_virtual_account_box_xpath = "//div[.='Personal Account']"
input_box_to_pass_va_name_id = "//input[@data-testid='virtualAccounts-nameInput-searchInput']"
next_button_va_creation_xpath = "//button[.='Next']"
search_customer_box_xpath = (
    "//input[contains(@placeholder,'name or email')]"
)
list_selection_1 = "(//div[@data-testid='virtualAccounts-searchList-resultItem'])[1]"
list_selection_2 = "(//div[@data-testid='virtualAccounts-searchList-resultItem'])[2]"
create_button_va_xpath = "//button[.='Create']"
list_of_va_in_dashboard = "//div[@class='_1RZFLstJ_MSq2-Riva77G6']"
