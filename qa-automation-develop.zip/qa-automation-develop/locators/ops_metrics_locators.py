"""This page has the locators for elements in the ops metrics page"""

# xpath
case_list_popup_sort_by_button = (
    "//*[name()='svg' and @data-icon='arrow-short']/parent::button"
)

case_list_sort_by_customer_name = "//span[text()='Customer Name']/parent::div"

active_escalations_count = "//span[text()='active escalations']/preceding-sibling::span"

choose_chart_type = "//div[text()='{chart_type}']/parent::div"
group_or_arrange_cases_by_options = "//span[text()='{value}']//parent::button"
new_chart_category = "//div[text()='{category}']//parent::div"

save_chart_edit = "//div[text()='Save']"
add_button_in_new_chart_popover = "//div[text()='Add']"
cancel_button_in_new_chart_popover = "//div[text()='Cancel']"

chart_name = "//span[normalize-space()='{chart_name}']"
chart_id = chart_name + "//ancestor::div[@data-id]"
default_chart_menu = "//*[name()='svg'][@data-icon='vertical-dots']/parent::div"
default_chart_download_button = "//*[name()='svg'][@data-icon='download']/parent::div"
chart_drag_button = "//div[@data-id]//*[name()='svg'][@data-icon='drag']/parent::div"
chart_drop_target = "(//div[@data-id])[2]"

# chart_menu = (
#     chart_name + "/ancestor::div[@class='TJ64-k-_GsfIRsLeOAcK_']"
#     "//div[@class='_21RFLKkZqaUUZITjpaPZw5']"
# )

chart_menu = (
    chart_name + "/../../../div[2]/div[2]"
)

default_chart_menu = (
    chart_name + "//*[name()='svg'][@data-icon='vertical-dots']/parent::*"
)

sla_default_chart_download_button = (
    "//*[name()='svg'][@data-icon='download']"
    "//parent::div[@class='_16Nets3P4ynchAGOWZCNFV']"
)
sla_default_chart_zero_state_msg = (
    "//*[name()='text'][contains(text(), 'no cases')]"
)

# css-selectors
mini_loader_css = "div._2g2SGfCsl3tCY80sB9n8GS"
onboard_page_button_css = "button._1A5rTCy6FWlA52kIqnCjod"

back_to_overview_css = "div[data-testid=metrics--operationalMetrics--backBtn]"
reset_to_default_charts_css = (
    "span[data-testid=metrics-metricsConfigurable-addMetricsChart-resetBtn]"
)

overview_section_card_css = "div[data-testid=metrics-summaryCard-{section}]"
overview_section_card_info_icon_css = (
    overview_section_card_css + " div._1EP13ogkSjoQogckVc4CZP"
)
overview_section_card_info_popover_css = "div#customer-notes-hint-popover"
overview_card_view_details_button_css = "div.AmxBJw89690VjnfdfWBKf"
overview_section_pie_chart_css = overview_section_card_css + " svg.highcharts-root"
overview_section_settings_css = overview_section_card_css + " div[class*=SettingsBtn] a"
overview_section_settings_tooltip_css = "div[class*=PopperContainer]:not(#root)"

overview_section_met_target_css = (
    overview_section_card_css + " div._12cVEi0555jFAGRPjw-J0J"
)

case_list_popup_export_button_css = "button._2faGOSKL3Nosq8HSIuGode"
case_list_popup_sort_by_dropdown_css = "div[data-testid=common-dropdown-btn]"
case_list_popup_card_client_name_css = "[data-testid=common-caseList-defaultItem-cardTitle]"

details_section_tab_css = "div[data-testid=metrics--summaryCard--detailsTab--{section}]"
add_chart_button_css = "span[data-testid^=metrics-addChartBtn]"

add_chart_custom_tab_css = "button[data-testid$=chartEditor-customTab]"
add_chart_general_tab_css = "button[data-testid$=chartEditor-generalTab]"
add_chart_standard_field_item_css = "button[data-testid$=chartEditor-standardField-{field}]"
add_chart_custom_field_item_css = "button[data-testid$=chartEditor-customField-{field}]"
add_chart_cancel_button_css = "div[data-testid$=chartEditor-cancelBtn]"
add_chart_submit_button_css = "div[data-testid$=chartEditor-addSubmitBtn]"
# choose chart type
add_chart_disabled_chart_type_css = "_1PWU4tx_G3jqtpOpzNTwhk"  # only for assertion
add_chart_popover_choose_type_css = "div[data-testid$=chartEditor-{type}]"
# add chart popover -> choose chart
add_chart_choose_name_css = "div[data-testid$='chartEditor-chooseChartType-{chart_name}']"
# applies only to general charts
add_chart_general_type_css = "div[data-testid$='chartEditor-chooseChartType-{chart_name}-{type}']"

section_in_focus_css = "div._2JhMDbSrMmx60PNisAq8EH > div.qoJKzUOd9AEHGeHvBGLEe"
section_sub_tabs_css = "button[data-testid=metrics--subTab--{tab_name}]"
current_selected_sub_tab_css = "li.tB6qcprPKnZvpQHZh_gwe"

sla_default_chart_container = "div._30aar1HlCH19pYIsJHgp6D"
charts_in_sla_section_tabs_css = sla_default_chart_container + " svg.highcharts-root"
sla_section_pie_chart_css = sla_default_chart_container + " div.highcharts-annotation"
sla_section_trend_chart_css = sla_default_chart_container + " div.highcharts-legend"

chart_in_efficiency_section_tabs_css = "div._3dPbhWvkJFYTe2oESds9eD svg.highcharts-root"

sla_pie_chart_met_target_css = sla_default_chart_container + " path.highcharts-color-0"
sla_pie_chart_missed_target_css = sla_default_chart_container + " path.highcharts-color-1"
sla_pie_chart_info_tooltip_css = sla_default_chart_container + " div.hc-custom-tickets-tooltip"

chart_tickets_popup_css = "div.ticketsPopup"
chart_tickets_popup_case_count_css = "div._1WVGRrCE1SbWLLmje_AG9m"
chart_name_css = "div.bCeL6LNvS-e94VJKH7zl8 > span"
chart_filter_dropdown_css = (
    """div[data-testid="{chart_name}--dropdown--trigger"] > div > div > div"""
)

temp_range_bucket_dropdown_css = "div.cITfztE_FyvTr2GWjvcMI[data-testid='{chart_name}--dropdown--trigger']"

chart_filter_options_css = """div[data-testid="{chart_name}--dropdown--{option}"]"""
chart_filter_dropdown_apply_btn_css = "[data-testid='{chart_name}--fieldValueSelector-applyBtn']"
edit_chart_css = """div[data-testid="{chart_name}--editChart--btn"]"""
delete_chart_css = """div[data-testid="{chart_name}--deleteChart--btn"]"""
sla_show_trend_chart_css = "div[data-testid='{chart_name}--show_trend_chart_view--btn']"
sla_show_donut_chart_css = "div[data-testid='{chart_name}--show_donut_chart_view--btn']"

days_spent_escalated_chart_xaxis_label_css = "[data-id='{value}'] .highcharts-xaxis-labels"
days_spent_escalated_chart_yaxis_label_css = "[data-id='{value}'] .highcharts-yaxis > .highcharts-axis-title"

customer_experience_chart_xaxis_label_css = "[data-id={value}] .highcharts-xaxis > .highcharts-axis-title"
customer_experience_chart_yaxis_label_css = "[data-id={value}] .highcharts-yaxis > .highcharts-axis-title"

export_csv_option_css = "div[data-testid='{chart_name}--exporter--option--csv']"
export_csv_option_checkbox_css = export_csv_option_css + " input[type=checkbox]"
export_image_option_css = "div[data-testid='{chart_name}--exporter--option--image']"
export_image_option_checkbox_css = export_image_option_css + " input[type=checkbox]"
export_button_css = "button[data-testid='{chart_name}--exporter--export-btn'"

sla_default_chart_overall_case_count_css = sla_default_chart_container + " div._2z5B2_PeoxcIVIWl8xSg9w"
sla_pie_chart_met_target_css = sla_default_chart_container + " path.highcharts-color-0"
sla_pie_chart_missed_target_css = sla_default_chart_container + " path.highcharts-color-1"
sla_pie_chart_info_tooltip_css = sla_default_chart_container + " div.hc-custom-tickets-tooltip"

new_escalations_count_css = "span._3YAA-rigu92i_SoUJ9bwul"

sentiment_signals_chart_visible_plot_css = "g.highcharts-series-group rect.highcharts-point"
sentiment_signals_case_list_item_css = "[data-testid=common-caseList-sideListItem] div"
sentiment_signals_case_list_item_link_css = sentiment_signals_case_list_item_css + " a"

case_status_in_detached_support_hub_css = "div[data-testid^=supportHub-caseStatusTag]"
