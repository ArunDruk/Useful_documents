"""This module contains the locators which are used in alerts page automation"""
__author__ = "Neha Jha"
__copyright__ = "Copyright (C) 2021 SupportLogic"

alerts_nav_bar = "//span[text()='Alerts']"
alerts_definition = "//div[text()='Notification Method']"
alerts_condition = "//div[text()='Alert Conditions']"
system_alerts = "//div[text()='System Alerts']"
new_alerts = "//div[@data-testid='alert--NewAlertButton']"
alerts_definition_mute = "//div[@data-testid='alert--muteToggle']"
alerts_name_definition = "//div[@data-testid='alertPage-editableText-name']"
alerts_copy = "//div[@data-testid='alert--DuplicateAlertButton']"
alerts_delete = "//div[@data-testid='alert--DeleteAlertButton']"
alerts_condition_option = (
    "(//div[contains(@class,'commonStyledComponents__ListTrigger-sc-1d7dtfa-20 ')])[1]"
)
condition_drop_down = "(//div[contains(@class,'styles__Item-sc-1497swj-1')])[1]"
sentiments_alerts_definition = "//div[contains(@class,'commonStyledComponents__ConditionItem-sc-1d7dtfa-7 ')]//div[@class='_3DyXFNN3M3szdH-1lt88pW']"
drag_drop_definition = "//div[contains(text(), 'Drag and drop a condition here!')]"
delete_alerts_delete_pop_up = "//div[text()='Delete']"
alerts_mute = "//div[@data-testid='alert--muteToggle-muteAlert']"
alerts_un_mute = "//div[@data-testid='alert--muteToggle-unMuteAlert']"
remove_sentiments = "//div[@class='commonStyledComponents__RemoveButtonWrapper-sc-1d7dtfa-6 " \
                    "commonStyledComponents__RemoveButtonWrapperPill-sc-1d7dtfa-8 jmSfdb']/div "
mute_alerts_list = "(//div[@data-testid='alert-alertsNavigationList-muteButton'])[1]"
un_mute_alerts_list = "(//div[@data-testid='alert-alertsNavigationList-unMuteButton'])[1]"
expand_list_box = "(//div[contains(@class,'styles__Container-sc-1twcur-0 ')]//div)[1]"
alerts_present_in_dashboard = "//div[@data-testid='alert--AlertsNavigationList--item']"

drag_drop_target = (
    "//div[contains(@class, 'eLAWGp')] | //div[contains(@class, 'iWXldK')]"
)
condition_parent = "//div[text()='{parent}']/ancestor::div[contains(@class, 'naibk')]"
condition_parent_minimized = "//*[name()='svg' and contains(@class, 'eDxmln')]"  # use as suffix with above locator
alert_condition_element = (
    "//div[text()='{condition}']/ancestor::div[contains(@class, 'iEtShm')]"
)
alerts_name_edit = "//div[contains(@class,'_1XHdcZSe0vsPT8UBBbCCQu')]"
alerts_name_input_field = "//div[@class='BxjsZ9MPF3mJlqvEW_KT8']//input[@type='text']"
alerts_list = "//div[contains(@class,'styles__Container-sc-1355xkc-0')]"
expand_and_collapse_button ="//div[@data-testid='alert--AlertExpandTrigger']"
collapse_state_of_alert_condition ="//div[@class='styles__Container-sc-11fd6b5-1 zyRyJ']"
last_activity_state_in_alert_condition = "//div[text()='Last Case Activity']"
last_case_activity_sentiments_inbound = "//div[text()='inbound']"
error_message_last_case_activity_is_left_blank ="//div[text()='This field cannot be left blank.']"
#undo button in condition
condition_undo_button = "(//div[contains(@class,'RevertChanges')])[1]"
payload_section_undo_button = "//div[text()='Payload']//following::div[contains(@class,'RevertChange')]"

# payload section
search_in_payload_section ="//div[contains(@class,'Select__placeholder')]"

# notification method
click_on_first_email_account = "//div[@class='_1eKFoba8heHFfCGAVH8U8Z']"
remove_email_account ="//div[@class='_1eKFoba8heHFfCGAVH8U8Z']//ancestor::div[@class='_3sJjGmejGZEvvYSxDZcHs9']//div[@class='styles__Button-sc-oqvoif-0 cFPuAc']"
notification_undo_button ="//div[text()='Notification Method']//div[contains(@class,'RevertChange')]"

#payload_section
payload_search_message =  "[class='Select__placeholder css-1wa3eu0-placeholder']"
payload_message_sentiments ="//div[contains(@class,'styles__DynamicOptionsWrapper')]//div[contains(@class,'styles__Item')]"
payload_menu_option_after_entering_back_slash = "[class='Select__control Select__control--is-focused Select__control--menu-is-open css-1pahdxg-control']"
check_email_box_send_me_alert = "//div[text()='Email']//ancestor::div[contains(@class,'styles__Item')]//label//span"
data_status_of_email_check_box = "//div[text()='Email']//ancestor::div[contains(@class,'styles__Item')]//label//input"
send_me_alert_check_box_data_status ="//div[text()='Send alerts to me']//ancestor::label//input"
send_me_alert_drop_down ="(//div[contains(@class,'styles__DropdownWrapper')])[1]"
notification_drop_down = "//div[text()='Notify the following recipients']//following::div[contains(@class,'styles__Dropdown')]"
select_slack_in_drop_down ="//div[text()='Slack']//ancestor::div[contains(@class,'styles__Item')]//label//span"
data_status_of_slack_check_or_not = "//div[text()='Slack']//ancestor::div[contains(@class,'styles__Item')]//label//input"
slack_not_configure_error_message  ="//div[text()='Your slack workspace is not available for the alerts']"
