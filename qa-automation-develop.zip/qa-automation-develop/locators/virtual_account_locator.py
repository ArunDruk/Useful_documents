"""This module contains the locators which are used in vitual_account page automation"""
__author__ = "Neha jha"
__copyright__ = "Copyright (C) 2021 SupportLogic"


first_virtual_account_group_name = "(//ul[contains(@class,'styles__ListWrapper-sc-1ojjgzg-11')])[2]//div[contains(@class,'styles__Label-sc-1mbvlf5-4')]"
error_message_on_providing_existing_name ="//div[@data-type='error-wrapper']"
create_virtual_group="//button[.= 'Create a Virtual Group']"
global_group ="//div[.='Global Group']"
next_button ="//button[.='Next']"
search_in_virtual_group ="//input[@data-testid='virtualAccounts-searchBox-searchInput']"
create_button = "//button[.='Create']"
delete_first_virtual_group="//div[text()='TEXT_PLACEHOLDER']//ancestor::div[contains(@class,'styles__Container-sc-1sg8k88-1')]//div[@data-testid='virtualAccounts-listItem-logical_group-delete']"
delete_pop_up ="//button[text()='Delete']"
search_customer_box_xpath = (
    "//input[@placeholder='Enter a customer/reporter name or email' or type='text']"
)
list_of_virtual_group_present ="(//ul[contains(@class,'styles__ListWrapper-sc-1ojjgzg-11')])[1]//div[contains(@class,'styles__Label-sc-1mbvlf5-4')]"
get_number_on_agents_on_expanding_virtual_group ="//div[contains(@class,'styles__Item-sc')]"
edit_first_virtual_group = "//div[text()='TEXT_PLACEHOLDER']//ancestor::div[contains(@class,'styles__Container-sc-1sg8k88-1')]//div[@data-testid='virtualAccounts-listItem-logical_group-edit']"

first_virtual_group_name="(//div[contains(@class,'styles__Container-sc-1ojjgzg-0')])[1]//div[contains(@class,'styles__Label-sc')]"
save_button ="//button[text()='Save']"
remove_agents_from_virtual_group ="(//*[contains(@class,'styles__RemoveIcon')])[1]"
list_of_virtual_account_present ="(//ul[contains(@class,'styles__ListWrapper-sc-1ojjgzg-11')])[2]//div[@class='_1RZFLstJ_MSq2-Riva77G6']"
first_virtual_group_expand ="(//ul[contains(@class,'styles__ListWrapper-sc-1ojjgzg-11 ')]//div[contains(@class,'styles__CollapseBtn')])[1]"
va_name = "(//div[contains(@class,'styles__Name-sc-1ojjgzg-3')])[2]"
va_name_title = '//div[text()="TEXT_PLACEHOLDER"]'
un_expand_first_virtual_group = "//div[@class='styles__Container-sc-1sg8k88-1 eTiAkx']"
virtual_account_search_result = "//div[@data-testid='virtualAccounts-searchList-resultItem']"
pencil_icon_on_virtual_group = "//*[contains(@class,'styles__EditIcon-sc-1mbvlf5-5')]"
edit_name_virtual_account_group = "//input[@id='virt-entity-name']"
virtual_account_name ="//div[contains(@class,'styles__Label-sc-1mbvlf5-4')]"