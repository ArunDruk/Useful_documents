"""This module contains the locators which are used in customer management page automation"""
__author__ = "Neha Jha"
__copyright__ = "Copyright (C) 2021 SupportLogic"


# xpath
customer_list = "(//div[contains(@class,'List__ListCard-sc-eox0h7-1')])[1]"
#vertical_dots_on_list = "(//*[name()='svg' and @data-icon='vertical-dots'])[1]"
vertical_dots_on_list = "(//*[@data-icon='vertical-dots'])[1]"
download_csv = "(//li[text()='Download CSV'])[1]"
delete_list = "(//li[text()='Delete list'])[1]"
edit_list = "(//li[text()='Edit list'])[1]"
switch_sort_direction = "(//li[text()='Switch sort direction'])[1]"
customer_field = "//div[contains(@class,'OptionEditor__DropdownTrigger-sc-7l1x8n-6' ) and  text()=' Customer Fields']"
add_note_icon = "(//div[contains(@class,'NotesTrigger__Container')])[1]"
create_new_list = "//button[@aria-label='Create new list']"
likely_to_be_escalated_cases = "(//span[@class='_3wRfdoCeYuFb7PRAcBEJ1'])[1]"
production_issue = "(//span[@class='_3wRfdoCeYuFb7PRAcBEJ1'])[2]"
first_client_list = "(//div[contains(@class,'Item__Header-sc-nvewbn-0')])[1]"
add_button = "//button[text()='Add']"
expand_list = "(//div[contains(@class,'List__ExpandTrigger-sc-eox0h7-6')])[1]"
list_present_on_dashboard = "//div[contains(@class,'List__ListCard-sc-eox0h7-1')]"
delete_on_delete_pop_up = "//button[text()='Delete']"
choose_list_pop_up = "//div[@class='_3XF84LfNUleGY_nIXUoivF']"
filter_by_list = "//div[@class='FiltersEditor__Container-sc-1xulcbb-0 eyHvVs']"
vertical_dots_list = "(//ul[contains(@class,'ContextMenu__List-sc-1dzej2g-0')])[1]"
creation_date = "//a[text()='Creation Date']"
health_assessment = "//a[text()='Health Assessment']"
one_year_option = "//div[text()='<1 year']"
filter_button = "//button[text()='Filter']"
apply_changes = "//button[text()='Apply changes']"
total_cases = "(//div[contains(@class,'Item__Footer-sc-nvewbn-4 ')]//strong)[1]"
cross_button = "(//div[contains(@class,'List__CloseTrigger')])[1]"
add_new_notes = "//span[contains(text(),'Add a new note')]"
add_a_notes = "//button[contains(text(),'Add a note')]"
add_notes = "//textarea[@class='_9OfdKOAwSr0vecTwzqPoR' or @placeholder='Add a note to this customer']"
first_notes_list = (
    "(//div[@class='_7IgUO03xKZwOVEnN5RD1D']//div[@class='_22gS9f2QOXcMnyX8ZO2dDK'])[1]"
)
edit_icon_notes = "(//div/*[name()='svg' and @data-icon='edit-light'])[1]"
delete_icon = "(//div/*[name()='svg' and @data-icon='trash' and @class='_31AntCaPLMVfEZlTG489gr'])[1]"
save_button = "//button[text()='Save']"
client_with_production_issue = "//div[contains(@class,'ListOption__Title')]//strong[text()='production issues']"
time_period = "//div[text()='Time Period']//div[@data-testid='common-dropdown-btn']"
time_period_in_list = "(//div[contains(@class,'List__ListCardBody')])[1]//div[@data-testid='common-dropdown-btn']"
time_period_menu = "//ul[@class='_2aa1vapzx54uYEruF5uHOD']"
list_name = "(//p[contains(text(), 'Ranked by #')]/preceding-sibling::h3)[1]"
notes_list = (
    "//div[@class='_7IgUO03xKZwOVEnN5RD1D']//div[@class='_22gS9f2QOXcMnyX8ZO2dDK']"
)
last_six_month_option = "(//ul[@class='_2aa1vapzx54uYEruF5uHOD']//div[text()='Last 6 months'])[1]"
profile ="//div[@class='pyRdl8ZTmdBJVOM9cwYD']"
ranked_by_case_volume= "//div[contains(@class,'ListOption__Title')]//strong[text()='ranked by case volume']"
time_period_list="(//div[@data-testid='common-dropdown-btn'])[1]//div[@class='TimePeriodIndicator__DropdownTrigger-sc-9y5t9e-1 ieTJYU']"
all_time="(//ul[@class='_2aa1vapzx54uYEruF5uHOD']//div[text()='All time'])[1]"
likely_to_be_escalated_in_profile="//span[text()='Likely to escalate']//ancestor::button//span[2]"
cross_button_notes = "//*[name()='svg' and @data-icon='cross'and @class='_2c3YbAr5fvtUAITf0V9LgL']"
notes_title="(//div[@class='_2uGvPGSqtHH9yVxnAv4J_V']//div[@class='_10ke10bnRN1ez7e5pkQ9Hm'])[1]"
edit_notes="//textarea"
first_list_first_client="(//div[contains(@class,'List__ListCard-sc-eox0h7-1')])[1]//div[contains(@class,'common__Container-sc-1wctfu1-0')]"
add_note_pop_up="//div[@class='_1Kzhsx1-FsiWHRYLflYi9W']"
creating_list_name ="//input[@placeholder='Enter a list name (optional)']"
list_name_number_list_present_on_dashboard = "(//p[contains(text(), 'Ranked by #')]/preceding-sibling::h3)"
standard_list = "//button[@data-testid='customersBoard-welcomePage-startButton-standard_list_button']"
custom_list ="//button[@data-testid='customersBoard-welcomePage-startButton-create_custom_list_button']"
cancel_button ="//button[text()='Cancel']"
ranked_by_health_assessment = "//div[contains(@class,'ListOption__Container-sc')]//div//strong[text()='ranked by health assessment']"
click_on_health_assessment_in_filter_by_list_pop_up = "//a[text()='Health Assessment']"
ahs_badge ="(//div[contains(@class,'AHSBadge__Wrapper')])[1]"
health_assessment_mark = "//div[text()='text_place_holder']"

customer_name_in_customer_list = "(//div[contains(@class,'ReactVirtualized__Grid ReactVirtualized__List')]//div[contains(@class,'common__Container')]//div[contains(@class,'Item__Header-sc-nvewbn-0')])[1]//h4"

customer_name_in_customer_list = "(//div[contains(@class,'List__ListCard')])[1]//div[contains(@class,'common__Container')]//div[contains(@class,'Item__Header-sc-nvewbn-0')][1]//h4"
ahs_score_chat = "//div[contains(@class,'AHSScoreChart__Label')]//h2"








