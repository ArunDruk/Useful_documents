"""This page has the locators for elements in the case assignment page"""

# css-selectors
case_list_tab_css = "button[data-testid=caseAssignment-sideListTab-{tab_name}-tab]"

case_queue_selector_dropdown_css = "div[data-testid=caseAssignmentPage-caseAssignmentTab-queueOption-trigger]"
case_sort_button_css = "button[data-testid$=sortButton]"
case_sort_by_selector_dropdown_css = "div[data-testid$=sortTrigger]"

case_cards_in_list_css = "div[data-testid=caseAssignmentPage-caseList-sideListItem] > div"
selected_card_css = "div[data-testid=caseAssignmentPage-caseList-sideListItem] > div._3OWPSBDFrLxS3kuwAbCiea"
selected_card_customer_name_css = selected_card_css + " span[data-testid$=cardTitle]"
selected_card_case_id_css = selected_card_css + " span[data-testid$=cardId]"
selected_card_case_subject_css = selected_card_css + " span[data-testid$=cardSubject]"
selected_card_case_priority_css = selected_card_css + " div[data-testid$=priorityLabel]"

summary_view_customer_name_css = "[data-testid='supportHub-caseCustomer-CustomerName']"
summary_view_case_id_css = "span[data-testid=supportHub-caseSummary-id]"
summary_view_case_title_css = "span[data-testid=supportHub-caseSummary-subject]"
summary_view_case_priority_css = "div[data-testid=common-priorityLabel]"
