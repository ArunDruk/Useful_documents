"""This page has the locators for elements shared across the application"""

# xpath
start_onboarding_button = (
    "//button[text()='Got it!'] | //button[text()='Let`s get started!'] | "
    "//button[text()='Set up your summary view!'] | //button[text()='Standard list']"
)

no_results = "//div[text()='No results found']"
preference_popup_close_btn = "//*[name()='svg' and @data-icon='cross']//parent::button"

# css-selectors
animated_loader_large_css = "div.JaVkbzmsYVmyJhFYJbJgS"
module_locked_icon = "#app_content svg[data-icon=lock]"
sl_sales_contact = "a[href='mailto:sales@supportlogic.io']"

search_icon_css = "div[data-testid=global-search-trigger]"
search_input_box_css = "input[data-testid=global-search-input]"
search_results_css = "div[data-testid=global-search-caseView-listItem]"

user_menu_icon_css = "[data-testid=layout-header-userMenu] .QOkJ2Wl5yIUHYIreGnQpD"
user_menu_option_css = "a[data-testid=layout-header-userMenu-{option}]"

preference_favorite_customers_css = "button._1XYbwpD20LwgQPtoi6iTtb"
preference_fav_customers_search_css = "input[placeholder='Add customer']"
preference_fav_customers_search_result_item_css = "li#-item-0[role=option]"
preference_fav_customers_item_css = "div.customerItem"
preference_fav_support_engineer_xpath = "(//ul[@class='_3G9lhMa0vZn9lizDr2PZUF']//li//button)[2]"
preference_fav_search_item_xpath ="//input[contains(@placeholder,'Add')]"
agents_in_fav_tab = "//div[contains(@class,'agentItem')]//div[text()='agents_name']"
support_engineer_fav_remove ="//div[text()='agents_name']//ancestor::div[@class='_1gmM4Jvz4ulis1GkEoNIn4 agentItem']//*[@data-icon='star-2']"

