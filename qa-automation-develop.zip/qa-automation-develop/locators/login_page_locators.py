"""This module contains the locators which are used in login page automation"""

# ID
email_sign_in_option_id = "sign-in-email"

email_textbox_id = "inputEmail"
password_textbox_id = "inputPassword"

sign_in_button_id = "email-login-button"
