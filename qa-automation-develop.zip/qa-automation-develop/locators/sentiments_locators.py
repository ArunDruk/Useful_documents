"""This page has the locators for elements in the sentiments page"""

# xpath
no_sentiments_found_banner: str = "//h2[text()='No sentiments found']"

# css-selectors
selected_case_status_css = "button._2_mbuVbafrxP6zIgPauACi"

total_sentiments_count_css = "div._2WdWp3YqorSutZFtzQ96vD"
start_date_css = "div[data-testid=sentimentExplorer-datePickerTrigger]"
end_date_css = "span._2yDPKZTYThUiI3RK-dYi2f"
heat_wave_plot_css = "div.chart-wrapper"

sentiment_graph_right_slider_css = "[data-testid=sentimentExplorer-sentimentExplorerContent-rightSliderArrowBtn]"
sentiment_graph_left_slider_css = "[data-testid=sentimentExplorer-sentimentExplorerContent-leftSliderArrowBtn]"

sentiment_tile_css = "rect[data-testid^=supportHub-sentimentChart]:nth-child({index})"
sentiment_tooltip_css = "div.highcharts-tooltip-container"
sentiment_tooltip_customer_name_css = "span.aGgIeDEY7ysnfFVqVG_gU"
sentiment_tooltip_case_id_css = "span._2ZgQYZ11xx3P71mhJ8lRGP"
sentiment_type_in_tooltip_css = "div._3fFwxeY9szBEQjKzVB3-l_"

case_status_filter_css = "button[data-testid=case-status--option--{status}]"
message_type_filter_css = "label[data-testid^=sentiments--message-type-filter--{type}]"

sentiment_filter_css = "div[data-testid='sentiments--chart-legend-type--{group}']"
sentiment_filter_count_css = sentiment_filter_css + " span span"
selected_sentiment_filter_css = sentiment_filter_css + " svg[data-icon=check]"

go_to_previous_month_css = "div[data-testid=globalDateRangePicker-NavButtonPrev]"
go_to_next_month_css = "div[data-testid=globalDateRangePicker-NavButtonNext]"
cancel_date_picker_button_css = "button[data-testid$=startDayPicker-cancelButton]"
apply_start_date_btn_css = "button[data-testid$=startDayPicker-applyButton]"
reset_date_filter_css = "button[data-testid$=startDayPicker-resetDaysButton]"

current_visible_month_css = "div.CalendarMonth[data-visible=true] strong"
select_day_css = "div.CalendarMonth[data-visible=true] td[aria-label*='{date}']"

delta_chart_top_down_arrow_button_css = "._2TplIQtANrIk0Sw3k2ZAU5"
delta_chart_top_down_arrow_tooltip_css = ".custom-tooltip .RpdJxNjhyIWX_kuXYr61d"
delta_chart_top_down_arrow_tooltip_title_css = "._2fxyZHXEb2PMRwOyn_v8U5"

delta_chart_i_icon_css = "._3WosJYlcBxxV8LmowJ2Wv5"
i_icon_info_tooltip_css = ".hint-tooltip"

sentiment_chart_x_axis_label_css = "div.highcharts-xaxis-labels"
sentiment_score_chart_plot_css = "div._22VI1spyXzTltSBp116BXx svg.highcharts-root"
sentiment_score_chart_tooltip_css = "div._1BM-L8k7LJHjcXpdkuLutZ"
