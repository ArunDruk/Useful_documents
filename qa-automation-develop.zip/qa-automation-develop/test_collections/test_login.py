"""Test class for Login Page"""
__author__ = "Praveen Nagajothi"
__copyright__ = "Copyright (C) 2021 SupportLogic"

import logging
import os

import pytest
from pytest_testrail.plugin import pytestrail

from constants import author_praveen_nj, default_url
from pom_library.login_page_new import LoginPage

LOGGER: logging.Logger = logging.getLogger(__name__)


@pytest.mark.run(order=1)
@pytest.mark.usefixtures("driver")
class TestLogin:
    @author_praveen_nj
    @pytestrail.case("C2264")
    def test_email_login(self, driver):
        login = LoginPage(driver)

        username = os.getenv("SL_USER")
        password = os.getenv("SL_PWD")

        if not username:
            pytest.skip("The environment variable 'SL_USER' needs to be set.")

        if not password:
            pytest.skip("The environment variable 'SL_PWD' needs to be set.")

        sign_in_page_url = os.getenv("SL_URL", default=default_url)
        if not sign_in_page_url.startswith("https://"):
            sign_in_page_url = "https://" + sign_in_page_url

        LOGGER.info(f"Navigating to {sign_in_page_url}")
        driver.get(sign_in_page_url)
        assert "Login" in driver.title, "Failed to navigate to login page"

        login.login_with_email(username, password)
        LOGGER.info("validating login state..")
        try:
            target_url_contains = "/support/"
            assert login.validate_url(target_url_contains), "Login Failed"
        except AssertionError:
            target_url_contains = "page-not-found"
            assert login.validate_url(target_url_contains), "Login Failed"
        LOGGER.info("Login Successful")
