"""Test class for case assignment page"""
__author__ = "Praveen Nagajothi"
__copyright__ = "Copyright (C) 2021 SupportLogic"

import logging
import time
from datetime import date

import pytest
from pytest_testrail.plugin import pytestrail
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By

import utils
from constants import author_praveen_nj, sanity_test
from enums import CaseAssignmentTabs, DeleteShift, NavbarItem, ShiftOccurrence
from locators import date_picker_locators as dpl
from locators import shift_calendar_locators as scl
from pom_library.api_keywords import ApiKeywords
from pom_library.case_assignment import CaseAssignment
from pom_library.commons import Commons
from pom_library.date_picker import DatePicker
from pom_library.helper_methods import HelperMethods
from pom_library.navbar import Navbar
from pom_library.shift_calendar import ShiftCalendar

LOGGER: logging.Logger = logging.getLogger(__name__)


class TestCaseAssignment:
    @pytest.fixture(scope="class", autouse=True)
    def case_assignment_setup(self, driver):
        navbar = Navbar(driver)
        commons = Commons(driver)
        api_keywords = ApiKeywords(driver)

        if not (
            NavbarItem.CASE_ASSIGNMENT.value
            in api_keywords.get_active_dashboard_pages()
        ):
            pytest.skip("User does not have access to Case Assignment page")

        commons.wait_for_loader_to_disappear()
        current_page_url: str = navbar.navigate_to_navbar_page(
            NavbarItem.CASE_ASSIGNMENT
        )
        assert "assignment" in current_page_url, "Failed to load Case Assignment page"
        commons.start_module_onboarding()

    @pytest.fixture(scope="class")
    def shift_calendar_setup(self, driver):
        commons = Commons(driver)
        api_keywords = ApiKeywords(driver)
        shift_calendar = ShiftCalendar(driver)

        if not api_keywords.has_manage_shift_permission():
            pytest.skip("User does not have 'Manage Shifts' permission")

        shift_calendar.go_to_shift_assignment_page()
        assert driver.current_url.endswith(
            "assignment-shifts"
        ), "Failed to navigate to shift assignments page"
        commons.start_module_onboarding()
        assert commons.is_element_visible((By.CSS_SELECTOR, dpl.date_picker_toggle_css))

        yield
        shift_calendar.go_back_to_case_assignment_page()

    @pytest.fixture(scope="class", autouse=True)
    def cleanup_shifts(self, driver):
        api_keywords = ApiKeywords(driver)

        yield
        vstar_accounts = api_keywords.query_vgroup()
        for account in vstar_accounts:
            if (
                account["gtype"] == "virtual_shift"
                and "automation shift" in account["name"]
            ):
                api_keywords.delete_vgroup(account["id"])

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C816")
    @pytest.mark.parametrize("tab_name", [*CaseAssignmentTabs])
    def test_case_list_loading(self, driver, tab_name):
        case_assignment = CaseAssignment(driver)

        try:
            case_assignment.switch_to_tab(tab_name)
            assert (
                case_assignment.check_visibility_of_case_list()
            ), "No cases are available or enabled"
            LOGGER.info(f"{tab_name.name} tab case list section is present and visible")
        finally:
            # cleanup
            case_assignment.switch_to_tab(CaseAssignmentTabs.UNASSIGNED)

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C2239")
    def test_case_card_data_against_case_summary_data(self, driver):
        commons = Commons(driver)
        case_assignment = CaseAssignment(driver)

        commons.wait_for_loader_to_disappear()
        assert utils.validate_values_equals(
            "Customer name in card",
            case_assignment.get_customer_name_from_selected_card(),
            "Customer name in summary",
            case_assignment.get_customer_name_from_summary(),
        )
        assert utils.validate_values_equals(
            "Case ID in card",
            case_assignment.get_case_id_from_selected_card(),
            "Case ID in summary",
            case_assignment.get_case_id_from_summary(),
        )
        assert utils.validate_values_equals(
            "Case subject in card",
            case_assignment.get_case_subject_from_selected_card(),
            "Case subject in summary",
            case_assignment.get_case_subject_from_summary(),
        )
        assert utils.validate_values_equals(
            "Case priority in card",
            case_assignment.get_case_priority_from_selected_card(),
            "Case priority in summary",
            case_assignment.get_case_priority_from_summary(),
        )

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C6582")
    def test_visit_shift_calendar_page(self, driver):
        api_keywords = ApiKeywords(driver)
        shift_calendar = ShiftCalendar(driver)

        if not api_keywords.has_manage_shift_permission():
            pytest.skip(reason="User does not have 'Manage Shifts' permission")

        try:
            shift_calendar.go_to_shift_assignment_page()
            assert driver.current_url.endswith(
                "assignment-shifts"
            ), "Failed to navigate to shift assignments page"
        finally:
            shift_calendar.go_back_to_case_assignment_page()

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C6583")
    def test_create_new_shift(self, driver, shift_calendar_setup):
        shift_calendar = ShiftCalendar(driver)

        shift_name: str = utils.generate_test_run_id("automation shift")

        try:
            shift_calendar.open_add_new_shift_popup()
            shift_calendar.enter_shift_name(shift_name)
            shift_calendar.change_default_assignment_hour("11:00 am", "8:00 pm")
            shift_calendar.change_default_working_hours("2:00 pm", "11:00 pm")
            shift_calendar.deselect_occurrence(
                (ShiftOccurrence.THU, ShiftOccurrence.FRI)
            )
            shift_calendar.click_create_button()
        except Exception as e:
            shift_calendar.click_cancel_button()
            raise e

        shift_calendar.hover_on_shift_bar(shift_name)
        shift_details_tooltip_content: str = shift_calendar.get_element_text_or_value(
            (By.CSS_SELECTOR, scl.visible_shift_details_tooltip_css),
            message="Failed to get text from shift details tooltip",
        )
        LOGGER.info(f"Shift tooltip details: {shift_details_tooltip_content}")
        assert (
            shift_name in shift_details_tooltip_content
        ), "Expected shift name != Shift name in tooltip"
        assert (
            "11:00 AM-08:00 PM" in shift_details_tooltip_content
        ), "Expected assignment hours != Assignment hours in tooltip"
        assert (
            "02:00 PM-11:00 PM" in shift_details_tooltip_content
        ), "Expected working hours != Working hours in tooltip"
        assert (
            "Mon-Wed" in shift_details_tooltip_content
        ), "Expected occurrence != occurrence in tooltip"

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C6586")
    def test_setting_shift_occurrence(self, driver, shift_calendar_setup):
        shift_calendar = ShiftCalendar(driver)

        shift_name: str = utils.generate_test_run_id("automation shift")

        try:
            shift_calendar.open_add_new_shift_popup()
            shift_calendar.enter_shift_name(shift_name)
            # deselect Mon, Wed & Fri
            shift_calendar.deselect_occurrence(
                (ShiftOccurrence.MON, ShiftOccurrence.WED, ShiftOccurrence.FRI)
            )
            # select Tue, Thu & Sat
            shift_calendar.select_occurrence(
                (ShiftOccurrence.TUE, ShiftOccurrence.THU, ShiftOccurrence.SAT)
            )
            shift_calendar.click_create_button()
        except Exception as e:
            shift_calendar.click_cancel_button()
            raise e

        shift_calendar.hover_on_shift_bar(shift_name)
        shift_details_tooltip_content: str = shift_calendar.get_element_text_or_value(
            (By.CSS_SELECTOR, scl.visible_shift_details_tooltip_css),
            message="Failed to get text from shift details tooltip",
        )
        LOGGER.info(f"Shift tooltip details: {shift_details_tooltip_content}")
        assert (
            "Tue,Thu,Sat" in shift_details_tooltip_content
        ), "Expected occurrence != occurrence in tooltip"

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C6585")
    def test_customize_assignment_and_working_hours(self, driver, shift_calendar_setup):
        shift_calendar = ShiftCalendar(driver)

        shift_name: str = utils.generate_test_run_id("automation shift")

        try:
            shift_calendar.open_add_new_shift_popup()
            shift_calendar.enter_shift_name(shift_name)
            shift_calendar.change_default_assignment_hour("11:00 am", "8:00 pm")
            shift_calendar.change_default_working_hours("2:00 pm", "11:00 pm")
            shift_calendar.deselect_occurrence(
                (ShiftOccurrence.THU, ShiftOccurrence.FRI)
            )
            # customize assignment hours
            shift_calendar.check_assignment_hour_customize_checkbox()
            shift_calendar.change_custom_assignment_hour_by_day(
                {ShiftOccurrence.TUE: ("12:00 pm", "9:00 pm")}
            )
            # customize working hours
            shift_calendar.check_working_hour_customize_checkbox()
            shift_calendar.change_custom_working_hour_by_day(
                {ShiftOccurrence.MON: ("11:00 am", "8:00 pm")}
            )
            shift_calendar.click_create_button()
        except Exception as e:
            shift_calendar.click_cancel_button()
            raise e

        try:
            assign_agents_button: str = scl.assign_agents_button_above_shift_bar.format(
                shift_name=shift_name
            )
            shift_calendar.click_on_element((By.XPATH, assign_agents_button))

            assignment_hour_details = shift_calendar.get_element_text_or_value(
                (By.CSS_SELECTOR, scl.assignment_hours_details_assign_agents_popup_css),
                message="Failed to get assignment hours text from assign agents modal",
            )
            LOGGER.info(assignment_hour_details)

            working_hour_details = shift_calendar.get_element_text_or_value(
                (By.CSS_SELECTOR, scl.working_hours_details_assign_agents_popup_css),
                message="Failed to get assignment hours text from assign agents modal",
            )
            LOGGER.info(working_hour_details)
        finally:
            # close the assign agents modal
            shift_calendar.click_on_element(
                (By.CSS_SELECTOR, scl.assign_agent_cancel_button_css),
                message="Failed to close assign agents modal window",
            )

        expected_assignment_hours: str = (
            "Mon\n11:00 AM-08:00 PM\nTue\n12:00 PM-09:00 PM\nWed\n11:00 AM-08:00 PM"
        )
        assert (
            expected_assignment_hours in assignment_hour_details
        ), "Customized time is not reflected in assignment hour details"

        expected_working_hours: str = (
            "Mon\n11:00 AM-08:00 PM\nTue\n02:00 PM-11:00 PM\nWed\n02:00 PM-11:00 PM"
        )
        assert (
            expected_working_hours in working_hour_details
        ), "Customized time is not reflected in working hour details"

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C6587")
    def test_edit_shift(self, driver, shift_calendar_setup):
        shift_calendar = ShiftCalendar(driver)

        shift_name: str = utils.generate_test_run_id("automation shift")
        updated_shift_name: str = f"{shift_name} edit"

        try:
            shift_calendar.open_add_new_shift_popup()
            shift_calendar.enter_shift_name(shift_name)
            shift_calendar.click_create_button()
        except Exception as e:
            shift_calendar.click_cancel_button()
            raise e

        shift_calendar.click_on_shift_bar(shift_name)
        time.sleep(2)
        shift_calendar.enter_shift_name(updated_shift_name)
        shift_calendar.click_save_button()

        shift_bar_locator: str = scl.individual_shift_bar_css.format(
            shift_name=updated_shift_name
        )
        assert shift_calendar.is_element_visible(
            (By.CSS_SELECTOR, shift_bar_locator)
        ), "Edited shift name is not reflected"

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C6704")
    @pytest.mark.xfail(reason="https://app.clickup.com/t/2277599/AA-20184")
    def test_delete_shift_for_today(self, driver, shift_calendar_setup):
        date_picker = DatePicker(driver)
        shift_calendar = ShiftCalendar(driver)

        shift_name: str = utils.generate_test_run_id("automation shift")
        try:
            # create a shift
            try:
                shift_calendar.open_add_new_shift_popup()
                shift_calendar.enter_shift_name(shift_name)
                shift_calendar.select_occurrence(
                    (ShiftOccurrence.SAT, ShiftOccurrence.SUN)
                )
                shift_calendar.click_create_button()
            except Exception as e:
                shift_calendar.click_cancel_button()
                raise e

            shift_calendar.click_on_shift_bar(shift_name)
            time.sleep(1)
            shift_calendar.click_edit_popup_delete_button()
            # delete shift
            try:
                shift_calendar.click_delete_popup_radio_button(DeleteShift.TODAY)
                shift_calendar.click_delete_popup_delete_button()
                time.sleep(2)
            except Exception as e:
                shift_calendar.click_delete_popup_cancel_button()
                raise e

            today_date = date.today().strftime("%B %d")
            locator = scl.shift_bar_by_date.format(
                date=today_date, shift_name=shift_name
            )
            assert (
                shift_calendar.is_element_visible((By.XPATH, locator), 5) is False
            ), "Failed to delete shift for today"
            # switch to next week in datepicker
            try:
                date_picker.open_date_picker()
                date_picker.select_next_week_shortcut()
                date_picker.apply_selected_date_filter()
            except Exception as e:
                date_picker.cancel_date_filter_selection()
                raise e

            assert shift_calendar.has_shift(
                shift_name
            ), "Shift is not present when deleting using `For today` option"
        finally:
            shift_calendar.click_on_shift_bar(shift_name)
            shift_calendar.click_edit_popup_delete_button()
            shift_calendar.click_delete_popup_radio_button(DeleteShift.DELETE_ENTIRELY)
            shift_calendar.click_delete_popup_delete_button()
            if date_picker.get_applied_date_filter() != "This week":
                date_picker.open_date_picker()
                date_picker.select_this_week_shortcut()
                date_picker.apply_selected_date_filter()

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C6705")
    def test_delete_shift_for_today_and_following(self, driver, shift_calendar_setup):
        date_picker = DatePicker(driver)
        helpers = HelperMethods(driver)
        shift_calendar = ShiftCalendar(driver)

        shift_name: str = utils.generate_test_run_id("automation shift")
        try:
            # create a shift
            try:
                shift_calendar.open_add_new_shift_popup()
                shift_calendar.enter_shift_name(shift_name)
                shift_calendar.select_occurrence(
                    (ShiftOccurrence.SAT, ShiftOccurrence.SUN)
                )
                shift_calendar.click_create_button()
            except Exception as e:
                shift_calendar.click_cancel_button()
                raise e
            # set the datepicker to 2 months from this week
            try:
                date_picker.open_date_picker()
                date_picker.select_this_week_shortcut()
                helpers.click_on_element((By.CSS_SELECTOR, dpl.next_month_button_css))
                time.sleep(1)
                helpers.click_on_element((By.CSS_SELECTOR, dpl.next_month_button_css))
                helpers.click_on_element((By.CSS_SELECTOR, dpl.week_rows_css))
                date_picker.apply_selected_date_filter()
            except Exception as e:
                date_picker.cancel_date_filter_selection()
                raise e

            shift_calendar.click_on_shift_bar(shift_name)
            time.sleep(1)
            shift_calendar.click_edit_popup_delete_button()
            try:
                shift_calendar.click_delete_popup_radio_button(
                    DeleteShift.TODAY_AND_FOLLOWING
                )
                shift_calendar.click_delete_popup_delete_button()
                time.sleep(5)
            except TimeoutException as e:
                shift_calendar.click_delete_popup_cancel_button()
                raise e

            assert (
                shift_calendar.has_shift(shift_name) is False
            ), "Shift is present after deleting today & following occurrences"
            # change datepicker to next week
            try:
                date_picker.open_date_picker()
                date_picker.select_next_week_shortcut()
                date_picker.apply_selected_date_filter()
            except TimeoutException as e:
                date_picker.cancel_date_filter_selection()
                raise e
            assert shift_calendar.has_shift(
                shift_name
            ), "Shift is not present in past dates from the day of deletion"
        finally:
            shift_calendar.click_on_shift_bar(shift_name)
            shift_calendar.click_edit_popup_delete_button()
            shift_calendar.click_delete_popup_radio_button(DeleteShift.DELETE_ENTIRELY)
            shift_calendar.click_delete_popup_delete_button()
            if date_picker.get_applied_date_filter() != "This week":
                date_picker.open_date_picker()
                date_picker.select_this_week_shortcut()
                date_picker.apply_selected_date_filter()

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C6706")
    def test_delete_shift_entirely(self, driver, shift_calendar_setup):
        date_picker = DatePicker(driver)
        shift_calendar = ShiftCalendar(driver)

        shift_name: str = utils.generate_test_run_id("automation shift")
        try:
            # create a shift
            try:
                shift_calendar.open_add_new_shift_popup()
                shift_calendar.enter_shift_name(shift_name)
                shift_calendar.select_occurrence(
                    (ShiftOccurrence.SAT, ShiftOccurrence.SUN)
                )
                shift_calendar.click_create_button()
            except Exception as e:
                shift_calendar.click_cancel_button()
                raise e

            shift_calendar.click_on_shift_bar(shift_name)
            time.sleep(1)
            shift_calendar.click_edit_popup_delete_button()
            try:
                shift_calendar.click_delete_popup_radio_button(
                    DeleteShift.DELETE_ENTIRELY
                )
                shift_calendar.click_delete_popup_delete_button()
                time.sleep(5)
            except TimeoutException as e:
                shift_calendar.click_delete_popup_cancel_button()
                raise e

            assert (
                shift_calendar.has_shift(shift_name) is False
            ), "Shift is present after deleting all occurrences"
            # change datepicker to next week
            try:
                date_picker.open_date_picker()
                date_picker.select_next_week_shortcut()
                date_picker.apply_selected_date_filter()
            except TimeoutException as e:
                date_picker.cancel_date_filter_selection()
                raise e
            assert (
                shift_calendar.has_shift(shift_name) is False
            ), "Shift is present in next week after deleting all occurrences"
        finally:
            if date_picker.get_applied_date_filter() != "This week":
                date_picker.open_date_picker()
                date_picker.select_this_week_shortcut()
                date_picker.apply_selected_date_filter()

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C6707", "C6708", "C6709")
    @pytest.mark.parametrize(
        "shortcut_function, expected_value",
        [
            ("select_last_week_shortcut", "Last week"),
            ("select_this_week_shortcut", "This week"),
            ("select_next_week_shortcut", "Next week"),
        ],
    )
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_datepicker_shortcuts(
        self, driver, shift_calendar_setup, shortcut_function, expected_value
    ):
        date_picker = DatePicker(driver)

        try:
            date_picker.open_date_picker()
            getattr(date_picker, shortcut_function)()
            selected_week_start_date_label: str = driver.find_element(
                By.CSS_SELECTOR, dpl.selected_week_start_date_css
            ).get_attribute("aria-label")
            selected_week_end_date_label: str = driver.find_element(
                By.CSS_SELECTOR, dpl.selected_week_end_date_css
            ).get_attribute("aria-label")
            date_picker.apply_selected_date_filter()
        except TimeoutException as e:
            date_picker.cancel_date_filter_selection()
            raise e

        active_datepicker_value: str = date_picker.get_applied_date_filter()
        assert (
            active_datepicker_value == expected_value
        ), f"{active_datepicker_value} != {expected_value}"

        start_date_string: str = utils.convert_date_string_to_different_format(
            " ".join(selected_week_start_date_label.split()[-3:]), "%B %d, %Y", "%B %d"
        )
        end_date_string: str = utils.convert_date_string_to_different_format(
            " ".join(selected_week_end_date_label.split()[-3:]), "%B %d, %Y", "%B %d"
        )
        assert (
            start_date_string
            in driver.find_element(By.CSS_SELECTOR, scl.app_content_body_css).text
        ), f"{start_date_string} is not present in shift calendar"
        assert (
            end_date_string
            in driver.find_element(By.CSS_SELECTOR, scl.app_content_body_css).text
        ), f"{end_date_string} is not present in shift calendar"
