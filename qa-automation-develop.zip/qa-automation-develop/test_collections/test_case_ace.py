"""This is the test class for ACE  page"""
__author__ = "Neha Jha", "Nalini Govindaraj"
__copyright__ = "Copyright (C) 2021 SupportLogic"

import logging
import os
import time

import pytest

import os

from pom_library import console_page, filters
from pytest_testrail.plugin import pytestrail
from selenium.webdriver.common.by import By
from constants import author_neha_jha, author_praveen_nj, author_nalini_govindaraj,regression_test, sanity_test

from constants import (
    author_neha_jha,
    author_praveen_nj,
    author_nalini_govindaraj,
    author_sutapa_g,
    regression_test,
    sanity_test,
)
from enums import ControlCenterMenuItem, ManageUser, NavbarItem
from locators import ace_locator as al, common_locators as cl
from pom_library import ace_page, date_picker, manage_user_page
from pom_library.commons import Commons
from pom_library.navbar import Navbar
from pom_library.support_hub import SupportHub

LOGGER = logging.getLogger(__name__)


@pytest.mark.usefixtures("driver")
class TestCaseEvaluation:
    @pytest.fixture()
    def ace_setup(self, driver):
        navbar = Navbar(driver)
        commons = Commons(driver)

        current_url = navbar.navigate_to_navbar_page(NavbarItem.CASE_EVALUATION)
        assert "evaluations" in current_url, "failed to load ace page"
        commons.start_module_onboarding()
        yield
        try:
            support_hub = SupportHub(driver)
            support_hub.close_support_hub_window()
            ace_module = TestCaseEvaluation(driver)
            ace_module.click_on_delete_button()
        except:
            LOGGER.info("support window is not displayed")

    @sanity_test
    @author_neha_jha
    def test_recommended_for_review(self, driver, ace_setup):
        page = ace_page.CaseEvaluation(driver)
        support_hub = SupportHub(driver)
        number_of_case_in_recommended_view = (
            page.get_number_case_present_in_recommended_view()
        )
        if "0 cases " not in number_of_case_in_recommended_view:
            page.click_on_case_list()
            assert (
                support_hub.check_visibility_of_support_hub()
            ), "failed to display Support Hub"
            support_hub.close_support_hub_window()
        else:
            LOGGER.info(f"{number_of_case_in_recommended_view} in recommended viw")
            assert False

    @sanity_test
    @author_neha_jha
    @pytestrail.case('C2231')
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_search_functionality(self, driver, ace_setup):
        page = ace_page.CaseEvaluation(driver)
        number_of_case_in_recommended_view = (
            page.get_number_case_present_in_recommended_view()
        )
        if "0 cases " not in number_of_case_in_recommended_view:
            case_id = page.get_id_of_first_case()
            page.search_id_in_search_bar(case_id)
            case_id_after_search = page.get_id_of_first_case()
            assert case_id_after_search == case_id, "failed to loaded  search result"
        else:
            LOGGER.info(f"{number_of_case_in_recommended_view} in recommended viw")

    @sanity_test
    @author_neha_jha
    def test_search_functionality_invalid_case_id(self, driver, ace_setup):
        page = ace_page.CaseEvaluation(driver)
        number_of_case_in_recommended_view = (
            page.get_number_case_present_in_recommended_view()
        )
        if "0 cases " not in number_of_case_in_recommended_view:
            case_id = page.get_id_of_first_case()
            case_id_data = case_id + "xyz"
            page.search_id_in_search_bar(case_id_data)
            time.sleep(2)
            assert page.get_id_of_first_case() is False, "failed invalid test"
            driver.refresh()
        else:
            LOGGER.info(f"{number_of_case_in_recommended_view} in recommended viw")

    @sanity_test
    @author_neha_jha
    def test_calendar_functionality(self, driver, ace_setup):
        date_pickers = date_picker.DatePicker(driver)
        filter_applied_on_calendar = date_pickers.get_applied_date_filter()
        LOGGER.info(f"filter applied on calendar is {filter_applied_on_calendar}")
        date_pickers.open_date_picker()
        if filter_applied_on_calendar != "Year to date":
            date_pickers.select_year_to_date_shortcut()
            date_pickers.apply_selected_date_filter()
            assert (
                date_pickers.get_applied_date_filter() == "Year to date"
            ), "failed to select year to date"
        elif filter_applied_on_calendar != "Last 3 months":

            date_pickers.select_last_n_months_shortcut()
            date_pickers.apply_selected_date_filter()
            assert (
                date_pickers.get_applied_date_filter() == "Last 3 months"
            ), "fail to select this month"

    @sanity_test
    @author_neha_jha
    def test_CSV_in_recently_viewed(self, driver, ace_setup):
        page = ace_page.CaseEvaluation(driver)
        number_of_case_in_recently_reviewed = (
            page.get_number_case_present_in_recently_review()
        )
        if "0 cases " not in number_of_case_in_recently_reviewed:
            page.click_on_csv_recently_viewed()
            time.sleep(5)
            file = os.path.expanduser("~/Downloads/")
            assert os.path.exists(
                file + "Recently reviewed.csv"
            ), "file is not  founded in download folder"
        else:
            LOGGER.info("O cases in recently viewed")

    @sanity_test
    @author_neha_jha
    def test_agents_functionality_in_recently_reviewed(self, driver, ace_setup):
        page = ace_page.CaseEvaluation(driver)
        support_hub = SupportHub(driver)
        option_applied = page.get_text_of_filter_applied_on_recently_reviewed()
        option_of_agents = ["Agent", "Support Engineer", "TSE"]
        if option_applied not in option_of_agents:
            page.click_on_group_by_filter_in_recently_reviewed()
            page.click_on_agents_option_in_group_by_filter()
            option_applied = page.get_text_of_filter_applied_on_recently_reviewed()
            assert (
                option_applied in option_of_agents
            ), "failed to  select recently reviewed"
            assert option_applied in option_of_agents, "failed to  select recently reviewed"
        else:
            LOGGER.info("Agents filter is already applied")
        number_of_case_in_recently_reviewed = (
            page.get_number_case_present_in_recently_review()
        )
        if "0 cases " not in number_of_case_in_recently_reviewed:
            agent_name = page.get_first_agent_name_or_date_time_group_by()
            page.click_on_first_case_in_recently_reviewed()
            support_hub.check_visibility_of_support_hub()
            agent_name_in_support_hub = support_hub.get_agent_name()
            assert agent_name == agent_name_in_support_hub, " failed to match with agent name"
            agent_name_in_support_hub = support_hub.get_agent_name()
            assert (
                agent_name == agent_name_in_support_hub
            ), " failed to match with agent name"
        else:
            LOGGER.info(
                f"{number_of_case_in_recently_reviewed}  case is present in recently reviewed"
            )

    @sanity_test
    @author_neha_jha
    def test_time_functionality_in_recently_reviewed(self, driver, ace_setup):
        page = ace_page.CaseEvaluation(driver)
        option_applied = page.get_text_of_filter_applied_on_recently_reviewed()
        if option_applied != "Time":
            page.click_on_group_by_filter_in_recently_reviewed()
            page.click_on_time_option_in_group_by_filter()
            option_applied = page.get_text_of_filter_applied_on_recently_reviewed()
            assert option_applied == "Time", "failed to  select recently reviewed"
        else:
            LOGGER.info(f"{option_applied} filter is already applied")
        number_of_case_in_recently_reviewed = (
            page.get_number_case_present_in_recently_review()
        )
        if "0 cases " not in number_of_case_in_recently_reviewed:
            data_time = page.get_first_agent_name_or_date_time_group_by()
            assert data_time[0].isdigit()
        else:
            LOGGER.info(
                f"{number_of_case_in_recently_reviewed}  case is present in recently reviewed"
            )

    @sanity_test
    @author_neha_jha
    def test_tabs_visibility(self, driver, ace_setup):
        page = ace_page.CaseEvaluation(driver)
        page.open_or_close_tab()
        assert page.check_for_tab_is_in_collapse_view(), "failed to close tabs"
        page.open_or_close_tab()
        assert page.check_for_tab_is_expand_state(), "failed to open tabs"
        driver.refresh()

    @pytestrail.case("C904")
    @regression_test
    @author_neha_jha
    def test_case_review_toggle_in_setting(self, driver, ace_setup):
        manage_user = manage_user_page.ManageUser(driver)
        navbar = Navbar(driver)
        current_page_url = navbar.navigate_to_control_center_item(
            ControlCenterMenuItem.MANAGE_USERS
        )
        assert "users" in current_page_url, "failed to load the page"
        current_page_url = navbar.navigate_to_control_center_item(ControlCenterMenuItem.MANAGE_USERS)
        assert "users" in current_page_url, "failed to load the page"
        manage_user.click_on_tabs_in_manage_user(ManageUser.SL_USER)
        manage_user.search_for_user_in_search_box("neha.jha@supportlogic.io")

        toggle_status = manage_user.check_for_toggle_is_on_or_off()
        if toggle_status:
            LOGGER.info("case review toggle is on")
        else:
            manage_user.click_on_toggle_to_on_state()
            toggle_status_should_on = manage_user.check_for_toggle_is_on_or_off()
            assert toggle_status_should_on, "failed to on the case review toggle"

    @pytestrail.case('C6313')
    @regression_test
    @author_nalini_govindaraj
    def test_new_template_creation_flow_empty(self, driver, ace_setup):
        page = ace_page.CaseEvaluation(driver)
        page.click_edit_evaluation_criteria_icon()
        page.click_create_new_button()
        assert page.draft_message_text(), "Unable to find the new checklist created confirmation message"
        page.click_goto_draft()
        draft_exists = page.display_recent_draft()#"Unable to find the recently created draft"
        if draft_exists:
            page.click_recent_draft()#"Unable to click the recently created draft"
            page.click_edit_draft()
        page.click_three_scale()
        page.click_newcategory()
        assert page.category_placeholder(), "Unable to find the category placeholder"
        assert page.item_placeholder(), "Unable to find the item placeholder"
        assert page.description_placeholder(), "Unable to find the description placeholder"
        add_button_state = page.add_button_enabled()
        if add_button_state:
            LOGGER.info("Add button is enabled and test case is failing")
        else:
            assert add_button_state == False, "Add button is enabled"
        page.click_finish_editing() # "Unable to find finish editing button"
        publish_button_state = page.publish_button_enabled()
        if publish_button_state:
            LOGGER.info("Publish button is enabled and test case is failing")
        else:
            assert publish_button_state == False, "Publish button is enabled"


    @regression_test
    @author_praveen_nj
    @pytestrail.case("C908")
    def test_welcome_screen_onboarding(self, driver, ace_setup):
        commons = Commons(driver)

        client_label = commons.get_label_settings().get(
            "customer.label", "customer"
        ).lower()
        client_label_plural = commons.get_label_settings().get(
            "customer.label.plural", "customers"
        ).lower()
        agent_label = commons.get_label_settings().get("agent.label", "TSE").lower()
        agent_label_plural = commons.get_label_settings().get(
            "agent.label.plural", "TSEs"
        ).lower()
        welcome_text = (
            f"""Use this product to:
• Identify coaching opportunities and provide in-context coaching to your {agent_label_plural} on cases that they are working on, in real time
• Define a case evaluation rubric that will be used by all the reviewers in your organization, enforcing uniform support standards in every {client_label} interaction
• Take advantage of machine learning to ensure that your managers review the highest value cases
• Promote consistent and timely evaluation for every {agent_label} with minimal effort
• Centralize {agent_label} performance metrics — no more spreadsheets scattered across individual managers' machines""",
            f"Review cases with your {agent_label_plural} and gather insights on how to provide consistent and delightful support to your {client_label_plural}."
        )

        commons.reset_onboarding(NavbarItem.CASE_EVALUATION)
        driver.refresh()
        assert commons.is_element_visible(
            (By.XPATH, cl.start_onboarding_button)
        ), "Get started button is not visible"
        assert commons.get_element_text_or_value(
            (By.CSS_SELECTOR, al.welcome_page_text_element)
        ) in welcome_text, "Welcome page text is not same as expected"

    @pytestrail.case('C6317')
    @regression_test
    @author_nalini_govindaraj
    def test_new_template_creation_flow_valid_category_empty_item(self, driver, ace_setup):
        page = ace_page.CaseEvaluation(driver)
        page.click_edit_evaluation_criteria_icon()
        page.click_create_new_button() #"Unable to click create new button"
        time.sleep(2)
        assert page.draft_message_text(), "Unable to find the new checklist created confirmation message"
        page.click_goto_draft()
        draft_exists = page.display_recent_draft()  # "Unable to find the recently created draft"
        if draft_exists:
            page.click_recent_draft()  # "Unable to click the recently created draft"
            page.click_edit_draft()
        page.click_five_scale()
        page.click_newcategory()
        first_category_name = "testing_category_1"
        page.enter_first_category_name(first_category_name)
        item_description = 'testing description'
        page.enter_item_description(item_description)
        add_button_state = page.add_button_enabled()
        if add_button_state:
            LOGGER.info("Add button is enabled and test case is failing")
        else:
            assert add_button_state == False, "Add button is enabled"

    @pytestrail.case('C6312')
    @regression_test
    @author_nalini_govindaraj
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_ace_checklist_page_display(self, driver, ace_setup):
        page = ace_page.CaseEvaluation(driver)
        page.click_edit_evaluation_criteria_icon()
        assert page.ace_checklist_header(),"Ace checklist header is not displayed"

    @pytestrail.case('C6316')
    @regression_test
    @author_nalini_govindaraj
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_creation_flow_empty_category_valid_item_valid_description_new_template(self, driver, ace_setup):
        page = ace_page.CaseEvaluation(driver)
        page.click_edit_evaluation_criteria_icon()
        page.click_create_new_button()
        assert page.draft_message_text(),"Unable to find the new checklist created confirmation message"
        page.click_goto_draft()
        draft_exists = page.display_recent_draft()  # "Unable to find the recently created draft"
        if draft_exists:
            page.click_recent_draft()  # "Unable to click the recently created draft"
            page.click_edit_draft()
        page.click_three_scale()
        page.click_newcategory()
        item_name = "testing_item_1"
        page.enter_item_name(item_name)
        item_description ='testing description'
        page.enter_item_description(item_description)
        add_button_state = page.add_button_enabled()
        if add_button_state:
            LOGGER.info("Add button is enabled and test case is failing")
        else:
            assert add_button_state == False, "Add button is enabled"

    @pytestrail.case('C6415')
    @regression_test
    @author_nalini_govindaraj
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_new_template_five_scale(self, driver, ace_setup):
        page = ace_page.CaseEvaluation(driver)
        page.click_edit_evaluation_criteria_icon()
        time.sleep(2)
        page.click_create_new_button()
        time.sleep(2)
        assert page.draft_message_text(), "Unable to find the new checklist created confirmation message"
        page.click_goto_draft()
        draft_exists = page.display_recent_draft()  # "Unable to find the recently created draft"
        if draft_exists:
            page.click_recent_draft()  # "Unable to click the recently created draft"
            page.click_edit_draft()
        page.click_five_scale()
        page.click_newcategory()
        first_category_name = "testing_category_1"
        page.enter_first_category_name(first_category_name)
        item_name = "testing_item_1"
        page.enter_item_name(item_name)
        item_description = 'testing description'
        page.enter_item_description(item_description)
        time.sleep(2)
        assert page.add_button_enabled(), "Add button is disabled"
        page.click_add_button()
        assert page.display_poor_rating(), "Poor rating icon is not displayed"
        assert page.display_bad_rating(), "Bad rating icon is not displayed"
        assert page.display_neutral_rating(), "Neutral rating icon is not displayed"
        assert page.display_good_rating(), "Good rating icon is not displayed"
        assert page.display_great_rating(), "Good rating icon is not displayed"
        page.click_finish_editing()
        assert page.publish_button_enabled(), "Publish button is disabled"
        page.click_publish_button()
        page.click_publish_ok()
        page.click_current_tab()
        page.click_back_to_evaluation()
        page.click_first_case()
        new_sh_exists = page.display_new_sh_prompt()  # "Unable to find the recently created draft"
        if new_sh_exists:
            page.click_new_sh()
            time.sleep(2)
        page.click_start_review()
        assert page.display_poor_rating(), "Poor rating icon is not displayed"
        assert page.display_bad_rating(), "Bad rating icon is not displayed"
        assert page.display_neutral_rating(), "Neutral rating icon is not displayed"
        assert page.display_good_rating(), "Good rating icon is not displayed"
        assert page.display_great_rating(), "Good rating icon is not displayed"


    @pytestrail.case('C6414')
    @regression_test
    @author_nalini_govindaraj
    def test_new_template_three_scale(self, driver, ace_setup):
        page = ace_page.CaseEvaluation(driver)
        page.click_edit_evaluation_criteria_icon()
        page.click_create_new_button()
        time.sleep(2)
        assert page.draft_message_text(), "Unable to find the new checklist created confirmation message"
        page.click_goto_draft()
        draft_exists = page.display_recent_draft()  # "Unable to find the recently created draft"
        if draft_exists:
            page.click_recent_draft()  # "Unable to click the recently created draft"
            page.click_edit_draft()
        page.click_three_scale()
        page.click_newcategory()
        first_category_name = "testing_category_1"
        page.enter_first_category_name(first_category_name)
        item_name = "testing_item_1"
        page.enter_item_name(item_name)
        item_description = 'testing description'
        page.enter_item_description(item_description)
        time.sleep(2)
        assert page.add_button_enabled(), "Add button is disabled"
        page.click_add_button()
        poor_rating_icon = page.display_poor_rating()
        if poor_rating_icon is False:
            assert poor_rating_icon == False, "Poor rating icon is displayed"
        assert page.display_bad_rating(), "Bad rating icon is not displayed"
        assert page.display_neutral_rating(), "Neutral rating icon is not displayed"
        assert page.display_good_rating(), "Good rating icon is not displayed"
        great_rating_icon = page.display_poor_rating()
        if great_rating_icon is False:
            assert great_rating_icon == False, "Great rating icon is displayed"
        page.click_finish_editing()
        assert page.publish_button_enabled(), "Publish button is disabled"
        page.click_publish_button()
        page.click_publish_ok()
        page.click_current_tab()
        page.click_back_to_evaluation()
        page.click_first_case()
        new_sh_exists = page.display_new_sh_prompt()  # "Unable to find the recently created draft"
        if new_sh_exists:
            page.click_new_sh()
            time.sleep(2)
        page.click_start_review()
        poor_rating_icon = page.display_poor_rating()
        if poor_rating_icon is False:
            assert poor_rating_icon == False, "Poor rating icon is displayed"
        assert page.display_bad_rating(), "Bad rating icon is not displayed"
        assert page.display_neutral_rating(), "Neutral rating icon is not displayed"
        assert page.display_good_rating(), "Good rating icon is not displayed"
        great_rating_icon = page.display_poor_rating()
        if great_rating_icon is False:
            assert great_rating_icon == False, "Great rating icon is displayed"

    @pytestrail.case('C6324')
    @regression_test
    @author_nalini_govindaraj
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_publish_workflow_draft(self, driver, ace_setup):
        page = ace_page.CaseEvaluation(driver)
        page.click_edit_evaluation_criteria_icon()
        page.click_create_new_button()
        time.sleep(2)
        assert page.draft_message_text(), "Unable to find the new checklist created confirmation message"
        page.click_goto_draft()
        draft_exists = page.display_recent_draft()  # "Unable to find the recently created draft"
        if draft_exists:
            page.click_recent_draft()  # "Unable to click the recently created draft"
            page.click_edit_draft()
        page.click_three_scale()
        page.click_newcategory()
        first_category_name = "testing_category_1"
        page.enter_first_category_name(first_category_name)
        item_name = "testing_item_1"
        page.enter_item_name(item_name)
        item_description = 'testing description'
        page.enter_item_description(item_description)
        time.sleep(2)
        assert page.add_button_enabled(), "Add button is disabled"
        page.click_add_button()
        assert page.display_neutral_rating(), "Neutral rating icon is not displayed"# to hold time
        page.click_finish_editing()
        time.sleep(2)
        assert page.publish_button_enabled(), "Publish button is disabled"
        page.click_publish_button()
        assert page.display_publish_message_first_line(), "Publish 1st line confirmation message is incorrect"
        assert page.display_publish_message_second_line(), "Publish 2nd line confirmation message is incorrect"
        assert page.display_publish_ok(),"Publish button is not displayed in publish confirmation window"
        assert page.display_publish_cancel(), "Cancel button is not displayed in publish confirmation window"
        page.click_publish_ok()
        page.click_current_tab()
        assert page.display_first_item_first_category(),"First item name under 1st category does not match the entered the item name"
        assert page.display_first_description_first_item_first_category(),"First description of 1st item name under 1st category does not match the entered the item description"
        assert page.display_first_category(), "First category name does not match the entered the category name"









