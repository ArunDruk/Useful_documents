"""This is the test class for Agents management page"""
__author__ = "Neha Jha"
__copyright__ = "Copyright (C) 2021 SupportLogic"

import logging
from datetime import date

import pytest
from pytest_testrail.plugin import pytestrail
from selenium.common.exceptions import ElementClickInterceptedException
from selenium.webdriver.common.by import By

import constants
import utils
from constants import author_neha_jha, author_praveen_nj, regression_test, sanity_test
from enums import AgentManagementTabs, NavbarItem, UserMenuOption
from locators import agents_management_locator, common_locators as cl
from pom_library import agent_management_page, commons, console_page
from pom_library.agent_management_page import AgentsPage
from pom_library.api_keywords import ApiKeywords
from pom_library.navbar import Navbar
from pom_library.support_hub import SupportHub

LOGGER = logging.getLogger(__name__)


class TestAgentManagement(object):
    @pytest.fixture()
    def agents_setup(self, driver):
        page = agent_management_page.AgentsPage(driver)
        common_page = commons.Commons(driver)
        driver.set_page_load_timeout(5)
        navbar = Navbar(driver)
        navbar.navigate_to_navbar_page(NavbarItem.AGENTS)
        common_page.start_module_onboarding()
        assert page.validate_support_engineer_page(),"failed to load support engineer page"
        page.click_search_icon()
        search_page_loaded = page.check_search_page_loaded()
        assert search_page_loaded, "Failed to search load page "
        yield
        support_hub = SupportHub(driver)
        try:
            support_hub.close_support_hub_window()
        except:
            LOGGER.info("support hub is not displayed")
        page.click_search_icon()
        page.click_on_back_button()

    @sanity_test
    @author_neha_jha
    @pytestrail.case('C484')
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_search_support_engineer(self, driver, agents_setup):
        page = agent_management_page.AgentsPage(driver)
        agents_profile = page.validate_search_result(agent_name="a")
        assert agents_profile, "failed to display agents profile"

    @sanity_test
    @author_neha_jha
    @pytestrail.case('C2232')
    def test_search_support_hub(self, driver, agents_setup):
        console = console_page.ConsolePage(driver)
        support_hub = SupportHub(driver)
        page = agent_management_page.AgentsPage(driver)
        agents_profile = page.validate_search_result(agent_name="a")
        page.click_on_tab(AgentManagementTabs.BACKLOG)
        assert agents_profile, "failed to display profile"
        backlog_cases = page.get_case_count_on_tabs(AgentManagementTabs.BACKLOG)
        if backlog_cases != "0":
            console.click_on_any_case_in_unassigned_list()
            assert support_hub.check_visibility_of_support_hub(), "failed to display support hub"
        else:
            LOGGER.warning("no case in backlog no data")

    @sanity_test
    @author_neha_jha
    @pytestrail.case('C2233')
    def test_support_hub_data(self, driver, agents_setup):
        support_hub = SupportHub(driver)
        console = console_page.ConsolePage(driver)
        page = agent_management_page.AgentsPage(driver)
        agents_profile = page.validate_search_result(agent_name="a")
        assert agents_profile, "failed to display support hub"
        page.click_on_tab(AgentManagementTabs.BACKLOG)
        backlog_cases = page.get_case_count_on_tabs(AgentManagementTabs.BACKLOG)
        if backlog_cases != "0":
            support_id = page.get_first_case_id_in_list()
            console.click_on_any_case_in_unassigned_list()
            assert support_hub.check_visibility_of_support_hub(), "failed to display support hub"

            support_hub_id = support_hub.get_case_id()
            assert support_id == support_hub_id, " ID of support hub is not same"
        else:
            LOGGER.warning("No case is backlog .")

    @sanity_test
    @author_neha_jha
    @pytestrail.case('C2234')
    def test_search_support_virtual_team(self, driver, agents_setup):
        """navigate to virtual team
        check for the virtual team if virtual team present get the text  of first virtual team
        else : create new virtual team and navigate to the agent page search for virtual team"""
        page = agent_management_page.AgentsPage(driver)
        navbar = Navbar(driver)
        current_url = navbar.navigate_to_navbar_page(NavbarItem.VIRTUAL_TEAMS)
        assert "virtual-teams" in current_url, "failed to navigate the virtual teams"
        virtual_team_and_virtual_org_count = (
            page.get_count_of_virtual_team_virtual_org_present_on_virtual_team()
        )
        if virtual_team_and_virtual_org_count == 0:
            page.click_on_create_virtual_team()
            page.click_on_global_team()
            vt_name = utils.generate_test_run_id(constants.VT_GLOBAL_RUN_ID_PREFIX)
            page.enter_virtual_account_name_text_box(vt_name)
            page.click_on_next_button()
            page.search_agents_while_creating_virtual_team()
            page.select_two_agents_while_creating_virtual_team()
            page.click_on_create_button()
            virtual_team_and_virtual_org_count = (
                page.get_count_of_virtual_team_virtual_org_present_on_virtual_team()
            )
            assert (
                virtual_team_and_virtual_org_count == 1
            ), "failed to crated the virtual team "
        virtual_team_name = page.get_text_of_first_virtual_team_name()
        navbar.navigate_to_navbar_page(NavbarItem.AGENTS)
        page.click_search_icon()
        virtual_org = virtual_team_name
        page.search_agents(virtual_org)
        result = page.check_search_result()
        assert result, "failed to load  search data"
        page.click_individual_agents()
        agents_search_result = page.check_if_agents_present_search_result()
        assert agents_search_result, "failed to load page"
        page.click_agents_search_result()

        agents_profile = page.check_agents_profile()
        assert agents_profile, "search agents is not displayed "
        if virtual_team_and_virtual_org_count == 0:
            current_url = navbar.navigate_to_navbar_page(NavbarItem.VIRTUAL_TEAMS)
            assert (
                "virtual-teams" in current_url
            ), "failed to navigate the virtual teams"
            page.hover_over_vt_click_on_delete_icon()
            page.click_on_delete_button_delete_pop_up()
            virtual_team_and_virtual_org_count = (
                page.get_count_of_virtual_team_virtual_org_present_on_virtual_team()
            )
            assert (
                virtual_team_and_virtual_org_count == 0
            ), "failed to delete the virtual team"

    @sanity_test
    @author_neha_jha
    @pytestrail.case('C2235')
    def test_virtual_team(self, driver):
        page = agent_management_page.AgentsPage(driver)
        driver.set_page_load_timeout(5)
        navbar = Navbar(driver)
        current_url=navbar.navigate_to_navbar_page(NavbarItem.VIRTUAL_TEAMS)
        common_page = commons.Commons(driver)
        common_page.start_module_onboarding()
        assert "virtual-teams" in current_url,"failed to load the virtual team page"

        page.click_virtual_team_expand()
        page.click_virtual_agents()

        open_windows = driver.window_handles
        driver.switch_to.window(open_windows[1])

        agents_profile = page.check_agents_profile()
        assert agents_profile, "failed to display profile"

        driver.close()
        driver.switch_to.window(open_windows[0])

    @regression_test
    @author_neha_jha
    @pytestrail.case('C487')
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_remove_favorites_functionality(self,driver,agents_setup):
        page =agent_management_page.AgentsPage(driver)
        agents_profile = page.validate_search_result(agent_name="jo")
        assert agents_profile, "failed to display agents profile"
        favorites_agent =page.validate_agents_is_favorites_or_not()
        if favorites_agent is False:
             page.click_on_favorites_star()# this click will add fav
        agents_name = page.get_agent_name_in_agents_profile()
        page.click_on_favorites_star() # this click will remove fav
        page.click_favorite_icon_module()
        favorites_agent=page.validate_particular_favorite_agents_is_present_in_favorites_module(agents_name)
        assert favorites_agent ==  False,"failed to remove the agent from the favorites list"

    @regression_test
    @author_neha_jha
    @pytestrail.case('C486')
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_add_favorites_functionality(self, driver, agents_setup):
        page = agent_management_page.AgentsPage(driver)
        agents_profile = page.validate_search_result(agent_name="jo")
        assert agents_profile, "failed to display agents profile"
        favorites_agent = page.validate_agents_is_favorites_or_not()
        if favorites_agent :
            page.click_on_favorites_star()# this click will remove fav
        agents_name = page.get_agent_name_in_agents_profile()
        page.click_on_favorites_star()
        page.click_favorite_icon_module() # this click will add fav
        favorites_agent = page.validate_particular_favorite_agents_is_present_in_favorites_module(agents_name)
        assert favorites_agent,"failed to added agents to the favorites list"

    @regression_test
    @author_neha_jha
    @pytestrail.case('C493')
    def test_functionality_of_view_profile_button_in_fav_section(self, driver, agents_setup):
        page = agent_management_page.AgentsPage(driver)
        page.click_favorite_icon_module()
        agents_name  = page.get_first_agent_name_in_fav_section()
        page.click_on_first_agents_view_profile_button()
        open_windows = driver.window_handles
        driver.switch_to.window(open_windows[1])
        agents_name_in_profile = page.get_agent_name_in_agents_profile()
        assert agents_name in agents_name_in_profile,"failed to view button"
        driver.close()
        driver.switch_to.window(open_windows[0])

    @regression_test
    @author_neha_jha
    @pytestrail.case('C490')
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_functionality_of_delete_fav_from_preferences(self, driver):
        page = agent_management_page.AgentsPage(driver)
        navbar = Navbar(driver)
        common_page = commons.Commons(driver)
        navbar.navigate_to_navbar_page(NavbarItem.AGENTS)
        page.click_search_icon()
        agents_profile = page.validate_search_result(agent_name="a")
        assert agents_profile, "failed to display agents profile"
        favorites_agent = page.validate_agents_is_favorites_or_not()
        if favorites_agent:
            page.click_on_favorites_star()  # this click will remove fav
        agents_name = page.get_agent_name_in_agents_profile()
        page.click_on_favorites_star()
        page.click_on_back_button()
        common_page. go_to_user_menu_option(option=UserMenuOption.PREFERENCES)
        common_page.click_preference_favorite_support_engineer()

        common_page.hover_on_element((By.XPATH, cl.agents_in_fav_tab.replace("agents_name",agents_name)))
        LOGGER.info("clicking on  agents star button  to remove from fav list")
        common_page.click_on_element(
            (By.XPATH, cl.support_engineer_fav_remove.replace("agents_name",agents_name)),
            message="failed to click on favorite star",
        )
        assert  common_page.check_for_agent_is_present_in_preference_support_engineer(agents_name) == False,"failed"
        common_page.close_user_preference_popup()

    @regression_test
    @author_neha_jha
    @pytestrail.case('C492')
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_functionality_of_searching_and_adding_support_engineer_to_fav_module(self, driver):
        page = agent_management_page.AgentsPage(driver)
        common_page = commons.Commons(driver)
        navbar = Navbar(driver)
        navbar.navigate_to_navbar_page(NavbarItem.AGENTS)

        page.click_favorite_icon_module()
        common_page.wait_for_loader_to_disappear()

        page.search_on_agents_on_fav(search_text="a")
        agent_name=page.get_first_name_from_the_search_result_in_fav_modules()
        page.click_on_first_name_the_search_result_in_fav_modules_to_add_fav()
        favorites_agent = page.validate_particular_favorite_agents_is_present_in_favorites_module(agent_name)
        assert favorites_agent ,"failed to add in fav in list"

    @regression_test
    @author_neha_jha
    @pytestrail.case('C491')
    def test_functionality_of_delete_fav_from_preferences_check_in_support_page(self, driver):
        page = agent_management_page.AgentsPage(driver)
        navbar = Navbar(driver)
        common_page = commons.Commons(driver)
        navbar.navigate_to_navbar_page(NavbarItem.AGENTS)
        page.click_search_icon()
        agents_profile = page.validate_search_result(agent_name="a")
        assert agents_profile, "failed to display agents profile"
        favorites_agent = page.validate_agents_is_favorites_or_not()
        if favorites_agent:
            page.click_on_favorites_star()  # this click will remove fav
        agents_name = page.get_agent_name_in_agents_profile()
        page.click_on_favorites_star()
        page.click_on_back_button()
        common_page.go_to_user_menu_option(option=UserMenuOption.PREFERENCES)
        common_page.click_preference_favorite_support_engineer()

        common_page.hover_on_element((By.XPATH, cl.agents_in_fav_tab.replace("agents_name", agents_name)))
        LOGGER.info("clicking on  agents star button  to remove from fav list")
        common_page.click_on_element(
            (By.XPATH, cl.support_engineer_fav_remove.replace("agents_name", agents_name)),
            message="failed to click on favorite star",
        )
        assert common_page.check_for_agent_is_present_in_preference_support_engineer(agents_name) == False, "failed"
        common_page.close_user_preference_popup()
        page.click_favorite_icon_module()
        favorites_agent = page.validate_particular_favorite_agents_is_present_in_favorites_module(agents_name)
        assert favorites_agent == False,"failed to added agents to the favorites list"

    @regression_test
    @author_neha_jha
    @pytestrail.case('C489')
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_functionality_of_adding_agents_directly_to_preference_pop_up(self, driver):
        page = agent_management_page.AgentsPage(driver)
        navbar = Navbar(driver)
        common_page = commons.Commons(driver)
        navbar.navigate_to_navbar_page(NavbarItem.AGENTS)
        common_page.go_to_user_menu_option(option=UserMenuOption.PREFERENCES)
        common_page.click_preference_favorite_support_engineer()
        common_page.search_in_preference_favorite_support_engineer(search_text="a")
        agent_name=page.get_first_name_from_the_search_result_in_fav_modules()
        page.click_on_first_name_the_search_result_in_fav_modules_to_add_fav()
        common_page.close_user_preference_popup()
        navbar.navigate_to_navbar_page(NavbarItem.AGENTS)
        page.click_search_icon()
        agents_profile = page.validate_search_result(agent_name=agent_name)
        assert agents_profile, "failed to display agents profile"
        assert page.validate_agents_is_favorites_or_not(),"agents is added to fav "
        page.click_on_back_button()

    @regression_test
    @author_neha_jha
    @pytestrail.case('C496')
    def test_functionality_of_adding_even_from_profile_page(self, driver, agents_setup):
        page = agent_management_page.AgentsPage(driver)
        agents_profile = page.validate_search_result(agent_name="a")
        assert agents_profile, "failed to display support hub"
        reason="Vacation"
        today = date.today().day
        if page.validate_whether_red_dot_is_displayed_on_date(today):
            page.single_click_on_date_in_out_of_office_calendar(today)
            page.click_on_save_delete_cancel_option_button(option="Delete")

        page.double_click_on_date_in_out_of_office_calendar(today)
        page.selecting_the_reason_option_of_out_of_office(reason)
        page.click_on_save_delete_cancel_option_button(option="Save")
        page.hover_over_date_in_out_of_office_calendar(today)
        assert page.get_element_when_visible(
            (By.XPATH,  agents_management_locator.tool_tip_on_date.replace("option_selected",reason)),
            message="Case Status options popup is not displayed",
        )

    @regression_test
    @author_neha_jha
    @pytestrail.case('C495')
    def test_functionality_of_editing_event_from_profile_page_on_today_date(self, driver, agents_setup):
        page = agent_management_page.AgentsPage(driver)
        agents_profile = page.validate_search_result(agent_name="a")
        assert agents_profile, "failed to display support hub"
        reason = "Vacation"
        edit_reason = "Sick"
        today = date.today().day
        if page.validate_whether_red_dot_is_displayed_on_date(today):
            page.single_click_on_date_in_out_of_office_calendar(today)
            page.click_on_save_delete_cancel_option_button(option="Delete")

        page.double_click_on_date_in_out_of_office_calendar(today)
        page.selecting_the_reason_option_of_out_of_office(reason)
        page.click_on_save_delete_cancel_option_button(option="Save")
        page.hover_over_date_in_out_of_office_calendar(today)
        assert page.get_element_when_visible(
            (By.XPATH, agents_management_locator.tool_tip_on_date.replace("option_selected", reason)),
            message="reason is not displayed on calendar",
        )
        assert page.validate_whether_red_dot_is_displayed_on_date(today)
        page.single_click_on_date_in_out_of_office_calendar(today)
        page.selecting_the_reason_option_of_out_of_office(edit_reason)
        page.click_on_save_delete_cancel_option_button(option="Save")
        page.hover_over_date_in_out_of_office_calendar(today)
        assert page.is_element_visible(
            (By.XPATH, agents_management_locator.tool_tip_on_date.replace("option_selected", edit_reason)),
        )

    @regression_test
    @author_neha_jha
    @pytestrail.case('C485')
    def test_functionality_median_count_display_on_profile(self, driver, agents_setup):
        page = agent_management_page.AgentsPage(driver)
        agents_profile = page.validate_search_result(agent_name="a")
        assert agents_profile, "failed to display support hub"
        assert " " != page.get_element_text_or_value(
            (By.XPATH, agents_management_locator.median_open_case_time),
            message="median open case time is empty",
        )
        assert " " != page.get_element_text_or_value(
            (By.XPATH, agents_management_locator.median_respond_time),
            message="median respond  time is empty",
        )
        assert " " != page.get_element_text_or_value(
            (By.XPATH, agents_management_locator.median_conversation_time),
            message="median conversation count is empty",
        )

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C2322")
    def test_agent_insights_content_tabs_zero_state(self, driver, agents_setup):
        agents = AgentsPage(driver)
        api_keywords = ApiKeywords(driver)

        expected_placeholders = (
            "no cases",
            "no cases found",
            "no tickets, try expanding your filter options"
        )
        agent_with_least_cases = api_keywords.get_agent_names(with_least_cases=True)[0]
        agents.validate_search_result(agent_with_least_cases)
        enabled_tabs = driver.find_elements(
            By.CSS_SELECTOR, agents_management_locator.tabs
        )
        for tab in enabled_tabs:
            try:
                tab.click()
            except ElementClickInterceptedException:
                driver.find_element(
                    By.CSS_SELECTOR, agents_management_locator.slider_next_arrow
                ).click()
                tab.click()
            tab_name = tab.get_attribute("data-testid").split("-")[-1]
            case_count_locator = agents_management_locator.case_count_on_tabs.format(
                tab_name=tab_name
            )
            count = agents.get_element_text_or_value((By.XPATH, case_count_locator))
            LOGGER.info(f"{tab_name}: {count} cases")
            if count != "0":
                continue
            actual_placeholder = agents.get_element_text_or_value(
                (By.CSS_SELECTOR, agents_management_locator.tab_placeholder_text)
            ).lower()
            assert (
                actual_placeholder in expected_placeholders
            ), f"Placeholder is not present in {tab_name}"
