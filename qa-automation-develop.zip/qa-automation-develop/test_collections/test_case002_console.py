"""This is the test class for  console  page"""
__author__ = "Neha Jha"
__copyright__ = "Copyright (C) 2021 SupportLogic"


import logging
import time

import pytest
from pytest_testrail.plugin import pytestrail
from selenium.webdriver.common.by import By

from constants import (
    author_neha_jha, author_praveen_nj, regression_test, sanity_test,
    sl_admin_users_test,
)
from enums import (
    CaseDistributionBar, ConsolePageTabs, GroupByCustomFields, ModuleState, NavbarItem,
)
from locators import common_locators as cl
from pom_library import agent_management_page, commons, console_page, filters
from pom_library.api_keywords import ApiKeywords
from pom_library.navbar import ControlCenterMenuItem, Navbar
from pom_library.support_hub import SupportHub

LOGGER = logging.getLogger(__name__)


@pytest.mark.last
@pytest.mark.usefixtures("driver")
class TestConsole(object):
    @pytest.fixture()
    def console_setup(self, driver):
        navbar = Navbar(driver)
        current_url = navbar.navigate_to_navbar_page(NavbarItem.CONSOLE)
        assert "console" in current_url, "failed to load current curl"
        yield
        support_hub = SupportHub(driver)
        try:
            support_hub.close_support_hub_window()
        except:
            LOGGER.info("support window is not displayed")

    @pytest.fixture()
    def dynamic_filter(self, driver):
        page = console_page.ConsolePage(driver)
        filter_obj = filters.Filters(driver)
        navbar = Navbar(driver)
        current_url = navbar.navigate_to_navbar_page(NavbarItem.CONSOLE)
        assert "console" in current_url, "failed to load current curl"
        check_filter = filter_obj.check_if_dynamic_filter_applied()
        if check_filter is False:
            dynamic_filter_applied = filter_obj.get_count_of_number_of_dynamic_filter()
            LOGGER.info(len(dynamic_filter_applied))
            for i in dynamic_filter_applied:
                filter_obj.click_on_selected_dynamic_filter()
                filter_options = filter_obj.check_the_presence_of_selected_tab()
                if filter_options:
                    filter_obj.click_on_deselect_button_in_dynamic_filter_option_applied()
                    filter_obj.click_on_apply_filter_in_selected()

            filter_obj.click_on_dynamic_filter()

            filter_obj.deselect_dynamic_filter()
            filter_obj.click_on_save_button()
            time.sleep(2)
            driver.refresh()
        else:
            LOGGER.info("dynamic filter is not applied")
        yield
        support_hub = SupportHub(driver)
        try:
            support_hub.close_support_hub_window()
        except:
            LOGGER.info("support window is not displayed")
        filter_obj.click_on_selected_dynamic_filter()
        filter_options = filter_obj.check_the_presence_of_selected_tab()
        if filter_options:
            filter_obj.click_on_deselect_button_in_dynamic_filter_option_applied()
            filter_obj.click_on_apply_filter_in_selected()
            check_filter = filter_obj.check_if_dynamic_filter_applied()
            if check_filter:
                filter_obj.click_on_dynamic_filter()
                filter_obj.deselect_dynamic_filter()
                filter_obj.click_on_save_button()

            else:
                LOGGER.info("dynamic filter is not applied")
        else:
            LOGGER.info("no option is displayed based on priority")

    @sanity_test
    def test_visibility_of_time_filters(self, driver, console_setup):

        page = console_page.ConsolePage(driver)
        navbar = Navbar(driver)
        navbar.navigate_to_control_center_item(ControlCenterMenuItem.SETTINGS)
        toady_filter = page.check_time_filter_today_is_enabled()
        assert toady_filter, "today filter is not enable"

    @author_neha_jha
    @sanity_test
    @pytestrail.case("C8")
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_console_page_load(self, driver):
        page = console_page.ConsolePage(driver)
        navbar = Navbar(driver)
        current_url = navbar.navigate_to_navbar_page(NavbarItem.CONSOLE)
        assert "console" in current_url, "failed to load current url"
        console_data_present = page.check_for_console_dashboard_display_data()
        assert (
            console_data_present
        ), " console page have no data or failed to click on console page "

    @sl_admin_users_test
    @author_neha_jha
    @sanity_test
    @pytestrail.case("C29")
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_visibility_of_time_filters_today(self, driver, console_setup):

        page = console_page.ConsolePage(driver)
        time_filter = page.get_time_filter_in_console()
        filter = "Today"
        if time_filter != filter:
            page.click_time_filter_drop_down()
            page.select_filter_in_console(filter)
            time_filter_selected = page.get_time_filter_in_console()
            assert filter == time_filter_selected, "failed to display today"
        console_data_present = page.check_for_console_dashboard_display_data()
        if console_data_present:
            page.click_on_tab(ConsolePageTabs.NEW_TICKETS)
            new_case = page.validate_cards_based_on_filter_new_case(filter)
            assert new_case, "failed to display data based on time filter  "
        else:
            LOGGER.warning("There are zero cases or no cases ")

    @sanity_test
    @author_neha_jha
    @pytestrail.case("C30")
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_visibility_of_time_filters_yesterday(self, driver, console_setup):

        page = console_page.ConsolePage(driver)
        navbar = Navbar(driver)
        navbar.navigate_to_navbar_page(NavbarItem.CONSOLE)
        time_filter = page.get_time_filter_in_console()
        filter = "Since yesterday"
        if time_filter != filter:
            page.click_time_filter_drop_down()
            page.select_filter_in_console(filter)
            selected_time_filter = page.get_time_filter_in_console()
            assert (
                selected_time_filter == filter
            ), "failed to displayed time filter Since yesterday"
        console_data_present = page.check_for_console_dashboard_display_data()
        if console_data_present:
            page.click_on_tab(ConsolePageTabs.NEW_TICKETS)
            new_case = page.validate_cards_based_on_filter_new_case(filter)
            assert new_case, " failed to displayed data based on time filter"
        else:
            LOGGER.warning("There are zero cases or no cases ")

    @sanity_test
    @author_neha_jha
    @pytestrail.case("C31")
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_visibility_of_time_filters_last_7_days(self, driver, console_setup):

        page = console_page.ConsolePage(driver)
        time_filter = page.get_time_filter_in_console()
        filter = "Last 7 days"
        if filter != time_filter:
            page.click_time_filter_drop_down()
            page.select_filter_in_console(filter)
            time_filter_selected = page.get_time_filter_in_console()
            assert filter in time_filter_selected, "failed to displayed time filter"
        console_data_present = page.check_for_console_dashboard_display_data()
        if console_data_present:
            page.click_on_tab(ConsolePageTabs.NEW_TICKETS)
            new_case = page.validate_cards_based_on_filter_new_case_7_days()
            assert new_case, "failed to displayed data based on time filter"
        else:
            LOGGER.warning("There are zero cases or no cases ")

    @sanity_test
    @author_neha_jha
    @pytestrail.case("C2206")
    def test_validate_data_loaded_for_all_tab(self, driver, console_setup):
        page = console_page.ConsolePage(driver)
        console_data_present = page.check_for_console_dashboard_display_data()
        if console_data_present:
            page.click_on_tab(ConsolePageTabs.NEW_TICKETS)
            select_card = page.new_case_cards_data_validation(card="New case")
            assert select_card, "failed to select card"
            page.click_on_tab(ConsolePageTabs.SERVICE_COMPLIANCE)
            data_card = page.service_compliance_cards_data_validation(
                card="Service compliance"
            )
            assert data_card, "failed to display service compliance data"
            page.click_on_tab(ConsolePageTabs.NEGATIVE_SENTIMENTS)
            negative_card = page.select_cards_data_validation(
                card="Negative sentiments"
            )
            assert negative_card, "failed to display negative sentiments data"
            page.click_on_tab(ConsolePageTabs.NEED_ATTENTION)
            need_data = page.select_cards_data_validation(card="Need attention")
            assert need_data, "failed to display need attention data"
            page.click_on_tab(ConsolePageTabs.POSITIVE_SENTIMENTS)
            positive_card = page.select_cards_data_validation(
                card=" Positive sentiments"
            )
            assert positive_card, "failed to display positive sentiments data"
        else:
            LOGGER.warning("There are zero cases or no cases ")

    @sanity_test
    @author_neha_jha
    @pytestrail.case("C48")
    def test_open_support_hub_new_case(self, driver, console_setup):
        page = console_page.ConsolePage(driver)
        support_hub = SupportHub(driver)
        console_data_present = page.check_for_console_dashboard_display_data()
        if console_data_present:
            page.click_on_tab(ConsolePageTabs.NEW_TICKETS)
            present_of_unassigned_cases = (
                page.check_the_presence_of_cases_unassigned_cases()
            )
            if present_of_unassigned_cases:
                page.click_on_any_case_in_unassigned_list()
                assert (
                    support_hub.check_visibility_of_support_hub()
                ), "failed to display support hub"

            else:
                LOGGER.warning("No cases in unassigned cases")
        else:
            LOGGER.warning("There are zero cases or no cases ")

    @sanity_test
    @author_neha_jha
    @pytestrail.case("C2207")
    def test_support_hub_in_negative_sentiments(self, driver, console_setup):
        support_hub = SupportHub(driver)
        page = console_page.ConsolePage(driver)
        console_data_present = page.check_for_console_dashboard_display_data()
        if console_data_present:
            page.click_on_tab(ConsolePageTabs.NEGATIVE_SENTIMENTS)
            select_card = page.select_cards_data_validation(card="Negative")
            assert select_card, "failed to select card on support hub"
            page.click_on_to_open_support_hub_in_cards()
            assert (
                support_hub.check_visibility_of_support_hub()
            ), "failed to display support hub"

        else:
            LOGGER.warning("There are zero cases or no cases ")

    @sanity_test
    @author_neha_jha
    @pytestrail.case("C2208")
    def test_support_hub_service(self, driver, console_setup):
        support_hub = SupportHub(driver)
        page = console_page.ConsolePage(driver)
        console_data_present = page.check_for_console_dashboard_display_data()
        if console_data_present:
            page.click_on_tab(ConsolePageTabs.SERVICE_COMPLIANCE)
            select_card = page.service_compliance_cards_data_validation(
                card="Service compliance"
            )
            assert select_card, "failed to select card in support hub"
            page.click_on_service_graph_and_list()
            assert (
                support_hub.check_visibility_of_support_hub()
            ), "failed to display support hub"

        else:
            LOGGER.warning("There are zero cases or no cases ")

    @sanity_test
    @author_neha_jha
    @pytestrail.case("C2209")
    def test_support_hub_in_need_attention(self, driver, console_setup):
        support_hub = SupportHub(driver)
        page = console_page.ConsolePage(driver)
        console_data_present = page.check_for_console_dashboard_display_data()
        if console_data_present:
            driver.refresh()
            page.click_on_tab(ConsolePageTabs.NEED_ATTENTION)
            toggle_status = page.get_text_expand_or_collapse_toggle_on_sentiments_tab()
            if toggle_status == "Expand All":
                page.click_on_expand_collapse_toggle_on_sentiments()
            select_card = page.select_cards_data_validation(card="Need attention")
            assert select_card, "failed to select card on support hub"
            page.click_on_to_open_support_hub_in_cards()
            assert (
                support_hub.check_visibility_of_support_hub()
            ), "failed to display support hub"

        else:
            LOGGER.warning("There are zero cases or no cases ")

    @sanity_test
    @author_neha_jha
    @pytestrail.case("C2210")
    def test_support_hub_in_positive_sentiments(self, driver, console_setup):
        support_hub = SupportHub(driver)
        page = console_page.ConsolePage(driver)
        console_data_present = page.check_for_console_dashboard_display_data()
        if console_data_present:
            page.click_on_tab(ConsolePageTabs.POSITIVE_SENTIMENTS)
            select_card = page.select_cards_data_validation(card="positive sentiments")
            assert select_card, "failed to select card on support hub"
            page.click_on_to_open_support_hub_in_cards()
            assert (
                support_hub.check_visibility_of_support_hub()
            ), "failed to display support hub"

        else:
            LOGGER.warning("There are zero cases or no cases ")

    @regression_test
    @author_neha_jha
    @pytestrail.case("C901")
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_support_hub_in_escalations_tab(self, driver, console_setup):
        support_hub = SupportHub(driver)
        page = console_page.ConsolePage(driver)
        console_data_present = page.check_for_console_dashboard_display_data()
        if console_data_present:
            # added time because escalation card take long time to load
            driver.refresh()
            time.sleep(3)

            page.click_on_tab(ConsolePageTabs.ESCALATIONS)

            assert (
                page.check_card_present_under_likely_to_escalated_card()
            ), "no case displayed on likely to be escalated"
            time.sleep(2)
            page.click_on_likely_to_escalated_card()
            assert (
                support_hub.check_visibility_of_support_hub()
            ), "failed to display support hub"

        else:
            LOGGER.warning("There are zero cases or no cases ")

    @regression_test
    @author_neha_jha
    @pytestrail.case("C42")
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_functionality_of_open_status_in_assigned_case(self, driver, console_setup):
        support_hub = SupportHub(driver)
        page = console_page.ConsolePage(driver)
        console_data_present = page.check_for_console_dashboard_display_data()
        if console_data_present:
            page.click_on_tab(ConsolePageTabs.NEW_TICKETS)
            status = page.get_text_of_current_status_in_assigned_case_tab()
            if status != "Open":
                page.click_on_assigned_cases_tab_status_button()
                page.select_status_in_assigned_tab(status="Open")

                open_status = page.get_text_of_current_status_in_assigned_case_tab()
                assert open_status == "Open", "status is not equal to open status"
            page.click_on_any_case_in_assigned_backlog()
            support_hub_display = support_hub.check_visibility_of_support_hub()
            if support_hub_display is False:
                page.click_on_assigned_this_period()
                assert (
                    support_hub.check_visibility_of_support_hub()
                ), "failed to display support hub"
                time.sleep(2)
            support_modal_window_case_status = support_hub.get_case_status()
            assert (
                support_modal_window_case_status != "Closed"
            ), " support hub case status is equal to close "
        else:
            LOGGER.warning(
                "There are no present of agents related to the search "
                " try to search different agents name"
            )

    @regression_test
    @author_neha_jha
    @pytestrail.case("C2211")
    @pytestrail.case("46")
    def test_functionality_of_open_status_in_distribution_tab(
        self, driver, console_setup
    ):
        support_hub = SupportHub(driver)
        page = console_page.ConsolePage(driver)
        console_data_present = page.check_for_console_dashboard_display_data()
        if console_data_present:
            page.click_on_tab(ConsolePageTabs.NEW_TICKETS)
            LOGGER.info("case distribution test start from  here")
            status = page.get_text_of_current_status_in_case_distribution_tab()
            if status != "Open":
                page.click_on_case_distribution_status_button()
                page.select_status_in_case_distribution_tab(status="Open")
                open_status = page.get_text_of_current_status_in_assigned_case_tab()
                assert open_status == "Open", "status is not equal to open status"
            page.click_on_case_distribution_tab_bar_chart_case()
            assert (
                support_hub.check_visibility_of_support_hub()
            ), "failed to display support hub"
            support_modal_window_case_status = support_hub.get_case_status()
            assert (
                support_modal_window_case_status != "Closed"
            ), "support hub case status is equal to close"
        else:
            LOGGER.warning(
                "There are no present of agents related to the search "
                " try to search different agents name"
            )

    @regression_test
    @author_neha_jha
    @pytestrail.case("C44")
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_click_on_close_status_in_assigned_case_tab(self, driver, console_setup):
        support_hub = SupportHub(driver)
        page = console_page.ConsolePage(driver)
        console_data_present = page.check_for_console_dashboard_display_data()
        if console_data_present:

            page.click_on_tab(ConsolePageTabs.NEW_TICKETS)
            status = page.get_text_of_current_status_in_assigned_case_tab()
            if status != "Closed":
                page.click_on_assigned_cases_tab_status_button()
                page.select_status_in_assigned_tab(status="Closed")

                status_after_change = (
                    page.get_text_of_current_status_in_assigned_case_tab()
                )
                assert (
                    status_after_change == "Closed"
                ), "status is not equal to close status"
            assigned_cases = page.get_text_of_assigned_cases_in_assigned_case_tab()
            assert assigned_cases != "(0)", "cases is not present in assigned cases"
            page.click_on_any_case_in_assigned_backlog()
            support_hub_visibility = support_hub.check_visibility_of_support_hub()
            if support_hub_visibility is False:
                page.click_on_assigned_this_period()
                assert (
                    support_hub.check_visibility_of_support_hub()
                ), "failed to display support hub"
                support_modal_window_case_status = support_hub.get_case_status()
                assert (
                    support_modal_window_case_status == "Closed"
                ), "support hub case status is equal to close"
        else:
            LOGGER.warning(
                "There are no present of agents related to the search "
                " try to search different agents name"
            )

    @regression_test
    @author_neha_jha
    @pytestrail.case("C2212")
    def test_click_on_close_status_in_case_distribution_tab(
        self, driver, console_setup
    ):
        support_hub = SupportHub(driver)
        page = console_page.ConsolePage(driver)
        console_data_present = page.check_for_console_dashboard_display_data()
        if console_data_present:
            page.click_on_tab(ConsolePageTabs.NEW_TICKETS)
            status = page.get_text_of_current_status_in_case_distribution_tab()
            if status != "Closed":
                page.click_on_case_distribution_status_button()
                page.select_status_in_case_distribution_tab(status="Closed")
                open_status = page.get_text_of_current_status_in_case_distribution_tab()
                assert open_status == "Closed"
            bar_chart_in_case_distribution = (
                page.check_the_presence_of_bar_chart_graph_in_case_distribution()
            )
            if bar_chart_in_case_distribution:
                page.click_on_case_distribution_tab_bar_chart_case()
                assert (
                    support_hub.check_visibility_of_support_hub()
                ), "failed to display support hub"
                support_modal_window_case_status = support_hub.get_case_status()
                assert (
                    support_modal_window_case_status == "Closed"
                ), "support hub status not equal to close"
            else:
                LOGGER.warning("no data display in case distribution ")
        else:
            LOGGER.warning(
                "There are no present of agents related to the search "
                " try to search different agents name"
            )

    @regression_test
    @author_neha_jha
    @pytestrail.case("C47")
    def test_functionality_of_status_after_refresh_page(self, driver, console_setup):
        LOGGER.info("assigned  case tab test start here ")
        page = console_page.ConsolePage(driver)
        console_data_present = page.check_for_console_dashboard_display_data()
        if console_data_present:

            page.click_on_tab(ConsolePageTabs.NEW_TICKETS)
            status = page.get_text_of_current_status_in_assigned_case_tab()
            if status == "Open":
                page.click_on_assigned_cases_tab_status_button()
                page.select_status_in_assigned_tab(status="Closed")

                open_status = page.get_text_of_current_status_in_assigned_case_tab()
                assert open_status == "Closed", "status is not equal  to close"
            else:
                page.click_on_assigned_cases_tab_status_button()
                page.select_status_in_assigned_tab(status="Open")
                time.sleep(2)  # time to reflect the status
                open_status = page.get_text_of_current_status_in_assigned_case_tab()
                assert open_status == "Open", "status is not equal to open"
            current_status = page.get_text_of_current_status_in_assigned_case_tab()
            driver.refresh()
            time.sleep(5)
            status_after_refresh = (
                page.get_text_of_current_status_in_assigned_case_tab()
            )
            assert (
                current_status == status_after_refresh
            ), "status before and after refresh is not same"
        else:
            LOGGER.warning(
                "There are no present of agents related to the search "
                " try to search different agents name"
            )

    @regression_test
    @author_neha_jha
    @pytestrail.case("C62")
    def test_functionality_of_expand_all_in_sentiments_tab(self, driver, console_setup):
        page = console_page.ConsolePage(driver)
        console_data_present = page.check_for_console_dashboard_display_data()
        if console_data_present:
            tab = [
                ConsolePageTabs.POSITIVE_SENTIMENTS,
                ConsolePageTabs.NEED_ATTENTION,
                ConsolePageTabs.NEGATIVE_SENTIMENTS,
            ]
            for tabs in tab:
                page.click_on_tab(tabs)
                page.click_on_grouped_by_on_tabs()
                page.select_filter_from_grouped_by(GroupByCustomFields.ELAPSED_TIME)
                toggle_status = (
                    page.get_text_expand_or_collapse_toggle_on_sentiments_tab()
                )
                if toggle_status == "Expand All":
                    page.click_on_expand_collapse_toggle_on_sentiments()

                driver.refresh()
                time.sleep(5)
                case_cards = page.check_for_presence_case_cards_in_tabs()
                assert case_cards, "failed to displayed card in tabs"
        else:
            LOGGER.warning(
                "There are no present of agents related to the search "
                " try to search different agents name"
            )

    @regression_test
    @author_neha_jha
    @pytestrail.case("C49")
    def test_functionality_of_switch_sort_in_unassigned_tab(self, driver):
        page = console_page.ConsolePage(driver)
        agent_management = agent_management_page.AgentsPage(driver)
        console_data_present = page.check_for_console_dashboard_display_data()
        if console_data_present:
            page.click_on_tab(ConsolePageTabs.NEW_TICKETS)
            present_of_unassigned_cases = (
                page.check_the_presence_of_cases_unassigned_cases()
            )
            if present_of_unassigned_cases:
                case_id_before_switch = agent_management.get_first_case_id_in_list()
                page.click_on_switch_sort_in_unassigned_tab()
                case_id_after_switch = agent_management.get_first_case_id_in_list()
                assert (
                    case_id_after_switch != case_id_before_switch
                ), " case id on support hub after switch and before switch is not same "

            else:
                LOGGER.info("no cases is present in unassigned cases")

        else:
            LOGGER.warning(
                "There are no present of agents related to the search "
                " try to search different agents name"
            )

    @regression_test
    @author_neha_jha
    @pytestrail.case("C2213")
    def test_functionality_of_filter_in_unassigned_tab(self, driver, console_setup):
        page = console_page.ConsolePage(driver)
        support_hub = SupportHub(driver)
        console_data_present = page.check_for_console_dashboard_display_data()
        if console_data_present:
            page.click_on_tab(ConsolePageTabs.NEW_TICKETS)
            present_of_unassigned_cases = (
                page.check_the_presence_of_cases_unassigned_cases()
            )
            if present_of_unassigned_cases:
                page.click_on_all_queues_filter_in_unassigned_tab()
                agent_name = page.get_text_of_first_option_in_all_queues()
                page.select_first_enable_option_in_all_queue_unassigned_tab()
                page.click_on_any_case_in_unassigned_list()
                assert (
                    support_hub.check_visibility_of_support_hub()
                ), "failed to display support hub"
                result = support_hub.get_agent_name()
                assert agent_name == result
            else:
                LOGGER.info("No cases is present in unassigned  cases")

        else:
            LOGGER.warning(
                "There are no present of agents related to the search "
                " try to search different agents name"
            )

    @regression_test
    @author_neha_jha
    @pytestrail.case("C2214")
    def test_functionality_of_assigned_bar_in_case_distribution_tab(
        self, driver, console_setup
    ):
        """if user click on assigned bar in the case  distribution tab then the
        bar chart should show hide the assigned ticket and should only show the tickets which are Unassigned"""

        support_hub = SupportHub(driver)
        page = console_page.ConsolePage(driver)
        console_data_present = page.check_for_console_dashboard_display_data()
        if console_data_present:
            page.click_on_tab(ConsolePageTabs.NEW_TICKETS)
            driver.refresh()
            page.click_on_assigned_or_unassigned_bar_in_case_distribution_if_enable(
                CaseDistributionBar.ASSIGNED
            )
            bar_chart_in_case_distribution = (
                page.check_the_presence_of_bar_chart_graph_in_case_distribution()
            )
            if bar_chart_in_case_distribution:
                page.click_on_case_distribution_tab_bar_chart_case()
                assert (
                    support_hub.check_visibility_of_support_hub()
                ), "failed to display support hub"
                unassigned_agent = page.get_text_agents_in_unassigned_cases()
                assert (
                    unassigned_agent == "Unassigned"
                ), " agents name is not equal to assigned cases"

            else:
                LOGGER.info("No bar is displayed in case distribution")

        else:
            LOGGER.warning(
                "There are no present of agents related to the search "
                " try to search different agents name"
            )

    @regression_test
    @author_neha_jha
    @pytestrail.case("C2215")
    def test_functionality_of_unassigned_bar_in_case_distribution_tab(
        self, driver, console_setup
    ):
        """if user click on assigned bar in the case  distribution tab then the
        bar chart should show hide the assigned ticket and should only show the tickets which are Unassigned"""
        support_hub = SupportHub(driver)
        page = console_page.ConsolePage(driver)
        console_data_present = page.check_for_console_dashboard_display_data()
        if console_data_present:
            page.click_on_tab(ConsolePageTabs.NEW_TICKETS)
            driver.refresh()
            page.click_on_assigned_or_unassigned_bar_in_case_distribution_if_enable(
                CaseDistributionBar.UNASSIGNED
            )
            bar_chart_in_case_distribution = (
                page.check_the_presence_of_bar_chart_graph_in_case_distribution()
            )
            if bar_chart_in_case_distribution:
                page.click_on_case_distribution_tab_bar_chart_case()
                assert (
                    support_hub.check_visibility_of_support_hub()
                ), "failed to display support hub"
                agent_name = page.result = support_hub.get_agent_name()
                assert agent_name != "Unassigned", "agents name is not equal to "
            else:
                LOGGER.info("No bar chart is present in  case distribution graph")

        else:
            LOGGER.warning(
                "There are no present of agents related to the search "
                " try to search different agents name"
            )

    @sanity_test
    @author_neha_jha
    @pytest.mark.console_filter_tests
    @pytestrail.case("C2216")
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_dynamic_filter(self, driver, dynamic_filter):
        sh = SupportHub(driver)
        page = console_page.ConsolePage(driver)
        console_data_present = page.check_for_console_dashboard_display_data()
        filter_obj = filters.Filters(driver)
        if console_data_present:

            filter_obj.click_on_dynamic_filter()
            dynamic_pop = filter_obj.validate_the_dynamic_filter_pop_up()
            assert dynamic_pop, "failed to display dynamic pop up "
            filter_obj.select_priority_filter_from_drop_down()
            filter_obj.click_on_add_filter()
            filter_obj.click_on_selected_dynamic_filter()
            filter_options = filter_obj.check_the_presence_of_filter_options_in_pop_up()
            if filter_options:
                dynamic_pop_up_options = filter_obj.get_text_of_priority_filter_option()
                filter_obj.click_on_first_option_from_dynamic_filter_applied()
                filter_obj.click_on_apply_filter_in_selected()
                console_data_present = page.check_for_console_dashboard_display_data()
                if console_data_present:
                    page.click_on_tab(ConsolePageTabs.NEW_TICKETS)
                    present_of_unassigned_cases = (
                        page.check_the_presence_of_cases_unassigned_cases()
                    )
                    if present_of_unassigned_cases:
                        page.click_on_any_case_in_unassigned_list()
                        assert (
                            sh.check_visibility_of_support_hub()
                        ), "failed to display support hub"
                        value = page.get_text_priority_support_hub()
                        assert (
                            value == dynamic_pop_up_options
                        ), "support hub is not filter based on option"
                    else:
                        LOGGER.warning("No cases present in unassigned cases")

                else:
                    LOGGER.warning("There are zero cases or no cases ")
            else:
                LOGGER.warning("No option is present based on priority option")
        else:
            LOGGER.warning("No data is displayed or No cases founded ")

    @author_neha_jha
    @regression_test
    @pytestrail.case("C70")
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_case_id_in_global_search(self, driver, console_setup):
        page = console_page.ConsolePage(driver)
        common_page = commons.Commons(driver)
        support_hub = SupportHub(driver)
        page.click_on_tab(ConsolePageTabs.NEW_TICKETS)
        present_of_unassigned_cases = (
            page.check_the_presence_of_cases_unassigned_cases()
        )
        if present_of_unassigned_cases:
            case_id = page.get_first_case_id_in_unassigned_tab()
            common_page.search_globally_for(case_id)
            support_hub.check_visibility_of_support_hub()
            case_id_from_support_hub = support_hub.get_case_id()
            assert case_id == case_id_from_support_hub
        else:
            LOGGER.info(
                "no case is present on unassigned tab - no case id to search in global search"
            )
            assert False

    @author_neha_jha
    @regression_test
    @pytestrail.case("C39")
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_footer_text_of_negative_positive_new_case_tabs(
        self, driver, console_setup
    ):
        page = console_page.ConsolePage(driver)
        time_filter = page.get_time_filter_in_console()
        filter = "Last 7 days"
        if filter != time_filter:
            page.click_time_filter_drop_down()
            page.select_filter_in_console(filter)
            time_filter_selected = page.get_time_filter_in_console()
            assert filter in time_filter_selected, "failed to displayed time filter"
        console_data_present = page.check_for_console_dashboard_display_data()
        if console_data_present:
            page.click_on_tab(ConsolePageTabs.NEW_TICKETS)
            assert page.validate_cards_based_on_filter_new_case_7_days()
            page.click_on_tab(ConsolePageTabs.POSITIVE_SENTIMENTS)
            assert page.validate_cards_based_on_filter_positive_card_footer()
            page.click_on_tab(ConsolePageTabs.NEGATIVE_SENTIMENTS)
            assert page.validate_cards_based_on_filter_negative_tab_footer()
        else:
            LOGGER.info("no data in console page")
            assert False

    @author_neha_jha
    @regression_test
    @pytestrail.case("C40")
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_footer_text_of_service_compliance_card(self, driver, console_setup):
        page = console_page.ConsolePage(driver)
        time_filter = page.get_time_filter_in_console()
        filter = "Last 7 days"
        if filter != time_filter:
            page.click_time_filter_drop_down()
            page.select_filter_in_console(filter)
            time_filter_selected = page.get_time_filter_in_console()
            assert filter in time_filter_selected, "failed to displayed time filter"
        console_data_present = page.check_for_console_dashboard_display_data()
        if console_data_present:
            page.click_on_tab(ConsolePageTabs.SERVICE_COMPLIANCE)
            assert page.validate_service_compliance_based_on_last_7_days_time_filter()
        else:
            LOGGER.info("no data is console page")
            assert False

    @author_neha_jha
    @regression_test
    @pytestrail.case("C41")
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_footer_text_of_need_attention_card(self, driver, console_setup):
        page = console_page.ConsolePage(driver)
        time_filter = page.get_time_filter_in_console()
        filter = "Last 7 days"
        if filter != time_filter:
            page.click_time_filter_drop_down()
            page.select_filter_in_console(filter)
            time_filter_selected = page.get_time_filter_in_console()
            assert filter in time_filter_selected, "failed to displayed time filter"
        console_data_present = page.check_for_console_dashboard_display_data()
        if console_data_present:
            page.click_on_tab(ConsolePageTabs.NEED_ATTENTION)
            page.click_on_grouped_by_on_tabs()
            page.select_filter_from_grouped_by(GroupByCustomFields.ELAPSED_TIME)
            toggle_status = page.get_text_expand_or_collapse_toggle_on_sentiments_tab()
            if toggle_status == "Collapse All":
                page.click_on_expand_collapse_toggle_on_sentiments()
            assert page.validate_need_attention_based_on_last_7_days_time_filter()
        else:
            LOGGER.info("no data is console page ")
            assert False

    @author_neha_jha
    @pytestrail.case("C2155")
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_functionality_of_check_button_in_escalations_tab(
        self, driver, console_setup
    ):
        support_hub = SupportHub(driver)
        page = console_page.ConsolePage(driver)
        console_data_present = page.check_for_console_dashboard_display_data()
        if console_data_present:
            page.click_on_tab(ConsolePageTabs.ESCALATIONS)
            assert (
                page.check_card_present_under_likely_to_escalated_card()
            ), "no case displayed on likely to be escalated"
            page.click_on_likely_to_escalated_card()
            assert (
                support_hub.check_visibility_of_support_hub()
            ), "failed to display support hub"
            if (
                page.check_for_presence_of_likely_to_be_escalated_banner_in_support_hub()
            ):
                if (
                    page.check_for_presence_of_check_button_in_likely_to_be_escalated()
                    is False
                ):
                    page.click_on_undo_button_likely_to_be_escalated_support_hub()
                time.sleep(2)
                page.click_on_check_button_likely_to_be_escalated_support_hub()
                assert (
                    page.check_for_you_took_care_of_it_text_in_likely_escalated_banner()
                )
                support_hub.close_support_hub_window()
                page.check_the_presence_of_few_second_ago_in_first_escalation_tab()

            else:
                raise Exception("no  likely to escalated banner present in support hub")
        else:
            LOGGER.warning("There are zero cases or no cases ")
            assert False, "no data "

    @author_neha_jha
    @regression_test
    @pytestrail.case("C3760")
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_functionality_of_bar_graph_present_on_escalation_tab(
        self, driver, console_setup
    ):
        page = console_page.ConsolePage(driver)
        console_data_present = page.check_for_console_dashboard_display_data()
        if console_data_present:
            page.click_on_tab(ConsolePageTabs.ESCALATIONS)
            assert page.checking_visibility_of_bar_graph_on_escalation_tab()
        else:
            assert False, "no data on console page"

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C33")
    def test_module_state_disabled(self, driver):
        api_helpers = ApiKeywords(driver)
        navbar = Navbar(driver)

        try:
            api_helpers.edit_module_state({NavbarItem.CONSOLE: ModuleState.DISABLED})
            driver.refresh()
            assert (
                navbar.has_navbar_module(NavbarItem.CONSOLE) is False
            ), "Failed to disable Console page"
        finally:
            api_helpers.edit_module_state({NavbarItem.CONSOLE: ModuleState.ENABLED})
            driver.refresh()

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C34")
    def test_module_state_locked(self, driver):
        api_helpers = ApiKeywords(driver)
        navbar = Navbar(driver)

        try:
            api_helpers.edit_module_state({NavbarItem.CONSOLE: ModuleState.LOCKED})
            driver.refresh()
            assert navbar.has_navbar_module(
                NavbarItem.CONSOLE
            ), "Console page is disabled"
            navbar.navigate_to_navbar_page(NavbarItem.CONSOLE)
            assert navbar.is_element_visible(
                (By.CSS_SELECTOR, cl.module_locked_icon)
            ), "Lock icon is not displayed when module is locked in prod edition"
            assert navbar.is_element_visible(
                (By.CSS_SELECTOR, cl.sl_sales_contact)
            ), "No contact info is displayed when module is locked in prod edition"
        finally:
            api_helpers.edit_module_state({NavbarItem.CONSOLE: ModuleState.ENABLED})
            driver.refresh()

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C35")
    def test_module_state_enabled(self, driver):
        api_helpers = ApiKeywords(driver)
        console = console_page.ConsolePage(driver)
        navbar = Navbar(driver)

        api_helpers.edit_module_state({NavbarItem.CONSOLE: ModuleState.ENABLED})
        navbar.navigate_to_navbar_page(NavbarItem.CONSOLE)
        assert navbar.has_navbar_module(NavbarItem.CONSOLE), "Console page is disabled"
        assert (
            console.check_if_time_filter_in_console_dashboard()
        ), "Time Filter element is not displayed"
