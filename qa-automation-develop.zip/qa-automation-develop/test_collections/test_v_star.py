"""Test class for V*"""

__author__ = "Praveen Nagajothi"
__copyright__ = "Copyright (C) 2022 SupportLogic"

import logging
import time

import pytest
from pytest_testrail.plugin import pytestrail
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By

import constants
import utils
from constants import author_praveen_nj, regression_test, skip_test
from enums import NavbarItem, SettingsSectionUrlSuffix, UserMenuOption, VStarType
from locators import common_locators as cl
from locators import settings_locators as sl
from locators import v_star_locators as vsl
from pom_library.commons import Commons
from pom_library.navbar import Navbar
from pom_library.settings_page import SettingsPage
from pom_library.v_star import VStar

LOGGER: logging.Logger = logging.getLogger(__name__)


class TestVStar:
    v_star_name: str = None

    @pytest.fixture(scope="class")
    def virtual_accounts_setup(self, driver):
        navbar = Navbar(driver)
        commons = Commons(driver)

        commons.wait_for_loader_to_disappear()
        current_page_url = navbar.navigate_to_navbar_page(NavbarItem.VIRTUAL_ACCOUNTS)
        assert (
            "virtual-accounts" in current_page_url
        ), "Failed to load Virtual Accounts module"
        commons.start_module_onboarding()

    @pytest.fixture(scope="class")
    def virtual_teams_setup(self, driver):
        navbar = Navbar(driver)
        commons = Commons(driver)

        commons.wait_for_loader_to_disappear()
        current_page_url = navbar.navigate_to_navbar_page(NavbarItem.VIRTUAL_TEAMS)
        assert (
            "virtual-teams" in current_page_url
        ), "Failed to load Virtual Teams module"
        commons.start_module_onboarding()

    @pytest.fixture
    def va_creation_deletion(self, driver, virtual_accounts_setup):
        v_star = VStar(driver)

        self.v_star_name = utils.generate_test_run_id(
            constants.VA_GLOBAL_RUN_ID_PREFIX, iterate=False
        )
        customers_to_select = v_star.get_client_names(size=2)
        LOGGER.info(f"Customers to select: {customers_to_select}")

        try:
            v_star.create_global_virtual_account(self.v_star_name, customers_to_select)
            assert v_star.is_element_visible(
                (
                    By.XPATH,
                    vsl.custom_virtual_star_item_name.format(name=self.v_star_name),
                )
            )
            yield
            v_star.click_virtual_account_delete_button(self.v_star_name)
            v_star.click_delete_confirmation_button()
        except TimeoutException as e:
            if v_star.is_element_visible(
                (By.CSS_SELECTOR, vsl.create_virtual_account_button_css)
            ):
                v_star.click_on_element((By.CSS_SELECTOR, vsl.cancel_button_css))
            v_star.click_cancel_button()
            raise Exception(
                f"{e.__class__.__name__}: {e}\nLine no: {e.__traceback__.tb_lineno}"
            )

    @pytest.fixture
    def vt_creation_deletion(self, driver, virtual_teams_setup):
        v_star = VStar(driver)

        self.v_star_name = utils.generate_test_run_id(
            constants.VT_GLOBAL_RUN_ID_PREFIX, iterate=False
        )
        agents_to_select = v_star.get_agent_names(size=2)
        LOGGER.info(f"Agents to select: {agents_to_select}")

        try:
            v_star.create_global_virtual_team(self.v_star_name, agents_to_select)
            yield
            v_star.click_virtual_team_delete_button(self.v_star_name)
            v_star.click_delete_confirmation_button()
        except TimeoutException as e:
            if v_star.is_element_visible(
                (By.CSS_SELECTOR, vsl.create_virtual_account_button_css)
            ):
                v_star.click_on_element((By.CSS_SELECTOR, vsl.cancel_button_css))
            v_star.click_cancel_button()
            raise Exception(
                f"{e.__class__.__name__}: {e}\nLine no: {e.__traceback__.tb_lineno}"
            )

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C740")
    def test_name_error_when_using_existing_va_name_with_space(
        self, driver, va_creation_deletion
    ):
        v_star = VStar(driver)

        v_star.click_create_virtual_account_button()
        v_star.choose_new_v_star_type(VStarType.GLOBAL_ACCOUNT)
        v_star.enter_new_v_star_name(self.v_star_name.replace("Global", "Glo b a l"))

        assert v_star.is_element_visible(
            (By.CSS_SELECTOR, vsl.name_error_message)
        ), "Name error is not shown for space influenced existing VA name"
        assert (
            driver.find_element(By.CSS_SELECTOR, vsl.name_error_message).text
            == "This name is already taken."
        ), "Error message is different from expected"
        # cleanup
        driver.find_element(By.CSS_SELECTOR, vsl.cancel_button_css).click()

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C742")
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_delete_va(self, driver, virtual_accounts_setup):
        v_star = VStar(driver)

        # delete newly created VA
        va_name = utils.generate_test_run_id(constants.VA_GLOBAL_RUN_ID_PREFIX)
        customers_to_select = v_star.get_client_names(size=2)
        LOGGER.info(f"agents to select: {customers_to_select}")

        v_star.create_global_virtual_account(va_name, customers_to_select)
        v_star.click_virtual_account_delete_button(va_name)
        v_star.click_delete_confirmation_button()

        time.sleep(5)
        locator = (By.XPATH, vsl.custom_virtual_star_item_name.format(name=va_name))
        assert v_star.is_element_visible(locator) is False

        # verify only 1 delete modal popover is displayed
        # this portion of the test runs only when there's at least 3 VAs
        available_v_account_names = v_star.get_virtual_account_names()
        if len(available_v_account_names) >= 3:
            for account_name in available_v_account_names[:3]:
                va_locator = (
                    vsl.custom_virtual_star_item_name.format(name=account_name)
                    + vsl.virtual_account_list_item + vsl.virtual_star_collapse_button
                )
                element = driver.find_element(By.XPATH, va_locator)
                driver.execute_script(
                    "arguments[0].scrollIntoView({block: 'center'});", element
                )
                v_star.click_virtual_account_delete_button(account_name)

                time.sleep(5)
                del_conf_button = driver.find_elements(
                    By.XPATH, vsl.delete_confirmation_button
                )
                assert len(del_conf_button) == 1, "More than 1 delete modal is present"
                # cleanup
                v_star.click_cancel_button()

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C743")
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_edit_va(self, driver, va_creation_deletion):
        v_star = VStar(driver)

        edited_va_name = self.v_star_name + " edit"
        v_star.click_virtual_account_edit_button(self.v_star_name)
        v_star.edit_existing_or_cloned_v_star_name(self.v_star_name, edited_va_name)
        v_star.click_save_button()

        assert v_star.is_element_visible(
            (By.XPATH, vsl.custom_virtual_star_item_name.format(name=edited_va_name))
        ), f"Failed to edit {self.v_star_name}"

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C744")
    @skip_test(reason="Created VA not reflected in user prefs favorite customer search")
    def test_add_created_va_to_favorites(self, driver, va_creation_deletion):
        commons = Commons(driver)

        commons.go_to_user_menu_option(UserMenuOption.PREFERENCES)
        driver.find_element(
            By.CSS_SELECTOR, cl.preference_fav_customers_search_css
        ).send_keys(self.v_star_name)
        time.sleep(2)  # waiting for the result to appear

        element = driver.find_element(
            By.CSS_SELECTOR, cl.preference_fav_customers_search_result_item_css
        )
        assert (
            element.text == self.v_star_name
        ), f"{self.v_star_name} did not appear in user prefs favorite customer search"

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C2191")
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_copy_va(self, driver, va_creation_deletion):
        v_star = VStar(driver)

        cloned_va_name: str = self.v_star_name + " Copy"
        va_name_after_edit: str = self.v_star_name + " edit"

        v_star.click_virtual_account_clone_button(self.v_star_name)
        assert v_star.is_element_visible(
            (By.XPATH, vsl.custom_virtual_star_item_name.format(name=cloned_va_name))
        ), f"Failed to edit {self.v_star_name}"

        v_star.edit_existing_or_cloned_v_star_name(cloned_va_name, va_name_after_edit)
        v_star.click_save_button()

        locator = vsl.custom_virtual_star_item_name.format(name=va_name_after_edit)
        assert v_star.is_element_visible(
            (By.XPATH, locator)
        ), f"Failed to edit {self.v_star_name}"

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C2191")
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_copy_vt(self, driver, vt_creation_deletion):
        v_star = VStar(driver)

        cloned_vt_name: str = self.v_star_name + " Copy"
        vt_name_after_edit: str = self.v_star_name + " edit"

        v_star.click_virtual_team_clone_button(self.v_star_name)
        assert v_star.is_element_visible(
            (By.XPATH, vsl.custom_virtual_star_item_name.format(name=cloned_vt_name))
        ), f"Failed to edit {self.v_star_name}"

        v_star.edit_existing_or_cloned_v_star_name(cloned_vt_name, vt_name_after_edit)
        v_star.click_save_button()

        locator = vsl.custom_virtual_star_item_name.format(name=vt_name_after_edit)
        assert v_star.is_element_visible(
            (By.XPATH, locator)
        ), f"Failed to edit {self.v_star_name}"

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C2340")
    @pytest.mark.xfail(reason="Created VT not returned in default team search results")
    def test_delete_message_default_vt_vo(self, driver, vt_creation_deletion):
        v_star = VStar(driver)
        navbar = Navbar(driver)
        settings = SettingsPage(driver)

        try:
            settings.go_to_settings_section(SettingsSectionUrlSuffix.CASE_ASSIGNMENT)
            settings.hover_on_element((By.XPATH, sl.case_assignment_default_team_text))

            default_team_name = self.v_star_name
            if not settings.is_element_visible((By.XPATH, sl.set_default_team_button), 5):
                settings.click_on_element(
                    (By.CSS_SELECTOR, sl.current_default_team_x_icon_css)
                )
                settings.click_on_element((By.XPATH, sl.popup_remove_button))
            settings.click_on_element((By.XPATH, sl.set_default_team_button))
            settings.pass_value_to_element(
                default_team_name,
                (By.CSS_SELECTOR, sl.set_default_team_popup_search_css),
            )
            locator = sl.set_default_team_popup_search_result.format(
                vt_name=default_team_name
            )
            settings.click_on_element((By.XPATH, locator))
        finally:
            current_page_url = navbar.navigate_to_navbar_page(NavbarItem.VIRTUAL_TEAMS)

        assert (
            "virtual-teams" in current_page_url
        ), "Failed to load Virtual Teams module"
        v_star.click_virtual_team_delete_button(default_team_name)
        assert v_star.is_element_visible(
            (By.XPATH, vsl.delete_popup_default_team_warning_text)
        ), "Warning message is not displayed when trying to delete default team/org"
        v_star.click_cancel_button()
