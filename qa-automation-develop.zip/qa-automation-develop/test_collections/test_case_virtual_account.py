"""This is the test class for customer management page"""
__author__ = "Neha Jha"
__copyright__ = "Copyright (C) 2021 SupportLogic"

import logging
import time

import pytest
from pytest_testrail.plugin import pytestrail

import constants
import utils
from constants import author_neha_jha, regression_test, sanity_test
from enums import NavbarItem
from pom_library import commons, customer_management_page, virtual_accounts_page
from pom_library.commons import Commons
from pom_library.navbar import Navbar

LOGGER = logging.getLogger(__name__)


@pytest.mark.usefixtures("driver")
class TestVirtualAccount(object):

    @pytest.fixture()
    def virtual_account_setup(self, driver):
        common_page = commons.Commons(driver)
        customer = customer_management_page.CustomerManagementPage(driver)
        navbar = Navbar(driver)
        current_url = navbar.navigate_to_navbar_page(NavbarItem.VIRTUAL_ACCOUNTS)
        assert "virtual-accounts" in current_url, "failed to  load virtual account page"
        common_page.start_module_onboarding()
        common_page.wait_for_loader_to_disappear()
        yield
        customer.virtual_account_pop_up_close()

    @regression_test
    @author_neha_jha
    @pytestrail.case('C749')
    def test_add_vg_favorite(self, driver, virtual_account_setup):
        page = virtual_accounts_page.VirtualAccountsPage(driver)
        commons = Commons(driver)
        customer = customer_management_page.CustomerManagementPage(driver)
        agents_name = page.get_virtual_group_name()
        page.click_on_first_vg()
        window_handles = driver.window_handles
        driver.switch_to.window(window_handles[1])
        time.sleep(5)
        try:
            commons.wait_for_loader_to_disappear()
            favorites_agents = customer.validate_profile_added_favorites()
            profile_agent_name = customer.get_text_profile_customer()
            if favorites_agents:
                LOGGER.warning("already added to favorites list")
                customer.click_add_favorites()
                assert customer.validate_profile_added_favorites() is False, f"{agents_name} is not removed from fav list"

            navbar = Navbar(driver)

            customer.click_add_favorites()  # add fav
            navbar.navigate_to_navbar_page(NavbarItem.FAVORITES)
            commons.start_module_onboarding()

            check_for_va_add_to_list=customer.check_favorites_agents_is_displayed(profile_agent_name)
            assert check_for_va_add_to_list
            driver.close()
            driver.switch_to.window(window_handles[0])
        except:
            driver.close()
            driver.switch_to.window(window_handles[0])
            assert False, "failed to test vg as favorites"


    @sanity_test
    @author_neha_jha
    @pytestrail.case('C2259')
    def test_functionality_of_virtual_account_profile_in_customer_insight(self, driver, virtual_account_setup):
        """1.expand the virtual account and get the first virtual account name
         2. click on the virtual account
         3. navigate newly open tab
         4.get the virtual account or agents name
         assert both the virtual account and agents name if same pass or fail
         """
        virtual_account = virtual_accounts_page.VirtualAccountsPage(driver)
        customer = customer_management_page.CustomerManagementPage(driver)
        commons = Commons(driver)
        virtual_account.click_virtual_virtual_group_name_expand()
        virtual_group_name = customer.get_text_virtual_group_agents()
        customer.click_virtual_group_agents()

        window_handles = driver.window_handles
        driver.switch_to.window(window_handles[1])
        time.sleep(5)
        commons.wait_for_loader_to_disappear()
        virtual_group_profile_name = customer.get_text_virtual_group_profile_name()
        assert (
                virtual_group_name == virtual_group_profile_name
        ), " virtual group name and profile name does not match"

        driver.close()
        driver.switch_to.window(window_handles[0])
        virtual_account.click_on_close_expand_virtual_group()

    @sanity_test
    @author_neha_jha
    @pytestrail.case('C2260')
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_virtual_account_group_loaded(self, driver, virtual_account_setup):
        """This test case checks if the virtual accounts page loads successfully showing
        all its contents as expected"""
        page = customer_management_page.CustomerManagementPage(driver)
        virtual_data = page.virtual_account_group_data()
        assert virtual_data, "virtual account group data is not loaded"

    @pytestrail.case('C2261')
    def test_page_is_having_expected_url_and_title(self, driver):
        """This test case focuses on fetching the current/actual url and title of the
        virtual accounts page and to verify it with the expected results"""
        page = virtual_accounts_page.VirtualAccountsPage(driver)
        # click on the page to see if it is clickable or not
        navbar = Navbar(driver)
        navbar.navigate_to_navbar_page(NavbarItem.VIRTUAL_ACCOUNTS)
        title_fetched = (
            page.fetch_the_title_of_the_page()
        )  # Verify the title of the page:
        assert (
                constants.title_of_va == title_fetched
        )  # verifying the actual and expected results
        actual_url = page.fetch_the_url_of_the_page()
        assert (
                constants.url_expectations["expected_url_va"] in actual_url
        )  # verifying the actual and expected results

    @pytestrail.case('C2262')
    def test_page_has_loaded_successfully(self, driver):
        """This test case checks if the virtual accounts page loads successfully showing
        all its contents as expected"""
        page = virtual_accounts_page.VirtualAccountsPage(driver)
        page.check_if_the_page_loaded_successfully()

    @regression_test
    @author_neha_jha
    @pytestrail.case('C741')
    def test_functionality_creating_virtual_account_existing_name(self, driver, virtual_account_setup):
        page = virtual_accounts_page.VirtualAccountsPage(driver)
        first_virtual_account_name = page.get_text_first_virtual_account_name()
        page.click_on_create_virtual_account()
        page.click_on_global_account()
        page.create_name_for_global_account(first_virtual_account_name)
        assert page.name_already_existing_error_message_is_displayed(), "error message is  not displayed"

    @regression_test
    @author_neha_jha
    @pytestrail.case('C737')
    def test_functionality_blank_global_account_name(self, driver, virtual_account_setup):
        page = virtual_accounts_page.VirtualAccountsPage(driver)
        page.click_on_create_virtual_account()
        page.click_on_global_account()
        assert page.check_the_next_button_is_enable() is False, " Next button is enable"

    @regression_test
    @author_neha_jha
    @pytestrail.case('C2263')
    def test_functionality_of_selecting_one_agents_account(self, driver, virtual_account_setup):
        page = virtual_accounts_page.VirtualAccountsPage(driver)
        page.click_on_create_virtual_account()
        page.click_on_global_account()
        va_name = utils.generate_test_run_id(constants.VA_GLOBAL_RUN_ID_PREFIX)
        page.create_name_for_global_account(va_name)
        page.click_on_next_button()
        page.search_agents_in_virtual_account()
        page.select_first_virtual_account_or_agents()
        assert page.check_the_create_is_enable() is False, "create button is enable"

    @pytest.mark.skipif("aruba-staging" in utils.get_app_url(), reason="aruba")
    @regression_test
    @author_neha_jha
    @pytestrail.case('C746')
    def test_functionality_of_creating_virtual_group(self, driver, virtual_account_setup):
        page = virtual_accounts_page.VirtualAccountsPage(driver)
        va_name = page.create_virtual_group()
        assert page.check_for_virtual_account_or_group_present_or_not(va_name), "failed to add virtual account"


    @pytest.mark.skipif("aruba-staging" in utils.get_app_url(), reason="aruba")
    @regression_test
    @author_neha_jha
    @pytestrail.case('C747')
    def test_delete_virtual_group_functionality(self, driver, virtual_account_setup):
        page = virtual_accounts_page.VirtualAccountsPage(driver)
        va_name = page.create_virtual_group()
        assert page.check_for_virtual_account_or_group_present_or_not(va_name), "failed to add virtual account"
        page.click_on_delete_first_virtual_group(va_name)
        page.click_on_delete_button_on_pop_up()
        time.sleep(5)
        # this method helps to check that  is deleted
        assert page.check_for_virtual_account_or_group_present_or_not(va_name) is False, "failed to delete virtual group"

    @pytest.mark.skipif("aruba-staging" in utils.get_app_url(), reason="aruba")
    @regression_test
    @author_neha_jha
    @pytestrail.case('C748')
    def test_functionality_of_edit_virtual_group(self, driver, virtual_account_setup):
        """ this method helps to checks that virtual group name can be edit or not"""

        page = virtual_accounts_page.VirtualAccountsPage(driver)
        va_name = page.create_virtual_group()
        assert page.check_for_virtual_account_or_group_present_or_not(va_name), "failed to add group"
        va_name_after_edit = va_name + "edit"
        page.click_on_edit_virtual_group(va_name)
        page.edit_virtual_group_name(va_name_after_edit)
        time.sleep(1)
        page.click_on_save_button()
        assert page.check_for_virtual_account_or_group_present_or_not(va_name_after_edit)



    @pytest.mark.skipif("aruba-staging" in utils.get_app_url(), reason="aruba")
    @sanity_test
    @author_neha_jha
    @pytestrail.case('C739')
    def test_create_a_virtual_account(self, driver, virtual_account_setup):
        """This test case checks the creation of the virtual account, validating the
        created virtual account is actually shown in the page"""
        page = virtual_accounts_page.VirtualAccountsPage(driver)
        va_name =page.create_virtual_account()
        assert page.check_for_virtual_account_or_group_present_or_not(va_name), "failed to add virtual account"


