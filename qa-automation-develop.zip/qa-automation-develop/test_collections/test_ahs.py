"""This is the test class for customer management page"""
__author__ = "Neha Jha"
__copyright__ = "Copyright (C) 2021 SupportLogic"

import logging
import pytest
from pytest_testrail.plugin import pytestrail
from selenium.webdriver.common.by import By
import utils
from locators import ahs_locator
from pom_library.commons import Commons
LOGGER = logging.getLogger(__name__)
import constants
from constants import author_neha_jha,regression_test
from enums import NavbarItem
from pom_library import  ahs_page,customer_board_page
from pom_library.navbar import Navbar



class TestAhs:

    @pytest.fixture(scope="class",autouse="True")
    def get_name_customer(self, driver):
        ahs = ahs_page.AhsPage(driver)
        customer_board = customer_board_page.CustomerBoardPage(driver)
        navbar = Navbar(driver)
        current_url = navbar.navigate_to_navbar_page(NavbarItem.CUSTOMER_BOARD)
        assert "customer-board" in current_url, "failed to load customer board page"
        customer_board.click_plus_button()
        choose_list_you_like_add_pop_up = customer_board.check_present_choose_list_pop_up()
        assert (
            choose_list_you_like_add_pop_up
        ), "choose list you like to add pop up is failed to displayed "
        customer_board.click_ranked_by_health_assessment()
        list_name_CB = utils.generate_test_run_id(constants.CUSTOMER_BOARD_RUN_ID_PREFIX)
        customer_board.create_list_name(list_name_CB)
        customer_board.click_on_add_button()
        customer_board.click_vertical_dots_list()
        customer_board.click_on_edit_list()
        customer_board.click_on_customer_field()
        customer_board.click_on_health_assessment()
        customer_board.select_the_health_assessment_filter_by_pop_up(value="Good")
        customer_board.click_on_filter()
        customer_board.click_on_apply_changes()
        good_customer_name = customer_board.check_cases_is_present_on_first_list()
        window_handles = driver.window_handles
        driver.switch_to.window(window_handles[1])
        # commons.wait_for_loader_to_disappear()
        health_score = ahs.get_ahs_health_score()
        assert health_score == "GOOD"

        yield
        driver.close()
        driver.switch_to.window(window_handles[0])

    @regression_test
    @author_neha_jha
    @pytestrail.case("C6486")
    def test_verify_disagree_flow_from_good_to_fair_with_comments_and_with_escalation(self, driver):
        ahs = ahs_page.AhsPage(driver)
        edit_button = ahs.check_for_edit_button_is_present_or_not()
        if edit_button:
            ahs.click_on_edit_button()
        assert ahs.check_present_of_thump_down_and_present_of_thumbs_up()
        ahs.click_on_disagree_button_health_assessment()
        ahs.click_on_fair_button()
        ahs.adding_comment_in_the_comment_section_of_gud_customer(comment="fair")
        ahs.click_on_disagree_button_escalation_option(escalated_option="Yes")
        ahs.click_on_save_button()
        assessment_text = ahs.get_assessment_text_near_edit_button()
        assert assessment_text == "Fair","fair assessment text is not displayed"

    @regression_test
    @author_neha_jha
    @pytestrail.case("C6487")
    def test_verify_disagree_flow_from_good_to_bad_with_comments_and_with_escalation(self, driver):
        ahs = ahs_page.AhsPage(driver)
        edit_button = ahs.check_for_edit_button_is_present_or_not()
        if edit_button:
            ahs.click_on_edit_button()
        assert ahs.check_present_of_thump_down_and_present_of_thumbs_up()
        ahs.click_on_disagree_button_health_assessment()
        ahs.click_on_bad_button()
        ahs.adding_comment_in_the_comment_section_of_gud_customer(comment="bad")
        ahs.click_on_disagree_button_escalation_option(escalated_option="Yes")
        ahs.click_on_save_button()
        assessment_text = ahs.get_assessment_text_near_edit_button()
        assert assessment_text == "Bad", "bad assessment text is not displayed"

    @regression_test
    @author_neha_jha
    @pytestrail.case("C6493")
    def test_verify_disagree_flow_from_good_to_bad_with_comments_and_with_not_sure_escalation(self, driver):
        ahs = ahs_page.AhsPage(driver)
        edit_button = ahs.check_for_edit_button_is_present_or_not()
        if edit_button:
            ahs.click_on_edit_button()
        assert ahs.check_present_of_thump_down_and_present_of_thumbs_up()
        ahs.click_on_disagree_button_health_assessment()
        ahs.click_on_bad_button()
        ahs.adding_comment_in_the_comment_section_of_gud_customer(comment="bad")
        ahs.click_on_disagree_button_escalation_option(escalated_option="Not sure")
        ahs.click_on_save_button()
        assessment_text = ahs.get_assessment_text_near_edit_button()
        assert assessment_text == "Bad", "bad assessment text is not displayed"

    @regression_test
    @author_neha_jha
    @pytestrail.case("C6492")
    def test_verify_disagree_flow_from_good_to_fair_with_comments_and_with_not_sure_escalation(self, driver):
        ahs = ahs_page.AhsPage(driver)
        edit_button = ahs.check_for_edit_button_is_present_or_not()
        if edit_button:
            ahs.click_on_edit_button()
        assert ahs.check_present_of_thump_down_and_present_of_thumbs_up()
        ahs.click_on_disagree_button_health_assessment()
        ahs.click_on_fair_button()
        ahs.adding_comment_in_the_comment_section_of_gud_customer(comment="fair")
        ahs.click_on_disagree_button_escalation_option(escalated_option="Not sure")
        ahs.click_on_save_button()
        assessment_text = ahs.get_assessment_text_near_edit_button()
        assert assessment_text == "Fair", "bad assessment text is not displayed"

    @regression_test
    @author_neha_jha
    @pytestrail.case("C6499")
    def test_verify_disagree_flow_from_good_to_bad_with_comments_and_with_not_escalation(self, driver):
        ahs = ahs_page.AhsPage(driver)
        edit_button = ahs.check_for_edit_button_is_present_or_not()
        if edit_button:
            ahs.click_on_edit_button()
        assert ahs.check_present_of_thump_down_and_present_of_thumbs_up()
        ahs.click_on_disagree_button_health_assessment()
        ahs.click_on_bad_button()
        ahs.adding_comment_in_the_comment_section_of_gud_customer(comment="bad")
        ahs.click_on_disagree_button_escalation_option(escalated_option="No")
        ahs.click_on_save_button()
        assessment_text = ahs.get_assessment_text_near_edit_button()
        assert assessment_text == "Bad", "bad assessment text is not displayed"

    @regression_test
    @author_neha_jha
    @pytestrail.case("C6447")
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_verify_that_agree_and_disagree_button_tooltip(self, driver):
        ahs = ahs_page.AhsPage(driver)
        edit_button = ahs.check_for_edit_button_is_present_or_not()
        if edit_button:
            ahs.click_on_edit_button()
        ahs.hover_on_agree_icon()
        assert ahs.is_element_visible(
            (By.XPATH, ahs_locator.agree_health_assessment_popup))
        ahs.hover_on_disagree_icon()
        assert ahs.is_element_visible(
            (By.XPATH, ahs_locator.disagree_health_assessment_pop_up))

    @regression_test
    @author_neha_jha
    @pytestrail.case("C6448")
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_verify_agree_cancel_workflow(self, driver):
        ahs = ahs_page.AhsPage(driver)
        edit_button = ahs.check_for_edit_button_is_present_or_not()
        if edit_button:
            ahs.click_on_edit_button()
        assert ahs.check_present_of_thump_down_and_present_of_thumbs_up()
        ahs.click_on_agree_button_health_assessment()
        ahs.click_on_cancel_button()
        assert ahs.check_for_edit_button_is_present_or_not() is False

    @regression_test
    @author_neha_jha
    @pytestrail.case("C6481")
    def test_verify_disagree_flow_from_good_to_bad_with_comments(self, driver):
        ahs = ahs_page.AhsPage(driver)
        edit_button = ahs.check_for_edit_button_is_present_or_not()
        if edit_button:
            ahs.click_on_edit_button()
        assert ahs.check_present_of_thump_down_and_present_of_thumbs_up()
        ahs.click_on_disagree_button_health_assessment()
        ahs.click_on_bad_button()
        ahs.adding_comment_in_the_comment_section_of_gud_customer(comment="bad")
        ahs.click_on_save_button()
        assessment_text = ahs.get_assessment_text_near_edit_button()
        assert assessment_text == "Bad", "bad assessment text is not displayed"

    @regression_test
    @author_neha_jha
    @pytestrail.case("C6480")
    def test_verify_disagree_flow_from_good_to_fair_with_comments(self, driver):
        ahs = ahs_page.AhsPage(driver)
        edit_button = ahs.check_for_edit_button_is_present_or_not()
        if edit_button:
            ahs.click_on_edit_button()
        assert ahs.check_present_of_thump_down_and_present_of_thumbs_up()
        ahs.click_on_disagree_button_health_assessment()
        ahs.click_on_fair_button()
        ahs.adding_comment_in_the_comment_section_of_gud_customer(comment="fair")
        ahs.click_on_save_button()
        assessment_text = ahs.get_assessment_text_near_edit_button()
        assert assessment_text == "Fair", "fair assessment text is not displayed"

    @regression_test
    @author_neha_jha
    @pytestrail.case("C6498")
    def test_verify_disagree_flow_from_good_to_fair_with_comments_and_with_not_escalation(self, driver,
                                                                                          ):
        ahs = ahs_page.AhsPage(driver)
        edit_button = ahs.check_for_edit_button_is_present_or_not()
        if edit_button:
            ahs.click_on_edit_button()
        assert ahs.check_present_of_thump_down_and_present_of_thumbs_up()
        ahs.click_on_disagree_button_health_assessment()
        ahs.click_on_fair_button()
        ahs.adding_comment_in_the_comment_section_of_gud_customer(comment="fair")
        ahs.click_on_disagree_button_escalation_option(escalated_option="No")
        ahs.click_on_save_button()
        assessment_text = ahs.get_assessment_text_near_edit_button()
        assert assessment_text == "Fair", "fair assessment text is not displayed"

    @regression_test
    @author_neha_jha
    @pytestrail.case("C6478")
    def test_verify_disagree_flow_from_fair_to_good_with_comments(self, driver):
        ahs = ahs_page.AhsPage(driver)
        edit_button = ahs.check_for_edit_button_is_present_or_not()
        if edit_button:
            ahs.click_on_edit_button()
        assert ahs.check_present_of_thump_down_and_present_of_thumbs_up()
        ahs.click_on_disagree_button_health_assessment()
        ahs.click_on_good_button()
        ahs.adding_comment_in_the_comment_section_of_gud_customer(comment="fair")
        ahs.click_on_save_button()
        assessment_text = ahs.get_assessment_text_near_edit_button()
        assert assessment_text ==  "Good", "good assessment text is not displayed"

    @regression_test
    @author_neha_jha
    @pytestrail.case("C6479")
    def test_verify_disagree_flow_from_fair_to_bad_with_comments(self, driver):
        ahs = ahs_page.AhsPage(driver)
        edit_button = ahs.check_for_edit_button_is_present_or_not()
        if edit_button:
            ahs.click_on_edit_button()
        assert ahs.check_present_of_thump_down_and_present_of_thumbs_up()
        ahs.click_on_disagree_button_health_assessment()
        ahs.click_on_bad_button()
        ahs.adding_comment_in_the_comment_section_of_gud_customer(comment="bad")
        ahs.click_on_save_button()
        assessment_text = ahs.get_assessment_text_near_edit_button()
        assert assessment_text == "Bad", "good assessment text is not displayed"

