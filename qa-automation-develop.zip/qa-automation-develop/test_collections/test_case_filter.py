"""This is the test class for  filter """
__author__ = "Neha Jha"
__copyright__ = "Copyright (C) 2021 SupportLogic"

import logging
import time
from datetime import datetime, timedelta, timezone

import pytest
from pytest_testrail.plugin import pytestrail
from selenium.common.exceptions import NoSuchElementException, TimeoutException
from selenium.webdriver.common.by import By

from constants import (
    author_neha_jha, author_praveen_nj, author_vignesh_k, regression_test, sanity_test,
)
from enums import (
    ConsolePageTabs, ControlCenterMenuItem, NavbarItem, SettingsSectionUrlSuffix,
    TrendsPageContentTabs,
)
from locators import console_page_locators as cpl
from locators import filter_locators
from pom_library import ace_page, case_board_page, console_page, filters
from pom_library.api_keywords import ApiKeywords
from pom_library.keywords_and_trends import KeywordsAndTrends
from pom_library.navbar import Navbar
from pom_library.settings_page import SettingsPage
from pom_library.support_hub import SupportHub

LOGGER = logging.getLogger(__name__)


class TestFilter(object):
    @pytest.fixture()
    def filter_setup(self, driver):
        navbar = Navbar(driver)
        filter_obj = filters.Filters(driver)
        current_url =navbar.navigate_to_navbar_page(NavbarItem.CONSOLE)
        assert "console" in current_url,"failed to load current url"
        yield
        support_hub= SupportHub(driver)
        try:
            support_hub.close_support_hub_window()
        except:
            LOGGER.info("support window is not displayed")
        scope_drop_down = filter_obj.validate_scope_filter_drop_down()
        if scope_drop_down:
            filter_obj.click_on_global_filter()

    @pytest.fixture()
    def agents_customer_filter_setup(self, driver):
        navbar = Navbar(driver)
        filter_obj = filters.Filters(driver)
        current_url = navbar.navigate_to_navbar_page(NavbarItem.CONSOLE)
        assert "console" in current_url, "failed to load current url"
        yield
        support_hub = SupportHub(driver)
        try:
            support_hub.close_support_hub_window()
        except:
            LOGGER.info("support window is not displayed")
        driver.refresh()
        filter_obj.click_on_global_filter()
        filter_obj.click_on_quick_filter_to_expand_the_drop_down_list()
        filter = []
        agents_name = filter_obj.get_on_agents_name_in_filters()
        filter.append(agents_name)
        customer_name = filter_obj.get_on_customer_name_in_filters()
        filter.append(customer_name)
        case_field_name_in_instance= filter_obj.get_on_case_filed_name_in_filters()
        filter.append(case_field_name_in_instance)
        for filter_name in filter:
            check_box_status_agents = filter_obj.check_if_agent_filter_is_applied(filter_name)
            if check_box_status_agents == "checked":
                filter_obj.click_on_agents_filter_checkbox(filter_name)
                time.sleep(2)
        driver.refresh()


    @sanity_test
    @author_neha_jha
    @pytestrail.case('C658')
    def test_select_agents(self,driver,filter_setup):
        filter_obj = filters.Filters(driver)
        agent_for_search = "l"
        filter_obj.click_on_global_filter()
        filter_obj.click_on_quick_filter_to_expand_the_drop_down_list()
        agents_name = filter_obj.get_on_agents_name_in_filters()
        check_box_status_agents =  filter_obj.check_if_agent_filter_is_applied(agents_name)
        if check_box_status_agents == "checked":
            filter_obj.click_on_agents_filter_checkbox(agents_name)
        filter_obj.select_global_filter_from_dropdown(agents_name)
        selected_case =filter_obj.verify_customer_or_agents_is_selected_or_not()
        if selected_case:
            filter_obj.click_on_close_icon_of_selected_tab_to_clear_selection_agents()
        filter_obj.search_agents_in_global_filter(agent_for_search)
        presence_of_customer_in_search = (
            filter_obj.check_the_presence_of_agents_in_global_search()
        )
        if presence_of_customer_in_search:
            filter_obj.select_check_box_from_agent_filter()
            selected_case = filter_obj.verify_customer_or_agents_is_selected_or_not()
            if selected_case:
                number_of_agents_should_displayed ="1 selected"
                number_of_agents_is_displayed = filter_obj.get_text_of_selected_customer_and_agents()
                assert  number_of_agents_is_displayed == number_of_agents_should_displayed,"failed"
            else:
                LOGGER.warning("failed to select agents ")
                assert False

        else:
            LOGGER.warning("There are no present of agents related to the search try to search different agents name")

    @sanity_test
    @author_neha_jha
    @pytestrail.case('C2217')
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_deselect_agents(self,driver,filter_setup):
        filter_obj = filters.Filters(driver)
        agent_for_search = "l"
        time.sleep(5)
        filter_obj.click_on_global_filter()
        filter_obj.click_on_quick_filter_to_expand_the_drop_down_list()
        agents_name = filter_obj.get_on_agents_name_in_filters()
        check_box_status_agents = filter_obj.check_if_agent_filter_is_applied(agents_name)
        if check_box_status_agents == "checked":
            filter_obj.click_on_agents_filter_checkbox(agents_name)
        filter_obj.select_global_filter_from_dropdown(agents_name)
        # if some agents is selected  already if block will clear selected agents and verify
        # else if block select the agents and then clear the selected agents and verify
        selected_case = filter_obj.verify_customer_or_agents_is_selected_or_not()
        if selected_case:
            filter_obj.click_on_close_icon_of_selected_tab_to_clear_selection_agents()
            filter_obj.click_on__apply_filter_in_agents_and_customer_search_pop_up()
            assert filter_obj.verify_customer_or_agents_is_selected_or_not() is False ,"failed to  deselect the agents"
        elif selected_case is False:
            filter_obj.search_agents_in_global_filter(agent_for_search)
            presence_of_customer_in_search = (
                filter_obj.check_the_presence_of_agents_in_global_search()
            )
            if presence_of_customer_in_search:
                filter_obj.select_check_box_from_agent_filter()

                selected_case = filter_obj.verify_customer_or_agents_is_selected_or_not()
                if selected_case:
                    filter_obj.click_on_close_icon_of_selected_tab_to_clear_selection_agents()
                    filter_obj.click_on__apply_filter_in_agents_and_customer_search_pop_up()
                    assert filter_obj.verify_customer_or_agents_is_selected_or_not() is False, "failed to deselect the agents"
                else:
                    LOGGER.info("agents is not selected")
                    assert False
            else:
                LOGGER.warning("There are no present o agents related to the search "
                " try to search different agents name")

    @sanity_test
    @author_neha_jha
    @pytestrail.case('C635')
    def test_agents_filters(self,driver,agents_customer_filter_setup):
        """
        1.click on global filter and select quick filter
        2.selected the agents filter and check for some agents is already selected or not if selected :clear it and apply filter
        3.again click on the agents and select the agents name ,apply filter
        4.click on the new cases tab on the console page
        click on assigned cases  get the case owner name

        """
        filter_obj = filters.Filters(driver)
        page = console_page.ConsolePage(driver)
        support_hub_page = SupportHub(driver)
        agent_for_search = "Sh "
        time.sleep(5)
        filter_obj.click_on_global_filter()
        filter_obj.click_on_quick_filter_to_expand_the_drop_down_list()
        # get the filter name [agent or TSEs or support engineer based on the instance]
        agents_name = filter_obj.get_on_agents_name_in_filters()
        check_box_status_agents = filter_obj.check_if_agent_filter_is_applied(agents_name)
        if check_box_status_agents == "checked":
            filter_obj.click_on_agents_filter_checkbox(agents_name)
        filter_obj.select_global_filter_from_dropdown(agents_name)
        # checking for already agents is selected or not
        selected_case = filter_obj.verify_customer_or_agents_is_selected_or_not()
        if selected_case:
            filter_obj.click_on_close_icon_of_selected_tab_to_clear_selection_agents()
            filter_obj.click_on__apply_filter_in_agents_and_customer_search_pop_up()
            assert filter_obj.verify_customer_or_agents_is_selected_or_not() is False, "failed to  deselect the agents"
            filter_obj.select_global_filter_from_dropdown(agents_name)
        else:
            LOGGER.info("no agents is selected")
        filter_obj.search_agents_in_global_filter(agent_for_search)
        presence_of_customer_in_search = (
            filter_obj.check_the_presence_of_agents_in_global_search()
        )
        if presence_of_customer_in_search:
            case_owner = filter_obj.agents_name_in_agents_filter()
            LOGGER.info(f"{case_owner}")
            filter_obj.select_check_box_from_agent_filter()
            selected_case = filter_obj.verify_customer_or_agents_is_selected_or_not()
            if selected_case:
                number_of_agents_should_displayed = "1 selected"
                number_of_agents_is_displayed = filter_obj.get_text_of_selected_customer_and_agents()
                assert number_of_agents_is_displayed == number_of_agents_should_displayed, "failed"
                filter_obj.click_on__apply_filter_in_agents_and_customer_search_pop_up()
            else:
                LOGGER.info("no agents is selected ")
                assert False
            time.sleep(1)
            driver.refresh()
            console_data_present = page.check_for_console_dashboard_display_data()
            if console_data_present:
                page.click_on_tab(ConsolePageTabs.NEW_TICKETS)
                page.click_on_any_case_in_assigned_backlog()
                support_hub = support_hub_page.check_visibility_of_support_hub()
                if support_hub is False:
                    page.click_on_assigned_this_period()
                    support_hub = support_hub_page.check_visibility_of_support_hub()
                    assert support_hub, "failed to display support hub"
                    result = support_hub_page.get_agent_name()
                    LOGGER.info(f"{result}")
                    assert (
                         case_owner in result
                ), "agent name in filters and agents name in support hub is not the same "


            else:
                LOGGER.warning("There are zero cases or no cases ")
        else:
            LOGGER.info("There are no present of agents related to the search try to search different agents name")

    @sanity_test
    @author_neha_jha
    @pytestrail.case('C635')
    def test_customer_filters(self, driver, agents_customer_filter_setup):
        """
        1.click on global filter and select quick filter
        2.selected the agents filter and check for some agents is already selected or not if selected :clear it and apply filter
        3.again click on the agents and select the agents name ,apply filter
        4.click on the new cases tab on the console page
        click on assigned cases  get the case owner name

        """
        filter_obj = filters.Filters(driver)
        page = console_page.ConsolePage(driver)
        support_hub_page = SupportHub(driver)
        agent_for_search = "l"
        filter_obj.click_on_global_filter()
        filter_obj.click_on_quick_filter_to_expand_the_drop_down_list()
        customer_name =filter_obj.get_on_customer_name_in_filters()

        check_box_status_agents = filter_obj.check_if_agent_filter_is_applied(customer_name)
        if check_box_status_agents == "checked":
            filter_obj.click_on_customer_filter_checkbox(customer_name)
        filter_obj.select_global_filter_from_dropdown(customer_name)
        selected_case = filter_obj.verify_customer_or_agents_is_selected_or_not()
        if selected_case:
            filter_obj.click_on_close_icon_of_selected_tab_to_clear_selection_client()
            filter_obj.click_on__apply_filter_in_agents_and_customer_search_pop_up()
            assert filter_obj.verify_customer_or_agents_is_selected_or_not() is False, "failed to  deselect the agents"
            filter_obj.select_global_filter_from_dropdown(customer_name)
        else:
            LOGGER.info("no customer  is selected ")

        filter_obj.search_agents_in_global_filter(agent_for_search)
        presence_of_customer_in_search = (
            filter_obj.check_the_presence_of_agents_in_global_search()
        )
        if presence_of_customer_in_search:
            case_owner = filter_obj.agents_name_in_agents_filter()
            filter_obj.select_check_box_from_agent_filter()
            selected_case = filter_obj.verify_customer_or_agents_is_selected_or_not()
            if selected_case:
                number_of_agents_should_displayed = "1 selected"
                number_of_agents_is_displayed = filter_obj.get_text_of_selected_customer_and_agents()
                assert number_of_agents_is_displayed == number_of_agents_should_displayed, "failed"
                filter_obj.click_on__apply_filter_in_agents_and_customer_search_pop_up()
            else:
                LOGGER.info("no agents is selected ")
                assert False
            time.sleep(1)
            driver.refresh()
            console_data_present = page.check_for_console_dashboard_display_data()
            if console_data_present:
                page.click_on_tab(ConsolePageTabs.NEW_TICKETS)
                page.click_on_any_case_in_assigned_backlog()
                support_hub = support_hub_page.check_visibility_of_support_hub()
                if support_hub is False:
                    page.click_on_assigned_this_period()
                    support_hub = support_hub_page.check_visibility_of_support_hub()
                    assert support_hub, "failed to display support hub"
                    result = support_hub_page.get_reporter_name()


                    assert (
                            result in case_owner
                    ), "customer name is filter and customer name in support hub is not the same"


            else:
                LOGGER.warning("There are zero cases or no cases ")
        else:
            LOGGER.info("There are no present of agents related to the search try to search different agents name")

    @sanity_test
    @author_neha_jha
    @pytestrail.case('C622')
    def test_customer_filters_in_backlog_page(self, driver, agents_customer_filter_setup):
        """
        1.click on global filter and select quick filter
        2.selected the agents filter and check for some agents is already selected or not if selected :clear it and apply filter
        3.again click on the agents and select the agents name ,apply filter
        4.click on the new cases tab on the console page
        click on assigned cases  get the case owner name

        """
        case_board = case_board_page.CaseBoardPage(driver)
        navbar = Navbar(driver)
        filter_obj = filters.Filters(driver)
        support_hub_page = SupportHub(driver)
        agent_for_search = "l"
        filter_obj.click_on_global_filter()
        filter_obj.click_on_quick_filter_to_expand_the_drop_down_list()
        customer_name = filter_obj.get_on_customer_name_in_filters()

        check_box_status_agents = filter_obj.check_if_agent_filter_is_applied(customer_name)
        if check_box_status_agents == "checked":
            filter_obj.click_on_customer_filter_checkbox(customer_name)
        filter_obj.select_global_filter_from_dropdown(customer_name)
        selected_case = filter_obj.verify_customer_or_agents_is_selected_or_not()
        if selected_case:
            filter_obj.click_on_close_icon_of_selected_tab_to_clear_selection_client()
            filter_obj.click_on__apply_filter_in_agents_and_customer_search_pop_up()
            assert filter_obj.verify_customer_or_agents_is_selected_or_not() is False, "failed to  deselect the agents"
            filter_obj.select_global_filter_from_dropdown(customer_name)
        else:
            LOGGER.info("no customer  is selected ")

        filter_obj.search_agents_in_global_filter(agent_for_search)
        presence_of_customer_in_search = (
            filter_obj.check_the_presence_of_agents_in_global_search()
        )
        if presence_of_customer_in_search:
            case_owner = filter_obj.agents_name_in_agents_filter()
            filter_obj.select_check_box_from_agent_filter()
            selected_case = filter_obj.verify_customer_or_agents_is_selected_or_not()
            if selected_case:
                number_of_agents_should_displayed = "1 selected"
                number_of_agents_is_displayed = filter_obj.get_text_of_selected_customer_and_agents()
                assert number_of_agents_is_displayed == number_of_agents_should_displayed, "failed"
                filter_obj.click_on__apply_filter_in_agents_and_customer_search_pop_up()
            else:
                LOGGER.info("no agents is selected ")
                assert False
            time.sleep(1)
            driver.refresh()

            current_url = navbar.navigate_to_navbar_page(NavbarItem.CASE_BOARD)
            assert "cases" in current_url, "failed to load backlog pages"

            try:
                case_board.click_on_a_case_to_open_supporthub()
                assert support_hub_page.check_visibility_of_support_hub()
                result = support_hub_page.get_reporter_name()

                assert (
                        result in case_owner
                ), "customer name is filter and customer name in support hub is not the same"


            except NoSuchElementException as e:
                LOGGER.info("No data founded in case board page")
                raise Exception(
                    f"{e.__class__.__name__}: {e}" f"\nLine no: {e.__traceback__.tb_lineno}"
                )

    @sanity_test
    @author_neha_jha
    @pytestrail.case('C630')
    def test_select_first_client_fav_in_client_filter(self, driver, filter_setup):
        filter_obj = filters.Filters(driver)
        filter_obj.click_on_global_filter()
        filter_obj.click_on_quick_filter_to_expand_the_drop_down_list()
        customer_name = filter_obj.get_on_customer_name_in_filters()
        check_box_status_agents = filter_obj.check_if_agent_filter_is_applied(customer_name)
        if check_box_status_agents == "checked":
            filter_obj.click_on_customer_filter_checkbox(customer_name)
        filter_obj.select_global_filter_from_dropdown(customer_name)
        selected_case = filter_obj.verify_customer_or_agents_is_selected_or_not()
        if selected_case:
            filter_obj.click_on_close_icon_of_selected_tab_to_clear_selection_client()
            filter_obj.click_on__apply_filter_in_agents_and_customer_search_pop_up()
            assert filter_obj.verify_customer_or_agents_is_selected_or_not() is False, "failed to  deselect the agents"
            filter_obj.select_global_filter_from_dropdown(customer_name)
        else:
            LOGGER.info("no customer  is selected ")
        filter_obj.click_on_fav_tab_in_client_filter()
        filter_obj.select_first_client_in_fav_client_filter()
        first_check_box_status = filter_obj.check_for_first_client_in_fav_client_filter_is_selected()
        assert first_check_box_status == "checked", "failed to select the first check box"

    @sanity_test
    @author_neha_jha
    @pytestrail.case('C227')
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_client_fav_in_client_filter_and_preference_tab(self,driver,filter_setup):
        filter_obj = filters.Filters(driver)
        filter_obj.click_on_global_filter()
        filter_obj.click_on_quick_filter_to_expand_the_drop_down_list()
        customer_name = filter_obj.get_on_customer_name_in_filters()
        check_box_status_agents = filter_obj.check_if_agent_filter_is_applied(customer_name)
        if check_box_status_agents == "checked":
            filter_obj.click_on_customer_filter_checkbox(customer_name)
        filter_obj.select_global_filter_from_dropdown(customer_name)
        selected_case = filter_obj.verify_customer_or_agents_is_selected_or_not()
        if selected_case:
            filter_obj.click_on_close_icon_of_selected_tab_to_clear_selection_client()
            filter_obj.click_on__apply_filter_in_agents_and_customer_search_pop_up()
            assert filter_obj.verify_customer_or_agents_is_selected_or_not() is False, "failed to  deselect the agents"
            filter_obj.select_global_filter_from_dropdown(customer_name)
        else:
            LOGGER.info("no customer  is selected ")
        filter_obj.click_on_fav_tab_in_client_filter()
        number_of_fav_client_in_customer_filter=filter_obj.get_number_of_fav_client_present_in_customer_filter()
        LOGGER.info(f"{number_of_fav_client_in_customer_filter} is present in client filter" )
        filter_obj.click_on_global_filter()
        filter_obj.click_on_user_menu_icon()
        fav_in_preference_tab=filter_obj.get_number_of_fav_client_present_in_preference_tab()
        assert  len(number_of_fav_client_in_customer_filter) == len(fav_in_preference_tab),"number of client filter is fav is mismatch with perference tab "
        filter_obj.click_on_close_icon_in_preference_pop_up()

    @regression_test
    @author_neha_jha
    @pytestrail.case('C625')
    def test_functionality_of_select_all_in_case_field(self,driver,filter_setup):
        filter_obj = filters.Filters(driver)
        filter_obj.click_on_global_filter()
        filter_obj.click_on_quick_filter_to_expand_the_drop_down_list()
        filter_name ="Case fields"
        check_box_status_agents = filter_obj.check_if_agent_filter_is_applied(filter_name)
        if check_box_status_agents == "checked":
            filter_obj.click_on_customer_filter_checkbox(filter_name)
        filter_obj.select_global_filter_from_dropdown(filter_name)
        filter_options = filter_obj.check_the_presence_of_selected_tab()
        if filter_options:
            filter_obj.click_on_close_icon_in_case_feild_to_deselected_field()
            filter_obj.click_on_apply_scope_button_in_case_field()
            filter_obj.select_global_filter_from_dropdown(filter_name)
            assert filter_obj.check_the_presence_of_selected_tab() is False," filter object is deselected successfully"
        filter_obj.click_on_case_filed_name_in_case_field(case_field="Age")
        assert filter_obj.check_for_on_age_section_is_expanded_or_not()
        filter_obj.click_on_age_section_select_all_button_in_case_field()
        assert filter_obj.check_the_presence_of_selected_tab()
        driver.refresh()

    @regression_test
    @author_neha_jha
    @pytestrail.case('C626')
    def test_functionality_of_expand_age_in_case_field(self, driver):
        filter_obj = filters.Filters(driver)
        filter_obj.click_on_global_filter()
        filter_obj.click_on_quick_filter_to_expand_the_drop_down_list()
        filter_name = "Case fields"
        check_box_status_agents = filter_obj.check_if_agent_filter_is_applied(filter_name)
        if check_box_status_agents == "checked":
            filter_obj.click_on_customer_filter_checkbox(filter_name)
        filter_obj.select_global_filter_from_dropdown(filter_name)
        filter_obj.click_on_case_filed_name_in_case_field(case_field="Age")
        assert filter_obj.check_for_on_age_section_is_expanded_or_not()
        filter_obj.click_on_global_filter()

    @regression_test
    @author_neha_jha
    @pytestrail.case('C624')
    def test_functionality_of_reset_in_case_field(self, driver,filter_setup):
        filter_obj = filters.Filters(driver)
        filter_obj.click_on_global_filter()
        filter_obj.click_on_quick_filter_to_expand_the_drop_down_list()
        filter_name = "Case fields"
        check_box_status_agents = filter_obj.check_if_agent_filter_is_applied(filter_name)
        if check_box_status_agents == "checked":
            filter_obj.click_on_customer_filter_checkbox(filter_name)
        filter_obj.select_global_filter_from_dropdown(filter_name)
        filter_options = filter_obj.check_the_presence_of_selected_tab()
        if filter_options:
            filter_obj.click_on_close_icon_in_case_feild_to_deselected_field()
            filter_obj.click_on_apply_scope_button_in_case_field()
            assert filter_obj.check_the_presence_of_selected_tab() is False, " filter object is deselected successfully"

        filter_obj.click_on_case_filed_name_in_case_field(case_field ="Age")
        assert filter_obj.check_for_on_age_section_is_expanded_or_not()
        filter_obj.click_on_age_section_select_all_button_in_case_field()
        assert filter_obj.check_the_presence_of_selected_tab()
        filter_obj.click_on_reset_all_button_in_case_field()
        filter_obj.select_global_filter_from_dropdown(filter_name)
        assert filter_obj.check_the_presence_of_selected_tab() is False,"failed to reset the selected tab"

    @regression_test
    @author_vignesh_k
    @pytestrail.case("C357")
    @pytest.mark.parametrize("value", ["Buffalo Bills"])
    def test_trends_tab_overview(self, driver, filter_setup, value):#Buffalo Bills,Baltimore Ravens
        """
            General search
            Test steps:
            1. Select any client from the clients option in the filter list and apply filter.
            2. Validate the overview tab test count with total cases
        """
        """Validate the overview tab test count with total cases after applying filter"""
        LOGGER.info("Applying filter and validate overview test cases with total test case count")
        filter_obj = filters.Filters(driver)
        navbar = Navbar(driver)
        trends = KeywordsAndTrends(driver)
        current_page_url: str = navbar.navigate_to_navbar_page(NavbarItem.TRENDS)
        assert "trends" in current_page_url, "Failed to load Keywords and Trends page"
        agent_for_search = "l"
        filter_obj.click_on_global_filter()
        filter_obj.click_on_quick_filter_to_expand_the_drop_down_list()
        customer_name = filter_obj.get_on_customer_name_in_filters()

        check_box_status_agents = filter_obj.check_if_agent_filter_is_applied(customer_name)
        if check_box_status_agents == "checked":
            filter_obj.click_on_customer_filter_checkbox(customer_name)
        filter_obj.select_global_filter_from_dropdown(customer_name)
        selected_case = filter_obj.verify_customer_or_agents_is_selected_or_not()
        if selected_case:
            filter_obj.click_on_close_icon_of_selected_tab_to_clear_selection_client()
            filter_obj.click_on__apply_filter_in_agents_and_customer_search_pop_up()
            assert filter_obj.verify_customer_or_agents_is_selected_or_not() is False, "failed to  deselect the agents"
            filter_obj.select_global_filter_from_dropdown(customer_name)
        else:
            LOGGER.info("no customer  is selected ")

        filter_obj.search_agents_in_global_filter(agent_for_search)
        presence_of_customer_in_search = (
            filter_obj.check_the_presence_of_agents_in_global_search()
        )
        if presence_of_customer_in_search:
            case_owner = filter_obj.agents_name_in_agents_filter()
            filter_obj.select_check_box_from_agent_filter()
            selected_case = filter_obj.verify_customer_or_agents_is_selected_or_not()
            if selected_case:
                number_of_agents_should_displayed = "1 selected"
                number_of_agents_is_displayed = filter_obj.get_text_of_selected_customer_and_agents()
                assert number_of_agents_is_displayed == number_of_agents_should_displayed, "failed"
                filter_obj.click_on__apply_filter_in_agents_and_customer_search_pop_up()
            else:
                LOGGER.info("no agents is selected ")
                assert False
            time.sleep(1)
        total_case_count=trends.get_displayed_case_count()
        total_case_count_in_content_tab=trends.get_displayed_case_count_on_tab(tab_name=TrendsPageContentTabs.OVERVIEW.value)
        LOGGER.info("Validate the content tab test count with total cases after applying filter")
        assert  total_case_count_in_content_tab == total_case_count

    @regression_test
    @author_neha_jha
    @pytestrail.case('C621')
    def test_for_first_case_field_enable_in_show_in_filter_should_enable_global_filter(self,driver):
        settings = SettingsPage(driver)
        navbar = Navbar(driver)
        filter_obj = filters.Filters(driver)
        current_page_url = navbar.navigate_to_control_center_item(ControlCenterMenuItem.SETTINGS)
        settings.go_to_settings_section(SettingsSectionUrlSuffix.FIELDS)
        case_field_name = settings.get_text_first_case_field_name_in_show_in_filter()
        case_field_toggle=settings.check_for_case_field_toggle_enable_or_not(case_field_name)
        current_url = navbar.navigate_to_navbar_page(NavbarItem.CONSOLE)
        assert "console" in current_url, "failed to load current url"
        filter_obj.click_on_global_filter()
        filter_obj.click_on_quick_filter_to_expand_the_drop_down_list()
        filter_name = filter_obj.get_on_case_filed_name_in_filters()

        check_box_status_agents = filter_obj.check_if_agent_filter_is_applied(filter_name)
        if check_box_status_agents == "checked":
            filter_obj.click_on_customer_filter_checkbox(filter_name)
        filter_obj.select_global_filter_from_dropdown(filter_name)
        if case_field_toggle:
           assert filter_obj.is_element_visible(
                (By.XPATH, filter_locators.check_for_case_field_name.replace("text_placehoder",case_field_name)),
               timeout=30),"case field is not showed in filters "
        elif case_field_toggle is False  :
            assert filter_obj.is_element_visible(
                (By.XPATH, filter_locators.check_for_case_field_name.replace("text_placehoder",case_field_name)), timeout=30) == False ,"case field is showed in filter"

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C32")
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_time_filter_with_global_filter(self, driver, filter_setup):
        support_hub = SupportHub(driver)
        api_keywords = ApiKeywords(driver)
        filters_page = filters.Filters(driver)
        console = console_page.ConsolePage(driver)

        expected_filter = "Last 7 days"
        agent_label_plural = console.get_label_settings().get(
            "agent.label.plural", "TSEs"
        )
        agent_with_most_cases = api_keywords.get_agent_names(size=5)
        LOGGER.info(f"Agents used in filter: {agent_with_most_cases}")

        current_time_filter = console.get_time_filter_in_console()
        if current_time_filter != expected_filter:
            console.click_time_filter_drop_down()
            console.select_filter_in_console(expected_filter)
            time_filter_selected = console.get_time_filter_in_console()
            assert (
                expected_filter in time_filter_selected
            ), f"{time_filter_selected} is not same as expected - {expected_filter}"

        filters_page.click_on_global_filter()
        filters_page.click_on_quick_filter_to_expand_the_drop_down_list()
        filters_page.select_global_filter_from_dropdown(agent_label_plural)
        try:
            filters_page.click_on_close_icon_of_selected_tab_to_clear_selection_agents()
        except TimeoutException:
            pass
        for agent in agent_with_most_cases:
            filters_page.search_agents_in_global_filter(agent)
            time.sleep(1)
            filters_page.select_check_box_from_agent_filter()
        filters_page.click_on__apply_filter_in_agents_and_customer_search_pop_up()

        try:
            console.click_on_tab(ConsolePageTabs.NEGATIVE_SENTIMENTS)
            if console.is_element_visible((By.XPATH, cpl.expand_all_button), timeout=5):
                console.click_on_element((By.XPATH, cpl.expand_all_button))
            assert console.check_for_presence_case_cards_in_tabs(), "No cases in tab"
            console.click_on_to_open_support_hub_in_cards()
            case_id = support_hub.get_case_id()

            case_summary = api_keywords.get_case_summary(case_id)[0]
            case_creation_date = case_summary["sl_created_at"]
            support_hub.close_support_hub_window()
            open_date = datetime.strptime(case_creation_date, "%Y-%m-%dT%H:%M:%S%z")
            assert (datetime.now(timezone.utc) - timedelta(7)) <= open_date
        finally:
            filters_page.click_on_global_filter()
            filters_page.click_on_quick_filter_to_expand_the_drop_down_list()
            filters_page.select_global_filter_from_dropdown(agent_label_plural)
            filters_page.click_on_close_icon_of_selected_tab_to_clear_selection_agents()
            filters_page.click_on__apply_filter_in_agents_and_customer_search_pop_up()
            filters_page.close_global_filter_dropdown()
            assert (
                filters_page.check_if_global_filter_applied() is False
            ), "Failed to remove global filter"

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C37")
    def test_content_tabs_behavior_zero_state(self, driver, filter_setup):
        api_keywords = ApiKeywords(driver)
        filters_page = filters.Filters(driver)
        console = console_page.ConsolePage(driver)

        expected_filter = "Since yesterday"
        agent_label_plural = console.get_label_settings().get(
            "agent.label.plural", "TSEs"
        )
        agent_with_most_cases = api_keywords.get_agent_names(size=40)[-1]
        LOGGER.info(f"Agent used in filter: {agent_with_most_cases}")

        current_time_filter = console.get_time_filter_in_console()
        if current_time_filter != expected_filter:
            console.click_time_filter_drop_down()
            console.select_filter_in_console(expected_filter)
            time_filter_selected = console.get_time_filter_in_console()
            assert (
                expected_filter in time_filter_selected
            ), f"{time_filter_selected} is not same as expected - {expected_filter}"

        filters_page.click_on_global_filter()
        filters_page.click_on_quick_filter_to_expand_the_drop_down_list()
        filters_page.select_global_filter_from_dropdown(agent_label_plural)
        try:
            filters_page.click_on_close_icon_of_selected_tab_to_clear_selection_agents()
        except TimeoutException:
            pass
        filters_page.search_agents_in_global_filter(agent_with_most_cases)
        filters_page.select_check_box_from_agent_filter()
        filters_page.click_on__apply_filter_in_agents_and_customer_search_pop_up()

        try:
            assert len(driver.find_elements(By.XPATH, cpl.tabs_with_placeholder)) >= 1
        finally:
            filters_page.select_global_filter_from_dropdown(agent_label_plural)
            filters_page.click_on_close_icon_of_selected_tab_to_clear_selection_agents()
            filters_page.click_on__apply_filter_in_agents_and_customer_search_pop_up()
            filters_page.close_global_filter_dropdown()
            assert (
                filters_page.check_if_global_filter_applied() is False
            ), "Failed to remove global filter"
