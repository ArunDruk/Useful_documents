"""This is the test class for Alerts page"""
__author__ = "Neha Jha"
__copyright__ = "Copyright (C) 2021 SupportLogic"

import logging
import time

import pytest
from pytest_testrail.plugin import pytestrail
from constants import author_neha_jha, sanity_test,regression_test
from enums import NavbarItem
from pom_library import alerts_page, commons
from pom_library.navbar import Navbar

LOGGER = logging.getLogger(__name__)


@pytest.mark.usefixtures("driver")
class TestAlerts(object):
    @pytest.fixture()
    def alerts_setup(self, driver):
        page = alerts_page.Alerts(driver)
        common_page = commons.Commons(driver)
        navbar = Navbar(driver)
        current_url = navbar.navigate_to_navbar_page(NavbarItem.ALERTS)
        assert "alerts" in current_url, "failed to load page"
        common_page.start_module_onboarding()
        yield
        page.alerts_delete()

    @regression_test
    @author_neha_jha
    @pytestrail.case('C750')
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_click_on_alert_page_on_nav_bar(self,driver):
        navbar = Navbar(driver)
        current_url = navbar.navigate_to_navbar_page(NavbarItem.ALERTS)
        assert "alerts" in current_url, "failed to load page"

    # TC 587
    @sanity_test
    @author_neha_jha
    @pytestrail.case('C2236')
    def test_check_alerts_page_loaded(self, driver):
        page = alerts_page.Alerts(driver)
        common_page = commons.Commons(driver)
        navbar = Navbar(driver)
        current_url = navbar.navigate_to_navbar_page(NavbarItem.ALERTS)
        assert "alerts" in current_url, "failed to load page"
        common_page.start_module_onboarding()
        alerts_list = page.check_present_alerts()
        assert alerts_list, "failed to displayed alerts list"
        alerts_definition = page.check_present_notification_method()
        assert alerts_definition, "failed to displayed alerts definition"
        alerts_condition = page.check_present_alert_condition()
        assert alerts_condition, "failed to displayed alerts condition"

    # TC 592
    @sanity_test
    @author_neha_jha
    @pytestrail.case('C756')
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_alerts_copy(self, driver, alerts_setup):
        page = alerts_page.Alerts(driver)
        page.create_new_alerts()
        assert (
            page.check_present_notification_method()
        ), "failed to display notification in alert definition"
        assert (
            page.check_presents_alerts_name_in_definition()
        ), "failed to display  alerts name in definition"

        page.click_alert_copy()
        time.sleep(1)
        alerts_name_after_copy = page.get_text_definition_alerts_name()
        assert (
            "Copy " in alerts_name_after_copy
        ), "test alert test copy test cases is failed"

    # TC 589
    @sanity_test
    @author_neha_jha
    @pytestrail.case('C2237')
    def test_new_alerts(self, driver, alerts_setup):
        page = alerts_page.Alerts(driver)
        page.create_new_alerts()
        alerts_name_display = page.check_presents_alerts_name_in_definition()
        assert alerts_name_display, "failed to display alerts name"
        assert (
            page.check_present_notification_method()
        ), "failed to display  notification method in alerts definition"
        assert (
            page.check_present_expand_list()
        ), "failed to display the expand list on the right"

    # TC 609
    @sanity_test
    @author_neha_jha
    @pytestrail.case('C2238')
    def test_adding_alerts_condition(self, driver, alerts_setup):
        page = alerts_page.Alerts(driver)
        page.create_new_alerts()
        alerts_name_display = page.check_presents_alerts_name_in_definition()
        assert alerts_name_display, "failed to display alerts name"
        page.click_alerts_conditions()
        sentiments = page.get_text_sentiment_alerts_condition()
        # double click sentiments
        page.double_click_to_add_sentiment()
        sentiments_alerts_definition = page.get_text_sentiment_alerts_definition()
        assert (
            sentiments in sentiments_alerts_definition
        ), " failed to add sentiments in alerts definition "


    # TC 594
    @sanity_test
    @author_neha_jha
    @pytestrail.case('C757')
    def test_alert_delete(self, driver, alerts_setup):
        page = alerts_page.Alerts(driver)
        new_alerts = page.check_present_new_alerts_button()
        assert new_alerts, "failed to displayed new alerts button"
        number_of_alerts_present_before = page.get_count_of_alerts()
        page.click_new_alerts_button()
        number_of_alerts = number_of_alerts_present_before + 1
        time.sleep(2)
        number_of_alerts_present_after = page.get_count_of_alerts()
        assert (
            number_of_alerts == number_of_alerts_present_after
        ), "failed to create new alerts"

        alerts_name_display = page.check_presents_alerts_name_in_definition()
        assert (
            alerts_name_display
        ), "failed to display alerts name in alerts definition "
        page.click_alert_delete()
        page.click_delete_on_delete_pop()
        time.sleep(2)
        number_of_alerts_present_after_delete = number_of_alerts_present_after - 1
        number_of_count_present_after_delete = page.get_count_of_alerts()
        assert (
            number_of_count_present_after_delete
            == number_of_alerts_present_after_delete
        ), "failed to delete list"

    # TC 592
    @sanity_test
    @author_neha_jha
    @pytestrail.case('C755')
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_alerts_mute(self, driver, alerts_setup):
        page = alerts_page.Alerts(driver)
        page.create_new_alerts()
        alerts_name_display = page.check_presents_alerts_name_in_definition()
        assert alerts_name_display, "failed to display alerts name in alerts definition"
        page.click_mute_alerts_definition()
        un_muted = page.checks_for_alerts_unmute()
        assert un_muted, " Failed to  unmute alerts in alerts definition "
        # mute check on alert list
        alerts_un_mute_list = page.checks_for_un_mute_alerts_list()
        if alerts_un_mute_list:
            page.click_unmute_alerts_list()
            page.click_mute_alerts_list()
            alerts_un_mute = page.checks_for_un_mute_alerts_list()
            assert alerts_un_mute, "failed to un mute alerts in alerts list"
        else:
            page.click_mute_alerts_list()
            alerts_un_mute = page.checks_for_un_mute_alerts_list()
            assert alerts_un_mute, "failed to un mute alerts in alerts list"


    @regression_test
    @author_neha_jha
    @pytestrail.case('C758')
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_undo_alert_condition(self,driver,alerts_setup):
        page = alerts_page.Alerts(driver)
        page.create_new_alerts()
        alerts_name_display = page.check_presents_alerts_name_in_definition()
        assert alerts_name_display, "failed to display alerts name"
        page.click_alerts_conditions()
        sentiments = page.get_text_sentiment_alerts_condition()
        # double click sentiments
        page.double_click_to_add_sentiment()
        sentiments_alerts_definition = page.get_text_sentiment_alerts_definition()
        assert (
                sentiments in sentiments_alerts_definition
        ), " failed to add sentiments in alerts definition "
        time.sleep(1)
        page.check_for_visibility_of_condition_undo_button()
        page.click_on_condition_undo_button()
        time.sleep(1)
        assert page.validating_alert_condition_present_on_alert_or_not() is False,"failed to undo alert condition"

    @regression_test
    @author_neha_jha
    @pytestrail.case('C759')
    def test_notification_method_undo(self, driver, alerts_setup):
        page = alerts_page.Alerts(driver)
        page.create_new_alerts()
        alerts_name_display = page.check_presents_alerts_name_in_definition()
        assert alerts_name_display, "failed to display alerts name"
        page.remove_first_email_in_notification_method()
        page.click_on_notification_undo_button()
        assert page.validate_email_is_displayed_notification_method()

    @regression_test
    @author_neha_jha
    @pytestrail.case('C767')
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_functionality_deselection_send_alert_to_me(self, driver, alerts_setup):
        page = alerts_page.Alerts(driver)
        page.create_new_alerts()
        alerts_name_display = page.check_presents_alerts_name_in_definition()
        assert alerts_name_display, "failed to display alerts name"
        page.click_on_send_alert_me_drop_down_menu()
        email_status = page.get_data_status_email_check_box_in_send_alert_me()
        if email_status == "checked":
            page.click_on_email_check_box_in_send_alert_me_drop_down()
        page.click_on_send_alert_me_drop_down_menu()
        status_of_send_alert_me_check_box=page.get_data_status_send_alert_me_check_box()
        assert status_of_send_alert_me_check_box == "unchecked"," send me alert is not un checked"

    @regression_test
    @author_neha_jha
    @pytestrail.case('C779')
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_last_case_activity_in_alert_condition_sentiments_error_message(self, driver, alerts_setup):
        page = alerts_page.Alerts(driver)
        page.create_new_alerts()
        alerts_name_display = page.check_presents_alerts_name_in_definition()
        assert alerts_name_display, "failed to display alerts name"
        page.click_on_last_activity_in_alert_condition_sentiments()
        page.double_click_to_added_last_activity_inbound()
        page.click_on_last_activity_in_alert_condition_sentiments()
        assert page.check_for_error_message_is_displayed_last_activity_inbound(),"failed to displayed error" \
                                                                     " message when last activity inbound is empty"

    @regression_test
    @author_neha_jha
    @pytestrail.case('C753')
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_error_message_slack_is_not_configured(self, driver, alerts_setup):
        page = alerts_page.Alerts(driver)
        page.create_new_alerts()
        alerts_name_display = page.check_presents_alerts_name_in_definition()
        assert alerts_name_display, "failed to display alerts name"
        page.click_on_notification_drop_down()
        page.click_on_slack_button_in_drop_down()
        # to close the drop down
        page.click_on_notification_drop_down()
        assert page.check_for_error_message_is_displayed_when_slack_is_not_configured(),"failed to display error message when slack " \
                                                                                        "is not configured"

    @regression_test
    @author_neha_jha
    @pytestrail.case('C766')
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_functionality_of_selection_notification(self, driver, alerts_setup):
        page = alerts_page.Alerts(driver)
        page.create_new_alerts()
        alerts_name_display = page.check_presents_alerts_name_in_definition()
        assert alerts_name_display, "failed to display alerts name"
        page.click_on_notification_drop_down()
        email_status = page.get_data_status_email_check_box_in_send_alert_me()
        #get status of email if its uncheked click on check .
        if email_status == "unchecked":
            page.click_on_email_check_box_in_send_alert_me_drop_down()

            email_check = page.get_data_status_email_check_box_in_send_alert_me()
            assert email_check == "checked","failed to check email box "

        else:
            assert email_status == "checked","email in notification box is not check"
        slack = page.check_of_status_on_slack_is_selected_or_not()
        # get status of slack if its unchecked click on check.
        if slack == "unchecked":
            page.click_on_slack_button_in_drop_down()
            slack_check = page.check_of_status_on_slack_is_selected_or_not()
            assert slack_check == "checked","failed to check slack box "
        else:
            assert slack == "checked","slack in notification box is checked"

    @regression_test
    @author_neha_jha
    @pytestrail.case('C762')
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_undo_button_in_payload_section(self, driver, alerts_setup):
        page = alerts_page.Alerts(driver)
        page.create_new_alerts()
        alerts_name_display = page.check_presents_alerts_name_in_definition()
        assert alerts_name_display, "failed to display alerts name"
        page.send_back_slash_in_payload_section()
        assert page.check_for_message_pay_load_section_have_sentiments_condition()
        page.click_on_undo_button_in_payload_section()
        time.sleep(1)
        assert page.check_for_message_pay_load_section_have_sentiments_condition() == False, "failed to undo payload section "

    @regression_test
    @author_neha_jha
    @pytestrail.case('C764')
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_condition_collapse_button(self, driver, alerts_setup):
        page = alerts_page.Alerts(driver)
        page.create_new_alerts()
        alerts_name_display = page.check_presents_alerts_name_in_definition()
        assert alerts_name_display, "failed to display alerts name"
        driver.refresh()
        page.click_on_expand_and_collapse_condition_sentiments()
        assert page.check_present_alert_condition_expand_state_or_collapse_state(), " failed to collapse alert condition"
        time.sleep(2)
        page.click_on_expand_and_collapse_condition_sentiments()
        assert page.check_present_alert_condition_expand_state_or_collapse_state() == False, " failed to expand alert condition"



