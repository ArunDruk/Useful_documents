"""Test class for sentiment page"""
__author__ = "Praveen Nagajothi"
__copyright__ = "Copyright (C) 2021 SupportLogic"

import datetime as dt
import logging
import time

import pytest
from pytest_testrail.plugin import pytestrail
from selenium.webdriver.common.by import By

import utils
from constants import author_praveen_nj, regression_test, sanity_test, skip_test
from enums import CaseStatusFilter, NavbarItem, SentimentGroup, SentimentMessageType
from locators import sentiments_locators as sl
from pom_library.commons import Commons
from pom_library.navbar import Navbar
from pom_library.sentiments import Sentiments
from pom_library.support_hub import SupportHub

LOGGER: logging.Logger = logging.getLogger(__name__)


class TestSentimentPage:
    @pytest.fixture(scope="class", autouse=True)
    def sentiment_page_setup(self, driver):
        navbar = Navbar(driver)
        commons = Commons(driver)

        current_page_url: str = navbar.navigate_to_navbar_page(NavbarItem.SENTIMENT)
        assert "sentiment" in current_page_url, "Failed to load Sentiment page"
        commons.start_module_onboarding()
        commons.wait_for_loader_to_disappear()

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C2270")
    def test_heat_wave_plot_loads(self, driver):
        sentiments = Sentiments(driver)
        assert (
            sentiments.check_presence_of_sentiment_graph()
        ), "Sentiment heatwave plot is not visible"

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C2271")
    def test_go_to_sentiment_page(self, driver):
        navbar = Navbar(driver)
        commons = Commons(driver)

        current_page_url: str = navbar.navigate_to_navbar_page(NavbarItem.SENTIMENT)
        assert "sentiment" in current_page_url, "Failed to load Sentiment page"
        commons.wait_for_loader_to_disappear()

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C439", "C440", "C441")
    @pytest.mark.parametrize("status", [*CaseStatusFilter])
    def test_case_status_filter(self, driver, status):
        sentiments = Sentiments(driver)

        failure_message: str = "Expected case status filter is not selected."
        assert (
            sentiments.filter_by_case_status(status) == status.value.title()
        ), failure_message
        assert (
            sentiments.check_presence_of_sentiment_graph()
        ), "Sentiment heatwave plot is not visible"
        # cleanup
        assert (
            sentiments.filter_by_case_status(CaseStatusFilter.ALL)
            == CaseStatusFilter.ALL.value.title()
        ), failure_message

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C456")
    @pytest.mark.parametrize("message_type", [*SentimentMessageType])
    def test_include_filter(self, driver, message_type):
        sentiments = Sentiments(driver)

        failure_message: str = "Failed to {status} expected include filter."
        assert sentiments.exclude_sentiment_by_message_type(
            message_type
        ), failure_message.format(status="deselect")
        assert (
            sentiments.check_presence_of_sentiment_graph()
        ), "Sentiment heatwave plot is not visible"
        # cleanup
        assert sentiments.include_sentiment_by_message_type(
            message_type
        ), failure_message.format(status="select")

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C445", "C446", "C447")
    @pytest.mark.parametrize("sentiment_group", [*SentimentGroup])
    def test_sentiment_legend_filter(self, driver, sentiment_group):
        sentiments = Sentiments(driver)

        failure_message: str = "Failed to {status} expected sentiment filter."
        sentiments.exclude_sentiment_by_group(sentiment_group)
        assert (
            sentiments.is_sentiment_filter_selected(sentiment_group) is False
        ), failure_message.format(status="deselect")
        assert (
            sentiments.check_presence_of_sentiment_graph()
        ), "Sentiment heatwave plot is not visible"
        # cleanup
        sentiments.include_sentiment_by_group(sentiment_group)
        assert sentiments.is_sentiment_filter_selected(
            sentiment_group
        ), failure_message.format(status="select")

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C450")
    def test_hover(self, driver):
        sentiments = Sentiments(driver)

        random_tile = sentiments.get_random_sentiment_tile(randomize=False)
        sentiments.hover_over_sentiment_tile(random_tile)
        # cleanup
        assert sentiments.check_visibility_of_sentiment_details_tooltip()

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C452")
    def test_support_hub(self, driver):
        commons = Commons(driver)
        support_hub = SupportHub(driver)
        sentiments = Sentiments(driver)

        random_tile = sentiments.get_random_sentiment_tile(randomize=False)
        sentiments.click_on_sentiment_tile(random_tile)
        commons.wait_for_loader_to_disappear()
        assert (
            support_hub.check_visibility_of_support_hub()
        ), "Failed to display SupportHub"
        # cleanup
        support_hub.close_support_hub_window()
        assert (
            sentiments.check_presence_of_sentiment_graph()
        ), "Sentiment heatwave plot is not visible"

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C442")
    def test_calendar_widget(self, driver):
        sentiments = Sentiments(driver)

        date_to_be_selected: dt.date = dt.date(2020, 12, 1)

        sentiments.open_date_picker()
        sentiments.select_start_date(date_to_be_selected)
        sentiments.apply_date_filter()
        assert sentiments.get_start_date_value() == date_to_be_selected.strftime(
            "%b %-d, %Y"
        ), "Selected date is not as expected."

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C443")
    def test_reset_date_to_last_n_days(self, driver):
        sentiments = Sentiments(driver)

        current_start_date = sentiments.get_start_date_value()

        sentiments.scroll_graph_to_previous_month()
        assert (
            current_start_date != sentiments.get_start_date_value()
        ), "Failed to change start date"

        sentiments.open_date_picker()
        reset_button_text: str = driver.find_element(
            By.CSS_SELECTOR, sl.reset_date_filter_css
        ).text
        LOGGER.info(reset_button_text)
        reset_days_length = int(reset_button_text.split()[-2])
        sentiments.reset_start_date()
        time.sleep(5)
        assert sentiments.get_start_date_value() == format(
            dt.date.today() - dt.timedelta(days=reset_days_length - 1), "%b %-d, %Y"
        )

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C453")
    def test_delta_chart_i_icon(self, driver):
        sentiments = Sentiments(driver)

        tooltip_text_with_cases: str = (
            "Sentiment Score Delta reflects the average difference between the Sentiment "
            "Score of cases before and after the sentiments depicted in the chart below "
            "were detected.\n"
            "If multiple sentiments appear within one comment, the delta reflects the net "
            "change in Sentiment Score for the comment as a whole. If multiple comments "
            "from one case appear in the chart, the change in Sentiment Score for all "
            "comments is included.\n"
            "Positive sentiments tend to increase Sentiment Score and Negative sentiments "
            "tend to decrease Sentiment Score. Very Negative values tend to cause the "
            "score to decrease more than Negative, and so on.\n"
            "It is worth noting that the same type of sentiment could have different "
            "deltas in different cases. Negative sentiments in a case where Sentiment "
            "Score is already very low may not decrease it as much as Negative sentiments "
            "in a case where Sentiment Score is very high, and vice versa."
        )
        tooltip_text_with_tickets: str = (
            "Sentiment Score Delta reflects the average difference between the Sentiment "
            "Score of tickets before and after the sentiments depicted in the chart below "
            "were detected.\n"
            "If multiple sentiments appear within one comment, the delta reflects the net "
            "change in Sentiment Score for the comment as a whole. If multiple comments "
            "from one ticket appear in the chart, the change in Sentiment Score for all "
            "comments is included.\n"
            "Positive sentiments tend to increase Sentiment Score and Negative sentiments "
            "tend to decrease Sentiment Score. Very Negative values tend to cause the "
            "score to decrease more than Negative, and so on.\n"
            "It is worth noting that the same type of sentiment could have different "
            "deltas in different tickets. Negative sentiments in a ticket where Sentiment "
            "Score is already very low may not decrease it as much as Negative sentiments "
            "in a ticket where Sentiment Score is very high, and vice versa."
        )
        sentiments.hover_on_element((By.CSS_SELECTOR, sl.delta_chart_i_icon_css))
        assert driver.find_element(
            By.CSS_SELECTOR, sl.i_icon_info_tooltip_css
        ).text in (
            tooltip_text_with_tickets,
            tooltip_text_with_cases,
        ), "Delta chart i icon tooltip text does not match"

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C454")
    @pytest.mark.xfail(reason="https://app.clickup.com/t/2277599/AA-17421")
    def test_sentiment_top_down_arrow(self, driver):
        sentiments = Sentiments(driver)

        sentiments.click_on_element(
            (By.CSS_SELECTOR, sl.delta_chart_top_down_arrow_button_css),
            message="Failed to click top down arrow button",
        )
        assert sentiments.is_element_visible(
            (By.CSS_SELECTOR, sl.delta_chart_top_down_arrow_tooltip_css)
        ), "top down arrow tooltip is not visible"
        assert (
            sentiments.get_total_sentiment_count() + " sentiments"
            in driver.find_element(
                By.CSS_SELECTOR, sl.delta_chart_top_down_arrow_tooltip_title_css
            ).text
        )

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C455")
    def test_graph_scroll_button(self, driver):
        sentiments = Sentiments(driver)

        start_date_before_left_scroll: str = sentiments.get_start_date_value()
        sentiments.scroll_graph_to_previous_month()
        time.sleep(5)
        start_date_after_left_scroll: str = sentiments.get_start_date_value()
        expected_date_in_xaxis: str = utils.convert_date_string_to_different_format(
            start_date_after_left_scroll, "%b %d, %Y", "%-d. %b"
        )
        assert (
            start_date_before_left_scroll != start_date_after_left_scroll
        ), "right slider graph button did not work as expected"
        assert (
            expected_date_in_xaxis
            in driver.find_element(
                By.CSS_SELECTOR, sl.sentiment_chart_x_axis_label_css
            ).text
        )

        start_date_before_right_scroll: str = sentiments.get_start_date_value()
        sentiments.scroll_graph_to_next_month()
        time.sleep(5)
        start_date_after_right_scroll: str = sentiments.get_start_date_value()
        expected_date_in_xaxis: str = utils.convert_date_string_to_different_format(
            start_date_after_right_scroll, "%b %d, %Y", "%-d. %b"
        )
        assert (
            start_date_before_right_scroll != start_date_after_right_scroll
        ), "right slider graph button did not work as expected"
        assert (
            expected_date_in_xaxis
            in driver.find_element(
                By.CSS_SELECTOR, sl.sentiment_chart_x_axis_label_css
            ).text
        )

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C448")
    def test_sentiment_filter_combination(self, driver):
        sentiments = Sentiments(driver)

        failure_message: str = "Failed to {status} expected sentiment filter"
        sentiments.exclude_sentiment_by_group(SentimentGroup.NEGATIVE)
        assert (
            sentiments.is_sentiment_filter_selected(SentimentGroup.NEGATIVE) is False
        ), failure_message.format(status="deselect")
        sentiments.include_sentiment_by_group(SentimentGroup.NEGATIVE)
        sentiments.exclude_sentiment_by_group(SentimentGroup.FEEDBACK)
        assert (
            sentiments.is_sentiment_filter_selected(SentimentGroup.FEEDBACK) is False
        ), failure_message.format(status="deselect")
        sentiments.include_sentiment_by_group(SentimentGroup.FEEDBACK)
        sentiments.exclude_sentiment_by_group(SentimentGroup.POSITIVE)
        assert (
            sentiments.is_sentiment_filter_selected(SentimentGroup.POSITIVE) is False
        ), failure_message.format(status="deselect")
        sentiments.include_sentiment_by_group(SentimentGroup.POSITIVE)

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C449")
    def test_sentiment_filter_none(self, driver):
        sentiments = Sentiments(driver)

        failure_message: str = "Failed to {status} expected sentiment filter"
        sentiments.exclude_sentiment_by_group(SentimentGroup.POSITIVE)
        sentiments.exclude_sentiment_by_group(SentimentGroup.FEEDBACK)
        sentiments.exclude_sentiment_by_group(SentimentGroup.NEGATIVE)
        assert (
            sentiments.is_sentiment_filter_selected(SentimentGroup.NEGATIVE)
        ), "Negative sentiment filter got deselected when other two is deselected"
        assert (
            sentiments.is_sentiment_filter_selected(SentimentGroup.POSITIVE) is False
        ), failure_message.format(status="deselect")
        assert (
            sentiments.is_sentiment_filter_selected(SentimentGroup.FEEDBACK) is False
        ), failure_message.format(status="deselect")
        sentiments.include_sentiment_by_group(SentimentGroup.POSITIVE)
        sentiments.include_sentiment_by_group(SentimentGroup.FEEDBACK)

    @skip_test
    @regression_test
    @author_praveen_nj
    @pytestrail.case("C451")
    def test_sentiment_score_chart_tooltip(self, driver):
        sentiments = Sentiments(driver)

        sentiments.hover_on_element(
            (By.CSS_SELECTOR, sl.sentiment_score_chart_plot_css)
        )
        assert sentiments.is_element_visible(
            (By.CSS_SELECTOR, sl.sentiment_score_chart_tooltip_css)
        ), "Sentiment score chart tooltip not visible"
