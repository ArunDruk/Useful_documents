"""Test class for Topic page"""
__author__ = "Neha jha"
__copyright__ = "Copyright (C) 2021 SupportLogic"

import logging
import os
import time

import pytest
from pytest_testrail.plugin import pytestrail

import constants
from constants import author_neha_jha, sanity_test ,regression_test
from enums import CaseStatusFilter, NavbarItem, TopicSortByFilter
from pom_library import commons, date_picker, topics_page
from pom_library.navbar import Navbar
from pom_library.sentiments import Sentiments

LOGGER = logging.getLogger(__name__)


@pytest.mark.usefixtures("driver")
class TestTopics(object):
    @pytest.fixture()
    def topics_setup(self, driver):
        navbar = Navbar(driver)
        common_page = commons.Commons(driver)
        current_page_url = navbar.navigate_to_navbar_page(NavbarItem.TOPICS)
        assert "topics" in current_page_url, "Failed to load topic page"
        common_page.start_module_onboarding()

    @sanity_test
    @author_neha_jha
    @pytestrail.case("C2249")
    def test_topic_selection_graph(self, driver, topics_setup):
        page = topics_page.TopicsPage(driver)
        page.click_on_topic_section()
        list_display = page.check_visibility_first_section_drop_down()
        assert list_display, "Failed to display list"
        topic_name = page.get_group_by_filter_name_from_first_topic_list()
        page.select_first_topic_section()
        selected_topic = page.get_group_by_option_selected_in_primary_topic()
        assert selected_topic in topic_name, "Failed to select topic name "
        data_present_in_topic_page = page.check_for_data_present_in_topic_page()

        if data_present_in_topic_page:
            page.click_on_second_topic_section()
            second_list_display = page.check_visibility_second_section_drop_down()
            assert second_list_display, "Failed to display list"
            page.select_second_topic_section()
            case = page.validate_case_and_client_count_in_second_topic_section()
            if case:
                graph = page.check_visibility_graph()
                assert graph, "Graph is not  displayed"
            else:
                LOGGER.warning("No data to display")
        else:
            LOGGER.warning("No data present in topics page")

    @sanity_test
    @author_neha_jha
    @pytestrail.case("C2250")
    def test_score_graph(self, driver, topics_setup):
        page = topics_page.TopicsPage(driver)
        data_present_in_topic_page = page.check_for_data_present_in_topic_page()
        if data_present_in_topic_page:
            case = page.validate_case_and_client_count_in_second_topic_section()
            if case:
                tabs = ["Sentiment Score", "Attention Score", "First Response Time"]
                for tab in tabs:
                    page.click_tabs(tab)
                    result = page.get_name_graph()
                    assert tab == result, "Graph is not loaded "
            else:
                LOGGER.warning("No data to display")
        else:
            LOGGER.warning("No data present in topics page")

    @sanity_test
    @author_neha_jha
    @pytestrail.case("C2251")
    def test_responder_graph(self, driver, topics_setup):
        page = topics_page.TopicsPage(driver)
        data_present_in_topic_page = page.check_for_data_present_in_topic_page()
        if data_present_in_topic_page:
            navbar = Navbar(driver)
            navbar.navigate_to_navbar_page(NavbarItem.TOPICS)
            case = page.validate_case_and_client_count_in_second_topic_section()
            if case:
                tab = "Responder"
                page.click_tabs(tab)
                tab_name_split = tab.split("der")
                tab_name = tab_name_split[0]
                graph_name = page.get_name_graph()
                graph_name_split = graph_name.split("der")
                result = graph_name_split[0]
                assert result == tab_name, "Graph is not loaded"
            else:
                LOGGER.warning("No data to display")
        else:
            LOGGER.warning("No data present in topics page")

    @sanity_test
    @author_neha_jha
    @pytestrail.case("C2252")
    def test_keyword_graph(self, driver, topics_setup):
        page = topics_page.TopicsPage(driver)
        data_present_in_topic_page = page.check_for_data_present_in_topic_page()
        if data_present_in_topic_page:
            case = page.validate_case_and_client_count_in_second_topic_section()
            if case:
                tab = "Keywords"
                page.click_tabs(tab)
                keyword_graph = page.validate_keyword_graph()
                assert keyword_graph, " Graph is not displayed"
            else:
                LOGGER.warning("No data to display")
        else:
            LOGGER.warning("No data present in topics page")

    @sanity_test
    @author_neha_jha
    @pytestrail.case("C2253")
    def test_case_list_graph(self, driver, topics_setup):
        page = topics_page.TopicsPage(driver)
        data_present_in_topic_page = page.check_for_data_present_in_topic_page()
        if data_present_in_topic_page:
            case = page.validate_case_and_client_count_in_second_topic_section()
            if case:
                page.click_case_list_graph()
                case_list = page.validate_case_list_graph()
                assert case_list, "Graph is not displayed"
            else:
                LOGGER.warning("No data to display")
        else:
            LOGGER.warning("No data present in topics page")

    @sanity_test
    @author_neha_jha
    @pytestrail.case("C2254")
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_export_csv(self, driver, topics_setup):

        page = topics_page.TopicsPage(driver)
        data_present_in_topic_page = page.check_for_data_present_in_topic_page()
        if data_present_in_topic_page:
            case = page.validate_case_and_client_count_in_second_topic_section()
            if case:
                page.click_case_list_graph()
                page.click_export_csv()
                # added time to download csv
                time.sleep(5)
                assert os.path.exists(
                    constants.report_dir + "/downloads/" + "topics-case-list.csv"
                ), "file is not  founded in download folder"
            else:
                LOGGER.warning("No data to display")
        else:
            LOGGER.warning("No data present in topics page")

    @sanity_test
    @author_neha_jha
    @pytestrail.case("C2255")
    def test_conversation_graph(self, driver, topics_setup):
        page = topics_page.TopicsPage(driver)
        data_present_in_topic_page = page.check_for_data_present_in_topic_page()
        if data_present_in_topic_page:
            case = page.validate_case_and_client_count_in_second_topic_section()
            if case:

                tab = "Conversations"
                page.click_tabs(tab)
                graph_name = page.get_name_graph()
                graph_name_split = graph_name.split(" ")
                result = graph_name_split[0]
                assert result == tab, "Graph is not displayed"
            else:
                LOGGER.warning("No data to display")
        else:
            LOGGER.warning("No data present in topics page")

    @sanity_test
    @author_neha_jha
    @pytestrail.case("C2256")
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_calendar(self, driver, topics_setup):
        page = topics_page.TopicsPage(driver)
        date_pickers = date_picker.DatePicker(driver)
        filter_applied_on_calendar = date_pickers.get_applied_date_filter()
        LOGGER.info(f"filter applied on calendar is {filter_applied_on_calendar}")
        date_pickers.open_date_picker()
        if filter_applied_on_calendar != "Year to date":
            date_pickers.select_year_to_date_shortcut()
            date_pickers.apply_selected_date_filter()
            assert (
                date_pickers.get_applied_date_filter() == "Year to date"
            ), "failed to select year to date"
        elif filter_applied_on_calendar != "This month":

            date_pickers.select_this_month_shortcut()
            date_pickers.apply_selected_date_filter()
            assert (
                date_pickers.get_applied_date_filter() == "This month"
            ), "fail to select this month"
        data_present_in_topic_page = page.check_for_data_present_in_topic_page()
        if data_present_in_topic_page:
            case = page.validate_case_and_client_count_in_second_topic_section()
            if case:
                graph = page.check_visibility_graph()
                assert graph, "Graph is not displayed"
            else:
                LOGGER.warning("No data to display")
        else:
            LOGGER.warning("No data present in topics page")

    @sanity_test
    @author_neha_jha
    @pytestrail.case("C2257")
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_topic_selection(self, driver, topics_setup):
        page = topics_page.TopicsPage(driver)
        page.click_on_topic_section()
        list_display = page.check_visibility_first_section_drop_down()
        assert list_display, "Failed to displayed drop down box"
        topic_name = page.get_group_by_filter_name_from_first_topic_list()
        page.select_first_topic_section()
        selected_topic = page.get_group_by_option_selected_in_primary_topic()
        assert selected_topic in topic_name, "Failed to select topic name "
        data_present_in_topic_page = page.check_for_data_present_in_topic_page()
        if data_present_in_topic_page:
            page.click_on_second_topic_section()
            second_list_display = page.check_visibility_second_section_drop_down()
            assert second_list_display, "Failed to display drop down"
            page.select_second_topic_section()
            selected_second_topic = page.selected_second_topic()
            assert selected_second_topic, "Failed to select topic name"
        else:
            LOGGER.warning("No data present in topics page")

    @author_neha_jha
    @pytestrail.case("C2258")
    @regression_test
    def test_functionality_of_case_status(self, driver, topics_setup):
        page = topics_page.TopicsPage(driver)
        sentiments = Sentiments(driver)

        case_filter = [
            CaseStatusFilter.ALL,
            CaseStatusFilter.OPEN,
            CaseStatusFilter.CLOSED,
        ]
        for case_status in case_filter:
            sentiments.filter_by_case_status(case_status)
            data_present_in_topic_page = page.check_for_data_present_in_topic_page()
            if data_present_in_topic_page:
                case = page.validate_case_and_client_count_in_second_topic_section()
                if case:
                    tab = "Conversations"
                    page.click_tabs(tab)
                    graph_name = page.get_name_graph()
                    graph_name_split = graph_name.split(" ")
                    result = graph_name_split[0]
                    assert result == tab, "Graph is not displayed"
                else:
                    LOGGER.warning(
                        "case count is zero so there is no present of cases "
                    )
            else:
                LOGGER.warning("No data present in topics page")

    @author_neha_jha
    @pytestrail.case("C203")
    @regression_test
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_functionality_of_sort_by(self, driver, topics_setup):
        page = topics_page.TopicsPage(driver)
        filter_name = page.get_text_of_sort_by_filter_applied()
        if filter_name != "Number of cases (High-low)":
            page.click_on_sort_by_filter_button()
            page.select_filter_based_on_sort_by_option(
                TopicSortByFilter.NUMBER_OF_CASES
            )
            after_selecting_filter = page.get_text_of_sort_by_filter_applied()
            assert (
                after_selecting_filter == "Number of cases (High-low)"
            ), "failed to match with number of cases filter option"
        assert page.get_number_cases_display_on_cards()

    @author_neha_jha
    @pytestrail.case("C204")
    def test_functionality_of_sort_by_percentage_change(self, driver, topics_setup):
        page = topics_page.TopicsPage(driver)
        filter_name = page.get_text_of_sort_by_filter_applied()
        if filter_name != "% Change (High-low)":
            page.click_on_sort_by_filter_button()
            page.select_filter_based_on_sort_by_option(
                TopicSortByFilter.PERCENTAGE_CHANGE
            )
        after_selecting_filter = page.get_text_of_sort_by_filter_applied()
        assert (
            after_selecting_filter == "% Change (High-low)"
        ), "failed to match with number of % Change"

    @author_neha_jha
    @pytestrail.case("C202")
    @regression_test
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_sort_by_filter_option(self, driver, topics_setup):
        page = topics_page.TopicsPage(driver)
        page.click_on_sort_by_filter_button()
        page.check_visibility_of_sort_by_filter_drop_down_menu()
        list_of_option = ["Number of cases", "% Change"]
        list_of_option_foundry =["Number of tickets", "% Change"]
        option = page.get_sort_by_filter_text_option()
        assert option == list_of_option or list_of_option_foundry == option, " list of option is same"



    @author_neha_jha
    @pytestrail.case("C209")
    @regression_test
    def test_functionality_of_suggestions_in_topics_group_by_option(self, driver, topics_setup):
        page = topics_page.TopicsPage(driver)
        page.click_on_topic_section()
        list_display = page.check_visibility_first_section_drop_down()
        assert list_display, "Failed to display list"
        topic_name = page.get_group_by_filter_name_from_first_topic_list()
        page.search_for_filter_name_in_first_topic_section(topic_name)
        first_topic_suggestion_option = page.get_text_of_primary_group_by_down_drop_menu_option_available()
        LOGGER.info(f"first topic drop down menu suggestion is {first_topic_suggestion_option}")
        assert topic_name in first_topic_suggestion_option, "failed to display suggestion drop down menu" \
                                                            " based on search "
        #secondary topic search

        page.click_on_second_topic_section()
        second_list_display = page.check_visibility_second_section_drop_down()
        assert second_list_display, "Failed to display list"
        second_group_by_filter_option = page.get_group_by_filter_name_from_first_topic_list()
        page.search_for_filter_name_in_second_topic_section(second_group_by_filter_option)
        second_group_by_filter_option_name = page.get_text_of_secondary_group_by_down_drop_menu_option_avaiable()
        assert second_group_by_filter_option in second_group_by_filter_option_name, "failed to display topic suggestion" \
                                                                                    "in drop down "





