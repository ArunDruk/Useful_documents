import logging
import time
from selenium.webdriver.support import expected_conditions as EC
import constants
import utils
from locators import my_dashboard_locator as mdl, agents_management_locator
import pytest
from selenium.webdriver.common.by import By
from constants import sanity_test, author_neha_jha,regression_test
from enums import NavbarItem, AgentManagementTabs
from pom_library import my_dashboard_page, agent_management_page
from pom_library.commons import Commons
from pom_library.navbar import Navbar
from pytest_testrail.plugin import pytestrail
LOGGER = logging.getLogger(__name__)
from pom_library.support_hub import SupportHub

@pytest.mark.usefixtures("driver")
class TestMyDashboard(object):
    @pytest.fixture()
    def my_dashboard_setup(self, driver):
        page = my_dashboard_page.MyDashboard(driver)
        navbar = Navbar(driver)
        commons = Commons(driver)
        current_url = navbar.navigate_to_navbar_page(NavbarItem.MY_DASHBOARD)
        assert "my-dashboard" in current_url, "failed to get load the page "
        commons.wait_for_loader_to_disappear()
        yield
        support_hub =SupportHub(driver)
        page.click_on_cross_button_on_add_a_card_pop_up()
        try:
            support_hub.close_support_hub_window()
        except:
            LOGGER.info("support hub window is not displayed")
        page.delete_list_and_tile_on_dash_board()

    @author_neha_jha
    @sanity_test
    @pytestrail.case('C2241')
    def test_welcome_page_visibility(self, driver, my_dashboard_setup):
        """1.checks for  welcome page is displayed
         if displayed
         2. checks for the welcome page title and click on first virtual team
         3. checks for the virtual team display in the my dashboard page
         4.print the virtual team name
         """

        page = my_dashboard_page.MyDashboard(driver)
        welcome_page=page.check_for_the_welcome_page_is_displayed()
        if welcome_page :
            welcome_page_note = page.welcome_page_title()
            if "You haven’t chosen your team yet!" == welcome_page_note:
                page.click_on_first_virtual_team_in_welcome_page()
        virtual_team = page.check_for_the_virtual_team()
        assert virtual_team, "failed to display virtual team  "
        virtual_team_dashboard=page.get_virtual_team_name_in_my_dashboard()
        LOGGER.info(f"{virtual_team_dashboard} is name of  virtual team")



    @sanity_test
    @author_neha_jha
    @pytestrail.case('C2242')
    def test_create_case_list(self,driver,my_dashboard_setup):
        """This helps check for case list is created or not"""
        page = my_dashboard_page.MyDashboard(driver)
        page.create_case_list()

    @sanity_test
    @author_neha_jha
    @pytestrail.case('C2243')
    def test_create_case_tile(self,driver,my_dashboard_setup):
        """ This helps check for case tile is created or not """
        page = my_dashboard_page.MyDashboard(driver)
        page.create_case_tile()

    @sanity_test
    @author_neha_jha
    @pytestrail.case('C2244')
    def test_delete_case_list(self,driver,my_dashboard_setup):
        """This method create the case list and delete the case list"""
        page = my_dashboard_page.MyDashboard(driver)
        page.create_case_list()
        page.delete_list_and_tile_on_dash_board()

    @sanity_test
    @author_neha_jha
    @pytestrail.case('C2245')
    def test_edit_case_list(self,driver,my_dashboard_setup):
        """1. create the case list
        2.click on vertical dots of created case list
        3.click on edit  case list button
        4.add case list pop up display edit the case name
        5. select negative or positive sentiments
        6.click on add button
        7. get the edit case list name in one variable assert edit is in case list """
        page = my_dashboard_page.MyDashboard(driver)
        dbname=page.create_case_list()
        page.click_on_vertical_dots_of_case_list(dbname)
        page.click_on_edit_case_list()
        edit_name ="Edit"
        page.edit_name_in_edit_list(edit_name)
        edit_name_in_list=page.get_edit_name_from_edit_list()
        page.click_on_about_miss_sla_in_card_list()
        page.click_on_add_button()
        first_case_list_name_after_edit=page.get_case_list_name_after_edit(dbname)
        assert edit_name_in_list in first_case_list_name_after_edit,"failed to  edit name "



    @author_neha_jha
    @sanity_test
    @pytestrail.case('C2246')
    def test_case_list_support_hub(self,driver,my_dashboard_setup):
        """1. create the case list
        2.get the first  case id in case list
        3.click on the first case list and get the case id in support hub
        4.assert both the case id"""
        page = my_dashboard_page.MyDashboard(driver)
        support_hub= SupportHub(driver)
        db_name=page.create_case_list()
        present_of_case_in_case_list=page.check_the_present_of_case_in_case_list()
        if present_of_case_in_case_list:
            case_id_on_case_list = page.get_text_first_case_id_in_case_list()
            page.click_on_first_case_in_case_list()
            assert  support_hub.check_visibility_of_support_hub(),"failed to display page"
            case_id_support_hub = support_hub.get_case_id()
            assert case_id_on_case_list == case_id_support_hub, " case id is mismatched "
        else:
            LOGGER.warning("No case in case list ")

    @author_neha_jha
    @sanity_test
    @pytestrail.case('C2247')
    def test_case_tile_support_hub(self,driver,my_dashboard_setup):
        """1. create the case tile
               2.get the first  case id in case tile
               3.click on the first case tile and get the case id in support hub
               4.assert both the case id"""
        page = my_dashboard_page.MyDashboard(driver)
        support_hub = SupportHub(driver)
        page.create_case_tile()
        case_count=page.get_case_count_first_tickets_in_case_tile()
        if case_count != "0 cases":
            page.click_on_first_tickets_in_case_tile()
            case_id_case_tile=page.get_text_of_case_id_in_case_tile()
            page.click_on_first_case_in_case_tile()
            assert support_hub.check_visibility_of_support_hub(), "failed to display page"
            case_id_support_hub=support_hub.get_case_id()
            assert case_id_support_hub ==case_id_case_tile," case is mismatched"
        else:
            LOGGER.warning(" no cases in case list ")

    @author_neha_jha
    @sanity_test
    @pytestrail.case('C2248')
    def test_edit_team_virtual_team(self,driver,my_dashboard_setup):
        """1.get the virtual team on the dashboard
        2.click on the verticals dots of virtual team
        3. click on the edit option
        get the number of virtual team, present on the dashboard if greater than one
        4.get the first virtual team on the welcome page check for the virtual team on dashboard == first virtual team
         if same
        5. click on second virtual team and get the name of second virtual team and assert
        6.if not same :
        click on first virtual team and get text of virtual team and assert
         """
        page = my_dashboard_page.MyDashboard(driver)
        virtual_team_dashboard = page.get_virtual_team_name_in_my_dashboard()
        page.click_on_vertical_dots_of_virtual_team()
        page.click_on_edit_team_of_virtual_team()
        virtual_team_present_case_list=page.get_number_virtual_team_present_on_dashboard()
        if virtual_team_present_case_list > 1:
            first_virtual_team_name=page.get_first_virtual_team_name()
            if virtual_team_dashboard ==first_virtual_team_name:
                    page.click_on_second_virtual_team_in_welcome_page()
                    second_virtual_team =page.click_on_second_virtual_team_in_welcome_page()
                    page.click_on_save_button()
                    virtual_team_dashboard_after_edit = page.get_virtual_team_name_in_my_dashboard().split("\n")
                    virtual_team_on_dashboard_edit = virtual_team_dashboard_after_edit[0]
                    assert virtual_team_on_dashboard_edit in second_virtual_team , "failed to match the virtual team"
            else:
                    page.click_on_first_virtual_team_in_welcome_page()
                    page.click_on_save_button()
                    virtual_team_dashboard_after_edit=page.get_virtual_team_name_in_my_dashboard().split("\n")
                    virtual_team_on_dashboard_edit =virtual_team_dashboard_after_edit[0]
                    assert  virtual_team_on_dashboard_edit in first_virtual_team_name ,"failed to match the virtual team"
        else:
            LOGGER.info("virtual team have only one virtual name edit is not possible")

    @author_neha_jha
    @sanity_test
    @pytestrail.case('C883')
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_no_of_agents_in_virtual_team_and_dash_board_is_same(self, driver, my_dashboard_setup):
        page = my_dashboard_page.MyDashboard(driver)
        navbar = Navbar(driver)
        agents = agent_management_page.AgentsPage(driver)
        virtual_team_name_in_dashboard = page.get_virtual_team_name_in_my_dashboard()
        virtual_team_dashboard = virtual_team_name_in_dashboard.split("|")
        agent_name = page.get_number_of_agents_name_present_in_dashboard()
        current_url = navbar.navigate_to_navbar_page(NavbarItem.VIRTUAL_TEAMS)
        assert "virtual-teams" in current_url, "failed to navigate the virtual teams"

        agents.search_virtual_teams(virtual_team_dashboard[0])
        agents.click_on_first_virtual_team_in_virtual_team_dashboard_expand()
        time.sleep(1)
        agents_name_in_virtual_team = agents.get_number_of_agents_name_present_present_in_first_virtual_team()
        assert agents_name_in_virtual_team == agent_name, "failed to check number of agents and agent present"

    @author_neha_jha
    @sanity_test
    @pytestrail.case('C885')
    def test_functionality_of_agents_link_in_dashboard(self, driver, my_dashboard_setup):
        page = my_dashboard_page.MyDashboard(driver)
        agents = agent_management_page.AgentsPage(driver)
        commons = Commons(driver)
        agent_name = page.get_number_of_agents_name_present_in_dashboard()
        page.click_on_first_agents_link_on_dash_board()
        window_handles = driver.window_handles
        driver.switch_to.window(window_handles[1])
        try:
            time.sleep(5)
            commons.wait_for_loader_to_disappear()
            agents_name_in_agents_profile = agents.get_agent_name_in_agents_profile()
            assert agent_name[0] == agents_name_in_agents_profile, "failed to click on first agents link"
            driver.close()
            driver.switch_to.window(window_handles[0])
        except:
            driver.close()
            driver.switch_to.window(window_handles[0])

    @author_neha_jha
    @sanity_test
    @pytestrail.case('C884')
    def test_one_agents_ticket_count_in_teams_and_dashboard(self, driver, my_dashboard_setup):
        page = my_dashboard_page.MyDashboard(driver)
        navbar = Navbar(driver)
        commons = Commons(driver)
        agents = agent_management_page.AgentsPage(driver)
        virtual_team_name_in_dashboard = page.get_virtual_team_name_in_my_dashboard()
        virtual_team_dashboard = virtual_team_name_in_dashboard.split("|")
        agent_name_in_dashboard = page.get_number_of_agents_name_present_in_dashboard()
        case_count_of_first_agents_in_dashboard = page.get_case_count_of_first_agents_in_dashboard()
        current_url = navbar.navigate_to_navbar_page(NavbarItem.VIRTUAL_TEAMS)
        assert "virtual-teams" in current_url, "failed to navigate the virtual teams"
        agents.search_virtual_teams(virtual_team_dashboard[0])
        agents.click_on_first_virtual_team_in_virtual_team_dashboard_expand()
        time.sleep(1)
        agents.click_on_particular_agent_name_in_virtual_team(agent_name_in_dashboard[0])
        window_handles = driver.window_handles
        driver.switch_to.window(window_handles[1])
        try:
            commons.wait_for_loader_to_disappear()
            check_for_agents_profile_is_displayed = agents.check_agents_profile()
            if check_for_agents_profile_is_displayed is False:
                assert case_count_of_first_agents_in_dashboard == 0, "case count in dashboard  and agents profile is mismatched"
            else:
                backlog_cases = agents.get_case_count_on_tabs(AgentManagementTabs.BACKLOG)
                assert backlog_cases == case_count_of_first_agents_in_dashboard, "case count in dashboard and agents profile mismatched"
            driver.close()
            driver.switch_to.window(window_handles[0])
        except:
            driver.close()
            driver.switch_to.window(window_handles[0])

    @author_neha_jha
    @sanity_test
    @pytestrail.case('C893')
    def test_sum_of_case_count_number_of_agents_is_equal_to_my_dashboard_case_count(self, driver, my_dashboard_setup):
        page = my_dashboard_page.MyDashboard(driver)
        navbar = Navbar(driver)
        agents = agent_management_page.AgentsPage(driver)
        current_url = navbar.navigate_to_navbar_page(NavbarItem.VIRTUAL_TEAMS)
        assert "virtual-teams" in current_url, "failed to navigate the virtual teams"
        virtual_team_name = "Dont_delete_automation_testing"
        agents.search_virtual_teams(virtual_team_name)
        my_team = agents.validate_whether_particular_virtual_team_is_set_in_dashboard(virtual_team_name)
        if my_team is False:
            agents.click_on_select_dashboard_icon_of_virtual_team(virtual_team_name)
        current_url = navbar.navigate_to_navbar_page(NavbarItem.MY_DASHBOARD)
        assert "my-dashboard" in current_url, "failed to get load the page "
        case_count = page.click_number_of_agents_link()
        total_count = 0
        for count in case_count:
            total_count += int(count)
        virtual_team_name_in_dashboard = page.get_virtual_team_name_in_my_dashboard()
        virtual_team_dashboard = virtual_team_name_in_dashboard.split("|")
        LOGGER.info(virtual_team_name_in_dashboard)
        LOGGER.info(virtual_team_dashboard)
        assert str(total_count) in virtual_team_dashboard[1], "failed to match the count "

    @author_neha_jha
    @sanity_test
    @pytestrail.case('C880','882','879')
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_functionality_of_create_new_virtual_team_and_assign_it_as_dashboard(self, driver):
        page = my_dashboard_page.MyDashboard(driver)
        navbar = Navbar(driver)
        agents = agent_management_page.AgentsPage(driver)
        current_url = navbar.navigate_to_navbar_page(NavbarItem.VIRTUAL_TEAMS)
        assert "virtual-teams" in current_url, "failed to navigate the virtual teams"
        agents.click_on_create_virtual_team()
        agents.click_on_global_team()
        vt_name = utils.generate_test_run_id(constants.VT_GLOBAL_RUN_ID_PREFIX)
        agents.enter_virtual_account_name_text_box(vt_name)
        agents.click_on_next_button()
        agents.search_agents_while_creating_virtual_team()
        agents.select_two_agents_while_creating_virtual_team()
        agents.click_on_create_button()
        agents.search_virtual_teams(vt_name)
        agents.click_on_select_dashboard_icon_of_virtual_team(vt_name)
        current_url = navbar.navigate_to_navbar_page(NavbarItem.MY_DASHBOARD)
        assert "my-dashboard" in current_url, "failed to get load the page "
        virtual_team_name_in_dashboard = page.get_virtual_team_name_in_my_dashboard()
        virtual_team_dashboard = virtual_team_name_in_dashboard.split("\n")
        LOGGER.info(virtual_team_name_in_dashboard)
        LOGGER.info(virtual_team_dashboard)
        assert vt_name == virtual_team_dashboard[0],"failed to assign virtual team"
        current_url = navbar.navigate_to_navbar_page(NavbarItem.VIRTUAL_TEAMS)
        assert "virtual-teams" in current_url, "failed to navigate the virtual teams"
        agents.search_virtual_teams(vt_name)
        agents.hover_on_element((By.XPATH, agents_management_locator.virtual_team_name.replace("agents_name",vt_name)))
        agents.click_on_delete_vt()
        agents.click_on_delete_button_delete_pop_up()
        current_url = navbar.navigate_to_navbar_page(NavbarItem.MY_DASHBOARD)
        assert "my-dashboard" in current_url, "failed to get load the page "
        assert page.check_for_the_welcome_page_is_displayed()
        current_url = navbar.navigate_to_navbar_page(NavbarItem.VIRTUAL_TEAMS)
        assert "virtual-teams" in current_url, "failed to navigate the virtual teams"
        assert agents.validate_you_have_not_chosen_your_team_yet_banner_in_vt_module()

    @author_neha_jha
    @sanity_test
    @pytestrail.case('C881')
    def test_functionality_edit_virtual_team_from_vt_module(self, driver, my_dashboard_setup):
        page = my_dashboard_page.MyDashboard(driver)
        navbar = Navbar(driver)
        agents = agent_management_page.AgentsPage(driver)
        current_url = navbar.navigate_to_navbar_page(NavbarItem.VIRTUAL_TEAMS)
        assert "virtual-teams" in current_url, "failed to navigate the virtual teams"
        agents.click_on_create_virtual_team()
        agents.click_on_global_team()
        vt_name = utils.generate_test_run_id(constants.VT_GLOBAL_RUN_ID_PREFIX)
        agents.enter_virtual_account_name_text_box(vt_name)
        agents.click_on_next_button()
        agents.search_agents_while_creating_virtual_team()
        agents.select_two_agents_while_creating_virtual_team()
        agents.click_on_create_button()
        agents.search_virtual_teams(vt_name)
        agents.click_on_select_dashboard_icon_of_virtual_team(vt_name)
        driver.refresh()
        current_url = navbar.navigate_to_navbar_page(NavbarItem.MY_DASHBOARD)
        assert "my-dashboard" in current_url, "failed to get load the page "
        virtual_team_name_in_dashboard = page.get_virtual_team_name_in_my_dashboard()
        virtual_team_dashboard = virtual_team_name_in_dashboard.split("\n")
        LOGGER.info(virtual_team_name_in_dashboard)
        LOGGER.info(virtual_team_dashboard)
        assert vt_name == virtual_team_dashboard[0], "failed to assign virtual team"
        current_url = navbar.navigate_to_navbar_page(NavbarItem.VIRTUAL_TEAMS)
        assert "virtual-teams" in current_url, "failed to navigate the virtual teams"

        agents.click_on_create_virtual_team()
        agents.click_on_global_team()
        vt_name_dashboard = utils.generate_test_run_id(constants.VT_GLOBAL_RUN_ID_PREFIX)
        agents.enter_virtual_account_name_text_box(vt_name_dashboard)
        agents.click_on_next_button()
        agents.search_agents_while_creating_virtual_team()
        agents.select_two_agents_while_creating_virtual_team()
        agents.click_on_create_button()
        agents.search_virtual_teams(vt_name_dashboard)
        my_team = agents.validate_whether_particular_virtual_team_is_set_in_dashboard(vt_name_dashboard)
        if my_team is False:
            agents.click_on_select_dashboard_icon_of_virtual_team(vt_name_dashboard)
            current_url = navbar.navigate_to_navbar_page(NavbarItem.MY_DASHBOARD)
            assert "my-dashboard" in current_url, "failed to get load the page "
        virtual_team_name_in_dashboard = page.get_virtual_team_name_in_my_dashboard()
        virtual_team_dashboard = virtual_team_name_in_dashboard.split("\n")
        LOGGER.info(virtual_team_dashboard)
        assert vt_name_dashboard != virtual_team_dashboard,"failed to edit virtual team"

    @author_neha_jha
    @sanity_test
    @pytestrail.case('C876')
    def test_functionality_of_personal_vt_is_select_as_primary_teams(self, driver, my_dashboard_setup):
        page = my_dashboard_page.MyDashboard(driver)
        navbar = Navbar(driver)
        agents = agent_management_page.AgentsPage(driver)
        current_url = navbar.navigate_to_navbar_page(NavbarItem.VIRTUAL_TEAMS)
        assert "virtual-teams" in current_url, "failed to navigate the virtual teams"
        agents.click_on_create_virtual_team()
        agents.click_on_personal_team()
        vt_name = utils.generate_test_run_id(constants.VT_GLOBAL_RUN_ID_PREFIX)
        agents.enter_virtual_account_name_text_box(vt_name)
        agents.click_on_next_button()
        agents.search_agents_while_creating_virtual_team()
        agents.select_two_agents_while_creating_virtual_team()
        agents.click_on_create_button()
        agents.search_virtual_teams(vt_name)
        agents.click_on_select_dashboard_icon_of_virtual_team(vt_name)
        current_url = navbar.navigate_to_navbar_page(NavbarItem.MY_DASHBOARD)
        assert "my-dashboard" in current_url, "failed to get load the page "
        virtual_team_name_in_dashboard = page.get_virtual_team_name_in_my_dashboard()
        virtual_team_dashboard = virtual_team_name_in_dashboard.split("\n")
        LOGGER.info(virtual_team_name_in_dashboard)
        LOGGER.info(virtual_team_dashboard)
        assert vt_name == virtual_team_dashboard[0], "failed to assign virtual team"

    @author_neha_jha
    @sanity_test
    @pytestrail.case('C875')
    def test_functionality_navigate_go_to_my_dashboard_pop_up(self, driver, my_dashboard_setup):
        """steps :
        1.create  a virtual team
        2.assigned the virtual team to the dash board and assert weather its assigned or not
        3.navigated to virtual team module -search for vt and unassigned it
        4.assigned the Vt to dashboard by clicking on arrow icon
        5.go to dashboard pop up will be appear """

        page = my_dashboard_page.MyDashboard(driver)
        navbar = Navbar(driver)
        agents = agent_management_page.AgentsPage(driver)
        current_url = navbar.navigate_to_navbar_page(NavbarItem.VIRTUAL_TEAMS)
        assert "virtual-teams" in current_url, "failed to navigate the virtual teams"
        agents.click_on_create_virtual_team()
        agents.click_on_global_team()
        vt_name = utils.generate_test_run_id(constants.VT_GLOBAL_RUN_ID_PREFIX)
        agents.enter_virtual_account_name_text_box(vt_name)
        agents.click_on_next_button()
        agents.search_agents_while_creating_virtual_team()
        agents.select_two_agents_while_creating_virtual_team()
        agents.click_on_create_button()
        agents.search_virtual_teams(vt_name)
        agents.click_on_select_dashboard_icon_of_virtual_team(vt_name)
        current_url = navbar.navigate_to_navbar_page(NavbarItem.MY_DASHBOARD)
        assert "my-dashboard" in current_url, "failed to get load the page "
        virtual_team_name_in_dashboard = page.get_virtual_team_name_in_my_dashboard()
        virtual_team_dashboard = virtual_team_name_in_dashboard.split("\n")
        assert vt_name == virtual_team_dashboard[0], "failed to assign virtual team"
        current_url = navbar.navigate_to_navbar_page(NavbarItem.VIRTUAL_TEAMS)
        assert "virtual-teams" in current_url, "failed to navigate the virtual teams"
        agents.search_virtual_teams(vt_name)
        #unassigned the virtual team to dash board (reset )
        agents.click_on_select_dashboard_icon_of_virtual_team(vt_name)
        #to set same virtual team to dash board
        agents.click_on_select_dashboard_icon_of_virtual_team(vt_name)
        agents.click_go_to_my_dashboard_button_pop_up()
        assert "my-dashboard" in driver.current_url, "failed to navigate dashboard by click on that go to dashboard" \
                                                     " button on pop up "

    @author_neha_jha
    @sanity_test
    @pytestrail.case('C874')
    def test_functionality_of_discarding_go_to_my_dash_board_pop_up(self, driver, my_dashboard_setup):
        """steps :
        1.create  a virtual team
        2.assigned the virtual team to the dash board and assert weather its assigned or not
        3.navigated to virtual team module -search for vt and unassigned it
        4.assigned the Vt to dashboard by clicking on arrow icon
        5.discard go to dashboard pop up """

        page = my_dashboard_page.MyDashboard(driver)
        navbar = Navbar(driver)
        agents = agent_management_page.AgentsPage(driver)
        current_url = navbar.navigate_to_navbar_page(NavbarItem.VIRTUAL_TEAMS)
        assert "virtual-teams" in current_url, "failed to navigate the virtual teams"
        agents.click_on_create_virtual_team()
        agents.click_on_global_team()
        vt_name = utils.generate_test_run_id(constants.VT_GLOBAL_RUN_ID_PREFIX)
        agents.enter_virtual_account_name_text_box(vt_name)
        agents.click_on_next_button()
        agents.search_agents_while_creating_virtual_team()
        agents.select_two_agents_while_creating_virtual_team()
        agents.click_on_create_button()
        agents.search_virtual_teams(vt_name)
        agents.click_on_select_dashboard_icon_of_virtual_team(vt_name)
        current_url = navbar.navigate_to_navbar_page(NavbarItem.MY_DASHBOARD)
        assert "my-dashboard" in current_url, "failed to get load the page "
        virtual_team_name_in_dashboard = page.get_virtual_team_name_in_my_dashboard()
        virtual_team_dashboard = virtual_team_name_in_dashboard.split("\n")
        assert vt_name == virtual_team_dashboard[0], "failed to assign virtual team"
        current_url = navbar.navigate_to_navbar_page(NavbarItem.VIRTUAL_TEAMS)
        assert "virtual-teams" in current_url, "failed to navigate the virtual teams"
        agents.search_virtual_teams(vt_name)
        # unassigned the virtual team to dash board (reset )
        agents.click_on_select_dashboard_icon_of_virtual_team(vt_name)
        # to set same virtual team to dash board
        agents.click_on_select_dashboard_icon_of_virtual_team(vt_name)
        agents.cross_icon_on_go_to_my_dashboard_pop_up()
        assert "virtual-teams" in driver.current_url, "failed to navigate dashboard by click on that go to dashboard" \
                                                     " button on pop up "

    @pytestrail.case('C893')
    def test_functionality_of_cancel_button(self, driver, my_dashboard_setup):
        page = my_dashboard_page.MyDashboard(driver)
        case_list_present_case_list = page.get_number_of_list_present_on_dashboard()
        page.click_on_plus_button()
        page.click_on_case_list_option()
        page.click_on_cancel_button()
        page.click_on_plus_button()
        page.click_on_case_list_option()
        page.click_on_next_button()
        page.click_on_negative_sentiments_in_card_list()
        page.click_on_cancel_button()
        case_list_after_case_list = page.get_number_of_list_present_on_dashboard()
        assert case_list_present_case_list == case_list_after_case_list," case list before count and after is differ"

    @author_neha_jha
    @sanity_test
    @pytestrail.case('C894')
    def test_functionality_of_back_button(self, driver, my_dashboard_setup):
        page = my_dashboard_page.MyDashboard(driver)
        case_list_present_case_list = page.get_number_of_list_present_on_dashboard()
        page.click_on_plus_button()
        page.click_on_case_list_option()
        page.click_on_next_button()
        page.click_on_negative_sentiments_in_card_list()
        page.click_on_back_button()
        assert page.is_element_visible(
            (By.XPATH, mdl.case_list)
        ), "case list not visible"
        case_list_after_case_list = page.get_number_of_list_present_on_dashboard()
        assert case_list_present_case_list == case_list_after_case_list, "case list before count and after is differ"

    @author_neha_jha
    @sanity_test
    @pytestrail.case('C872')
    def test_check_if_an_existing_vt_is_getting_selected_as_primary_teams_from_vt_page(self, driver, my_dashboard_setup):
        page = my_dashboard_page.MyDashboard(driver)
        navbar = Navbar(driver)
        agents = agent_management_page.AgentsPage(driver)
        current_url = navbar.navigate_to_navbar_page(NavbarItem.VIRTUAL_TEAMS)
        assert "virtual-teams" in current_url, "failed to navigate the virtual teams"
        virtual_team_name=agents.get_text_of_first_virtual_team_name()
        my_team = agents.validate_whether_particular_virtual_team_is_set_in_dashboard(virtual_team_name)
        if my_team is False:
            agents.search_virtual_teams(virtual_team_name)
            agents.click_on_select_dashboard_icon_of_virtual_team(virtual_team_name)
        driver.refresh()
        current_url = navbar.navigate_to_navbar_page(NavbarItem.MY_DASHBOARD)
        assert "my-dashboard" in current_url, "failed to get load the page "
        virtual_team_name_in_dashboard = page.get_virtual_team_name_in_my_dashboard()
        virtual_team_dashboard = virtual_team_name_in_dashboard.split("\n")
        LOGGER.info(virtual_team_name_in_dashboard)
        LOGGER.info(virtual_team_dashboard)
        assert virtual_team_name == virtual_team_dashboard[0], "failed to assign virtual team"