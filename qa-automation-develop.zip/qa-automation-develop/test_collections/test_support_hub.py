"""Test class for Support Hub"""
__author__ = "Praveen Nagajothi"
__copyright__ = "Copyright (C) 2021 SupportLogic"

import logging
import os
import random
import time
from datetime import date
from typing import Union

import pytest
from pytest_testrail.plugin import pytestrail
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webelement import WebElement

import utils
from constants import (
    author_neha_jha, author_praveen_nj, regression_test, report_dir, sanity_test,
    sfdc_test,
)
from enums import CasePriority, CaseStatus, ConsolePageTabs, NavbarItem


from locators import console_page_locators as cpl
from locators import escalations_management_locators as eml
from pom_library import customer_management_page, console_page

from locators import (
    console_page_locators as cpl,
    escalations_management_locators as eml
)


from locators import support_hub_locators as shl
from pom_library import customer_management_page

from pom_library.commons import Commons
from pom_library.console_page import ConsolePage
from pom_library.helper_methods import HelperMethods
from pom_library.navbar import Navbar
from pom_library.support_hub import SupportHub

LOGGER: logging.Logger = logging.getLogger(__name__)


class TestSupportHub:
    file_name: str = report_dir + "/case_id.txt"

    @pytest.fixture(scope="class")
    def support_hub_setup(self, driver):
        navbar = Navbar(driver)
        commons = Commons(driver)
        support_hub = SupportHub(driver)

        case_id: Union[str, list] = utils.read_text_file(TestSupportHub.file_name)
        if not case_id:
            current_page_url: str = navbar.navigate_to_navbar_page(
                NavbarItem.ESCALATIONS
            )
            assert "escalations" in current_page_url, "Failed to load Escalations page"
            commons.wait_for_loader_to_disappear()
            commons.start_module_onboarding()

            element: WebElement = driver.find_element(
                By.CSS_SELECTOR, eml.active_escalations_css
            )
            case_id = element.get_attribute("data-testid").split("-")[-1]
            utils.write_to_file(case_id, TestSupportHub.file_name)
            element.click()
        else:
            case_id = case_id if isinstance(case_id, str) else case_id[0]
            utils.write_to_file(case_id, TestSupportHub.file_name)
            commons.search_globally_for(case_id)
            commons.wait_for_loader_to_disappear()

        assert (
            support_hub.check_visibility_of_support_hub()
        ), "SupportHub is not visible"
        assert utils.validate_values_equals(
            "Case ID in support hub",
            support_hub.get_case_id(),
            "Case ID searched",
            case_id,
        ), "SupportHub case is different from case clicked"

        yield
        support_hub.close_support_hub_window()
        assert (
            support_hub.check_visibility_of_support_hub() is False
        ), "SupportHub is visible after clicking close"
        LOGGER.info("SupportHub modal window is closed")

    @pytest.fixture
    def client_note_setup(self, driver, support_hub_setup):
        support_hub = SupportHub(driver)

        support_hub.open_add_client_note_popover()
        yield
        support_hub.close_client_note_popover()
        time.sleep(3)

    @pytest.fixture
    def console_setup(self, driver):
        navbar = Navbar(driver)
        commons = Commons(driver)
        support_hub = SupportHub(driver)

        current_url = navbar.navigate_to_navbar_page(NavbarItem.CONSOLE)
        assert "console" in current_url, "Failed to load Console page"
        commons.start_module_onboarding()
        commons.wait_for_loader_to_disappear()

        yield
        support_hub.close_support_hub_window()
        assert (
            support_hub.check_visibility_of_support_hub() is False
        ), "SupportHub is visible after clicking close"
        LOGGER.info("SupportHub modal window is closed")

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C287")
    def test_case_share_button_tooltip(self, driver, console_setup):
        console = ConsolePage(driver)
        helpers = HelperMethods(driver)

        driver.get(utils.get_app_url() + "/support/console?tab=Negative+Sentiments")
        console_data_present = console.check_for_console_dashboard_display_data()
        if not console_data_present:
            raise Exception("There are no cases in Console -> Negative Sentiments tab")

        console.click_on_tab(ConsolePageTabs.NEGATIVE_SENTIMENTS)
        select_card = console.select_cards_data_validation(card="Negative")
        assert select_card, "failed to select card on support hub"
        helpers.hover_on_element((By.XPATH, cpl.support_hub_in_negative))
        helpers.hover_on_element(
            (By.XPATH, cpl.console_negative_case_card_share_button)
        )
        assert helpers.is_element_visible(
            (By.XPATH, cpl.share_button_tooltip)
        ), "Console -> Negative Sentiment case share button tooltip not displayed"

        console.click_on_to_open_support_hub_in_cards()
        helpers.hover_on_element((By.CSS_SELECTOR, shl.share_button_outer_css))
        assert (
            helpers.is_element_visible((By.XPATH, cpl.share_button_tooltip)) is False
        ), "Share button has tooltip is present in SupportHub"

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C288")
    def test_case_share_button_icon_console_v_support_hub(self, driver, console_setup):
        console = ConsolePage(driver)
        helpers = HelperMethods(driver)

        driver.get(utils.get_app_url() + "/support/console?tab=Negative+Sentiments")
        console_data_present = console.check_for_console_dashboard_display_data()
        if not console_data_present:
            raise Exception("There are no cases in Console -> Negative Sentiments tab")

        console.click_on_tab(ConsolePageTabs.NEGATIVE_SENTIMENTS)
        select_card = console.select_cards_data_validation(card="Negative")
        assert select_card, "failed to select card on support hub"

        helpers.hover_on_element((By.XPATH, cpl.support_hub_in_negative))
        console_share_icon = helpers.is_element_visible(
            (By.CSS_SELECTOR, cpl.share_button_icon_css)
        )

        console.click_on_to_open_support_hub_in_cards()
        assert console_share_icon is helpers.is_element_visible(
            (By.CSS_SELECTOR, shl.share_button_icon_css)
        ), "Case Share icon is different in console and SupportHub"

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C320")
    @pytest.mark.skip(reason="Failing to click pie chart in console -> service comp.")
    def test_notify_agent_button(self, driver):
        console = ConsolePage(driver)
        helpers = HelperMethods(driver)
        support_hub = SupportHub(driver)

        driver.get(utils.get_app_url() + "/support/console?tab=Service+Compliance")
        console_data_present = console.check_for_console_dashboard_display_data()
        if not console_data_present:
            raise Exception("There are no cases in Console -> Service Compliance tab")

        helpers.mouse_click_on_element(
            (By.CSS_SELECTOR, cpl.service_compliance_missed_target_chart_section_css),
            message="Failed to click on missed section in service compliance pie chart",
        )
        helpers.click_on_element(
            (By.CSS_SELECTOR, cpl.case_list_card_css),
            message="Failed to click first case card in list",
        )
        assert (
            support_hub.check_visibility_of_support_hub()
        ), "SupportHub is not visible"

        assert helpers.is_element_visible(
            (By.CSS_SELECTOR, shl.notify_agent_button_css),
        ), "Notify agent button is not displayed for missed target cases in SupportHub"

        helpers.click_on_element(
            (By.CSS_SELECTOR, shl.notify_agent_button_css),
            message="Failed to click on 'Notify agent' button in SupportHub",
        )
        assert helpers.is_element_visible(
            (By.CSS_SELECTOR, shl.share_case_popover_css)
        ), "Case share popover is not displayed after clicking notify agent button"

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C272", "C273")
    def test_support_hub_opening_and_close(self, driver):
        navbar = Navbar(driver)
        commons = Commons(driver)
        support_hub = SupportHub(driver)

        current_page_url: str = navbar.navigate_to_navbar_page(NavbarItem.ESCALATIONS)
        assert "escalations" in current_page_url, "Failed to load Escalations page"
        commons.wait_for_loader_to_disappear()
        commons.start_module_onboarding()

        element: WebElement = driver.find_element(
            By.CSS_SELECTOR, eml.active_escalations_css
        )
        case_id = element.get_attribute("data-testid").split("-")[-1]
        utils.write_to_file(case_id, TestSupportHub.file_name)

        element.click()
        assert (
            support_hub.check_visibility_of_support_hub()
        ), "SupportHub is not visible"
        assert utils.validate_values_equals(
            "Case ID in support hub",
            support_hub.get_case_id(),
            "Case ID searched",
            case_id,
        ), "SupportHub case is different from case clicked"

        support_hub.close_support_hub_window()
        assert (
            support_hub.check_visibility_of_support_hub() is False
        ), "SupportHub is visible after clicking close"
        LOGGER.info("SupportHub modal window is closed")

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C276")
    def test_add_client_note_components(self, driver, client_note_setup):
        support_hub = SupportHub(driver)

        support_hub.click_add_new_client_note_button()
        assert support_hub.is_element_visible(
            (By.CSS_SELECTOR, shl.save_client_note_css)
        ), "Client note Add button is not visible or present"
        LOGGER.info("Save button in client note is visible")
        assert support_hub.is_element_visible(
            (By.CSS_SELECTOR, shl.cancel_new_client_note_css)
        ), "Client note Cancel button is not visible or present"
        LOGGER.info("Cancel client note button is visible")

        assert (
            support_hub.check_client_notes_visibility()
        ), "Client notes are not visible or present"
        LOGGER.info("Client notes is/are visible")

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C277")
    def test_client_note_agent_icon_and_time(self, driver, client_note_setup):
        support_hub = SupportHub(driver)

        if not support_hub.get_client_notes_count_in_support_hub() > 0:
            LOGGER.warning("No client note is available")
        else:
            assert support_hub.is_element_visible(
                (By.CSS_SELECTOR, shl.client_note_agent_icon_css)
            ), "Client note agent icon is not visible or present"
            LOGGER.info("Agent icon in client note is visible")

            assert support_hub.is_element_visible(
                (By.CSS_SELECTOR, shl.client_note_time_css)
            ), "Time of client note creation is not visible"
            LOGGER.info("Client note add time is visible")

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C278")
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_cancel_client_note(self, driver, client_note_setup):
        support_hub = SupportHub(driver)
        dummy_client_note: str = "testing cancel button"

        support_hub.click_add_new_client_note_button()
        support_hub.enter_client_note_text(dummy_client_note)
        support_hub.cancel_adding_new_client_note()

        assert (
            support_hub.check_visibility_of_given_client_note(dummy_client_note)
            is False
        ), "Entered note is found after clicking cancel button"
        assert (
            support_hub.is_element_visible(
                (By.CSS_SELECTOR, shl.client_note_textarea_css)
            )
            is False
        ), "Client note textarea is visible"
        LOGGER.info("Client note textarea is not visible as expected")

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C279")
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_add_button_disabled_on_empty_note(self, driver, client_note_setup):
        support_hub = SupportHub(driver)

        support_hub.click_add_new_client_note_button()
        assert (
            support_hub.is_element_enabled((By.CSS_SELECTOR, shl.save_client_note_css))
            is False
        ), "Save client note button is enabled"
        LOGGER.info("Save client note button is not enabled as expected")

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C280", "C281", "C282")
    @pytest.mark.skip(reason="Covered in Cypress")
    @pytest.mark.xfail(reason="Combines 3 TC. Depends on the success of all 3 to pass")
    def test_add_edit_delete_client_note(self, driver, client_note_setup):
        """
        EXPECTED TO FAIL
        Dependent on each other until we start using API for creating and deleting
        client notes as needed.
        """
        support_hub = SupportHub(driver)
        note: str = utils.generate_test_run_id("automation test note", iterate=False)
        try:
            support_hub.click_add_new_client_note_button()
            support_hub.enter_client_note_text(note)
            support_hub.save_client_note()
            support_hub.wait_for_new_client_note_to_appear(note)

            assert utils.validate_values_equals(
                "New client note",
                support_hub.get_client_note_text(),
                "Value passed",
                note,
            ), "note added is not same as expected"
        except TimeoutException as e:
            raise Exception(
                f"{e.__class__.__name__}: {e}" f"\nLine no: {e.__traceback__.tb_lineno}"
            )
        new_note: str = utils.generate_test_run_id("Edited note", iterate=False)
        try:
            support_hub.edit_client_note(note, new_note)
            support_hub.wait_for_new_client_note_to_appear(new_note)
            assert utils.validate_values_equals(
                "Edited client note",
                support_hub.get_client_note_text(),
                "Value passed",
                new_note,
            ), "edited note is not same as expected"
        except TimeoutException as e:
            raise Exception(
                f"{e.__class__.__name__}: {e}" f"\nLine no: {e.__traceback__.tb_lineno}"
            )

        try:
            support_hub.delete_client_note(new_note)
            support_hub.wait_for_new_client_note_to_disappear(new_note)
            assert (
                utils.validate_values_equals(
                    "Client note",
                    support_hub.get_client_note_text(),
                    "Value passed",
                    new_note,
                )
                is False
            ), "Failed to delete note"
        except TimeoutException as e:
            raise Exception(
                f"{e.__class__.__name__}: {e}" f"\nLine no: {e.__traceback__.tb_lineno}"
            )

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C289")
    def test_share_button_enable_disable(self, driver, support_hub_setup):
        support_hub = SupportHub(driver)

        disable_button_css: str = "Ko-g-3VBzY5DbUVxlb5S0"
        support_hub.open_case_share_popover()
        support_hub.enter_share_case_email_address("")
        assert disable_button_css in driver.find_element(
            By.CSS_SELECTOR, shl.share_button_inner_css
        ).get_attribute("class"), "Inner share case button is enabled"
        LOGGER.info("Share button in Share case popover is disabled")

        support_hub.enter_share_case_email_address(os.getenv("SL_USER"))
        assert (
            support_hub.validate_share_case_email_address() is False
        ), "Entered email address is not valid"

        assert disable_button_css not in driver.find_element(
            By.CSS_SELECTOR, shl.share_button_inner_css
        ).get_attribute("class"), "Inner share case button is disabled"
        LOGGER.info("Share button in Share case popover is enabled")
        support_hub.close_case_share_popover()

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C292")
    def test_shared_with_visible(self, driver, support_hub_setup):
        support_hub = SupportHub(driver)

        support_hub.share_case_via_email(os.getenv("SL_USER"))
        assert support_hub.is_case_shared(), "'Shared with' info not displayed"
        support_hub.close_case_share_popover()

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C293")
    def test_email_received_on_share_case(self, driver, support_hub_setup):
        support_hub = SupportHub(driver)

        username: str = support_hub.username
        email_pwd: str = os.getenv("EMAIL_APP_PWD")

        support_hub.share_case_via_email(username)
        assert support_hub.is_case_shared(), "Failed to check if case is shared"

        case_id: str = utils.read_text_file(TestSupportHub.file_name)[0]
        time.sleep(10)  # wait for the incoming mail to be received
        subjects: set[str] = utils.fetch_email_subjects(username, email_pwd)

        assert case_id in "".join(subjects), "Case share invite email is not received"
        utils.delete_email_by_sender_and_date_received(
            username, email_pwd, "noreply@mail-dev.supportlogic.io", date.today(), True
        )
        LOGGER.info("Case Share invite email is received")

    @sfdc_test
    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C296")
    def test_change_case_status(self, driver, support_hub_setup):
        support_hub = SupportHub(driver)

        current_status: str = support_hub.get_case_status()
        random_status = random.choice(list(CaseStatus))
        for status in CaseStatus:
            if current_status != random_status.value:
                break
            random_status = status
        support_hub.edit_case_status(random_status)
        assert utils.validate_values_equals(
            "Current case status",
            support_hub.get_case_status(),
            "Expected Status",
            random_status.value,
        ), "Status is not same as expected after changing"

    @sfdc_test
    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C297")
    def test_change_case_priority(self, driver, support_hub_setup):
        support_hub = SupportHub(driver)

        current_priority: str = support_hub.get_case_priority()
        random_priority = random.choice(list(CasePriority))
        for priority in CasePriority:
            if current_priority != random_priority.value:
                break
            random_priority = priority
        support_hub.edit_case_priority(random_priority)
        assert utils.validate_values_in(
            "Current case priority",
            support_hub.get_case_priority(),
            "Expected Priority",
            random_priority.value,
        ), "Priority is not same as expected after changing"

    @sfdc_test
    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C298")
    def test_change_assigned_agent(self, driver, support_hub_setup):
        support_hub = SupportHub(driver)

        search_text = "jo"
        selected_agent: str = support_hub.assign_new_agent(search_text)
        time.sleep(5)  # wait for agent change to reflect
        assert utils.validate_values_in(
            "Assigned agent",
            support_hub.get_agent_name(),
            "Selected agent",
            selected_agent,
        ), "Agent name is not same as expected after changing"

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C299")
    def test_add_remove_favorite(self, driver, support_hub_setup):
        support_hub = SupportHub(driver)

        support_hub.mark_as_favorite()
        assert support_hub.is_favorite_client(), "Client is not marked favorite"
        LOGGER.info("Case is successfully added as favorite")

        support_hub.mark_as_not_favorite()
        assert (
            support_hub.is_favorite_client() is False
        ), "Client is still marked as favorite"
        LOGGER.info("Case is successfully removed from favorite")

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C211")
    def test_conversation_search(self, driver, support_hub_setup):
        support_hub = SupportHub(driver)

        search_text = "th"
        support_hub.search_conversation_for(search_text)
        highlighted_text: str = support_hub.get_search_result_text_from_case_comments(
            search_text
        ).lower()
        failure_message: str = f"{search_text} is not same as {highlighted_text}"
        assert highlighted_text in ["", search_text], failure_message

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C2273")
    def test_case_fields(self, driver, support_hub_setup):
        support_hub = SupportHub(driver)

        LOGGER.info("Expanding case fields overflow section..")
        assert support_hub.is_element_visible(
            (By.CSS_SELECTOR, shl.case_field_overflow_css)
        ), "Case Field overflow button is not visible"
        support_hub.click_on_element(
            (By.CSS_SELECTOR, shl.case_field_overflow_css),
            message="SupportHub case field overflow button is not visible or present",
        )
        LOGGER.info("Checking visibility of custom field tags..")
        assert support_hub.is_element_visible(
            (By.CSS_SELECTOR, shl.case_field_overflow_popover_css), timeout=30
        ), "Custom field tags are not visible or present"
        LOGGER.info("Custom field tags are present and visible")

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C2274")
    def test_sentiment_label_click(self, driver, support_hub_setup):
        support_hub = SupportHub(driver)

        if support_hub.is_element_visible(
            (By.XPATH, shl.no_sentiments_found_text), timeout=5
        ):
            LOGGER.warning(
                f"Case {support_hub.get_case_id()} has no detected sentiments"
            )
        else:
            label_text: str = support_hub.click_sentiment_label_and_get_trigger_text()
            LOGGER.info(f"Sentiment label text: {label_text}")
            assert support_hub.is_element_visible(
                (
                    By.XPATH,
                    shl.labelled_sentiment_with_text.format(trigger_text=label_text),
                )
            ), "Text in sentiment label is not same found in respective case comment"
            LOGGER.info("Sentiment label text is found in case comment")

    @sfdc_test
    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C283")
    def test_private_case_note_with_cc_bcc(self, driver, support_hub_setup):
        support_hub = SupportHub(driver)

        case_note = utils.generate_test_run_id("automation private note", iterate=False)
        support_hub.add_new_case_note(
            case_note,
            cc_email=os.getenv("SL_USER"),
            bcc_email=os.getenv("SL_USER"),
        )

        newly_added_note: str = support_hub.get_element_text_or_value(
            (By.CSS_SELECTOR, shl.case_comments_text_css),
            message="Failed to get text from private note",
        )
        assert case_note in newly_added_note, f"{case_note} not in {newly_added_note}"

    @sfdc_test
    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C285")
    def test_public_case_note(self, driver, support_hub_setup):
        support_hub = SupportHub(driver)

        case_note = utils.generate_test_run_id("automation public note", iterate=False)
        support_hub.add_new_case_note(case_note, make_public=True)

        newly_added_note: str = support_hub.get_element_text_or_value(
            (By.CSS_SELECTOR, shl.case_comments_text_css),
            timeout=5,
            message="Failed to get text from public note",
        )
        assert case_note in newly_added_note, f"{case_note} not in {newly_added_note}"

        case_note_locator = shl.private_case_note_icon.format(case_note=case_note)
        assert (
            support_hub.is_element_visible((By.XPATH, case_note_locator)) is False
        ), f"Newly added case note is not public as expected"

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C2275")
    def test_add_escalation_note(self, driver, support_hub_setup):
        support_hub = SupportHub(driver)

        if not support_hub.is_case_escalated():
            LOGGER.warning("Cannot add escalation to non-escalated case")
            return

        note: str = utils.generate_test_run_id("Escalation note", iterate=False)
        support_hub.add_new_escalation_note(note)
        support_hub.wait_for_new_escalation_note_to_be_added(note)
        assert utils.validate_values_equals(
            "Last added escalation note",
            support_hub.get_escalation_note_text(),
            "Expected escalation note",
            note,
        ), "Last added escalation note not same as expected"

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C300")
    def test_customer_favoriting_add(self, driver, support_hub_setup):
        support_hub = SupportHub(driver)

        support_hub.mark_as_not_favorite()
        support_hub.hover_on_element((By.CSS_SELECTOR, shl.favorite_client_button_css))
        assert support_hub.is_element_visible(
            (By.CSS_SELECTOR, shl.favorites_tooltip_css)
        ), "Favorite button tooltip is not displayed"
        assert "Add" in support_hub.get_element_text_or_value(
            (By.CSS_SELECTOR, shl.favorites_tooltip_css),
            message="Failed to get tooltip text",
        ), "Tooltip for 'add to favorite' button is displayed incorrectly"

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C301")
    def test_customer_favoriting_remove(self, driver, support_hub_setup):
        support_hub = SupportHub(driver)

        support_hub.mark_as_favorite()
        support_hub.hover_on_element((By.CSS_SELECTOR, shl.favorite_client_button_css))
        assert support_hub.is_element_visible(
            (By.CSS_SELECTOR, shl.favorites_tooltip_css)
        ), "Favorite button tooltip is not displayed"
        assert "Remove" in support_hub.get_element_text_or_value(
            (By.CSS_SELECTOR, shl.favorites_tooltip_css),
            message="Failed to get tooltip text",
        ), "Tooltip for 'remove favorite' button is displayed incorrectly"

    @regression_test
    @author_neha_jha
    @pytestrail.case("C302")
    def test_hover_over_reporter_name(self, driver, support_hub_setup):
        support_hub = SupportHub(driver)
        support_hub.hover_on_element((By.CSS_SELECTOR, shl.reporter_name_css))
        assert support_hub.is_element_visible(
            (By.XPATH, shl.reporter_tool_tip_xpath)
        ), "reporter tool tip is displayed"
        assert support_hub.check_for_reporter_name_display_in_tool_tip()
        assert support_hub.check_for_reporter_email_display_in_tool_tip()
        assert support_hub.check_for_report_active_hours_display_in_tooltip()

    @regression_test
    @author_neha_jha
    @pytestrail.case("C308")
    def test_functionality_of_click_on_customer_name_lead_to_customer_page(
        self, driver, support_hub_setup
    ):
        support_hub = SupportHub(driver)
        page = customer_management_page.CustomerManagementPage(driver)
        customer_name = support_hub.get_customer_name()
        support_hub.click_on_customer_name()
        open_windows = driver.window_handles
        driver.switch_to.window(open_windows[1])
        try:
            time.sleep(5)
            profile_agent_name = page.get_text_profile_customer()
            assert customer_name == profile_agent_name, "failed to match customer name"
        except:
            driver.close()
            driver.switch_to.window(open_windows[0])
        driver.close()
        driver.switch_to.window(open_windows[0])

    @regression_test
    @author_neha_jha
    @pytestrail.case("C307")
    @pytest.mark.skipif(
        "staging" in utils.get_app_url(), reason="tool tip cannot verify in staging"
    )
    def test_on_click_case_status_listing_down_case_status(
        self, driver, support_hub_setup
    ):
        support_hub = SupportHub(driver)
        support_hub.hover_on_element((By.CSS_SELECTOR, shl.edit_case_status_css))
        assert support_hub.check_for_case_status_tool_tip()
        support_hub.click_on_case_status_button()
        assert support_hub.get_element_when_visible(
            (By.CSS_SELECTOR, shl.case_status_options_popover_css),
            message="Case Status options popup is not displayed",
        )

    @regression_test
    @author_neha_jha
    @pytestrail.case("C303")
    @pytestrail.case("C304")
    def test_hovering_over_case_owner(self, driver, ):
        support_hub_page = SupportHub(driver)

        page = console_page.ConsolePage(driver)
        console_data_present = page.check_for_console_dashboard_display_data()
        if console_data_present:
            page.click_on_tab(ConsolePageTabs.NEW_TICKETS)
            page.click_on_any_case_in_assigned_backlog()
            support_hub = support_hub_page.check_visibility_of_support_hub()
            if support_hub is False:
                page.click_on_assigned_this_period()
                support_hub = support_hub_page.check_visibility_of_support_hub()
                assert support_hub, "failed to display support hub"

                try:
                    case_owner_name = support_hub_page.get_agent_name()
                    support_hub_page.hover_on_element((By.XPATH, shl.case_owner_icon))
                    assert support_hub_page.check_for_agents_name_present_on_case_owner_tool_tip(case_owner_name)
                    assert support_hub_page.is_element_visible(
                        (By.XPATH, shl.case_owner_active_hours_in_tooltip.replace("TEXT_PLACE_HOLDER", case_owner_name))
                    ), "hover over case owner tooltip is not displayed "
                    support_hub_page.close_support_hub_window()
                except:
                    support_hub_page.close_support_hub_window()
                    assert False



    @regression_test
    @author_praveen_nj
    @pytestrail.case("C275")
    def test_copy_url_button(self, driver, support_hub_setup):
        commons = Commons(driver)
        support_hub = SupportHub(driver)

        case_id: str = support_hub.get_case_id()

        support_hub.copy_case_url()
        try:
            driver.execute_script("window.open();")
            driver.switch_to.window(driver.window_handles[1])
            driver.execute_script(
                "navigator.clipboard.readText().then(text => window.location.replace(text));"
            )

            commons.wait_for_loader_to_disappear()
            assert support_hub.get_case_id() == case_id
        finally:
            driver.close()
            driver.switch_to.window(driver.window_handles[0])

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C316", "C317")
    def test_add_and_remove_sentiment_acknowledgement(self, driver, support_hub_setup):
        support_hub = SupportHub(driver)

        case_id = utils.read_text_file(TestSupportHub.file_name)
        if not support_hub.is_element_visible(
            (By.CSS_SELECTOR, shl.case_sentiment_card_css), timeout=5
        ):
            raise Exception(f"No sentiments detected in {case_id}")

        support_hub.acknowledge_first_sentiment_found()
        assert "Acknowledged by" in support_hub.get_acknowledged_sentiment_button_text()
        # cleanup
        support_hub.remove_acknowledgment()

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C290")
    def test_case_share_custom_message(self, driver, support_hub_setup):
        support_hub = SupportHub(driver)

        sl_email = os.getenv("SL_USER")
        sl_email_pwd = os.getenv("EMAIL_APP_PWD")
        reason: str = utils.generate_test_run_id("share message", iterate=False)

        support_hub.share_case_via_email(sl_email, reason=reason)
        time.sleep(10)  # wait for the incoming mail to be received
        emails = utils.fetch_email_body(sl_email, sl_email_pwd)
        assert any(
            [reason in mail_body for mail_body in emails]
        ), "Reason entered while sharing case is not in email"
        utils.delete_email_by_sender_and_date_received(
            sl_email, sl_email_pwd, "noreply@mail-dev.supportlogic.io", date.today()
        )

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C305")
    @pytest.mark.skipif(
        "staging" in utils.get_app_url(), reason="tooltip cannot be verified in staging"
    )
    def test_case_priority_tooltip(self, driver, support_hub_setup):
        helpers = HelperMethods(driver)

        helpers.hover_on_element(
            (By.CSS_SELECTOR, shl.edit_case_priority_css),
            message="Failed to hover over case priority",
        )
        time.sleep(1)
        assert helpers.is_element_visible(
            (By.XPATH, shl.case_priority_tooltip)
        ), "Case Priority tooltip is not displayed"

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C294")
    def test_add_sentiment_label(self, driver, support_hub_setup):
        helpers = HelperMethods(driver)

        case_comment = driver.find_element(By.CSS_SELECTOR, shl.case_comments_text_css)
        driver.execute_script(
            "arguments[0].scrollIntoView({block: 'center'});", case_comment
        )
        helpers.actions.move_to_element(case_comment)
        helpers.actions.move_by_offset(30, 0)
        helpers.actions.click_and_hold().move_by_offset(0, 50).release().perform()

        helpers.click_on_element((By.CSS_SELECTOR, shl.add_label_button_css))
        helpers.click_on_element((By.CSS_SELECTOR, shl.add_label_list_header_css))
        helpers.click_on_element((By.CSS_SELECTOR, shl.add_label_signal_option_css))
        helpers.click_on_element((By.CSS_SELECTOR, shl.add_label_apply_button_css))
        time.sleep(1)
        assert helpers.get_element_text_or_value(
            (By.CSS_SELECTOR, shl.labelled_sentiment_css)
        ) in helpers.get_element_text_or_value(
            (By.CSS_SELECTOR, shl.case_comments_text_css)
        ).replace(
            "\n", " "
        ), "Failed to add new sentiment label"
        helpers.hover_on_element((By.CSS_SELECTOR, shl.sentiment_label_css))
        helpers.click_on_element((By.CSS_SELECTOR, shl.sentiment_label_menu_css))
        helpers.click_on_element((By.XPATH, shl.change_sentiment_label_menu_option))
        helpers.click_on_element((By.CSS_SELECTOR, shl.add_label_clear_button_css))
        helpers.click_on_element((By.CSS_SELECTOR, shl.add_label_apply_button_css))
