__author__ = "Jacob Mathew"
__copyright__ = "Copyright (C) 2021 SupportLogic"

import logging
import os
import time

import pytest
from pytest_testrail.plugin import pytestrail
from selenium.webdriver.common.by import By

import constants
from constants import (
    author_jake_mat, author_neha_jha, author_praveen_nj, regression_test, sanity_test,
)
from enums import ModuleState, NavbarItem
from locators import caseboard_locators as cbl
from locators import common_locators as cl
from pom_library import case_board_page, support_hub
from pom_library.api_keywords import ApiKeywords
from pom_library.navbar import Navbar

LOGGER: logging.Logger = logging.getLogger(__name__)


class TestCaseBoard(object):
    @pytest.fixture()
    def case_board_setup(self, driver):
        page = case_board_page.CaseBoardPage(driver)
        navbar = Navbar(driver)
        current_url = navbar.navigate_to_navbar_page(NavbarItem.CASE_BOARD)
        assert "cases" in current_url, "failed to load backlog pages"
        page.if_welcome_page_click_default_lists_set()
        yield
        navbar.navigate_to_navbar_page(NavbarItem.CUSTOMER_INSIGHTS)

    @sanity_test
    @author_jake_mat
    @pytestrail.case("C507")
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_click_case_board_menu_from_navbar(self, driver):
        """
        Test ID - TC438-1
        Test will visit the case board page
        Steps to case board visit
        1. Click on the Case board option in the Navbar
        Assertion is based on the page title
        """

        navbar = Navbar(driver)
        current_url = navbar.navigate_to_navbar_page(NavbarItem.CASE_BOARD)
        assert "cases" in current_url, "failed to load backlog pages"

    @sanity_test
    @author_jake_mat
    @pytestrail.case("C14")
    def test_add_a_case_list(self, driver, case_board_setup):
        """
        Test ID - TC438
        Test will add a case list
        Steps to adding a case list
        1. Click on the Add case list floating button
        2. Add a name to the case list
        3. Click on the next button
        4. Select a rank case by parameter
        5. Click on the Create button
        Assertion : The case list count will go up by 1
        new count = original count + 1
        """
        page = case_board_page.CaseBoardPage(driver)
        no_of_lists = page.count_case_lists_in_caseboard()
        page.click_on_add_case_list_button()
        page.add_new_name_for_list()
        page.click_next_button()
        page.select_a_random_list_choice()
        page.click_create_button()
        LOGGER.info(f"Number of lists before new one created = {no_of_lists}")
        new_no_of_lists = page.count_case_lists_in_caseboard()
        LOGGER.info(f"Number of lists after new one added = {new_no_of_lists}")
        assert new_no_of_lists == no_of_lists + 1, "New case list not creation failed. "

    @author_jake_mat
    @pytestrail.case("C94")
    def test_edit_name_of_first_case_list(self, driver, case_board_setup):
        """
        Test ID - TC453
        Test will edit the name of the first case list
        Steps to Editing the name
        1. Click on the Options(Vertical Dots) in first case list
        2. Click on the Edit option from the Dropdown
        3. Add a edit text to the already existing name
        4. Click on the apply change button
        Assertion : updated_name = original_name + edit_text
        """
        page = case_board_page.CaseBoardPage(driver)

        original_title = page.get_title_of_case_list(1)
        # Getting current title of 1st case list
        LOGGER.info(f"Original title of the case list  = {original_title}")
        edit_text = " Edited"
        page.click_options_button_on_nth_list(1)
        page.click_edit_list_button()
        page.edit_name_for_list(edit_text)
        page.click_apply_change_button_in_edit_flow()
        title_after_edit = page.get_title_of_case_list(1)
        LOGGER.info(f"Title after Edit = {title_after_edit}")
        assert (
            title_after_edit == original_title + edit_text
        ), "Name change not effected - Case list name change test failed "

    @sanity_test
    @author_jake_mat
    @pytestrail.case("C93")
    def test_delete_a_case_list(self, driver, case_board_setup):
        """
        Test ID - TC-449
        This test will delete a case list from the caseboard.
        Steps to deletion:
        1. Click on the Options(Vertical Dots) in first case list
        2. Click on the Delete option from the Dropdown
        3. Click on the DELETE button on the delete modal
        Assertion:
        case list count after deletion = original count - 1
        """
        page = case_board_page.CaseBoardPage(driver)
        case_lists_count_before_deletion = page.count_case_lists_in_caseboard()
        LOGGER.info(
            f"Total lists count before delete action = {case_lists_count_before_deletion}"
        )
        page.click_options_button_on_nth_list(1)
        page.click_delete_list_button()
        page.click_delete_in_delete_modal()
        case_lists_count_after_deletion = page.count_case_lists_in_caseboard()
        LOGGER.info(
            f"Total lists count after delete action = {case_lists_count_after_deletion}"
        )
        assert case_lists_count_after_deletion == case_lists_count_before_deletion - 1

    @sanity_test
    @author_jake_mat
    @pytestrail.case("C508")
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_custom_case_list_creation(self, driver):
        """
        Test ID - 452-1
        Custom List creation flow starts from the welcome page / empty state
        of the case board.
        Test Steps :
        1. Delete all case lists in case board.
        2. Click on Create Custom List button and create a case list.
        3. Do the steps to create a new case list
        4. Assert the case list count incremented.
        """
        page = case_board_page.CaseBoardPage(driver)
        navbar = Navbar(driver)
        current_url = navbar.navigate_to_navbar_page(NavbarItem.CASE_BOARD)
        assert "cases" in current_url, "failed to load backlog pages"
        if page.count_case_lists_in_caseboard() > 0:
            page.delete_all_case_lists_in_caseboard()
        page.custom_list_creation()
        number_of_case_lists = page.count_case_lists_in_caseboard()
        assert number_of_case_lists == 1, "Custom case list creation failed."

    @sanity_test
    @author_jake_mat
    @pytestrail.case("C524")
    def test_default_case_list_creation(self, driver, case_board_setup):
        """
        Test ID - 452
        Custom List creation flow starts from the welcome page / empty state
        of the case board.
        Test Steps :
        1. Delete all case lists in case board.
        2. Click on Create Default List button
        3. Assert all the case lists are created by validating count = 8
        """
        page = case_board_page.CaseBoardPage(driver)
        present_of_list = page.check_for_presence_of_list_on_dashboard()
        if present_of_list:
            page.delete_all_case_lists_in_caseboard()
        page.default_case_lists_creation()
        assert page.check_for_presence_of_list_on_dashboard()

    @sanity_test
    @author_jake_mat
    @pytestrail.case("C528")
    def test_support_hub_opening(self, driver, case_board_setup):
        """
        Test ID - TC-0
        Click on a random case and see if the support hub loads for that case
        """
        sh = support_hub.SupportHub(driver)
        page = case_board_page.CaseBoardPage(driver)
        page.click_on_a_case_to_open_supporthub()
        assert sh.check_visibility_of_support_hub()
        sh.close_support_hub_window()

    @author_jake_mat
    @pytestrail.case("C510")
    def test_cancelling_case_list_creation(self, driver, case_board_setup):
        """
        Test ID - TC-440
        Test cancelling of caselist creation
        Test Steps
        1. Click on add Case list button
        2. Click on CANCEL button in add case list modal
        Assert the Edit modal window is closed
        """
        page = case_board_page.CaseBoardPage(driver)
        case_lists_count = page.count_case_lists_in_caseboard()
        page.click_on_add_case_list_button()
        page.click_cancel_button()
        case_lists_count_after_click_on_cancel_button = (
            page.count_case_lists_in_caseboard()
        )
        assert (
            case_lists_count_after_click_on_cancel_button == case_lists_count
        ), " case list count is mismatched"

    @author_jake_mat
    @pytestrail.case("C2195")
    def test_cancelling_case_list_creation_after_naming(self, driver, case_board_setup):
        """
        Test ID -  TC0
        Test cancelling of caselist creation
        Test Steps
        1. Click on add Case list button
        2. Add a name to the case list
        3. Click next button
        4. Select an option from Rank Cases By
        5. Click on CANCEL button in add case list modal
        Assert the Edit modal window is closed
        """
        page = case_board_page.CaseBoardPage(driver)
        case_lists_count = page.count_case_lists_in_caseboard()
        page.click_on_add_case_list_button()
        page.add_new_name_for_list()
        page.click_next_button()
        page.select_a_random_list_choice()
        page.click_cancel_button()
        case_lists_count_after_click_on_cancel_button = (
            page.count_case_lists_in_caseboard()
        )
        assert (
            case_lists_count_after_click_on_cancel_button == case_lists_count
        ), " case list count is mismatched"

    @author_jake_mat
    @pytestrail.case("C95")
    def test_cancelling_edit_case_list(self, driver, case_board_setup):
        """
        Test ID - TC-447
        Test cancelling  Edit action
        Test Steps
        1. Click on case list options button
        2. Select Edit List option from the dropdown
        3. Add a edit text to the existing title
        4. Click cancel button
        Assert the Edit modal window is closed
        """
        page = case_board_page.CaseBoardPage(driver)
        original_title = page.get_title_of_case_list(1)
        edit_text = " Edited"
        page.click_options_button_on_nth_list(1)
        page.click_edit_list_button()
        page.edit_name_for_list(edit_text)
        page.click_cancel_button()
        title_after_cancelling = page.get_title_of_case_list(1)
        assert (
            original_title == title_after_cancelling
        ), "Cancelling edit operation failed."

    @author_jake_mat
    @pytestrail.case("C519")
    def test_cancelling_deletion(self, driver, case_board_setup):
        """
        Test ID - TC-448
        Test Cancelling Case list deletion
        Test Steps
        1. Click on case list options button
        2. Click on Delete case list from dropdown
        3. Click on the Cancel button on Delete confirmation modal
        Assert : Case list delete modal is closed.
        """
        page = case_board_page.CaseBoardPage(driver)
        page.click_options_button_on_nth_list(1)
        page.click_delete_list_button()
        page.click_cancel_button_on_delete_modal()
        assert page.check_if_delete_modal_is_closed()

    @sanity_test
    @author_jake_mat
    @pytestrail.case("C522")
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_click_case_list_expand_button(self, driver, case_board_setup):
        """
        Test ID - TC451
        Click on the case list expand view.
        Validation : The expanded modal should appear .
        """
        page = case_board_page.CaseBoardPage(driver)
        title_of_case_list = page.get_title_of_case_list(1)
        page.click_on_expand_button_on_first_case_list()
        LOGGER.info(f"Expanding case list titled {title_of_case_list}")
        assert (
            page.check_if_case_list_expanded()
        ), "Case list is not expanded upon clicking the expand view button"
        page.click_on_close_expand_view_button()
        expand_view_closed_boolean = page.check_if_expanded_case_list_closed()
        if expand_view_closed_boolean:
            assert True
        else:
            assert False, "failed to close case list expand button"

    @author_neha_jha
    @regression_test
    @pytestrail.case("C2338")
    def test_switch_sort(self, driver, case_board_setup):
        page = case_board_page.CaseBoardPage(driver)
        page.click_case_list_option_vertical_dots()
        case_id_before_switch = page.get_first_list_first_case_id()
        page.click_on_switch_sort_button()
        time.sleep(2)
        case_id_after_switch = page.get_first_list_first_case_id()
        assert (
            case_id_after_switch != case_id_before_switch
        ), "count is matching so switch is not possible"

    @author_neha_jha
    @regression_test
    @pytestrail.case("C511")
    def test_functionality_of_rank_by_list_window_pop_up(
        self, driver, case_board_setup
    ):
        page = case_board_page.CaseBoardPage(driver)
        no_of_lists = page.count_case_lists_in_caseboard()
        page.click_on_add_case_list_button()
        page.add_new_name_for_list()
        page.click_next_button()
        assert page.check_for_visibility_of_rank_cases_by_pop_up()
        page.click_on_sentiment_score_radio_button()
        page.click_on_attention_score_radio_button()
        page.click_create_button()
        LOGGER.info(f"Number of lists before new one created = {no_of_lists}")
        new_no_of_lists = page.count_case_lists_in_caseboard()
        LOGGER.info(f"Number of lists after new one added = {new_no_of_lists}")
        assert new_no_of_lists == no_of_lists + 1, "New case list not creation failed. "

    @author_neha_jha
    @regression_test
    @pytestrail.case("C521")
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_download_csv(self, driver, case_board_setup):
        page = case_board_page.CaseBoardPage(driver)
        no_of_lists = page.count_case_lists_in_caseboard()
        page.click_on_add_case_list_button()
        case_list_name = page.add_new_name_for_list()
        page.click_next_button()
        page.click_on_sentiment_score_radio_button()
        page.click_create_button()
        LOGGER.info(f"Number of lists before new one created = {no_of_lists}")
        new_no_of_lists = page.count_case_lists_in_caseboard()
        LOGGER.info(f"Number of lists after new one added = {new_no_of_lists}")
        assert new_no_of_lists == no_of_lists + 1, "New case list not creation failed. "
        page.click_case_list_option_vertical_dots()
        page.click_on_download_csv_method()
        # added time to download csv
        time.sleep(5)
        file = "case " + case_list_name
        assert os.path.exists(
            constants.report_dir + "/downloads/" + f"{file}.csv"
        ), "file is not  founded in download folder"

    @author_neha_jha
    @regression_test
    @pytestrail.case("C2193")
    def test_functionality_of_sentiments_score_in_sentiments_list(
        self, driver, case_board_setup
    ):
        page = case_board_page.CaseBoardPage(driver)
        no_of_lists = page.count_case_lists_in_caseboard()
        page.click_on_add_case_list_button()
        page.add_new_name_for_list()
        page.click_next_button()
        page.click_on_sentiment_score_radio_button()
        page.click_create_button()
        LOGGER.info(f"Number of lists before new one created = {no_of_lists}")
        new_no_of_lists = page.count_case_lists_in_caseboard()
        LOGGER.info(f"Number of lists after new one added = {new_no_of_lists}")
        assert new_no_of_lists == no_of_lists + 1, "New case list not creation failed. "
        sentiment_score = page.fetch_sentiments_score_in_sentiments_list()
        print(sentiment_score)
        sentiments_score_after_copy = sentiment_score[:]
        for i in range(len(sentiment_score)):
            for j in range(i + 1, len(sentiment_score)):
                if sentiment_score[i] >= sentiment_score[j]:
                    sentiment_score[i], sentiment_score[j] = (
                        sentiment_score[j],
                        sentiment_score[i],
                    )

        assert (
            sentiments_score_after_copy == sentiment_score
        ), "failed is sorted sentiments"

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C71")
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_module_state_disabled(self, driver):
        api_helpers = ApiKeywords(driver)
        navbar = Navbar(driver)

        try:
            api_helpers.edit_module_state({NavbarItem.CASE_BOARD: ModuleState.DISABLED})
            driver.refresh()
            assert (
                navbar.has_navbar_module(NavbarItem.CASE_BOARD) is False
            ), "Failed to disable Case Board page"
        finally:
            api_helpers.edit_module_state({NavbarItem.CASE_BOARD: ModuleState.ENABLED})
            driver.refresh()

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C72")
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_module_state_locked(self, driver):
        api_helpers = ApiKeywords(driver)
        navbar = Navbar(driver)

        try:
            api_helpers.edit_module_state({NavbarItem.CASE_BOARD: ModuleState.LOCKED})
            driver.refresh()
            assert navbar.has_navbar_module(
                NavbarItem.CASE_BOARD
            ), "Case Board page is disabled"
            navbar.navigate_to_navbar_page(NavbarItem.CASE_BOARD)
            assert navbar.is_element_visible(
                (By.CSS_SELECTOR, cl.module_locked_icon)
            ), "Lock icon is not displayed when module is locked in prod edition"
            assert navbar.is_element_visible(
                (By.CSS_SELECTOR, cl.sl_sales_contact)
            ), "No contact info is displayed when module is locked in prod edition"
        finally:
            api_helpers.edit_module_state({NavbarItem.CASE_BOARD: ModuleState.ENABLED})
            driver.refresh()

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C73")
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_module_state_enabled(self, driver):
        api_helpers = ApiKeywords(driver)
        navbar = Navbar(driver)

        api_helpers.edit_module_state({NavbarItem.CASE_BOARD: ModuleState.ENABLED})
        navbar.navigate_to_navbar_page(NavbarItem.CASE_BOARD)
        assert navbar.has_navbar_module(NavbarItem.CASE_BOARD), "Case Board page is disabled"
        assert (
            navbar.is_element_visible((By.XPATH, cbl.add_case_list_button))
        ), "Time Filter element is not displayed"
