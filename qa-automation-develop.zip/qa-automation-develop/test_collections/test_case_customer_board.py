"""Test class for customer Board page"""
__author__ = "Neha jha"
__copyright__ = "Copyright (C) 2021 SupportLogic"

import logging
import os
import pytest
import time
from datetime import date
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.wait import WebDriverWait
import constants
from constants import sanity_test, author_neha_jha,regression_test
from locators import customer_board_locator
from enums import NavbarItem, CustomerManagementTabs
from pom_library import customer_board_page, customer_management_page
from pom_library.navbar import Navbar
import utils

from pytest_testrail.plugin import pytestrail

LOGGER = logging.getLogger(__name__)


@pytest.mark.usefixtures("driver")
class TestCustomerBoard(object):
    @pytest.fixture()
    def customer_board_setup(self, driver):
        page = customer_board_page.CustomerBoardPage(driver)
        navbar = Navbar(driver)
        current_url=navbar.navigate_to_navbar_page(NavbarItem.CUSTOMER_BOARD)
        assert "customer-board" in current_url, "failed to load customer board page"
        page.check_presence_of_welcome_page()
        yield
        add_pop_up=page.check_if_add_notes_pop_up()
        if add_pop_up:
            page.click_on_cross_button_notes()
        page.delete_list()
        navbar.navigate_to_navbar_page(NavbarItem.CUSTOMER_INSIGHTS)

    # TC 01
    @sanity_test
    @author_neha_jha
    @pytestrail.case('C2196')
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_customer_page_loaded(self, driver, customer_board_setup):
        page = customer_board_page.CustomerBoardPage(driver)
        customer_board_data = page.check_list_present_customer_board()
        assert customer_board_data, "failed to loaded data"

    # TC 04
    @sanity_test
    @author_neha_jha
    @pytestrail.case('C2160')
    def test_download_csv_list(self, driver, customer_board_setup):
        page = customer_board_page.CustomerBoardPage(driver)
        list_name = page.get_list_name().replace(" ", "_")
        page.click_vertical_dots_list()
        drop_down_menu = page.check_present_drop_down_on_click_vertical_dots()
        assert drop_down_menu, "failed to display drop down menu"
        page.click_on_download_csv()

        time.sleep(5)
        assert os.path.exists(
            constants.report_dir
            + "/downloads/"
            + f"{list_name}-{date.today().strftime('%Y-%m-%d')}.csv"
        ), "failed to founded the file"

    # TC 05
    @sanity_test
    @author_neha_jha
    @pytestrail.case('C2196')
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_delete_list(self, driver, customer_board_setup):
        page = customer_board_page.CustomerBoardPage(driver)
        list_present_on_dashboard_before_delete = (
            page.get_number_of_list_present_on_dashboard()
        )
        page.click_vertical_dots_list()
        drop_down_menu = page.check_present_drop_down_on_click_vertical_dots()
        assert drop_down_menu, "failed to display drop down menu"
        page.click_on_delete_list()
        page.click_delete_button_on_delete_pop_up()
        list_present_on_dashboard_after_delete = (
            page.get_number_of_list_present_on_dashboard()
        )
        list_present_on_dashboard = list_present_on_dashboard_before_delete - 1
        assert (
            list_present_on_dashboard == list_present_on_dashboard_after_delete
        ), "failed to delete list "

    # TC 03
    @sanity_test
    @author_neha_jha
    @pytestrail.case('C79')
    def test_create_list(self, driver, customer_board_setup):
        page = customer_board_page.CustomerBoardPage(driver)
        list_present_on_dashboard_before_creating_new_list = (
            page.get_number_of_list_present_on_dashboard()
        )
        page.click_plus_button()
        choose_list_you_like_add_pop_up = page.check_present_choose_list_pop_up()
        assert (
            choose_list_you_like_add_pop_up
        ), "choose list you like to add pop up is failed to displayed "
        page.click_likely_to_be_escalated()

        list_name_CB = utils.generate_test_run_id(constants.CUSTOMER_BOARD_RUN_ID_PREFIX)
        page.create_list_name(list_name_CB)
        page.click_on_add_button()
        list_present_on_dashboard_after_creating_new_list = (
            page.get_number_of_list_present_on_dashboard()
        )
        list_present_on_dashboard = (
            list_present_on_dashboard_before_creating_new_list + 1
        )
        assert (
            list_present_on_dashboard
            == list_present_on_dashboard_after_creating_new_list
        ), "failed to create list in customer board"

    # TC 08
    @sanity_test
    @author_neha_jha
    @pytestrail.case('C2197')
    def test_expanding_list(self, driver, customer_board_setup):
        page = customer_board_page.CustomerBoardPage(driver)
        page.click_on_expand_button()
        single_list = page.check_present_single_list()
        assert single_list, "list is present on the dashboard"
        page.click_on_cross_button()

    # TC 12
    @sanity_test
    @author_neha_jha
    @pytestrail.case('C2197')
    def test_switch_sort_direction(self, driver, customer_board_setup):
        page = customer_board_page.CustomerBoardPage(driver)
        page.click_vertical_dots_list()
        drop_down_menu = page.check_present_drop_down_on_click_vertical_dots()
        assert drop_down_menu, "failed to display drop down menu"
        cases_before_switch = page.get_number_cases_present_on_customer_board_list()
        page.click_on_switch_sort_direction()
        time.sleep(1)
        cases_after_switch = page.get_number_cases_present_on_customer_board_list()
        assert cases_before_switch != cases_after_switch, "failed to switch direction"

    # TC 06
    @sanity_test
    @author_neha_jha
    @pytestrail.case('C2197')
    def test_edit_list(self, driver, customer_board_setup):
        page = customer_board_page.CustomerBoardPage(driver)
        page.create_new_list_using_Likely_to_be_Escalated()
        page.click_vertical_dots_list()
        drop_down_menu = page.check_present_drop_down_on_click_vertical_dots()
        assert drop_down_menu, "failed to display drop down menu"
        page.click_on_edit_list()
        filter_by_list_pop_up = page.check_present_filter_by_list_pop_up()
        assert filter_by_list_pop_up, "failed to display filter by list pop up"
        page.click_on_customer_field()
        page.click_on_creation_date()
        page.click_on_one_year_option_in_creation_data()
        page.click_on_filter()
        page.click_on_apply_changes()
        client_present_in_list = page.check_the_client_present_in_list()
        if client_present_in_list:
            LOGGER.info(" clients are present in the list")
        else:
            LOGGER.warning("No client present")

    # TC 02
    @sanity_test
    @author_neha_jha
    @pytestrail.case('C2197')
    def test_client_profile_customer_board(self, driver, customer_board_setup):
        page = customer_board_page.CustomerBoardPage(driver)
        customer = customer_management_page.CustomerManagementPage(driver)
        client_name = page.get_text_first_client_name_in_list()
        page.click_on_client_present_in_list()

        open_windows = driver.window_handles
        driver.switch_to.window(open_windows[1])

        profile_present_customer_insight = (
            customer.checks_for_customer_profile_displayed_or_not()
        )
        if profile_present_customer_insight:
            profile_name = customer.get_text_profile_customer()
            assert (
                client_name == profile_name
            ), "failed to match customer name and profile name"
        else:
            LOGGER.warning(f"{client_name} account is no longer exist")

        driver.close()
        driver.switch_to.window(open_windows[0])

    # TC 11

    @sanity_test
    @author_neha_jha
    def test_ticket_count_in_client_profile_and_list(
        self, driver, customer_board_setup
    ):
        page = customer_board_page.CustomerBoardPage(driver)
        customer =customer_management_page.CustomerManagementPage(driver)
        list_present_on_dashboard_before_creating_new_list = (
            page.get_number_of_list_present_on_dashboard()
        )
        page.click_plus_button()
        choose_list_you_like_add_pop_up = page.check_present_choose_list_pop_up()
        assert (
            choose_list_you_like_add_pop_up
        ), "choose list you like to add pop up is failed to displayed "
        page.click_likely_to_be_escalated()

        list_name_CB = utils.generate_test_run_id(constants.CUSTOMER_BOARD_RUN_ID_PREFIX)
        page.create_list_name(list_name_CB)
        page.click_on_add_button()
        list_present_on_dashboard_after_creating_new_list = (
            page.get_number_of_list_present_on_dashboard()
        )
        list_present_on_dashboard = (
                list_present_on_dashboard_before_creating_new_list + 1
        )
        assert (
                list_present_on_dashboard
                == list_present_on_dashboard_after_creating_new_list
        ), "failed to create list in customer board"

        client_present_in_list = page.check_the_client_present_in_list()
        if client_present_in_list:
            LOGGER.info(" clients are present in the list")
            client_name = page.get_text_first_client_name_in_list()
            likely_to_be_escalated_case_count = page.get_number_cases_present_on_customer_board_list()
            page.click_on_client_present_in_list()
            window_handles = driver.window_handles
            driver.switch_to.window(window_handles[1])
            try:

                profile_present_customer_insight = (
                    customer.checks_for_customer_profile_displayed_or_not()
                )
                if profile_present_customer_insight:
                    profile_name = customer.get_text_profile_customer()
                    assert (
                            client_name == profile_name
                    ), "failed to match customer name and profile name"
                    customer.click_on_tab(CustomerManagementTabs.ESCALATION)
                    total_cases_in_profile = (
                        page.get_likely_to_be_escalated_cases_count_in_profile()
                    )
                    assert (
                            likely_to_be_escalated_case_count in total_cases_in_profile
                    ), "failed to match cases count "

                    driver.close()
                    driver.switch_to.window(window_handles[0])
                else:
                    LOGGER.warning(f"{client_name} account is no longer exist")
                    driver.close()
                    driver.switch_to.window(window_handles[0])

            except:
                driver.close()
                driver.switch_to.window(window_handles[0])
                assert False ,"no data in customer management page and likely to be escalated case in list" \
                              " and profile is mismatch"

        else:
            LOGGER.warning("No client present")


    # TC 07
    @sanity_test
    @author_neha_jha
    @pytestrail.case('C88')
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_time_period_while_creating_list(self, driver, customer_board_setup):
        page = customer_board_page.CustomerBoardPage(driver)
        list_present_on_dashboard_before_creating_new_list = (
            page.get_number_of_list_present_on_dashboard()
        )
        page.click_plus_button()
        choose_list_you_like_add_pop_up = page.check_present_choose_list_pop_up()
        assert (
            choose_list_you_like_add_pop_up
        ), "choose list you like to add pop up is failed to displayed "
        page.click_on_production_issue()
        list_name_cb = utils.generate_test_run_id(constants.CUSTOMER_BOARD_RUN_ID_PREFIX)
        page.create_list_name(list_name_cb)
        page.click_on_time_period()
        page.click_on_last_six_month_option_in_time_period_menu()
        page.click_on_add_button()
        list_present_on_dashboard_after_creating_new_list = (
            page.get_number_of_list_present_on_dashboard()
        )
        list_present_on_dashboard = (
            list_present_on_dashboard_before_creating_new_list + 1
        )
        assert (
            list_present_on_dashboard
            == list_present_on_dashboard_after_creating_new_list
        ), "failed to create list in customer board"

    # TC 13
    @sanity_test
    @author_neha_jha
    @pytestrail.case('C2202')
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_time_period_in_list(self, driver, customer_board_setup):
        page = customer_board_page.CustomerBoardPage(driver)
        list_present_on_dashboard_before_creating_new_list = (
            page.get_number_of_list_present_on_dashboard()
        )
        page.click_plus_button()
        choose_list_you_like_add_pop_up = page.check_present_choose_list_pop_up()
        assert (
            choose_list_you_like_add_pop_up
        ), "choose list you like to add pop up is failed to displayed "
        page.click_on_client_ranked_by_case_volume()
        list_name_CB = utils.generate_test_run_id(constants.CUSTOMER_BOARD_RUN_ID_PREFIX)
        page.create_list_name(list_name_CB)
        page.click_on_add_button()
        list_present_on_dashboard_after_creating_new_list = (
            page.get_number_of_list_present_on_dashboard()
        )
        list_present_on_dashboard = (
                list_present_on_dashboard_before_creating_new_list + 1
        )
        assert (
                list_present_on_dashboard
                == list_present_on_dashboard_after_creating_new_list
        ), "failed to create list in customer board"

        page.click_on_client_showing_time_in_list()
        time_period = "last 6 months"

        page.click_on_last_six_month_option_in_time_period_menu()

        showing_client_time_after_change_last_six_month_option = (
            page.get_text_showing_time_in_list()
        )

        assert (
                time_period == showing_client_time_after_change_last_six_month_option
        ), "failed to change time period in list"
        time.sleep(1)
        page.click_on_client_showing_time_in_list()

        all_time = "all time"
        page.click_on_all_time_in_time_period_menu()

        showing_client_time_after_change_all_time_option = (
            page.get_text_showing_time_in_list()
        )
        assert (
                all_time == showing_client_time_after_change_all_time_option
        ), "failed to change time period in list"

    # # TC 09
    @sanity_test
    @author_neha_jha
    @pytestrail.case('C2203')
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_add_notes(self, driver, customer_board_setup):
        page = customer_board_page.CustomerBoardPage(driver)

        page.click_on_add_note_icon()
        number_of_notes_present_before_adding_notes = page.get_number_of_notes_present()
        page.click_on_add_a_note()
        notes = "add a notes"
        page.add_text_in_notes(notes)
        page.click_on_add_button()
        number_of_notes_present = number_of_notes_present_before_adding_notes + 1
        time.sleep(1)
        number_of_notes_present_after_adding_notes = page.get_number_of_notes_present()
        assert (
            number_of_notes_present == number_of_notes_present_after_adding_notes
        ), "failed to add notes "

    # TC 10
    @sanity_test
    @author_neha_jha
    @pytestrail.case('C2204')
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_edit_notes(self, driver, customer_board_setup):
        page = customer_board_page.CustomerBoardPage(driver)

        page.click_on_add_note_icon()
        number_of_notes_present_before_adding_notes = page.get_number_of_notes_present()
        page.click_on_add_a_note()
        notes = "add a notes"
        page.add_text_in_notes(notes)
        page.click_on_add_button()
        number_of_notes_present = number_of_notes_present_before_adding_notes + 1
        time.sleep(1)
        number_of_notes_present_after_adding_notes = page.get_number_of_notes_present()
        assert (
            number_of_notes_present == number_of_notes_present_after_adding_notes
        ), "failed to add notes "

        page.click_on_edit_icon_in_notes()
        edit_notes = "Edit "
        page.edit_text_in_notes(edit_notes)
        page.click_on_save_button_in_notes()
        self.wait = WebDriverWait(driver, 20)
        self.wait.until(
            EC.text_to_be_present_in_element(
                (By.XPATH, customer_board_locator.notes_title), text_=edit_notes
            )
        )
        note_after_edit = page.get_notes_title()
        assert edit_notes in note_after_edit, "failed to edit notes"

    # TC 10
    @sanity_test
    @author_neha_jha
    @pytestrail.case('C2205')
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_delete_notes(self, driver, customer_board_setup):
        page = customer_board_page.CustomerBoardPage(driver)
        page.click_on_add_note_icon()
        number_of_notes_present_before_adding_notes = page.get_number_of_notes_present()
        page.click_on_add_a_note()
        notes = "add a notes"
        page.add_text_in_notes(notes)
        page.click_on_add_button()
        number_of_notes_present = number_of_notes_present_before_adding_notes + 1
        time.sleep(1)
        number_of_notes_present_after_adding_notes = page.get_number_of_notes_present()
        assert (
            number_of_notes_present == number_of_notes_present_after_adding_notes
        ), "failed to add notes "
        page.click_on_delete_icon_in_notes()
        number_of_notes_present_in_list_of_notes = (
            number_of_notes_present_after_adding_notes - 1
        )
        number_of_notes_present_after_delete_notes = page.get_number_of_notes_present()
        assert (
            number_of_notes_present_after_delete_notes
            == number_of_notes_present_in_list_of_notes
        )


    @regression_test
    @author_neha_jha
    @pytestrail.case('C84')
    @pytestrail.case('C89')
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_check_for_list_accept_special_character_in_list_name(self,driver,customer_board_setup):

        page = customer_board_page.CustomerBoardPage(driver)
        list_present_on_dashboard_before_creating_new_list = (
            page.get_number_of_list_present_on_dashboard()
        )
        page.click_plus_button()
        choose_list_you_like_add_pop_up = page.check_present_choose_list_pop_up()
        assert (
            choose_list_you_like_add_pop_up
        ), "choose list you like to add pop up is failed to displayed "
        page.click_likely_to_be_escalated()

        list_name_cb = utils.generate_test_run_id(constants.CUSTOMER_BOARD_RUN_ID_PREFIX)+"@*^%"

        page.create_list_name(list_name_cb)
        page.click_on_add_button()
        list_present_on_dashboard_after_creating_new_list = (
            page.get_number_of_list_present_on_dashboard()
        )
        list_present_on_dashboard = (
                list_present_on_dashboard_before_creating_new_list + 1
        )
        assert (
                list_present_on_dashboard
                == list_present_on_dashboard_after_creating_new_list
        ), "failed to create list in customer board"

        first_list_name_on_dashboard =page.get_name_of_first_list_on_dashboard()
        assert "@*^%" in first_list_name_on_dashboard,"failed to create name with spacial character"

    @regression_test
    @author_neha_jha
    @pytestrail.case('C83')
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_check_for_list_accept_space_in_list_name(self, driver, customer_board_setup):
        page = customer_board_page.CustomerBoardPage(driver)
        list_present_on_dashboard_before_creating_new_list = (
            page.get_number_of_list_present_on_dashboard()
        )
        page.click_plus_button()
        choose_list_you_like_add_pop_up = page.check_present_choose_list_pop_up()
        assert (
            choose_list_you_like_add_pop_up
        ), "choose list you like to add pop up is failed to displayed "
        page.click_likely_to_be_escalated()
        list_name_cb = utils.generate_test_run_id(constants.CUSTOMER_BOARD_RUN_ID_PREFIX)

        list_name_with_space =list_name_cb+"        customer board"
        page.create_list_name(list_name_with_space)
        page.click_on_add_button()
        list_present_on_dashboard_after_creating_new_list = (
            page.get_number_of_list_present_on_dashboard()
        )
        list_present_on_dashboard = (
                list_present_on_dashboard_before_creating_new_list + 1
        )
        assert (
                list_present_on_dashboard
                == list_present_on_dashboard_after_creating_new_list
        ), "failed to create list in customer board"
        first_list_name_on_dashboard = page.get_name_of_first_list_on_dashboard()
        assert list_name_cb+" customer board" == first_list_name_on_dashboard

    @regression_test
    @author_neha_jha
    @pytestrail.case('C90')
    @pytestrail.case('C82')
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_check_for_list_created_with_blank_name_field(self, driver, customer_board_setup):
        page = customer_board_page.CustomerBoardPage(driver)
        list_present_on_dashboard_before_creating_new_list = (
            page.get_number_of_list_present_on_dashboard()
        )
        page.click_plus_button()
        choose_list_you_like_add_pop_up = page.check_present_choose_list_pop_up()
        assert (
            choose_list_you_like_add_pop_up
        ), "choose list you like to add pop up is failed to displayed "
        page.click_likely_to_be_escalated()
        page.click_on_add_button()
        list_present_on_dashboard_after_creating_new_list = (
            page.get_number_of_list_present_on_dashboard()
        )
        list_present_on_dashboard = (
                list_present_on_dashboard_before_creating_new_list + 1
        )
        assert (
                list_present_on_dashboard
                == list_present_on_dashboard_after_creating_new_list
        ), "failed to create list in customer board"
        first_list_name_on_dashboard = page.get_name_of_first_list_on_dashboard()
        assert " " != first_list_name_on_dashboard, "name list is blank"
        assert "likely to escalate cases" in first_list_name_on_dashboard, " mismatch default name "

    @regression_test
    @author_neha_jha
    @pytestrail.case('C87')
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_click_on_cancel_button_in_add_to_your_board(self, driver, customer_board_setup):
        page = customer_board_page.CustomerBoardPage(driver)
        list_present_on_dashboard_before_creating_new_list = (
            page.get_number_of_list_present_on_dashboard()
        )
        page.click_plus_button()
        choose_list_you_like_add_pop_up = page.check_present_choose_list_pop_up()
        assert (
            choose_list_you_like_add_pop_up
        ), "choose list you like to add pop up is failed to displayed "
        page.click_likely_to_be_escalated()
        list_name_cb = utils.generate_test_run_id(constants.CUSTOMER_BOARD_RUN_ID_PREFIX)
        page.create_list_name(list_name_cb)
        page.click_on_cancel_button()
        list_present_on_dashboard_present_on_customer_board = (
            page.get_number_of_list_present_on_dashboard()
        )
        assert (
                list_present_on_dashboard_before_creating_new_list
                == list_present_on_dashboard_present_on_customer_board
        ), "failed to mismatch count of list"

    @regression_test
    @author_neha_jha

    @pytestrail.case('C78')

    def test_functionality_of_create_custom_list(self, driver, customer_board_setup):
        page = customer_board_page.CustomerBoardPage(driver)
        number_of_list = page.get_number_of_list_present_on_dashboard()
        for i in range(number_of_list):
            page.click_vertical_dots_list()
            drop_down_menu = page.check_present_drop_down_on_click_vertical_dots()
            assert drop_down_menu, "failed to display drop down menu"
            page.click_on_delete_list()
            page.click_delete_button_on_delete_pop_up()
        page.click_on_create_custom_list_on_start_page()
        page.click_likely_to_be_escalated()
        list_name_cb = utils.generate_test_run_id(constants.CUSTOMER_BOARD_RUN_ID_PREFIX)
        page.create_list_name(list_name_cb)
        page.click_on_add_button()
        number_of_list = page.get_number_of_list_present_on_dashboard()
        assert  number_of_list == 1,"failed to create  custom list"

    @regression_test
    @author_neha_jha
    @pytestrail.case('C77')
    def test_functionality_of_standard_list(self, driver, customer_board_setup):
        page = customer_board_page.CustomerBoardPage(driver)
        number_of_list = page.get_number_of_list_present_on_dashboard()
        for i in range(number_of_list):
            page.click_vertical_dots_list()
            drop_down_menu = page.check_present_drop_down_on_click_vertical_dots()
            assert drop_down_menu, "failed to display drop down menu"
            page.click_on_delete_list()
            page.click_delete_button_on_delete_pop_up()
        page.click_on_standard_list_on_start_page()
        number_of_list = page.get_number_of_list_present_on_dashboard()
        assert number_of_list == 6, "failed to create  custom list"

    @pytestrail.case('C80')
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_functionality_of_adding_multiple_list(self, driver, customer_board_setup):
        page = customer_board_page.CustomerBoardPage(driver)
        list_present_on_dashboard_before_creating_new_list = (
            page.get_number_of_list_present_on_dashboard()
        )
        page.click_plus_button()
        choose_list_you_like_add_pop_up = page.check_present_choose_list_pop_up()
        assert (
            choose_list_you_like_add_pop_up
        ), "choose list you like to add pop up is failed to displayed "
        page.click_likely_to_be_escalated()
        list_name_cb = utils.generate_test_run_id(constants.CUSTOMER_BOARD_RUN_ID_PREFIX)
        page.create_list_name(list_name_cb)
        page.click_on_production_issue()
        list_name_cb = utils.generate_test_run_id(constants.CUSTOMER_BOARD_RUN_ID_PREFIX)
        page.create_list_name(list_name_cb)
        page.click_on_add_button()
        list_present_on_dashboard = (
            list_present_on_dashboard_before_creating_new_list + 2
                )
        list_present_on_dashboard_after_on_customer_board = (
            page.get_number_of_list_present_on_dashboard()
        )
        assert (
            list_present_on_dashboard == list_present_on_dashboard_after_on_customer_board
                ), "failed to create list in customer board"

