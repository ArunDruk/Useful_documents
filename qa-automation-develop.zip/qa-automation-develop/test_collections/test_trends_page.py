"""Test class for Operational Metrics"""
__author__ = "Praveen Nagajothi"
__copyright__ = "Copyright (C) 2021 SupportLogic"

import datetime as dt
import logging
import os
import time
from collections import Counter
from typing import List

import pytest
from pytest_testrail.plugin import pytestrail
from selenium.webdriver.common.by import By

import constants
import utils
from constants import author_praveen_nj, author_sutapa_g, sanity_test, skip_test
from enums import (
    CaseStatusFilter, NavbarItem, TrendsGroupByOptions, TrendsPageContentTabs,
)
from locators import keyword_and_trends_locators as ktl
from pom_library.commons import Commons
from pom_library.date_picker import DatePicker
from pom_library.keywords_and_trends import KeywordsAndTrends
from pom_library.navbar import Navbar
from pom_library.sentiments import Sentiments
from pom_library.support_hub import SupportHub

LOGGER = logging.getLogger(__name__)


@pytest.mark.incheck
@pytest.mark.usefixtures("driver")
class TestTrends:
    @pytest.fixture(autouse=True)
    def trends_setup(self, driver):
        navbar = Navbar(driver)
        commons = Commons(driver)
        commons.wait_for_loader_to_disappear()
        current_page_url: str = navbar.navigate_to_navbar_page(NavbarItem.TRENDS)
        assert "trends" in current_page_url, "Failed to load Keywords and Trends page"
        commons.start_module_onboarding()
        commons.wait_for_loader_to_disappear()

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C343")
    def test_graph_loading(self, driver):
        trends = KeywordsAndTrends(driver)
        date_picker = DatePicker(driver)

        # check graph is visible/loading
        trends.is_element_visible((By.CSS_SELECTOR, ktl.main_graph_plot_css))
        if date_picker.get_applied_date_filter() != "This month":
            date_picker.open_date_picker()
            date_picker.select_this_month_shortcut()
            date_picker.apply_selected_date_filter()

        trends.click_on_element(
            (By.CSS_SELECTOR, ktl.graph_previous_date_period_arrow_css)
        )
        time.sleep(2)
        previous_month: dt.date = dt.date.today().replace(day=1) - dt.timedelta(days=1)
        assert trends.validate_xaxis_date_label(previous_month.strftime("%b"))

        # Clicking next button in graph during automation loads previous month
        trends.click_on_element((By.CSS_SELECTOR, ktl.graph_next_date_period_arrow_css))
        time.sleep(2)
        assert trends.validate_xaxis_date_label(dt.date.today().strftime("%b"))

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C348")
    def test_graph_tooltip(self, driver):
        trends = KeywordsAndTrends(driver)

        trends.actions.move_to_element(
            driver.find_element(By.CSS, ktl.main_graph_plot_css)
        ).move_by_offset(100, 100).perform()
        date_when_tooltip_stable: str = trends.get_element_text_or_value(
            (By.CSS_SELECTOR, ktl.graph_tooltip_date_text_css)
        )
        trends.actions.move_to_element(
            driver.find_element(By.CSS, ktl.main_graph_plot_css)
        ).move_by_offset(100, 100).click().perform()
        assert utils.validate_values_equals(
            "Date when tooltip is stable",
            date_when_tooltip_stable,
            "Date on free moving tooltip",
            driver.find_element(By.CSS, ktl.graph_tooltip_date_text_css).text,
        )

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C321")
    def test_keyword_search(self, driver):
        trends = KeywordsAndTrends(driver)

        trends.search_using_condition("all", "he", "goo")
        search_text: List[str] = trends.get_search_box_text()
        LOGGER.info("validate search keywords are applied successful")
        assert (
            Counter(search_text) == Counter(trends.get_applied_search_keywords()),
        ), "Search keywords are incorrect or not applied"
        LOGGER.info("keyword search is valid")
        # cleanup
        driver.find_element(By.CSS, ktl.clear_search_box_css).click()
        assert trends.get_search_box_text() == [], "Searched keywords are not cleared"

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C353")
    def test_group_by(self, driver):
        trends = KeywordsAndTrends(driver)

        trends.group_by(option=TrendsGroupByOptions.STATUS)
        graph_grouped_by: str = trends.get_element_text_or_value(
            (By.CSS_SELECTOR, ktl.floating_draggable_graph_title_css),
            message="Failed to get group by value from graph floating dialog",
        ).lower()
        assert utils.validate_values_equals(
            "Group by value displayed in graph",
            graph_grouped_by,
            "Expected group by value",
            "status",
        )

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C344")
    def test_calendar_widget(self, driver):
        trends = KeywordsAndTrends(driver)
        date_picker = DatePicker(driver)

        if date_picker.get_applied_date_filter() != "Last 1 month":
            date_picker.open_date_picker()
            date_picker.select_last_n_months_shortcut(1)
            date_picker.apply_selected_date_filter()

        time.sleep(2)
        assert trends.validate_xaxis_date_label(
            format(dt.date.today().replace(day=1) - dt.timedelta(days=1), "%b")
        ), "Selected date range is not reflected in the graph"

    @sanity_test
    @author_praveen_nj
    @skip_test(reason="Overview tab is not found")
    def test_top_entities(self, driver):
        trends = KeywordsAndTrends(driver)

        trends.click_on_tab(TrendsPageContentTabs.OVERVIEW)
        time.sleep(2)
        assert trends.is_element_visible(
            (By.CSS_SELECTOR, ktl.top_entities_barchart_points_css)
        )
        trends.click_on_tab(TrendsPageContentTabs.ESCALATIONS)
        time.sleep(2)
        assert trends.is_element_visible(
            (By.CSS_SELECTOR, ktl.top_entities_barchart_points_css)
        )

        case_count_in_first_barchart_row: str = trends.get_element_text_or_value(
            (By.CSS_SELECTOR, ktl.top_entities_barchart_count_css)
        )
        trends.click_on_element(
            (By.CSS_SELECTOR, ktl.top_entities_barchart_points_css),
            message="Failed to click on barchart point in top entities",
        )
        time.sleep(2)  # wait for the charts to load
        trends.hover_on_element((By.CSS_SELECTOR, ktl.pie_chart_css))
        assert utils.validate_values_in(
            "Count in barchart row 1",
            case_count_in_first_barchart_row,
            "Count displayed in pie chart tooltip",
            trends.get_element_text_or_value(
                (By.CSS_SELECTOR, ktl.pie_chart_tooltip_css)
            ),
        )

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C2276")
    @pytest.mark.xfail(reason="Involves clicking on charts")
    def test_load_case_list_from_graph(self, driver):
        support_hub = SupportHub(driver)
        trends = KeywordsAndTrends(driver)

        trends.click_on_tab(TrendsPageContentTabs.OVERVIEW)
        time.sleep(2)
        trends.mouse_click_on_element((By.CSS_SELECTOR, ktl.pie_chart_css))
        assert trends.is_element_visible(
            (By.CSS_SELECTOR, ktl.tickets_popup_css)
        ), "Ticket popup is not displayed after click on pie chart"

        case_id: str = trends.get_element_text_or_value(
            (By.CSS_SELECTOR, ktl.ticket_id_css),
            message="Failed to get case id from card in pie chart ticket list",
        )
        trends.click_on_element((By.CSS_SELECTOR, ktl.tickets_card_in_popup_css))

        assert (
            support_hub.check_visibility_of_support_hub(),
        ), f"SupportHub for {case_id} is not displayed after clicking on ticket"
        assert utils.validate_values_equals(
            "Case id in sentiment card",
            case_id,
            "Case id in support hub",
            support_hub.get_case_id(),
        )
        support_hub.close_support_hub_window()

    @author_sutapa_g
    @pytestrail.case("C2277")
    def test_content_tabs_ticket_opens_up_in_support_hub(self, driver):
        """check if content tabs has data"""
        trends_page = KeywordsAndTrends(driver)
        support_hub_page = SupportHub(driver)
        LOGGER.setLevel(logging.INFO)
        LOGGER.info("Entering >> traverse_to_content_tabs(EnumTrends.OVERVIEW_TAB)")
        trends_page.traverse_to_content_tabs(TrendsPageContentTabs.OVERVIEW)
        time.sleep(5)
        ticket_case_id = trends_page.click_tickets_present_in_content_sentiment_tabs(
            TrendsPageContentTabs.OVERVIEW
        )
        LOGGER.info("Check the ticket in support_hub")
        if ticket_case_id != "Not in desired tab":
            support_hub_page.check_visibility_of_support_hub()
            assert utils.validate_values_equals(
                "Case id in sentiment card",
                ticket_case_id,
                "Case id in support hub",
                support_hub_page.get_case_id(),
            )
            support_hub_page.close_support_hub_window()

        LOGGER.info(
            "here the tabs are over-view or escalations-- hence checking the graph"
        )
        ticket_id = trends_page.click_on_graph_content_tabs(
            TrendsPageContentTabs.OVERVIEW
        )
        if ticket_id != "Not in desired tab":
            trends_page.click_on_element(
                (By.CSS_SELECTOR, ktl.tickets_card_in_popup_css)
            )
            support_hub_page.check_visibility_of_support_hub()
            assert utils.validate_values_equals(
                "Case id in sentiment card",
                ticket_id,
                "Case id in support hub",
                support_hub_page.get_case_id(),
            )
            support_hub_page.close_support_hub_window()

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C325", "C326", "C327")
    @pytest.mark.parametrize("status", [*CaseStatusFilter])
    def test_case_status_filter(self, driver, status):
        sentiments = Sentiments(driver)
        trends = KeywordsAndTrends(driver)

        failure_message: str = "Expected case status filter is not selected."
        assert (
            sentiments.filter_by_case_status(status) == status.value.title()
        ), failure_message
        assert (
            status.value.title()
            in driver.find_element(By.CSS_SELECTOR, ktl.graph_title_text_css).text
        )

        sentiments.filter_by_case_status(CaseStatusFilter.ALL)
        time.sleep(2)
        all_cases = trends.get_displayed_case_count().replace(",", "")
        sentiments.filter_by_case_status(CaseStatusFilter.OPEN)
        time.sleep(2)
        open_cases = trends.get_displayed_case_count().replace(",", "")
        sentiments.filter_by_case_status(CaseStatusFilter.CLOSED)
        time.sleep(2)
        closed_cases = trends.get_displayed_case_count().replace(",", "")
        if CaseStatusFilter.ALL:
            assert int(all_cases) == int(open_cases) + int(closed_cases)
        if CaseStatusFilter.OPEN:
            assert int(open_cases) == int(all_cases) - int(closed_cases)
        if CaseStatusFilter.CLOSED:
            assert int(closed_cases) == int(all_cases) - int(open_cases)

        # cleanup
        assert (
            sentiments.filter_by_case_status(CaseStatusFilter.ALL)
            == CaseStatusFilter.ALL.value.title()
        ), failure_message

    @author_praveen_nj
    @pytestrail.case("C346")
    def test_calendar_custom_date_range(self, driver):
        date_picker = DatePicker(driver)
        trends = KeywordsAndTrends(driver)

        from_date: dt.date = dt.date.today() - dt.timedelta(days=5)
        to_date: dt.date = dt.date.today()

        if (
            date_picker.get_applied_date_filter()
            == f"{from_date.strftime('%b %-d, %Y')} - {to_date.strftime('%b %-d, %Y')}"
        ):
            date_picker.open_date_picker()
            date_picker.select_this_month_shortcut()
            date_picker.apply_selected_date_filter()
        date_picker.open_date_picker()
        date_picker.select_custom_date_range(from_date, to_date)
        date_picker.apply_selected_date_filter()
        time.sleep(5)
        assert trends.validate_xaxis_date_label(from_date.strftime("%-d. %b"))
        assert trends.validate_xaxis_date_label(to_date.strftime("%-d. %b"))

    @author_praveen_nj
    @pytestrail.case("C351")
    def test_chart_export_csv(self, driver):
        trends = KeywordsAndTrends(driver)

        trends.open_graph_menu()
        trends.export_chart_as_csv()

        file_name = f"Trends_by_{trends.get_selected_group_by_value()}-{dt.date.today().strftime('%Y-%m-%d')}.csv"
        file_path = f"{constants.report_dir}/downloads/{file_name}"

        utils.wait_for_download(file_path)
        assert os.path.exists(file_path)
