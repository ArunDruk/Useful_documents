"""This is the test class for escalations page"""
__author__ = "Sutapa Ganguly, Praveen Nagajothi"

import logging
import time
from typing import List

import pytest
from pytest_testrail.plugin import pytestrail
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By

import utils
from constants import author_praveen_nj, author_sutapa_g, regression_test, sanity_test
from enums import (
    ActiveEscalationsSortOptions, EscalationRequestsSortOptions, EscalationState,
    LTESortOptions, ModuleState, NavbarItem, OpsMetricsType,
    ResolvedEscalationsSortOptions, UserType,
)
from locators import escalations_management_locators as eml, support_hub_locators as shl
from pom_library import escalations_management_page, login_page
from pom_library.api_keywords import ApiKeywords
from pom_library.commons import Commons
from pom_library.date_picker import DatePicker
from pom_library.escalations_management_page import EscalationsManagementPage
from pom_library.helper_methods import HelperMethods
from pom_library.navbar import Navbar
from pom_library.ops_metrics import OpsMetricsPage
from pom_library.support_hub import SupportHub

LOGGER = logging.getLogger(__name__)


class TestEscalations:
    @pytest.fixture
    def escalations_setup(self, driver):
        """set up the escalations page"""
        navbar = Navbar(driver)
        commons = Commons(driver)

        commons.wait_for_loader_to_disappear()
        current_page_url: str = navbar.navigate_to_navbar_page(NavbarItem.ESCALATIONS)
        assert "escalations" in current_page_url, "Failed to load Escalations page"
        commons.start_module_onboarding()

    def test_click_on_escalation_in_dashboard(self, driver):
        """click on escalation in dashboard"""
        navbar = Navbar(driver)

        current_page_url: str = navbar.navigate_to_navbar_page(NavbarItem.ESCALATIONS)
        assert (
            "escalations" in current_page_url
        ), "Failed to load Escalation Management page"

    @pytest.mark.sanity
    @author_sutapa_g
    @pytestrail.case("C2220")
    def test_page_load_sanity_check_escalations_management(
        self, driver, escalations_setup
    ):
        """1.check for all 4 escalation container present on the page"""
        escalations_page = EscalationsManagementPage(driver)
        assert escalations_page.check_for_likely_to_be_escalated_present()
        assert escalations_page.check_for_escalation_request_is_present()
        assert escalations_page.check_for_active_escalation_present_or_not()
        assert escalations_page.check_for_resolved_is_present()

    # TC191, TC192, TC184
    @pytest.mark.skip(reason="BUG AA-7435")
    @author_sutapa_g
    @pytestrail.case("C2223")
    def test_drag_drop_feature_from_active_escalations_to_resolved(self, driver):
        """This method test whether drag and drop is possible from active escalations
        column to resolved escalations"""
        try:
            LOGGER.info(
                "test_drag_drop_feature_from_active_escalations_to_resolved-- Starts"
            )
            page = escalations_management_page.EscalationsManagementPage(driver)
            # Waiting till all important elements are getting loading
            page.wait_till_the_important_elements_loads()
            LOGGER.info(page.check_if_the_active_list_is_collapsed())
            # If the list is collapsed then drag and drop will not work hence
            # checking before-hand and if collapsed clicking
            if page.check_if_the_active_list_is_collapsed() is False:
                page.click_on_collapsed_active_list_to_expand()
            page.move_to_resolved_col()
            if page.check_if_the_resolved_list_is_collapsed() is False:
                page.click_on_collapsed_resolved_list_to_expand()
            col_count_active_escalations_num = (
                page.get_the_list_of_active_escalations_column()[0]
            )
            # The DnD will work only when calendar is set to 'Right Now' and atleast
            # one ticket should be present in the list
            calendar_option = page.calendar_selection_return_text()
            LOGGER.info(calendar_option)
            if (
                int(col_count_active_escalations_num) > 0
                and calendar_option.lower() == "right now"
            ):
                # Checking the drag and drop functionality from active column to
                # resolved column
                ticket_list = page.get_the_list_of_active_escalations_column()
                print(ticket_list)
                list_resolved_col_1 = page.get_the_list_of_resolved_escalations_column()
                list_new = []
                for item in ticket_list:
                    if item.isnumeric():
                        # TODO: This code will change for each instance as ticket id
                        #  will be different
                        if len(item) == 6 or len(item) == 5:
                            list_new.append(item)

                page.perform_the_functionality_of_drag_and_drop_with_first_case_active_escalations_to_resolved(
                    list_new[0]
                )
                page.move_to_resolved_col()
                time.sleep(5)
                list_resolved_col_2 = page.get_the_list_of_resolved_escalations_column()
                LOGGER.info(list_resolved_col_2[0])
                if int(list_resolved_col_2[0]) == int(list_resolved_col_1[0]) + 1:
                    assert True
                else:
                    assert False
            else:
                LOGGER.warning("There is no case for DnD - Please check")
                assert True
        except IndexError:
            LOGGER.info("No data in active escalation column or resolved column")
            assert False

    @author_sutapa_g
    @pytestrail.case("C2224")
    # TODO: This test should not be here
    def test_user_type(self, driver):
        """Check the user type"""
        page_login = login_page.LoginPage(driver)
        user_id = page_login.identify_current_user_type()
        LOGGER.info(user_id)
        # Recheck that the values returned is correct in test class collection
        if user_id is UserType.ADMIN:
            print("Admin user")
        elif user_id is UserType.NORMAL:
            print("Normal user")
        elif user_id is UserType.SL_ADMIN:
            print(" SL Admin user ")
        else:
            print("Not set")
            assert False

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C2225")
    def test_active_escalations_count_against_ops_metrics(
        self, driver, escalations_setup
    ):
        navbar = Navbar(driver)
        commons = Commons(driver)
        date_picker = DatePicker(driver)
        ops_metrics = OpsMetricsPage(driver)
        escalations_page = EscalationsManagementPage(driver)

        escalations_page.switch_to_board_view()
        active_escalations_count = int(
            escalations_page.get_escalation_count_from_column_header(
                EscalationState.ACTIVE_ESCALATIONS
            )
        )
        expected_active_escalations: List[int] = list(
            range(active_escalations_count - 150, active_escalations_count + 150)
        )

        current_page_url: str = navbar.navigate_to_navbar_page(NavbarItem.OPS_METRICS)
        assert "metrics" in current_page_url, "Failed to load Ops Metrics page"
        commons.start_module_onboarding()

        if date_picker.get_applied_date_filter() != "This month":
            date_picker.open_date_picker()
            date_picker.select_this_month_shortcut()
            date_picker.apply_selected_date_filter()

        ops_metrics.navigate_to_section_card(OpsMetricsType.EFFICIENCY)
        assert "Efficiency" in ops_metrics.get_current_section_name()

        ops_metrics_escalations_count: str = (
            ops_metrics.get_active_escalation_count().replace(",", "")
        )
        ops_metrics.go_to_overview_page()

        # Asserting against range of values as a workaround for
        # https://app.clickup.com/t/2277599/ENG-9286?comment=38777620
        assert utils.validate_values_in(
            "Active escalations in Ops Metrics - Efficiency",
            ops_metrics_escalations_count,
            "Active escalations (active + today) in IEM",
            [str(val) for val in expected_active_escalations],
        )

    @sanity_test
    @author_sutapa_g
    @pytestrail.case("C2226")
    @pytest.mark.skipif(
        "qa-automation" in utils.get_app_url(), reason="no calendar is present in qa"
    )
    def test_calendar_sanity_checks(self, driver, escalations_setup):
        """Checks the calendar"""
        escalation_page = escalations_management_page.EscalationsManagementPage(driver)
        LOGGER.info("Checking if calendar icon is visible or not")
        assert escalation_page.check_if_date_picker_is_visible()
        escalation_page.click_on_calendar_icon()
        LOGGER.info("Checking the popup is visible for shortcuts or date selections")
        assert escalation_page.check_calendar_popup_modal_is_visible()

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C231")
    def test_enable_disable_escalations_module(self, driver):
        navbar = Navbar(driver)
        api_helpers = ApiKeywords(driver)

        try:
            api_helpers.edit_module_state(
                {NavbarItem.ESCALATIONS: ModuleState.DISABLED}
            )
            driver.refresh()
            assert (
                navbar.has_navbar_module(NavbarItem.ESCALATIONS) is False
            ), "Failed to disable Escalations page"
        finally:
            api_helpers.edit_module_state({NavbarItem.ESCALATIONS: ModuleState.ENABLED})

        driver.refresh()
        navbar.navigate_to_navbar_page(NavbarItem.ESCALATIONS)
        assert navbar.has_navbar_module(
            NavbarItem.ESCALATIONS
        ), "Escalations page is disabled"
        assert navbar.is_element_visible(
            (By.CSS_SELECTOR, eml.board_view_layout_switcher_css)
        ), "View switcher element is not displayed"

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C258")
    def test_escalation_notes_data_flow(self, driver, escalations_setup):
        commons = Commons(driver)
        helpers = HelperMethods(driver)
        support_hub = SupportHub(driver)
        escalations = EscalationsManagementPage(driver)

        note = utils.generate_test_run_id("Note from escalations page", iterate=False)

        escalations.switch_to_board_view()
        count_in_header: str = escalations.get_escalation_count_from_column_header(
            EscalationState.ACTIVE_ESCALATIONS
        )
        if count_in_header == "0":
            raise Exception("No escalated cases found")

        case_id: str = escalations.get_case_id_from_first_case_card(
            EscalationState.ACTIVE_ESCALATIONS
        )
        escalations.expand_board_view(EscalationState.ACTIVE_ESCALATIONS)
        escalations.click_first_active_escalation_case_note_button()
        escalations.enter_note_in_first_active_escalation_case(note)

        support_hub.wait_for_new_escalation_note_to_be_added(note)
        assert utils.validate_values_equals(
            "Last added escalation note",
            support_hub.get_escalation_note_text(),
            "Expected escalation note",
            note,
        ), "Last added escalation note not same as expected"

        try:
            commons.search_globally_for(case_id)
            helpers.click_on_element(
                (By.CSS_SELECTOR, shl.add_escalation_note_button_css)
            )
            assert utils.validate_values_equals(
                "Last added escalation note",
                support_hub.get_escalation_note_text(),
                "Expected escalation note",
                note,
            ), "Last added escalation note not same as expected"
        finally:
            support_hub.close_support_hub_window()

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C2319")
    def test_list_view_add_a_field_button_tooltip_and_functionality(
        self, driver, escalations_setup
    ):
        helpers = HelperMethods(driver)
        api_helpers = ApiKeywords(driver)
        escalations = EscalationsManagementPage(driver)

        try:
            fields_enabled_in_escalations_settings: list[
                str
            ] = api_helpers.get_active_escalations_case_fields()

            escalations.switch_to_list_view()
            assert helpers.is_element_visible(
                (By.CSS_SELECTOR, eml.add_field_plus_button_css)
            ), "Add a field button is not visible"
            helpers.hover_on_element((By.CSS_SELECTOR, eml.add_field_plus_button_css))
            assert helpers.is_element_visible(
                (By.XPATH, eml.add_field_plus_button_tooltip)
            ), "Add a field button tooltip is not visible"

            escalations.click_add_field_plus_button()
            displayed_fields = escalations.get_field_names_from_add_field_popover()
            assert any(
                [
                    field in fields_enabled_in_escalations_settings
                    for field in displayed_fields
                ]
            ), "The fields enabled in settings are not present in add field popup"

            field_to_select = displayed_fields[0]
            escalations.select_fields_in_add_field_popover(field_to_select)
            assert (
                field_to_select in escalations.get_list_view_column_names()
            ), f"list view columns not updated with the newly added field {field_to_select}"

            escalations.deselect_fields_in_add_field_popover(field_to_select)
            assert (
                field_to_select not in escalations.get_list_view_column_names()
            ), f"failed to deselect newly added list view field {field_to_select}"
            escalations.click_add_field_plus_button()
        finally:
            # cleanup
            escalations.switch_to_board_view()

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C3786")
    def test_list_view_add_a_field_button_visibility(self, driver, escalations_setup):
        helpers = HelperMethods(driver)
        escalations = EscalationsManagementPage(driver)

        try:
            escalations.switch_to_list_view()
            assert helpers.is_element_visible(
                (By.CSS_SELECTOR, eml.add_field_plus_button_css)
            ), "Add a field button is not visible"
            escalations.click_add_field_plus_button()
            displayed_fields = escalations.get_field_names_from_add_field_popover()

            fields_to_select: list[str] = displayed_fields[:-1]  # excludes last item
            escalations.select_fields_in_add_field_popover(fields_to_select)
            assert all(
                [
                    field in escalations.get_list_view_column_names()
                    for field in fields_to_select
                ]
            ), f"list view columns not updated with the newly added fields {fields_to_select}"

            escalations.select_fields_in_add_field_popover(displayed_fields[-1])
            assert displayed_fields[-1] in escalations.get_list_view_column_names()

            escalations.deselect_fields_in_add_field_popover(displayed_fields)
            assert all(
                [
                    field not in escalations.get_list_view_column_names()
                    for field in fields_to_select
                ]
            ), f"failed to deselect newly added list view fields {fields_to_select}"
        finally:
            # cleanup
            escalations.switch_to_board_view()

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C2334")
    def test_escalation_request_decline_functionality(self, driver, escalations_setup):
        helpers = HelperMethods(driver)
        escalations = EscalationsManagementPage(driver)

        escalations.switch_to_board_view()
        count_in_header: str = escalations.get_escalation_count_from_column_header(
            EscalationState.ESCALATION_REQUESTS
        )
        if count_in_header == "0":
            raise Exception("No escalation requests found")

        case_id: str = escalations.get_case_id_from_first_case_card(
            EscalationState.ESCALATION_REQUESTS
        )

        escalations.expand_board_view(EscalationState.ESCALATION_REQUESTS)
        escalations.decline_first_escalation_request_case()

        esc_req_case_card = eml.escalations_case_card_with_id_css.format(
            state=EscalationState.ESCALATION_REQUESTS.value, id=case_id
        )
        actual_text = helpers.get_element_text_or_value(
            (By.CSS_SELECTOR, esc_req_case_card)
        )
        assert (
            case_id in actual_text and "Predictions disagreed" in actual_text
        ), f"Failed to move {case_id} from escalation requests to disagreed column"

        escalations.expand_board_view(EscalationState.DISMISSED)
        dismissed_case_card = eml.escalations_case_card_with_id_css.format(
            state=EscalationState.DISMISSED.value, id=case_id
        )
        assert helpers.is_element_visible((By.CSS_SELECTOR, dismissed_case_card))
        # TODO: Should try to handle this via API in the future
        try:
            escalations.undo_snoozed_declined_accepted_cases(
                EscalationState.DISMISSED, case_id
            )
        except TimeoutException:
            pass

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C253", "C254", "C256", "C257")
    @pytest.mark.skipif("staging" in utils.get_app_url(), reason="Priority values are different in staging & difficult to sort")
    @pytest.mark.xfail(reason="https://app.clickup.com/t/2277599/AA-20587")
    @pytest.mark.parametrize(
        "state, options",
        [
            (EscalationState.LTE, LTESortOptions),
            (EscalationState.ESCALATION_REQUESTS, EscalationRequestsSortOptions),
            (EscalationState.ACTIVE_ESCALATIONS, ActiveEscalationsSortOptions),
            (EscalationState.RESOLVED, ResolvedEscalationsSortOptions),
        ],
    )
    def test_escalations_queue_sort(self, driver, escalations_setup, state, options):
        date_picker = DatePicker(driver)
        escalations = EscalationsManagementPage(driver)
        verifications = {
            "OLDEST_CASE": escalations.verify_sort_by_oldest_case,
            "LOWEST_SENTIMENT": escalations.verify_sort_by_lowest_sentiment,
            "HIGHEST_ATTENTION": escalations.verify_sort_by_highest_attention,
            "HIGHEST_PRIORITY": escalations.verify_sort_by_highest_priority,
            "MOST_RECENT_RESPONSE": escalations.verify_sort_by_most_recent_response,
            "MOST_LTE": escalations.verify_sort_by_most_lte,
            "MOST_RECENT_REQUEST": escalations.verify_sort_by_most_recent_request,
            "MOST_RECENT_ESCALATION": escalations.verify_sort_by_most_recent_escalation,
            "CLOSED_DATE": escalations.verify_sort_by_closed_date,
        }

        if escalations.get_escalation_count_from_column_header(state) in ["0", ""]:
            raise Exception(f"No cases in {state.name} column")
        if (
            date_picker.is_date_picker_visible()
            and date_picker.get_applied_date_filter() != "Right now"
        ):
            date_picker.open_date_picker()
            date_picker.select_right_now_shortcut()
            date_picker.apply_selected_date_filter()
        escalations.expand_board_view(state)
        for option in options:
            time.sleep(2)
            escalations.sort_by(state, option)
            assert option.value in escalations.get_current_sort_by_value(state)
            assert verifications[option.name](state)
