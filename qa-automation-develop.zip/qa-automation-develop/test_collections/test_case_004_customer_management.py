"""This is the test class for customer management page"""
__author__ = "Neha Jha"
__copyright__ = "Copyright (C) 2021 SupportLogic"

import logging
import os
import time
from datetime import date

import pytest

from selenium.webdriver.common.by import By

import utils

import constants
import utils
from locators import customer_management_locator
from pom_library import virtual_accounts_page
from constants import author_neha_jha, sanity_test,regression_test
from enums import CustomerManagementTabs, NavbarItem
from pom_library import agent_management_page, customer_management_page,commons,date_picker,customer_board_page
from pom_library.navbar import Navbar
from pom_library.support_hub import SupportHub

from pytest_testrail.plugin import pytestrail

LOGGER = logging.getLogger(__name__)


@pytest.mark.usefixtures("driver")
class TestCustomerManagement(object):
    @pytest.fixture()
    def customer_setup(self, driver):

        common_page =commons.Commons(driver)
        navbar = Navbar(driver)
        current_url = navbar.navigate_to_navbar_page(NavbarItem.CUSTOMER_INSIGHTS)
        assert "customer-insights" in current_url, "failed to load customer board page"
        common_page.start_module_onboarding()
        yield
        support_hub = SupportHub(driver)
        try:
            support_hub.close_support_hub_window()
        except:
            LOGGER.info("support HUB is not displayed")
        navbar.navigate_to_navbar_page(NavbarItem.FAVORITES)

    @sanity_test
    @author_neha_jha
    @pytestrail.case('C2218')
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_search_result(self, driver, customer_setup):
        customers = customer_management_page.CustomerManagementPage(driver)
        customers.search_customers(customer_name="le")
        result = customers.check_search_result()
        assert result, "failed to  load search data"

    @sanity_test
    @author_neha_jha
    @pytestrail.case('C484')
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_search_agents(self, driver, customer_setup):
        support_hub = SupportHub(driver)
        agents = agent_management_page.AgentsPage(driver)
        page = customer_management_page.CustomerManagementPage(driver)
        page.search_customers(customer_name="le")
        result = customers.check_search_result()
        assert result, "failed to  load search data"
        customers_search_result = page.check_if_agents_present_search_result()
        assert agents_search_result, "No Client is founded"
        agents_name = page.get_text_search_result()
        agents.click_agents_search_result()
        customer_profile = page.checks_for_customer_profile_displayed_or_not()
        if customer_profile:
            profile_agent_name = page.get_text_profile_customer()
            assert (
               profile_agent_name in agents_name
            ), "search agents name is not match with profile agents name"
            page.click_on_tab(CustomerManagementTabs.OVERVIEW)
            cases_count = page.get_case_count_on_tabs(CustomerManagementTabs.OVERVIEW)
            if cases_count != "0":
                page.click_open_tab_in_overview()
                open_case = page.check_present_cases_open_tab()
                if open_case is False:
                    page.click_recently_closed_tab()
                    assert page.check_present_cases_recently_closed_tab()

                assert support_hub.check_visibility_of_support_hub(), "failed to display support hub"
            else:
                LOGGER.warning("zero cases in overview ,no data present")
                assert False
        else:
            LOGGER.warning("customer profile have no data")
            assert False

    @sanity_test
    @author_neha_jha
    @pytestrail.case('C2219')
    def test_search_for_virtual_account_or_group(self, driver, customer_setup):
        support_hub = SupportHub(driver)
        agents = agent_management_page.AgentsPage(driver)
        virtual_account = virtual_accounts_page.VirtualAccountsPage(driver)
        page = customer_management_page.CustomerManagementPage(driver)
        navbar = Navbar(driver)
        current_url = navbar.navigate_to_navbar_page(NavbarItem.VIRTUAL_ACCOUNTS)
        assert "virtual-accounts" in current_url, "failed to  load virtual account page"
        global first_virtual_group_name
        first_virtual_group_name = virtual_account.get_virtual_group_name()
        current_url = navbar.navigate_to_navbar_page(NavbarItem.CUSTOMER_INSIGHTS)
        page.search_customers(customer_name=first_virtual_group_name)
        result = page.check_search_result()
        assert result, "failed to  load search data"
        page.click_individual_accounts()
        page.click_individual_reporter()
        agents_search_result =  page.check_if_agents_present_search_result()
        if agents_search_result:
            agents_name = page.get_text_search_result()
            agents.click_agents_search_result()
            customer_profile = page.checks_for_customer_profile_displayed_or_not()
            if customer_profile:
                profile_agent_name = page.get_text_profile_customer()
                assert (
                    agents_name == profile_agent_name
                ), "search agents name not match with profile agents name"
                page.click_on_tab(CustomerManagementTabs.OVERVIEW)
                cases_count = page.get_case_count_on_tabs(CustomerManagementTabs.OVERVIEW)
                if cases_count != "0":
                    page.click_open_tab_in_overview()
                    open_case = page.check_present_cases_open_tab()
                    if open_case is False:
                        page.click_recently_closed_tab()
                        assert page.check_present_cases_recently_closed_tab()
                    assert open_case, "No cases in open and recently close tabs cases"
                    assert support_hub.check_visibility_of_support_hub(),"failed to display support hub"
                else:
                    LOGGER.warning("no cases in overview tab")
                    assert False
            else:
                LOGGER.warning("customer profile have no data")
                assert False

        else:
            LOGGER.warning("No search data related to this agents name please try to search different agent name")
            assert False

    @sanity_test
    @author_neha_jha
    @pytestrail.case('C462')
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_add_favorites(self, driver, customer_setup):
        support_hub = SupportHub(driver)
        agents = agent_management_page.AgentsPage(driver)
        customer = customer_management_page.CustomerManagementPage(driver)
        customer.search_customers(customer_name="le")
        result = customer.check_search_result()
        assert result, "failed to  load search data"
        customers_search_result = customer.check_if_agents_present_search_result()
        assert customers_search_result, "No Client is founded"
        customers_name = customer.get_text_search_result()
        agents.click_agents_search_result()
        customer_profile = customer.checks_for_customer_profile_displayed_or_not()
        if customer_profile:
            profile_agent_name = customer.get_text_profile_customer()

            assert (
                  profile_agent_name in customers_name
            ), "search agents name not match with profile agents"
            favorites_agents = customer.validate_profile_added_favorites()
            if favorites_agents:
                LOGGER.warning(f"{customers_name}  is already added to the favorites")
                # This method helps to click on the fav start icon which will added or remove favorites
                customer.click_add_favorites()
                assert customer.validate_profile_added_favorites() is False,f"{customers_name} is not removed from fav list"


            navbar = Navbar(driver)
            customer.click_add_favorites() # clicking on add fav button
            common_page = commons.Commons(driver)
            navbar.navigate_to_navbar_page(NavbarItem.FAVORITES)
            common_page.start_module_onboarding()


            customer.click_favorites_agents_profile(profile_agent_name )

            profile_agent_name = customer.get_text_profile_customer()
            assert profile_agent_name in customers_name, f"failed to add {customers_name} name to the fav list"
            navbar.navigate_to_navbar_page(NavbarItem.CUSTOMER_BOARD)

        else:
            LOGGER.warning("customer profile have no data")
            assert False

    @regression_test
    @author_neha_jha
    @pytestrail.case('C471')
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_calendar_widget_apply_button(self, driver, customer_setup):
        support_hub = SupportHub(driver)
        agents = agent_management_page.AgentsPage(driver)
        page = customer_management_page.CustomerManagementPage(driver)
        page.search_customers(customer_name="l")
        result = customers.check_search_result()
        assert result, "failed to  load search data"
        customers_search_result = page.check_if_agents_present_search_result()
        assert agents_search_result, "No Client is founded"
        customer_name = page.get_text_search_result()
        agents.click_agents_search_result()
        customer_profile = page.checks_for_customer_profile_displayed_or_not()
        if customer_profile:
            customer_name_in_customer_insight_page = page.get_text_profile_customer()
            assert (
                    customer_name_in_customer_insight_page in customer_name
            ), "customer name in search result and customer insight page is not same "
            filter_applied_on_calendar = date_pickers.get_applied_date_filter()
            LOGGER.info(f"filter applied on calendar is {filter_applied_on_calendar}")
            date_pickers.open_date_picker()
            if filter_applied_on_calendar != "Year to date":
                date_pickers.select_year_to_date_shortcut()
                date_pickers.apply_selected_date_filter()
                assert (
                        date_pickers.get_applied_date_filter() == "Year to date"
                ), "failed to select year to date"
            elif filter_applied_on_calendar != "This month":

                date_pickers.select_this_month_shortcut()
                date_pickers.apply_selected_date_filter()
                assert (
                        date_pickers.get_applied_date_filter() == "This month"
                ), "fail to select this month"
        else:
           LOGGER.warning(f"We were unable to find any case for this customer -{customer_name} ")
           assert False

    @regression_test
    @author_neha_jha
    @pytestrail.case('C472')
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_calendar_widget_cancel_button(self, driver, customer_setup):
        support_hub = SupportHub(driver)
        agents = agent_management_page.AgentsPage(driver)
        page = customer_management_page.CustomerManagementPage(driver)
        page.search_customers(customer_name=first_virtual_group_name)
        result = customers.check_search_result()
        assert result, "failed to  load search data"
        customers_search_result = page.check_if_agents_present_search_result()
        assert agents_search_result, "No Client is founded"
        customer_name = page.get_text_search_result()
        agents.click_agents_search_result()
        customer_profile = page.checks_for_customer_profile_displayed_or_not()
        if customer_profile:
            customer_name_in_customer_insight_page = page.get_text_profile_customer()
            assert (
                    customer_name_in_customer_insight_page in customer_name
            ), "customer name in search result and customer insight page is not same "
            filter_applied_on_calendar = date_pickers.get_applied_date_filter()
            LOGGER.info(f"filter applied on calendar is {filter_applied_on_calendar}")
            date_pickers.open_date_picker()
            if filter_applied_on_calendar != "Year to date":
                date_pickers.select_year_to_date_shortcut()
                date_pickers.cancel_date_filter_selection()
                assert (
                        date_pickers.get_applied_date_filter() == filter_applied_on_calendar
                ), "failed to select year to date"
            elif filter_applied_on_calendar != "This month":

                date_pickers.select_this_month_shortcut()
                date_pickers.cancel_date_filter_selection()
                assert (
                        date_pickers.get_applied_date_filter() == filter_applied_on_calendar
                ), "fail to select this month"
        else:
            LOGGER.warning(f"We were unable to find any case for this customer -{customer_name} ")
            assert False

    @regression_test
    @author_neha_jha
    @pytestrail.case('C461')
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_recent_search_customer_insight(self, driver, customer_setup):
        """
        1.search the customer in search box
        2.checking for search box is displayed if search result displayed check of present of customer in search result
        3.fetching text of first customer in the search result
        4. click on first customer and check for customer profile is display
        5. click on  fav in nav bar then click on insight in nav bar
        6. click on recently search from customer insight page

        """
        support_hub = SupportHub(driver)
        agents = agent_management_page.AgentsPage(driver)
        page = customer_management_page.CustomerManagementPage(driver)
        page.search_customers(customer_name="le")
        result = customers.check_search_result()
        assert result, "failed to  load search data"
        customers_search_result = page.check_if_agents_present_search_result()
        assert agents_search_result, "No Client is founded"
        customer_name = page.get_text_search_result()
        agents.click_agents_search_result()
        customer_profile = page.checks_for_customer_profile_displayed_or_not()
        if customer_profile:
            customer_name_in_customer_insight_page = page.get_text_profile_customer()
            assert (
                    customer_name_in_customer_insight_page in customer_name
            ), "customer name in search result and customer insight page is not same "
            navbar.navigate_to_navbar_page(NavbarItem.FAVORITES)
            current_url = navbar.navigate_to_navbar_page(NavbarItem.CUSTOMER_INSIGHTS)
            assert "customer-insights" in current_url, "failed to load customer board page"

            # Recently search customer name
            page.click_on_recently_search_customer_name()
            customer_profile = page.checks_for_customer_profile_displayed_or_not()
            if customer_profile:
                customer_name_in_customer_insight_page_on_recently_search = page.get_text_profile_customer()
                assert (
                        customer_name_in_customer_insight_page_on_recently_search in customer_name
                ), "customer name in recently search and customer  name is same "

        else:
            LOGGER.warning(f"We were unable to find any case for this customer -{customer_name} ")
            assert False
    @regression_test
    @author_neha_jha
    @pytestrail.case('C457')
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_add_notes_customer_insight_page(self,driver,customer_setup):
        support_hub = SupportHub(driver)
        agents = agent_management_page.AgentsPage(driver)
        page = customer_management_page.CustomerManagementPage(driver)
        page.search_customers(customer_name="le")
        result = customers.check_search_result()
        assert result, "failed to  load search data"
        customers_search_result = page.check_if_agents_present_search_result()
        assert agents_search_result, "No Client is founded"
        customer_name = page.get_text_search_result()
        agents.click_agents_search_result()
        customer_profile = page.checks_for_customer_profile_displayed_or_not()
        if customer_profile:
            customer_name_in_customer_insight_page = page.get_text_profile_customer()
            assert (
                    customer_name_in_customer_insight_page in customer_name
            ), "customer name in search result and customer insight page is not same "
        time.sleep(2)
        count_of_customer_notes_present_insight = page.get_number_of_notes_count_in_customer_insight()

        count_before_adding_notes = count_of_customer_notes_present_insight.replace("("," ").replace(")"," ")
        LOGGER.info(f"before adding notes count is -{count_before_adding_notes}")
        notes = "Add a notes"
        page.add_customer_notes_in_customer_insight_page(notes)
        customer_board.click_on_add_button()
        count_should_be_after_adding_notes = int(count_before_adding_notes) + 1
        time.sleep(2)
        count_of_customer_notes_after_adding_notes = page.get_number_of_notes_count_in_customer_insight()
        count_after_adding_notes = count_of_customer_notes_after_adding_notes.replace("(","").replace(")","")
        assert count_should_be_after_adding_notes == int(count_after_adding_notes)," notes count mis match after" \
                                                                              " and before adding the notes "
    @regression_test
    @author_neha_jha
    @pytestrail.case('C463')
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_remove_favorites(self, driver, customer_setup):
        support_hub = SupportHub(driver)
        agents = agent_management_page.AgentsPage(driver)
        page = customer_management_page.CustomerManagementPage(driver)
        page.search_customers(customer_name="le")
        result = customers.check_search_result()
        assert result, "failed to  load search data"
        customers_search_result = page.check_if_agents_present_search_result()
        assert agents_search_result, "No Client is founded"
        agents_name = page.get_text_search_result()
        agents.click_agents_search_result()
        customer_profile = page.checks_for_customer_profile_displayed_or_not()
        if customer_profile:
            profile_agent_name = page.get_text_profile_customer()
            assert (
                    profile_agent_name in agents_name
            ), "search agents name not match with profile agents"
            favorites_agents = page.validate_profile_added_favorites()
            if favorites_agents:
                LOGGER.warning(f"{agents_name}  is already added to the favorites")
                # This method helps to click on the fav start icon which will added or remove favorites
                page.click_add_favorites()
                assert page.validate_profile_added_favorites() is False, f"failed to click on start icon in customer profile"
            else:
                LOGGER.info(f"{agents_name} is not added in the fav list")
                # This method helps to added in favorites list
                page.click_add_favorites()
                assert page.validate_profile_added_favorites(), "failed to click on start icon"
                page.click_add_favorites()
                assert page.validate_profile_added_favorites() is False, "failed to click on start icon"
            navbar = Navbar(driver)
            common_page = commons.Commons(driver)
            navbar.navigate_to_navbar_page(NavbarItem.FAVORITES)
            common_page.start_module_onboarding()
            time.sleep(5)
            assert page.checks_for_customer_is_present_in_fav_list(agents_name) is False, f"failed to remove " \
                                                                                          f"{agents_name} from fav list"
        else:
            LOGGER.warning(f"{agents_name} in the customer insight have  no data ")

    @regression_test
    @author_neha_jha
    @pytestrail.case('C460')
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_customer_profile_in_customer_insight(self, driver, customer_setup):
        support_hub = SupportHub(driver)
        agents = agent_management_page.AgentsPage(driver)
        page = customer_management_page.CustomerManagementPage(driver)
        page.search_customers(customer_name="le")
        result = customers.check_search_result()
        assert result, "failed to  load search data"
        customers_search_result = page.check_if_agents_present_search_result()
        assert agents_search_result, "No Client is founded"
        agents_name = page.get_text_search_result()
        agents.click_agents_search_result()
        customer_profile = page.checks_for_customer_profile_displayed_or_not()
        if customer_profile:
            profile_agent_name = page.get_text_profile_customer()
            assert (
                    profile_agent_name in agents_name
            ), "search agents name is not match with profile agents name"

            assert page.checks_for_customer_profile_have_fav_button_or_not()
            assert page.checks_for_add_notes_text_box_displayed_or_not_in_customer_profile()
        else:
            LOGGER.warning(f"{agents_name} in the customer insight have  no data ")

    @regression_test
    @author_neha_jha
    @pytestrail.case('C473')
    def test_customer_page_overview_tab(self, driver, customer_setup):
        support_hub = SupportHub(driver)
        agents = agent_management_page.AgentsPage(driver)
        page = customer_management_page.CustomerManagementPage(driver)
        page.search_customers(customer_name="le")
        result = customers.check_search_result()
        assert result, "failed to  load search data"
        customers_search_result = page.check_if_agents_present_search_result()
        assert agents_search_result, "No Client is founded"
        agents_name = page.get_text_search_result()
        agents.click_agents_search_result()
        customer_profile = page.checks_for_customer_profile_displayed_or_not()
        if customer_profile:
            profile_agent_name = page.get_text_profile_customer()
            assert (
                   profile_agent_name in agents_name
                ), "search agents name is not match with profile agents name"
        page.click_on_tab(CustomerManagementTabs.OVERVIEW)
        assert page.check_present_of_open_tab_in_overview_tab(),"open tab is not present in overview section "
        assert page.check_present_of_recently_close_tab_in_overview_tab(),"recently closed tab is not present in overview section"
        assert page.check_present_of_recent_cases_in_overview_tab(),"recent case is not present in overview section"

    @regression_test
    @author_neha_jha
    @pytestrail.case('C473')
    def test_functionality_of_opening_support_hub_in_fav_module(self, driver, customer_setup):
        navbar = Navbar(driver)
        support_hub = SupportHub(driver)
        page = customer_management_page.CustomerManagementPage(driver)
        common_page = commons.Commons(driver)
        navbar.navigate_to_navbar_page(NavbarItem.FAVORITES)
        common_page.wait_for_loader_to_disappear()
        page.click_on_new_case_sections_first_column_in_the_customer_favourites_table()
        page.click_on_first_case_from_list_of_cases_display_on_click_on_new_case_sections()
        assert support_hub.check_visibility_of_support_hub()

    @regression_test
    @author_neha_jha
    @pytestrail.case('C475')
    def test_functionality_of_sort_button_in_overview(self, driver, customer_setup):
        support_hub = SupportHub(driver)
        agents = agent_management_page.AgentsPage(driver)
        page = customer_management_page.CustomerManagementPage(driver)
        page.search_customers(customer_name="le")
        result = customers.check_search_result()
        assert result, "failed to  load search data"
        customers_search_result = page.check_if_agents_present_search_result()
        assert agents_search_result, "No Client is founded"
        customer_name = page.get_text_search_result()
        agents.click_agents_search_result()
        customer_profile = page.checks_for_customer_profile_displayed_or_not()
        if customer_profile:
            customer_name_in_customer_insight_page = page.get_text_profile_customer()
            assert (
                    customer_name_in_customer_insight_page in customer_name
            ), "customer name in search result and customer insight page is not same "
            page.click_on_tab(CustomerManagementTabs.OVERVIEW)
            page.click_open_tab_in_overview()
            case_count = page.get_number_of_count_present_on_overview_tabs()
            LOGGER.info(len(case_count))
            if len(case_count) > 1:
                LOGGER.info(case_count)
                case_count_before_sort = page.get_first_case_id_in_overview_tabs()
                page.click_on_sort_button_in_overview()
                time.sleep(2)
                case_count_after_sort = page.get_first_case_id_in_overview_tabs()
                assert case_count_after_sort != case_count_before_sort, " sort is failed"
            else:

                LOGGER.info("only one case is present on overview tab sort cannot be performed")


    @regression_test
    @author_neha_jha
    @pytestrail.case('C470')
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_functionality_clicking_on_move_forward_arrow_button(self, driver, customer_setup):
        support_hub = SupportHub(driver)
        agents = agent_management_page.AgentsPage(driver)
        page = customer_management_page.CustomerManagementPage(driver)
        page.search_customers(customer_name="le")
        result = customers.check_search_result()
        assert result, "failed to  load search data"
        customers_search_result = page.check_if_agents_present_search_result()
        assert agents_search_result, "No Client is founded"
        customer_name = page.get_text_search_result()
        agents.click_agents_search_result()
        customer_profile = page.checks_for_customer_profile_displayed_or_not()
        if customer_profile:
            customer_name_in_customer_insight_page = page.get_text_profile_customer()
            assert (
                    customer_name_in_customer_insight_page in customer_name
            ), "customer name in search result and customer insight page is not same "

            date_pickers.open_date_picker()
            month_name_before_clicking_forward_arrow = date_pickers.get_month_name_on_calendar()
            LOGGER.info(month_name_before_clicking_forward_arrow)
            date_pickers.click_on_move_forward_arrow_button()
            month_name_after_clicking_on_forward_arrow = date_pickers.get_month_name_on_calendar()
            assert month_name_before_clicking_forward_arrow != month_name_after_clicking_on_forward_arrow,"failed to click on fprward arrow"

        else:
            assert False,"no data for this customer"



    @regression_test
    @author_neha_jha
    @pytestrail.case('C467')
    def test_calendar_widget(self, driver, customer_setup):
        support_hub = SupportHub(driver)
        agents = agent_management_page.AgentsPage(driver)
        page = customer_management_page.CustomerManagementPage(driver)
        page.search_customers(customer_name="le")
        result = customers.check_search_result()
        assert result, "failed to  load search data"
        customers_search_result = page.check_if_agents_present_search_result()
        assert agents_search_result, "No Client is founded"
        customer_name = page.get_text_search_result()
        agents.click_agents_search_result()
        customer_profile = page.checks_for_customer_profile_displayed_or_not()
        if customer_profile:
            customer_name_in_customer_insight_page = page.get_text_profile_customer()
            assert (
                    customer_name_in_customer_insight_page in customer_name
            ), "customer name in search result and customer insight page is not same "
            filter_applied_on_calendar = date_pickers.get_applied_date_filter()
            LOGGER.info(f"filter applied on calendar is {filter_applied_on_calendar}")
            date_pickers.open_date_picker()
            if filter_applied_on_calendar != "This month":
                date_pickers.select_this_month_shortcut()
                date_pickers.apply_selected_date_filter()
                assert (
                        date_pickers.get_applied_date_filter() == "This month"
                ), "fail to select this month"
            page.click_on_tab(CustomerManagementTabs.OVERVIEW)
            page.click_open_tab_in_overview()
            page.check_present_cases_open_tab()
            today = str(date.today().day)
            time.sleep(0.5)
            ticket_open_for = page.get_number_of_day_before_ticket_is_created()
            assert ticket_open_for >= today, " calendar filter is not done based on date range selected "
        else:
            LOGGER.warning(f"We were unable to find any case for this customer -{customer_name} ")
            assert False

    @regression_test
    @author_neha_jha
    @pytestrail.case('C476')
    def test_download_csv_in_overview_tab(self, driver, customer_setup):

        support_hub = SupportHub(driver)
        agents = agent_management_page.AgentsPage(driver)
        page = customer_management_page.CustomerManagementPage(driver)
        page.search_customers(customer_name="le")
        result = customers.check_search_result()
        assert result, "failed to  load search data"
        customers_search_result = page.check_if_agents_present_search_result()
        assert agents_search_result, "No Client is founded"
        agents_name = page.get_text_search_result()
        agents.click_agents_search_result()
        customer_profile = page.checks_for_customer_profile_displayed_or_not()
        if customer_profile:
            profile_agent_name = page.get_text_profile_customer()
            assert (
                    profile_agent_name in agents_name
            ), "search agents name is not match with profile agents name"
            page.click_on_tab(CustomerManagementTabs.OVERVIEW)

            page.click_on_first_chart_section_vertical_dots()
            name_of_file = page.get_element_text_or_value(
                (By.XPATH, customer_management_locator.get_first_chart_name), timeout=30,
                message="agent name is not visible",
            )
            file_name = f"{name_of_file}-{date.today().strftime('%Y-%m-%d')}.png"
            file_path = f"{constants.report_dir}/downloads/{file_name}"
            utils.wait_for_download(file_path, timeout=30)

            assert os.path.exists(file_path)

        else:
            LOGGER.warning(f"{agents_name} in the customer insight have  no data ")