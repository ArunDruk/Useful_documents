"""Test class for Operational Metrics"""
__author__ = "Praveen Nagajothi"
__copyright__ = "Copyright (C) 2021 SupportLogic"

import logging
import random
import re
import time
from datetime import date, datetime, timedelta
from pathlib import Path

import pytest
from pytest_testrail.plugin import pytestrail
from selenium.common.exceptions import ElementClickInterceptedException
from selenium.webdriver.common.by import By

import constants
import utils
from constants import author_praveen_nj, regression_test, sanity_test
from enums import (
    ChartStatusFilter, ChartTypes, EfficiencySubTabs, GroupByStandardFields, NavbarItem,
    OpsMetricsType, SlaSubTabs,
)
from locators import date_picker_locators as dpl
from locators import ops_metrics_locators as oml
from pom_library.commons import Commons
from pom_library.date_picker import DatePicker
from pom_library.helper_methods import HelperMethods
from pom_library.navbar import Navbar
from pom_library.ops_metrics import OpsMetricsPage

LOGGER: logging.Logger = logging.getLogger(__name__)


class TestOpsMetrics:
    @pytest.fixture(scope="class", autouse=True)
    def metrics_setup(self, driver):
        navbar = Navbar(driver)
        commons = Commons(driver)

        commons.wait_for_loader_to_disappear()
        current_page_url: str = navbar.navigate_to_navbar_page(NavbarItem.OPS_METRICS)
        assert "metrics" in current_page_url, "Failed to load Ops Metrics page"
        commons.start_module_onboarding()

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C529")
    @pytest.mark.parametrize("section_name", [*OpsMetricsType])
    def test_overview_section(self, driver, section_name):
        metrics_page = OpsMetricsPage(driver)

        if section_name is OpsMetricsType.SLA and not metrics_page.has_sla_enabled():
            pytest.skip("SLA is disabled")

        LOGGER.info(f"Checking {section_name.value} section visibility..")
        overview_card = oml.overview_section_card_css.format(section=section_name.value)
        assert metrics_page.is_element_visible(
            (By.CSS_SELECTOR, overview_card)
        ), f"{section_name.value} section is not visible"

        LOGGER.info(f"Checking {section_name.value} pie chart visibility..")
        chart = oml.overview_section_pie_chart_css.format(section=section_name.value)
        assert metrics_page.is_element_visible(
            (By.CSS_SELECTOR, chart)
        ), f"{section_name.value} section pie char is not visible"

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C2265")
    @pytest.mark.parametrize("section_name", [*OpsMetricsType])
    def test_detailed_view(self, driver, section_name):
        metrics_page = OpsMetricsPage(driver)

        if section_name is OpsMetricsType.SLA and not metrics_page.has_sla_enabled():
            pytest.skip("SLA is disabled")

        try:
            metrics_page.navigate_to_section_card(section_name)
            LOGGER.info(
                f"Checking {section_name.value} details view 'Add a Chart' button "
                f"visibility.."
            )
            has_add_chart_button: bool = metrics_page.is_element_visible(
                (By.CSS_SELECTOR, oml.add_chart_button_css), timeout=5
            )
            assert has_add_chart_button, "Detailed view page has not loaded correctly"
        finally:
            # cleanup
            metrics_page.go_to_overview_page()

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C530", "C532")
    def test_change_date_range(self, driver):
        date_picker = DatePicker(driver)

        expected_value: str = "This month"
        if date_picker.get_applied_date_filter() != expected_value:
            date_picker.open_date_picker()
            date_picker.select_this_month_shortcut()
            date_picker.apply_selected_date_filter()

        actual_value: str = date_picker.get_applied_date_filter()
        LOGGER.info(f"Selected date range is '{actual_value}'")
        assert (
            expected_value.lower() in actual_value.lower().strip()
        ), f"Selected date range '{actual_value}' is not same as '{expected_value}'"

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C533")
    def test_calendar_cancel_selection(self, driver):
        date_picker = DatePicker(driver)

        expected_value: str = "This month"
        date_picker.open_date_picker()
        if date_picker.get_applied_date_filter() == expected_value:
            date_picker.select_last_n_months_shortcut(1)
        else:
            date_picker.select_this_month_shortcut()
        date_picker.cancel_date_filter_selection()
        assert (
            date_picker.get_applied_date_filter() == expected_value
        ), "Selected date range is applied after clicking cancel"

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C2266")
    @pytest.mark.parametrize(
        "section_name, tab_name",
        tuple(zip([OpsMetricsType.SLA] * 3, SlaSubTabs)),
    )
    def test_section_sub_tabs(self, driver, section_name, tab_name):
        metrics_page = OpsMetricsPage(driver)

        if not metrics_page.has_sla_enabled():
            pytest.skip("SLA is disabled")

        try:
            metrics_page.navigate_to_section_card(section_name)
            if tab_name:
                metrics_page.switch_to_sub_tab(tab_name)

            failure_msg: str = "{message} tab does not have any charts".format(
                message=f"{section_name.value} - {tab_name.value}"
            )
            assert metrics_page.is_element_visible(
                (By.CSS_SELECTOR, oml.charts_in_sla_section_tabs_css)
            ), failure_msg
            LOGGER.info(f"Graphs are loading in {section_name.value}->{tab_name.value}")
        finally:
            # cleanup
            metrics_page.go_to_overview_page()

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C2267")
    def test_add_chart(self, driver):
        metrics_page = OpsMetricsPage(driver)

        try:
            metrics_page.navigate_to_section_card(OpsMetricsType.EFFICIENCY)
            metrics_page.delete_all_existing_charts()

            metrics_page.add_custom_efficiency_chart(
                GroupByStandardFields.STATUS, ChartTypes.VERTICAL
            )
            group_by_value: str = GroupByStandardFields.STATUS.value
            expected_chart_name: str = f"Escalations by {group_by_value.capitalize()}"
            # waiting for the new chart added to reflect in UI
            time.sleep(2)
            assert (
                expected_chart_name in metrics_page.get_available_chart_names()
            ), f"{group_by_value} was not added"
        finally:
            # cleanup
            metrics_page.go_to_overview_page()

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C591", "C592", "C593", "C594")
    def test_graph_status_grouping(self, driver):
        metrics_page = OpsMetricsPage(driver)

        try:
            metrics_page.navigate_to_section_card(OpsMetricsType.EFFICIENCY)

            chart_names: list[str] = metrics_page.get_available_chart_names()
            if not chart_names:
                metrics_page.reset_to_default_charts()
                chart_names = metrics_page.get_available_chart_names()
            random_chart_name: str = random.choice(chart_names)

            metrics_page.filter_chart_by_status(
                random_chart_name, ChartStatusFilter.CREATED
            )
        finally:
            # cleanup
            metrics_page.go_to_overview_page()

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C2268")
    def test_edit_chart(self, driver):
        metrics_page = OpsMetricsPage(driver)

        try:
            metrics_page.navigate_to_section_card(OpsMetricsType.EFFICIENCY)

            chart_names: list[str] = metrics_page.get_available_chart_names()
            if not chart_names:
                metrics_page.reset_to_default_charts()
                chart_names = metrics_page.get_available_chart_names()
            random_chart_name: str = random.choice(chart_names)

            metrics_page.edit_chart(random_chart_name)
            metrics_page.choose_chart_type(ChartTypes.VERTICAL)
            metrics_page.click_on_element(
                (By.XPATH, oml.save_chart_edit), message="Failed to save edit changes"
            )
        finally:
            # cleanup
            metrics_page.go_to_overview_page()

    @sanity_test
    @author_praveen_nj
    @pytestrail.case("C2269")
    def test_delete_chart(self, driver):
        metrics_page = OpsMetricsPage(driver)

        try:
            metrics_page.navigate_to_section_card(OpsMetricsType.EFFICIENCY)

            chart_names: list[str] = metrics_page.get_available_chart_names()
            if not chart_names:
                metrics_page.reset_to_default_charts()
                chart_names = metrics_page.get_available_chart_names()
            random_chart_name: str = random.choice(chart_names)

            metrics_page.delete_chart(random_chart_name)
        finally:
            # cleanup
            metrics_page.go_to_overview_page()

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C531")
    def test_date_picker_scroll(self, driver):
        helpers = HelperMethods(driver)
        date_picker = DatePicker(driver)

        try:
            date_picker.open_date_picker()
            current_selected_from_month = helpers.get_element_text_or_value(
                (By.CSS_SELECTOR, dpl.from_calendar_current_month_css)
            )
            current_selected_to_month = helpers.get_element_text_or_value(
                (By.CSS_SELECTOR, dpl.to_calendar_current_month_css)
            )

            next_month_in_from_calendar = datetime.strptime(
                current_selected_from_month, "%b"
            ) + timedelta(days=31)
            next_month_in_to_calendar = datetime.strptime(
                current_selected_to_month, "%b"
            ) + timedelta(days=31)

            helpers.click_on_element(
                (By.CSS_SELECTOR, dpl.from_calendar_go_to_next_month_css)
            )
            helpers.click_on_element(
                (By.CSS_SELECTOR, dpl.to_calendar_go_to_next_month_css)
            )
            time.sleep(1)
            assert helpers.get_element_text_or_value(
                (By.CSS_SELECTOR, dpl.from_calendar_current_month_css)
            ) == next_month_in_from_calendar.strftime("%b")
            assert helpers.get_element_text_or_value(
                (By.CSS_SELECTOR, dpl.to_calendar_current_month_css)
            ) == next_month_in_to_calendar.strftime("%b")

            helpers.click_on_element(
                (By.CSS_SELECTOR, dpl.from_calendar_go_to_previous_month_css)
            )
            helpers.click_on_element(
                (By.CSS_SELECTOR, dpl.to_calendar_go_to_previous_month_css)
            )
            time.sleep(1)
            from_month_after_right_arrow_click = helpers.get_element_text_or_value(
                (By.CSS_SELECTOR, dpl.from_calendar_current_month_css)
            )
            to_month_after_right_arrow_click = helpers.get_element_text_or_value(
                (By.CSS_SELECTOR, dpl.to_calendar_current_month_css)
            )
            assert from_month_after_right_arrow_click == current_selected_from_month
            assert to_month_after_right_arrow_click == current_selected_to_month
        finally:
            # cleanup
            date_picker.cancel_date_filter_selection()

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C572")
    def test_sla_chart_additional_info(self, driver):
        helpers = HelperMethods(driver)
        metrics = OpsMetricsPage(driver)

        if not metrics.has_sla_enabled():
            pytest.skip("SLA is disabled")

        try:
            metrics.navigate_to_section_card(OpsMetricsType.SLA)
            metrics.switch_to_sub_tab(SlaSubTabs.FIRST_RESP)

            chart_name = "First Response Time"
            if not helpers.is_element_visible(
                (By.CSS_SELECTOR, oml.sla_section_pie_chart_css)
            ):
                metrics.switch_sla_default_chart_to_donut(chart_name)

            for status in ChartStatusFilter:
                metrics.filter_chart_by_status(chart_name, status)
                case_count_in_chart = helpers.get_element_text_or_value(
                    (By.CSS_SELECTOR, oml.sla_default_chart_overall_case_count_css)
                )

                helpers.hover_on_element(
                    (By.CSS_SELECTOR, oml.sla_pie_chart_met_target_css)
                )
                time.sleep(0.5)
                # gets the case count number alone
                met_cases_count_in_tooltip: str = helpers.get_element_text_or_value(
                    (By.CSS_SELECTOR, oml.sla_pie_chart_info_tooltip_css)
                ).split(" ")[1]
                LOGGER.info(met_cases_count_in_tooltip)
                helpers.hover_on_element((By.CSS_SELECTOR, oml.add_chart_button_css))

                helpers.hover_on_element(
                    (By.CSS_SELECTOR, oml.sla_pie_chart_missed_target_css)
                )
                time.sleep(0.5)
                # gets the case count number alone
                missed_cases_count_in_tooltip: str = helpers.get_element_text_or_value(
                    (By.CSS_SELECTOR, oml.sla_pie_chart_info_tooltip_css)
                ).split(" ")[1]
                LOGGER.info(missed_cases_count_in_tooltip)

                assert int("".join(re.findall("\\d", case_count_in_chart))) == int(
                    met_cases_count_in_tooltip
                ) + int(missed_cases_count_in_tooltip)
        finally:
            # cleanup
            metrics.go_to_overview_page()

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C573")
    def test_sla_chart_csv(self, driver):
        helpers = HelperMethods(driver)
        metrics = OpsMetricsPage(driver)

        if not metrics.has_sla_enabled():
            pytest.skip("SLA is disabled")

        try:
            metrics.navigate_to_section_card(OpsMetricsType.SLA)
            metrics.switch_to_sub_tab(SlaSubTabs.FIRST_RESP)
            helpers.click_on_element((By.XPATH, oml.default_chart_download_button))

            chart_name = "First Response Time"
            metrics.export_default_chart(chart_name, only_csv=True)

            locator = oml.export_button_css.format(chart_name=chart_name)
            helpers.click_on_element((By.CSS_SELECTOR, locator))

            file_name = f"First_Response_Time-{date.today().strftime('%Y-%m-%d')}.csv"
            file_path = f"{constants.report_dir}/downloads/{file_name}"
            utils.wait_for_download(file_path)
            assert Path(file_path).exists()
        finally:
            # cleanup
            metrics.go_to_overview_page()

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C587", "C602")
    @pytest.mark.parametrize(
        "chart_name",
        ["Days Spent in Escalated State", "Escalation Distribution by Day"],
    )
    def test_chart_labels(self, driver, chart_name):
        helpers = HelperMethods(driver)
        date_picker = DatePicker(driver)
        metrics = OpsMetricsPage(driver)

        try:
            metrics.navigate_to_section_card(OpsMetricsType.EFFICIENCY)
            try:
                metrics.add_general_efficiency_chart(chart_name, is_trendline=True)
            except ElementClickInterceptedException:
                helpers.click_on_element(
                    (By.CSS_SELECTOR, oml.add_chart_cancel_button_css)
                )
            chart_id = metrics.get_chart_id(chart_name)

            if date_picker.get_applied_date_filter() != "This month":
                date_picker.open_date_picker()
                date_picker.select_this_month_shortcut()
                date_picker.apply_selected_date_filter()

            xaxis_label_locator = oml.days_spent_escalated_chart_xaxis_label_css.format(
                value=chart_id
            )
            yaxis_label_locator = oml.days_spent_escalated_chart_yaxis_label_css.format(
                value=chart_id
            )
            assert date.today().strftime("%b %Y") in [
                elem.text
                for elem in driver.find_elements(By.CSS_SELECTOR, xaxis_label_locator)
            ]
            assert "Number of Escalations" in helpers.get_element_text_or_value(
                (By.CSS_SELECTOR, yaxis_label_locator)
            )
        finally:
            # cleanup
            metrics.go_to_overview_page()

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C606")
    def test_customer_score_chart_labels(self, driver):
        helpers = HelperMethods(driver)
        metrics = OpsMetricsPage(driver)

        labels = metrics.get_label_settings()
        client_label = labels.get("customer.label")
        client_label_plural = labels.get("customer.label.plural")
        try:
            metrics.navigate_to_section_card(OpsMetricsType.CUSTOMER_EXP)
            expected_chart_name = "Current Customer Sentiment Score"
            if f"{expected_chart_name}\ni" not in metrics.get_available_chart_names():
                chart_name = "Customer Sentiment Score"
                metrics.add_client_experience_chart(chart_name, ChartTypes.VERTICAL)
            chart_id = metrics.get_chart_id(expected_chart_name + "i")

            xaxis_label_locator = oml.customer_experience_chart_xaxis_label_css.format(
                value=chart_id
            )
            yaxis_label_locator = oml.customer_experience_chart_yaxis_label_css.format(
                value=chart_id
            )
            expected_xaxis_title = f"{client_label} Sentiment Score"
            assert expected_xaxis_title in helpers.get_element_text_or_value(
                (By.CSS_SELECTOR, xaxis_label_locator)
            )
            assert f"# of {client_label_plural}" in helpers.get_element_text_or_value(
                (By.CSS_SELECTOR, yaxis_label_locator)
            )
        finally:
            # cleanup
            metrics.go_to_overview_page()

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C609")
    def test_rearrange_charts(self, driver):
        helpers = HelperMethods(driver)
        metrics = OpsMetricsPage(driver)

        try:
            metrics.navigate_to_section_card(OpsMetricsType.EFFICIENCY)
            metrics.switch_to_sub_tab(EfficiencySubTabs.CASE_ACTIVITY)

            chart_order_before = metrics.get_available_chart_names()
            LOGGER.info(f"Chart names in order before rearranging {chart_order_before}")
            width, height = driver.get_window_size().values()

            source = driver.find_element(By.XPATH, oml.chart_drag_button)
            target = driver.find_element(By.XPATH, oml.chart_drop_target)
            helpers.actions.click_and_hold(source).move_to_element(target).pause(
                2
            ).move_by_offset(width/10, height/10).release().perform()
            chart_order_after = metrics.get_available_chart_names()
            LOGGER.info(f"Chart names in order after rearranging {chart_order_before}")
            assert chart_order_before != chart_order_after, "Failed to rearrange charts"
        finally:
            # cleanup
            metrics.go_to_overview_page()

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C610", "C611", "C612")
    @pytest.mark.xfail(reason="https://app.clickup.com/t/2277599/AA-19198")
    def test_export_any_chart_as_csv_and_image(self, driver):
        helpers = HelperMethods(driver)
        metrics = OpsMetricsPage(driver)

        try:
            metrics.navigate_to_section_card(OpsMetricsType.EFFICIENCY)
            metrics.switch_to_sub_tab(EfficiencySubTabs.ESCALATIONS)
            helpers.click_on_element((By.XPATH, oml.default_chart_download_button))

            chart_name = "Escalations"
            count = helpers.get_element_text_or_value(
                (By.CSS_SELECTOR, oml.new_escalations_count_css)
            )
            # replace commas and other symbols
            new_escalations_count = re.sub("\\D", "", count)
            metrics.export_default_chart(chart_name)

            csv_file_name = f"{chart_name}-{date.today().strftime('%Y-%m-%d')}.csv"
            img_file_name = f"{chart_name}-{date.today().strftime('%Y-%m-%d')}.csv"
            csv_file_path = f"{constants.report_dir}/downloads/{csv_file_name}"
            img_file_path = f"{constants.report_dir}/downloads/{img_file_name}"
            utils.wait_for_download(csv_file_path)
            utils.wait_for_download(img_file_path)

            # TODO add verifications for exported images
            assert Path(csv_file_path).exists(), f"{csv_file_name} does not exist"
            assert Path(img_file_path).exists(), f"{img_file_name} does not exist"
            assert len(utils.read_csv_file(csv_file_path)) in tuple(
                range(int(new_escalations_count) - 5, int(new_escalations_count) + 5)
            )
        finally:
            # cleanup
            metrics.go_to_overview_page()

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C561")
    def test_efficiency_backlog_add_general_chart(self, driver):
        metrics = OpsMetricsPage(driver)

        try:
            metrics.navigate_to_section_card(OpsMetricsType.EFFICIENCY)
            metrics.switch_to_sub_tab(EfficiencySubTabs.BACKLOG)
            time.sleep(5)  # wait for the chart data to load
            metrics.delete_all_existing_charts()
            metrics.add_general_efficiency_chart("Case Age")
            metrics.add_general_efficiency_chart("Case Age", is_trendline=True)
            assert len(set(metrics.get_available_chart_names())) == 1
        finally:
            # cleanup
            metrics.go_to_overview_page()

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C562")
    def test_efficiency_case_activity_add_chart(self, driver):
        metrics = OpsMetricsPage(driver)

        try:
            metrics.navigate_to_section_card(OpsMetricsType.EFFICIENCY)
            metrics.switch_to_sub_tab(EfficiencySubTabs.CASE_ACTIVITY)
            metrics.delete_all_existing_charts()

            case_activity_charts = (
                "Case Conversation Count", "Owner Count", "Responder Count",
            )
            for chart in case_activity_charts:
                metrics.add_general_efficiency_chart(chart)
                metrics.add_general_efficiency_chart(chart, is_trendline=True)
            assert case_activity_charts == tuple(
                sorted(set(metrics.get_available_chart_names()))
            ), "Newly added charts don't match with expected"
        finally:
            # cleanup
            metrics.go_to_overview_page()

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C582", "C583", "C585")
    @pytest.mark.parametrize(
        "tab_name, chart_name",
        [
            (SlaSubTabs.FIRST_RESP, "First Response Time"),
            (SlaSubTabs.FOLLOW_UP, "Follow-up Time"),
            (SlaSubTabs.CASE_RESOLUTION, "Case Resolution Time"),
        ],
    )
    def test_default_chart_donut_view_switcher(self, driver, tab_name, chart_name):
        helpers = HelperMethods(driver)
        metrics = OpsMetricsPage(driver)

        if helpers.is_element_visible((By.XPATH, oml.sla_default_chart_zero_state_msg)):
            raise Exception(f"{chart_name} chart has no cases")
        try:
            metrics.navigate_to_section_card(OpsMetricsType.SLA)
            metrics.switch_to_sub_tab(tab_name)
            if helpers.is_element_visible(
                (By.CSS_SELECTOR, oml.sla_section_pie_chart_css)
            ):
                metrics.switch_sla_default_chart_to_trendline(chart_name)
                assert helpers.is_element_visible(
                    (By.CSS_SELECTOR, oml.sla_section_trend_chart_css)
                )
            metrics.switch_sla_default_chart_to_donut(chart_name)
            assert helpers.is_element_visible(
                (By.CSS_SELECTOR, oml.sla_section_pie_chart_css)
            )
        finally:
            # cleanup
            metrics.go_to_overview_page()

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C581", "C584", "C586")
    @pytest.mark.parametrize(
        "tab_name, chart_name",
        [
            (SlaSubTabs.FIRST_RESP, "First Response Time"),
            (SlaSubTabs.FOLLOW_UP, "Follow-up Time"),
            (SlaSubTabs.CASE_RESOLUTION, "Case Resolution Time"),
        ],
    )
    def test_default_chart_trendline_view_switcher(self, driver, tab_name, chart_name):
        helpers = HelperMethods(driver)
        metrics = OpsMetricsPage(driver)

        if helpers.is_element_visible((By.XPATH, oml.sla_default_chart_zero_state_msg)):
            raise Exception(f"{chart_name} chart has no cases")
        try:
            metrics.navigate_to_section_card(OpsMetricsType.SLA)
            metrics.switch_to_sub_tab(tab_name)
            if helpers.is_element_visible(
                (By.CSS_SELECTOR, oml.sla_section_trend_chart_css)
            ):
                metrics.switch_sla_default_chart_to_donut(chart_name)
                assert helpers.is_element_visible(
                    (By.CSS_SELECTOR, oml.sla_section_pie_chart_css)
                )
            metrics.switch_sla_default_chart_to_trendline(chart_name)
            assert helpers.is_element_visible(
                (By.CSS_SELECTOR, oml.sla_section_trend_chart_css)
            )
        finally:
            # cleanup
            metrics.go_to_overview_page()

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C588", "C589", "C590", "C595", "C596", "C597")
    @pytest.mark.parametrize(
        "chart_name", ["Days Spent in Escalated State", "Days to Escalation"]
    )
    @pytest.mark.parametrize("escalated_within", ["< 7 Days", "7-14 Days", "> 14 Days"])
    def test_escalations_chart_range_bucket(self, driver, chart_name, escalated_within):
        helpers = HelperMethods(driver)
        metrics = OpsMetricsPage(driver)

        try:
            metrics.navigate_to_section_card(OpsMetricsType.EFFICIENCY)
            metrics.switch_to_sub_tab(EfficiencySubTabs.ESCALATIONS)

            if chart_name not in metrics.get_available_chart_names():
                metrics.add_general_efficiency_chart(chart_name, is_trendline=True)
            time.sleep(2)
            dropdown_locator = oml.temp_range_bucket_dropdown_css.format(
                chart_name=chart_name
            )
            helpers.click_on_element((By.CSS_SELECTOR, dropdown_locator))
            time.sleep(0.2)
            select_all_option_locator = oml.chart_filter_options_css.format(
                chart_name=chart_name, option="selectAll"
            )
            helpers.select_if_unselected(By.CSS_SELECTOR, select_all_option_locator)
            helpers.unselect_if_selected(By.CSS_SELECTOR, select_all_option_locator)

            range_locator = oml.chart_filter_options_css.format(
                chart_name=chart_name, option=escalated_within
            )
            helpers.select_if_unselected(By.CSS_SELECTOR, range_locator)
            apply_btn_locator = oml.chart_filter_dropdown_apply_btn_css.format(
                chart_name=chart_name
            )
            helpers.click_on_element((By.CSS_SELECTOR, apply_btn_locator))
            assert (
                helpers.get_element_text_or_value((By.CSS_SELECTOR, dropdown_locator))
                == escalated_within
            )
        finally:
            # cleanup
            metrics.go_to_overview_page()

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C598", "C599", "C600", "C601")
    @pytest.mark.parametrize(
        "status",
        [
            ChartStatusFilter.OPEN,
            ChartStatusFilter.CLOSED,
            ChartStatusFilter.CREATED,
            ChartStatusFilter.ESCALATED,
        ],
    )
    def test_days_to_escalation_chart_status(self, driver, status):
        metrics = OpsMetricsPage(driver)

        try:
            metrics.navigate_to_section_card(OpsMetricsType.EFFICIENCY)
            metrics.switch_to_sub_tab(EfficiencySubTabs.ESCALATIONS)

            chart_name = "Days to Escalation"
            if chart_name not in metrics.get_available_chart_names():
                metrics.add_general_efficiency_chart(chart_name, is_trendline=True)
            time.sleep(2)
            metrics.filter_chart_by_status(chart_name, status)

            assert metrics.get_current_chart_filter(chart_name) == status.value
        finally:
            # cleanup
            metrics.go_to_overview_page()

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C541")
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_settings_hover(self, driver):
        helpers = HelperMethods(driver)

        client_label = helpers.get_label_settings()["customer.label"]
        for _type in OpsMetricsType:
            card_locator = oml.overview_section_card_css.format(section=_type.value)
            LOGGER.info(_type.value)
            settings_button_locator: str = oml.overview_section_settings_css.format(
                section=_type.value
            )

            helpers.hover_on_element((By.CSS_SELECTOR, card_locator))
            helpers.scroll_into_view((By.CSS_SELECTOR, settings_button_locator))
            helpers.hover_on_element((By.CSS_SELECTOR, settings_button_locator))
            time.sleep(1)

            print(f"********** client_label.lower() = {client_label.lower()}")
            section_name = _type.value
            # if _type is OpsMetricsType.CUSTOMER_EXP:
            #     print("***** Replacing")
            #     section_name = section_name.replace("customer", client_label.lower())
            expected_text: str = (
                f"edit {section_name.replace('_', ' ')} targets (in advanced settings)"
            )
            assert helpers.is_element_visible(
                (By.CSS_SELECTOR, oml.overview_section_settings_tooltip_css)
            )
            assert expected_text == helpers.get_element_text_or_value(
                (By.CSS_SELECTOR, oml.overview_section_settings_tooltip_css)
            ).lower()

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C543")
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_settings_click(self, driver):
        metrics = OpsMetricsPage(driver)

        client_label = metrics.get_label_settings()["customer.label"]
        for _type in OpsMetricsType:
            section_name = _type.value
            # if _type is OpsMetricsType.CUSTOMER_EXP:
            #     section_name = section_name.replace("customer", client_label.lower())
            metrics.click_settings_in_overview_card(_type)
            try:
                assert section_name in driver.current_url.lower()
            finally:
                driver.back()

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C544")
    def test_efficiency_default_subsection(self, driver):
        metrics = OpsMetricsPage(driver)

        try:
            metrics.navigate_to_section_card(OpsMetricsType.EFFICIENCY)
            assert "escalations" == metrics.get_current_selected_sub_tab().lower()
        finally:
            # cleanup
            metrics.go_to_overview_page()

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C545")
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_efficiency_escalation_default_chart(self, driver):
        helpers = HelperMethods(driver)
        metrics = OpsMetricsPage(driver)

        try:
            metrics.navigate_to_section_card(OpsMetricsType.EFFICIENCY)
            assert helpers.is_element_visible(
                (By.CSS_SELECTOR, oml.chart_in_efficiency_section_tabs_css)
            )
        finally:
            # cleanup
            metrics.go_to_overview_page()

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C605", "C613")
    def test_case_activity_and_delete_chart_functionality(self, driver):
        metrics = OpsMetricsPage(driver)

        expected_chart_names = (
            "Case Conversation Count",
            "Owner Count",
            "Responder Count",
        )

        try:
            metrics.navigate_to_section_card(OpsMetricsType.EFFICIENCY)
            metrics.switch_to_sub_tab(EfficiencySubTabs.CASE_ACTIVITY)

            metrics.delete_all_existing_charts()
            for chart_name in expected_chart_names:
                metrics.add_general_efficiency_chart(chart_name)
                metrics.add_general_efficiency_chart(chart_name, is_trendline=True)
            assert sorted(expected_chart_names * 2) == sorted(
                metrics.get_available_chart_names()
            ), "Failed to add back all deleted charts"
        finally:
            # cleanup
            metrics.go_to_overview_page()

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C534", "C535", "C536")
    @pytest.mark.parametrize("section_name", [*OpsMetricsType])
    @pytest.mark.skip(reason="Covered in Cypress")
    def test_section_info_icon_tooltip(self, driver, section_name):
        helpers = HelperMethods(driver)

        labels = helpers.get_label_settings()
        agent_label_plural = labels.get("agent.label.plural", "TSEs").lower()
        case_label_plural = labels.get("case.label.plural", "Cases").lower()
        client_label_plural = labels.get("customer.label.plural", "Customers").lower()

        tooltip_text: dict[OpsMetricsType, str] = {
            OpsMetricsType.SLA: f"This panel shows a breakdown of {case_label_plural} that have met or missed the SLA target.",
            OpsMetricsType.EFFICIENCY: f"This panel shows how your agents are performing based on different factors such as case conversation, responder, and case owner counts.",
            OpsMetricsType.CUSTOMER_EXP: f"Know how your customers are feeling with a view into your team’s CSAT, NPS, and Sentiment Scores.",
        }
        i_icon_locator: str = oml.overview_section_card_info_icon_css.format(
            section=section_name.value
        )

        helpers.hover_on_element((By.CSS_SELECTOR, i_icon_locator))
        time.sleep(0.2)
        assert helpers.is_element_visible(
            (By.CSS_SELECTOR, oml.overview_section_card_info_popover_css)
        ), f"{section_name.name} Info tooltip is not displayed"

        assert tooltip_text[section_name] == helpers.get_element_text_or_value(
            (By.CSS_SELECTOR, oml.overview_section_card_info_popover_css)
        ), f"{section_name.name} Info tooltip text is different than expected"
    
    @regression_test
    @author_praveen_nj
    @pytestrail.case("C554")
    def test_customer_experience_chart_filter(self, driver):
        helpers = HelperMethods(driver)
        metrics_page = OpsMetricsPage(driver)

        try:
            metrics_page.navigate_to_section_card(OpsMetricsType.CUSTOMER_EXP)
            metrics_page.filter_chart_by_status(
                "Sentiment Signals", ChartStatusFilter.CLOSED
            )
            helpers.click_on_element(
                (By.CSS_SELECTOR, oml.sentiment_signals_chart_visible_plot_css)
            )
            print(f"looking for { oml.sentiment_signals_case_list_item_css}")
            #time.sleep(3000)
            helpers.hover_on_element(
                (By.CSS_SELECTOR, oml.sentiment_signals_case_list_item_css)
            )
            helpers.click_on_element(
                (By.CSS_SELECTOR, oml.sentiment_signals_case_list_item_link_css)
            )

            try:
                driver.switch_to.window(driver.window_handles[1])
                case_status: str = helpers.get_element_text_or_value(
                    (By.CSS_SELECTOR, oml.case_status_in_detached_support_hub_css)
                ).lower()
                assert case_status == "closed", "Case status in SH is not as expected"
            finally:
                driver.close()
                driver.switch_to.window(driver.window_handles[0])
        finally:
            # cleanup
            metrics_page.go_to_overview_page()

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C557")
    def test_add_chart_types(self, driver):
        helpers = HelperMethods(driver)
        metrics = OpsMetricsPage(driver)

        try:
            metrics.navigate_to_section_card(OpsMetricsType.EFFICIENCY)
            metrics.delete_all_existing_charts()
            # add new charts one of each type
            for _type in ChartTypes:
                metrics.add_custom_efficiency_chart(GroupByStandardFields.STATUS, _type)
            chart_names: list[str] = metrics.get_available_chart_names()
            assert len(chart_names) == 4 and "Escalations by Status" in set(chart_names)
            # delete all again and reset to default
            metrics.delete_all_existing_charts()
            metrics.reset_to_default_charts()
        finally:
            cancel_button_locator = By.CSS_SELECTOR, oml.add_chart_cancel_button_css
            if helpers.is_element_visible(cancel_button_locator):
                driver.find_element(cancel_button_locator).click()
            # cleanup
            metrics.go_to_overview_page()

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C558")
    @pytest.mark.xfail(reason="https://app.clickup.com/t/2277599/AA-18642")
    def test_escalation_general_vertical_charts(self, driver):
        helpers = HelperMethods(driver)
        metrics = OpsMetricsPage(driver)

        try:
            metrics.navigate_to_section_card(OpsMetricsType.EFFICIENCY)
            metrics.delete_all_existing_charts()
            # add new charts one of each type
            general_charts = (
                "Days Spent in Escalated State",
                "Days to Escalation",
                "Escalation Distribution by Day",
            )
            for chart in general_charts:
                metrics.add_general_efficiency_chart(chart)
            chart_names: list[str] = metrics.get_available_chart_names()
            assert all((chart in chart_names for chart in general_charts))
            # delete all again and reset to default
            metrics.delete_all_existing_charts()
            metrics.reset_to_default_charts()
        finally:
            cancel_button_locator = By.CSS_SELECTOR, oml.add_chart_cancel_button_css
            if helpers.is_element_visible(cancel_button_locator):
                driver.find_element(cancel_button_locator).click()
            # cleanup
            metrics.go_to_overview_page()

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C566")
    def test_sla_default_subsection(self, driver):
        metrics = OpsMetricsPage(driver)

        if not metrics.has_sla_enabled():
            pytest.skip("SLA is disabled")

        try:
            metrics.navigate_to_section_card(OpsMetricsType.SLA)
            assert "first response" == metrics.get_current_selected_sub_tab().lower()
        finally:
            # cleanup
            metrics.go_to_overview_page()

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C567")
    def test_sla_default_chart(self, driver):
        helpers = HelperMethods(driver)
        metrics = OpsMetricsPage(driver)

        if not metrics.has_sla_enabled():
            pytest.skip("SLA is disabled")

        try:
            metrics.navigate_to_section_card(OpsMetricsType.SLA)
            metrics.switch_to_sub_tab(SlaSubTabs.FIRST_RESP)
            assert helpers.is_element_visible(
                (By.CSS_SELECTOR, oml.charts_in_sla_section_tabs_css)
            ), "Default chart is not displayed in metrics First Response SLA section"
        finally:
            # cleanup
            metrics.go_to_overview_page()

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C568")
    def test_sla_chart_hover_info(self, driver):
        helpers = HelperMethods(driver)
        metrics = OpsMetricsPage(driver)

        if not metrics.has_sla_enabled():
            pytest.skip("SLA is disabled")

        try:
            metrics.navigate_to_section_card(OpsMetricsType.SLA)
            metrics.switch_to_sub_tab(SlaSubTabs.FIRST_RESP)
            helpers.hover_on_element(
                (By.CSS_SELECTOR, oml.sla_pie_chart_met_target_css)
            )
            time.sleep(0.5)
            assert helpers.is_element_visible(
                (By.CSS_SELECTOR, oml.sla_pie_chart_info_tooltip_css)
            )
            helpers.hover_on_element(
                (By.CSS_SELECTOR, oml.sla_pie_chart_missed_target_css)
            )
            time.sleep(0.5)
            assert helpers.is_element_visible(
                (By.CSS_SELECTOR, oml.sla_pie_chart_info_tooltip_css)
            )
        finally:
            # cleanup
            metrics.go_to_overview_page()

    @regression_test
    @author_praveen_nj
    @pytestrail.case("C569")
    @pytest.mark.xfail(reason="ClickIntercept Exception at line 442")
    def test_sla_chart_met_target(self, driver):
        helpers = HelperMethods(driver)
        metrics = OpsMetricsPage(driver)

        if not metrics.has_sla_enabled():
            pytest.skip("SLA is disabled")

        try:
            metrics.navigate_to_section_card(OpsMetricsType.SLA)
            metrics.switch_to_sub_tab(SlaSubTabs.FIRST_RESP)
            helpers.hover_on_element(
                (By.CSS_SELECTOR, oml.sla_pie_chart_met_target_css)
            )
            time.sleep(0.5)
            assert helpers.is_element_visible(
                (By.CSS_SELECTOR, oml.sla_pie_chart_info_tooltip_css)
            )
            # gets the case count number alone
            met_cases_count_in_tooltip: str = helpers.get_element_text_or_value(
                (By.CSS_SELECTOR, oml.sla_pie_chart_info_tooltip_css)
            ).split(" ")[1]
            LOGGER.info(met_cases_count_in_tooltip)
            helpers.click_on_element(
                (By.CSS_SELECTOR, oml.sla_pie_chart_met_target_css)
            )
            assert helpers.is_element_visible(
                (By.CSS_SELECTOR, oml.chart_tickets_popup_css)
            )
            assert met_cases_count_in_tooltip in helpers.get_element_text_or_value(
                (By.CSS_SELECTOR, oml.chart_tickets_popup_case_count_css)
            )
        finally:
            # cleanup
            metrics.go_to_overview_page()
