import csv
import email
import imaplib
import logging
import os
import re
import shutil
import time
from datetime import date, datetime
from email.header import decode_header
from email.message import Message
from pathlib import Path
from typing import Any, AnyStr, Iterable, List, Sequence, Set, Union

import constants

LOGGER: logging.Logger = logging.getLogger(__name__)


def create_directory(folder_path: str) -> str:
    """
    Creates a directory at the specified location

    Parameters
    ----------
    folder_path: str
        Target location for the new directory along with the directory name

    Returns
    -------
    str
        Path of the newly created directory
    """
    Path(folder_path).mkdir(parents=True, exist_ok=True)
    assert Path(folder_path).is_dir(), f"Failed to create a directory at {folder_path}"
    return folder_path


def delete_directory(folder_path: str, only_if_empty: bool = False) -> None:
    """
    Deletes the directory found at the specified path

    Parameters
    ----------
    folder_path: str
        Path of the directory required to be deleted
    only_if_empty: bool, optional
        Flag to control deletion of non-empty directories (default is False)
    """
    folder_to_delete = Path(folder_path)
    assert folder_to_delete.is_dir(), f"{folder_path} is not a directory"
    if only_if_empty:
        try:
            Path(folder_path).rmdir()
        except OSError:
            pass
    else:
        shutil.rmtree(folder_to_delete, ignore_errors=True)


def read_text_file(filepath: str) -> List[str]:
    """
    Reads the contents of a text file at the given location

    Parameters
    ----------
    filepath: str
        Location of the file

    Returns
    -------
    List[str]
        Contents of the file as a list; Empty list when file is not found or has no data
    """
    if not Path(filepath).is_file() or Path(filepath).stat().st_size == 0:
        return []

    with open(filepath) as file:
        lines: List[str] = file.readlines()

    return [line.replace("\n", "") for line in lines]


def read_csv_file(filepath: str, as_dict: bool = False) -> List[Any]:
    """
    Reads the contents of a csv file at the given location. By default, the contents are
    returned as lists.

    Parameters
    ----------
    filepath: str
        Location of the file
    as_dict: bool
        Returns the contents as a dict with the column names as keys

    Returns
    -------
    List[Any]
        Contents of the file as a list; Empty list when file is not found or has no data
    """
    if not Path(filepath).is_file() or Path(filepath).stat().st_size == 0:
        return []

    if Path(filepath).suffix != ".csv":
        raise Exception("given file is not a CSV")

    with open(filepath) as file:
        read_method = csv.DictReader if as_dict else csv.reader
        reader = read_method(file)
        return [row for row in reader]


def write_to_file(
    content: Iterable[AnyStr], filepath: str, overwrite: bool = True
) -> None:
    """
    Writes the given data onto a file at the specified location

    If the file of the same name and type exists already the new data is either
    appended to the end or replaces the existing contents of the file depending on the
    `overwrite` flag

    Parameters
    ----------
    content: Iterable
        Data that needs to be written to the file
    filepath: str
        Location at which the file needs to created or already exists, along with the
        filename and extension
    overwrite: bool, optional
        Set this flag to 'False' to avoid overwriting existing data (default is True)
    """
    mode: str = "w" if overwrite else "a"
    with open(filepath, mode=mode) as file:
        file.writelines(content)


def get_current_datetime_as_string() -> str:
    """Returns the current date & time as a formatted string separated by underscores"""
    return datetime.now().strftime("%d_%m_%Y_%I_%M_%S")


def generate_test_run_id(
    id_prefix: str, separator: str = " ", iterate: bool = True
) -> str:
    """
    Generates a new test run id with the given prefix and run_id_suffix (default is an
    empty string).

    If run_id_suffix is,
    - available, it is concatenated with the prefix using the separator, and the
    resultant string is returned.
    - not available, it is then assigned with the current date & time, and a recursive
    call is made.

    If the argument `separator` is not passed, the default separator is used.

    Parameters
    ----------
    id_prefix : str
        prefix of the test run id
    separator : str, optional
        value that separates the prefix & the suffix (default is whitespace)
    iterate: bool, optional
        Set this flag to False if a unique incremental number does not need to be
        appended at the end of the run id value (default is True)
    Returns
    -------
    str
        test run id as a string
    """
    if not constants.run_id:
        constants.run_id = get_current_datetime_as_string()

    test_run_id: str = id_prefix + separator + constants.run_id
    if iterate:
        test_run_id += f"{separator}{constants.iterator}"
        constants.iterator += 1
    return test_run_id


def validate_values_equals(
    actual_field_name: str,
    actual_value: str,
    expected_field_name: str,
    expected_value: str,
) -> bool:
    """
    An expectation for checking that the two given values are the same or not.

    The `'equals'` in the method name denotes the operator used for comparing.

    Returns
    -------
    bool
        True when both actual and expected are similar, False otherwise.
    """
    LOGGER.info(f"Comparing {actual_field_name} against {expected_field_name}..")
    log_msg: str = (
        f"{actual_field_name}: '{actual_value}'"
        + "{val}"
        + f"{expected_field_name}: '{expected_value}'"
    )
    if actual_value.strip().lower() == expected_value.strip().lower():
        LOGGER.info(log_msg.format(val=" is same as "))
        return True
    else:
        LOGGER.info(log_msg.format(val=" is not the same as "))
        return False


def validate_values_in(
    actual_field_name: str,
    actual_value: str,
    expected_field_name: str,
    expected_value: Union[str, Sequence],
) -> bool:
    """
    An expectation for checking that the given actual value is present in the expected
    value.

    The `'in'` in the method name denotes the operator used for comparing.

    Returns
    -------
    bool
        True when both actual and expected are similar, False otherwise.
    """
    LOGGER.info(f"Comparing {actual_field_name} against {expected_field_name}..")

    # convert to lowercase only if expected value is a string
    actual: str = actual_value
    if isinstance(actual_value, str):
        actual_value.strip().lower()

    expected: Union[str, Sequence] = expected_value
    if isinstance(expected_value, str):
        expected_value.strip().lower()

    log_msg: str = (
        f"{actual_field_name}: '{actual_value}'"
        + "{val}"
        + f"{expected_field_name}: '{expected_value}'"
    )
    if actual in expected:
        LOGGER.info(log_msg.format(val=" is in "))
        return True
    else:
        LOGGER.info(log_msg.format(val=" is not in "))
        return False


def fetch_email_subjects(
    username: str, password: str, top_n_emails: int = 5
) -> Set[str]:
    """
    **IMPORTANT: This method only works for gmail accounts**

    Fetch the subject lines from the inbox of the given user using imap configuration.

    By default, the top 5 emails subject are retrieved. This behavior can be changed by
    passing a different value to the optional top_n_email parameter.

    Parameters
    ----------
    username: str
        Username or email id
    password: str
        application password for the given username
    top_n_emails: int, optional
        number of subject lines to be fetched (default is 5)
    Returns
    -------
    set[str]
        Top N email subject lines
    """
    subjects: list = []
    with imaplib.IMAP4_SSL(host="imap.gmail.com", port=993) as conn:
        conn.login(username, password)
        status, messages = conn.select(readonly=True)
        msg_count = int(messages[0])
        n: int = top_n_emails if msg_count > top_n_emails else 0
        for i in range(msg_count, msg_count - n, -1):
            resp, message = conn.fetch(str(i), "(RFC822)")
            for response in message:
                if isinstance(response, tuple):
                    # parse a bytes email into a message object
                    msg: Message = email.message_from_bytes(response[1])
                    # decode the email subject
                    subject, encoding = decode_header(msg["Subject"])[0]
                    if isinstance(subject, bytes):
                        # if it's a bytes, decode to str
                        subject: str = subject.decode(encoding)
                    subjects.append(subject)
    return set(subjects)


def fetch_email_body(username: str, password: str, top_n_emails: int = 5) -> list[str]:
    """
    **IMPORTANT: This method only works for gmail accounts**

    Fetch the subject lines from the inbox of the given user using imap configuration.

    By default, the top 5 emails' body are retrieved. This behavior can be changed by
    passing a different value to the optional top_n_email parameter.

    Parameters
    ----------
    username: str
        Username or email id
    password: str
        application password for the given username
    top_n_emails: int, optional
        number of message body to be fetched (default is 5)
    Returns
    -------
    set[str]
        Top N email message body
    """
    message_body: list = []
    with imaplib.IMAP4_SSL(host="imap.gmail.com", port=993) as conn:
        conn.login(username, password)
        status, messages = conn.select(readonly=True)
        msg_count = int(messages[0])
        n: int = top_n_emails if msg_count > top_n_emails else 0
        for i in range(msg_count, msg_count - n, -1):
            resp, message = conn.fetch(str(i), "(RFC822)")
            for response in message:
                if isinstance(response, tuple):
                    # parse a bytes email into a message object
                    msg: Message = email.message_from_bytes(response[1])
                    # if the email message is multipart
                    if msg.is_multipart():
                        # iterate over email parts
                        for part in msg.walk():
                            # extract content type of email
                            content_type = part.get_content_type()
                            content_disposition = str(part.get("Content-Disposition"))
                            try:
                                # get the email body
                                body = part.get_payload(decode=True).decode()
                            except:
                                pass
                            if (
                                content_type == "text/plain"
                                and "attachment" not in content_disposition
                            ):
                                # print text/plain emails and skip attachments
                                message_body.append(body)
                    else:
                        # extract content type of email
                        content_type = msg.get_content_type()
                        # get the email body
                        body = msg.get_payload(decode=True).decode()
                        if content_type == "text/plain":
                            # print only text email parts
                            message_body.append(body)
    return message_body


def delete_email_by_sender_and_date_received(
    username: str,
    password: str,
    sender_email: str,
    since_date: date,
    delete_permanently: bool = False,
) -> None:
    """
    **IMPORTANT: This method only works for gmail accounts**

    Deletes all emails from the inbox that is received since the given date and from the
    specified sender.

    Parameters
    ----------
    username: str
        Username or email id
    password: str
        application password for the given username
    sender_email: str
        Email ID of sender whose emails need to be removed
    since_date: date
        Start date from when the emails will be removed
    delete_permanently: bool, optional
        Determines if deletion is permanent or temporary (default is False)
    """
    formatted_date_received = since_date.strftime("%d-%b-%Y")
    with imaplib.IMAP4_SSL(host="imap.gmail.com", port=993) as conn:
        conn.login(username, password)
        conn.select()
        status, messages = conn.search(
            None, f"FROM {sender_email} SINCE {formatted_date_received}"
        )
        emails = messages[0].split()
        for mail in emails:
            if delete_permanently:
                conn.store(mail, "+FLAGS", "\\Deleted")
            else:
                conn.store(mail, "+X-GM-LABELS", "\\Trash")
        conn.expunge()


def convert_date_string_to_different_format(
    date_string: str, date_string_fmt: str, output_format: str
) -> str:
    """
    Converts the given date string of the given format into a string specified by
    output_format.

    Parameters
    ----------
    date_string: str
        a date value in string format
    date_string_fmt: str
        current date format style of the date_string that needs to be converted
    output_format: str
        expected date format style
    Returns
    -------
    str
        Date String in specified output format
    """
    return datetime.strptime(date_string, date_string_fmt).strftime(output_format)


def wait_for_download(filename: str, timeout: int = 30) -> None:
    seconds = 0
    while seconds <= timeout:
        time.sleep(1)
        if Path(filename).exists():
            break
        seconds += 1
    if seconds > timeout:
        raise FileNotFoundError(
            f"{filename} did not finish downloading within {timeout} seconds"
        )


def get_app_url():
    app_url: str = os.getenv("SL_URL", default=constants.default_url)
    app_url = app_url.removesuffix("/")
    if not app_url.startswith("https://"):
        app_url = "https://" + app_url
    return app_url


def sort_time_phrases(times: list[str], in_descending: bool = False) -> list[str]:
    def span(value):
        value = re.sub("^a\\sfew|^an|^a", "1", value, flags=re.IGNORECASE)
        return int(value.split()[0])

    def unit(value):
        units = {
            "second": 0,
            "seconds": 0,
            "minute": 1,
            "minutes": 1,
            "hour": 2,
            "hours": 2,
            "day": 3,
            "days": 3,
            "month": 4,
            "months": 4,
            "year": 5,
            "years": 5,
        }
        key = re.sub("^a\\sfew|^an|^a|ago$|\\d", "", value, flags=re.IGNORECASE)
        return units[key.strip().lower()]

    sorted_values = sorted(sorted(times, key=span), key=unit)
    result = sorted_values[::-1] if in_descending else sorted_values
    LOGGER.info(f"After sorting: {result}")
    return result
