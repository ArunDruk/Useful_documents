""" This is the conftest.py where all the fixtures are listed """
import logging
import logging.config
import os
import pathlib
import time

import pytest
from pyvirtualdisplay import Display
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from webdriver_manager.firefox import GeckoDriverManager

import constants
import utils


# --------------------------------------------------------------------------------------
# configurations / settings
# --------------------------------------------------------------------------------------
@pytest.hookimpl(hookwrapper=True, tryfirst=True)
def pytest_runtest_makereport(item):
    """Hook to return the test outcome"""
    outcome = yield
    rep = outcome.get_result()
    setattr(item, "rep", rep)


def pytest_configure(config):
    """Tells pytest where to store reports and related artifacts"""
    # create a unique directory to store the report (if not already exists)
    if not constants.report_dir:
        directory_name = utils.generate_test_run_id(id_prefix="Report", iterate=False)
        folder_path = f"{pathlib.Path(__file__).parent}/reports/{directory_name}"
        constants.report_dir = utils.create_directory(folder_path)

    # adds a logfile path to pytest config
    if not config.option.log_file:
        logging.getLogger("urllib3.connectionpool").setLevel(logging.WARNING)
        logging.getLogger("selenium.webdriver.remote.remote_connection").setLevel(
            logging.WARNING
        )
        config.option.log_file = constants.report_dir + "/logfile"


# --------------------------------------------------------------------------------------
# global fixtures
# --------------------------------------------------------------------------------------
@pytest.fixture(autouse=True)
def capture_screen_on_failure(request, driver):
    """Takes a screenshot automatically when a test case fails"""
    yield
    method_name = request.node.nodeid.split("::")[-1]
    if request.node.rep.failed:
        screenshots_dir = utils.create_directory(f"{constants.report_dir}/screenshots")
        driver.save_screenshot(f"{screenshots_dir}/{method_name}.png")


@pytest.fixture(scope="session", autouse=True)
def driver():
    """Will open the browser"""
    display = None
    browser_name = constants.browser_names
    download_dir = utils.create_directory(f"{constants.report_dir}/downloads")

    # The driver for the given browser will be downloaded automatically. Please
    # install the browser, if not installed already.
    if browser_name == "chrome":
        # setting to store downloads in a custom location
        prefs = {
            "download.directory_upgrade": "true",
            "download.prompt_for_download": "false",
            "download.default_directory": download_dir,
            "profile.content_settings.exceptions.clipboard": {
                f"{utils.get_app_url()},*": {
                    "expiration": "0",
                    "last_modified": int(time.time() * 1000),
                    "model": 0,
                    "setting": 1,
                }
            },
            "profile.default_content_setting_values.automatic_downloads": 1,
        }

        opts = webdriver.ChromeOptions()
        opts.add_experimental_option("prefs", prefs)

        # This configuration is for running on CI/CD (Jenkins)
        if (
            os.getenv("SL_RUN_ENVIRONMENT")
            and os.getenv("SL_RUN_ENVIRONMENT").upper() == "JENKINS"
        ):
            opts.add_argument("--no-sandbox")
            opts.add_argument("--disable-dev-shm-usage")

            # Help with some javascript issues
            display = Display(size=(1600, 900))
            display.start()

        service = Service(ChromeDriverManager().install())
        browser = webdriver.Chrome(service=service, options=opts)
    elif browser_name.lower() == "firefox":
        browser = webdriver.Firefox(GeckoDriverManager().install())
    elif browser_name.lower() == "safari":
        browser = webdriver.Safari()
    else:
        raise ValueError(
            f"{browser_name} is not defined. Please enter a valid browser."
        )

    browser.set_page_load_timeout(30)
    browser.implicitly_wait(30)
    browser.maximize_window()

    yield browser

    browser.quit()
    utils.delete_directory(download_dir, only_if_empty=True)
    if isinstance(display, Display):
        display.stop()
