const { defineConfig } = require('cypress');

const fs = require('fs');
const OTPAuth = require('otpauth');
const TestRailReporter = require('cypress-testrail');

const { callFunctionToCreateCase } = require('./customPlugins/ASX/createDataInSfdc.js');
const { authenticationTokenGenerationAndTicketDeletion } = require('./customPlugins/ASX/deleteDataInSfdc.js');
const onboardUser = require('./customPlugins/SLC/onboardUser');
const loginWithApi = require('./customPlugins/SLC/loginWithApi');
const fetchProfileData = require('./customPlugins/SLC/fetchProfileData');
const removeProfileData = require('./customPlugins/SLC/removeProfileData');
const checkSiteName = require('./cypress/utils/productionUtils');

require('dotenv').config();

module.exports = defineConfig({
  env: {
    // filter all specs first and only run the ones with a match
    grepFilterSpecs: true,
    // completely omit filtered tests instead of skipping them
    grepOmitFiltered: true,
    testrail: {
      projectId: 1,
      domain: process.env.TESTRAIL_DOMAIN,
      username: process.env.TESTRAIL_USERNAME,
      password: process.env.TESTRAIL_PASSWORD,
      runId: process.env.TESTRAIL_RUN_ID,
      screenshots: true,
    },
  },
  e2e: {
    defaultCommandTimeout: 15000,
    requestTimeout: 15000,
    retries: { runMode: 2 },
    testIsolation: process.env.PRODUCTION === false,
    setupNodeEvents(on, config) {
      require('@cypress/grep/src/plugin')(config);
      if (process.env.TESTRAIL_RUN_ID) new TestRailReporter(on, config).register();

      config.env = config.env || {};

      if (!process.env.PRODUCTION) {
        config.baseUrl = process.env.CYPRESS_BASE_URL || 'https://qa-automation.supportlogic.io/';
      } else {
        config.baseUrl = checkSiteName(process.env.CYPRESS_BASE_URL);
      }
      config.viewportWidth = +process.env.CYPRESS_VIEWPORT_WIDTH || 1920;
      config.viewportHeight = +process.env.CYPRESS_VIEWPORT_HEIGHT || 1080;
      // config.numTestsKeptInMemory = 0;
      config.env.autoWaitForLoaders = process.env.hasOwnProperty('CYPRESS_AUTO_WAIT_FOR_LOADERS') ? process.env.CYPRESS_AUTO_WAIT_FOR_LOADERS : true;

      config.env.userEmail = process.env.CYPRESS_EMAIL;
      config.env.userPassword = process.env.CYPRESS_PASSWORD;

      config.env.oktaDomain = process.env.OKTA_DOMAIN;
      config.env.oktaUsername = process.env.OKTA_USERNAME;
      config.env.oktaPassword = process.env.OKTA_PASSWORD;
      config.env.secretKey = process.env.OKTA_CLIENTID;

      config.env.normalUserEmail = process.env.NORMAL_USER_EMAIL;
      config.env.otpSecret = process.env.CYPRESS_OTP_TOKEN_KEY;

      // junit reporter config
      // enabled only in a CI environment
      if (process.env.CI) {
        config.reporter = 'cypress-multi-reporters';
        config.reporterOptions = {
          reporterEnabled: 'spec, mocha-junit-reporter',
          mochaJunitReporterReporterOptions: {
            mochaFile: 'cypress/results/results-[hash].xml',
          },
        };
      }

      on('task', {
        generateOtp(secretKey) {
          const totp = new OTPAuth.TOTP({ secret: secretKey });
          return totp.generate();
        },
      });

      on('before:run', async () => {
        if (!process.env.IS_ASX && !process.env.PRODUCTION) {
          const dataStoreFilePath = './cypress.env.json';
          const sessionCookie = await loginWithApi(config.baseUrl, config.env.userEmail, config.env.userPassword);
          const sessionCookieForNormalUser = await loginWithApi(config.baseUrl, config.env.normalUserEmail, config.env.userPassword);

          await onboardUser(config.baseUrl, sessionCookie);
          await onboardUser(config.baseUrl, sessionCookieForNormalUser);
          await console.log('Hooray! User onboarding completed.');

          await fetchProfileData(config.baseUrl, sessionCookie, dataStoreFilePath).then(() => console.log('Success! Fetched Profile data'));
        }
        if (process.env.IS_ASX && fs.existsSync(process.env.FILE_INPUT_NAME)) {
          await callFunctionToCreateCase();
        }
      });

      on('after:run', async () => {
        if (!process.env.IS_ASX) {
          removeProfileData().then(() => console.log('Profile data removed'));
        }
        if (process.env.IS_ASX) {
          await authenticationTokenGenerationAndTicketDeletion();
          if (fs.existsSync(process.env.FILE_OUTPUT_NAME)) {
            fs.unlinkSync(process.env.FILE_OUTPUT_NAME);
          }
          if (fs.existsSync('file.json')) {
            fs.unlinkSync('file.json');
          }
        }
      });

      return config;
    },
    experimentalInteractiveRunEvents: true,
    video: process.env.CYPRESS_ENABLE_VIDEO === 'true',
    blockHosts: ['js.amberflo.io', 'widget.freshworks.com'],
  },
});
