# E2E Tests
## Intro
This repository contains collection of E2E tests created using [Cypress](https://www.cypress.io/). For more information please visit:
- [Cypress E2E Developers Guide](https://supportlogic.atlassian.net/wiki/spaces/ENG/pages/1643773961/Cypress+E2E+Developers+Guide)
- [Automated Testing @ SupportLogic](https://supportlogic.atlassian.net/wiki/spaces/ENG/pages/1613987924/Automated+Testing+SupportLogic)

## Installation
### Prerequisites
1. [Node](https://nodejs.org/en/) (16.16.0 LTS) + npm
2. If you're using Linux, you'll want to have the required dependencies installed on your system:

**Ubuntu/Debian**
```
apt-get install libgtk2.0-0 libgtk-3-0 libgbm-dev libnotify-dev libgconf-2-4 libnss3 libxss1 libasound2 libxtst6 xauth xvfb
```

**CentOS**
```
yum install -y xorg-x11-server-Xvfb gtk2-devel gtk3-devel libnotify-devel GConf2 nss libXScrnSaver alsa-lib
```

### Installing dependencies
To install all the required dependencies simply run (this can take a couple of minutes):

```
npm install
```

After it you should install pre-commit hooks:
```
npm run prepare
```

### Environment Settings
Copy `.env.sample` to the same folder:

```
cp .env.sample .env
```

And fill up the following variables:

```
CYPRESS_BASE_URL=<instance target URL, e.g. https://qa-automation.supportlogic.io>
CYPRESS_ENABLE_VIDEO=<set to true/false depending on if you want to keep test suite screen recordings>

CYPRESS_EMAIL=<SL user's email>
CYPRESS_PASSWORD=<SL user's password>
CYPRESS_AUTO_WAIT_FOR_LOADERS=<true | false>
```

NOTE: `CYPRESS_AUTO_WAIT_FOR_LOADERS` should be set `true` when `SLC` is being tested and `false` when `ASX` is being tested.

## Running Tests
### With 'Cypress App'
Just run `npm start` command, and it will start Cypress App - main entrypoint for running test suite. You'll be prompted if you want to run "E2E Testing" or "Component Testing", choose the former. After it - you can start running any test from the list.

### Run with reporter
> **Warning**
> This feature isn't fully configured

If you want to just get report for a complete test suite, you can run `npm run cypress:run` command. It will automatically run all test specs and provide report
