module.exports = {
  plugins: ['cypress', 'filename-rules', 'folders'],
  env: {
    browser: true,
    es2021: true,
    mocha: true,
  },
  extends: ['airbnb-base', 'plugin:cypress/recommended', 'prettier'],
  parserOptions: {
    ecmaVersion: 'latest',
    sourceType: 'module',
  },
  rules: {
    'prefer-arrow-callback': 'off',
    'import/prefer-default-export': 'off',
    'func-names': ['error', 'always'],
    //camelcase: ['error', { properties: 'always' }],
    'filename-rules/match': [2, 'camelCase'],
    'folders/match-regex': [2, /^(?:[A-Z0-9]+|[a-zA-Z0-9-]+|[a-z0-9]+(?:[A-Z][a-z]*)*|[a-z]+)$/g, '/cypress/'],
    'class-methods-use-this': 'off',
    'cypress/unsafe-to-chain-command': 'off',
  },
  reportUnusedDisableDirectives: true,
};
