const checkSiteName = (targetUrl) => {
  const url = targetUrl.split('://')[1].split('.supportlogic.io')[0];
  // eslint-disable-next-line no-param-reassign
  if (url.toLowerCase() === 'eightbyeight') targetUrl = 'https://8x8.supportlogic.io';
  // eslint-disable-next-line no-param-reassign
  if (url.toLowerCase() === 'qlik2') targetUrl = 'https://qlik.supportlogic.io';
  // eslint-disable-next-line no-param-reassign
  if (url.toLowerCase() === 'sl4sl2') targetUrl = 'https://sl4sl.supportlogic.io';
  // eslint-disable-next-line no-param-reassign
  if (url.toLowerCase() === 'datarobot-sf') targetUrl = 'https://datarobot.supportlogic.io';
  // eslint-disable-next-line no-param-reassign
  if (url.toLowerCase() === 'salesforce') targetUrl = 'https://salesforce-old.supportlogic.io';
  // eslint-disable-next-line no-param-reassign
  if (url.toLowerCase() === 'salesforce-new') targetUrl = 'http://salesforce.supportlogic.io';
  // eslint-disable-next-line no-param-reassign
  if (url.toLowerCase() === 'financialforce') targetUrl = 'http://certinia.supportlogic.io';
  // eslint-disable-next-line no-param-reassign
  if (url.toLowerCase() === 'shiftleft') targetUrl = 'http://qwiet.supportlogic.io';

  return targetUrl;
};
module.exports = checkSiteName;
