let profileData = {};
try {
  // eslint-disable-next-line global-require,import/no-unresolved
  profileData = require('../../cypress.env.json').profileData;
} catch (e) {
  // eslint-disable-next-line no-console
  console.log('cypress.env.json not found!');
}
const nameRepo = profileData?.companySettings?.support?.custom_names_repo;

const standardLabels = {
  agent: 'agent',
  agents: 'agents',
  case: 'case',
  cases: 'cases',
  customer: 'customer',
  customers: 'customers',
};

const customLabels = {
  agent: nameRepo?.['agent.label'],
  agents: nameRepo?.['agent.label.plural'],
  case: nameRepo?.['case.label'],
  cases: nameRepo?.['case.label.plural'],
  customer: nameRepo?.['customer.label'],
  customers: nameRepo?.['customer.label.plural'],
};

export const labelHelper = profileData?.companySettings?.support?.custom_names_repo_type === 'customize' ? customLabels : standardLabels;

export const targetDatabase = profileData?.active_database || 'qa-automation';

export const currentUserName = profileData?.name;
