import { labelHelper } from './labelHelper';

const consoleHome = 'support/console';
const agentInsightsHome = `support/${labelHelper.agents.toLowerCase()}`;
const customerInsightsHome = 'support/customer-insights';

const operationalMetrics = 'support/operational-metrics';
const experientialMetrics = 'support/experiential-metrics';

const consoleTimeFilters = {
  today: 'timeFilter=Today',
  sinceYesterday: 'timeFilter=Since+yesterday',
  lastSevenDays: 'timeFilter=Last+7+days',
};
const consoleTabs = {
  newCases: `${consoleHome}?tab=Tickets`,
  escalations: `${consoleHome}?tab=Escalations`,
  needAttention: `${consoleHome}?tab=Need+attention`,
  productFeedback: `${consoleHome}?tab=Product+Feedback`,
  positiveSentiments: `${consoleHome}?tab=Positive+Sentiments`,
  negativeSentiments: `${consoleHome}?tab=Negative+Sentiments`,
  newEscalations: `${consoleHome}?tab=New+Escalations`,
  likelyToEscalate: `${consoleHome}?tab=Likely+to+Escalate`,
};

export const urlHelpers = {
  // Workspace
  myDashboard: 'support/my-dashboard',
  console: {
    home: consoleHome,
    withTimeFilter: {
      today: `${consoleHome}?${consoleTimeFilters.today}`,
      sinceYesterday: `${consoleHome}?${consoleTimeFilters.sinceYesterday}`,
      lastSevenDays: `${consoleHome}?${consoleTimeFilters.lastSevenDays}`,
    },
    tabs: consoleTabs,
    tabsWithTimeFilterToday: {
      newCases: `${consoleTabs.newCases}&${consoleTimeFilters.today}`,
      escalations: `${consoleTabs.escalations}&${consoleTimeFilters.today}`,
      needAttention: `${consoleTabs.needAttention}&${consoleTimeFilters.today}`,
      productFeedback: `${consoleTabs.productFeedback}&${consoleTimeFilters.today}`,
      positiveSentiments: `${consoleTabs.positiveSentiments}&${consoleTimeFilters.today}`,
      negativeSentiments: `${consoleTabs.negativeSentiments}&${consoleTimeFilters.today}`,
      newEscalations: `${consoleTabs.newEscalations}&${consoleTimeFilters.today}`,
      likelyToEscalate: `${consoleTabs.likelyToEscalate}&${consoleTimeFilters.today}`,
    },
    tabsWithTimeFilterSinceYesterday: {
      newCases: `${consoleTabs.newCases}&${consoleTimeFilters.sinceYesterday}`,
      escalations: `${consoleTabs.escalations}&${consoleTimeFilters.sinceYesterday}`,
      needAttention: `${consoleTabs.needAttention}&${consoleTimeFilters.sinceYesterday}`,
      productFeedback: `${consoleTabs.productFeedback}&${consoleTimeFilters.sinceYesterday}`,
      positiveSentiments: `${consoleTabs.positiveSentiments}&${consoleTimeFilters.sinceYesterday}`,
      negativeSentiments: `${consoleTabs.negativeSentiments}&${consoleTimeFilters.sinceYesterday}`,
      newEscalations: `${consoleTabs.newEscalations}&${consoleTimeFilters.sinceYesterday}`,
      likelyToEscalate: `${consoleTabs.likelyToEscalate}&${consoleTimeFilters.sinceYesterday}`,
    },
    tabsWithTimeFilterLastSevenDays: {
      newCases: `${consoleTabs.newCases}&${consoleTimeFilters.lastSevenDays}`,
      escalations: `${consoleTabs.escalations}&${consoleTimeFilters.lastSevenDays}`,
      needAttention: `${consoleTabs.needAttention}&${consoleTimeFilters.lastSevenDays}`,
      productFeedback: `${consoleTabs.productFeedback}&${consoleTimeFilters.lastSevenDays}`,
      positiveSentiments: `${consoleTabs.positiveSentiments}&${consoleTimeFilters.lastSevenDays}`,
      negativeSentiments: `${consoleTabs.negativeSentiments}&${consoleTimeFilters.lastSevenDays}`,
      newEscalations: `${consoleTabs.newEscalations}&${consoleTimeFilters.lastSevenDays}`,
      likelyToEscalate: `${consoleTabs.likelyToEscalate}&${consoleTimeFilters.lastSevenDays}`,
    },
  },
  alerts: 'support/alerts',
  myAgents: 'support/my-agents',
  myCustomers: 'support/my-customers',
  backlog: `support/${labelHelper.cases.toLowerCase()}`,

  // Escalation Management
  escalationBoard: 'support/escalations-board',
  escalationReport: 'support/escalations-report',

  // Case Assignment
  caseAssignment: `support/${labelHelper.case.toLowerCase()}-assignment`,
  shiftCalendar: 'support/shift-management',
  assignmentQueues: 'support/virtual-queues',

  // Quality Monitoring
  caseEvaluation: 'support/manual-qa',
  aceQaScorecards: 'support/qa-scorecards',

  // Agent Management
  agentInsights: {
    home: `${agentInsightsHome}/search`,
    agentPage(agentId) {
      return `${agentInsightsHome}/search?searchAgent=${agentId}`;
    },
    agentPageTabs(agentId, tabName) {
      return `${agentInsightsHome}/search?searchAgent=${agentId}&tab=${tabName}`;
    },
  },
  virtualTeams: 'support/virtual-teams',

  // Customer Management
  customerBoard: 'support/customer-board',
  customerInsights: {
    home: customerInsightsHome,
    customerPage(customerId) {
      return `${customerInsightsHome}?searchCustomer=${customerId}`;
    },
    customerPageTabs(customerId, tabName) {
      return `${customerInsightsHome}?searchCustomer=${customerId}&tab=${tabName}`;
    },
  },
  virtualAccounts: 'support/virtual-accounts',

  // Analytics
  operationalMetrics: {
    home: operationalMetrics,
    escalations: `${operationalMetrics}/escalations`,
    backlog: `${operationalMetrics}/backlog`,
    caseActivity: `${operationalMetrics}/caseActivity`,
    firstResponse: `${operationalMetrics}/firstResponse`,
    followUp: `${operationalMetrics}/followUp`,
    caseResolution: `${operationalMetrics}/caseResolution`,
  },
  experientialMetrics: {
    home: experientialMetrics,
    customerExperience: `${experientialMetrics}/customerExperience`,
    sentiments: `${experientialMetrics}/sentiments`,
  },

  kpiMetrics: 'support/kpi-metrics',
  trends: 'support/trends',
  topics: 'support/topics',

  controlCenter: {
    manageUsers: 'support/users',
    userEngagement: 'support/user-engagement',
    settingsHome: 'support/settings',
  },

  supportHubCasePage(caseId) {
    return `support/${labelHelper.cases}/${caseId}`;
  },
};
