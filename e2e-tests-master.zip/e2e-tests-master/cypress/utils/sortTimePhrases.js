export default function sortTimePhrases(times, inDescending = false) {
  const units = {
    second: 0,
    seconds: 0,
    minute: 1,
    minutes: 1,
    hour: 2,
    hours: 2,
    day: 3,
    days: 3,
    week: 4,
    weeks: 4,
    month: 5,
    months: 5,
    year: 6,
    years: 6,
  };

  function parseTimeSpan(value) {
    const timeSpan = value.replace(/^a\sfew|^an|^a/i, '1');
    return parseInt(timeSpan.split(' ')[0], 10);
  }

  function parseTimeUnit(value) {
    const key = value
      .replace(/^a\sfew|^an|^a|ago|\d/gi, '')
      .trim()
      .toLowerCase();
    return units[key];
  }

  const sortedByTimeSpan = times.sort((a, b) => parseTimeSpan(a) - parseTimeSpan(b));
  const sortedByUnit = sortedByTimeSpan.sort((a, b) => parseTimeUnit(a) - parseTimeUnit(b));

  const result = inDescending ? sortedByUnit.reverse() : sortedByUnit;
  cy.log(`After sorting: ${result}`);
  return result;
}
