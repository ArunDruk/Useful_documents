export const pages = [
  // Workspace
  'summary',
  'console',
  'alerts',
  'myAgents',
  'myCustomers',
  'cases',

  // escalation management
  'escalationsBoard',
  'escalationsReport',

  // case assignment
  'caseAssignment',
  'shiftManagement',
  'virtualQueues',

  // Quality monitoring
  'manualQA',
  'qaScorecards',

  // Agent management
  'agents',
  'virtualTeams',

  // Customer management
  'customerBoard',
  'customerInsights',
  'virtualAccounts',

  // Analytics
  'operationalMetrics',
  'experientialMetrics',
  'kpiMetrics',
  'metrics',
  'trends',
  'topics',
  'sentiments',

  // Agent workspaces

  // Workspace
  'agentCases',
  'agentBacklogList',
  'agentInsights',
  'agentSubscriptions',
];
