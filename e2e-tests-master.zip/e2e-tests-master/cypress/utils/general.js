export const randId = () => Cypress._.random(0, 1e6);

export const sortNumbers = (numberArray, inDescending = false) => numberArray.sort((a, b) => (inDescending ? b - a : a - b));

export const honorsOrder = (inputValues, orderArray) => {
  let prevIndex = -1;

  const uniqValues = new Set(inputValues);
  return [...uniqValues].every((value) => {
    const curIndex = orderArray.findIndex((x) => x === value);
    const result = curIndex > prevIndex;

    prevIndex = curIndex;

    return result;
  });
};

export const arrayEquals = (a, b) => Array.isArray(a) && Array.isArray(b) && a.length === b.length && a.every((val, index) => val === b[index]);

export function hexToRGBA(hex, alpha) {
  const hexValue = hex.replace(/^#/, '');
  const r = parseInt(hexValue.substring(0, 2), 16);
  const g = parseInt(hexValue.substring(2, 4), 16);
  const b = parseInt(hexValue.substring(4, 6), 16);
  const a = alpha >= 0 && alpha <= 1 ? alpha : 1;

  return `rgba(${r}, ${g}, ${b}, ${a})`;
}
