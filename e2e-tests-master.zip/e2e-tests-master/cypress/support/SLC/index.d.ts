// load the global Cypress types
/// <reference types="cypress" />

declare namespace Cypress {
  interface WaitOptions {
    /**
     * Waits for the global loader
     *
     * @default false
     */
    waitForGlobalLoader: boolean;
    /**
     * Waits for the other types of loaders
     *
     * @default true
     */
    waitForSkeletons: boolean;
    /**
     * Time to wait for the loaders (ms)
     *
     * @default 60000
     */
    timeout: number;
    /**
     * Amount of information to be included in the logs
     *
     * @default false
     */
    verbose: boolean;
  }

  interface Chainable {
    /**
     * Authenticate the current session using API
     * @example
     *    cy.loginByApi()
     *    cy.loginByApi('example@email.com', 'password')
     */
    loginByApi(email?: string, password?: string): void;

    /**
     * Authenticate the current session through Okta UI
     * @example
     *    cy.loginWithOktaUI()
     *    cy.loginWithOktaUI('oktaUsername', 'password')
     */
    loginWithOktaUI(username?: string, password?: string): void;

    /**
     * Get one or more DOM element by testid.
     * @example
     *    cy.getByTestId('testid')      // Yields all matching elements
     *    cy.getByTestId('testid').should('have.class', 'active')
     *    cy.getByTestId('testid', { timeout: 6000 }).click()
     */
    getByTestId(selector: string, options?: Partial<Loggable & Timeoutable & Withinable & Shadow>): Chainable<Element>;

    /**
     * Waits for all loaders to disappear.
     * @example
     *    cy.waitForLoaders() // Waits only for the skeleton loaders
     *    cy.waitForLoaders({waitForGlobalLoader: true}) // Waits for both the global and skeleton loaders
     *    cy.waitForLoaders({verbose: true}) // Increases the log details
     */
    waitForLoaders(options?: Partial<WaitOptions>);
  }
}
