const editModuleState = (pages) =>
  cy.request({
    method: 'POST',
    url: 'api/company/settings/support',
    body: {
      settings: {
        product_edition: 'PRODUCT_EDITION_CUSTOM',
        product_edition_settings: null,
        dashboard_restrictions: { pages },
      },
      replace: false,
      keys: ['product_edition'],
    },
  });

cy.slcHelpers = {
  getAgentIds(size = 20) {
    return cy
      .request({
        method: 'POST',
        url: 'api/v2/user/query',
        headers: { 'Content-Type': 'application/json' },
        body: {
          page_number: 0,
          page_size: size,
          sort_key: 's_created_at',
          sort_direction: 'asc',
          selected: ['id'],
          filter_list: [
            {
              column: 'sl_user_is_valid_assignee',
              op: '=',
              value: true,
            },
          ],
        },
      })
      .then(({ body }) => body.data.map(({ id }) => id));
  },

  deleteVgroup(id) {
    return cy.request('DELETE', `api/v2/group/${id}`);
  },

  createVT(name, agentIds) {
    return cy.request({
      method: 'POST',
      url: 'api/v2/group',
      headers: { 'Content-Type': 'application/json' },
      body: {
        name,
        gtype: 'virtual_team',
        is_public: true,
        owner: 'system',
        created_by: Cypress.env('userEmail'),
        account_ids: [],
        crm_user_ids: agentIds,
        email_user_ids: [],
        child_ids: [],
      },
    });
  },

  defaultToSupportHubThree() {
    return cy.request({
      method: 'PUT',
      url: '/api/users/dashboard_settings',
      headers: { 'Content-Type': 'application/json' },
      body: {
        dashboardName: 'support',
        settingsKey: 'support_hub_settings',
        settingsSubKey: null,
        settingsValue: { beta: { enabled: true, switchedBackBefore: true } },
        replace: false,
      },
    });
  },

  getCaseDetails({ predicates = [], ordering = [] }) {
    const selected = [
      '_sl_created_at',
      '_sl_last_modified_at',
      'contains_spans',
      'entities',
      'id',
      'is_deleted',
      'object_type',
      's_created_at',
      's_deleted_at',
      's_id',
      's_modified_at',
      's_object_id_creator',
      's_object_type_creator',
      's_seq_id',
      'signal_count',
      'sl_account_id',
      'sl_account_name',
      'sl_assignee_id',
      'sl_assignee_id_count_users_only',
      'sl_assignee_id_uniq_users_only',
      'sl_assignee_name',
      'sl_case_id',
      'sl_closed_at',
      'sl_comment_count',
      'sl_comment_ids',
      'sl_created_at',
      'sl_custom_fields',
      'sl_engineering_issues',
      'sl_escalated_at_first',
      'sl_escalated_at_last',
      'sl_escalation_count',
      'sl_escalation_history',
      'sl_escalation_type_last',
      'sl_first_escalation_prediction',
      'sl_first_response_time_ms',
      'sl_group_id',
      'sl_group_name',
      'sl_is_bot',
      'sl_is_closed',
      'sl_is_escalated',
      'sl_is_internal',
      'sl_is_partner',
      'sl_is_predicted_to_escalate',
      'sl_last_follow_up_time_ms',
      'sl_last_inbound_ms',
      'sl_last_outbound_ms',
      'sl_max_follow_up_time_ms',
      'sl_most_recent_comment',
      'sl_most_recent_comment_is_ib',
      'sl_most_recent_inbound',
      'sl_most_recent_outbound',
      'sl_need_attention_score',
      'sl_num_participants',
      'sl_num_participants_ib',
      'sl_num_participants_ob',
      'sl_open_time_ms',
      'sl_participants',
      'sl_participants_ib',
      'sl_participants_ob',
      'sl_priority',
      'sl_priority_n',
      'sl_requester_email',
      'sl_requester_id',
      'sl_requester_name',
      'sl_sentiment_score',
      'sl_span_counts',
      'sl_status',
      'sl_status_n',
      'sl_subject',
      'sl_ticket_id',
      'sl_updated_at',
      'sl_wait_time_inbound_ms',
      'sl_wait_time_outbound_ms',
    ];

    return cy.request({
      method: 'POST',
      url: '/api/v2/case/summary/search?page_number=0&page_size=100',
      headers: { 'Content-Type': 'application/json' },
      body: { selected, predicates, ordering },
    });
  },

  enableModule(moduleName) {
    let moduleNames;
    if (typeof moduleName === 'string') {
      moduleNames = moduleName.split();
    }
    return editModuleState(moduleNames.reduce((k, v) => ({ ...k, [v]: true }), {}));
  },

  disableModule(moduleName) {
    let moduleNames;
    if (typeof moduleName === 'string') {
      moduleNames = moduleName.split();
    }
    return editModuleState(moduleNames.reduce((k, v) => ({ ...k, [v]: false }), {}));
  },

  lockModule(moduleName) {
    let moduleNames;
    if (typeof moduleName === 'string') {
      moduleNames = moduleName.split();
    }
    return editModuleState(moduleNames.reduce((k, v) => ({ ...k, [v]: null }), {}));
  },

  getAgentDetails(size = 20) {
    return cy
      .request({
        method: 'POST',
        url: 'api/v2/user/query',
        headers: { 'Content-Type': 'application/json' },
        body: {
          page_number: 0,
          page_size: size,
          sort_key: 's_created_at',
          sort_direction: 'asc',
          selected: [
            'id',
            's_id',
            'sl_name',
            'sl_email',
            'sl_account_id',
            'sl_custom_fields',
            'sl_time_zone',
            'sl_created_at',
            'sl_updated_at',
            'sl_active_hours_predicted',
            'sl_user_is_valid_assignee',
            'sl_first_requested_case_date',
            'sl_last_requested_case_date',
          ],
          filter_list: [{ column: 'sl_user_is_valid_assignee', op: '=', value: true }],
        },
      })
      .then(({ body }) => body.data);
  },

  disableCustomersQuickFilter() {
    return cy.request({
      method: 'PUT',
      url: '/api/users/dashboard_settings/deep/support/filter_ui_settings_v2/quick_filter_customers_disabled',
      headers: { 'Content-Type': 'application/json' },
      body: {
        settingsValue: true,
        replace: true,
      },
    });
  },

  disableAgentsQuickFilter() {
    return cy.request({
      method: 'PUT',
      url: '/api/users/dashboard_settings/deep/support/filter_ui_settings_v2/quick_filter_agents_disabled',
      headers: { 'Content-Type': 'application/json' },
      body: {
        settingsValue: true,
        replace: true,
      },
    });
  },

  disableCaseFieldsQuickFilter() {
    return cy.request({
      method: 'PUT',
      url: '/api/users/dashboard_settings/deep/support/filter_ui_settings_v2/quick_filter_case_fields_disabled',
      headers: { 'Content-Type': 'application/json' },
      body: {
        settingsValue: true,
        replace: true,
      },
    });
  },

  clearCustomersQuickFilter() {
    return cy.request({
      method: 'PUT',
      url: 'api/users/dashboard_settings/deep/support/filter_ui_settings_v2/quick_filter_customers',
      headers: { 'Content-Type': 'application/json' },
      body: {
        settingsValue: {},
        replace: true,
      },
    });
  },

  clearAgentsQuickFilter() {
    return cy.request({
      method: 'PUT',
      url: 'api/users/dashboard_settings/deep/support/filter_ui_settings_v2/quick_filter_agents',
      headers: { 'Content-Type': 'application/json' },
      body: {
        settingsValue: {},
        replace: true,
      },
    });
  },

  clearCaseFieldQuickFilter() {
    return cy.request({
      method: 'PUT',
      url: 'api/users/dashboard_settings/deep/support/filter_ui_settings_v2/quick_filter_case_fields',
      headers: { 'Content-Type': 'application/json' },
      body: {
        settingsValue: {},
        replace: true,
      },
    });
  },

  deleteGlobalFilter() {
    return cy.request({
      method: 'PUT',
      url: '/api/users/dashboard_settings',
      headers: { 'Content-Type': 'application/json' },
      body: {
        dashboardName: 'support',
        settingsKey: 'filter_ui_settings_v2',
        settingsSubKey: 'scope_filters_by_id',
        settingsValue: {},
        replace: true,
      },
    });
  },

  getCustomerDetails(size = 20, withLeastCases = false) {
    const sortDirection = withLeastCases === false ? 'desc' : 'asc';

    return cy
      .request({
        method: 'POST',
        url: `api/v2/customer_metric/search?page_number=0&page_size=${size}&aggregation_label=all`,
        body: {
          record_types: ['individual_account'],
          selected: [
            'id',
            'native_id',
            'parent_id',
            'record_type',
            'name',
            'created_by',
            'owner',
            'sl_custom_fields',
            'customer_score',
            'is_partner_flag',
            'is_public_flag',
            'churn_risk_latest_date',
            'churn_risk_num_cases',
            'escalation_total_num',
            'escalation_total_active_num',
            'escalation_latest_date',
            'escalation_likely_num',
            'cases_total_num',
            'cases_total_open',
            'cases_first_creation_date',
            'cases_last_creation_date',
            'cases_last_inbound_msg_date',
            'cases_prod_issues_num',
            'cases_critical_issues_num',
            'cases_escalation_requests_num',
            'created_at',
            'updated_at',
            'account_health_score',
          ],
          ordering: [{ column: 'cases_total_num', direction: sortDirection }],
          predicates: [{ column: 'cases_total_num', op: '>=', value: '1' }],
        },
      })
      .then(({ body }) => body);
  },

  getVirtualAccountCustomerDetails(size = 20, withLeastCases = false) {
    const sortDirection = withLeastCases === false ? 'desc' : 'asc';

    return cy
      .request({
        method: 'POST',
        url: `api/v2/customer_metric/search?page_number=0&page_size=${size}&aggregation_label=all`,
        body: {
          record_types: ['virtual_account'],
          selected: [
            'id',
            'native_id',
            'parent_id',
            'record_type',
            'name',
            'created_by',
            'owner',
            'sl_custom_fields',
            'customer_score',
            'is_partner_flag',
            'is_public_flag',
            'churn_risk_latest_date',
            'churn_risk_num_cases',
            'escalation_total_num',
            'escalation_total_active_num',
            'escalation_latest_date',
            'escalation_likely_num',
            'cases_total_num',
            'cases_total_open',
            'cases_first_creation_date',
            'cases_last_creation_date',
            'cases_last_inbound_msg_date',
            'cases_prod_issues_num',
            'cases_critical_issues_num',
            'cases_escalation_requests_num',
            'created_at',
            'updated_at',
            'account_health_score',
          ],
          ordering: [{ column: 'cases_total_num', direction: sortDirection }],
          predicates: [{ column: 'cases_total_num', op: '>=', value: '1' }],
        },
      })
      .then(({ body }) => body);
  },

  getDetailsOfAgentsWithCases(size = 20, withLeastCases = false) {
    // 1 is ascending; -1 is descending
    const sortDirection = withLeastCases === false ? 1 : -1;

    return cy
      .request({
        method: 'POST',
        url: 'api/v2/stats/grouped',
        body: {
          table: 'case_summary',
          column: 'sl_assignee_id',
          operation: 'count',
          target_column: 'id',
          predicates: [{ column: 'sl_assignee_id', op: 'not_null' }],
        },
      })
      .then(({ body }) => Object.fromEntries(Object.entries(body).sort(([, leftVal], [, rightVal]) => sortDirection * (rightVal - leftVal))))
      .then((sortedAgentIds) => {
        cy.request({
          method: 'POST',
          url: 'api/v2/user/get_by_ids',
          body: {
            user_ids: { ids: Object.keys(sortedAgentIds).slice(0, size) },
            selected: [
              'id',
              's_id',
              'sl_name',
              'sl_email',
              'sl_account_id',
              'sl_custom_fields',
              'sl_time_zone',
              'sl_created_at',
              'sl_updated_at',
              'sl_active_hours_predicted',
              'sl_user_is_valid_assignee',
              'sl_first_requested_case_date',
              'sl_last_requested_case_date',
            ],
            ordering: [],
          },
        });
      })
      .then(({ body }) => body);
  },
};
