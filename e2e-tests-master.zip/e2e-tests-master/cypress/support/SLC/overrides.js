Cypress.Commands.overwrite('visit', (originalFn, url, { waitUntilLoads = Cypress.env('autoWaitForLoaders'), waitForSkeletons = true, ...options } = {}) => {
  originalFn(url, options);
  // make sure to add a return here!
  return cy.get('body').then(() => {
    if (waitUntilLoads) {
      return cy.waitForLoaders({ waitForSkeletons, waitForGlobalLoader: true, verbose: true });
    }

    return true;
  });
});
