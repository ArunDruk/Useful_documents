Cypress.Commands.add('getByTestId', (selector, options) => cy.get(`[data-testId='${selector}']`, options));
