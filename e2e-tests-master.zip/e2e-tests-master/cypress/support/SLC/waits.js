const checkTimeout = 60000;
const loaderCheckDelay = 500;
const votingThreshold = 3;

Cypress.Commands.add('waitForLoaders', ({ waitForGlobalLoader, waitForSkeletons = true, timeout = checkTimeout, verbose } = {}) => {
  let seenGlobalLoader = false;
  const loadingCompleteVotes = [];

  return cy.waitUntil(
    () => {
      if (waitForGlobalLoader && !seenGlobalLoader && Cypress.$('[data-is-global-loader="true"]').length === 0) {
        // There should be at least a global loader, wait for it...
        seenGlobalLoader = true;

        return false;
      }

      // Use voting + delayed check:
      // voting is about storing history of checks - resolve it only if the last 3 votes are true
      // delayed check helps with subsequent loaders we might have in the app
      return new Promise((resolve) => {
        setTimeout(() => {
          const noLoaders = Cypress.$('[data-is-loader="true"]').length === 0 && (!waitForSkeletons || Cypress.$('[data-is-skeleton-loader="true"]').length === 0);

          loadingCompleteVotes.push(noLoaders);
          resolve(loadingCompleteVotes.slice(-votingThreshold).filter(Boolean).length >= votingThreshold);
        }, loaderCheckDelay);
      });
    },
    { verbose, timeout }
  );
});
