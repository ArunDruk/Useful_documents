import { apiHelpers } from '../../pages';

Cypress.Commands.addAll({
  loginByApi(email = Cypress.env('userEmail'), password = Cypress.env('userPassword')) {
    cy.session(
      email,
      () => {
        cy.request({
          method: 'POST',
          url: 'login/local',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: `email=${encodeURIComponent(email)}&passwd=${encodeURIComponent(password)}`,
        });

        apiHelpers.setUserRole();
        apiHelpers.onboardCurrentUser();
      },
      {
        validate() {
          cy.request('api/v2/system/last_sync').its('status').should('equal', 200);
        },
        cacheAcrossSpecs: true,
      }
    );
  },

  loginWithOktaUI(username = Cypress.env('oktaUsername'), password = Cypress.env('oktaPassword')) {
    cy.intercept('/api/v1/authn*').as('waitForMfaPage');

    cy.session(
      `okta-${username}`,
      () => {
        const log = Cypress.log({
          displayName: 'Okta Login',
          message: [`🔐 Authenticating | ${username}`],
          autoEnd: false,
        });
        log.snapshot('before');

        cy.visit('identity/sladmin');
        cy.getByTestId('loginPage-form-oktaSignInBtn').click();

        cy.origin(Cypress.env('oktaDomain'), { args: { _username: username, _password: password } }, ({ _username, _password }) => {
          cy.get('#okta-signin-username').type(_username);
          cy.get('#okta-signin-password').type(_password);
          // eslint-disable-next-line cypress/no-unnecessary-waiting
          cy.wait(1000);
          cy.get('#okta-signin-submit').click();
          cy.wait('@waitForMfaPage');

          cy.task('generateOtp', Cypress.env('secretKey')).then((otp) => cy.get('[data-se=o-form-input-answer]').type(otp));
          cy.get('input[data-type=save]').click();
          // eslint-disable-next-line cypress/no-unnecessary-waiting
          cy.wait(5000);
        });

        apiHelpers.setUserRole();
        // TODO: Uncomment after updating the below request body (Person of Contact: Faical Arab)
        // apiHelpers.resetSlUserModuleOnboardingState();
        apiHelpers.onboardCurrentUser();

        log.snapshot('after');
        log.end();
      },
      {
        validate() {
          cy.request('api/v2/system/last_sync').its('status').should('equal', 200);
        },
        cacheAcrossSpecs: true,
      }
    );
  },
});
