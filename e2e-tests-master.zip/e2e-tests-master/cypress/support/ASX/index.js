/* eslint-disable no-unused-vars */
import { authenticator } from 'otplib';

const secretKey = Cypress.env('otpSecret');

Cypress.on('uncaught:exception', (err, runnable) => false);

Cypress.Commands.add('loginAgentSX', (email = Cypress.env('userEmail'), password = Cypress.env('userPassword')) => {
  Cypress.session.clearAllSavedSessions();
  cy.session(
    'AGENTSX_LOGIN',
    () => {
      cy.origin('https://login.salesforce.com/', { args: { _email: email, _password: password } }, ({ _email, _password }) => {
        cy.visit(`${Cypress.config().baseUrl}/asx/salesforce/login`);
        cy.get('#username').clear();
        cy.get('#username').type(_email);
        cy.get('#password').type(_password);
        cy.get('#rememberUn').check();
        cy.get('#Login').click();
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(2000);
      });

      const codeGenerated = authenticator.generate(secretKey);
      const code = codeGenerated.toString();
      cy.origin('https://supportlogic-4a-dev-ed.develop.my.salesforce.com/', { args: { _code: code } }, ({ _code }) => {
        cy.get('#tc').type(_code);
        cy.get('#save').click();
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(5000);
      });
    },
    { cacheAcrossSpecs: true }
  );

  cy.visit('/');
});
