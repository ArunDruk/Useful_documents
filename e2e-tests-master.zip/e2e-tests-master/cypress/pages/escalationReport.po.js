class EscalationReport {
  exportAsCsvButton() {
    return cy.getByTestId('escalations-listView-exportAsCsvBtn');
  }

  commonTableHeader(columnName) {
    if (columnName) {
      return cy.getByTestId(`table-header-cell_${columnName}`);
    }
    return cy.get('[data-testid^=table-header-cell_]');
  }

  commonTableHeaderInfoIcon(columnName) {
    // TODO: For data-testid, refer https://supportlogic.atlassian.net/browse/SLC-35096
    return this.commonTableHeader(columnName).find('[class^=styles__InfoIconWrapper]');
  }

  // Request for data-testid https://supportlogic.atlassian.net/browse/SLC-35661
  commonTableRowCaseIdLabel() {
    return cy.get('[class^="CaseIdPlaceholder__CaseIdCell-sc"]');
  }

  infoIconTooltip() {
    // TODO: For data-testid, refer https://supportlogic.atlassian.net/browse/SLC-35096
    return cy.get('[class^=styles__PopperContainer]');
  }

  escalationStatusTooltip() {
    // TODO: For data-testid, refer https://supportlogic.atlassian.net/browse/SLC-35096
    return cy.get('[class^=EscStatusPopupContent__Container]');
  }

  escalationStatusTooltipTitle() {
    // TODO: For data-testid, refer https://supportlogic.atlassian.net/browse/SLC-35096
    return cy.get('[class^=EscStatusPopupContent__Title]');
  }

  escalationStatusTooltipRow() {
    // TODO: For data-testid, refer https://supportlogic.atlassian.net/browse/SLC-35096
    return cy.get('[class^=EscStatusPopupContent__Row]');
  }

  escalationsValueMetricsNavIcon() {
    return cy.getByTestId('escalationsPage-reportBtn');
  }

  escalationPageGoBackButton() {
    return cy.getByTestId('escalationPage-goBack-Btn');
  }

  escalationValueMetricsContainer() {
    return cy.getByTestId('escalationsValueMetricsPage-container');
  }

  // Request for data-testid https://supportlogic.atlassian.net/browse/SLC-35661
  escalationValueMetricsTab() {
    return cy.get('[data-testid="escalationsValueMetricsPage-container"] span[class^="sc"]');
  }

  // Request for data-testid https://supportlogic.atlassian.net/browse/SLC-35661
  escalationValueMetricsShowClosedCasesToggle() {
    return cy.get('[class^="styles__Element-sc-"]');
  }

  // Request for data-testid https://supportlogic.atlassian.net/browse/SLC-35661
  escalationValueMetricsAgentFilterButton() {
    return cy.get('[class^="EscalationValueMetricsManager__Pill-"]');
  }
}

export const escalationReport = new EscalationReport();
