class CustomerFavorites {
  zeroStateAddFavoriteButton() {
    // TODO: Get data-testid for empty state Add Favorite button
    return cy.contains('button', 'Add a new favorite');
  }

  addFavoriteButton() {
    return cy.getByTestId('customers-addFavorite-addButton');
  }

  searchTextfield() {
    return cy.getByTestId('customers-addFavorite-searchInput');
  }

  searchResultsListItem() {
    return cy.get('[data-testid^=favCustomers__search__results__item]');
  }

  searchTextFieldResultListFirst() {
    return cy.getByTestId('favCustomers__search__results__item-0');
  }

  // TODO data-testid requested via SLC-35735.
  favoritesTableSortColumnIcon() {
    return cy.get('[class^="HeaderColumn__SortByTrigger-sc"]');
  }

  favoritesTableRow() {
    return cy.getByTestId('favCustomers__table__row');
  }

  favoritesTableCustomerNameLabel() {
    return cy.getByTestId('favCustomers__table__customerName');
  }

  favoritesTableMenuButton() {
    return cy.getByTestId('favCustomers__table__customerMenu__trigger');
  }

  favoritesTableTooltipTriggerIcon() {
    return cy.getByTestId('hint__trigger');
  }

  // TODO data-testid requested via SLC-35735.
  myCustomersPageHeaderTitle() {
    return cy.get('[class^="BaseLayout__Header-sc"]');
  }

  // TODO data-testid requested via SLC-35735.
  myCustomersPageBackTocustomersLinkButton() {
    return cy.get('[class^="BaseLayout__BackLink-sc"]');
  }

  // TODO data-testid requested via SLC-35735.
  favoritesTableCustomerScoreHeaderTitle() {
    return cy.get('[data-column="customerScore"] [class^="HeaderColumn__Title-sc"]');
  }

  // TODO data-testid requested via SLC-35735.
  favoritesTableAttentionScoreHeaderTitle() {
    return cy.get('[data-column="attentionScore"] [class^="HeaderColumn__Title-sc"]');
  }

  // TODO data-testid requested via SLC-35735.
  favoritesTableSentimentScoreHeaderTitle() {
    return cy.get('[data-column="sentimentScore"] [class^="HeaderColumn__Title-sc"]');
  }

  // TODO data-testid requested via SLC-35735.
  favoritesTableHealthScoreHeaderTitle() {
    return cy.get('[data-column="healthScore"] [class^="HeaderColumn__Title-sc"]');
  }

  // TODO data-testid requested via SLC-35735.
  favoritesTableNewCasesHeaderTitle() {
    return cy.get('[data-column="newCases"] [class^="HeaderColumn__Title-sc"]');
  }

  // TODO data-testid requested via SLC-35735.
  favoritesTableOpenCasesHeaderTitle() {
    return cy.get('[data-column="openCases"] [class^="HeaderColumn__Title-sc"]');
  }

  // TODO data-testid requested via SLC-35735.
  favoritesTableActiveEscalationsCasesHeaderTitle() {
    return cy.get('[data-column="activeEscalations"] [class^="HeaderColumn__Title-sc"]');
  }

  // TODO data-testid requested via SLC-35735.
  favoritesTableTotalEscalationsCasesHeaderTitle() {
    return cy.get('[data-column="totalEscalations"] [class^="HeaderColumn__Title-sc"]');
  }

  // TODO data-testid requested via SLC-35735.
  favoritesTableHeaderSubtitle() {
    return cy.get('[class^="HeaderColumn__Subtitle-sc"]');
  }

  // TODO data-testid requested via SLC-35735.
  customerScoreTooltipHeaderFirst() {
    return cy.get('[class^="CustomerScoreInfo__Header-sc"]');
  }

  // TODO data-testid requested via SLC-35735.
  customerScoreTooltipHeaderSecond() {
    return cy.get('._6hXL6OaoNPFFAIjtxtXse');
  }

  // TODO data-testid requested via SLC-35735.
  attentionScoreTooltipHeaderFirst() {
    return cy.get('[class^="AttentionScoreInfo__Header-sc"]');
  }

  // TODO data-testid requested via SLC-35735.
  attentionScoreTooltipHeaderSecond() {
    return cy.get('._3UjuZqEdqb5rEafvDeU-66');
  }

  // TODO data-testid requested via SLC-35735.
  sentimentScoreTooltipHeaderFirst() {
    return cy.get('[class^="SentimentScoreInfo__Header-sc"]');
  }

  // TODO data-testid requested via SLC-35735.
  sentimentScoreTooltipHeaderSecond() {
    return cy.get('._1O7myRKJiv9vdDJlz9O5S');
  }

  // TODO data-testid requested via SLC-35735.
  healthScoreTooltipHeaderFirst() {
    return cy.get('[class^="AHSInfo__Title-sc"]');
  }

  // TODO data-testid requested via SLC-35735.
  healthScoreTooltipHeaderSecond() {
    return cy.get('[class^="AHSInfo__KYSItem-sc"]');
  }

  // TODO data-testid requested via SLC-35735.
  healthScoreTooltipHeaderThird() {
    return cy.get('[class^="AHSInfo__KYSItemDescription-sc"]');
  }

  // TODO data-testid requested via SLC-35735.
  favoritesTableDropdownMenuTrigger() {
    return cy.get('[class^="HeaderColumn__MenuTrigger-sc"]');
  }

  // TODO data-testid requested via SLC-35735.
  favoritesTableDropdownOption() {
    return cy.get('[class^="HeaderMenu__ItemContainer-sc"]');
  }

  // TODO data-testid requested via SLC-35735.
  favoritesTableCustomerScoreColumn() {
    return cy.get('[class^="CustomerScoreColumn__Container-sc-"]');
  }

  // TODO data-testid requested via SLC-35735.
  favoritesTableAttentionScoreColumn() {
    return cy.get('[class^="AttentionScoreColumn__Container-sc"]');
  }

  // TODO data-testid requested via SLC-35735.
  favoritesTableSentimentScoreColumn() {
    return cy.get('[class^="SentimentScoreColumn__Container-sc"] [class^="ScoreIndicator-sc"]');
  }

  // TODO data-testid requested via SLC-35735.
  favoritesTableHealthScoreColumn() {
    return cy.get('[class^="AHSBadge__Score-sc"]');
  }

  // TODO data-testid requested via SLC-35735.
  favoritesTableCasesCountColumn() {
    return cy.get('[class^="CountColumn__Label-sc"]');
  }

  // TODO data-testid requested via SLC-35735.
  favoritesTableTicketsPopupHeaderTitle() {
    return cy.get('._19iJUlxJktwt3DYEVe6zbo');
  }

  // TODO data-testid requested via SLC-35735.
  favoritesTableTicketsPopupCasesCount() {
    return cy.get('._1WVGRrCE1SbWLLmje_AG9m > :nth-child(2)');
  }

  caseListEscalatedLabel() {
    return cy.getByTestId('escalated');
  }

  removeFavoriteButton() {
    return cy.getByTestId('favCustomers__table__customerMenu__removeButton');
  }

  caseCountLabel() {
    return cy.contains('[class^=CountColumn__Label]', /\d+/);
  }

  caseListItem() {
    return cy.getByTestId('common-caseList-sideListItem');
  }

  favoritesExportButton() {
    return cy.getByTestId('favCustomers__table__exportButton');
  }

  searchFor(searchText) {
    cy.intercept('POST', 'search/virtual_groups/_search*').as('searchCustomer');

    this.searchTextfield().type(searchText);
    cy.wait('@searchCustomer');
  }
}

export const customerFavorites = new CustomerFavorites();
