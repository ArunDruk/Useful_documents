const randId = () => Cypress._.random(0, 1e6);

export class VirtualTeamPageObject {
  // Virtual Team
  createVirtualTeamButton() {
    return cy.getByTestId('virtualAccounts-groupList-virtual_team-createButton');
  }

  searchVirtualTeamInput() {
    return cy.getByTestId('virtualAccounts-groupList-virtual_team-searchInput');
  }

  searchResultVirtualTeamList() {
    return cy.getByTestId('virtualAccounts-virtual_team-listItem-label');
  }

  expandAllVirtualTeamButton() {
    return cy.getByTestId('virtual_team-expand-overall_button');
  }

  expandAllVirtualOrgsButton() {
    return cy.getByTestId('virtual_teams_group-expand-overall_button');
  }

  agentNameInVirtualTeamList() {
    return cy.getByTestId('virtualAccounts-virtual_team-listItem');
  }

  // waiting for the data-testid SLC-33506
  agentNamesInVirtualTeamList() {
    return cy.get('[data-testid="common-scrollList"] .styles__Label-sc-3rijla-4');
  }

  deleteVirtualTeamButton() {
    return cy.getByTestId('virtualAccounts-listItem-virtual_team-delete');
  }

  confirmDeleteVirtualTeamPopupButton() {
    return cy.getByTestId('virtual-primary-team-alert-modal-btn_delete');
    // cy.getByTestId('common-button').contains('Delete');
  }

  editVirtualTeamSaveButton() {
    return cy.getByTestId('common-button').contains('Save');
  }

  editVirtualTeamCancelButton() {
    return cy.getByTestId('common-button').contains('Cancel');
  }

  vtFilterTrigger() {
    return cy.getByTestId('virtualAccounts-groupList-virtual_team-filter_trigger');
  }

  vtFilterGlobalVirtualTeamCheckboxStatus() {
    return cy.getByTestId('animated-checkbox-default-group-Global Virtual Team-id').invoke('attr', 'data-status');
  }

  vtFilterPersonalVirtualTeamCheckboxStatus() {
    return cy.getByTestId('animated-checkbox-default-group-Personal Virtual Team-id').invoke('attr', 'data-status');
  }

  // Virtual Team Create Popup
  teamTypeGlobalButton() {
    return cy.getByTestId('virtualAccounts-chooseAccountType-global_team');
  }

  teamTypePersonalButton() {
    return cy.getByTestId('virtualAccounts-chooseAccountType-personal_team');
  }

  virtualTeamNameInput() {
    return cy.getByTestId('virtualAccounts-nameInput-searchInput');
  }

  vtCreatePopupNextOrSubmitButton() {
    return cy.getByTestId('virtualAccounts-createAccount-submitButton');
  }

  vtCreatePopupSearchCustomerNameInput() {
    return cy.getByTestId('virtualAccounts-searchBox-searchInput');
  }

  vtCreatePopupCustomerSearchResultList() {
    return cy.getByTestId('virtualAccounts-searchList-resultItem');
  }

  vtCreatePopupCustomerNameInSearchResultList() {
    return cy.get('[data-testid="virtualAccounts-searchList-resultItem"] span');
  }

  // waiting for the data-testid SLC-33506
  vtEditCustomerNameInSearchResultList() {
    return cy.get('[data-testid="virtualAccounts-searchList-resultItem"] .styles__Label-sc-1hwj5e1-3');
  }

  // waiting for the data-testid SLC-33506
  editVirtualTeamNameButton() {
    return cy.get('[class^="styles__LabelWrapper-sc-"]');
  }

  editVirtualTeamNameInput() {
    return cy.get('#virt-entity-name');
  }

  // waiting for the data-testid SLC-33506
  editVirtualTeamSelectedAgentNameLabel() {
    return cy.get('[data-testid="common-scrollList"] [class^=styles__Label-sc]');
  }

  // waiting for the data-testid SLC-33506
  editVirtualTeamSelectedAgentRemoveIcon() {
    return cy.get('[data-testid="common-scrollList"] [class^=styles__RemoveIcon]');
  }

  vtContentWrapperParentDiv() {
    return cy.get('[data-testid="virtual-teams-src-content-wrapper"]');
  }

  virtualOrgsNoDataLabel() {
    return '[data-testid="virtual_teams_group-zero-state-contianer"]';
  }

  setAsYourTeamPopupParentDiv() {
    return cy.get('#page-modal');
  }

  // waiting for the data-testid SLC-33506
  setAsYourTeamPopup() {
    return '.styles__Container-sc-1gb9eu9-0';
  }

  // waiting for the data-testid SLC-33506
  setAsYourTeamPopupCloseButton() {
    return cy.get('[class^="styles__CloseButtonWrapper-sc-"]');
  }

  setAsYourTeamButton(vtName) {
    return cy.contains(vtName).parents('[data-testid="virtualAccounts-virtual_team-listItem"]').find('[data-testid="virtualAccounts-listItem-virtual_team-primary"]');
  }

  editVirtualTeamButton(vtName) {
    return cy.contains(vtName).parents('[data-testid="virtualAccounts-virtual_team-listItem"]').find('[data-testid="virtualAccounts-listItem-virtual_team-edit"]');
  }

  copyVirtualTeamButton(vtName) {
    return cy.contains(vtName).parents('[data-testid="virtualAccounts-virtual_team-listItem"]').find('[data-testid="virtualAccounts-listItem-virtual_team-clone"]');
  }

  // waiting for the data-testid SLC-33506
  deleteWarningMessageLabel() {
    return cy.get('[class^="styles__DeleteWarning-sc-"]');
  }

  closeSetAsYourTeamPopup() {
    this.setAsYourTeamPopupParentDiv().then((popup) => {
      if (popup.find(this.setAsYourTeamPopup()).length) {
        this.setAsYourTeamPopupCloseButton().click();
      }
    });
  }

  // Virtual Orgs
  // waiting for the data-testid SLC-33506
  virtualTeamPageTitleLabel() {
    return cy.get('#app_wrapper [class^="styles__Title-sc-"]');
  }

  createVirtualOrgsButton() {
    return cy.getByTestId('virtualAccounts-groupList-virtual_teams_group-createButton');
  }

  virtualOrgsNameLists() {
    return cy.getByTestId('virtualAccounts-virtual_teams_group-listItem-label');
  }

  virtualOrgsEditButton() {
    return cy.getByTestId('virtualAccounts-listItem-virtual_teams_group-edit');
  }

  virtualOrgsCopyButton() {
    return cy.getByTestId('virtualAccounts-listItem-virtual_teams_group-clone');
  }

  virtualOrgsDeleteButton() {
    return cy.getByTestId('virtualAccounts-listItem-virtual_teams_group-delete');
  }

  // Virtual Orgs Create Popup
  OrgsTypeGlobalButton() {
    return cy.getByTestId('virtualAccounts-chooseAccountType-global_org');
  }

  OrgsTypePersonalButton() {
    return cy.getByTestId('virtualAccounts-chooseAccountType-personal_org');
  }

  /**
   * Creating the Virtual Team of specified AccountType with two customers
   * @param teamType to be 'Global' or 'Personal'
   * @returns the created Virtual Team Name
   */
  createVirtualTeam(teamType) {
    cy.intercept('POST', 'api/v2/group').as('createGroup');
    cy.intercept('search/virtual_groups/_search*').as('search');
    this.createVirtualTeamButton().scrollIntoView().should('be.visible').click();
    // Selecting the Global or Personal Team
    if (teamType === 'Global') {
      this.teamTypeGlobalButton().should('be.visible').click();
    }
    if (teamType === 'Personal') {
      this.teamTypePersonalButton().should('be.visible').click();
    }
    const virtualTeam = `Test ${teamType} Team ${randId()}`;
    this.virtualTeamNameInput().type(virtualTeam);
    this.vtCreatePopupNextOrSubmitButton().should('be.visible').click();
    this.vtCreatePopupSearchCustomerNameInput().should('be.visible').type('a');
    cy.wait('@search');
    this.vtCreatePopupCustomerSearchResultList().eq(0).click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(2000);
    this.vtCreatePopupCustomerSearchResultList().eq(1).click();
    this.vtCreatePopupCustomerNameInSearchResultList()
      .eq(0)
      .then((name) => {
        const agentName = name.text();
        this.vtCreatePopupNextOrSubmitButton()
          .should('be.visible')
          .then(() => {
            this.vtCreatePopupNextOrSubmitButton().click();
          });
        cy.wait('@createGroup');
        this.verifyAgentNameInVirtualTeam(virtualTeam, agentName);
      });
    return virtualTeam;
  }

  /**
   * Verifying the entered Virtual Team Name is present in the VT List
   * @param virtualTeam Virtual Team Name to be verified
   * @returns True or False based on Virtual Team Name exist
   */
  verifyVirtualTeamIsPresent(virtualTeam) {
    let virtualTeamIsPresent = 'False';
    this.searchVirtualTeamInput().then(() => {
      this.searchVirtualTeamInput().clear().type(virtualTeam);
    });
    this.searchResultVirtualTeamList().should('have.text', virtualTeam);
    virtualTeamIsPresent = 'True';
    return virtualTeamIsPresent;
  }

  /**
   * Verifying the entered Virtual Team Name is not present in the Virtual Team List
   * @param virtualTeam Virtual Team Name to be verified as not exist
   */
  verifyVirtualTeamIsNotPresent(virtualTeam) {
    this.vtContentWrapperParentDiv().then(($ele) => {
      if ($ele.find('[data-testid=virtualAccounts-virtual_team-listItem]').length > 0) {
        this.searchResultVirtualTeamList().invoke('text').should('not.contain', virtualTeam);
      }
    });
  }

  /**
   * Verifying the selected Agent only displaying in the Virtual Team List
   * @param VirtualTeam Virtual Team Name in which Agent Name to be verified
   * @param agentName Agent Name needs to be verified
   * @returns True or False based on Virtual Team Name exist
   */
  verifyAgentNameInVirtualTeam(VirtualTeam, agentName) {
    const virtualTeamIsPresent = this.verifyVirtualTeamIsPresent(VirtualTeam);
    if (virtualTeamIsPresent === 'True') {
      this.expandAllVirtualTeamButton().eq(0).click();
      this.agentNameInVirtualTeamList().eq(0).contains(agentName);
    }
    return virtualTeamIsPresent;
  }

  /**
   * Deleting the given Virtual Account
   * @param VirtualTeam Virtual Account Name to be deleted
   */
  deleteVirtualTeam(VirtualTeam) {
    const virtualTeamIsPresent = this.verifyVirtualTeamIsPresent(VirtualTeam);
    if (virtualTeamIsPresent === 'True') {
      this.deleteVirtualTeamButton().click();
      this.confirmDeleteVirtualTeamPopupButton().click();
    }
    this.searchVirtualTeamInput().clear();
    this.verifyVirtualTeamIsNotPresent(VirtualTeam);
  }

  addNewAgentInVirtualTeam(virtualTeam) {
    cy.intercept('search/virtual_groups/_search*').as('search');
    let agentName = '';
    cy.slcHelpers.getAgentDetails().then((agentDetails) => {
      agentName = agentDetails[0].sl_name;
      this.vtCreatePopupSearchCustomerNameInput().should('be.visible').clear().type(agentName);
      cy.wait('@search');
      this.vtEditCustomerNameInSearchResultList().eq(0).click();
      // eslint-disable-next-line cypress/no-unnecessary-waiting
      cy.wait(2000);
      this.editVirtualTeamSaveButton()
        .should('be.visible')
        .then(() => {
          this.editVirtualTeamSaveButton().click({ force: true });
        });
      this.verifyAgentNameInVirtualTeam(virtualTeam, agentName);
    });
    return agentName;
  }

  /**
   * Creating the Virtual Orgs of specified OrgType with two Virtual Teams
   * @param orgsType to be 'Global' or 'Personal'
   * @param vtName needs to be an array with 2 virtual team name
   * @returns the created Virtual Orgs Name
   */
  createVirtualOrgs(orgsType, vtName) {
    cy.intercept('POST', 'api/v2/group').as('createOrgs');
    cy.intercept('search/virtual_groups/_search*').as('search');
    this.createVirtualOrgsButton().scrollIntoView().should('be.visible').click();
    // Selecting the Global or Personal Orgs
    if (orgsType === 'Global') {
      this.OrgsTypeGlobalButton().should('be.visible').click();
    }
    if (orgsType === 'Personal') {
      this.OrgsTypePersonalButton().should('be.visible').click();
    }
    const virtualOrgs = `Test ${orgsType} Orgs ${randId()}`;
    this.virtualTeamNameInput().type(virtualOrgs);
    this.vtCreatePopupNextOrSubmitButton().should('be.visible').click();
    this.vtCreatePopupSearchCustomerNameInput().should('be.visible').clear().type(vtName[0]);
    cy.wait('@search');
    this.vtCreatePopupCustomerSearchResultList()
      .eq(0)
      .should('be.visible')
      .then(() => {
        this.vtCreatePopupCustomerSearchResultList().eq(0).click();
      });
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(2000);
    this.vtCreatePopupSearchCustomerNameInput().should('be.visible').clear().type(vtName[1]);
    cy.wait('@search');
    this.vtCreatePopupCustomerSearchResultList()
      .eq(0)
      .should('be.visible')
      .then(() => {
        this.vtCreatePopupCustomerSearchResultList().eq(0).click();
      });
    this.vtCreatePopupNextOrSubmitButton().should('be.visible').click();
    cy.wait('@createOrgs');
    return virtualOrgs;
  }

  /**
   * Verifying the entered Virtual Orgs Name is present in the VirtualOrgs List
   * @param voName Virtual Orgs Name to be verified
   * @returns True or False based on Virtual Orgs Name exist
   */
  verifyVirtualOrgsIsPresent(voName) {
    let voIsPresent = 'False';
    this.virtualOrgsNameLists().invoke('text').should('contain', voName);
    voIsPresent = 'True';
    return voIsPresent;
  }

  /**
   * Verifying the entered Virtual Orgs Name is not present in the VirtualOrgs List
   * @param voName Virtual Orgs Name to be verified as not exist
   */
  verifyVirtualOrgsIsNotPresent(voName) {
    this.vtContentWrapperParentDiv().then(($ele) => {
      if ($ele.find('[data-testid=virtualAccounts-virtual_teams_group-listItem]').length > 0) {
        this.virtualOrgsNameLists().invoke('text').should('not.contain', voName);
      }
    });
  }

  /**
   * Verify the voName exist in page and Deleting the given Virtual Orgs
   * @param voName Virtual Orgs Name to be deleted
   */
  deleteVirtualOrgs(voName) {
    const voIsPresent = this.verifyVirtualOrgsIsPresent(voName);
    if (voIsPresent === 'True') {
      this.virtualOrgsNameLists().then((voNameList) => {
        for (let i = 0; i < voNameList.length; i += 1) {
          const vorgsName = voNameList.eq(i).text();
          if (vorgsName === voName) {
            this.virtualOrgsDeleteButton().eq(i).scrollIntoView().click();
            this.confirmDeleteVirtualTeamPopupButton().click();
            this.verifyVirtualOrgsIsNotPresent(voName);
          }
        }
      });
    }
  }
}

export const virtualTeam = new VirtualTeamPageObject();
