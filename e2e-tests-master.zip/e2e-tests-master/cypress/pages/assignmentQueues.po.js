class AssignmentQueues {
  addCrmQueueButton() {
    // TODO: Refer https://supportlogic.atlassian.net/browse/SLC-34063
    return cy.get('._3mc0YxjyxiVyAAPNboEhWL:not([data-testid])').first();
  }

  addCrmQueueSearchBox() {
    return cy.getByTestId('settings-caseAssignment-newQueue-searchBox');
  }

  addQueueSearchResultItems() {
    // TODO: Refer https://supportlogic.atlassian.net/browse/SLC-34063
    return cy.get('[id^=add-queue-input-typeahead-item]');
  }

  commonCrmQueueListItem() {
    return cy.get("[value]:not([value='Virtual Queue']) [data-testid=assignment-queue-editableText-name]");
  }

  crmQueueListItemByQueueName(queueName) {
    return cy.contains('[data-testid=assignment-queue-editableText-name]', queueName);
  }

  editQueueNameInputField() {
    return cy.getByTestId('assignment-queue-editableText-input');
  }

  editQueueNameErrorMessage() {
    return cy.getByTestId('assignment-queue-errorMessage');
  }

  commonAutoAssignDropdown() {
    // TODO: For data-testid, refer https://supportlogic.atlassian.net/browse/SLC-34063
    return cy.get('[mode=autoAssign] [data-testid=common-dropdown]');
  }

  autoAssignDropdownByQueueName(queueName) {
    // TODO: For data-testid, refer https://supportlogic.atlassian.net/browse/SLC-34063
    return cy.contains('[class*=TableRow]', queueName).find('[mode=autoAssign] [data-testid=common-dropdown]');
  }

  queueDeleteButtonByQueueName(queueName) {
    // TODO: Refer https://supportlogic.atlassian.net/browse/SLC-34063
    return cy.contains('[class*=TableRow]', queueName).find('[class*=DeleteQueueButton]');
  }

  commonAddAgentButton() {
    return cy.getByTestId('settings-caseAssignment-queue-addAgentBtn');
  }

  addAgentButtonByQueueName(queueName) {
    return cy.contains('[class*=TableRow]', queueName).find('[data-testid=settings-caseAssignment-queue-addAgentBtn]');
  }

  addAgentPopupSearchBox() {
    return cy.getByTestId('settings-caseAssignment-queue-addAgent-searchInput');
  }

  addAgentPopupSearchResultItem() {
    return cy.getByTestId('settings-caseAssignment-queue-addAgent-searchResult');
  }

  assignedAgentItemsByQueueName(queueName) {
    // TODO: Refer https://supportlogic.atlassian.net/browse/SLC-34063
    return cy.contains('[class*=TableRow]', queueName).find('[data-testid=settings-caseAssignment-queue-removeAgentBtn]').parent();
  }

  addVirtualQueueButton() {
    return cy.get('[data-testid=settings-caseAssignment-virtualQueue-addVirtualQueue] span');
  }

  createVirtualQueueCancelButton() {
    return cy.getByTestId('settings-caseAssignment-virtualQueue-cancelBtn');
  }

  saveVirtualQueueButton() {
    return cy.getByTestId('settings-caseAssignment-virtualQueue-saveBtn');
  }

  assignmentQueueNameList() {
    return cy.getByTestId('assignment-queue-editableText-name');
  }

  deleteQueueConfirmButton() {
    return cy.getByTestId('settings-caseAssignment-virtualQueue-deleteShiftDialog-deleteButton');
  }

  queueFilterTabList() {
    return cy.get('[data-testid=optionsSwitcherNew-list] li');
  }

  caseFieldPriorityCollapseButton() {
    return cy.getByTestId('scopeFilters__dialog__field__sl_priority__collapseButton');
  }

  caseFieldPriorityHighPill() {
    return cy.getByTestId('scopeFilters__dialog__field__sl_priority__High');
  }

  caseFieldPriorityHighSelectedPill() {
    return cy.getByTestId('settings-caseAssignment-virtualQueue-caseFilter-High');
  }

  // TODO Deprecate OpsSystem Case Field Option , Remove on Sept 30.
  // caseFieldOpsSysCollapseButton() {
  //   return cy.getByTestId('scopeFilters__dialog__field__sl_op_sys_c__collapseButton');
  // }

  caseFieldSeverityCollapseButton() {
    return cy.getByTestId('scopeFilters__dialog__field__sl_severity_c__collapseButton');
  }

  // TODO Deprecate OpsSystem Case Field Option , Remove on Sept 30.
  // caseFieldOpsSysMacOSXJaguarPill() {
  //   return cy.getByTestId('scopeFilters__dialog__field__sl_op_sys_c__Mac OS X Jaguar');
  // }

  // TODO Deprecate OpsSystem Case Field Option , Remove on Sept 30.
  // caseFieldOpsSysUbuntuSaucySalamanderPill() {
  //   return cy.getByTestId('scopeFilters__dialog__field__sl_op_sys_c__Ubuntu Saucy Salamander');
  // }

  // TODO Deprecate OpsSystem Case Field Option , Remove on Sept 30.
  // caseFieldOpsSysUbuntuOneiricOcelotPill() {
  //   return cy.getByTestId('scopeFilters__dialog__field__sl_op_sys_c__Ubuntu Oneiric Ocelot');
  // }

  caseFieldSeverityHighPill() {
    return cy.getByTestId('scopeFilters__dialog__field__sl_severity_c__high');
  }

  caseFieldSeverityMediumPill() {
    return cy.getByTestId('scopeFilters__dialog__field__sl_severity_c__medium');
  }

  caseFieldOpsSysMacOSXJaguarSelectedPill() {
    return cy.getByTestId('settings-caseAssignment-virtualQueue-caseFilter-Mac OS X Jaguar');
  }

  caseFieldOpsSysUbuntuSaucySalamanderSelectedPill() {
    return cy.getByTestId('settings-caseAssignment-virtualQueue-caseFilter-Ubuntu Saucy Salamander');
  }

  caseFieldOpsSysUbuntuOneiricOcelotSelectedPill() {
    return cy.getByTestId('settings-caseAssignment-virtualQueue-caseFilter-Ubuntu Oneiric Ocelot');
  }

  caseFieldSeverityHighSelectedPill() {
    return cy.getByTestId('settings-caseAssignment-virtualQueue-caseFilter-high');
  }

  caseFieldSeverityMediumSelectedPill() {
    return cy.getByTestId('settings-caseAssignment-virtualQueue-caseFilter-medium');
  }

  virtualQueueFilterSearchTextField() {
    return cy.getByTestId('filters-scoreFilters-searchOptionFilter-searchInput');
  }

  virtualQueueFilterCheckboxList() {
    return cy.get('[data-testid^=animated-checkbox]');
  }

  virtualQueueFilterLabel() {
    return cy.get('[data-testid^=settings-caseAssignment-virtualQueue-filter]');
  }

  // TODO data-testid request SLC-34063
  virtualQueueDeleteButtonTooltip() {
    return cy.get('#arrow').parent();
  }

  vqDeletePopupCancelButton() {
    return cy.getByTestId('settings-caseAssignment-virtualQueue-deleteShiftDialog-cancelButton');
  }

  assignmentQueueNameEditButton() {
    return cy.getByTestId('assignment-queue-editableText-btn');
  }

  // TODO: data-testid request SLC-34063
  vqEditFilterButton(queueName) {
    return cy.contains('[class*=TableRow]', queueName).find('[data-testid=settings-caseAssignment-virtualQueue-editBtn]');
  }

  // TODO: For data-testid, refer https://supportlogic.atlassian.net/browse/SLC-34063
  defaultTeamValueWrapper() {
    return cy.get('[class^="styles__ValueWrapper-sc-"]');
  }

  // TODO: For data-testid, refer https://supportlogic.atlassian.net/browse/SLC-34063
  defaultTeamAddButtonWrapper() {
    return cy.get('[class^="styles__AddDefaultTeamBtnWrapper-sc-"]');
  }

  // TODO: For data-testid, refer https://supportlogic.atlassian.net/browse/SLC-34063
  defaultTeamValueLabel() {
    return cy.get('[class^="styles__ValueWrapper-sc-"] [class^="styles__LabelWrapper-sc-"]');
  }

  // TODO: For data-testid, refer https://supportlogic.atlassian.net/browse/SLC-34063
  defaultTeamRemoveIcon() {
    return cy.get('[class^="styles__ValueWrapper-sc-"] [class^="styles__RemoveIcon-sc-"]');
  }

  defaultTeamAddButton() {
    return cy.getByTestId('common-button').contains('Set a default team');
  }

  // TODO: For data-testid, refer https://supportlogic.atlassian.net/browse/SLC-34063
  addDefaultTeamPopupSearchInput() {
    return cy.get('[class^="styles__Input-sc-"]');
  }

  // TODO: For data-testid, refer https://supportlogic.atlassian.net/browse/SLC-34063
  addDefaultTeamPopupSearchResultList() {
    return cy.get('[data-testid="common-scrollList"] [class^="styles__Container-sc-"]');
  }

  defaultTeamRemovePopupYesButton() {
    return cy.getByTestId('common-button').contains('Remove');
  }

  defaultTeamRemovePopupCancelButton() {
    return cy.getByTestId('common-button').contains('Cancel');
  }

  // TODO: For data-testid, refer https://supportlogic.atlassian.net/browse/SLC-34063
  assignmentQueueSettingsContainer() {
    return cy.get('[class^="styles__Settings-sc"]');
  }

  // TODO: For data-testid, refer https://supportlogic.atlassian.net/browse/SLC-34063
  removeVirtualQueues() {
    cy.get('[data-testid=virtualQueuesPage-container]').then(($ele) => {
      if ($ele.find('[class^=styles__VirtualQueueLabel]').length > 0) {
        cy.get('[class^=styles__VirtualQueueLabel]').each((vq) => {
          cy.wrap(vq)
            .siblings('[data-testid=settings-caseAssignment-queueVisibility-toggleBtn]')
            .last()
            .find('svg')
            .invoke('attr', 'class')
            .then((visiblity) => {
              if (visiblity.includes('EyeClosed')) {
                cy.wrap(vq).siblings('[data-testid=settings-caseAssignment-queueVisibility-toggleBtn]').click();
              }
            });
          cy.wrap(vq).parent().siblings('[mode=autoAssign]').find('[class^=styles__DeleteQueueButton]').click();
          this.deleteQueueConfirmButton().click();
          cy.waitForLoaders();
        });
      }
    });
  }

  autoAssignDropdownOptionAlways() {
    return cy.getByTestId('common-dropdown-ENABLED');
  }

  autoAssignDropdownOptionNever() {
    return cy.getByTestId('common-dropdown-NEVER');
  }

  autoAssignDropdownOptionDoNothing() {
    return cy.getByTestId('common-dropdown-DO_NOTHING');
  }

  autoAssignDropdownOptionOptional() {
    return cy.getByTestId('common-dropdown-OPTIONAL');
  }

  // TODO: For data-testid, refer https://supportlogic.atlassian.net/browse/SLC-34063
  queueVisibilityToggleButton(queueName) {
    return cy.contains('[class*=TableRow]', queueName).find('[data-testid=settings-caseAssignment-queueVisibility-toggleBtn]');
  }

  // TODO data-testid request SLC-34063
  addAgentPopupFilterButton() {
    return cy.get('[class^=SearchFilters__TriggerContainer]');
  }
}

export const assignmentQueues = new AssignmentQueues();
