export class ConsolePageObject {
  // Console Page Locators

  navigationConsole() {
    return cy.getByTestId('layout-navigation-module-item--console');
  }

  newCasesTab() {
    return cy.getByTestId('consolePage-tabsSlider-tab-Tickets');
  }

  positiveSentimentsTab() {
    return cy.getByTestId('consolePage-tabsSlider-tab-Positive_Sentiments');
  }

  // TODO data-testid requested via SLC-30800.
  caseListCustomerName() {
    return cy.getByTestId('common-ticketSentimentsBlock-customerName');
  }

  negativeSentimentsTab() {
    return cy.getByTestId('consolePage-tabsSlider-tab-Negative_Sentiments');
  }

  escalationsTab() {
    return cy.getByTestId('consolePage-tabsSlider-tab-Escalations');
  }

  newEscalationsTab() {
    return cy.getByTestId('consolePage-tabsSlider-tab-New_Escalations');
  }

  lteTab() {
    return cy.getByTestId('consolePage-tabsSlider-tab-Likely_to_Escalate');
  }

  needAttentionTab() {
    return cy.getByTestId('consolePage-tabsSlider-tab-Need_Attention');
  }

  productFeedbackTab() {
    return cy.getByTestId('consolePage-tabsSlider-tab-Product_Feedback');
  }

  sentimentsGroupbyButton() {
    return cy.getByTestId('sentimentsFeed-lightFilter-groupBy-btn');
  }

  acknowledgeDropdown() {
    return cy.get('[data-testid=consolePage-acknowledge-dropdown-trigger]');
  }

  groupedByDropdown() {
    return cy.getByTestId('common-dropdown-btn');
  }

  dropdownElapsedTimeOption() {
    return cy.getByTestId('common-dropdown-recency');
  }

  // TODO data-testid requested via SLC-30800.
  consoleHeader() {
    return cy.get('._1hBxtsLkoc4MFboLmFv910');
  }

  newCasesTabHeaderList() {
    return cy.getByTestId('consolePage_lists-header');
  }

  // TODO data-testid requested via SLC-30800.
  newCasesTabUnassignedHeader() {
    return cy.get('.ADJ4dHIXGUD4jN6Y8TWKC');
  }

  collapseExpandButton() {
    return cy.getByTestId('consolePage-sentimentTab_expand-collapse-button');
  }

  sentimentsTabHeaderList() {
    return cy.getByTestId('consolePage_lists-tab-header');
  }

  caseCard() {
    return cy.getByTestId('consolePage-tabs-case-card');
  }

  unassignedCasesSortDropdown() {
    return cy.getByTestId('consolePage-all_queues-dropdown--trigger-btn');
  }

  unassignedCasesSortDirection() {
    return cy.getByTestId('consolePage_cases-list_sort-trigger');
  }

  unassignedCasesCardID() {
    return cy.getByTestId('common-caseList-defaultItem-cardId');
  }

  unassignedCasesCardTitle() {
    return cy.getByTestId('common-caseList-defaultItem-cardTitle');
  }

  unassignedCaseCardLists() {
    return cy.getByTestId('common-caseList-sideListItem');
  }

  assignedCasesSortDataStatus() {
    return cy.get('[data-testid=common__sortingControl__toggle] > svg');
  }

  assignedCasesSortDirection() {
    return cy.getByTestId('common__sortingControl__toggle');
  }

  // Time filters - Last 7 days
  timeFilterButton() {
    return cy.getByTestId('consolePage-filters-timeFilter');
  }

  lastSevenDaysDropdownOption() {
    return cy.getByTestId('consolePage-filters-timeFilter-option-Last_7_days');
  }

  setTimeFilterToLastSevenDays() {
    this.timeFilterButton().click();
    this.lastSevenDaysDropdownOption().click();
  }

  // Time filters - Since Yesterday
  sinceYesterdayDropdownOption() {
    return cy.getByTestId('common-dropdown-Since_yesterday');
  }

  setTimeFilterToSinceYesterday() {
    this.timeFilterButton().click();
    this.sinceYesterdayDropdownOption().click();
  }

  // Time filters - Today
  todayDropdownOption() {
    return cy.getByTestId('consolePage-filters-timeFilter-option-Today');
  }

  setTimeFiltertoday() {
    this.timeFilterButton().click();
    this.todayDropdownOption().click();
  }

  unassignedCasesSortStatus() {
    return cy.get('[data-testid="consolePage_cases-list_sort-trigger"] svg');
  }

  // list-Header - Assigned Cases or Case Distribution
  selectedStatusDropdown(headerValue) {
    return cy.contains(headerValue).parents('[data-testid="consolePage_lists-header"]').find('[data-testid="common-dropdown-btn"]');
  }

  selectClosedInStatusDropdown(headerValue) {
    return cy.contains(headerValue).parents('[data-testid="consolePage_lists-header"]').find('[data-testid="common-dropdown-Closed"]');
  }

  selectOpenInStatusDropdown(headerValue) {
    return cy.contains(headerValue).parents('[data-testid="consolePage_lists-header"]').find('[data-testid="common-dropdown-Opened"]');
  }

  newCasesUnassignedLabel() {
    return cy.get('[data-testid^=distributionChartLegend--unassigned]');
  }

  unassignedCasesQueuesDropdownTrigger() {
    return cy.getByTestId('consolePage-all_queues-dropdown--trigger').eq(0);
  }

  unassignedCasesCommonDropdownTrigger() {
    return cy.getByTestId('consolePage-all_queues-dropdown--trigger').eq(1);
  }

  unassignedCasesCommonDropdownListItems() {
    return cy.get('[data-testid^="common-dropdown-sl"]');
  }

  unassignedCaseCardSentimentScore() {
    return cy.getByTestId('consolePage-tabs-case-card-sentiment-score');
  }

  unassignedCaseCardNeedAttentionScore() {
    return cy.getByTestId('consolePage-tabs-case-card-need-attention-score');
  }

  assignedCasesChartListItem() {
    return cy.getByTestId('common-chart-category');
  }

  showAllDropdown() {
    return cy.getByTestId('consolePage-acknowledge-dropdown-trigger');
  }

  // TODO waiting for the data-testid for below locator SLC-30800
  assignedCasesDropdown() {
    return cy.get('._3xUxtin2bc4T96gulhdq5g');
  }

  // TODO waiting for the data-testid for below locator SLC-30800
  assignedCasesContainer() {
    return cy.get('._2imROAVq5Ic-pBuAIndrZx .highcharts-plot-background');
  }

  assignedCasesDropdownOptionClosed() {
    return cy.getByTestId('common-dropdown-Closed');
  }

  assignedCasesDropdownOptionOpened() {
    return cy.getByTestId('common-dropdown-Opened');
  }

  // TODO waiting for the data-testid for below locator SLC-30800
  caseDistributionLabel() {
    return cy.get('._6rPVjHt2bLrAhZDVLlYfx ._1-MGuMU8fZsniwwoCRM7ry');
  }

  caseDistributionUnassignedLabel() {
    return cy.getByTestId('distributionChartLegend--unassigned-enabled');
  }

  needAttentionTabCaseCount() {
    return cy.getByTestId('consolePage-tabsSlider-tab-count-Need_Attention');
  }

  escalationCaseCard() {
    return cy.getByTestId('case-card-base-wrapper');
  }

  caseCardEscalationNotesIcon() {
    return cy.get('[data-testid^="escalationCard-notes-btn-"]');
  }

  // Request for data-testid SLC-30803
  caseCardEscalationNotesTooltip() {
    return cy.get('[class^="styles__PopperContainer-sc"]');
  }

  activeEscalationSubTab() {
    return cy.getByTestId('optionsSwitcherNew-option-Active Escalations');
  }

  escalationRequestSubTab() {
    return cy.getByTestId('optionsSwitcherNew-option-Escalation Request');
  }

  groupByTabs() {
    return cy.getByTestId('optionsSwitcherNew-list');
  }

  groupByTabOption(tab) {
    return cy.getByTestId(`optionsSwitcherNew-option-${tab}`);
  }

  groupByTabOptionLabel() {
    return cy.get('[data-testid^="optionsSwitcherNew-option-"]');
  }

  escalationGroupByDropdownText() {
    return cy.getByTestId('dropdown-trigger-text');
  }

  // TODO waiting for the data-testid for below locator SLC-30800
  unassignedCaseCount() {
    return cy.get('._1ll7nU4V6YXvOXgxtLVWDt');
  }

  // TODO waiting for the data-testid for below locator SLC-30800
  unassignedCaseListItemQueue() {
    return cy.get('._2crn8zcLrV5yC1WzL68jnn');
  }

  newCasesTabCount() {
    return cy.getByTestId('consolePage-tabsSlider-tab-count-New_Cases');
  }

  positiveSentimentsTabCount() {
    return cy.getByTestId('consolePage-tabsSlider-tab-count-Positive_Sentiments');
  }

  negativeSentimentsTabCount() {
    return cy.getByTestId('consolePage-tabsSlider-tab-count-Negative_Sentiments');
  }

  needAttentionTabCount() {
    return cy.getByTestId('consolePage-tabsSlider-tab-count-Need_Attention');
  }

  productFeedbackTabCount() {
    return cy.getByTestId('consolePage-tabsSlider-tab-count-Product_Feedback');
  }

  likelyToEscalateTabCount() {
    return cy.getByTestId('consolePage-tabsSlider-tab-count-Likely_to_Escalate');
  }

  newEscalationsTabCount() {
    return cy.getByTestId('consolePage-tabsSlider-tab-count-New_Escalations');
  }

  engineeringIssuesTabCount() {
    return cy.getByTestId('consolePage-tabsSlider-tab-count-Engineering_Issues');
  }

  newCasesUnassignedCasesHeader() {
    return cy.contains('Unassigned Cases');
  }

  newCasesAssignedCasesHeader() {
    return cy.contains('Assigned Cases');
  }

  newCasesDistributionHeader() {
    return cy.contains('Case Distribution');
  }

  // TODO: SLC-34692 do add an enable/disable attibute that can be used to identify queues in a better way
  unassignedCasesCrmQueueDropdownOptions() {
    return cy.get('[data-testid^=common-dropdown-005][data-status=enabled]');
  }

  newCasesAssignedLabel() {
    return cy.get('[data-testid^=distributionChartLegend--assigned]');
  }

  assignedCasesBacklogLegend() {
    return cy.get('[data-testid^=assignChartLegend-backlog]');
  }

  assignedCasesThisPeriodLegend() {
    return cy.get('[data-testid^=assignChartLegend-current-period]');
  }

  noUnassignedCases() {
    return cy.getByTestId('common-zeroStateContainer');
  }

  escalationGroupByDrodownOptionEscalationState() {
    return cy.getByTestId('common-dropdown-escActivityType');
  }

  sentimentsGroupByDrodownOptionStatus() {
    return cy.getByTestId('common-dropdown-sl_status');
  }

  sentimentsGroupByDrodownOptionCustomer() {
    return cy.getByTestId('common-dropdown-sl_account_name');
  }

  sentimentsGroupByDrodownOptionPriority() {
    return cy.getByTestId('common-dropdown-sl_priority');
  }

  sentimentsGroupByDrodownOptionAgent() {
    return cy.getByTestId('common-dropdown-sl_assignee_name');
  }

  sentimentsOrderedByDropdownButton() {
    return cy.getByTestId('sentimentsFeed-lightFilter-orderBy-btn');
  }

  sentimentsOrderedByDropdownOptionName() {
    return cy.getByTestId('common-dropdown-label');
  }

  sentimentsOrderedByDropdownOptionSignalCount() {
    return cy.getByTestId('common-dropdown-sentimentsCount');
  }

  consoleSliderContainer() {
    return cy.getByTestId('consolePage-slider-container');
  }

  caseCardScoreBadgeAhsIcon() {
    return cy.getByTestId('case-card-base-scoreBadge-ahs');
  }

  caseCardShareIcon() {
    return cy.getByTestId('sentimentCard-share-case-btn');
  }

  // TODO waiting for the data-testid for below locator SLC-30800
  caseCardShareTooltip() {
    return cy.get('._78hqQYxd1vi3DDjjJVkJ');
  }

  acknowledgeDropdownValueAll() {
    return cy.getByTestId('common-dropdown-ALL');
  }

  acknowledgeDropdownValueAck() {
    return cy.getByTestId('common-dropdown-ACK');
  }

  acknowledgeDropdownValueUnack() {
    return cy.getByTestId('common-dropdown-NOT_ACK');
  }

  sentimentAckButton() {
    return cy.getByTestId('sentimentCard-acknowledge-btn');
  }

  caseCardTicketIdLabel() {
    return cy.getByTestId('common-ticketSentimentsBlock-id');
  }

  // TODO: Request data-testid  SLC-35148
  caseCardDetectedSentimentLabel() {
    return cy.get('._3HBTrtzr96nyhSCAugJRGz');
  }

  caseCardAgentAvatarIcon() {
    return cy.getByTestId('agentAvatar-icon');
  }

  // TODO: Request data-testid  SLC-35148
  caseCardDetectedSentimentCommentsLabel() {
    return cy.get('._1FBsGUWi882pLHrL4nxAZ0');
  }

  caseCardAgentHeadsetIcon() {
    return cy.get('[data-icon="headset-frame"]');
  }

  caseCardSentimentScoreCountIcon() {
    return cy.getByTestId('case-card-base-sentimentScore');
  }

  caseCardAttentionScoreCountIcon() {
    return cy.getByTestId('case-card-base-attentionScore');
  }

  // TODO: Request data-testid  SLC-35148
  sentimentSignalsdropdown() {
    return cy.get('[class^="TriggerV2__Container-sc-"]');
  }

  // TODO: Request data-testid SLC-30803
  likelyToEscalateTitle() {
    return cy.getByTestId('common-dropdown').siblings('h2');
  }

  caseCardCaseAgeLabel() {
    return cy.getByTestId('case-card-base-caseAge');
  }

  // This priority label is for console tabs New Escalation and Lte tabs alone
  escalationCaseCardPriorityLabel() {
    return cy.getByTestId('case-card-base-priority');
  }

  // TODO waiting for the data-testid for below locator SLC-30803
  // This priority label is for console tabs excluding New Escalation and Lte tabs
  caseCardPriorityLabel() {
    return cy.get('._3s1bqBCe_nJt57AfFD4iQl');
  }

  // TODO waiting for the data-testid for below locator SLC-30803
  caseCardStatusLabel() {
    return cy.get('._1TFr3P1IJxiBU96oPufi9n');
  }

  caseCardLastResponseLabel() {
    return cy.getByTestId('case-card-base-lastResponseDateFormatted');
  }

  caseCardEscalatedDate() {
    return cy.getByTestId('case-card-base-inEscalatedStateDateFormatted');
  }

  // TODO data-testid requested via SLC-35284.
  consoleTabsDropdownButton() {
    return cy.get('[class^="EscActivityGrid__DropdownTrigger"]');
  }

  consoleGroupedByDropdownSentimentScoreOption() {
    return cy.getByTestId('common-dropdown-sentiment_score_group_name');
  }

  newEscalationEscalatedOptionSwitcher() {
    return cy.getByTestId('optionsSwitcherNew-option-Escalated');
  }

  // TODO data-testid requested via SLC-35284.
  consoleEscalatedTabHeaderTitle() {
    return cy.get('[class^="EscActivityGrid__Header"]');
  }

  // TODO data-testid requested via SLC-35284.
  consoleTabsHeaderTitleTooltip() {
    return cy.get('[class*=PopperContainer]');
  }

  consoleGroupedByDropdownAttentionScoreOption() {
    return cy.getByTestId('common-dropdown-attention_score_group_name');
  }

  consoleSubTabsOptionSwitcher() {
    return cy.get('[data-testid^="optionsSwitcherNew-option"]');
  }

  consoleSentimentsSubTabsOptionSwitcher() {
    return cy.get('[data-testid^="optionsSwitcherNew-option"] [class="_3umPcsIu4biuSxa9bK12q-"]');
  }

  // TODO data-testid requested via SLC-35284.
  consoleSentimentsTabsHeaderTitle() {
    return cy.get('._1qFXtCSXUFnzWDr-ilv1ZG');
  }

  // TODO data-testid requested via SLC-35284.
  consoleTabsShowingHeaderTitle() {
    return cy.get('._59V9JvVo6GdZRXBjW7tHi');
  }

  // TODO data-testid requested via SLC-35284.
  sentimentsTabsSignalsDropdown() {
    return cy.get('[class^="DirectionFilterV2__Container"]');
  }

  // TODO data-testid requested via SLC-35284.
  signalsDropdownSentimentSignalHeader() {
    return cy.get('[class^="DirectionFilterV2__Header"]');
  }

  signalsDropdownSentimentSignalCheckbox() {
    return cy.getByTestId('animated-checkbox-default-group--id');
  }

  engIssuesChartWrapperEntities() {
    return cy.getByTestId('agentPage-engIssues--entities__chartwrapper_title');
  }

  engIssuesChartWrapperStatus() {
    return cy.getByTestId('chartWrapper-agent_engineering_issues__overview__sl_status');
  }

  engIssuesChartWrapperPriority() {
    return cy.getByTestId('chartWrapper-agent_engineering_issues__overview__sl_priority');
  }

  caseCardCustomerName() {
    return cy.getByTestId('case-card-base-accountInfo-name');
  }

  caseCardHeaderText() {
    return cy.get('._340d2tQ-sATEwfuW4bJIly');
  }

  acknowledgeLabelWithCrossIcon() {
    return cy.get("[class='_1DkWEwVw6AXwxCSLTMizih'][data-icon='cross']");
  }

  acknowledgeLabelTooltip() {
    return cy.get('._78hqQYxd1vi3DDjjJVkJ._3czN3Zz0sZvukIpl1GuFo7._39s9z_DPagKPhZA0hKh08N');
  }

  groupByDropdownOptionAttentionScore() {
    return cy.getByTestId('common-dropdown-attention_score_group_name');
  }

  groupByDropdownOptionSentimentScore() {
    return cy.getByTestId('common-dropdown-sentiment_score_group_name');
  }

  groupByDropdownOptionBusinessHours() {
    return cy.getByTestId('common-dropdown-business_hours');
  }

  groupByDropdownOptionSentimentType() {
    return cy.getByTestId('common-dropdown-sentiment_type');
  }

  sentimentSignalsAllCheckBox() {
    return cy.getByTestId('animated-checkbox-default-group--id');
  }

  sentimentSignalsIndividualCheckbox(signal) {
    return cy.getByTestId(`animated-checkbox-${signal}-undefined-id`);
  }

  // TODO waiting for the data-testid for below locator SLC-30803
  sentimentSignalsIndividualNameLabel() {
    return cy.get('[class^="DirectionFilterV2__LabelWrapper-sc-"]');
  }

  expandAllConsoleLists() {
    this.collapseExpandButton().then((button) => {
      const textmsg = button.text();

      if (textmsg === 'Expand All') {
        this.collapseExpandButton().click().invoke('text').should('be.equal', 'Collapse All');
      }
    });
  }

  groupByElapsedTime() {
    this.sentimentsGroupbyButton().then((groupValue) => {
      const dropdownValue = groupValue.text();
      if (dropdownValue !== 'Elapsed Time') {
        this.sentimentsGroupbyButton().click();
        this.dropdownElapsedTimeOption().click();
        this.consoleHeader().click();
      }
    });
  }

  groupByStatusOption() {
    this.escalationGroupByDropdownText().then((groupValue) => {
      const dropdownValue = groupValue.text();
      if (dropdownValue !== 'Status') {
        this.consoleTabsDropdownButton().click();
        this.sentimentsGroupByDrodownOptionStatus().click();
      }
    });
  }

  // This function will work only in the New Escalation and lte tab only
  groupByPriorityOption() {
    this.escalationGroupByDropdownText().then((groupValue) => {
      const dropdownValue = groupValue.text();
      if (dropdownValue !== 'Priority') {
        this.consoleTabsDropdownButton().click();
        this.sentimentsGroupByDrodownOptionPriority().click();
      }
    });
  }

  // This function will work on other than New Escalation and lte tab
  sentimentTabgroupByPriorityOption() {
    this.sentimentsGroupbyButton().then((groupValue) => {
      const dropdownValue = groupValue.text();
      if (dropdownValue !== 'Priority') {
        this.sentimentsGroupbyButton().click();
        this.sentimentsGroupByDrodownOptionPriority().click();
      }
    });
  }

  groupByAttentionScoreOption() {
    this.sentimentsGroupbyButton().then((groupValue) => {
      const dropdownValue = groupValue.text();
      if (dropdownValue !== 'Attention Score') {
        this.sentimentsGroupbyButton().click();
        this.consoleGroupedByDropdownAttentionScoreOption().click();
      }
    });
  }

  groupBySentimentScoreOption() {
    this.sentimentsGroupbyButton().then((groupValue) => {
      const dropdownValue = groupValue.text();
      if (dropdownValue !== 'Sentiment Score') {
        this.sentimentsGroupbyButton().click();
        this.consoleGroupedByDropdownSentimentScoreOption().click();
      }
    });
  }

  getListsHeaderTitle() {
    const listHeaderValue = [];
    let tempValue;
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(3000);
    this.newCasesTabHeaderList()
      .eq(0)
      .should('be.visible')
      .then(($bfrvalue) => {
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(3000);
        tempValue = $bfrvalue.text();
        listHeaderValue.push(tempValue);
      });
    return listHeaderValue;
  }

  // orderValue will be 'Name' or 'Signal Count'
  orderByDropdownSelectName() {
    this.sentimentsOrderedByDropdownButton().then((orderValue) => {
      if (orderValue.text() !== 'Name') {
        this.sentimentsOrderedByDropdownButton().click();
        this.sentimentsOrderedByDropdownOptionName().click();
        this.consoleHeader().click();
      }
    });
  }

  selectAllSignalsInDropdown() {
    this.sentimentSignalsdropdown()
      .should('be.visible')
      .then(($value) => {
        const signalValue = $value.text();
        if (signalValue !== 'All Signals') {
          this.sentimentSignalsdropdown().click();
          this.sentimentSignalsAllCheckBox().click({ force: true });
          this.sentimentSignalsdropdown().invoke('text').should('contain', 'All Signals');
          this.sentimentSignalsdropdown().click();
        }
      });
  }

  selectShowAllInDropdown() {
    this.acknowledgeDropdown()
      .should('be.visible')
      .then(($value) => {
        const signalValue = $value.text();
        if (signalValue !== 'Show all') {
          this.acknowledgeDropdown().click();
          this.acknowledgeDropdownValueAll().click();
          this.acknowledgeDropdown().invoke('text').should('contain', 'Show all');
          this.acknowledgeDropdown().click();
        }
      });
  }

  selectShowAcknowledgedInDropdown() {
    this.acknowledgeDropdown()
      .should('be.visible')
      .then(($value) => {
        const drpdwnValue = $value.text().trim();
        // Selecting the Show Acknowledged in the show dropdown
        if (drpdwnValue !== 'Show Acknowledged') {
          this.acknowledgeDropdown().click();
          this.acknowledgeDropdownValueAck().click();
          this.acknowledgeDropdown().invoke('text').should('contain', 'Show Acknowledged');
        }
      });
  }

  selectShowUnacknowledgedInDropdown() {
    this.acknowledgeDropdown()
      .should('be.visible')
      .then(($value) => {
        const drpdwnValue = $value.text().trim();
        // Selecting the Show Unacknowledged in the show dropdown
        if (drpdwnValue !== 'Show Unacknowledged') {
          this.acknowledgeDropdown().click();
          this.acknowledgeDropdownValueUnack().click();
          this.acknowledgeDropdown().invoke('text').should('contain', 'Show Unacknowledged');
        }
      });
  }

  verifyStatusDropdownafterRefresh(headerValue, status) {
    this.selectedStatusDropdown(headerValue).invoke('text').should('include', status);
    cy.reload();
    cy.waitForLoaders();
    this.selectedStatusDropdown(headerValue).invoke('text').should('include', status);
  }

  // Highchart locator class most likely won't change. Hence no need to create a data-testid
  assignedCasesBacklogChartElements() {
    return cy.getByTestId('consolePage_lists-header').eq(1).parent().find('g.highcharts-series-1 rect');
  }

  // Highchart locator class most likely won't change. Hence no need to create a data-testid
  assignedCasesThisPeriodChartElements() {
    return cy.getByTestId('consolePage_lists-header').eq(1).parent().find('g.highcharts-series-0 rect');
  }

  // Highchart locator class most likely won't change. Hence no need to create a data-testid
  highchartsTooltip() {
    return cy.get('.highcharts-tooltip span');
  }
}

export const consolePage = new ConsolePageObject();
