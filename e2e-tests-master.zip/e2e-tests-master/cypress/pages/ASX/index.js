export { reminderPage } from './reminder.po';
