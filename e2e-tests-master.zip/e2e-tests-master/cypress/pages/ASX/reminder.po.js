class ReminderPage {
  reminderEmptyText() {
    return cy.get('div[data-testid="reminders-empty-state-title"]');
  }

  reminderCreationPlusIcon() {
    return cy.get('div[data-testid="add-reminder"]');
  }

  reminderCreationTextArea() {
    return cy.get('textarea[placeholder="Add a reminder"]');
  }
}

export const reminderPage = new ReminderPage();
