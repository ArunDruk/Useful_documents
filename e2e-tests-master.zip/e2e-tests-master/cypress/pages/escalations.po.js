import sortTimePhrases from '../utils/sortTimePhrases';
import { apiHelpers } from './general/apiHelpers.po';
import { arrayEquals, honorsOrder, sortNumbers } from '../utils';

class Escalations {
  headerText() {
    return cy.getByTestId('escalations-header_text');
  }

  headerInfoIcon() {
    return cy.getByTestId('escalations-header__hint__trigger');
  }

  headerInfoIconTooltip() {
    return cy.getByTestId('escalations-header__hint__tooltip');
  }

  reviewedCasesContainer() {
    return cy.getByTestId('escalation-list-container-reviewedTickets');
  }

  reviewedCasesContainerHeader() {
    return cy.getByTestId('escalation-list-header-reviewedTickets');
  }

  reviewedCasesHeaderCount() {
    return cy.getByTestId('escalation-list-header-reviewedTickets-number');
  }

  reviewedTicketsAcknowledgedTab() {
    return cy.getByTestId('escalationsBoard-reviewedTickets-tabs--option--acknowledgedTickets');
  }

  reviewedTicketsSnoozedTab() {
    return cy.getByTestId('escalationsBoard-reviewedTickets-tabs--option--snoozedPredictions');
  }

  reviewedTicketsDisagreedTab() {
    return cy.getByTestId('escalationsBoard-reviewedTickets-tabs--option--dismissedPredictions');
  }

  reviewedCasesCaseCard(caseId = '') {
    if (caseId !== '') {
      return cy.getByTestId(`escalation-card-list-reviewedTickets-${caseId}`);
    }
    return cy.get('[data-testid^=escalation-card-list-reviewedTickets]');
  }

  reviewedCasesUndoButtonByCaseId(caseId) {
    return this.reviewedCasesCaseCard(caseId).find('[data-testid=escalation-card-list-dismissedRequests-undoBtn]');
  }

  lteContainer() {
    return cy.getByTestId('escalation-list-container-escalationPredictions');
  }

  lteContainerHeader() {
    return cy.getByTestId('escalation-list-header-escalationPredictions');
  }

  lteHeaderCount() {
    return cy.getByTestId('escalation-list-header-escalationPredictions-number');
  }

  lteHeaderInfoIcon() {
    return cy.getByTestId('escalation-list-header-escalationPredictions-hint__trigger');
  }

  lteInfoIconTooltip() {
    return cy.getByTestId('escalation-list-header-escalationPredictions-hint__tooltip');
  }

  lteCaseCard() {
    return cy.get('[data-testid^=escalation-card-list-escalationPredictions]');
  }

  escalationRequestsContainer() {
    return cy.getByTestId('escalation-list-container-escalationRequests');
  }

  escalationRequestsContainerHeader() {
    return cy.getByTestId('escalation-list-header-escalationRequests');
  }

  escalationRequestsHeaderCount() {
    return cy.getByTestId('escalation-list-header-escalationRequests-number');
  }

  escalationRequestsDeclineRequestButton() {
    return cy.getByTestId('escalation-card-list-escalationRequests-declineRequestBtn');
  }

  escalationRequestsCaseCard() {
    return cy.get('[data-testid^=escalation-card-list-escalationRequests]');
  }

  escalationRequestsCaseCardCaseId() {
    return cy.getByTestId('escalation-card-list-escalation_requests-caseId');
  }

  escalationCaseCardCustomerName() {
    return cy.getByTestId('case-card-base-accountInfo-name');
  }

  activeEscalationsContainer() {
    return cy.getByTestId('escalation-list-container-activeEscalations');
  }

  activeEscalationsContainerHeader() {
    return cy.getByTestId('escalation-list-header-activeEscalations');
  }

  activeEscalationsHeaderCount() {
    return cy.getByTestId('escalation-list-header-activeEscalations-number');
  }

  activeEscalationsCaseCard() {
    return cy.get('[data-testid^=escalation-card-list-activeEscalations]');
  }

  resolvedEscalationsContainer() {
    return cy.getByTestId('escalation-list-container-resolvedEscalations');
  }

  resolvedEscalationsContainerHeader() {
    return cy.getByTestId('escalation-list-header-resolvedEscalations');
  }

  resolvedEscalationsHeaderCount() {
    return cy.getByTestId('escalation-list-header-resolvedEscalations-number');
  }

  resolvedEscalationsCaseCard() {
    return cy.get('[data-testid^=escalation-card-list-resolvedEscalations]');
  }

  escalationNotesButton() {
    return cy.getByTestId('escalationCard-notes-btn-activeEscalations');
  }

  escalationNotesButtonTooltip() {
    return cy.getByTestId('escalationCard-notes-btn-tooltip');
  }

  closeEscalationNotesPopupButton() {
    return cy.getByTestId('supportHub-escalationNoteDialog-closeNoteIcon');
  }

  escalationNotesTextarea() {
    return cy.getByTestId('supportHub-escalationNoteDialog-editNoteInput');
  }

  existingEscalationNoteTexts() {
    return cy.getByTestId('escalation-activeEscalations-escalationNotes-noteText');
  }

  escalationReviewTriggerButton() {
    return cy.getByTestId('escalations__escalationReviewTrigger__button').last();
  }

  escalationReviewPanelHeader() {
    return cy.getByTestId('escalations__escalationReviewPanel__header');
  }

  escalationReviewPanelFooter() {
    return cy.getByTestId('escalations__escalationReviewPanel__banner');
  }

  exitReviewButton() {
    return cy.getByTestId('escalations__escalationReviewPanel__exitButton');
  }

  removeFromQueueButton() {
    return cy.getByTestId('escalations__escalationReviewPanel__removeFromQueueButton');
  }

  undoEscalationReviewButton() {
    return cy.getByTestId('escalations__escalationReviewPanel__banner__undoButton');
  }

  acknowledgePredictionOption() {
    return cy.getByTestId('escalations__escalationReviewPanel__footer__complete');
  }

  snoozeItForOption() {
    return cy.getByTestId('escalations__escalationReviewPanel__footer__snooze');
  }

  disagreeWithPredictionOption() {
    return cy.getByTestId('escalations__escalationReviewPanel__footer__reject');
  }

  snoozeForTwelveHoursOption() {
    return cy.getByTestId('escalations__escalationReviewPanel__footer__snooze__12h');
  }

  snoozeForOneDayOption() {
    return cy.getByTestId('escalations__escalationReviewPanel__footer__snooze__1d');
  }

  snoozeForThreeDaysOption() {
    return cy.getByTestId('escalations__escalationReviewPanel__footer__snooze__3d');
  }

  escalationReviewCancelButton() {
    return cy.getByTestId('escalations__escalationReviewPanel__dialog__cancelButton');
  }

  escalationReviewOkButton() {
    return cy.getByTestId('escalations__escalationReviewPanel__dialog__submitButton');
  }

  reviewPanelActionCompleteBanner() {
    return cy.getByTestId('escalations__escalationReviewPanel__action__completeBanner');
  }

  commonReviewPanelActionTrigger(actionType) {
    return cy.getByTestId(`escalations__escalationReviewPanel__action__${actionType.toUpperCase()}__trigger`);
  }

  reviewPanelEscalationNotesButton() {
    return cy.getByTestId('escalations__escalationReviewPanel__action__ESCALATION_NOTE__trigger');
  }

  reviewPanelEscalationNotesTextarea() {
    return cy.getByTestId('escalations__escalationReviewPanel__action__ESCALATION_NOTE__noteInput');
  }

  reviewPanelEscalationNotesCancelButton() {
    return cy.getByTestId('escalations__escalationReviewPanel__action__ESCALATION_NOTE__cancel');
  }

  reviewPanelEscalationNotesSendButton() {
    return cy.getByTestId('escalations__escalationReviewPanel__action__ESCALATION_NOTE__submit');
  }

  reviewPanelCustomerNotesButton() {
    return cy.getByTestId('escalations__escalationReviewPanel__action__CUSTOMER_NOTE__trigger');
  }

  reviewPanelCustomerNotesTextarea() {
    return cy.getByTestId('escalations__escalationReviewPanel__action__CUSTOMER_NOTE__noteInput');
  }

  reviewPanelCustomerNotesCancelButton() {
    return cy.getByTestId('escalations__escalationReviewPanel__action__CUSTOMER_NOTE__cancel');
  }

  reviewPanelCustomerNotesSendButton() {
    return cy.getByTestId('escalations__escalationReviewPanel__action__CUSTOMER_NOTE__submit');
  }

  reviewPanelContactAgentButton() {
    return cy.getByTestId('escalations__escalationReviewPanel__action__CONTACT_AGENT__trigger');
  }

  reviewPanelContactAgentTextarea() {
    return cy.getByTestId('escalations__escalationReviewPanel__action__CONTACT_AGENT__noteInput');
  }

  reviewPanelContactAgentCancelButton() {
    return cy.getByTestId('escalations__escalationReviewPanel__action__CONTACT_AGENT__cancel');
  }

  reviewPanelContactAgentSendButton() {
    return cy.getByTestId('escalations__escalationReviewPanel__action__CONTACT_AGENT__submit');
  }

  reviewPanelLeaveCaseNoteButton() {
    return cy.getByTestId('escalations__escalationReviewPanel__action__CASE_NOTE__trigger');
  }

  reviewPanelShareCaseButton() {
    return cy.getByTestId('escalations__escalationReviewPanel__action__SHARE_CASE__trigger');
  }

  reviewPanelReassignCaseButton() {
    return cy.getByTestId('escalations__escalationReviewPanel__action__REASSIGN__trigger');
  }

  reviewPanelContactCustomerButton() {
    return cy.getByTestId('escalations__escalationReviewPanel__action__CONTACT_CUSTOMER__trigger');
  }

  commonSortByDropdown(containerName) {
    return cy.get(`[data-testid=escalation-list-container-${containerName}] [data-testid^=escalation-list-sortBy]`).first();
  }

  commonSortByDropdownLabel(containerName) {
    return cy.get(`[data-testid=escalation-list-container-${containerName}] [data-testid=common-dropdown-btn]`);
  }

  commonSortOption(containerName, optionName) {
    const formattedOptionName = optionName.toLowerCase().replaceAll(' ', '-');
    return cy.get(`[data-testid=escalation-list-container-${containerName}] [data-testid=escalation-list-sortBy-option-${formattedOptionName}]`);
  }

  commonCaseCardCaseAgeLabel(containerName) {
    return cy.get(`[data-testid=escalation-list-container-${containerName}] [data-testid=case-card-base-caseAge]`);
  }

  commonCaseCardCaseLastResponseLabel(containerName) {
    return cy.get(`[data-testid=escalation-list-container-${containerName}] [data-testid=case-card-base-lastResponseDateFormatted]`);
  }

  commonCaseCardSentimentScoreBadge(containerName) {
    // TODO: Get data-testid for sentiment score badge (SLC-33927)
    return cy.get(`[data-testid=escalation-list-container-${containerName}] [class*=BadgeContainer] div:nth-child(1)`);
  }

  commonCaseCardAttentionScoreBadge(containerName) {
    // TODO: Get data-testid for attention score badge (SLC-33927)
    return cy.get(`[data-testid=escalation-list-container-${containerName}] [class*=BadgeContainer] div:nth-child(2)`);
  }

  commonCaseCardPriorityLabel(containerName) {
    return cy.get(`[data-testid=escalation-list-container-${containerName}] [data-testid=case-card-base-priority]`);
  }

  lteCaseIds() {
    return cy.get('[data-testid=escalation-card-list-likely_to_escalate-caseId]');
  }

  activeEscalationEscalatedStateLabel() {
    return cy.get('[data-testid=escalation-list-container-activeEscalations] [data-testid=case-card-base-inEscalatedStateDateFormatted]');
  }

  resolvedCaseCardClosedDateLabel() {
    return cy.get('[data-testid=escalation-list-container-resolvedEscalations] [data-testid=case-card-base-closedDateFormatted]');
  }

  isContainerExpanded(containerElement) {
    return containerElement().invoke('attr', 'data-status');
  }

  collapseContainer(containerElement) {
    this.isContainerExpanded(containerElement).then((state) => {
      if (state === 'expanded') containerElement().click('top');
    });
  }

  expandContainer(containerElement) {
    this.isContainerExpanded(containerElement).then((state) => {
      if (state === 'collapsed') containerElement().click('top');
    });
  }

  selectSortOption(containerName, optionText) {
    this.commonSortByDropdownLabel(containerName)
      .text({ depth: Infinity })
      .then((currentVal) => {
        if (!currentVal.startsWith(optionText)) {
          this.commonSortByDropdown(containerName).click();
          this.commonSortOption(containerName, optionText).click();
          // eslint-disable-next-line cypress/no-unnecessary-waiting
          cy.wait(2000);
        }
      });
  }

  sortByOldestCase(containerName) {
    this.selectSortOption(containerName, 'Oldest case');
    // TODO: Remove once SLC-33797 is fixed
    if (containerName === 'resolvedEscalations') this.expandContainer(this.resolvedEscalationsContainer);
    return this.commonCaseCardCaseAgeLabel(containerName)
      .text()
      .then(async (caseAge) => arrayEquals(caseAge, sortTimePhrases(caseAge, true)));
  }

  sortByMostLikelyToEscalate(containerName) {
    this.selectSortOption(containerName, 'Most likely to escalate');
    return this.lteCaseIds()
      .text()
      .to('number')
      .then((lteCaseIds) =>
        apiHelpers
          .getPredictionScores()
          .then((scores) => scores.map(({ caseId }) => caseId))
          .then((caseIds) => lteCaseIds.every((item) => caseIds.includes(item)))
      );
  }

  sortByMostRecentResponse(containerName) {
    this.selectSortOption(containerName, 'Most recent response');
    return this.commonCaseCardCaseLastResponseLabel(containerName)
      .text({ depth: Infinity })
      .then((resTimes) => resTimes.map((resTime) => resTime.replace(/Last\sresponse:\s(Inbound|Outbound),\s/gi, '')))
      .then(async (responseTimes) => arrayEquals(responseTimes, sortTimePhrases(responseTimes)));
  }

  sortByLowestCaseSentiment(containerName) {
    this.selectSortOption(containerName, 'Lowest case sentiment');
    // TODO: Remove once SLC-33797 is fixed
    if (containerName === 'resolvedEscalations') this.expandContainer(this.resolvedEscalationsContainer);
    return this.commonCaseCardSentimentScoreBadge(containerName)
      .text()
      .to('number')
      .then(async (sentimentScores) => arrayEquals(sentimentScores, sortNumbers(sentimentScores)));
  }

  sortByHighestAttentionNeeded(containerName) {
    this.selectSortOption(containerName, 'Highest attention needed');
    // TODO: Remove once SLC-33797 is fixed
    if (containerName === 'resolvedEscalations') this.expandContainer(this.resolvedEscalationsContainer);
    return this.commonCaseCardAttentionScoreBadge(containerName)
      .text()
      .to('number')
      .then(async (attentionScores) => arrayEquals(attentionScores, sortNumbers(attentionScores, true)));
  }

  sortByHighestPriority(containerName) {
    this.selectSortOption(containerName, 'Highest case priority');
    return apiHelpers.getPriorityCaseFieldValues().then((priorityOrderArray) =>
      this.commonCaseCardPriorityLabel(containerName)
        .text({ depth: Infinity })
        .then(async (priorities) => honorsOrder(priorities, priorityOrderArray))
    );
  }

  sortByMostRecentRequest(containerName) {
    this.selectSortOption(containerName, 'Most recent request');
    return this.commonCaseCardCaseAgeLabel(containerName)
      .text()
      .then(async (caseAge) => arrayEquals(caseAge, sortTimePhrases(caseAge)));
  }

  sortByMostRecentEscalation(containerName) {
    this.selectSortOption(containerName, 'Most recent escalation');
    return this.activeEscalationEscalatedStateLabel()
      .text({ depth: Infinity })
      .then((escalatedStates) => escalatedStates.map((escalatedState) => escalatedState.replace(/In escalated state:\s/, '')))
      .then(async (escalatedDates) => arrayEquals(escalatedDates, sortTimePhrases(escalatedDates)));
  }

  sortByClosedDate(containerName) {
    this.selectSortOption(containerName, 'Closed date');
    // TODO: Remove once SLC-33797 is fixed
    if (containerName === 'resolvedEscalations') this.expandContainer(this.resolvedEscalationsContainer);
    return this.resolvedCaseCardClosedDateLabel()
      .text({ depth: Infinity })
      .then((closedDates) => closedDates.map((closedDate) => closedDate.replace(/Closed:\s/, '')))
      .then(async (closedDates) => arrayEquals(closedDates, sortTimePhrases(closedDates)));
  }

  escalationReportContainer() {
    return cy.getByTestId('escalationsReportPage-container');
  }

  escalationBoardContainer() {
    return cy.getByTestId('escalationsBoardPage-container');
  }

  historicDataTooltipIcon() {
    return cy.get('[data-icon=info]');
  }

  tooltipText() {
    return cy.get('#arrow');
  }

  currentDataTooltipIcon() {
    return cy.getByTestId('escalations-header__hint__trigger');
  }
}

export const escalations = new Escalations();
