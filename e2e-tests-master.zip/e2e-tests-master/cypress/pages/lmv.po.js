/* --TODO data-test id requested via missing elements--> SLC-32706-- */

export class LmvPageObject {
  addCardButton() {
    return cy.getByTestId('caseBoard--floating-action-button');
  }

  caseListButton() {
    return cy.getByTestId('myDashBoard-createCard-case_list-cardItem');
  }

  caseTileButton() {
    return cy.getByTestId('myDashBoard-createCard-tile-cardItem');
  }

  addCardCancelButton() {
    return cy.getByTestId('myDashboard-createCardModal-cancelBtn');
  }

  addCardNextButton() {
    return cy.getByTestId('myDashboard-createCardModal-saveBtn');
  }

  addCardBackButton() {
    return cy.getByTestId('myDashboard-createCardModal-caseListEditor-backBtn');
  }

  caseListEditorTitleInput() {
    return cy.getByTestId('myDashboard-createCardModal-caseListEditor-editCardName');
  }

  caseListLabelsRadio() {
    return cy.getByTestId('myDashboard-createCardModal-caseListEditor-optionContent');
  }

  caseListEditorCancelButton() {
    return cy.getByTestId('myDashboard-createCardModal-caseListEditor-cancelBtn');
  }

  caseListEditorAddButton() {
    return cy.getByTestId('myDashboard-createCardModal-caseListEditor-addBtn');
  }

  caseTileTitleInput() {
    return cy.getByTestId('mmyDashboard-createCardModal-tileCardEditor-editCardName');
  }

  caseTileLabelsCheckbox() {
    return cy.getByTestId('common-checkbox');
  }

  caseTileEditorCancelButton() {
    return cy.getByTestId('myDashboard-createCardModal-tileCardEditor-cancelBtn');
  }

  caseTileEditorAddButton() {
    return cy.getByTestId('myDashboard-createCardModal-tileCardEditor-addBtn');
  }

  // waiting for the data-testid SLC-33519
  cardTitleName() {
    return cy.get('.sharedStyles__CardName-sc-101gp8h-1');
  }

  // waiting for the data-testid SLC-33519
  caseStatisticsDropdown() {
    return cy.get('.styles__ArrowIcon-sc-144g1b7-2');
  }

  caseListSupportHubCardName() {
    return cy.get('.ReactVirtualized__Grid__innerScrollContainer ._2E-fazM8qpq3QimaIrukDZ');
  }

  caseListSupportHubCaseId() {
    return cy.get('.ReactVirtualized__Grid__innerScrollContainer .FCz2-LucAE1GSFNYvw4l3');
  }

  // waiting for the data-testid SLC-33519
  clickSupportHubList() {
    return cy.get('[class^="styles__Trigger-sc-"]');
  }

  caseTileSupportHubCardName() {
    return cy.getByTestId('common-caseList-defaultItem-cardTitle');
  }

  caseTileSupportHubCardId() {
    return cy.getByTestId('common-caseList-defaultItem-cardId');
  }

  supportHubCustomerName() {
    return cy.getByTestId('supportHub-caseCustomer-CustomerName');
  }

  supportHubCaseId() {
    return cy.getByTestId('supportHub-caseHeader-caseNumber');
  }

  supportHubPopupCloseIcon() {
    return cy.getByTestId('supportHub-actionWrapper-closeDialog');
  }

  // waiting for the data-testid SLC-33519
  welcomePageTitle() {
    return cy.get('.styles__Title-sc-djup1-3');
  }

  // waiting for the data-testid SLC-33519
  welcomePageDescription() {
    return cy.get('.styles__Description-sc-djup1-4');
  }

  // waiting for the data-testid SLC-33519
  welcomePageLastNote() {
    return cy.get('.styles__VTLinkWrapper-sc-djup1-10');
  }

  threeDotMenuDropdown() {
    return cy.getByTestId('summary-teamBacklog--menu_trigger');
    // return cy.getByTestId('context-menu_trigger');
  }

  threeDotMenuCaseTileorListDropdown() {
    return cy.get('[data-testid$="__-menu_trigger"]');
  }

  editTeamButton() {
    return cy.contains('Edit team');
  }

  // waiting for the data-testid SLC-33519
  editTeamFlowTitle() {
    return cy.get('.styles__Title-sc-djup1-3');
  }

  teamTitleName() {
    return cy.get('[class^="styles__TeamName-sc"]');
  }

  selectingVirtualTeamList() {
    return cy.get('[class^="styles__TeamsListItem-sc-"]');
  }

  // waiting for the data-testid SLC-33519
  virtualTeamCancelButton() {
    return cy.get('.Button__ActionButton-sc-1c5e0zp-0').contains('Cancel');
  }

  // waiting for the data-testid SLC-33519
  virtualTeamSaveButton() {
    return cy.get('.Button__ActionButton-sc-1c5e0zp-0').contains('Save');
  }

  lmvTeamTitleName() {
    return cy.get('[class^="styles__Name-sc-"]');
  }

  // waiting for the data-testid SLC-33519
  lmvAgentName() {
    return cy.get('[class^="styles__AgentsList-sc-"] ._1RZFLstJ_MSq2-Riva77G6');
  }

  // waiting for the data-testid SLC-33519
  lmvAgentOpenCaseCount() {
    return cy.get('[class^="styles__CasesNumber-sc"]');
  }

  // waiting for the data-testid SLC-33519
  lmvAgentLinkButton() {
    return cy.get('[class^="styles__AgentLink-sc-1"]');
  }

  editCaseListButton() {
    return cy.contains('Edit Case List');
  }

  editCaseTileButton() {
    return cy.contains('Edit Case Tile');
  }

  deleteCaseListButton() {
    return cy.contains('Delete Case List');
  }

  deleteCaseTileButton() {
    return cy.contains('Delete Case Tile');
  }

  editCaseListLabelRadio() {
    return cy.getByTestId('myDashboard-createCardModal-caseListEditor-optionContent');
  }

  addCardPopup() {
    return cy.get('.sharedStyles__CreateCardModalWrapper-sc-101gp8h-3');
  }

  addCardCloseButton() {
    return cy.get('[class^="sharedStyles__CloseButtonWrapper-sc"]');
  }

  lmvCaseListSortDropdownText() {
    return cy.getByTestId('dropdown-trigger-text');
  }

  lmvCaseListSortDropdown() {
    return cy.getByTestId('common-dropdown-btn');
  }

  lmvCaseListSortDropdownSentimentScoreOption() {
    return cy.getByTestId('common-dropdown-sl_sentiment_score');
  }

  lmvCaseListSortDropdownAttentionScoreOption() {
    return cy.getByTestId('common-dropdown-sl_need_attention_score');
  }

  lmvCaseListSortDropdownConversationCountOption() {
    return cy.getByTestId('common-dropdown-sl_comment_count');
  }

  lmvCaseListSortDropdownResponderCountOption() {
    return cy.getByTestId('common-dropdown-sl_num_participants_ob_sort');
  }

  lmvCaseListSortDropdownLastOutboundMessageOption() {
    return cy.getByTestId('common-dropdown-sl_most_recent_outbound_sort');
  }

  lmvCaseListSortDropdownLastInboundMessageOption() {
    return cy.getByTestId('common-dropdown-sl_most_recent_inbound_sort');
  }

  lmvCaseListSortDropdownCaseOpenTimeOption() {
    return cy.getByTestId('common-dropdown-sl_created_at');
  }

  lmvCaseListSortDropdownCaseViewsOption() {
    return cy.getByTestId('common-dropdown-sl_case_views_num');
  }

  lmvTeamFirstAgentName() {
    return cy.get('[data-testid^="my__dashboard-agent__list-name"]').first();
  }

  lmvTeamFirstAgentCaseNumber() {
    return cy.get('[data-testid^="my__dashboard-agent__list-case__number"]').first();
  }

  /**
   * Creating the case list in the LMV page.
   */
  createCaseList() {
    this.addCardButton().should('be.visible').click();
    this.caseListButton().should('be.visible').click();
    this.addCardNextButton().should('be.visible').click();
    this.caseListLabelsRadio().eq(0).should('be.visible').click();
    this.caseListEditorAddButton().should('be.visible').click();
    this.cardTitleName().eq(0).invoke('text').should('include', 'Case List');
  }

  /**
   * Deleting the case list in the LMV page.
   */
  deleteCaseList() {
    this.threeDotMenuCaseTileorListDropdown().eq(0).click({ force: true });
    this.deleteCaseListButton().eq(0).click({ force: true });
    this.cardTitleName().should('not.exist');
  }

  /**
   * Deleting the case tile in the LMV page.
   */
  deleteCaseTile() {
    this.threeDotMenuCaseTileorListDropdown().eq(0).click({ force: true });
    this.deleteCaseTileButton().eq(0).click({ force: true });
    this.cardTitleName().should('not.exist');
  }

  /**
   * Edit the case list in the LMV page.
   */
  editCaseList() {
    this.threeDotMenuCaseTileorListDropdown().eq(0).click({ force: true });
    this.editCaseListButton().click({ force: true });
    this.caseListEditorTitleInput().click().clear().type('Case list edited');
    this.caseListLabelsRadio().eq(1).should('be.visible').click();
    this.caseListEditorAddButton().should('be.visible').click();
    this.cardTitleName().eq(0).invoke('text').should('include', 'Case list edited');
  }

  /**
   * Creating the case tile in the LMV page.
   */
  createCaseTile() {
    this.addCardButton().should('be.visible').click();
    this.caseTileButton().should('be.visible').click();
    this.addCardNextButton().should('be.visible').click();
    this.caseTileLabelsCheckbox().eq(0).click({ force: true });
    this.caseTileLabelsCheckbox().eq(1).click({ force: true });
    this.caseTileLabelsCheckbox().eq(6).click({ force: true });
    this.caseTileLabelsCheckbox().eq(7).click({ force: true });
    this.caseTileLabelsCheckbox().eq(8).click({ force: true });
    this.caseTileLabelsCheckbox().eq(9).click({ force: true });
    this.caseTileEditorAddButton().should('be.visible').click();
    this.cardTitleName().eq(0).invoke('text').should('include', 'Case Statistics');
  }

  /**
   * Verifying the support hub in case list.
   */
  verifyListSupportHub() {
    this.caseListSupportHubCaseId()
      .eq(0)
      .then(($btn) => {
        const caseID = $btn.text();
        this.clickSupportHubList().eq(0).click();
        cy.waitForLoaders();
        this.supportHubCaseId().should('contain.text', caseID);
        this.supportHubPopupCloseIcon().click();
      });
  }

  /**
   * Verifying the support hub in case tile.
   */
  verifyTileSupportHub() {
    this.caseTileSupportHubCardId()
      .eq(0)
      .then(($btn) => {
        const caseID = $btn.text();
        this.caseTileSupportHubCardId().eq(0).click();
        cy.waitForLoaders();
        this.supportHubCaseId().should('contain.text', caseID);
        this.supportHubPopupCloseIcon().click();
      });
  }

  /**
   * Verifying the welcome page in LMV.
   */
  verifyWelcomePage() {
    this.welcomePageTitle().should('have.text', 'You haven’t chosen your team yet!');
    this.welcomePageDescription().should('have.text', 'Select from your Virtual Teams below; this will curate this page to show only case belonging to your team.');
    this.welcomePageLastNote().should('have.text', 'Want to create a new team? Go to Virtual Teams');
  }

  /**
   * Edit the team in the LMV page.
   */
  editLMVTeam() {
    this.threeDotMenuDropdown().eq(0).click({ force: true });
    this.editTeamButton().click({ force: true });
    this.editTeamFlowTitle().should('have.text', 'Change your team');
    this.teamTitleName()
      .eq(0)
      .then(($btn) => {
        const expectedName = $btn.text();
        this.selectingVirtualTeamList().eq(0).click();
        this.virtualTeamSaveButton().click();
        this.lmvTeamTitleName().should('contain.text', expectedName);
      });
  }

  // waiting for the data-testid SLC-32706
  teamAgentList() {
    return cy.get('[class^="styles__AgentsList-sc-"]');
  }

  // waiting for the data-testid SLC-32706
  teamCard() {
    return cy.get('[class^="styles__CardContainer-sc-"]');
  }
}

export const lmvTeamPage = new LmvPageObject();
