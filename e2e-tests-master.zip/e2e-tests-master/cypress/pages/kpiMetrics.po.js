class KPIMetrics {
  summaryCard() {
    return cy.get('[data-testid^=metrics-summaryCard]');
  }

  // TODO: waiting for data test-id SLC-34201
  summaryCardInfoIcon() {
    return cy.getByTestId('metrics--operationalMetrics--hint-icon');
  }

  // TODO: Need to establish best practices regarding naming conventions
  summaryCardTooltip() {
    return cy.get('#customer-notes-hint-popover');
  }

  settingsTooltip() {
    return cy.get('[class*=PopperContainer]:not(#root)');
  }

  // TODO: waiting for data test-id SLC-34201
  settingsButton() {
    return cy.get('div[class*=SettingsBtn] a');
  }

  // highcharts locator class most likely won't change. Hence no need to create a data-testid
  // cardName = 'sla', 'Efficiency', 'Customer Experience'
  pieChartBackground(cardName) {
    const formattedName = cardName.toLowerCase().replaceAll(' ', '_');
    return cy.get(`[data-testid="metrics-summaryCard-${formattedName}"] .highcharts-background`);
  }

  // TODO: waiting for data test-id SLC-34201
  barChartBackground(cardName) {
    const formattedName = cardName.toLowerCase().replaceAll(' ', '_');
    return cy.get(`[data-testid="metrics-summaryCard-${formattedName}"] ._13rWSam7t4Bw-JmsI8QHKw`);
  }

  // highcharts locator class most likely won't change. Hence no need to create a data-testid
  metTargetChartLabel(cardName) {
    const formattedName = cardName.toLowerCase().replaceAll(' ', '_');
    return cy.get(`[data-testid="metrics-summaryCard-${formattedName}"] .highcharts-title`);
  }
}
export const kpiMetrics = new KPIMetrics();
