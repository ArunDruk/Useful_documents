class ShiftManagement {
  addShiftButton() {
    return cy.getByTestId('agentAssignmentShift-shiftDialog-addShiftButton');
  }

  deleteDialogCancelButton() {
    return cy.getByTestId('agentAssignmentShift-deleteShiftDialog-cancelButton');
  }

  deleteDialogDeleteButton() {
    return cy.getByTestId('agentAssignmentShift-deleteShiftDialog-deleteButton');
  }

  assignAgentPopoverSubmitButton() {
    return cy.getByTestId('agentAssignmentShift-assignModal-submitButton');
  }

  shiftBar() {
    return cy.get('[data-visible=true] > [data-testid^=assignmentHours-shiftBar]');
  }

  deleteDialogTodayRadioButton() {
    return cy.getByTestId('agentShift--deleteDialog--today_radiobtn');
  }

  deleteDialogDeleteAllRadioButton() {
    return cy.getByTestId('agentShift--deleteDialog--delete_radiobtn');
  }

  deleteDialogTodayAndFollowingRadioButton() {
    return cy.getByTestId('agentShift--deleteDialog--today_and_following_radiobtn');
  }

  createShiftDialogNameTextField() {
    return cy.getByTestId('agentShift--formDetails--textinput_name');
  }

  createShiftDialogCancelButton() {
    return cy.getByTestId('agentShift--formDetails--cancel_btn');
  }

  createShiftDialogSaveButton() {
    return cy.getByTestId('agentShift--formDetails--save_btn');
  }

  createShiftDialogCreateButton() {
    return cy.getByTestId('agentShift--formDetails--create_btn');
  }

  createShiftDialogDeleteButton() {
    return cy.getByTestId('agentShift--formDetails--delete_btn');
  }

  createShiftDialogAssignmentHrsDateLabel() {
    return cy.getByTestId('agentShift--formDetails--assignmentHours-fromDate');
  }

  createShiftDialogWorkingHrsDateLabel() {
    return cy.getByTestId('agentShift--formDetails--workingHours-fromDate');
  }

  createShiftDialogAssignmentHourFromTextField() {
    return cy.getByTestId('agentShift--formDetails--assignmenthour_textinput_from');
  }

  createShiftDialogAssignmentHourToTextField() {
    return cy.getByTestId('agentShift--formDetails--assignmenthour_textinput_to');
  }

  createShiftDialogInfoIconTooltip() {
    return cy.get('div[class*=show][data-id=tooltip]');
  }

  createShiftDialogCustomizeAssignmentHoursCheckbox() {
    return cy.getByTestId('animated-checkbox-isCustomizingAssignmentHours-Customize-id');
  }

  createShiftDialogCustomizeWorkingHoursCheckbox() {
    return cy.getByTestId('animated-checkbox-isCustomizingWorkingHours-Customize-id');
  }

  createShiftDialogAssignmentHoursTueFromSlot1() {
    return cy.getByTestId('agentShift--formDetails--assignmenthour_tue_from_0');
  }

  createShiftDialogAssignmentHoursTueToSlot1() {
    return cy.getByTestId('agentShift--formDetails--assignmenthour_tue_to_0');
  }

  createShiftDialogWorkingHoursFriFromSlot1() {
    return cy.getByTestId('agentShift--formDetails--workinghours_fri_from_0');
  }

  createShiftDialogWorkingHoursFriToSlot1() {
    return cy.getByTestId('agentShift--formDetails--workinghours_fri_to_0');
  }

  createShiftDialogWorkingHoursFromTextField() {
    return cy.getByTestId('agentShift--formDetails--workinghours_textinput_from');
  }

  createShiftDialogWorkingHoursToTextField() {
    return cy.getByTestId('agentShift--formDetails--workinghours_textinput_to');
  }

  createShiftDialogAssignmentHoursTueFromSlot2() {
    return cy.getByTestId('agentShift--formDetails--assignmenthour_tue_from_1');
  }

  createShiftDialogAssignmentHoursTueToSlot2() {
    return cy.getByTestId('agentShift--formDetails--assignmenthour_tue_to_1');
  }

  createShiftDialogAssignmentHoursTueAddSlotButton1() {
    return cy.getByTestId('agentShift--formDetails--assignmenthour_tue_addtimeblockbtn_0');
  }

  createShiftDialogColorPickerDropdown() {
    return cy.getByTestId('agentShift--formDetails--shiftColorPicker');
  }

  createShiftDialogtWeekdayInputField(day) {
    return cy.getByTestId(`agentShift--formDetails--weekday__${day}`);
  }

  createShiftDialogColorItem() {
    return cy.get('[data-testid^=agentShift--formDetails--shiftColorItem]');
  }

  missingHoursVisibilityToggle() {
    return cy.getByTestId('agentAssignmentCalendar-calendarToolbar-missingHoursTrigger');
  }

  noAssignmentHourInfoIconButton() {
    return cy.getByTestId('agentAssignmentCalendar-noAssignmentHour-infoBtn');
  }

  noAssignmentHour() {
    return cy.getByTestId('agentAssignmentCalendar-noAssignmentHour');
  }

  noAgentAssignAgentsButton(shiftName) {
    return cy.getByTestId(`agentAssignmentCalendar-${shiftName}-noAgent-assignAgentsBtn`);
  }

  assignAgentsButton(shiftName) {
    return cy.getByTestId(`agentAssignmentCalendar-${shiftName}-assignAgentsBtn`);
  }

  timezoneSwitcherTrigger() {
    return cy.getByTestId('agentAssignmentCalendar-calendarToolbar-timezoneSelectTrigger');
  }

  timezoneSwitcherSearchTextField() {
    return cy.getByTestId('agentAssignmentCalendar-calendarToolbar-timezoneSelectInput');
  }

  timezoneSwitcherSearchResultListItem() {
    return cy.getByTestId('agentAssignmentCalendar-calendarToolbar-timezoneSelectDropdownItem');
  }

  datePickerSelectedStartDate() {
    return cy.get('td.CalendarDay__selected_start');
  }

  copyAssignmentHoursButton() {
    return cy.getByTestId('agentShift--formDetails--copy_assignment_hour_btn');
  }

  workingHoursTrigger() {
    return cy.getByTestId('agentAssignmentCalendar-calendarToolbar-workingHoursTrigger');
  }

  shiftManagementContainer() {
    return cy.getByTestId('agentShiftManagementPage-container');
  }

  clickOnDeleteOptionsDeleteThisShift() {
    return cy.getByTestId('agentShift--deleteDialog--delete_radiobtn');
  }

  agentAssignmentCalendarNameSelector(shiftName) {
    return cy.get(`[data-testid='agentAssignmentCalendar-agentShift-${shiftName}']`);
  }
}
export const shiftManagement = new ShiftManagement();
