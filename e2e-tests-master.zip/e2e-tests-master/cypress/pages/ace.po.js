const firstCategoryTitle = 'Testing Category 1';
const firstCategoryFirstItemTitle = 'Testing Item 1 under Category 1';
const firstCategoryFirstItemDescription = 'Testing description 1 for item 1 under Category 1';
const secondCategoryTitle = 'Testing Category 2';
const secondCategoryFirstItemTitle = 'Testing Item 1 under Category 2';

export class AcePage {
  aceCaseID() {
    return cy.getByTestId('case-card-base-v2-caseInfo-id');
  }

  // TODO data-testid requested via SLC-34639.
  aceAgentAvatarIcon() {
    return cy.get('.EupdjNUWSmwGa_iryYxg2');
  }

  // TODO data-testid requested via SLC-34639.
  aceAgentAvatarDetailsPopup() {
    return cy.get('[class*=PopperContainer]');
  }

  // TODO data-testid requested via SLC-34639.
  aceAgentListTextfield() {
    return cy.get('.AgentList__ItemContent-sc-1ntkppn-2.dozIZM');
  }

  // TODO data-testid requested via SLC-34639.
  aceAgentCaseList() {
    return cy.get('[class^="CaseListBase__CardWrapper-sc-"]');
  }

  // TODO data-testid requested via SLC-34639.
  aceCaseListContainer() {
    return cy.get('[class^="CaseListBase__Container"]');
  }

  // TODO data-testid requested via SLC-34639.
  agentListTextField() {
    return cy.get('[class^=AgentList__Text]');
  }

  // TODO data-testid requested via SLC-34639.
  agentListBadgeField() {
    return cy.get('[class^=AgentList__Badge]');
  }

  downloadCSVButton() {
    return cy.getByTestId('ace-reviewList-actions--export');
  }

  recommendationsTab() {
    return cy.getByTestId('ace__tabs__recommendations');
  }

  completedEvaluationsTab() {
    return cy.getByTestId('ace__tabs__completedReviews');
  }

  datePeriod3WeeksTab() {
    return cy.getByTestId('ace__datePeriodSwitcher__last-week,3');
  }

  datePeriod2WeeksTab() {
    return cy.getByTestId('ace__datePeriodSwitcher__last-week,2');
  }

  datePeriodThisWeekTab() {
    return cy.getByTestId('ace__datePeriodSwitcher__this-week');
  }

  dropdownText() {
    return cy.getByTestId('dropdown-trigger-text');
  }

  recommendedSidebarDropdown() {
    return cy.getByTestId('caseEvaluation-reviewList-filter-sort-Recommended-btn');
  }

  recommendedCaseIDs() {
    return cy.get('data-testid*=caseEvaluation-list-container-recommended');
  }

  recommendedSidebarCaseIDs() {
    return cy.get('[data-testid^=caseEvaluation-list-container-recommended]');
  }

  recommendedSidebarExpandButton() {
    return cy.getByTestId('collapsibleSidebar-toggle').eq(0);
  }

  editChecklist() {
    return cy.getByTestId('ace__settings__trigger');
  }

  backToEvaluationButton() {
    return cy.getByTestId('ace__settings__goBack');
  }

  createNewChecklistButton() {
    return cy.getByTestId('ace__reviewTemplateEditor__createNew');
  }

  gotoDraftButton() {
    return cy.getByTestId('ace__reviewTemplateEditor__goToDrafts');
  }

  recentDraftTemplateLink() {
    return cy.getByTestId('ace__reviewTemplateListItem__0');
  }

  editDraftChecklistButton() {
    return cy.getByTestId('ace__reviewTemplateEditor__enterEditMode');
  }

  fiveScaleRatingButton() {
    return cy.getByTestId('ace__reviewTemplateEditor__ratingControl__5');
  }

  addNewCategoryButton() {
    return cy.getByTestId('ace__configurationChecklist__newCategory');
  }

  categoryTitleTextfield() {
    return cy.getByTestId('ace__categoryItem__Input');
  }

  itemTitleTextField() {
    return cy.getByTestId('ace__checklistItem__title');
  }

  itemDescriptionTextField() {
    return cy.getByTestId('ace__checklistItem__description');
  }

  saveChecklistButton() {
    return cy.getByTestId('ace__checklistItem__save');
  }

  addNewLibraryItemButton() {
    return cy.getByTestId('ace__decisionTreePicker__trigger');
  }

  addOneLibraryItemButton() {
    return cy.getByTestId('ace__decisionTreePicker__add');
  }

  escalationHandlingLibraryItemLink() {
    return cy.getByTestId('ace__decisionTreePicker__item__Escalation_Handling');
  }

  closureRequestLibraryItemLink() {
    return cy.getByTestId('ace__decisionTreePicker__item__Closure_Requests');
  }

  callSchedulingLibraryItemLink() {
    return cy.getByTestId('ace__decisionTreePicker__item__Call_Scheduling');
  }

  priorityChangeHandlingLibraryItemLink() {
    return cy.getByTestId('ace__decisionTreePicker__item__Priority_Change_Handling');
  }

  agentGreetingLibraryItemLink() {
    return cy.getByTestId('ace__decisionTreePicker__item___agent_capitalize__Greeting');
  }

  finishEditingButton() {
    return cy.getByTestId('ace__reviewTemplateEditor__exitEditMode');
  }

  itemEditingButton() {
    return cy.getByTestId('ace__checklistItem__edit');
  }

  itemEditSaveButton() {
    return cy.getByTestId('ace-category-edit-confirm');
  }

  draftPublishButton() {
    return cy.getByTestId('ace__reviewTemplateEditor__publish');
  }

  draftPublishConfirmButton() {
    return cy.getByTestId('ace__confirmationModal__submit');
  }

  currentDraftTab() {
    return cy.getByTestId('ace__settings__tabs__current');
  }

  draftsTab() {
    return cy.getByTestId('ace__settings__tabs__drafts');
  }

  previousVersionsTab() {
    return cy.getByTestId('ace__settings__tabs__previous-versions');
  }

  checklistDuplicateButton() {
    return cy.getByTestId('ace__reviewTemplateEditor__duplicate');
  }

  checklistHeaderTitle() {
    return cy.getByTestId('category-header-title');
  }

  checklistItemTitle() {
    return cy.getByTestId('category-item-title');
  }

  // TODO data-testid requested via SLC-34639.
  completedSectionTableField() {
    return cy.get('[class^="CompleteSectionTable__EmptyStateWrapper"]');
  }

  commonReviewButton() {
    return cy.get("[data-testid^='ace__caseReviewContainer__reviewBtn__']");
  }

  startReviewButton() {
    return cy.getByTestId('ace__caseReviewContainer__reviewBtn__start');
  }

  continueReviewButton() {
    return cy.getByTestId('ace__caseReviewContainer__reviewBtn__continue');
  }

  viewCaseReviewButton() {
    return cy.getByTestId('ace__caseReviewContainer__reviewBtn__openPublished');
  }

  markForReviewButton() {
    return cy.getByTestId('ace__caseReviewContainer__markForReview');
  }

  unmarkForReviewButton() {
    return cy.getByTestId('ace__caseReviewContainer__unmarkForReview');
  }

  // TODO data-testid requested via SLC-34639.
  markForReviewPopup() {
    return cy.get('[class*=PopperContainer]');
  }

  // TODO unique data-testid requested via SLC-34639.
  categoryChecklistItemInSamePageReview() {
    return cy.get('[data-testid^="ace-case-review-checklist-item"]');
  }

  reviewPageCategoryCommentsArea() {
    return cy.getByTestId('ace-evaluation-category-zero-comments');
  }

  // TODO data-testid requested via SLC-34639.
  reviewPageCategoryHeader() {
    return cy.get('[class^="CaseReviewPanel__CategoryRating"]');
  }

  // TODO data-testid requested via SLC-34639 also data status requested via- SLC-34802
  reviewPageCollapseAllButton() {
    return cy.get('[class^="shared__CategoryHeader-sc"]').first();
  }

  reviewPageErrorNotificationPopup() {
    return cy.getByTestId('ace-evaluations-notification');
  }

  reviewPageCaseFieldStatus() {
    return cy.getByTestId('supportHub-caseField-status');
  }

  reviewPageCaseFieldPriority() {
    return cy.getByTestId('supportHub-caseField-priority');
  }

  // TODO data-testid requested via SLC-34639.
  reviewPageAgentNameHeader() {
    return cy.get('[class^="CaseHeader__AvatarName-sc"]');
  }

  // TODO data-testid requested via SLC-34639.
  reviewPageCaseInsightListItem() {
    return cy.get('[class^="CaseInsightList__Item"]');
  }

  // TODO data-testid requested via SLC-34639.
  reviewPageCaseId() {
    return cy.get('[class^="CaseHeader__CaseId-sc"]');
  }

  // TODO data-testid requested via SLC-34639.
  reviewPageHeaderSavedTextTextArea() {
    return cy.get('[class^=CaseReviewPanel__HeaderExtra]');
  }

  caseReviewSummaryPageBackToCaseButton() {
    return cy.getByTestId('ace__caseReviewSummary_backToCase');
  }

  caseReviewSummaryPageCancelButton() {
    return cy.getByTestId('ace__caseReviewSummary__cancel');
  }

  caseReviewSummaryReviewDetailsButton() {
    return cy.getByTestId('ace__caseReviewSummary_backToReview');
  }

  caseReviewSummaryDownloadPdfButton() {
    return cy.getByTestId('ace__caseReviewSummary__downloadPDF');
  }

  caseReviewDetailsEditButton() {
    return cy.getByTestId('ace__caseReviewSummary__reopen');
  }

  crmLinkReviewPage() {
    return cy.getByTestId('supportHub-actionWrapper-openNewTab');
  }

  crmLinkPopupreviewPage() {
    return cy.getByTestId('supportHub-actionWrapper-openNewTabTooltip');
  }

  // TODO data-testid requested via SLC-34639.
  caseReviewMessageContainer() {
    return cy.get('[class^="CaseReviewPublished__MessageContainer-sc"]');
  }

  caseReviewHeaderTitle() {
    return cy.getByTestId('ace-case-review-title');
  }

  poorRatingButton() {
    return cy.getByTestId('supportHub-caseComment-caseReview-rating-Poor');
  }

  badRatingButton() {
    return cy.getByTestId('supportHub-caseComment-caseReview-rating-Bad');
  }

  neutralRatingButton() {
    return cy.getByTestId('supportHub-caseComment-caseReview-rating-Neutral');
  }

  goodRatingButton() {
    return cy.getByTestId('supportHub-caseComment-caseReview-rating-Good');
  }

  greatRatingButton() {
    return cy.getByTestId('supportHub-caseComment-caseReview-rating-Great');
  }

  notApplicableRatingButton() {
    return cy.getByTestId('supportHub-caseComment-caseReview-rating-Not_Applicable');
  }

  nextReviewConfirmationPopupWindow() {
    return cy.getByTestId('ace__caseReviewContainer__next');
  }

  completeReviewConfirmationPopupWindow() {
    return cy.getByTestId('ace__caseReviewSummary__completeReview');
  }

  // TODO data-testid requested via SLC-34639.
  completedReviewPublishedTitle() {
    return cy.get('[class^="CaseReviewPublished__Title"]');
  }

  // TODO data-testid requested via SLC-34639.
  completedReviewPublishedContainer() {
    return cy.get('[class^="CaseReviewPublished__Container"]');
  }

  // TODO data-testid requested via SLC-34639.
  completedReviewEmptyMessageTitle() {
    return cy.get('[class^="CaseSuggestions__EmptyMessage"]');
  }

  completedReviewCaseCard() {
    return cy.getByTestId('case-card-base-accountInfo-name');
  }

  aceCardRatingItemLabel() {
    return cy.getByTestId('ace-card-rating-item-label');
  }

  // TODO data-testid requested via SLC-34639.
  completedEvaluationsTableCustomerColumn() {
    return cy.get('[class^="Table__TableCell-"][data-testid="table-body-cell_Customer"]').eq(1);
  }

  // TODO data-testid requested via SLC-34639.
  completedEvaluationsTableWeekGroupContainer() {
    return cy.get('[class^="CompleteSectionTable__WeekGroupContainer"]');
  }

  completedEvaluationsTableTicketsCountTitle() {
    return cy.getByTestId('ace-evaluation-completed-completed');
  }

  // TODO data-testid requested via SLC-34639.
  completedEvaluationsTableAgentColumnLists() {
    return cy.get('[class^="AgentInfoContainer__Container"] ._1RZFLstJ_MSq2-Riva77G6');
  }

  // TODO data-testid requested via SLC-34639.
  completedEvaluationsTableAgentColumn() {
    return cy.get('[class^="AgentInfoContainer__Container"] ._1RZFLstJ_MSq2-Riva77G6').first();
  }

  // TODO data-testid requested via SLC-34639.
  completedEvaluationsTableAgentItemContent() {
    return cy.get('[class^="AgentList__MutedText"]');
  }

  // TODO data-testid requested via SLC-34639.
  completedEvaluationsTableEvaluaterColumn() {
    return cy.getByTestId('table-body-cell_Evaluator').eq(1);
  }

  completedEvaluationsTableEvaluatedTimeColumn() {
    return cy.getByTestId('table-body-cell_Evaluated').eq(1);
  }

  completedEvaluationsTableNeutralRatingColumn() {
    return cy.getByTestId('supportHub-caseComment-caseReview-rating-Neutral').first();
  }

  completedEvaluationsTableChecklistHeaderTitleFirst() {
    return cy.getByTestId('table-header-cell_Testing Category 1');
  }

  completedEvaluationsTableChecklistHeaderTitleSecond() {
    return cy.getByTestId('table-header-cell_Testing Category 2');
  }

  completedReviewPageBadRatingButton() {
    return cy.getByTestId('supportHub-caseComment-caseReview-rating-Bad').last();
  }

  completedReviewPageGoodRatingButton() {
    return cy.getByTestId('supportHub-caseComment-caseReview-rating-Good').last();
  }

  completedReviewPageGreatRatingButton() {
    return cy.getByTestId('supportHub-caseComment-caseReview-rating-Great').last();
  }

  completedReviewPagePoorRatingButton() {
    return cy.getByTestId('supportHub-caseComment-caseReview-rating-Poor').last();
  }

  completedReviewPageNeutralRatingButton() {
    return cy.getByTestId('supportHub-caseComment-caseReview-rating-Neutral').last();
  }

  completedReviewPageNotApplicableRatingButton() {
    return cy.getByTestId('supportHub-caseComment-caseReview-rating-Not_Applicable').last();
  }

  // TODO data-testid requested via SLC-34639.
  completedReviewPageAverageRating() {
    return cy.get('[class^="CaseReviewSummary__CategoryRatingWrapper"]').first();
  }

  // TODO data-testid requested via SLC-34639.
  completedSummaryPageAverageRating() {
    return cy.get('[class^="ReviewSummary__RatingWrapper"]').first();
  }

  downloadCSVButtonCompletedEvaluationTab() {
    return cy.getByTestId('ace-evaluation-completed-completed-export-btn');
  }

  aceCaseSummaryCloseButton() {
    return cy.getByTestId('ace__caseReviewSummary__close');
  }

  dropdownRecommendedList() {
    return cy.getByTestId('common-dropdown-_signal_count');
  }

  dropdownConversationsList() {
    return cy.getByTestId('common-dropdown-_sl_comment_count');
  }

  dropdownCollaboratorsList() {
    return cy.getByTestId('common-dropdown-_sl_num_participants_ob');
  }

  backButtonInSamePageReview() {
    return cy.getByTestId('ace__caseReviewContainer__back');
  }

  cancelButtonInSamePageReview() {
    return cy.getByTestId('ace__caseReviewContainer__cancel');
  }

  cancelReviewConfirmationPopupWindow() {
    return cy.getByTestId('ace__messageModal__message');
  }

  cancelButtonInCancelReviewConfirmationPopupWindow() {
    return cy.getByTestId('ace__confirmationModal__cancel');
  }

  submitButtonInCancelReviewConfirmationPopupWindow() {
    return cy.getByTestId('ace__confirmationModal__submit');
  }

  categoryTitleTextInSamePageReview() {
    return cy.getByTestId('ace__categoryItem__enterEditMode');
  }

  recommendedContainerHeader() {
    return cy.getByTestId('caseEvaluation-collapsibleSidebar-title-Recommended');
  }

  recommendedCaseCard(caseId) {
    if (caseId) {
      return cy.getByTestId(`caseEvaluation-list-container-recommended-${caseId}`);
    }
    return cy.get('[data-testid^=caseEvaluation-list-container-recommended]');
  }

  reviewListCaseCard(caseId) {
    if (caseId) {
      return cy.getByTestId(`caseEvaluation-list-container-reviewList-${caseId}`);
    }
    return cy.get('[data-testid^=caseEvaluation-list-container-reviewList]');
  }

  commonAgentNameLabel() {
    return cy.getByTestId('ace-case-review-agantName');
  }

  agentFilterButton() {
    return cy.getByTestId('ace__agentFilter__trigger');
  }

  celebrateEmojiButton() {
    return cy.getByTestId('ace__caseReview__emoji_celebrate');
  }

  celebrateEmojiSelectedInSamePageReview() {
    return cy.getByTestId('ace__caseReview__emoji_celebrate_selected');
  }

  starEmojiSelectedInSamePageReview() {
    return cy.getByTestId('ace__caseReview__emoji_star_selected');
  }

  // TODO data-testid requested via SLC-34639.
  reviewCommentListText() {
    return cy.get('[class^="ReviewCommentList__Text"]');
  }

  // TODO data-testid requested via SLC-34639.
  reviewCommentViewListText() {
    return cy.get('[class^="CaseReviewCommentView__Text"]');
  }

  // TODO data-testid requested via SLC-34639.
  reviewCommentViewCategoryText() {
    return cy.get('[class^="CaseReviewCommentView__Categories"]');
  }

  reviewCommentTriggerLink() {
    return cy.getByTestId('ace-evaluation-category-comments-trigger');
  }

  // TODO data-testid requested via SLC-34639.
  categoryDropdownCheckboxLabel() {
    return cy.get('[class^="CategoriesDropdown__CheckboxLabel"]');
  }

  starEmojiButton() {
    return cy.getByTestId('ace__caseReview__emoji_star');
  }

  // TODO data-testid requested via SLC-34639.
  bubbleViewedInSamePageReview() {
    return cy.get('[class^="CaseReviewCommentView__Bubble"]');
  }

  // TODO data-testid requested via SLC-34639.
  caseReviewPanelTitle() {
    return cy.get('[class^="CaseReviewPanel__Title"]');
  }

  reviewKeyTakeAwayInputTextbox() {
    return cy.getByTestId('ace-case-review-textarea-keyTakeaways');
  }

  reviewCategoryInputTextbox() {
    return cy.getByTestId('ace-case-review-category-Textarea_Testing Category 1');
  }

  reviewSummaryKeyTakeAwayTitle() {
    return cy.getByTestId('ace-review-summary-key-takeaways-title');
  }

  reviewSummaryKeyTakeAwayContent() {
    return cy.getByTestId('ace-review-summary-category-comment-content');
  }

  reviewSummaryCategoryTitle() {
    return cy.getByTestId('ace-review-summary-category-title');
  }

  reviewSummaryCoachingFeedbackTitle() {
    return cy.getByTestId('ace-review-summary-coaching-feedback-title');
  }

  reviewSummaryCoachingFeedbackContent() {
    return cy.getByTestId('ace-review-summary-coaching-feedback-content');
  }

  reviewSummaryOtherCommentsTitle() {
    return cy.getByTestId('ace-review-summary-other-comments-title');
  }

  reviewSummaryCategorySliderComment() {
    return cy.getByTestId('ace-review-summary-category-slider-comment');
  }

  // Requested data-testid and data-status and its tracked in SLC-32654
  // Todo : Update this once SLC-32654 is fixed
  poorRatingSelectedInSamePageReview() {
    return cy.get("div[class='RatingControl__Option-sc-4q28at-2 dPqXYH'][data-testid=supportHub-caseComment-caseReview-rating-Poor]");
  }

  // Requested data-testid and data-status and its tracked in SLC-32654
  // Todo : Update this once SLC-32654 is fixed
  badRatingSelectedInSamePageReview() {
    return cy.get("div[class='RatingControl__Option-sc-4q28at-2 bVLkSg'][data-testid=supportHub-caseComment-caseReview-rating-Bad]");
  }

  creatingFiveScaleChecklistUI() {
    this.editChecklist().click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(5000);
    this.createNewChecklistButton().click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(5000);
    this.gotoDraftButton().click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(5000);
    this.recentDraftTemplateLink().click();
    this.editDraftChecklistButton().click();
    this.fiveScaleRatingButton().click();
    this.addNewCategoryButton().click();

    // Adding new category with custom item and library items
    this.categoryTitleTextfield().type(firstCategoryTitle);
    this.itemTitleTextField().type(firstCategoryFirstItemTitle);
    this.itemDescriptionTextField().type(firstCategoryFirstItemDescription);
    this.saveChecklistButton().click();

    // Adding five Library items
    this.addNewLibraryItemButton().click();
    this.closureRequestLibraryItemLink().click({ force: true });
    this.addOneLibraryItemButton().click({ force: true });
    this.addNewLibraryItemButton().click({ force: true });
    this.callSchedulingLibraryItemLink().click({ force: true });
    this.addOneLibraryItemButton().click({ force: true });
    this.addNewLibraryItemButton().click();
    this.callSchedulingLibraryItemLink().click({ force: true });
    this.addOneLibraryItemButton().click({ force: true });
    this.addNewLibraryItemButton().click();
    this.priorityChangeHandlingLibraryItemLink().click({ force: true });
    this.addOneLibraryItemButton().click({ force: true });
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    this.addNewLibraryItemButton().click();
    this.agentGreetingLibraryItemLink().click({ force: true });
    this.addOneLibraryItemButton().click({ force: true });
    this.finishEditingButton().click();
    this.draftPublishButton().click();
    this.draftPublishConfirmButton().click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    this.currentDraftTab().click();
    this.backToEvaluationButton().click();
  }

  creatingSingleChecklist() {
    cy.waitForLoaders();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(5000);
    this.createNewChecklistButton().click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(5000);
    this.gotoDraftButton().click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(5000);
    this.recentDraftTemplateLink().click();
    this.editDraftChecklistButton().click();
    this.fiveScaleRatingButton().click();
    this.addNewCategoryButton().click();

    // Adding new category with custom item and library items
    this.categoryTitleTextfield().type(firstCategoryTitle);
    this.itemTitleTextField().type(firstCategoryFirstItemTitle);
    this.saveChecklistButton().click();

    // Adding Library items
    this.addNewLibraryItemButton().click();
    this.escalationHandlingLibraryItemLink().click({ force: true });
    this.addOneLibraryItemButton().click({ force: true });
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    this.addNewLibraryItemButton().click();
    this.closureRequestLibraryItemLink().click({ force: true });
    this.addOneLibraryItemButton().click({ force: true });
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    this.finishEditingButton().click();
    this.draftPublishButton().click();
    this.draftPublishConfirmButton().click();
  }

  creatingSingleChecklistWithSixRatings() {
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(5000);
    this.createNewChecklistButton().click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(5000);
    this.gotoDraftButton().click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(5000);
    this.recentDraftTemplateLink().click();
    this.editDraftChecklistButton().click();
    this.fiveScaleRatingButton().click();
    this.addNewCategoryButton().click();

    // Adding new category with custom item and library items
    this.categoryTitleTextfield().type(firstCategoryTitle);
    this.itemTitleTextField().type(firstCategoryFirstItemTitle);
    this.saveChecklistButton().click();

    // Adding Library items
    this.addNewLibraryItemButton().click();
    this.callSchedulingLibraryItemLink().click({ force: true });
    this.addOneLibraryItemButton().click({ force: true });
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);

    // Adding Library items
    this.addNewLibraryItemButton().click();
    this.closureRequestLibraryItemLink().click({ force: true });
    this.addOneLibraryItemButton().click({ force: true });
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);

    // Adding Library items
    this.addNewLibraryItemButton().click();
    this.escalationHandlingLibraryItemLink().click({ force: true });
    this.addOneLibraryItemButton().click({ force: true });
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);

    // Adding Library items
    this.addNewLibraryItemButton().click();
    this.priorityChangeHandlingLibraryItemLink().click({ force: true });
    this.addOneLibraryItemButton().click({ force: true });
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);

    this.addNewLibraryItemButton().click();
    this.agentGreetingLibraryItemLink().click({ force: true });
    this.addOneLibraryItemButton().click({ force: true });
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);

    this.finishEditingButton().click();
    this.draftPublishButton().click();
    this.draftPublishConfirmButton().click();
  }

  creatingDoubleCategoryChecklist() {
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(5000);
    this.createNewChecklistButton().click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(5000);
    this.gotoDraftButton().click();
    cy.waitForLoaders();
    // hard wait is added for recent checklist to load in the draft page.
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(5000);
    this.recentDraftTemplateLink().click();
    this.editDraftChecklistButton().click();
    this.fiveScaleRatingButton().click();
    this.addNewCategoryButton().click();

    // Adding new category with custom item and library items
    this.categoryTitleTextfield().type(firstCategoryTitle);
    this.itemTitleTextField().type(firstCategoryFirstItemTitle);
    this.saveChecklistButton().click();

    // Adding Library items
    this.addNewLibraryItemButton().click();
    this.escalationHandlingLibraryItemLink().click({ force: true });
    this.addOneLibraryItemButton().click({ force: true });
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);

    this.addNewCategoryButton().click();
    // Adding new category with custom item and library items
    this.categoryTitleTextfield().type(secondCategoryTitle);
    this.itemTitleTextField().type(secondCategoryFirstItemTitle);
    this.saveChecklistButton().click();

    // Adding Library items
    this.addNewLibraryItemButton().eq(1).click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    this.agentGreetingLibraryItemLink().click({ force: true });
    this.addOneLibraryItemButton().click({ force: true });
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);

    this.finishEditingButton().click();
    this.draftPublishButton().click();
    this.draftPublishConfirmButton().click();
    this.currentDraftTab().click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
  }

  completedEvaluationsDropdown() {
    return cy.getByTestId('common-dropdown-btn');
  }

  dropdownGroupByWeekList() {
    return cy.getByTestId('common-dropdown-published_week');
  }

  dropdownGroupByAgentList() {
    return cy.getByTestId('common-dropdown-review_recipient_id');
  }

  recommendedContainer() {
    return cy.getByTestId('ace-reviewList-wrapper').eq(0);
  }

  toReviewContainer() {
    return cy.getByTestId('ace-reviewList-wrapper').eq(1);
  }

  inProgressContainer() {
    return cy.getByTestId('ace-reviewList-wrapper').eq(2);
  }

  recentlyReviewedContainer() {
    return cy.getByTestId('ace-reviewList-wrapper').eq(3);
  }

  evaluateLaterListToggle() {
    return cy.getByTestId('ace-card-action-Trigger-listToggle').eq(0);
  }

  groupByWeek() {
    this.completedEvaluationsDropdown().then((groupValue) => {
      const dropdownValue = groupValue.text();
      if (dropdownValue !== 'Week') {
        this.completedEvaluationsDropdown().click();
        this.dropdownGroupByWeekList().click();
      }
    });
  }

  coachingFeedbackButton() {
    return cy.getByTestId('supportHub-caseTimeline-caseComment-addCoachComment');
  }

  commentButtonInCoachingFeedbackWindow() {
    return cy.getByTestId('supportHub-caseComments_coaching-submit');
  }

  cancelButtonInCoachingFeedbackWindow() {
    return cy.getByTestId('supportHub-caseComments_coaching-cancel');
  }

  coachingFeedbackTextbox() {
    return cy.getByTestId('supportHub-caseComments_coaching-input');
  }

  addedCoachingFeedbackText() {
    return cy.getByTestId('supportHub-caseComments_coaching-content');
  }

  coachingFeedbackMenuButton() {
    return cy.getByTestId('context-menu_trigger');
  }

  coachingFeedbackEditButton() {
    return cy.getByTestId('supportHub-caseComments_coaching-context-menu-edit');
  }

  coachingFeedbackDeleteButton() {
    return cy.getByTestId('supportHub-caseComments_coaching-context-menu-delete');
  }

  // Requested data-testid and data-status and its tracked in SLC-34694
  // Todo : Update this once SLC-34694 is fixed
  coachingFeedbackEmptyStateMessage() {
    return cy.get('[class^=shared__ErrorMessage]');
  }

  // Requested data-testid and its tracked in SLC-35039
  agentCaseCount() {
    return cy.get('[class^=VirtEntityOptionItem__Count]');
  }

  aceChecklistReviewTemplateEditorCancleButton() {
    return cy.getByTestId('ace__reviewTemplateEditor__cancel');
  }

  aceChecklistItemCancelButton() {
    return cy.getByTestId('ace__checklistItem__cancel');
  }
}
export const acePage = new AcePage();
