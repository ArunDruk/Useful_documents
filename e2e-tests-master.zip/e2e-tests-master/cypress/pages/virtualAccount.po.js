// import { getCustomerNameFromCaseDetails } from '../e2e/SLC/customers/support';

const randId = () => Cypress._.random(0, 1e6);

export class VirtualAccountPage {
  // Virtual Account Page
  createVaButton() {
    return cy.getByTestId('virtualAccounts-groupList-customer_group-createButton');
  }

  virtualGroupLists() {
    return cy.getByTestId('virtualAccounts-logical_group-listItem');
  }

  virtualAccountLists() {
    return cy.getByTestId('virtualAccounts-customer_group-listItem');
  }

  virtualAccountNameListItem(vaName) {
    return cy.getByTestId('virtualAccounts-customer_group-listItem').find(`[data-label="${vaName}"]`);
  }

  searchVaNameInput() {
    return cy.getByTestId('virtualAccounts-groupList-customer_group-searchInput');
  }

  searchResultVaNameList() {
    return cy.getByTestId('virtualAccounts-customer_group-listItem-label');
  }

  searchResultSystemOfRecordsMergedAccountList() {
    return cy.getByTestId('virtualAccounts-sf_virtual_account-listItem-label');
  }

  virtualAccountDeleteButton() {
    return cy.getByTestId('virtualAccounts-listItem-customer_group-delete');
  }

  confirmDeleteVaPopupButton() {
    return cy.getByTestId('virtual-primary-team-alert-modal-btn_delete').scrollIntoView();
    // cy.getByTestId('common-button').contains('Delete').scrollIntoView();
  }

  cancelDeleteVaPopupButton() {
    return cy.getByTestId('virtual-primary-team-alert-modal-btn_cancel').scrollIntoView();
    // cy.getByTestId('common-button').contains('Cancel').scrollIntoView();
  }

  // waiting for the data-testid SLC-33287
  virtualAccountExpandCollapseListItemButton() {
    return cy.get('[data-testid="virtualAccounts-customer_group-listItem"] [class^="styles__CollapseBtn-sc-"]');
  }

  deleteVirtualAccountButton(vaName) {
    return cy.contains(vaName).parents('[data-testid="virtualAccounts-customer_group-listItem"]').find('[data-testid="virtualAccounts-listItem-customer_group-delete"]');
  }

  // Virtual Account Create popup
  vaAccountTypeGlobalButton() {
    return cy.getByTestId('virtualAccounts-chooseAccountType-global_account');
  }

  vaAccountTypePersonalButton() {
    return cy.getByTestId('virtualAccounts-chooseAccountType-personal_account');
  }

  vaCreatePopupCancelOrBackButton() {
    return cy.getByTestId('virtualAccounts-createAccount-backCancelButton');
  }

  vaCreatePopupSubmitOrNextButton() {
    return cy.getByTestId('virtualAccounts-createAccount-submitButton');
  }

  vaCreatePopupNameInput() {
    return cy.getByTestId('virtualAccounts-nameInput-searchInput');
  }

  vaNameErrorLabel() {
    return cy.get('[data-type="error-wrapper"]');
  }

  vaCreatePopupSearchCustomerNameInput() {
    return cy.getByTestId('virtualAccounts-searchBox-searchInput');
  }

  vaCreatePopupCustomerSearchResultList() {
    return cy.getByTestId('virtualAccounts-searchList-resultItem');
  }

  vaCreatePopupCustomerNameInSearchResultList() {
    return cy.get('[data-testid="virtualAccounts-searchList-resultItem"] span');
  }

  // Virtual Group
  virtualGroupCreateButton() {
    return cy.getByTestId('virtualAccounts-groupList-logical_group-createButton');
  }

  virtualGroupNameLists() {
    return cy.getByTestId('virtualAccounts-logical_group-listItem-label');
  }

  virtualGroupEditButton() {
    return cy.getByTestId('virtualAccounts-listItem-logical_group-edit');
  }

  virtualGroupCopyButton() {
    return cy.getByTestId('virtualAccounts-listItem-logical_group-clone');
  }

  virtualGroupDeleteButton() {
    return cy.getByTestId('virtualAccounts-listItem-logical_group-delete');
  }

  editVirtualGroupButton(vgName) {
    return cy.contains(vgName).parents('[data-testid="virtualAccounts-logical_group-listItem"]').find('[data-testid="virtualAccounts-listItem-logical_group-edit"]');
  }

  copyVirtualGroupButton(vgName) {
    return cy.contains(vgName).parents('[data-testid="virtualAccounts-logical_group-listItem"]').find('[data-testid="virtualAccounts-listItem-logical_group-clone"]');
  }

  deleteVirtualGroupButton(vgName) {
    return cy.contains(vgName).parents('[data-testid="virtualAccounts-logical_group-listItem"]').find('[data-testid="virtualAccounts-listItem-logical_group-delete"]');
  }

  // waiting for the data-testid SLC-33287
  selectedVAListInVirtualGroupLabel(vgName) {
    return cy.contains(vgName).parents('[data-testid="virtualAccounts-logical_group-listItem"]').find('.styles__Container-sc-pv2fg3-0');
  }

  editVirtualGroupSaveButton() {
    return cy.getByTestId('common-button').contains('Save');
  }

  editVirtualGroupCancelButton() {
    return cy.getByTestId('common-button').contains('Cancel');
  }

  // Virtual Group Create Popup
  virtualGroupAccountTypeGlobalButton() {
    return cy.getByTestId('virtualAccounts-chooseAccountType-global_group');
  }

  virtualGroupAccountTypePersonalButton() {
    return cy.getByTestId('virtualAccounts-chooseAccountType-personal_group');
  }

  vaFilterTrigger() {
    return cy.getByTestId('virtualAccounts-groupList-customer_group-filter_trigger');
  }

  vaFilterGlobalVirtualAccountCheckboxStatus() {
    return cy.getByTestId('animated-checkbox-default-group-Global Virtual Account-id').invoke('attr', 'data-status');
  }

  vaFilterPersonalVirtualAccountCheckboxStatus() {
    return cy.getByTestId('animated-checkbox-default-group-Personal Virtual Account-id').invoke('attr', 'data-status');
  }

  vaFilterSystemOfRecordsMergedAccountCheckboxStatus() {
    return cy.getByTestId('animated-checkbox-default-group-System of Records Merged Account-id').invoke('attr', 'data-status');
  }

  /**
   * Creating the Virtual Account of specified AccountType with two customers
   * @param accountType to be Global or Personal
   * @returns the created VirtualAccount Name
   */
  createVirtualAccount(accountType) {
    cy.intercept('POST', 'api/v2/group').as('createGroup');
    cy.intercept('search/virtual_groups/_search*').as('search');
    this.createVaButton().scrollIntoView().click();
    if (accountType === 'Global') {
      this.vaAccountTypeGlobalButton().should('be.visible').click();
    } else {
      this.vaAccountTypePersonalButton().should('be.visible').click();
    }
    const vaName = `Test ${accountType}Account ${randId()}`;
    this.vaCreatePopupNameInput().type(vaName);
    this.vaCreatePopupSubmitOrNextButton().should('be.visible').click();
    // Added as a temp fix until the "getCustomerNameFromCaseDetails" API is fixed
    this.vaCreatePopupSearchCustomerNameInput().should('be.visible').type('a');
    cy.wait('@search');
    this.vaCreatePopupCustomerSearchResultList().eq(0).click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(2000);
    this.vaCreatePopupCustomerSearchResultList().eq(1).click();
    // Temp fix end line
    /* Note: If fetched customer id is not valid/active, the tests will fail
    getCustomerNameFromCaseDetails().then((caseDetails) => {
      this.vaCreatePopupSearchCustomerNameInput().should('be.visible').clear().type(caseDetails[0].customerName);
      cy.wait('@search');
      this.vaCreatePopupCustomerSearchResultList().eq(0).click();
      this.vaCreatePopupSearchCustomerNameInput().should('be.visible').clear().type(caseDetails[1].customerName);
      cy.wait('@search');
      this.vaCreatePopupCustomerSearchResultList().eq(0).click();
    });
    */
    this.vaCreatePopupSubmitOrNextButton().should('be.visible').click();
    cy.wait('@createGroup');
    return vaName;
  }

  /**
   * Verifying the entered Virtual Account Name is present in the VA List
   * @param vaName Virtual Account Name to be verified
   * @returns True or False based on VA Name exist
   */
  verifyVirtualAccountIsPresent(vaName) {
    let vaIsPresent = 'False';
    this.searchVaNameInput().then(() => {
      this.searchVaNameInput().clear().type(vaName);
    });
    this.searchResultVaNameList().should('have.text', vaName);
    vaIsPresent = 'True';
    return vaIsPresent;
  }

  /**
   * Verifying the entered Virtual Account Name is not present in the VA List
   * @param vaName Virtual Account Name to be verified as not exist
   */
  verifyVirtualAccountIsNotPresent(vaName) {
    // waiting for the data-testid SLC-33287
    cy.get('[class^=styles__ContentWrapper-sc-]').then(($ele) => {
      if ($ele.find('[data-testid=virtualAccounts-customer_group-listItem-label]').length > 0) {
        this.searchResultVaNameList().should('not.contain', vaName);
      }
    });
  }

  /**
   * Deleting the given Virtual Account
   * @param vaName Virtual Account Name to be deleted
   */
  deleteVirtualAccount(vaName) {
    const vaIsPresent = this.verifyVirtualAccountIsPresent(vaName);
    if (vaIsPresent === 'True') {
      this.virtualAccountDeleteButton().click();
      this.confirmDeleteVaPopupButton().click();
      this.searchVaNameInput().clear();
      this.verifyVirtualAccountIsNotPresent(vaName);
    }
  }

  editVirtualAccount(vaName) {
    cy.contains(vaName)
      .parents('[data-testid=virtualAccounts-customer_group-listItem]')
      .within(() => {
        cy.getByTestId('virtualAccounts-listItem-customer_group-edit').click();
      });
  }

  cloneVirtualAccount(vaName) {
    cy.contains(vaName).parents('[data-testid=virtualAccounts-customer_group-listItem]').find('[data-testid=virtualAccounts-listItem-customer_group-clone]').click();
  }

  /**
   * Creating the Virtual Group of specified AccountType with two Virtual Account
   * @param accountType to be Global or Personal
   * @returns the created VirtualGroup Name
   */
  createVirtualGroup(accountType) {
    cy.intercept('POST', 'api/v2/group').as('createGroup');
    cy.intercept('search/virtual_groups/_search*').as('search');
    this.virtualGroupCreateButton().scrollIntoView().click();
    if (accountType === 'Global') {
      this.virtualGroupAccountTypeGlobalButton().should('be.visible').click();
    } else {
      this.virtualGroupAccountTypePersonalButton().should('be.visible').click();
    }
    const vgName = `Test ${accountType}Group ${randId()}`;
    this.vaCreatePopupNameInput().type(vgName);
    this.vaCreatePopupSubmitOrNextButton().should('be.visible').click();
    this.vaCreatePopupSearchCustomerNameInput().should('be.visible').type('a');
    cy.wait('@search');
    this.vaCreatePopupCustomerSearchResultList().eq(0).click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(2000);
    this.vaCreatePopupCustomerSearchResultList().eq(1).click();
    this.vaCreatePopupSubmitOrNextButton().should('be.visible').click();
    cy.wait('@createGroup');
    return vgName;
  }

  /**
   * Verifying the entered Virtual Group Name is present in the VG List
   * @param vgName Virtual Group Name to be verified
   * @returns True or False based on VG Name exist
   */
  verifyVirtualGroupIsPresent(vgName) {
    let vgIsPresent = 'False';
    this.virtualGroupNameLists().invoke('text').should('contain', vgName);
    vgIsPresent = 'True';
    return vgIsPresent;
  }

  /**
   * Verifying the entered Virtual Group Name is not present in the VG List
   * @param vgName Virtual Group Name to be verified as not exist
   */
  verifyVirtualGroupIsNotPresent(vgName) {
    // waiting for the data-testid SLC-33287
    cy.get('[class^=styles__ContentWrapper-sc-]').then(($ele) => {
      if ($ele.find('[data-testid=virtualAccounts-logical_group-listItem-label]').length > 0) {
        this.searchResultVaNameList().should('not.contain', vgName);
      }
    });
  }

  /**
   * Verify the vgName exist in page and Deleting the given Virtual Group
   * @param vgName Virtual Group Name to be deleted
   */
  deleteVirtualGroup(vgName) {
    const vgIsPresent = this.verifyVirtualGroupIsPresent(vgName);
    if (vgIsPresent === 'True') {
      this.virtualGroupNameLists().then((vgNameList) => {
        for (let i = 0; i < vgNameList.length; i += 1) {
          const vgroupName = vgNameList.eq(i).text();
          if (vgroupName === vgName) {
            this.virtualGroupDeleteButton().eq(i).scrollIntoView().click();
            this.confirmDeleteVaPopupButton().click();
            this.verifyVirtualGroupIsNotPresent(vgName);
          }
        }
      });
    }
  }
}

export const virtualAccount = new VirtualAccountPage();
