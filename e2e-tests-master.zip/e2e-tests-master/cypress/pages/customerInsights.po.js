class CustomerInsights {
  searchTextfield() {
    return cy.getByTestId('customerInsights-searchBar-searchInput');
  }

  searchResultsList() {
    return cy.getByTestId('customerInsights-searchBar-searchOption-item');
  }

  searchResultListCustomerNameLabel() {
    return cy.getByTestId('customerInsights-searchBar-searchOption-item__label');
  }

  recentlyVisitedItem() {
    return cy.getByTestId('customersPage-searchTab-visitedCustomer-recentVisitItem');
  }

  healthScoreTab() {
    return cy.getByTestId('tabNav__ahs');
  }

  shareButton() {
    return cy.getByTestId('customers-addFavorite-shareButton');
  }

  insightsTab() {
    return cy.getByTestId('tabNav__insights');
  }

  insightTabDataViewContainer() {
    return cy.get('#customer-data-view');
  }

  // waiting for data-testid SLC-33611
  insightSubTabDataViewContainer() {
    return cy.get('#customer-data-view [class^="Content__Container-sc-"]');
  }

  // waiting for data-testid SLC-31060
  insightTabCustomerScoreLabel() {
    return cy.get('[class^="CustomerDataView__LeftPanel-sc"] div[style]');
  }

  favoriteButton() {
    return cy.getByTestId('customersPage-customerInfo-favoriteCustomerTrigger');
  }

  customerNameLabel() {
    return cy.getByTestId('customerPage-customerInfo-customerName');
  }

  customerNotesTextarea() {
    return cy.getByTestId('customerPage-customerNote-notesInput');
  }

  // TODO data-testid requested via SLC-35284.
  customerNotesHintPopOver() {
    return cy.get('._1Y_DTccGARCe8HZCc00kFD');
  }

  customerNotesCancelButton() {
    return cy.getByTestId('customerPage-customerNote-cancelNoteBtn');
  }

  customerNotesAddButton() {
    return cy.getByTestId('customerPage-customerNote-addNoteBtn');
  }

  allTabs() {
    return cy.get('[data-testid^=customersPage-tabSlider]');
  }

  commonTabCard(tabName) {
    const formattedTabName = tabName.toLowerCase().replaceAll(' ', '_');

    return cy.getByTestId(`customersPage-tabSlider-${formattedTabName}`);
  }

  tabCaseCountLabel(tabName) {
    const formattedTabName = tabName.replace(' ', '_');

    return cy.getByTestId(`consolePage-tabsSlider-tab-count-${formattedTabName}`);
  }

  // TODO data-testid requested via SLC-35284.
  overviewTabRecentCasesHeader() {
    return cy.get('._2ELWpJmKAzkFj5Vin9En-v');
  }

  // TODO data-testid requested via SLC-35284.
  overviewTabSortOrderButtonTooltip() {
    return cy.get('._78hqQYxd1vi3DDjjJVkJ._3czN3Zz0sZvukIpl1GuFo7._1vg-K0K-GYd7E-Qvb7Def7').last();
  }

  overviewTabStatusChartTitle() {
    return cy.getByTestId('chartWrapper-_support_customer_insights__sl_status');
  }

  overviewTabPriorityChartTitle() {
    return cy.getByTestId('chartWrapper-_support_customer_insights__sl_priority');
  }

  overviewTabSortByDropdownCreatedAtOption() {
    return cy.getByTestId('common-dropdown-sl_created_at');
  }

  overviewTabSortByDropdownRecentActivityOption() {
    return cy.getByTestId('common-dropdown-sl_updated_at');
  }

  overviewTabSortByDropdownSentimentScoreOption() {
    return cy.getByTestId('common-dropdown-sl_sentiment_score');
  }

  overviewTabSortByDropdownAttentionScoreOption() {
    return cy.getByTestId('common-dropdown-sl_need_attention_score');
  }

  overviewTabSortByDropdownClosedAtOption() {
    return cy.getByTestId('common-dropdown-sl_closed_at');
  }

  overviewTabSortByDropdown() {
    return cy.getByTestId('customersPage-sortableCaseList-dropdown');
  }

  overviewTabSortOrderButton() {
    return cy.getByTestId('customersPage-sortableCaseList-orderIcon');
  }

  overviewTabOpenTab() {
    return cy.getByTestId('common-buttonSwitcher-btn').first();
  }

  overviewTabRecentlyClosedTab() {
    return cy.getByTestId('common-buttonSwitcher-btn').last();
  }

  overviewTabCaseListItem() {
    return cy.getByTestId('common-caseList-sideListItem');
  }

  overviewTabCaseListItemSentimentScoreLabel() {
    return cy.getByTestId('consolePage-tabs-case-card-sentiment-score');
  }

  overviewTabCaseListItemAttentionScoreLabel() {
    return cy.getByTestId('consolePage-tabs-case-card-need-attention-score');
  }

  overviewTabCaseListItemCaseIdLabel() {
    return cy.getByTestId('common-caseList-defaultItem-cardId');
  }

  overviewTabCaseListItemTimeLabel() {
    return cy.get('[data-testid=common-caseList-defaultItem-cardSubject] + span');
  }

  commonOverviewChartMenuButton() {
    return cy.get('[data-testid$=--settings--popup-trigger]');
  }

  escalationsGroupByDropdown() {
    // TODO: Get data-testid for groupBy dropdown (SLC-33611)
    return cy.get('[class^=EscActivityGrid__DropdownTrigger]');
  }

  groupByOptionEscalationState() {
    return cy.getByTestId('common-dropdown-escActivityType');
  }

  escalationSubTab(subTabName) {
    return cy.getByTestId(`optionsSwitcherNew-option-${subTabName}`);
  }

  escalationCaseCard() {
    return cy.getByTestId('case-card-base-wrapper');
  }

  oldLteCardActionButtons() {
    return cy.get('[class^=ConsolePageLtbeCard__ActionsWrapper] button');
  }

  // Used for Need attention, sentiments & product feedback tabs
  consoleTabsCaseCards() {
    return cy.getByTestId('consolePage-tabs-case-card');
  }

  overviewTabCommonChartPoint() {
    return cy.get('[data-testid^="chartWrapper-_support_customer_insights"] .highcharts-point');
  }

  commonCasesPopup() {
    return cy.getByTestId('common__ticketsPopup');
  }

  commonCasesPopupDownloadButton() {
    return cy.get('[data-testid="common__ticketsPopup"] button').eq(0);
  }

  commonCasesPopupSortButton() {
    return cy.get('[data-testid="common__ticketsPopup"] button').eq(1);
  }

  commonCasesPopupListsCaseIdLabel() {
    return cy.get('[data-testid="common__ticketsPopup"] [data-testid="common-caseList-defaultItem-cardId"]');
  }

  searchFor(searchText) {
    cy.intercept('POST', 'search/virtual_groups/_search*').as('searchCustomer');

    this.searchTextfield().type(searchText);
    cy.wait('@searchCustomer');
  }

  sortCasesBy(optionName) {
    this.overviewTabSortByDropdown()
      .invoke('text')
      .then((currentVal) => {
        if (currentVal !== optionName) {
          this.overviewTabSortByDropdown().click();
          cy.contains('[data-testid^=common-dropdown-sl]', RegExp(optionName, 'i')).click();
        }
      });
  }

  switchSortDirection(direction = 'desc') {
    this.overviewTabSortOrderButton()
      .find('svg')
      .invoke('attr', 'data-status')
      .then((currentDirection) => {
        if (currentDirection !== direction) this.overviewTabSortOrderButton().click();
      });
  }
}

export const customerInsights = new CustomerInsights();
