export class GlobalSearchPageObject {
  // TODO - SLC-33502 for data-testid request
  noResultsFoundLabel() {
    return cy.get('._3lWO0j6uHavxvx7r3_Wj9Z ._179sx-Zv1POW5ujSPbRQb5');
  }

  globalSearchButton() {
    return cy.getByTestId('global-search-trigger');
  }

  globalSearchInput() {
    return cy.getByTestId('global-search-input');
  }

  globalSearchResultListItem() {
    return cy.getByTestId('global-search-caseView-listItem');
  }
}

export const globalSearch = new GlobalSearchPageObject();
