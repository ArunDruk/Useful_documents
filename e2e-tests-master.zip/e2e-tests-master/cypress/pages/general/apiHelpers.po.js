import moment from 'moment';
import { targetDatabase } from '../../utils';
import { pages } from '../../utils/modulesList';

const predicates = [
  { column: 'sl_is_closed', op: '=', value: 'false' },
  { column: 'sl_account_id', op: '<>', value: 'null' },
  { column: 'sl_requester_id', op: '<>', value: 'null' },
];

const now = new Date();
const editEscalationReviewActions = (actionTypes, value) => {
  const data = {
    CASE_NOTE: true,
    CONTACT_AGENT: true,
    CONTACT_CUSTOMER: true,
    CUSTOMER_NOTE: true,
    ESCALATION_NOTE: true,
    REASSIGN: true,
    SHARE_CASE: true,
    UPDATE_CASE_FIELD: true,
    actionTypes: {
      CASE_NOTE: true,
      CONTACT_AGENT: true,
      CONTACT_CUSTOMER: true,
      CUSTOMER_NOTE: true,
      ESCALATION_NOTE: true,
      REASSIGN: true,
      SHARE_CASE: true,
      UPDATE_CASE_FIELD: true,
    },
  };

  // eslint-disable-next-line no-return-assign
  actionTypes.map((actionType) => (data[actionType] = value));

  cy.request({
    method: 'POST',
    url: 'api/company/settings/support',
    body: {
      settings: {
        escalations_page_settings: { escalation_review_action_restrictions: data },
        sl_last_updated: Date.now(),
      },
      replace: false,
      keys: ['escalations_page_settings', 'escalation_review_action_restrictions'],
    },
  });
};

class ApiHelpers {
  getOpenCaseDetails = () =>
    cy.slcHelpers
      .getCaseDetails({ predicates })
      // eslint-disable-next-line camelcase
      .then(({ body }) => body.map(({ id, sl_account_id, sl_account_name }) => ({ caseId: id, customerId: sl_account_id, customerName: sl_account_name })));

  setUserRole() {
    cy.request({
      method: 'PUT',
      url: 'api/users/role',
      body: { role: 'Support QA' },
    });
  }

  resetSlUserModuleOnboardingState() {
    cy.request('api/users/profile').then(({ body }) =>
      cy.request({
        method: 'POST',
        url: 'api/company/settings/support',
        body: {
          replace: true,
          keys: ['modules_onboarding_state'],
          modules_onboarding_state: pages.reduce(
            (acc, page) => ({
              ...acc,
              [page]: {
                forCustomer: false,
                forSlUser: true,
                slUser: { date: new Date(), user: body.s_id },
              },
            }),
            {}
          ),
        },
      })
    );
  }

  onboardCurrentUser() {
    cy.request({
      method: 'PUT',
      url: 'api/users/dashboard_settings',
      body: {
        dashboardName: 'support',
        settingsKey: 'modules_onboarding',
        settingsSubKey: null,
        settingsValue: pages.reduce((acc, module) => ({ ...acc, [module]: now }), {}),
        replace: false,
      },
    });
  }

  isModuleEnabled(moduleName) {
    return cy.request('api/company/settings/support').then(({ body }) => {
      const { [moduleName]: isEnabled = true } = body.activeCompanySettings.dashboard_restrictions.pages;
      return isEnabled === true;
    });
  }

  resetLegendFilters = () =>
    cy.request({
      method: 'PUT',
      url: 'api/users/dashboard_settings',
      body: {
        dashboardName: 'support',
        settingsKey: 'sentiments_page_settings',
        settingsSubKey: 'sentiment_selected_tabs',
        settingsValue: { 'Feature Requests': true, Negative: true, Positive: true, 'Product Feedback': true },
        replace: false,
      },
    });

  removeAllFavoriteCustomers = () =>
    cy.request({
      method: 'PUT',
      url: 'api/users/dashboard_settings',
      body: {
        dashboardName: 'support',
        settingsKey: 'favorite_customers',
        settingsSubKey: null,
        settingsValue: { AllFavoritesCustomersGroupID: [] },
        replace: true,
      },
    });

  addCustomerNote = (noteText, customerId, customerName) =>
    cy
      .request({
        method: 'POST',
        url: 'api/customer-notes',
        headers: { 'Content-Type': 'application/json' },
        body: {
          customerName,
          sl_customer_id: customerId,
          text: noteText,
        },
      })
      .then(({ body }) => body.note.id);

  deleteCustomerNote = (noteId) => cy.request('DELETE', `api/customer-notes/${noteId}`);

  setToDefaultListBacklog() {
    cy.request({
      method: 'PUT',
      url: '/api/users/dashboard_settings',
      headers: { 'Content-Type': 'application/json' },
      body: {
        dashboardName: 'support',
        settingsKey: 'cases_page_settings',
        settingsSubKey: 'cases_tab_items',
        settingsValue: [],
        replace: true,
      },
    });
  }

  setToWelcomePageBacklog() {
    cy.request({
      method: 'PUT',
      url: '/api/users/dashboard_settings',
      headers: { 'Content-Type': 'application/json' },
      body: {
        dashboardName: 'support',
        settingsKey: 'cases_page_settings',
        settingsSubKey: 'cases_tab_items',
        settingsValue: [
          {
            id: 'sentimentScore-default-list',
            isDeleted: true,
          },
          {
            id: 'attentionScore-default-list',
            isDeleted: true,
          },
          {
            id: 'caseOpenTime-default-list',
            isDeleted: true,
          },
          {
            id: 'lastUnrepliedCase-default-list',
            isDeleted: true,
          },
        ],
        replace: true,
      },
    });
  }

  setToDefaultTeamLMV(vteamId) {
    cy.request({
      method: 'PUT',
      url: '/api/users/dashboard_settings',
      headers: { 'Content-Type': 'application/json' },
      body: {
        dashboardName: 'support',
        settingsKey: 'virtual_teams_user_settings',
        settingsSubKey: null,
        settingsValue: {
          primary_team: vteamId,
        },
        replace: false,
      },
    });
  }

  removeExistingListAndTileLMV() {
    cy.request({
      method: 'PUT',
      url: '/api/users/dashboard_settings',
      headers: { 'Content-Type': 'application/json' },
      body: {
        dashboardName: 'support',
        settingsKey: 'summary_page_settings',
        settingsSubKey: 'cards',
        settingsValue: {
          '2CkKZacFMS4SdwQkJeQDc': {
            cardType: 'case_list',
            customFields: ['contains_spans'],
            dataFilters: {
              sl_is_closed: false,
              sl_root_sentiment_signal: 'Negative Sentiment',
            },
            id: '2CkKZacFMS4SdwQkJeQDc',
            isDeleted: true,
            isProfile: true,
            key: 'contains_negative',
            label: '{case.plural.capitalize} with **Negative Sentiments**',
            name: 'card 4Edit',
            order: 2,
            type: 'CONTAINS_SENTIMENT_TYPE',
            value: 'Negative Sentiment',
          },
          R9rK3lqM_NW34hGQHWm6W: {
            cardType: 'case_list',
            customFields: ['contains_spans'],
            dataFilters: {
              sl_is_closed: false,
              sl_root_sentiment_signal: 'Negative Sentiment',
            },
            id: 'R9rK3lqM_NW34hGQHWm6W',
            isDeleted: true,
            isProfile: true,
            key: 'contains_negative',
            label: '{case.plural.capitalize} with **Negative Sentiments**',
            name: 'Ticket ListEdit',
            order: 4,
            type: 'CONTAINS_SENTIMENT_TYPE',
            value: 'Negative Sentiment',
          },
          _QDgNMPcCg1f0VSs2KrV8: {
            id: '_QDgNMPcCg1f0VSs2KrV8',
            isDeleted: true,
          },
          k1pe3hVJquYp0PYkHVHhm: {
            id: 'k1pe3hVJquYp0PYkHVHhm',
            isDeleted: true,
          },
        },
        replace: true,
      },
    });
  }

  setToWelcomePageLMV() {
    cy.request({
      method: 'PUT',
      url: '/api/users/dashboard_settings',
      headers: { 'Content-Type': 'application/json' },
      body: {
        dashboardName: 'support',
        settingsKey: 'virtual_teams_user_settings',
        settingsSubKey: null,
        settingsValue: {
          primary_team: null,
        },
        replace: false,
      },
    });
  }

  setToWelcomePageGlobalFilters() {
    cy.request({
      method: 'PUT',
      url: '/api/users/dashboard_settings',
      headers: {
        accept: '*/*',
        'content-type': 'application/json',
      },
      body: JSON.stringify({
        dashboardName: 'support',
        settingsKey: 'filter_ui_settings_v2',
        settingsSubKey: 'scope_filters_onboarding_done',
        settingsValue: false,
        replace: false,
      }),
      // }).then(() => location.reload());
    });
  }

  removeAllFavoriteAgents = () =>
    cy.request({
      method: 'PUT',
      url: 'api/users/dashboard_settings',
      body: {
        dashboardName: 'support',
        settingsKey: 'favorite_agents',
        settingsSubKey: null,
        settingsValue: { AllFavoritesAgentsGroupID: [] },
        replace: true,
      },
    });

  removeAllCustomGlobalAgentGlobalFilters = () =>
    cy.request({
      method: 'PUT',
      url: 'api/users/dashboard_settings/deep/support/filter_ui_settings_v2/quick_filter_agents_disabled',
      body: {
        settingsValue: true,
        replace: true,
      },
    });

  resetFavoriteCustomers = () =>
    cy.request({
      method: 'PUT',
      url: 'api/users/dashboard_settings',
      body: {
        dashboardName: 'support',
        replace: true,
        settingsKey: 'favorite_customers',
        settingsSubKey: null,
        settingsValue: {
          AllFavoritesCustomersGroupID: [],
        },
      },
    });

  removeAllCustomGlobalCustomerFilters = () =>
    cy.request({
      method: 'PUT',
      url: 'api/users/dashboard_settings/deep/support/filter_ui_settings_v2/quick_filter_customers_disabled',
      body: {
        settingsValue: true,
        replace: true,
      },
    });

  removeDynamicFilterConsolePage = () =>
    cy.request({
      method: 'PUT',
      url: 'api/users/dashboard_settings/deep/support/console_page_settings/filtering/selectedDynamicFilters',
      headers: { 'Content-Type': 'application/json' },
      body: {
        replace: true,
        settingsValue: {},
      },
    });

  removeDynamicFilterBacklogPage = () =>
    cy.request({
      method: 'PUT',
      url: 'api/users/dashboard_settings/deep/support/cases_page_settings/filtering/selectedDynamicFilters',
      headers: { 'Content-Type': 'application/json' },
      body: {
        replace: true,
        settingsValue: {},
      },
    });

  removeDynamicFilterAcePage = () =>
    cy.request({
      method: 'PUT',
      url: 'api/users/dashboard_settings/deep/support/ace_page_settings/filtering/selectedDynamicFilters',
      headers: { 'Content-Type': 'application/json' },
      body: {
        replace: true,
        settingsValue: {},
      },
    });

  clearAgentFilterInACEPage() {
    cy.request({
      method: 'PUT',
      url: '/api/users/dashboard_settings',
      headers: { 'Content-Type': 'application/json' },
      body: {
        dashboardName: 'support',
        settingsKey: 'ace_page_settings',
        settingsSubKey: null,
        settingsValue: { agent_filters: {} },
        replace: true,
      },
    });
  }

  // SupportHub Settings
  enablePublicComments() {
    cy.request({
      method: 'POST',
      url: 'api/company/settings/support',
      body: { settings: { public_comments_enabled: true, sl_last_updated: moment().unix() }, replace: false, keys: ['public_comments_enabled'] },
    });
  }

  // SupportHub Settings
  disablePublicComments() {
    cy.request({
      method: 'POST',
      url: 'api/company/settings/support',
      body: { settings: { public_comments_enabled: false, sl_last_updated: moment().unix() }, replace: false, keys: ['public_comments_enabled'] },
    });
  }

  addCustomerToFavorite(customerId, customerType = 'ACCOUNT') {
    cy.request({
      method: 'PUT',
      url: 'api/users/dashboard_settings',
      body: {
        dashboardName: 'support',
        settingsKey: 'favorite_customers',
        settingsSubKey: null,
        settingsValue: { AllFavoritesCustomersGroupID: [{ id: customerId, type: customerType }] },
        replace: true,
      },
    });
  }

  getCasesWithSentiments = () =>
    cy
      .request('api/sentiment-ontology')
      .then(({ body }) => body.data.filter((x) => x.inbound && x.inbound.allow_in_sound_bites).map((x) => x.id))
      .then((allowedSignals) =>
        cy.request({
          method: 'POST',
          url: `api/cache/${targetDatabase}/spans/data`,
          body: {
            filters: {
              'ticket.sl_created_at': [
                new Date(new Date() - 7 * 24 * 60 * 60 * 1000), // last 7 days
                null,
              ],
              'ticket.sl_is_closed': false,
              contains_spans: allowedSignals,
            },
          },
        })
      )
      .then(({ body }) =>
        cy.request({
          method: 'POST',
          url: `api/cache/${targetDatabase}/tickets/v2/byCaseIds`,
          body: {
            slCaseIds: [...new Set(body.map((x) => x.sl_case_id))],
            fieldIds: ['id', 'sl_account_id', 'sl_account_name'],
          },
        })
      )
      .then((res) => res.body);

  closeOnboardingPageCustomerBoard = () =>
    cy.request({
      method: 'PUT',
      url: '/api/users/dashboard_settings',
      headers: { 'Content-Type': 'application/json' },
      body: {
        dashboardName: 'support',
        settingsKey: 'customer_board_page_settings',
        settingsSubKey: 'is_onboarding_done',
        settingsValue: true,
        replace: true,
      },
    });

  removeExistingListCustomerBoard = () =>
    cy.request({
      method: 'PUT',
      url: '/api/users/dashboard_settings',
      headers: { 'Content-Type': 'application/json' },
      body: {
        dashboardName: 'support',
        settingsKey: 'customer_board_page_settings',
        settingsSubKey: 'lists',
        settingsValue: {},
        replace: true,
      },
    });

  resetOnboardingCustomerBoard = () =>
    cy.request({
      method: 'PUT',
      url: '/api/users/dashboard_settings',
      headers: { 'Content-Type': 'application/json' },
      body: {
        dashboardName: 'support',
        settingsKey: 'customer_board_page_settings',
        settingsSubKey: 'is_onboarding_done',
        settingsValue: false,
        replace: true,
      },
    });

  setToStandardListCustomerBoard = () =>
    cy.request({
      method: 'PUT',
      url: '/api/users/dashboard_settings',
      headers: { 'Content-Type': 'application/json' },
      body: {
        dashboardName: 'support',
        settingsKey: 'customer_board_page_settings',
        settingsSubKey: 'lists',
        settingsValue: {
          _aQdksHXcFc_qf0Og_FoA: { type: 'score', value: 'sl_account_health_score', name: 'Customers ranked by Health Score', order: 0 },
          'JgusCJ-pzS1Up_mJj2U48': { type: 'escalation', value: 'escalation', escalationState: 'total', name: 'Customers with Escalations', order: 1 },
          '-NsumVu4HPoqn-4EDL7Y7': { type: 'escalationPrediction', value: 'escalationPrediction', name: 'Customers with likely to escalate cases', order: 2 },
          uzU5Nsm7gfRfpkaqz1rLv: { type: 'signal', value: 'Production Issue', timePeriod: { value: 3, unit: 'months' }, name: 'Customers with production issues', order: 3 },
          'xyR0orfs-3PR5EJQswrVa': { type: 'signal', value: 'Critical Issue', timePeriod: { value: 3, unit: 'months' }, name: 'Customers with critical issues', order: 4 },
          'O_F0xdaRI2uAPWf-JzfWj': { type: 'icon', value: 'caseVolume', timePeriod: { value: 3, unit: 'months' }, name: 'Customers ranked by case volume', order: 5 },
          Me2NgPxTqFdLGDXKcyurq: { type: 'signal', value: 'Escalation Request', timePeriod: { value: 3, unit: 'months' }, name: 'Customers with Escalation requests', order: 6 },
        },
        replace: true,
      },
    });

  getPriorityCaseFieldValues() {
    return cy.request('api/customFields/list?fieldType=case').then(({ body }) => body.values.sl_priority);
  }

  // Returns an array of objects containing the case id and the respective prediction score.
  // The returned array is sorted in descending order based on the prediction score value.
  getPredictionScores() {
    return cy
      .request('api/v2/case/escalation/prediction')
      .then(({ body }) =>
        // eslint-disable-next-line camelcase
        body.map(({ sl_case_id, prediction_score }) => ({
          // eslint-disable-next-line camelcase
          caseId: sl_case_id,
          // eslint-disable-next-line camelcase
          predictionScore: prediction_score,
        }))
      )
      .then((data) => data.sort((a, b) => b.predictionScore - a.predictionScore));
  }

  setTrendsGroupByValue(fieldKey) {
    return cy.request({
      method: 'PUT',
      url: 'api/users/dashboard_settings',
      body: { dashboardName: 'support', settingsKey: 'trends_chart_group_by', settingsSubKey: null, settingsValue: fieldKey, replace: false },
    });
  }

  getAgentMedianMetrics(agentId) {
    return cy
      .request({
        method: 'POST',
        url: `/api/cache/${targetDatabase}}/tickets/metrics`,
        body: { fieldIds: ['sl_comment_count', 'sl_max_follow_up_time_ms', 'sl_open_time_ms'], filters: { sl_assignee_id: [agentId] } },
      })
      .then(({ body }) => body);
  }

  // (minHealthScore, maxHealthScore) => Bad (0-39), Fair (40-69), Good (70-100)
  getCustomerDetailsWithHealthScore(minHealthScore, maxHealthScore) {
    return cy
      .request({
        method: 'POST',
        url: '/api/v2/customer_metric/search?page_number=0&page_size=50&aggregation_label=all',
        headers: { 'content-type': 'application/json' },
        body: {
          record_types: ['individual_account'],
          selected: ['native_id', 'name', 'record_type', 'account_health_score'],
          ordering: [{ column: 'account_health_score', direction: 'asc' }],
          predicates: [
            {
              column: 'record_type',
              op: '=',
              value: 'individual_account',
            },
            { column: 'account_health_score', op: 'not_null' },
            { column: 'account_health_score', op: '>=', value: minHealthScore },
            { column: 'account_health_score', op: '<', value: maxHealthScore },
          ],
        },
      })
      .then(({ body }) => body);
  }

  getIndividualReporterDetails(size = 10) {
    return cy
      .request({
        method: 'POST',
        url: `/api/v2/user/search?page_size=${size}`,
        headers: {
          'content-type': 'application/json',
        },
        body: {
          predicates: [{ column: 'sl_user_is_valid_assignee', op: '=', value: false }],
          selected: ['id', 's_id', 'sl_name', 'sl_email', 'sl_user_is_valid_assignee'],
          ordering: [],
        },
      })
      .then(({ body }) => body);
  }

  clearRecentlyVisitedAgentInsight() {
    return cy.request({
      method: 'PUT',
      url: '/api/users/dashboard_settings',
      body: {
        dashboardName: 'support',
        settingsKey: 'visited_agents',
        settingsSubKey: null,
        settingsValue: [],
        replace: false,
      },
    });
  }

  clearRecentlyVisitedCustomerInsight() {
    return cy.request({
      method: 'PUT',
      url: '/api/users/dashboard_settings',
      body: {
        dashboardName: 'support',
        settingsKey: 'visited_customers',
        settingsSubKey: null,
        settingsValue: [],
        replace: false,
      },
    });
  }

  sortReviewedColumnByTimeInACEPage() {
    cy.request({
      method: 'PUT',
      url: '/api/users/dashboard_settings',
      headers: { 'Content-Type': 'application/json' },
      body: {
        dashboardName: 'support',
        settingsKey: 'ace_page_settings',
        settingsSubKey: null,
        settingsValue: { published_review_group_by: 'time' },
        replace: true,
      },
    });
  }

  sortCustomerScoreByAllTimeInMyCustomersPage() {
    cy.request({
      method: 'PUT',
      url: '/api/users/dashboard_settings',
      headers: { 'Content-Type': 'application/json' },
      body: {
        dashboardName: 'support',
        settingsKey: 'fav_customers_page_settings',
        settingsSubKey: null,
        settingsValue: {
          time_periods: {
            customerScore: {
              value: null,
              unit: 'days',
            },
          },
        },
        replace: false,
      },
    });
  }

  sortAttentionScoreBy180DaysInMyCustomersPage() {
    cy.request({
      method: 'PUT',
      url: '/api/users/dashboard_settings',
      headers: { 'Content-Type': 'application/json' },
      body: {
        dashboardName: 'support',
        settingsKey: 'fav_customers_page_settings',
        settingsSubKey: null,
        settingsValue: {
          time_periods: {
            attentionScore: {
              value: 180,
              unit: 'days',
            },
          },
        },
        replace: false,
      },
    });
  }

  sortSentimentScoreBy180DaysInMyCustomersPage() {
    cy.request({
      method: 'PUT',
      url: '/api/users/dashboard_settings',
      headers: { 'Content-Type': 'application/json' },
      body: {
        dashboardName: 'support',
        settingsKey: 'fav_customers_page_settings',
        settingsSubKey: null,
        settingsValue: {
          time_periods: {
            sentimentScore: {
              value: 180,
              unit: 'days',
            },
          },
        },
        replace: false,
      },
    });
  }

  sortNewCasesBy30DaysInMyCustomersPage() {
    cy.request({
      method: 'PUT',
      url: '/api/users/dashboard_settings',
      headers: { 'Content-Type': 'application/json' },
      body: {
        dashboardName: 'support',
        settingsKey: 'fav_customers_page_settings',
        settingsSubKey: null,
        settingsValue: {
          time_periods: {
            newCases: {
              value: 30,
              unit: 'days',
            },
          },
        },
        replace: false,
      },
    });
  }

  groupByAllCommentsInsideSupportHubInACEPage() {
    cy.request({
      method: 'PUT',
      url: '/api/users/dashboard_settings',
      headers: { 'Content-Type': 'application/json' },
      body: {
        dashboardName: 'support',
        settingsKey: 'support_hub_settings',
        settingsSubKey: null,
        settingsValue: { displayed_comments: 'all_comments' },
        replace: false,
      },
    });
  }

  enableEscalationReviewActions(actionType) {
    let actionTypes = actionType;
    if (typeof actionType === 'string') {
      actionTypes = actionType.split();
    }
    return editEscalationReviewActions(actionTypes, true);
  }

  disableEscalationReviewActions(actionType) {
    let actionTypes = actionType;
    if (typeof actionType === 'string') {
      actionTypes = actionType.split();
    }
    return editEscalationReviewActions(actionTypes, false);
  }

  showLikelyToEscalateQueue(value = true) {
    cy.request({
      method: 'POST',
      url: 'api/company/settings/support',
      body: {
        settings: { escalations_page_settings: { escalations_predictions_enabled: value }, sl_last_updated: Date.now() },
        replace: false,
        keys: ['escalations_page_settings', 'escalations_predictions_enabled'],
      },
    });
  }
}

export const apiHelpers = new ApiHelpers();
