class CommonElements {
  appWrapper() {
    return cy.get('#app_wrapper');
  }

  lockIcon() {
    return cy.get('[data-icon=lock]');
  }

  contactAdminMessage() {
    return cy.contains('Contact admin@supportlogic.io to unlock this feature!');
  }

  settingsDashboardEditorContainer() {
    return cy.getByTestId('dashboardEditorContent-container');
  }

  savedIndicatorLabel() {
    return cy.getByTestId('companySettings__savedIndicator');
  }

  zeroStateContainer() {
    return cy.getByTestId('common-zeroStateContainer');
  }

  welcomePageGetStartedButton() {
    return cy.getByTestId('module-common-welcome-page-button');
  }

  // This function click Get Started button to clear the Welcome page (excludes Backlog and Customer Board Section)
  clickWelcomePageGetStartedButton() {
    this.appWrapper().then(($parentDiv) => {
      if ($parentDiv.find('[data-testid="module-common-welcome-page-button"]').length > 0) {
        this.welcomePageGetStartedButton().click();
        cy.waitForLoaders();
      }
    });
  }
}

export const commonElements = new CommonElements();
