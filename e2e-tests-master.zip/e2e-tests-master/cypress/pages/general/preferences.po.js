export class Preferences {
  userMenuButton() {
    return cy.getByTestId('layout-header-userMenu');
  }

  userMenuPreferenceButton() {
    return cy.getByTestId('layout-header-userMenu-preferences');
  }

  preferenceFavoriteCustomersTab() {
    return cy.getByTestId('settingsModal__tabs__item__favoriteCustomers');
  }

  preferenceFavoriteAgentsTab() {
    return cy.getByTestId('settingsModal__tabs__item__favoriteAgents');
  }

  preferenceFavoriteAgentsTitle() {
    return cy.getByTestId('settingsModal__title');
  }

  favoriteCustomerSearchInput() {
    return cy.getByTestId('virtEntityTypeahed-input');
  }

  favoriteCustomerSearchResultList() {
    return cy.getByTestId('global-searchBar-searchOption-item__label');
  }

  removeFavoriteCustomersIcon() {
    return cy.getByTestId('settingsModal__favCustomers__removeButton');
  }

  preferencePopupCloseButton() {
    return cy.getByTestId('settingsModal__closeButton');
  }

  // Search Result Filter Tab
  searchResultFilterButton() {
    return cy.getByTestId('virtEntityTypeahed-filters__button');
  }

  customerSearchIndividualAccountCheckBox() {
    return cy.getByTestId('animated-checkbox-default-group-Individual Account-id');
  }

  customerSearchVirtualAccountCheckBox() {
    return cy.getByTestId('animated-checkbox-default-group-Virtual Account-id');
  }

  customerSearchVirtualGroupCheckBox() {
    return cy.getByTestId('animated-checkbox-default-group-Virtual Group-id');
  }

  customerSearchIndividualReporterCheckBox() {
    return cy.getByTestId('animated-checkbox-default-group-Individual Reporter-id');
  }

  searchFilterNameLabel() {
    return cy.getByTestId('virtEntityTypeahed-filters__item');
  }

  selectFavoriteCustomerInPreference(custName) {
    this.userMenuButton().click();
    this.userMenuPreferenceButton().click();
    this.preferenceFavoriteCustomersTab().click();
    this.favoriteCustomerSearchInput().type(custName);
    this.selectAllFilterItemsInFavCustomer();
    this.favoriteCustomerSearchResultList()
      .eq(0)
      .then(($custName1) => {
        const custName1 = $custName1.text();
        this.favoriteCustomerSearchResultList().eq(0).click();
        expect(custName1).contains(custName);
        this.preferencePopupCloseButton().click();
      });
  }

  removeRecentlyFavoriteCustomersInPreference() {
    this.userMenuButton().scrollIntoView().click();
    this.userMenuPreferenceButton().click();
    this.preferenceFavoriteCustomersTab().click();
    this.removeFavoriteCustomersIcon().eq(0).click();
    this.preferencePopupCloseButton().click();
  }

  selectAllFilterItemsInFavCustomer() {
    this.searchResultFilterButton().click();
    this.customerSearchIndividualAccountCheckBox()
      .invoke('attr', 'data-status')
      .then(($statusValue) => {
        if ($statusValue === 'unchecked') {
          this.searchFilterNameLabel().contains('Individual Account').click();
          this.customerSearchIndividualAccountCheckBox().invoke('attr', 'data-status').should('include', 'checked');
        }
      });
    this.customerSearchVirtualAccountCheckBox()
      .invoke('attr', 'data-status')
      .then(($statusValue) => {
        if ($statusValue === 'unchecked') {
          this.searchFilterNameLabel().contains('Virtual Account').click();
          this.customerSearchVirtualAccountCheckBox().invoke('attr', 'data-status').should('include', 'checked');
        }
      });
    this.customerSearchVirtualGroupCheckBox()
      .invoke('attr', 'data-status')
      .then(($statusValue) => {
        if ($statusValue === 'unchecked') {
          this.searchFilterNameLabel().contains('Virtual Group').click();
          this.customerSearchVirtualGroupCheckBox().invoke('attr', 'data-status').should('include', 'checked');
        }
      });
    this.customerSearchIndividualReporterCheckBox()
      .invoke('attr', 'data-status')
      .then(($statusValue) => {
        if ($statusValue === 'unchecked') {
          this.searchFilterNameLabel().contains('Individual Reporter').click();
          this.customerSearchIndividualReporterCheckBox().invoke('attr', 'data-status').should('include', 'checked');
        }
      });
  }

  // TODO waiting for the data-testid for below locator SLC-30804
  dataSyncStatus() {
    return cy.get('._2VRzQnP1PS_BoI98kzuOyR .DataSyncCircle__Container-sc-17mm7fb-0');
  }
}

export const preferences = new Preferences();
