import { urlHelpers } from '../../utils';

export class GlobalFilterPageObject {
  // Global Filter
  filterButton() {
    return cy.getByTestId('layout-header-filter-toggle');
  }

  createANewFilterButton() {
    return cy.getByTestId('filters-scoreFilters-createNewFilter');
  }

  // TODO- SLC-33502 for data-testid request
  createANewFilterButtonFromPopupScreen() {
    return cy.getByTestId('scopeFilters__newButton');
  }

  globalFilterWelcomeScreenLetsGetStartedButton() {
    return cy.getByTestId('filters-welcomePage-startButton-lets_get_started');
  }

  // TODO - SLC-33502 for data-testid request
  globalFilterHeaderText() {
    return cy.get('[class^="styles__Title-sc-h"]');
  }

  globalFiltersManageLink() {
    return cy.getByTestId('layout-header-filter-manageGlobalBtn');
  }

  // TODO - SLC-33502 for data-testid request
  globalFiltersSelectedValuesWillAppearHereText() {
    return cy.get('[class^="styles__ZeroStateBlock-sc"]');
  }

  // TODO - SLC-33502 for data-testid request
  globalFilterName() {
    return cy.get('[class^="styles__LabelWrapper-sc"]');
  }

  // TODO - SLC-33502 for data-testid request
  globalFilterCancelButton() {
    return cy.getByTestId('scopeFilters__dialog__cancelButton');
  }

  globalFilterCaseFieldsButton() {
    return cy.getByTestId('globall-filter-tab-Case Fields');
  }

  globalFilterCustomerFieldsButton() {
    return cy.getByTestId('globall-filter-tab-Customers');
  }

  // Removed 'globalFilterCaseFieldsList' due to each header DialogBox have seperate data-testid
  caseFieldsAgeHeaderDialogBox() {
    return cy.getByTestId('scopeFilters__dialog__field__sl_ticket_open_time__title');
  }

  caseFieldsInactivityHeaderDialogBox() {
    return cy.getByTestId('scopeFilters__dialog__field__sl_ticket_inactivity__title');
  }

  // TODO - SLC-33672 for data-testid request
  customerFieldsSearchFieldInput() {
    return cy.get('[class^="styles__Input-sc-"]');
  }

  globalFilterCaseFieldSelectedValueButton() {
    return cy.getByTestId('common-pill-label');
  }

  globalFilterSelectedValueCountLabel() {
    return cy.getByTestId('scopeFilters__dialog__selectedCount');
  }

  globalFilterSelectedValuesResetButton() {
    return cy.contains('Reset');
  }

  globalFilterCreateButton() {
    return cy.getByTestId('scopeFilters__dialog__submitButton');
  }

  // TODO - SLC-33502 for data-testid request
  globalFilterApplyButton() {
    return cy.get('[data-testid$="__applyButton"]');
  }

  globalFilterDeleteButtonMouseoverText() {
    return cy.contains('Delete global filter');
  }

  // TODO - SLC-33672 for data-testid request
  globalFilterDeleteButton() {
    return cy.get('[class^="styles__RemoveIcon-sc"]');
  }

  globalFilterAreYouSurePopupDeletePopup() {
    return cy.contains('[data-testid^=common-button]', 'Delete');
  }

  globalFilterListPopupCloseButton() {
    return cy.getByTestId('common__modal__closeButton');
  }

  // TODO - SLC-33502 for data-testid request
  globalFilterCreatedNameText() {
    return cy.get('[class^="styles__Label-sc-"]');
  }

  quickFilterDropdown() {
    return cy.getByTestId('filters-scoreFilters-quickFilterBtn');
  }

  quickFilterAgentLink() {
    return cy.getByTestId('filters-scoreFilters-agents');
  }

  quickFilterCaseFieldsLink() {
    return cy.getByTestId('filters-scoreFilters-caseFields');
  }

  quickFilterSearchFieldInput() {
    return cy.getByTestId('filters-scoreFilters-searchOptionFilter-searchInput');
  }

  quickFilterSearchResultList() {
    return cy.getByTestId('filters-scoreFilters-searchResult-optionItem');
  }

  quickFilterAgentClearAllLink() {
    return cy.getByTestId('global-filter--selected--sl_assignee_id--clear');
  }

  quickFilterCustomerLink() {
    return cy.getByTestId('filters-scoreFilters-customers');
  }

  quickFilterContainer() {
    return cy.getByTestId('filters-scoreFilters-searchOptionFilter-wrapper');
  }

  quickFilterFavoritesListItem() {
    return cy.getByTestId('filters-scopeFilters-searchResult-favoriteItem');
  }

  quickFilterAgentFavoritesLink() {
    return cy.getByTestId('global-filter--searchBox--favoritesContainer--sl_assignee_id');
  }

  quickFilterCustomerFavoritesLink() {
    return cy.getByTestId('global-filter--searchBox--favoritesContainer--sl_account_id');
  }

  // TODO data-testid requested via SLC-33700
  quickFilterCaseFieldsAgeButton() {
    return cy.get('._2QnZ5wCmDxQpaybuRO9Ho2');
  }

  // TODO data-testid requested via SLC-33700
  quickFilterCaseFieldsAgeLT30DaysButton() {
    return this.globalFilterCaseFieldSelectedValueButton().contains('< 30 Days');
  }

  // TODO data-testid requested via SLC-33700
  quickFilterCaseFieldsAgeL30To60DaysButton() {
    return this.globalFilterCaseFieldSelectedValueButton().contains('30-60 Days');
  }

  quickFilterSelectedValuesResetButton() {
    return cy.contains('Reset');
  }

  quickFilterCaseFieldsNumberSelectedButton() {
    return cy.getByTestId('global-filter--selected--caseFields');
  }

  filterApplyButton() {
    return cy.getByTestId('filters-scoreFilters-searchOptionFilter-applyFilterBtn');
  }

  filterAgentsHeadingText() {
    return cy.getByTestId('ace-evaluations-filters-agent-label');
  }

  quickFilterCaseFieldApplyButton() {
    return cy.getByTestId('filters-caseField-scoreFilters-Apply_scope-btn');
  }

  quickFiltersPriorityExpandButton() {
    return cy.getByTestId('scopeFilters__dialog__field__sl_priority__collapseButton');
  }

  // TODO data-testid requested via SLC-33700
  quickFilterSearchResultFirst() {
    return cy.get('._3wRfdoCeYuFb7PRAcBEJ1');
  }

  quickFilterCustomerSelectedButton() {
    return cy.getByTestId('global-filter--selected--sl_account_id');
  }

  quickFilterCustomerClearAllLink() {
    return cy.getByTestId('global-filter--selected--sl_account_id--clear');
  }

  commonPriorityCaseFieldOptions(optionName) {
    return cy.getByTestId(`scopeFilters__dialog__field__sl_priority__${optionName}`);
  }

  clickFilterToExpand() {
    this.filterButton()
      .should('be.visible')
      .invoke('attr', 'data-status')
      .then(($statusValue) => {
        if ($statusValue === 'collapsed') {
          this.filterButton().click().invoke('attr', 'data-status').should('include', 'expanded');
        }
      });
  }

  clickQuickFilterToExpand() {
    this.quickFilterDropdown()
      .should('be.visible')
      .invoke('attr', 'data-status')
      .then(($statusValue) => {
        if ($statusValue === 'collapsed') {
          this.quickFilterDropdown().click().invoke('attr', 'data-status').should('include', 'expanded');
        }
      });
  }

  selectAgentInQuickFilter(vaTeam) {
    this.clickFilterToExpand();
    this.clickQuickFilterToExpand();
    this.quickFilterAgentLink().click();
    this.quickFilterSearchFieldInput().type(vaTeam);
    cy.waitForLoaders();
    this.quickFilterSearchResultList().first().find('input[type=checkbox]').click({ force: true });
    this.filterApplyButton().should('be.visible').click();
    this.filterButton().click();
  }

  clearAllAgentSelectedInQuickFilter() {
    this.filterButton().then((button) => {
      if (button.text() === 'Custom') {
        this.clickFilterToExpand();
        this.clickQuickFilterToExpand();
        this.quickFilterAgentLink().click();
        this.quickFilterAgentClearAllLink().click();
        this.filterApplyButton().should('be.visible').click();
        this.filterButton().click();
      }
    });
  }

  // add quick filter for 1st favorite customer in Favorites list
  addFavoriteCustomerQuickFilter() {
    this.clickFilterToExpand();
    this.clickQuickFilterToExpand();
    // go to globalFilters for Customers
    this.quickFilterCustomerLink().should('be.visible').click();
    // Click on a Favorites link
    this.quickFilterCustomerFavoritesLink().click();
    // click on checkbox for the customer
    this.quickFilterFavoritesListItem().should('be.visible').click();
    // apply filter button
    this.filterApplyButton().should('be.visible').click();
    // Filter button now changed to custom
    this.filterButton().should('be.visible').contains('Custom');
  }

  // add quick filter for 1st favorite agent in Favorites list
  addFavoriteAgentQuickFilter() {
    this.clickFilterToExpand();
    this.clickQuickFilterToExpand();
    // go to globalFilters for Agents
    this.quickFilterAgentLink().should('be.visible').click();
    // Click on Favorites link
    this.quickFilterAgentFavoritesLink().click();
    // click on checkbox for the agent
    this.quickFilterFavoritesListItem().should('be.visible').click();
    // apply filter button
    this.filterApplyButton().should('be.visible').click();
    // Filter button now changed to custom
    this.filterButton().should('be.visible').contains('Custom');
  }

  // add global filter for Cases with Age less than 30 days
  addGlobalFilterCaseAgeLT30Days() {
    cy.visit(urlHelpers.console.home);
    this.filterButton().should('be.visible').click().invoke('attr', 'data-status').should('include', 'expanded');
    this.clickFilterToExpand();
    this.createANewFilterButton().click();
    this.selectAgeLT30DaysInGlobalFilter();
    this.globalFilterCreateButton().should('be.visible').click();
    this.globalFilterApplyButton().click();
    this.globalFilterListPopupCloseButton().click();
  }

  // go to page to choose Global Filter items
  goToGlobalFilterCreationPage() {
    this.filterButton().should('be.visible').click().invoke('attr', 'data-status').should('include', 'expanded');
    this.clickFilterToExpand();
    this.createANewFilterButton().click();
  }

  // on Global Filters page to choose filter values, choose to add for Age is less than 30 days
  selectAgeLT30DaysInGlobalFilter() {
    this.globalFilterCaseFieldsButton().click();
    this.caseFieldsAgeHeaderDialogBox().should('be.visible').eq(0).click();
    this.globalFilterCaseFieldSelectedValueButton().contains('< 30 Days').click();
  }

  filterByCustomers(customerNames) {
    cy.intercept('PUT', 'api/users/dashboard_settings/deep/support/filter_ui_settings_v2/quick_filter_customers').as('applyCustomerQuickFilter');

    // eslint-disable-next-line no-param-reassign
    if (!Array.isArray(customerNames)) customerNames = [customerNames];
    this.clickFilterToExpand();
    this.clickQuickFilterToExpand();

    this.quickFilterCustomerLink().click();
    customerNames.forEach((customerName) => {
      this.quickFilterSearchFieldInput().type(customerName);
      this.quickFilterSearchResultList().first().click();
    });

    this.filterApplyButton().click();
    cy.wait('@applyCustomerQuickFilter');
  }

  filterByCustomerGlobalFilter(customerName) {
    this.goToGlobalFilterCreationPage();
    this.globalFilterCustomerFieldsButton().click();
    this.customerFieldsSearchFieldInput().should('be.visible').type(customerName);
    cy.waitForLoaders();
    this.globalFilterAgentCaseFieldCheckboxes().eq(0).click({ force: true });
    this.globalFilterCreateButton().click();
    this.globalFilterApplyButton().click();
    this.globalFilterListPopupCloseButton().click();
  }

  selectCustomerInQuickFilter(customerName) {
    cy.intercept('PUT', 'api/users/dashboard_settings/deep/support/filter_ui_settings_v2/quick_filter_customers').as('applyCustomerQuickFilter');
    this.clickFilterToExpand();
    this.clickQuickFilterToExpand();
    this.quickFilterCustomerLink().click();
    this.quickFilterSearchFieldInput().type(customerName);
    this.quickFilterSearchResultFirst().eq(0).click({ force: true });
    this.filterApplyButton().click({ force: true });
    cy.wait('@applyCustomerQuickFilter');
  }

  filterByPriorityCaseField(priorities) {
    cy.intercept('PUT', 'api/users/dashboard_settings/deep/support/filter_ui_settings_v2/quick_filter_case_fields').as('applyPriorityCaseFieldQuickFilter');

    // eslint-disable-next-line no-param-reassign
    if (!Array.isArray(priorities)) priorities = [priorities];
    this.clickFilterToExpand();
    this.clickQuickFilterToExpand();

    this.quickFilterCaseFieldsLink().click();
    this.quickFiltersPriorityExpandButton().click();
    priorities.forEach((priority) => this.commonPriorityCaseFieldOptions(priority).click());

    this.quickFilterCaseFieldApplyButton().click();
    cy.wait('@applyPriorityCaseFieldQuickFilter');
  }

  globalFilterPopup() {
    return cy.getByTestId('common-modal-message');
  }

  commonGlobalFilterTabs(tabName) {
    if (tabName) {
      return cy.getByTestId(`globall-filter-tab-${tabName}`);
    }
    return cy.get('[data-testid^=globall-filter-tab]');
  }

  // TODO - SLC-33502 for data-testid request
  globalFilterAgentCaseFields() {
    return cy.get('[class^=styles__ContentContainer]');
  }

  // TODO - SLC-33502 for data-testid request
  globalFilterAgentSearchTextField() {
    return cy.get('[placeholder^=Search]');
  }

  globalFilterAgentCaseFieldCheckboxes() {
    return cy.get('[data-testid^="item-list_label_"]');
  }

  // TODO - SLC-33502 for data-testid request
  globalFilterCloseButton() {
    return cy.get("[data-icon='cross']");
  }

  acceptWelcomePagePopup(filterPopup) {
    const filtersOnboardingPageStartButton = '[data-testid=filters-welcomePage-startButton-lets_get_started]';
    if (filterPopup.find(filtersOnboardingPageStartButton).length) {
      // cy.get(filtersOnboardingPage).should('be.visible')
      cy.get(filtersOnboardingPageStartButton).click();
    }
  }
}

export const globalFilters = new GlobalFilterPageObject();
