class PluginErrorPopup {
  baseContainer() {
    return cy.getByTestId('common-salesforce-connection-popup');
  }

  maybeLaterButton() {
    return cy.getByTestId('common-salesforce-connection-popup__maybeLater-btn');
  }

  signInLink() {
    return cy.getByTestId('common-salesforce-connection-popup__signIn-btn');
  }
}

export const pluginErrorPopup = new PluginErrorPopup();
