export class Filters {
  allCaseStatusFilterButton() {
    return cy.getByTestId('case-status--option--all');
  }

  openCaseStatusFilterButton() {
    return cy.getByTestId('case-status--option--open');
  }

  closedCaseStatusFilterButton() {
    return cy.getByTestId('case-status--option--closed');
  }

  addDynamicFilterButton() {
    return cy.getByTestId('filters-dynamicFilters-addAFilter');
  }

  dynamicFilterHeader() {
    return cy.getByTestId('dynamicFilter--content-header');
  }

  // TODO - data-testid request SLC-35410
  dynamicFilterPriorityPopupHeader() {
    return cy.get('.thu95u1LWIWRMpXnZIqXO');
  }

  dynamicFilterPriorityPopupSelectedRemoveButton() {
    return cy.getByTestId('global-filter--selected--sl_priority--clear');
  }

  dynamicFilterStatusCheckbox() {
    return cy.getByTestId('dynamicFilter--sl_status--label');
  }

  dynamicFilterSaveButton() {
    return cy.getByTestId('dynamicFilter--add-or-save');
  }

  dynamicFilterDropdown() {
    return cy.getByTestId('common-popupFilter-btn');
  }

  dynamicFilterApplyButton() {
    return cy.getByTestId('dynamicFilter--apply');
  }

  dynamicFilterSelectedRemoveButton() {
    return cy.getByTestId('dynamicFilter--unselect-all-fields-clear');
  }

  dynamicFilterDropdownOptions() {
    return cy.get('[data-testid^=item-list_checkbox_]');
  }

  // TODO - data-testid request SLC-35280
  dynamicFilterDropdownListFirstItem() {
    return cy.get('.ReactVirtualized__Grid__innerScrollContainer').eq(1).find('._394LIe4fu4bC0T-vIzKq-0').eq(0);
  }

  dynamicFilterDropdownCancelButton() {
    return cy.getByTestId('dynamicFilter--cancel');
  }

  dynamicFilterDropdownApplyButton() {
    return cy.getByTestId('dynamicFilter--apply');
  }

  // TODO - data-testid request SLC-35410
  dynamicFilterWelcomePopupVisibilityCheck() {
    cy.get('body').then((body) => {
      if (body.find('[class^="styles__Popup-sc-"]').length) {
        cy.get('[class^="styles__Button-sc-"]').contains('Add a dynamic filter').should('be.visible').click();
      }
    });
  }

  getStartedButtonSentimentsModule() {
    cy.get('body').then(($body) => {
      if ($body.find('button[data-testid=module-common-welcome-page-button]').length) {
        cy.getByTestId('module-common-welcome-page-button').then(($btn) => {
          if ($btn.is(':enabled')) {
            cy.wrap($btn).click();
          }
        });
      }
    });
  }

  /* Elements for Customer and Agents Filters - Dynamic */
  customerFilterButtonDynamic() {
    return cy.getByTestId('operationalMetrics-dynamic-filter-customers-count-block');
  }

  customerFilterButtonDynamicTitle() {
    return cy.getByTestId('filters-scoreFilters-searchOptionFilter-title');
  }

  customerFilterButtonselectedbtn() {
    return cy.getByTestId('filters-scoreFilters-searchOptionFilter-selectedOption');
  }

  // TODO data-testid request SLC-35410
  customerFilterEmptyStateMessageText() {
    return cy.get('[class^=ZeroState__Label-sc-]');
  }

  agentsFilterButtonDynamic() {
    return cy.getByTestId('operationalMetrics-dynamic-filter-agents-count-block');
  }
}

export const filters = new Filters();
