import moment from 'moment';

class DatePicker {
  datePickerTrigger() {
    return cy.get('[data-testid=globalDateRangePicker-trigger] > button');
  }

  datePickerPopover() {
    return cy.get('[class^=DateRangePicker__Popover]');
  }

  cancelButton() {
    return cy.getByTestId('globalDateRangePicker-CancelButton');
  }

  applyButton() {
    return cy.getByTestId('globalDateRangePicker-ApplyButton');
  }

  commonShortcutsRadioButton() {
    return cy.get('[data-testid^=globalDateRangePicker-Shortcut]');
  }

  rightNowRadioButton() {
    return cy.getByTestId('globalDateRangePicker-Shortcut-all_time');
  }

  lastWeekRadioButton() {
    return cy.getByTestId('globalDateRangePicker-Shortcut-past_week');
  }

  thisWeekRadioButton() {
    return cy.getByTestId('globalDateRangePicker-Shortcut-current_week');
  }

  thisMonthRadioButton() {
    return cy.getByTestId('globalDateRangePicker-Shortcut-this_month');
  }

  yearToDateRadioButton() {
    return cy.getByTestId('globalDateRangePicker-Shortcut-year_to_date');
  }

  quarterRadioButton() {
    return cy.getByTestId('globalDateRangePicker-Shortcut-quarter');
  }

  lastMonthRadioButton() {
    return cy.getByTestId('globalDateRangePicker-Shortcut-last_month');
  }

  lastMonthDropdown() {
    return cy.getByTestId('globalDateRangePicker-Dropdown-last-month');
  }

  lastMonthDropdownOption(optionName) {
    return cy.contains('[data-testid^=globalDateRangePicker-last-monthOption]', RegExp(optionName, 'i'));
  }

  previousMonthButton() {
    return cy.getByTestId('globalDateRangePicker-NavButtonPrev');
  }

  nextMonthButton() {
    return cy.getByTestId('globalDateRangePicker-NavButtonNext');
  }

  visibleMonthDropdown() {
    return cy.get('.CalendarMonth[data-visible=true] [data-testid=globalDateRangePicker-MonthDropdown-trigger]');
  }

  monthDropdownOptions(monthName) {
    return cy.getByTestId(`globalDateRangePicker-MonthDropdown-${monthName}`);
  }

  visibleYearTextField() {
    return cy.get('.CalendarMonth[data-visible=true] [data-testid=globalDateRangePicker-yearInput]');
  }

  calendarDay() {
    return cy.get('div.CalendarMonth[data-visible=true] td.CalendarDay');
  }

  calendarDayButton(dateText) {
    return cy.get(`[data-visible=true] [aria-label*='${dateText}']`);
  }

  fromDateTextField() {
    return cy.getByTestId('globalDateRangePicker-FromDateInput');
  }

  toDateTextField() {
    return cy.getByTestId('globalDateRangePicker-ToDateInput');
  }

  nextWeekRadioButton() {
    return cy.getByTestId('globalDateRangePicker-Shortcut-next_week');
  }

  inputErrorMessageLabel() {
    return cy.getByTestId('globalDateRangePicker-emptyField-errorMessage');
  }

  selectLastMonthWithOptionWithoutApply(optionName) {
    this.lastMonthDropdown().then((radioButton) => {
      cy.wrap(radioButton).click();

      if (radioButton.textContent === '3') this.lastMonthDropdownOption(optionName).click();
    });
  }

  selectAndApplyThisMonthRadioButton() {
    this.datePickerTrigger().click();
    this.thisMonthRadioButton().click();
    this.applyButton().click();
    this.datePickerTrigger().should('have.text', 'This month');
  }

  selectAndApplyLast3MonthsRadioButton() {
    this.datePickerTrigger().click();
    this.selectLastMonthWithOption(3);
    this.datePickerTrigger().should('have.text', 'Last 3 months');
  }

  scrollThroughCalendar() {
    // the datepicker has 2 sections, left side -> FROM date & right side -> TO date
    // since testid is the same for both we're using the index values
    const calendarSections = { from: 0, to: 1 };

    Object.values(calendarSections).forEach((sectionIndex) => {
      this.visibleMonthDropdown()
        .eq(sectionIndex)
        .invoke('text')
        .then((currentSelectedMonth) => {
          // previous month
          this.previousMonthButton().eq(sectionIndex).click();
          // eslint-disable-next-line cypress/no-unnecessary-waiting
          cy.wait(1000);
          this.visibleMonthDropdown().eq(sectionIndex).should('contain.text', moment(currentSelectedMonth, 'MMM').subtract(1, 'months').format('MMM'));
          // next month
          this.nextMonthButton().eq(sectionIndex).click();
          // eslint-disable-next-line cypress/no-unnecessary-waiting
          cy.wait(1000);
          this.visibleMonthDropdown().eq(sectionIndex).should('contain.text', currentSelectedMonth);
        });
    });
  }

  selectLastMonthWithOption(optionName) {
    this.lastMonthDropdown().then((radioButton) => {
      cy.wrap(radioButton).click();

      if (radioButton.textContent === '3') this.lastMonthDropdownOption(optionName).click();
    });

    this.applyButton().click();
  }

  setToYearToDateOption() {
    this.datePickerTrigger()
      .invoke('text')
      .then((currentValue) => {
        if (currentValue !== 'Year to date') {
          this.datePickerTrigger().click();
          this.yearToDateRadioButton().click();
          this.applyButton().click();
        }
      });
  }
}

export const datePicker = new DatePicker();
