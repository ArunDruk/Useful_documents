class SettingsSidebar {
  escalationsSection() {
    return cy.getByTestId('settings-sidebar-escalations-item');
  }
}

export const settingsSidebar = new SettingsSidebar();
