class EscalationSettings {
  showLteToggleButton() {
    return cy.contains('Show the Likely to Escalate queue').siblings();
  }
}

export const escalationSettings = new EscalationSettings();
