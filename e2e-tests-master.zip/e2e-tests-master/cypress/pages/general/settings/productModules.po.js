class ProductModules {
  assignmentBoardDropdown() {
    // NOTE: using index since testid is the same for the section dropdown
    return cy.getByTestId('product-edition-caseAssignment').eq(1);
  }

  assignmentBoardDropdownEnableOption() {
    return cy.getByTestId('product-edition-caseAssignment-enabled');
  }

  assignmentBoardDropdownDisableOption() {
    return cy.getByTestId('product-edition-caseAssignment-disabled').eq(1);
  }
}

export const productModules = new ProductModules();
