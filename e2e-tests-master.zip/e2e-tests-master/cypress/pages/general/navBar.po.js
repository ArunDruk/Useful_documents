class NavBar {
  navbarCollapseExpandButton() {
    return cy.getByTestId('layout-navigation-toggle');
  }

  baseContainer() {
    // NOTE: This does not need a separate testid
    return cy.getByTestId('menu-container').parent();
  }

  commonNavbarModuleItem() {
    return cy.get('[data-testid^=layout-navigation-module-item] > a');
  }

  // Section: Workspace
  myDashboard() {
    return cy.getByTestId('layout-navigation-module-item--summary');
  }

  console() {
    return cy.getByTestId('layout-navigation-module-item--console');
  }

  myAlerts() {
    return cy.getByTestId('layout-navigation-module-item--alerts');
  }

  myAgents() {
    return cy.getByTestId('layout-navigation-module-item--myAgents');
  }

  myCustomers() {
    return cy.getByTestId('layout-navigation-module-item--myCustomers');
  }

  backlog() {
    return cy.getByTestId('layout-navigation-module-item--cases');
  }

  // Section: Escalations Management
  escalationsBoard() {
    return cy.getByTestId('layout-navigation-module-item--escalationsBoard');
  }

  escalationsReport() {
    return cy.getByTestId('layout-navigation-module-item--escalationsReport');
  }

  // Section: Case Assignment
  assignmentBoard() {
    return cy.getByTestId('layout-navigation-module-item--caseAssignment');
  }

  shiftManagement() {
    return cy.getByTestId('layout-navigation-module-item--shiftManagement');
  }

  assignmentQueues() {
    return cy.getByTestId('layout-navigation-module-item--virtualQueues');
  }

  // Section: Quality Monitoring
  elevateSX() {
    return cy.getByTestId('layout-navigation-module-item--elevatePlusExternal');
  }

  agentCoaching() {
    return cy.getByTestId('layout-navigation-module-item--manualQA');
  }

  qaScorecards() {
    return cy.getByTestId('layout-navigation-module-item--qaScorecards');
  }

  // Section: Agent Management
  agentInsights() {
    return cy.getByTestId('layout-navigation-module-item--agents');
  }

  virtualTeams() {
    return cy.getByTestId('layout-navigation-module-item--virtualTeams');
  }

  // Section: Customer Management
  // Currently, Top Customers in application
  customerBoard() {
    return cy.getByTestId('layout-navigation-module-item--customerBoard');
  }

  customerInsights() {
    return cy.getByTestId('layout-navigation-module-item--customerInsights');
  }

  virtualAccounts() {
    return cy.getByTestId('layout-navigation-module-item--virtualAccounts');
  }

  // Section: Analytics
  operationalMetrics() {
    return cy.getByTestId('layout-navigation-module-item--operationalMetrics');
  }

  experientialMetrics() {
    return cy.getByTestId('layout-navigation-module-item--experientialMetrics');
  }

  kpiMetrics() {
    return cy.getByTestId('layout-navigation-module-item--kpiMetrics');
  }

  // Currently, Text Analytics in application
  trends() {
    return cy.getByTestId('layout-navigation-module-item--trends');
  }

  // Currently, Trend Analytics in application
  topics() {
    return cy.getByTestId('layout-navigation-module-item--topics');
  }

  // TODO waiting for the data-testid for below locator SLC-30804
  dataSyncStatus() {
    return cy.get('._5n0oWH8FzyuP3ZeZbO1wL .DataSyncCircle__Container-sc-17mm7fb-0');
  }

  expand() {
    this.navbarCollapseExpandButton()
      .invoke('attr', 'data-state')
      .then((state) => {
        if (state === 'collapsed') this.navbarCollapseExpandButton().click();
      });
  }

  collapse() {
    this.navbarCollapseExpandButton()
      .invoke('attr', 'data-state')
      .then((state) => {
        if (state === 'expanded') this.navbarCollapseExpandButton().click();
      });
  }
}

export const navBar = new NavBar();
