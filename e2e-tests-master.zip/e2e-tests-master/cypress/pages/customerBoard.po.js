import { randId } from '../utils';
import { commonElements } from './general/commonElements.po';

export class CustomerBoardPageObject {
  createNewListButton() {
    return cy.getByTestId('customerBoard-createNewListButton');
  }

  createListAddButton() {
    return cy.getByTestId('customer-board_modal-add-button');
  }

  createListCancelButton() {
    return cy.getByTestId('customer-board_modal-cancel-button');
  }

  // TODO data-test id requested via SLC-31545
  createCaseListHeaderTitle() {
    return cy.get('[class^="ListOption__Header-sc"]');
  }

  // TODO data-test id requested via SLC-31545
  createListTitleNameInput() {
    return cy.get('[class^=OptionEditor__Input-]');
  }

  createListPopupTimePeriodDropdown() {
    // TODO data-test id requested via SLC-31545
    return cy.get('[class^=OptionEditor__DropdownTrigger]').eq(0);
  }

  createListPopupCustomerFieldDropdown() {
    // TODO data-test id requested via SLC-31545
    return cy.get('[class^=OptionEditor__DropdownTrigger]').eq(1);
  }

  createListEscalationPredictionLabelCheckbox() {
    return cy.getByTestId('animated-checkbox-customer-board--wizard-escalationPrediction:escalationPrediction-id');
  }

  createListProductionIssueLabelCheckbox() {
    return cy.getByTestId('animated-checkbox-customer-board--wizard-signal:Production Issue-id');
  }

  createListCriticalIssueLabelCheckbox() {
    return cy.getByTestId('animated-checkbox-customer-board--wizard-signal:Critical Issue-id');
  }

  createListCaseVolumeLabelCheckbox() {
    return cy.getByTestId('animated-checkbox-customer-board--wizard-icon:caseVolume-id');
  }

  createListCaseBacklogLabelCheckbox() {
    return cy.getByTestId('animated-checkbox-customer-board--wizard-icon:caseBacklog-id');
  }

  createListNewIdLabelCheckbox() {
    return cy.getByTestId('animated-checkbox-customer-board--wizard-tag:new-id');
  }

  createListEscalationIdLabelCheckbox() {
    return cy.getByTestId('animated-checkbox-customer-board--wizard-escalation:escalation-id');
  }

  createListEscalationREquestIdLabelCheckbox() {
    return cy.getByTestId('animated-checkbox-customer-board--wizard-signal:Escalation Request-id');
  }

  createListCustomerScoreIdLabelCheckbox() {
    return cy.getByTestId('animated-checkbox-customer-board--wizard-score:sl_customer_score-id');
  }

  createListHealthScoreIdLabelCheckbox() {
    return cy.getByTestId('animated-checkbox-customer-board--wizard-score:sl_account_health_score-id');
  }

  createListPartnerIdLabelCheckbox() {
    return cy.getByTestId('animated-checkbox-customer-board--wizard-tag:partner-id');
  }

  createListCaseActivityIdLabelCheckbox() {
    return cy.getByTestId('animated-checkbox-customer-board--wizard-icon:caseActivity-id');
  }

  listTitleNameLabel() {
    return cy.getByTestId('customer-board_list-title');
  }

  threeDotMenuDropdown() {
    return cy.getByTestId('context-menu_trigger');
  }

  deleteListButton() {
    return cy.getByTestId('customer-board_list-context-menu-delete');
  }

  cancelDeleteListPopupButton() {
    return cy.getByTestId('customer-board_list-modal-confirmation-cancel');
  }

  deleteListPopupButton() {
    return cy.getByTestId('customer-board_list-modal-confirmation-action');
  }

  editListButton() {
    return cy.getByTestId('customer-board_list-context-menu-edit');
  }

  editListCancelButton() {
    return cy.getByTestId('customer-board_list-edit-modal-cancel-button');
  }

  editListApplyButton() {
    return cy.getByTestId('customer-board_list-edit-modal-apply-button');
  }

  // TODO data-test id requested via SLC-31545
  editListCustomFieldDropDown() {
    return cy.get('.OptionEditor__DropdownTrigger-sc-7l1x8n-6');
  }

  editListOptionModalTitle() {
    return cy.getByTestId('customer-board_list-edit-modal-option-modal-title');
  }

  editListOptionModalList() {
    return cy.getByTestId('customer-board_list-edit-modal-option-modal-field');
  }

  editListOptionFilterButton() {
    return cy.getByTestId('customer-board_list-edit-modal-option-filter-button');
  }

  editListOptionCancelButton() {
    return cy.getByTestId('customer-board_list-edit-modal-option-cancel-button');
  }

  customerBoardEmptyStateList() {
    return cy.getByTestId('customer-board_list-no-items');
  }

  sortListButton() {
    return cy.getByTestId('customer-board_list-context-menu-sort');
  }

  downloadCSVListButton() {
    return cy.getByTestId('customer-board_list-context-menu-export');
  }

  // TODO data-test id requested via SLC-31545
  appContentContainer() {
    return cy.get('._1salCEQw8CpbhFUN9KWqSS');
  }

  // TODO data-test id requested via SLC-31545
  customerBoardListBodyLabel() {
    return cy.get('[class^="List__ListCard-sc"] [data-testid="customer-board_list-body"]');
  }

  // TODO data-test id requested via SLC-31545
  customerBoardListTitleLabel() {
    return cy.get('[class^="List__ListCard-sc"] [data-testid="customer-board_list-title"]');
  }

  customerBoardCustomerNameLabel() {
    return cy.get('[data-testid="customer-board_list-item"] h4');
  }

  expandButton() {
    return cy.getByTestId('customer-board_list-expand-button');
  }

  customerBoardExpandPopupListTitleLabel() {
    return cy.get('[data-testid="common-modal-message"] [data-testid="customer-board_list-title"]');
  }

  customerBoardExpandPopupListBodyLabel() {
    return cy.get('[data-testid="common-modal-message"] [data-testid="customer-board_list-body"]');
  }

  customerBoardExpandPopupCustomerNameLabel() {
    return cy.get('[data-testid="common-modal-message"] [data-testid="customer-board_list-item"] h4');
  }

  expandPopupThreeDotMenuDropdown() {
    return cy.get('[data-testid="common-modal-message"] [data-testid="context-menu_trigger"]');
  }

  expandPopupDeleteListButton() {
    return cy.get('[data-testid="common-modal-message"] [data-testid="customer-board_list-context-menu-delete"]');
  }

  expandPopupSortListButton() {
    return cy.get('[data-testid="common-modal-message"] [data-testid="customer-board_list-context-menu-sort"]');
  }

  // TODO data-test id requested via SLC-31545
  expandPopupCloseIcon() {
    return cy.get('[class^="List__CloseTrigger-sc"]');
  }

  customerBoardCaseListStats() {
    return cy.getByTestId('customer-board_list-item-stats');
  }

  customerBoardCaseListLabel() {
    return cy.getByTestId('customer-board_list-item-labels');
  }

  welcomePageStandardListButton() {
    return cy.getByTestId('customersBoard-welcomePage-startButton-standard_list_button');
  }

  // TODO data-test id requested via SLC-31545
  customerBoardListCustomerName() {
    return cy.get('.ReactVirtualized__Grid__innerScrollContainer ._1RZFLstJ_MSq2-Riva77G6');
  }

  // TODO data-test id requested via SLC-31545
  customerNotesContainer() {
    return cy.get('[class^="NotesTrigger__Container-sc-"]');
  }

  customerNotesAddNewNotesButton() {
    return cy.getByTestId('supportHub-caseCustomerNotes-addNewNotesButton');
  }

  customerNotesInput() {
    return cy.getByTestId('supportHub-caseCustomerNotes-notesInput');
  }

  customerNotesAddButton() {
    return cy.getByTestId('supportHub-caseCustomerNotes-AddNewNote');
  }

  customerNotesCancelButton() {
    return cy.getByTestId('supportHub-caseCustomerNotes-cancelAddNewNote');
  }

  customerNotesCloseIcon() {
    return cy.getByTestId('supportHub-caseCustomerNotes-closeNoteIcon');
  }

  customerNotesEditNoteIcon() {
    return cy.getByTestId('supportHub-caseCustomerNotes-editNoteIcon');
  }

  customerNotesEditNoteInput() {
    return cy.getByTestId('supportHub-caseCustomerNotes-EditNoteTextarea');
  }

  customerNotesEditNoteCancelButton() {
    return cy.getByTestId('supportHub-caseCustomerNotes-cancelEditNote');
  }

  customerNotesEditNoteSaveButton() {
    return cy.getByTestId('supportHub-caseCustomerNotes-SaveEditNote');
  }

  customerNotesTitle() {
    return cy.get('[data-testid^=supportHub-CaseCustomerNotes--]');
  }

  customerNotesDeleteNoteIcon() {
    return cy.getByTestId('supportHub-caseCustomerNotes-deleteNoteIcon');
  }

  customerBoardTimePeriodDropDown() {
    return cy.getByTestId('common-dropdown-btn');
  }

  customerBoardTimePeriodSixMonthLabel() {
    return cy.getByTestId('common-dropdown-months_6');
  }

  customerBoardTimePeriodAllTimeLabel() {
    return cy.getByTestId('common-dropdown-days_null');
  }

  welcomePageDefaultListButton() {
    return cy.getByTestId('module-common-welcome-page-button-secondary');
  }

  welcomePageCreateCustomListButton() {
    return cy.contains('[data-testid=module-common-welcome-page-button]', 'Create custom list');
  }

  welcomePageTitle() {
    return cy.getByTestId('module-common-welcome-page-title');
  }

  clickCreateNewCaseListButton() {
    commonElements
      .appWrapper()
      .contains('Top Customers')
      .invoke('attr', 'data-testid')
      .then((classValue) => {
        if (classValue === 'module-common-welcome-page-title') {
          this.welcomePageCreateCustomListButton().click();
        } else {
          this.createNewListButton().should('be.visible').click();
        }
      });
  }

  // HealthType - Good/ Fair/ Bad
  createHealthScoreCaseList(HealthType) {
    this.clickCreateNewCaseListButton();
    this.createCaseListHeaderTitle().contains('Health Score').click();
    const caseListName = `Health Score${randId()}`;
    this.createListTitleNameInput().clear().type(caseListName);
    this.createListHealthScoreIdLabelCheckbox().invoke('attr', 'data-status').should('include', 'checked');
    this.editListCustomFieldDropDown().should('be.visible').click();
    this.editListOptionModalTitle().contains('Health Score').click();
    // Select the Health Score as Fair
    this.editListOptionModalList().contains(HealthType).click();
    // Click on Filter button
    this.editListOptionFilterButton().click();
    this.createListAddButton().eq(0).click();
    return caseListName;
  }

  // TODO data-testid requested via SLC-31545.
  deleteCaseList() {
    this.threeDotMenuDropdown().eq(0).click();
    this.deleteListButton().eq(0).click();
    this.deleteListPopupButton().click();
  }

  // TODO data-testid requested via SLC-31545.
  customerBoardSwitchSortOrder() {
    this.customerBoardListCustomerName()
      .eq(0)
      .then((buttonText) => {
        const customerNameBeforeSorted = buttonText.text();

        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(1000);
        this.threeDotMenuDropdown().eq(0).should('be.visible').click({ force: true });
        this.sortListButton().eq(0).should('be.visible').click({ force: true });
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(1000);
        this.customerBoardListCustomerName()
          .eq(0)
          .then((buttonTextAfterSort) => {
            const customerNameAfterSorted = buttonTextAfterSort.text();

            expect(customerNameAfterSorted).to.not.equal(customerNameBeforeSorted);
          });
      });
  }

  customerBoardWelcomePageVisibilityCheck() {
    cy.get('body').then((body) => {
      const getStartedButton = '[data-testid=module-common-welcome-page-button-secondary]';
      if (body.find(getStartedButton).length) {
        cy.get(getStartedButton).should('be.visible').click();
      }
    });
  }
}

export const customerBoardPage = new CustomerBoardPageObject();
