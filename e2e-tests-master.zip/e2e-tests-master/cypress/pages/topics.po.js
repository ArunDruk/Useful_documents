export class TopicsPageObject {
  topicsFirstTopicDropdown() {
    return cy.getByTestId('topicsPage-topicPicker-firstDropdown');
  }

  topicsSecondTopicDropdown() {
    return cy.getByTestId('topicsPage-topicPicker-secondDropdown');
  }

  topicsFirstTopicDropdownListItems() {
    return cy.get('#topic-picker-typeahead');
  }

  topicsTopicDropdownFirstItem() {
    return cy.get('#topic-picker-typeahead-item-0');
  }

  // TODO - data-testid request in SLC-34059
  topicsTropicDropdownNoMatchesFound() {
    return cy.get('.dropdown-item.disabled');
  }

  topicsCaseStatusOpenButton() {
    return cy.getByTestId('case-status--option--open');
  }

  topicsHeaderTicketCount() {
    return cy.getByTestId('topicsPage-headerKPI-ticketCount');
  }

  topicsCaseStatusClosedButton() {
    return cy.getByTestId('case-status--option--closed');
  }

  topicsCaseStatusAllButton() {
    return cy.getByTestId('case-status--option--all');
  }

  topicsPageCardTile() {
    return cy.getByTestId('topicsPage-top-card');
  }

  // TODO - data-testid request in SLC-34059
  topicsPageCardTileTitle() {
    return cy.get('[data-testid="topicsPage-top-card"] ._866wXVKXYDQeRTmsGzN9-');
  }

  // TODO - data-testid request in SLC-34059
  topicsSortByDropdownArrow() {
    return cy.get('.-W4IZfuJRjqi9Zle76cLf');
  }

  topicsSortByCurrentValue() {
    return cy.getByTestId('common-dropdown-value');
  }

  topicsSortByNumberOfCasesDropdownValue() {
    return cy.getByTestId('common-dropdown-cases');
  }

  topicsSortByPercentChangeDropdownValue() {
    return cy.getByTestId('common-dropdown-percentage_change');
  }

  topicsSentimentsTab() {
    return cy.getByTestId('topicsPage-explorer-sentimentCountBtn');
  }

  topicsCaseListTab() {
    return cy.getByTestId('topicsPage-explorer-caseListBtn');
  }

  // TODO - data-testid request in SLC-34059
  topicsCaseListGroupBy() {
    return cy.get('._17z6k28XyDC2Wp-m3d2a_Z');
  }

  // TODO - data-testid request in SLC-34059
  topicsCaseListCustomerName() {
    return cy.get('._3vQc9t04dAasKYpCyyBD0c');
  }

  // TODO - data-testid request in SLC-34059
  topicsThreeDotsToExportButton() {
    return cy.get('._1jDXMzpXLuOggTtieeO0XY');
  }

  topicsExportCountByCasesButton() {
    return cy.get('[data-testid$="count by Cases--exporter--export-btn"]');
  }

  sortByDropdown() {
    return cy.getByTestId('common-dropdown-btn').eq(0);
  }

  dynamicFilterStatusCheckbox() {
    return cy.getByTestId('dynamicFilter--sl_status--label');
  }

  dynamicFilterPriorityCheckbox() {
    return cy.getByTestId('dynamicFilter--sl_priority--label');
  }

  dynamicFilterSaveButton() {
    return cy.getByTestId('dynamicFilter--add-or-save');
  }

  dynamicFilterDropdown() {
    return cy.getByTestId('common-popupFilter-btn');
  }

  dynamicFilterDropdownCheckbox() {
    return cy.get('[data-testid^=item-list_checkbox_]');
  }

  topicPriorities() {
    return cy.getByTestId('topic-explorer_topic_name__medium');
  }

  // TODO - data-testid request in SLC-34441
  topicSearchInputField() {
    return cy.get('[data-testid^=topicsPage-topicPicker-searchInput]');
  }

  topicNameSecondaryTableRowList() {
    return cy.get('[data-testid^="topic-explorer_topic_name"]');
  }

  conversationsTab() {
    return cy.getByTestId('topicsPage-explorer-conversationsBtn');
  }

  responderTab() {
    return cy.getByTestId('topicsPage-explorer-responderCountBtn');
  }

  sentimentsTab() {
    return cy.getByTestId('topicsPage-explorer-sentimentsBtn');
  }

  firstResponseTab() {
    return cy.getByTestId('topicsPage-explorer-firstResponseTimeBtn');
  }

  keywordsTab() {
    return cy.getByTestId('topicsPage-explorer-patternsBtn');
  }

  // Highchart locator class most likely won't change. Hence no need to create a data-testid
  xAxis() {
    return cy.get('.highcharts-xaxis');
  }

  // Highchart locator class most likely won't change. Hence no need to create a data-testid
  xAxisLabels() {
    return cy.get('.highcharts-axis-labels');
  }

  // Highchart locator class most likely won't change. Hence no need to create a data-testid
  yAxis() {
    return cy.get('.highcharts-yaxis');
  }

  // Highchart locator class most likely won't change. Hence no need to create a data-testid
  chartElements() {
    return cy.get('rect.highcharts-point');
  }

  secondaryTabDropdown() {
    return cy.getByTestId('common-dropdown-btn').eq(1);
  }

  conversationCountDropdownOptionAgents() {
    return cy.getByTestId('common-dropdown-agentConversationCount');
  }

  responderCountDropdownOptionAgents() {
    return cy.getByTestId('common-dropdown-agentResponderCount');
  }

  sentimentDropdownOptionAgents() {
    return cy.getByTestId('common-dropdown-agentSentiment');
  }

  sentimentCountDropdownOptionAgents() {
    return cy.getByTestId('common-dropdown-agentSentimentCount');
  }

  firstResponseDropdownOptionAgents() {
    return cy.getByTestId('common-dropdown-agentFirstResponse');
  }

  errorMessage() {
    return cy.contains('Oops! Trouble loading this part');
  }
}

export const topics = new TopicsPageObject();
