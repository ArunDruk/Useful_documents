class SupportHub {
  breadcrumbContent() {
    return cy.getByTestId('supportHub-breadcrumbs-content');
  }

  breadcrumbScrollLeftButton() {
    return cy.getByTestId('supportHub-breadcrumbs-paginationBackBtn');
  }

  breadcrumbScrollRightButton() {
    return cy.getByTestId('supportHub-breadcrumbs-paginationForwardBtn');
  }

  baseContainer() {
    return cy.getByTestId('supportHub-SHContainer');
  }

  closeButton() {
    return cy.getByTestId('supportHub-actionWrapper-closeDialog');
  }

  nowHeaderLabel() {
    return cy.get('[class*=NowHeader]');
  }

  caseIdLabel() {
    return cy.getByTestId('supportHub-caseHeader-caseNumber');
  }

  gotoCaseDescriptionButton() {
    return cy.getByTestId('supporthub-go-to-description');
  }

  commentsDropdown() {
    return cy.getByTestId('supportHub-caseComments-commentsDropdown');
  }

  commentsDropdownAutomatedFeedbackOption() {
    return cy.getByTestId('supportHub-caseComments-commentsDropdownOption-automated_feedback');
  }

  commentsDropdownAllCommentsOption() {
    return cy.getByTestId('supportHub-caseComments-commentsDropdownOption-all_comments');
  }

  commentsDropdownDiscussionOption() {
    return cy.getByTestId('supportHub-caseComments-commentsDropdownOption-discussion');
  }

  commentsDropdownCoachingFeedbackOption() {
    return cy.getByTestId('supportHub-caseComments-commentsDropdownOption-coaching_feedback');
  }

  caseCommentsCoachingHeader() {
    return cy.getByTestId('supportHub-caseComments_coaching-header');
  }

  favoriteButton() {
    return cy.getByTestId('supportHub-caseCustomer-favoriteCaseTrigger');
  }

  favoriteButtonTooltip() {
    return cy.getByTestId('supportHub-caseCustomer-favoriteCaseTooltip');
  }

  customerNotesTriggerButton() {
    return cy.getByTestId('supportHub-caseCustomerNotes-NotesTrigger');
  }

  customerNotesAddNewNotesButton() {
    return cy.getByTestId('supportHub-caseCustomerNotes-addNewNotesButton');
  }

  customerNotesTextField() {
    return cy.getByTestId('supportHub-caseCustomerNotes-notesInput');
  }

  addCustomerNoteCancelButton() {
    return cy.getByTestId('supportHub-caseCustomerNotes-cancelAddNewNote');
  }

  addCustomerNoteAddButton() {
    return cy.getByTestId('supportHub-caseCustomerNotes-AddNewNote');
  }

  customerNotesUserAvatar() {
    return cy.getByTestId('supportHub-caseCustomerNotes-userAvatar');
  }

  customerNotesUserAvatarTooltip() {
    return cy.getByTestId('supportHub-caseCustomerNotes-userAvatar-tooltip');
  }

  customerNotesNoteText(noteId) {
    return cy.getByTestId(`supportHub-CaseCustomerNotes--${noteId}--noteText`);
  }

  customerNotesCreationTimeLabel() {
    return cy.get('[data-testid$=noteDate]');
  }

  customerNotesEditIconButton() {
    return cy.getByTestId('supportHub-caseCustomerNotes-editNoteIcon');
  }

  customerNotesDeleteIconButton() {
    return cy.getByTestId('supportHub-caseCustomerNotes-deleteNoteIcon');
  }

  customerNotesEditTextarea() {
    return cy.getByTestId('supportHub-caseCustomerNotes-EditNoteTextarea');
  }

  customerNotesSaveEditButton() {
    return cy.getByTestId('supportHub-caseCustomerNotes-SaveEditNote');
  }

  agentAvatar() {
    return cy.getByTestId('supportHub-sideBar-agentAvatar-icon');
  }

  agentAvatarDetailsPopup() {
    return cy.getByTestId('agentAvatar-tooltip');
  }

  caseReporterNameText() {
    return cy.getByTestId('supportHub-caseHeader-caseReporterName');
  }

  replyToCustomerButton() {
    return cy.getByTestId('supportHub-caseCommentForm-replyToClientButton');
  }

  addCaseNoteButton() {
    return cy.getByTestId('supportHub-caseCommentForm-addCaseNoteButton');
  }

  caseNotesCcButton() {
    return cy.getByTestId('supportHub-caseCommentForm-CCButton');
  }

  caseNotesCcInput() {
    return cy.getByTestId('supportHub-caseCommentForm-CCContainerInput');
  }

  caseNotesBccButton() {
    return cy.getByTestId('supportHub-caseCommentForm-BCCButton');
  }

  caseNotesBccInput() {
    return cy.getByTestId('supportHub-caseCommentForm-BCCContainerInput');
  }

  caseNotesTextarea() {
    return cy.getByTestId('supportHub-caseCommentForm-addNewCaseNoteInput');
  }

  caseNotesCancelButton() {
    return cy.getByTestId('supportHub-caseCommentForm-cancelButton');
  }

  caseNotesSaveButton() {
    return cy.getByTestId('supportHub-caseCommentForm-saveSendButton');
  }

  caseCommentByText(caseNoteText) {
    return cy.contains('[data-testid^=supportHub-caseComments-body]', caseNoteText);
  }

  /*  Duplicate Locators will be removed Sept 30
  sentimentScoreValue() {
    return cy.getByTestId('case-card-base-sentimentScore');
  }

  attentionScoreValue() {
    return cy.getByTestId('case-card-base-attentionScore');
  }
*/
  privateCaseNoteIcon() {
    return cy.get('[data-icon=notes]');
  }

  supportHubShareIcon() {
    return cy.getByTestId('supportHub-caseShare-trigger');
  }

  // TODO: Request data-testid for share popup SLC-35422
  supportHubScorePopupGrid() {
    return cy.get('[class^="ScorePopup__Grid-sc"]');
  }

  // TODO: Request data-testid for share popup SLC-35122
  supportHubSharePopupAssignedAgentMailLabel() {
    return cy.get('#case-share-popover ._3lkEyePcIfbsBhyt41OxYP ._1RZFLstJ_MSq2-Riva77G6');
  }

  sharePopup() {
    return cy.get('#case-share-popover');
  }

  sharePopupHeader() {
    return cy.getByTestId('supportHub-caseShare-header');
  }

  sharePopupCloseButton() {
    return cy.getByTestId('supportHub-caseShare-closeButton');
  }

  sharePopupSlackButton() {
    return cy.getByTestId('supportHub-caseShare-SlackInputTab');
  }

  sharePopupEmailButton() {
    return cy.getByTestId('supportHub-caseShare-EmailInputTab');
  }

  sharePopupRecipientTextfield() {
    return cy.getByTestId('supportHub-caseShare-shareWithInput');
  }

  sharePopupMessageTextarea() {
    return cy.getByTestId('supportHub-caseShare-addMessageInput');
  }

  reviewPanelShareOptionCancelButton() {
    return cy.getByTestId('escalations__escalationReviewPanel__action__SHARE_CASE__cancel');
  }

  reviewPanelShareOptionSendButton() {
    return cy.getByTestId('escalations__escalationReviewPanel__action__SHARE_CASE__submit');
  }

  shareActionTimelineCommentContainer() {
    return cy.getByTestId('supportHub-caseTimeline-shareAction-container');
  }

  escalationStatusLabel() {
    return cy.getByTestId('supportHub-escalationStatusIndicator-escalationLabel');
  }

  addEscalationNotesIconButton() {
    return cy.getByTestId('supportHub-caseEscalationNotes-addNoteButton');
  }

  escalationNotesTextarea() {
    return cy.getByTestId('supportHub-escalationNoteDialog-editNoteInput');
  }

  postedEscalationNoteText() {
    return cy.getByTestId('escalation-activeEscalations-escalationNotes-noteText');
  }

  sentimentCard() {
    return cy.getByTestId('supportHub-sentiment-card');
  }

  sentimentCardSentimentLabelByText(sentimentText) {
    return cy.contains('[data-testid=supportHub-sentiment-card-caseComment]', sentimentText);
  }

  noSentimentLabel() {
    return cy.contains('No Sentiments detected');
  }

  sentimentBarLeftScrollButton() {
    return cy.getByTestId('supportHub-caseSentiments-paginationButton-left');
  }

  sentimentBarRightScrollButton() {
    return cy.getByTestId('supportHub-caseSentiments-paginationButton-right');
  }

  caseDescriptionComment() {
    return cy.get('[data-testid^=supportHub-caseComments-body]').last();
  }

  addAnnotationButton() {
    return cy.getByTestId('supportHub-caseTimeline-caseComment-addAnnotation');
  }

  addAnnotationTextarea() {
    return cy.getByTestId('supportHub-caseComments-caseAnnotation-editInput');
  }

  addAnnotationSendButton() {
    return cy.getByTestId('supportHub-caseComments-caseAnnotation-sendButton');
  }

  // TODO data-testid requested via SLC-34877.
  addAnnotationCommentTextarea() {
    return cy.get('[class^="public-DraftStyleDefault-block"]');
  }

  addAnnotationCancelButton() {
    return cy.getByTestId('supportHub-caseComments-caseAnnotation-cancelButton');
  }

  addAnnotationDeleteIcon() {
    return cy.getByTestId('supportHub-caseComments_annotation-delete-icon');
  }

  annotationUserNameHeader() {
    return cy.getByTestId('supportHub-caseComments_annotation-author-username');
  }

  annotationCreationDetailsField() {
    return cy.getByTestId('supportHub-caseComments_annotation-creation-date');
  }

  annotationHeader() {
    return cy.getByTestId('supportHub-caseComments_annotation-header');
  }

  annotationText() {
    return cy.getByTestId('supportHub-caseComments_annotation-content');
  }

  highlightsButton() {
    return cy.getByTestId('supportHub-caseComments-highLightButton');
  }

  highlightsPopupCaseCreationTimeText() {
    return cy.getByTestId('customer-board_list-item-time');
  }

  highlightsPopupCaseCustomerWaitTimeText() {
    return cy.getByTestId('supportHub-customerWaitTime');
  }

  highlightsPopupCaseCreationTimeTooltip() {
    return cy.get('[class*=PopperContainer]').last();
  }

  searchButton() {
    return cy.getByTestId('supportHub-caseComments-searchContainer');
  }

  searchTextfield() {
    return cy.getByTestId('supportHub-caseComments-searchInput');
  }

  collapseAllCaseCommentsButton() {
    return cy.getByTestId('supportHub-caseCommentForm-collapseNotesTrigger');
  }

  notifyAgentButton() {
    return cy.getByTestId('supportHub-caseCommentForm-notifyButton');
  }

  caseCommentsContainer() {
    return cy.get('[data-testid^=caseTimeline__caseComment]');
  }

  caseCommentsHeader() {
    return cy.get('[class*=shared__BetaHeader]');
  }

  caseCommentsHeaderCollapseButton() {
    return cy.get('[class*=shared__BetaIconButton]');
  }

  commonCaseCommentText() {
    return cy.get('[data-testid^=supportHub-caseComments-body]');
  }

  caseCommentAddInteractionButton() {
    return cy.getByTestId('supportHub-caseTimeline-caseComment-addACELabel');
  }

  commonInteractionPopupCheckbox() {
    // TODO: For data-testid, refer https://supportlogic.atlassian.net/browse/SLC-34242
    return cy.get('[class*=InteractionPopup__CheckboxItem]');
  }

  interactionPopupClearAllButton() {
    // TODO: For data-testid, refer https://supportlogic.atlassian.net/browse/SLC-34242
    return cy.contains('[class*=InteractionPopup__Footer] button', 'Clear all');
  }

  interactionPopupApplyButton() {
    // TODO: For data-testid, refer https://supportlogic.atlassian.net/browse/SLC-34242
    return cy.contains('[class*=InteractionPopup__Footer] button', 'Apply');
  }

  interactedCaseCommentText() {
    // TODO: For data-testid, refer https://supportlogic.atlassian.net/browse/SLC-34242
    return cy.get('[data-interaction]');
  }

  interactionPreviewPopupContainer() {
    // TODO: For data-testid, refer https://supportlogic.atlassian.net/browse/SLC-34242
    return cy.get('[class^=InteractionPreviewPopup__Container]');
  }

  interactionPreviewPopupRemoveButton() {
    // TODO: For data-testid, refer https://supportlogic.atlassian.net/browse/SLC-34242
    return cy.contains('[class*=LinkButton]', 'Remove label');
  }

  interactionPreviewPopupUndoButton() {
    // TODO: For data-testid, refer https://supportlogic.atlassian.net/browse/SLC-34242
    return cy.contains('[class*=LinkButton]', 'Undo');
  }

  caseCustomerNameLabel() {
    return cy.getByTestId('supportHub-caseCustomer-CustomerName');
  }

  timelineStatsLabel() {
    // TODO: Get data-testid for timeline stats label (SLC-33335)
    return cy.get('[class^=Timeline__NotesStats]');
  }

  caseFieldStatusLabel() {
    return cy.getByTestId('supportHub-caseField-status');
  }

  caseFieldPriorityLabel() {
    return cy.getByTestId('supportHub-caseField-priority');
  }

  reviewCommentHeader() {
    return cy.getByTestId('ace-evaluation-review-comment-header');
  }

  reviewCommentInput() {
    return cy.getByTestId('ace-evaluation-review-comment-input');
  }

  // TODO data-testid requested via SLC-34877.
  reviewCommentDropdown() {
    return cy.get('[class^="CategoriesDropdown__Field"]');
  }

  reviewCommentsDropdown() {
    return cy.getByTestId('common-checkbox');
  }

  reviewCommentEditButton() {
    return cy.getByTestId('ace-evaluation-review-comment-edit-button');
  }

  reviewCommentDeleteButton() {
    return cy.getByTestId('ace-evaluation-review-comment-delete-button');
  }

  // TODO data-testid requested via SLC-34877.
  reviewPageCommentText() {
    return cy.get('[class^="CaseReviewCommentView__Grid"] [class^="CaseReviewCommentView__Text"]');
  }

  // TODO data-testid requested via SLC-34877.
  reviewPageCategoryText() {
    return cy.get('[class^="CategoriesDropdown__Category"]');
  }

  reviewSummaryCommentText() {
    return cy.getByTestId('ace-review-summary-category-slider-comment');
  }

  reviewSummaryCategoryText() {
    return cy.getByTestId('ace-review-summary-category-title');
  }

  reviewCommentsContainer() {
    return cy.get('[data-testid^="supportHub-caseComments-caseReview"]');
  }

  /**
   * Returns the SH timeline action comment-body element of the specified type
   * @param {string} actionType - the type of recommended action
   * @example
   * timelineActionComment('ESCALATION_NOTE')
   * timelineActionComment('SHARE_CASE')
   */
  timelineActionComment(actionType) {
    return cy.getByTestId(`supportHub-escalationReview-${actionType}-caseComment-body`);
  }

  timelineCommentShowMoreButton() {
    return cy.getByTestId('truncated-content_showMoreButton');
  }

  timelineCommentShowLessButton() {
    return cy.getByTestId('truncated-content_showLessButton');
  }

  timelineCommentAssignmentHistory() {
    return cy.getByTestId('supportHub-caseTimeLine-assignmentHistory-assignedName').parent();
  }

  reviewCommentsCancelButton() {
    return cy.getByTestId('supportHub-caseComments-caseReview-cancelButton');
  }

  reviewCommentsSendButton() {
    return cy.getByTestId('supportHub-caseComments-caseReview-sendButton');
  }

  // TODO data-testid requested via SLC-34877.
  caseInsightListItem() {
    return cy.get('[class^="Insights__Item-sc"]');
  }

  addPublicCaseNote(noteText) {
    this.replyToCustomerButton().click();

    this.caseNotesTextarea().type(noteText, { force: true });
    this.caseNotesSaveButton().click();
  }

  addPrivateCaseNote(noteText) {
    this.addCaseNoteButton().click();

    this.caseNotesTextarea().type(noteText, { force: true });
    this.caseNotesSaveButton().click();
  }

  addCustomerNotes(noteText) {
    const emptyNotesBtnSelector = '[data-testid=supportHub-caseCustomerNotesEmpty-addNewNotesButton]';

    this.customerNotesTriggerButton().click();
    cy.get('body').then(($body) => {
      if ($body.find(emptyNotesBtnSelector).length) {
        cy.get(emptyNotesBtnSelector).should('be.visible').click();
      } else {
        this.customerNotesAddNewNotesButton().click();
      }
    });

    this.customerNotesTextField().type(noteText);
    this.addCustomerNoteAddButton().should('be.enabled').click();
  }

  selectCaseCommentText(commentIndex) {
    this.commonCaseCommentText()
      .eq(commentIndex)
      .trigger('mousedown')
      .then(($commentElement) => {
        const elementText = Cypress.$($commentElement)
          .contents()
          .filter(function returnTextNode() {
            return this.nodeType === Node.TEXT_NODE;
          })[0];
        const document = elementText.ownerDocument;
        const range = document.createRange();
        range.selectNodeContents(elementText);
        document.getSelection().removeAllRanges();
        document.getSelection().addRange(range);
      })
      .trigger('mouseup');
  }

  caseOwnerContainer() {
    return cy.getByTestId('supportHub-caseOwnerSelect-ownerContainer');
  }

  caseOwnerLabel() {
    return cy.getByTestId('supportHub-caseOwnerSelect-caseOwnerName');
  }

  reviewPanelReassignAgentSearchButton() {
    return cy.getByTestId('supportHub-caseOwnerSelect-ica-searchTab');
  }

  reviewPanelReassignAgentSearchTextfield() {
    return cy.getByTestId('supportHub-caseOwnerSelect-searchInput');
  }

  reviewPanelReassignAgentSearchResultListItem() {
    return cy.getByTestId('supportHub-caseOwnerSelect-ica-itemCard');
  }

  reviewPanelReassignAgentAssignBtn() {
    return cy.getByTestId('supportHub-caseOwnerSelect-ica-itemCard-assignButton');
  }

  likelyToEscalateLabel() {
    return cy.getByTestId('supportHub-lte_lte-section');
  }

  supportHubAcknowledgeButton() {
    return cy.getByTestId('supportHub-sentiment-acknowledge');
  }

  supportHubAcknowledgeWaterMarkIcon() {
    return cy.getByTestId('supportHub-sentiment-acknowledgedWatermarkIcon');
  }

  supportHubAcknowledgeByLabel() {
    return cy.getByTestId('supportHub-sentiment-acknowledgeContainer');
  }

  supportHubAcknowledgeRemoveIcon() {
    return cy.getByTestId('supportHub-sentiment-removeAcknowledge');
  }

  supportHubSentimentScoreLabel() {
    return cy.getByTestId('case-card-base-sentimentScore');
  }

  supportHubAttentionScoreLabel() {
    return cy.getByTestId('case-card-base-attentionScore');
  }

  // TODO: Request data-testid SLC-35422
  supportHubLteLabel() {
    return cy.get('.styles__Container-sc-dkaqrj-0');
  }

  clearEscalationNotesWelcomeScreen() {
    cy.get('body').then((body) => {
      const locator = '[data-testid=supportHub-escalationNoteDialog-addEscalationNoteButton]';
      if (body.find(locator).length) {
        cy.get(locator).click();
      }
    });
  }
}

export const supportHub = new SupportHub();
