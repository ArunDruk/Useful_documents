class Trends {
  searchTextField() {
    // 3rd party component - cannot add testid
    return cy.get('.Select__value-container');
  }

  clearSearchButton() {
    // 3rd party component - cannot add testid
    return cy.get('.Select__clear-indicator');
  }

  searchPopupAllRadioButton() {
    return cy.getByTestId('search-menu-radio-button--and');
  }

  searchPopupAnyRadioButton() {
    return cy.getByTestId('search-menu-radio-button--or');
  }

  currentlySearchedTextChips() {
    return cy.getByTestId('trends-search-select-value');
  }

  mainChartSearchedTextChips() {
    return cy.getByTestId('trends-mainChart-header-select-value');
  }

  headerTicketCountLabel() {
    return cy.getByTestId('trendBetaPage-headerKPI-ticketCount');
  }

  groupByDropdownTrigger() {
    return cy.getByTestId('trends--group-by--popup-trigger');
  }

  groupByDropdownOptions(optionName) {
    if (optionName) {
      return cy.contains('[data-testid^=trends--group-by--option]', optionName);
    }
    return cy.get('[data-testid^=trends--group-by--option]');
  }

  chartLeftTraverseButton() {
    return cy.getByTestId('trends--previous-date-period');
  }

  chartRightTraverseButton() {
    return cy.getByTestId('trends--next-date-period');
  }

  chartMenuButton() {
    return cy.getByTestId('trends-mainChart-menu-trigger');
  }

  chartMenuPopup() {
    return cy.getByTestId('trends-mainChart-menu-options-popup');
  }

  chartMenuRollUpOptions(rollUpPeriod) {
    return cy.getByTestId(`trends-mainChart-menu-options-rollUp_${rollUpPeriod.toLowerCase()}`);
  }

  chartMenuOptionCsvExportCheckbox() {
    return cy.get('[data-testid$=exporter--option--csv] input');
  }

  chartMenuOptionImageExportCheckbox() {
    return cy.get('[data-testid$=exporter--option--image] input');
  }

  chartMenuOptionExportButton() {
    return cy.get('[data-testid$=exporter--export-btn]');
  }

  chartLegendCardHeaderLabel() {
    return cy.getByTestId('trends-mainChart-legend-title');
  }

  chartLegendSentimentScoreLabel() {
    return cy.getByTestId('trends-mainChart-legend-sentimentScore-value');
  }

  chartLegendItems() {
    return cy.getByTestId('trends-mainChart-legend-item');
  }

  chartXAxisLabels() {
    // NOTE: This does not need testid (or at least until we run against other instances)
    return cy.get('.highcharts-xaxis-labels');
  }

  commonTabs() {
    return cy.get('[data-testid^=trends--tabs--option]:not([tabindex])');
  }

  commonTabCaseCountLabel() {
    return cy.get('[data-testid^=consolePage-tabsSlider-tab-count]');
  }

  tabChartContainers() {
    // NOTE: THIS METHOD ONLY APPLIES FOR OVERVIEW & ESCALATIONS TAB AT THE MOMENT
    return cy.get('[data-testid^=chartWrapper-trends__overview]');
  }

  topEntityListItem() {
    // NOTE: This does not need testid (or at least until we run against other instances)
    return cy.get('._2Mk3blLJGUCEeVaXHtIBUD .highcharts-xaxis-labels text');
  }

  topEntityRestoreButton() {
    return cy.getByTestId('trends-top-entities-restore-btn');
  }

  selectedTopEntityHighlight() {
    // NOTE: This does not need testid (or at least until we run against other instances)
    return cy.get('.highcharts-overlay');
  }

  selectedTopEntityRemoveButton() {
    // NOTE: This does not need testid (or at least until we run against other instances)
    return cy.get('.highcharts-delete-btn');
  }

  overviewTab() {
    return cy.getByTestId('trends--tabs--option--tickets').eq(1);
  }

  escalationsTab() {
    return cy.getByTestId('trends--tabs--option--escalations').eq(1);
  }

  negativeSentimentsTab() {
    return cy.getByTestId('trends--tabs--option--negative_sentiments').eq(1);
  }

  positiveSentimentsTab() {
    return cy.getByTestId('trends--tabs--option--positive_sentiments').eq(1);
  }

  needAttentionTab() {
    return cy.getByTestId('trends--tabs--option--need_attention').eq(1);
  }

  productFeedbackTab() {
    return cy.getByTestId('trends--tabs--option--product_feedback').eq(1);
  }

  escalationsRequestsTab() {
    return cy.getByTestId('trends--tabs--option--escalation_requests').eq(1);
  }

  tabGroupByDropdownTrigger() {
    return cy.getByTestId('sentimentsFeed-lightFilter-groupBy-btn');
  }

  tabGroupByOptionElapsedTime() {
    return cy.getByTestId('common-dropdown-recency');
  }

  searchKeywordDropdownListButton() {
    return cy.getByTestId('trends--search--keywords--popup-trigger');
  }

  // Request for data-testId in SLC-35736
  searchKeywordsOptionActiveList() {
    return cy.get('[data-testid^="trends--search--keywords--option--"]:not(._1rTgGGTNX_zuDqoe2Qc4t9)');
  }

  getHeaderTicketCount() {
    return this.headerTicketCountLabel()
      .invoke('text')
      .then((ticketCounts) => parseInt(ticketCounts.replace(',', ''), 10));
  }

  openGroupByDropdown() {
    this.groupByDropdownTrigger().then((element) => {
      if (element.attr('aria-expanded') === 'false') cy.wrap(element, { log: false }).click();
    });
  }

  searchForKeyword(keyword) {
    this.searchTextField()
      .type(keyword)
      .then(() => {
        cy.tab();
      })
      .type('{enter}');
  }

  groupTabDataByElapsedTime() {
    this.tabGroupByDropdownTrigger()
      .invoke('text')
      .then((currentValue) => {
        if (currentValue !== 'Elapsed Time') {
          this.tabGroupByDropdownTrigger().click();
          this.tabGroupByOptionElapsedTime().click();
        }
      });
  }

  verifyMainChartTooltipPriorities() {
    cy.get('.highcharts-axis')
      .parent()
      .then(($el) => {
        if ($el.find('.highcharts-tooltip').length > 0) {
          const tooltip = $el.find('.highcharts-tooltip').text();
          expect(tooltip).to.match(/(Medium|High|Low)/);
          expect(tooltip).to.contain('Click to view cases');
        }
      });
  }

  chartTracker() {
    return cy.get('.highcharts-tracker-line');
  }

  overviewChartStatusWrapper() {
    return cy.getByTestId('chartWrapper-trends__overview__sl_status');
  }

  overviewChartPriorityWrapper() {
    return cy.getByTestId('chartWrapper-trends__overview__sl_priority');
  }

  // Highchart locator class most likely won't change. Hence no need to create a data-testid
  overviewCommonChartElements() {
    return cy.get('[data-testid^="chartWrapper-trends__overview"] .highcharts-point');
  }
}

export const trends = new Trends();
