const randId = () => Cypress._.random(0, 1e6);

export class BacklogPageObject {
  listTitleNameLabel() {
    return cy.getByTestId('casesPage-casesList-listTitle-titleName');
  }

  listFullTitleNameLabel() {
    return cy.getByTestId('casesPage-casesList-listTitle');
  }

  expandButton() {
    return cy.getByTestId('caseBoard--list--expand');
  }

  expandedListCloseIcon() {
    return cy.getByTestId('casesPage-casesList-caseListExpanded-closeBtn');
  }

  backlogDisableModalMessage() {
    return cy.getByTestId('Case_Backlog-disable-modal-message');
  }

  createNewListButton() {
    return cy.getByTestId('caseBoard--floating-action-button');
  }

  backlogLockModalMessage() {
    return cy.getByTestId('welcomeScreen-restricted--label');
  }

  createNewListSubmitButton() {
    return cy.getByTestId('steps-actionButton__submit');
  }

  createNewListTitleNameInput() {
    return cy.getByTestId('caseBoard--list-form--listNameInput');
  }

  createListSentimentScoreLabelRadio() {
    return cy.getByTestId('caseBoard--list-form--tabs--rank--items--sentimentScore');
  }

  createListAttentionScoreLabelRadio() {
    return cy.getByTestId('caseBoard--list-form--tabs--rank--items--attentionScore');
  }

  createListSentimentCountLabelRadio() {
    return cy.getByTestId('caseBoard--list-form--tabs--rank--items--sentimentCount');
  }

  createNewListCancelButton() {
    return cy.getByTestId('steps-actionButton__cancel');
  }

  addDynamicFilterButton() {
    return cy.getByTestId('filters-dynamicFilters-addAFilter');
  }

  createNewListModalMessage() {
    return cy.getByTestId('common-modal-message');
  }

  threeDotMenuDropdown() {
    return cy.getByTestId('caseBoard--list--menu');
  }

  deleteListButton() {
    return cy.getByTestId('caseBoard--list--menu--delete-list');
  }

  cancelDeleteListPopupButton() {
    return cy.getByTestId('casesPage-casesList-removePopup-cancelDeleteBtn');
  }

  deleteListPopupButton() {
    return cy.getByTestId('casesPage-casesList-removePopup-confirmDeleteBtn');
  }

  welcomePageTitle() {
    return cy.getByTestId('module-common-welcome-page-title');
  }

  welcomePageDefaultListButton() {
    return cy.getByTestId('module-common-welcome-page-button-secondary');
  }

  welcomePageCreateCustomListButton() {
    return cy.getByTestId('module-common-welcome-page-button');
  }

  editListButton() {
    return cy.getByTestId('caseBoard--list--menu--edit-list');
  }

  backlogListCustomerName() {
    return cy.getByTestId('casesPage-casesList-caseCard-customerName');
  }

  backlogListPriorityLabel() {
    return cy.getByTestId('casesPage-caseCard-priorityLabel');
  }

  // TODO data test id requested via SLC-35542
  backlogListCaseIdLabel() {
    return cy.get('[class^="_3AvKbbafTO7GzAFKNSeM"]');
  }

  // TODO data-testid requested via SLC-31545.
  backlogListSentimentCount() {
    return cy.get('._3c4qvcdzXQqGQa0PKF2AIx [data-testid="case-card-base-scoreBadge"]');
  }

  backlogCustomerCaseList() {
    return cy.getByTestId('caseBoard--list--item');
  }

  supportHubCustomerName() {
    return cy.getByTestId('supportHub-caseCustomer-CustomerName');
  }

  supportHubCustomerId() {
    return cy.getByTestId('supportHub-caseHeader-caseNumber');
  }

  supportHubPopupCloseIcon() {
    return cy.getByTestId('supportHub-actionWrapper-closeDialog');
  }

  switchSortButton() {
    return cy.getByTestId('caseBoard--list--menu--switch-sort-direction');
  }

  // TODO data-testid requested via SLC-35542.
  createListFilterTitleName() {
    return cy.get('[class^="styles__Title-sc-3"]');
  }

  // TODO data-testid requested via SLC-35542.
  createListRankCaseByTitleName() {
    return cy.get('[class^="styles__Title-sc-j"]');
  }

  enterPressAction() {
    return cy.realPress('Enter');
  }

  rankCaseByCheck() {
    return cy.contains('Rank cases by');
  }

  downloadCSVButton() {
    return cy.getByTestId('caseBoard--list--menu--download-csv');
  }

  // TODO data test id requested via SLC-35542
  expandedListPopupDiv() {
    return cy.get('._3c4qvcdzXQqGQa0PKF2AIx');
  }

  // TODO data test id requested via SLC-35542
  expandedListthreeDotMenuDropdown() {
    return cy.get('._3c4qvcdzXQqGQa0PKF2AIx [data-testid="caseBoard--list--menu"]');
  }

  // TODO data test id requested via SLC-35542
  expandedListswitchSortButton() {
    return cy.get('._3c4qvcdzXQqGQa0PKF2AIx [data-testid="caseBoard--list--menu--switch-sort-direction"]');
  }

  // TODO data test id requested via SLC-35542
  expandedListPopupCustomerCaseList() {
    return cy.get('._3c4qvcdzXQqGQa0PKF2AIx [data-testid="caseBoard--list--item"]');
  }

  // TODO data test id requested via SLC-35542
  expandedListPopupCustomerNameList() {
    return cy.get('._3c4qvcdzXQqGQa0PKF2AIx [data-testid="casesPage-casesList-caseCard-customerName"]');
  }

  // TODO data test id requested via SLC-35542
  expandedListPopupCaseIdLabel() {
    return cy.get('._3c4qvcdzXQqGQa0PKF2AIx [class^="_3AvKbbafTO7GzAFKNSeM"]');
  }

  createNewList() {
    const caseName = `Test Case Board ${randId()}`;

    this.createNewListButton().click();
    this.createNewListSubmitButton().should('be.disabled');
    this.createNewListTitleNameInput().type(caseName);
    this.createNewListSubmitButton().should('be.enabled');
    this.createNewListSubmitButton().should('be.visible').and('have.text', 'Next').click();
    this.createNewListSubmitButton().click();
    this.createListSentimentScoreLabelRadio().click();
    this.createNewListSubmitButton().should('be.visible').and('have.text', 'Create').click();
    this.listFullTitleNameLabel().eq(0).contains(caseName);
  }

  deleteBacklogList() {
    this.threeDotMenuDropdown().eq(0).click({ force: true });
    this.deleteListButton().eq(0).click({ force: true });
    this.deleteListPopupButton().eq(0).click({ force: true });
  }

  editNameBacklogList() {
    this.threeDotMenuDropdown().eq(0).should('be.visible').click();
    this.editListButton().eq(0).should('be.visible').click();
    this.createNewListTitleNameInput().clear().type('Test_Case_Board_Edited');
    this.createNewListSubmitButton().click();
    this.createNewListSubmitButton().click();
    this.createNewListSubmitButton().should('be.visible').click({ force: true });
    this.listFullTitleNameLabel().eq(0).contains('Test_Case_Board_Edited');
  }

  welcomePageVisibility() {
    this.welcomePageTitle().should('have.text', 'Backlog');
    this.welcomePageDefaultListButton().should('be.enabled').and('have.text', 'Load default lists set');
    this.welcomePageCreateCustomListButton().should('be.enabled').and('have.text', 'Create custom list');
  }

  welcomePageDefaultListsSet() {
    this.welcomePageTitle().should('have.text', 'Backlog');
    this.welcomePageDefaultListButton().should('be.enabled').and('have.text', 'Load default lists set');
    this.welcomePageCreateCustomListButton().should('be.enabled').and('have.text', 'Create custom list');
    this.welcomePageDefaultListButton().should('be.enabled').and('have.text', 'Load default lists set').click();
    this.listFullTitleNameLabel().contains('Sentiment Score');
    this.listFullTitleNameLabel().contains('Attention Score');
    this.listFullTitleNameLabel().contains('Case Age');
    this.listFullTitleNameLabel().contains('Unreplied Case');
  }

  welcomePageCreateCustomList() {
    const caseName = `Test Case Board ${randId()}`;

    this.welcomePageTitle().should('have.text', 'Backlog');
    this.welcomePageDefaultListButton().should('be.enabled').and('have.text', 'Load default lists set');
    this.welcomePageCreateCustomListButton().should('be.enabled').and('have.text', 'Create custom list').click();
    this.createNewListTitleNameInput().type(caseName);
    this.createNewListSubmitButton().should('be.enabled').and('have.text', 'Next').click();
    this.createNewListSubmitButton().click();
    this.createListSentimentScoreLabelRadio().click();
    this.createNewListSubmitButton().should('be.visible').and('have.text', 'Create').click();
    this.listFullTitleNameLabel().eq(0).contains(caseName);
    this.deleteBacklogList();
    this.welcomePageDefaultListButton().click();
  }

  verifyBacklogSupportHub() {
    this.backlogListCustomerName()
      .eq(0)
      .then((buttonText) => {
        const customerName = buttonText.text();

        this.backlogCustomerCaseList().eq(0).should('be.visible').click();
        this.supportHubCustomerName().invoke('text').should('be.equal', customerName);
        this.supportHubPopupCloseIcon().click();
      });
  }

  verifyCancelInDeletePopUp() {
    this.listFullTitleNameLabel().eq(0).contains('Sentiment Score');
    this.threeDotMenuDropdown().eq(0).click({ force: true });
    this.deleteListButton().eq(0).click({ force: true });
    this.cancelDeleteListPopupButton().eq(0).should('be.enabled').and('have.text', 'Cancel').click({ force: true });
    this.listFullTitleNameLabel().eq(0).contains('Sentiment Score');
  }

  verifyNewListWithSentimentCount() {
    this.createNewListButton().click();
    const caseName = `Test Case Board ${randId()}`;

    this.createNewListSubmitButton().should('be.disabled');
    this.createNewListTitleNameInput().type(caseName);
    this.createNewListSubmitButton().should('be.enabled').and('have.text', 'Next').click();
    this.createNewListSubmitButton().click();
    this.createListSentimentCountLabelRadio().click();
    this.createNewListSubmitButton().should('be.visible').and('have.text', 'Create').click();
    cy.waitForLoaders();

    this.listFullTitleNameLabel().eq(0).contains(caseName);
    this.listFullTitleNameLabel().eq(0).contains('Sentiment Count');
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(500);
    this.expandButton().first().click();
    cy.waitForLoaders();
    this.backlogListSentimentCount()
      .first()
      .then((buttonTextFirst) => {
        const sentimentCount = buttonTextFirst.text();

        this.backlogListSentimentCount()
          .last()
          .then((buttonTextSecond) => {
            const sentimentCount1 = buttonTextSecond.text();
            expect(parseInt(sentimentCount, 10)).to.be.greaterThan(parseInt(sentimentCount1, 10));
            this.expandedListCloseIcon().click();
          });
      });
  }

  verifyListSortOrder() {
    this.backlogListCaseIdLabel()
      .eq(0)
      .then((buttonText) => {
        const customerNameBeforeSorted = buttonText.text();

        cy.intercept('POST', '/api/cache/qa-automation/tickets/v2/data').as('dataload');
        this.threeDotMenuDropdown().eq(0).should('be.visible').click({ force: true });
        this.switchSortButton().eq(0).should('be.visible').click({ force: true });
        // cy.wait('@dataload');
        cy.waitForLoaders();
        this.backlogListCaseIdLabel()
          .eq(0)
          .then((buttonTextAfterSort) => {
            const customerNameAfterSorted = buttonTextAfterSort.text();

            expect(customerNameAfterSorted).to.not.equal(customerNameBeforeSorted);
          });
      });
  }

  verifyNewListEnterKeyPress() {
    const caseName = `Test Case Board ${randId()}`;
    this.createNewListButton().click();
    this.createNewListSubmitButton().should('be.disabled');
    this.createNewListTitleNameInput().type(caseName);
    this.createNewListSubmitButton().click();
    this.enterPressAction();
    this.createNewListModalMessage().should('be.visible');
    this.rankCaseByCheck();
    this.createListSentimentScoreLabelRadio().click();
    this.createNewListSubmitButton().should('be.visible').and('have.text', 'Create').click();
    this.listFullTitleNameLabel().eq(0).contains(caseName);
  }

  verifyNewListCancelAfterNaming() {
    const caseName = `Test Case Board ${randId()}`;

    this.createNewListButton().click();
    this.createNewListSubmitButton().should('be.disabled');
    this.createNewListTitleNameInput().type(caseName);
    this.createNewListSubmitButton().should('be.enabled').and('have.text', 'Next').click();
    this.createNewListSubmitButton().click();
    this.createListSentimentScoreLabelRadio().click();
    this.createNewListCancelButton().should('be.enabled').and('have.text', 'Cancel').click();
    this.createNewListButton().should('be.visible');
    this.addDynamicFilterButton().should('be.visible');
  }

  verifyNewListCancel() {
    this.createNewListButton().click();
    this.createNewListSubmitButton().should('be.disabled');
    this.createNewListCancelButton().should('be.visible').click();
    this.createNewListButton().should('be.visible');
    this.addDynamicFilterButton().should('be.visible');
  }

  verifyNewListRankCasesByFlow() {
    const caseName = `Test Case Board ${randId()}`;

    this.createNewListButton().click();
    this.createNewListSubmitButton().should('be.disabled');
    this.createNewListTitleNameInput().type(caseName);
    this.createNewListSubmitButton().should('be.enabled').and('have.text', 'Next').click();
    this.createNewListModalMessage().should('be.visible');
    this.rankCaseByCheck();
    this.createNewListSubmitButton().click();
    this.createListSentimentScoreLabelRadio().click();
    this.createNewListSubmitButton().should('be.visible').and('have.text', 'Create').click();
    this.listFullTitleNameLabel().eq(0).contains(caseName);
  }

  verifyListEditFLow() {
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    const caseName = `Test Case Board ${randId()}`;

    this.backlogListCustomerName()
      .eq(0)
      .then((buttonText) => {
        const customerName = buttonText.text(); //

        cy.intercept('POST', 'api/v2/ticket/assignment/metadata/query').as('dataload');
        this.threeDotMenuDropdown().eq(0).should('be.visible').click();
        this.editListButton().eq(0).should('be.visible').click();
        this.createNewListTitleNameInput().clear().type(caseName);
        this.createNewListSubmitButton().click();
        this.createListFilterTitleName().should('have.text', 'Filter cases by');
        this.createNewListSubmitButton().click();
        this.createListRankCaseByTitleName().should('have.text', 'Rank cases by');
        this.createListAttentionScoreLabelRadio().click();
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(1000);
        this.createNewListSubmitButton().should('be.enabled').and('have.text', 'Apply changes').click();
        cy.wait('@dataload');
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(2000);
        this.backlogListCustomerName()
          .eq(0)
          .then((buttonTextAfterCancelled) => {
            const customerNameAfterCancelled = buttonTextAfterCancelled.text();

            expect(customerNameAfterCancelled).to.not.equal(customerName);
          });
      });
    this.listFullTitleNameLabel().eq(0).contains(caseName);
    this.deleteBacklogList();
  }

  verifyListEditCancellingFlow() {
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    this.listFullTitleNameLabel()
      .eq(0)
      .then((buttonText) => {
        const listName = buttonText.text();

        this.threeDotMenuDropdown().eq(0).should('be.visible').click();
        this.editListButton().eq(0).should('be.visible').click();
        this.createNewListSubmitButton().click();
        this.createListFilterTitleName().should('have.text', 'Filter cases by');
        this.createNewListSubmitButton().click();
        this.createListRankCaseByTitleName().should('have.text', 'Rank cases by');
        this.createNewListSubmitButton().should('be.enabled').and('have.text', 'Apply changes');
        this.createNewListCancelButton().should('be.enabled').and('have.text', 'Cancel').click();
        this.listFullTitleNameLabel()
          .eq(0)
          .then((buttonTextAfterCancelled) => {
            const listNameAfterCancelled = buttonTextAfterCancelled.text();

            expect(listNameAfterCancelled).to.equal(listName);
          });
      });
  }

  backlogWelcomePageVisibilityCheck() {
    cy.get('body').then((body) => {
      const loadDefaultListButton = '[data-testid=module-common-welcome-page-button-secondary]';
      if (body.find(loadDefaultListButton).length) {
        cy.get(loadDefaultListButton).should('be.visible').click();
      }
    });
  }
}

export const backlogPage = new BacklogPageObject();
