export class AgentInsightsPageObject {
  // Search Agents
  agentSearchFieldInput() {
    return cy.getByTestId('common__favoriteSearchBar__input');
  }

  agentInsightsSearchFieldInput() {
    return cy.getByTestId('agentsPage-searchBar-searchInput');
  }

  agentSearchResultList() {
    return cy.getByTestId('global-searchBar-searchOption-item');
  }

  searchFilterNameLabel() {
    return cy.getByTestId('virtEntityTypeahed-filters__item');
  }

  expandFilterButton() {
    return cy.getByTestId('virtEntityTypeahed-filters__button');
  }

  agentSearchIndividualAgentCheckBox() {
    return cy.getByTestId('animated-checkbox-default-group-Individual Agent-id');
  }

  // Favorite Agents
  // SLC-32375 asks to make the name verifiable instead of just checking for the favorite button's presence
  removeFavoriteAgentButton() {
    return cy.getByTestId('agentsPage-agentBacklog-removeFavoriteButton');
  }

  agentActivityTab() {
    return cy.getByTestId('tabNav__activity');
  }

  agentPerformanceTab() {
    return cy.getByTestId('tabNav__performance');
  }

  agentPerformanceBetaTab() {
    return cy.getByTestId('tabNav__performanceBeta');
  }

  // TODO data-testid requested via SLC-31020
  agentPerformanceBetaContainer() {
    return cy.get('.AgentPerformanceEmptyView__Container-sc-1vru57f-0.dwkZdI');
  }

  // TODO data-testid requested via SLC-31020
  agentInAgentOOOLabel() {
    return cy.get('._1sMqy-dTnndFV4b6rmw_AC');
  }

  agentInAgentSearchListOnFavorites() {
    return cy.getByTestId('global-searchBar-searchOption-item');
  }

  agentSearchFromFavoritesFieldInput() {
    return cy.getByTestId('common__favoriteSearchBar__input');
  }

  agentSearchFromFavoritesResultList() {
    return cy.getByTestId('global-searchBar-searchOption-item');
  }

  agentSearchResultListNameLabel() {
    return cy.getByTestId('global-searchBar-searchOption-item__label');
  }

  agentOpenCasesCountTab() {
    return cy.getByTestId('consolePage-tabsSlider-tab-count-Open_Cases');
  }

  agentClosedCasesCountTab() {
    return cy.getByTestId('consolePage-tabsSlider-tab-count-Closed_Cases');
  }

  searchAgentOpenCasesCaseId() {
    return cy.getByTestId('common-caseList-defaultItem-cardId');
  }

  // waiting for the data-testid SLC-31020
  agentNameInsightViewLabel() {
    return cy.get('[class^="AgentDataView__AgentInfoContainer-sc"] ._262NcsdVedkn8DRq3826GK');
  }

  agentProfileButton() {
    return cy.getByTestId('my-agents-page-agentBacklog-viewProfileButton');
  }

  agentInsightsCalendarForwardButton() {
    return cy.getByTestId('common-calendar-button-next');
  }

  agentInsightsEventOOOSelectionButton() {
    return cy.getByTestId('common-buttonSwitcher-btn').contains('Out of office');
  }

  agentInsightsEventAwaySelectionButton() {
    return cy.getByTestId('common-buttonSwitcher-btn').contains('Away');
  }

  agentInsightsOOOReasonButton() {
    return cy.getByTestId('common-pill-label').parent();
  }

  agentInsightsOOOSaveButton() {
    return cy.getByTestId('away-widget-save-button');
  }

  agentInsightsOOODeleteButton() {
    return cy.getByTestId('away-widget-delete-button');
  }

  selectIndividualAgentCheckboxInFavAgent() {
    this.expandFilterButton().click();
    this.agentSearchIndividualAgentCheckBox()
      .invoke('attr', 'data-status')
      .then(($statusValue) => {
        if ($statusValue === 'unchecked') {
          this.searchFilterNameLabel().contains('Individual Agent').click();
          this.agentSearchIndividualAgentCheckBox().invoke('attr', 'data-status').should('include', 'checked');
        }
      });
  }

  getTabsByName(tabName) {
    const formattedTabName = tabName.toLowerCase().replaceAll(' ', '_');

    return cy.getByTestId(`agentsPage-tabSlider-${formattedTabName}`);
  }

  calendarDate() {
    return cy.getByTestId('agentAssignmentCalendar-calendarTitle-calendarDate');
  }

  noAgentsFoundLabel() {
    return cy.getByTestId('virtEntityTypeahed-menu__empty');
  }

  recentlyVisitedAgentItems() {
    return cy.getByTestId('agentsPage-searchTab-visitedAgent-item');
  }

  recentlyVisited() {
    cy.get('#app_wrapper').then(($el) => {
      if ($el.text().includes('Recently Visited')) {
        return this.recentlyVisitedAgentItems();
      }
      return false;
    });
  }

  agentNameLabel() {
    return cy.getByTestId('agent-insights-name');
  }

  medianCaseOpenTimeLabel() {
    return cy.getByTestId('agent-insights-median-case-open-time-label');
  }

  medianCaseOpenTimeValue() {
    return cy.getByTestId('agent-insights-median-case-open-time-value');
  }

  medianResponseTimeLabel() {
    return cy.getByTestId('agent-insights-median-response-time-label');
  }

  medianResponseTimeValue() {
    return cy.getByTestId('agent-insights-median-response-time-value');
  }

  medianConversationCountLabel() {
    return cy.getByTestId('agent-insights-median-conversation-count-label');
  }

  medianConversationCountValue() {
    return cy.getByTestId('agent-insights-median-conversation-count-value');
  }

  agentInsightsOutOfOfficeWidget() {
    return cy.getByTestId('agent-insights-awayWidget-container');
  }

  agentInsightsAssignmentHours() {
    return cy.getByTestId('agentsPage-agentInfo-container').contains('Assignment Hours');
  }

  agentInsightsFavoriteButton() {
    return cy.getByTestId('agentsPage-agentInfo-favoriteAgent-starBtn');
  }

  filterByType(type) {
    cy.getByTestId(`animated-checkbox-default-group-${type}-id`).then(($el) => {
      cy.wrap($el)
        .invoke('attr', 'data-status')
        .then((status) => {
          if (status === 'unchecked') {
            cy.wrap($el).click({ force: true });
            cy.waitForLoaders();
          }
        });
    });
  }

  backButton() {
    return cy.get('#agent-insights-toolbar');
  }

  shiftAssignmentModal() {
    return cy.getByTestId('common-modal-message');
  }

  shiftCheckbox(shiftName) {
    return cy.contains('[data-testid=common-checkbox--label]', shiftName).find('input');
  }

  editAssignmentHours() {
    return cy.getByTestId('edit-shifts-btn');
  }

  assignThisAgentButton() {
    return cy.getByTestId('assign-this-agent-btn');
  }

  shiftPopupCalendarLink(shiftName) {
    return cy.getByTestId(`agentAssignmentCalendar-shiftDetails-popup-${shiftName}`).find('a').first();
  }

  eventReasonPill(reason) {
    return cy.getByTestId('common-pill-label').parent().contains(reason);
  }

  eventDetailTextArea() {
    return cy.contains('Details').siblings('textarea');
  }

  eventTooltip() {
    return cy.get('#future-event-tooltip');
  }

  OOOStatus() {
    return cy.getByTestId('common-OOOStatusTag-container');
  }

  caseDetails() {
    return cy.getByTestId('agentPage-content--content');
  }

  agentInsightsOpenCaseList() {
    return cy.getByTestId('common-caseList-sideListItem');
  }

  agentInsightsCaseSortDropdown() {
    return cy.getByTestId('global-sortableCaseList-dropdown');
  }

  agentInsightsCaseSortOrderButton() {
    return cy.getByTestId('global-sortableCaseList-orderIcon');
  }

  // TODO data-testid requested via SLC-36071.
  caseDistributionChartHeader() {
    return cy.get('._31hv_KFDUP2lOSvELxChKF');
  }

  overviewTabStatusChartTitle() {
    return cy.getByTestId('chartWrapper-null__sl_status');
  }

  overviewTabPriorityChartTitle() {
    return cy.getByTestId('chartWrapper-null__sl_priority');
  }

  closedCaseTabComponentChartWrapper() {
    return cy.getByTestId('chartWrapper-agents_global_charts__sl_component_c');
  }

  openCaseListItemSentimentScoreLabel() {
    return cy.getByTestId('consolePage-tabs-case-card-sentiment-score');
  }

  openCaseListItemAttentionScoreLabel() {
    return cy.getByTestId('consolePage-tabs-case-card-need-attention-score');
  }

  openCaseListItemTimeLabel() {
    return cy.get('[data-testid=common-caseList-defaultItem-cardSubject] + span');
  }

  closedCaseTabStatusChartWrapper() {
    return cy.getByTestId('chartWrapper-agents_global_charts__sl_status');
  }

  closedCaseTabPriorityChartWrapper() {
    return cy.getByTestId('chartWrapper-agents_global_charts__sl_priority');
  }

  closedCaseTabResponseTimeChartWrapper() {
    return cy.getByTestId('chartWrapper-agents_global_charts__sl_response_time_chart');
  }

  closedCaseTabCaseAgeChartWrapper() {
    return cy.getByTestId('chartWrapper-agents_global_charts__sl_case_open_time_chart');
  }

  engineeringIssuesChartsContainer() {
    return cy.getByTestId('agentPage-engIssues--charts__container');
  }

  engineeringIssuesEntitiesChartWrapper() {
    return cy.getByTestId('agentPage-engIssues--entities__chartwrapper_content');
  }

  engineeringIssuesStatusChartWrapper() {
    return cy.getByTestId('chartWrapper-agent_engineering_issues__overview__sl_status');
  }

  engineeringIssuesPriorityChartWrapper() {
    return cy.getByTestId('chartWrapper-agent_engineering_issues__overview__sl_priority');
  }

  agentNeedAttentionTabCaseCount() {
    return cy.getByTestId('consolePage-tabsSlider-tab-count-Need_Attention');
  }

  // highchart classes most likely will not change and therefore do not need data-testids
  remainingComponents() {
    return cy.getByTestId('chartWrapper-agents_global_charts__sl_component_c').find('.highcharts-drilldown-point');
  }

  remainingComponentsBackButton() {
    return cy.getByTestId('chartWrapper-agents_global_charts__sl_component_c').contains('Back');
  }

  OOOAllDayCheckBox() {
    return cy.getByTestId('animated-checkbox-default-group-All Day-id');
  }

  sortCasesBy(optionName) {
    this.agentInsightsCaseSortDropdown()
      .invoke('text')
      .then((currentVal) => {
        if (currentVal !== optionName) {
          this.agentInsightsCaseSortDropdown().click();
          cy.contains('[data-testid^=common-dropdown-sl]', optionName).click();
        }
      });
  }

  switchSortDirection(direction = 'desc') {
    this.agentInsightsCaseSortOrderButton()
      .find('svg')
      .invoke('attr', 'data-status')
      .then((currentDirection) => {
        if (currentDirection !== direction) this.agentInsightsCaseSortOrderButton().click();
      });
  }

  performanceTabWelcomePageVisibilityCheck() {
    cy.get('body').then((body) => {
      const getStartedButton = '[data-testid=welcomeScreen-actions]';
      if (body.find(getStartedButton).length) {
        cy.get(getStartedButton).should('be.visible').click();
      }
    });
  }
}

export const agentInsights = new AgentInsightsPageObject();
