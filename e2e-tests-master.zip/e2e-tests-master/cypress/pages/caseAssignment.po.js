class CaseAssignment {
  unassignedTab() {
    return cy.getByTestId('caseAssignment-sideListTab-unassigned-tab');
  }

  assignedTodayTab() {
    return cy.getByTestId('caseAssignment-sideListTab-assigned_today-tab');
  }

  unassignedTabCountLabel() {
    return cy.get('[data-testid=caseAssignment-sideListTab-unassigned-tab] > span:nth-child(1)');
  }

  assignedTodayTabCountLabel() {
    return cy.get('[data-testid=caseAssignment-sideListTab-assigned_today-tab] > span:nth-child(1)');
  }

  unassignedTabSortByDropdown() {
    return cy.getByTestId('caseAssignmentPage-caseAssignmentTab-unassigned-sortTrigger');
  }

  assignedTodayTabSortByDropdown() {
    return cy.getByTestId('caseAssignmentPage-caseAssignmentTab-assignedToday-sortTrigger');
  }

  unassignedTabZeroStateLabel() {
    return cy.contains('No cases found, please check your filter!');
  }

  assignedTodayTabZeroStateLabel() {
    return cy.contains('You have not assigned any cases today.');
  }

  caseListItemCard() {
    return cy.getByTestId('caseAssignmentPage-caseList-sideListItem');
  }

  caseListCardTitleLabel() {
    return cy.getByTestId('caseAssignmentPage-caseList-defaultItem-cardTitle');
  }

  caseListCaseIdLabel() {
    return cy.getByTestId('caseAssignmentPage-caseList-defaultItem-cardId');
  }

  caseListCaseSubjectLabel() {
    return cy.getByTestId('caseAssignmentPage-caseList-defaultItem-cardSubject');
  }

  caseListCasePriorityLabel() {
    return cy.getByTestId('caseAssignmentPage-caseListItem-priorityLabel');
  }

  summaryCustomerNameLabel() {
    return cy.getByTestId('supportHub-caseCustomer-CustomerName');
  }

  summaryCaseIdLabel() {
    return cy.getByTestId('supportHub-caseSummary-id');
  }

  summaryCaseSubjectLabel() {
    return cy.getByTestId('supportHub-caseSummary-subject');
  }

  summaryCasePriorityLabel() {
    return cy.getByTestId('common-priorityLabel');
  }

  // TODO: For data-testid, refer SLC-35636
  caseAssignmentFilterButton() {
    return cy.get('._2SFMXmNI7TUL7rr7_KCdYV');
  }

  caseAssignmentFilterApplyButton() {
    return cy.getByTestId('filters-global-scoreFilters-Apply_scope-btn');
  }

  caseAssignmentFilterResetAllButotn() {
    return cy.getByTestId('filters-global-scoreFilters-resetBtn');
  }
}

export const caseAssignment = new CaseAssignment();
