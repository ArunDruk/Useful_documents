class Metrics {
  addChartButton() {
    return cy.contains('[data-testid^="metrics-addChartBtn-"]', 'Add a chart');
  }

  escalationSubTab() {
    return cy.getByTestId('tabNav__escalations');
  }

  backlogSubTab() {
    return cy.getByTestId(`tabNav__backlog`);
  }

  caseActivitySubTab() {
    return cy.getByTestId('tabNav__caseActivity');
  }

  firstResponseSubTab() {
    return cy.getByTestId('tabNav__firstResponse');
  }

  followUpSubTab() {
    return cy.getByTestId('tabNav__followUp');
  }

  caseResolutionSubTab() {
    return cy.getByTestId('tabNav__caseResolution');
  }

  // SLC-34201 for data-testid request
  newEscalationsCount() {
    return cy.get('._3YAA-rigu92i_SoUJ9bwul');
  }

  // TODO: waiting for data test-id SLC-31011
  escalationsTitle() {
    return cy.get('._6IHyDIYt-51re4px80s0s');
  }

  // TODO: waiting for data test-id SLC-34201
  responseTimeDefaultChartTitle() {
    return cy.get('._1tr0PUtUB0DEnKe04b48Qf');
  }

  activeEscalationCountLabel() {
    return cy.getByTestId('metrics-metricsDetails-mainChart-activeEscalationCount');
  }

  activeEscalationPercantageLabel() {
    return cy.getByTestId('metrics-metricsDetails-mainChart-activeEscalationPercentage');
  }

  opsMetricsContainer() {
    return cy.getByTestId('operationalMetrics-tabs');
  }

  opsMetricsSentimentsCount() {
    return cy.getByTestId('ops-customer-exp-sentiments-count');
  }

  chartBackground() {
    return cy.get('.highcharts-background');
  }

  opsMetricsDownloadButton() {
    return cy.getByTestId('ops-charts-settings-buttons-download');
  }

  opsMetricsThreeDotButton() {
    return cy.getByTestId('ops-charts-settings-buttons-dots');
  }

  opsMetricsDropdownValue() {
    return cy.getByTestId('common-dropdown-value');
  }
}

export const metrics = new Metrics();
