class ExperientialMetrics {
  expMetricsCasesShownText() {
    return cy.getByTestId('ops-customer-exp-sentiments-count');
  }

  sentimentSignalsDropdownTrigger() {
    return cy.getByTestId('Sentiment Signals--dropdown--trigger');
  }

  sentimentSignalsCountLabel() {
    return cy.getByTestId('ops-customer-exp-sentiments-count');
  }

  experientialMetricsTabs() {
    return cy.getByTestId('experientialMetrics-tabs');
  }

  addChartButton() {
    return cy.getByTestId('metrics-addChartBtn-CX');
  }

  addChartPopupSentimentScoreOption() {
    return cy.getByTestId('metrics-metricsConfigurableCharts-chartEditor-chooseChartType-sentiment_score');
  }

  addChartPopupAttentionScoreOption() {
    return cy.getByTestId('metrics-metricsConfigurableCharts-chartEditor-chooseChartType-attention_score');
  }

  addChartPopupSentimentSignalsOption() {
    return cy.getByTestId('metrics-metricsConfigurableCharts-chartEditor-chooseChartType-sentiment_signals');
  }

  addChartPopupCustomerSentimentScoreOption() {
    return cy.getByTestId('metrics-metricsConfigurableCharts-chartEditor-chooseChartType-customer_sentiment_score');
  }

  addChartPopupCSATScoreOption() {
    return cy.getByTestId('metrics-metricsConfigurableCharts-chartEditor-chooseChartType-csat_score');
  }

  addChartPopupNPSScoreOption() {
    return cy.getByTestId('metrics-metricsConfigurableCharts-chartEditor-chooseChartType-nps_score');
  }

  addChartPopupVerticalBarOption() {
    return cy.getByTestId('metrics-metricsConfigurableCharts-chartEditor-vertical_bar');
  }

  addChartPopupTrendOption() {
    return cy.getByTestId('metrics-metricsConfigurableCharts-chartEditor-trendline');
  }

  addChartPopupAddButton() {
    return cy.getByTestId('metrics-metricsConfigurableCharts-chartEditor-addSubmitBtn');
  }

  addChartPopupCancelButton() {
    return cy.getByTestId('metrics-metricsConfigurableCharts-chartEditor-cancelBtn');
  }

  addChartPopup() {
    return cy.getByTestId('common-modal-message');
  }

  // Highchart locator class most likely won't change. Hence no need to create a data-testid
  experimentalCharts() {
    return cy.get('.highcharts-root');
  }

  chartCaseStatusDropdownTrigger(option) {
    return cy.getByTestId(`${option}--dropdown--trigger-btn`);
  }

  chartsDotMenu() {
    return cy.getByTestId('ops-charts-settings-buttons-dots');
  }

  chartDeleteButton() {
    return cy.get('[data-testid$=deleteChart--btn]');
  }

  clearCharts() {
    this.experimentalCharts().then(($charts) => {
      const initialChartCount = $charts.length;
      for (let index = 1; index < initialChartCount; index += 1) {
        this.chartsDotMenu().click();
        this.chartDeleteButton().first().click({ force: true });
      }
    });
  }

  addChartGroupByDropdownButton() {
    return cy.getByTestId('common-dropdown-btn');
  }

  addChartGroupByDropdownOption(option) {
    return cy.get(`[data-testid^=common-dropdown-sl_${option}]`);
  }

  chartHeader(headertext) {
    return cy.getByTestId('experientialMetrics-tabs').contains(headertext);
  }

  // TODO: data-testid request https://supportlogic.atlassian.net/browse/SLC-35438
  customerSentimentScoreVerticalBarsDropdownTrigger() {
    return cy.get('[class^=CustomerChart__CustomerSelectorWrapper]');
  }

  // TODO: data-testid request https://supportlogic.atlassian.net/browse/SLC-35438
  customerSentimentScoreTrendlineDropdownTrigger() {
    return cy.get('[class^=CustomerSelector__Trigger]');
  }

  chartGroupByDropdownOption(option) {
    if (option) {
      return cy.get(`[data-testid^='Sentiment Signals--dropdown--${option}']`);
    }
    return cy.get(`[data-testid^='Sentiment Signals--dropdown']`);
  }

  chartSignalSortButton() {
    return cy.getByTestId('common-buttonSwitcher-btn');
  }

  // Highchart locator class most likely won't change. Hence no need to create a data-testid
  chartLabels() {
    return cy.get('.highcharts-axis-labels');
  }

  chartBarPoints() {
    return cy.get('.highcharts-point');
  }

  editSentimentsButton() {
    return cy.getByTestId('Sentiment Signals--editSentiments--btn');
  }

  editSentimentsSaveButton() {
    return cy.getByTestId('experientialMetrics-tabs').contains('Save');
  }

  sentimentLabel(sentiment) {
    return cy.get('svg[data-icon="check"]').parent().contains(sentiment);
  }

  customerExperienceSubTab() {
    return cy.getByTestId('tabNav__customerExperience');
  }

  sentimentsSubTab() {
    return cy.getByTestId('tabNav__sentiments');
  }

  // Includes value needs to be - Incoming, Outgoing, CaseNote
  sentimentIncludesCheckBox(value) {
    return cy.getByTestId(`sentiments--message-type-filter--is${value}`);
  }

  // type needs to be - negative, postive, product feedback
  sentimentChartLegentType(type) {
    return cy.getByTestId(`sentiments--chart-legend-type--${type}`);
  }

  // TODO: data-testid request SLC-35614
  addAllSentiments() {
    this.chartsDotMenu().click();
    this.editSentimentsButton().click();
    cy.get('.C9MF_2BIv_XMmQ4PWyyua').each(($el) => {
      if ($el.find('svg').length === 0) {
        cy.wrap($el).click();
      }
    });
    this.editSentimentsSaveButton().click();
  }

  customerFilterCheckbox(filter) {
    return cy.get(`[data-testid*="${filter}"]`);
  }

  customerFilterTextInputField() {
    return cy.getByTestId('common-scrollList').find('input[type=text]');
  }

  customerFilterSearchButton() {
    return cy.getByTestId('common-scrollList').contains('Filter search');
  }

  customerFilterSearchResult(name) {
    return cy.contains(name);
  }
}

export const experientialMetrics = new ExperientialMetrics();
