const randId = () => Cypress._.random(0, 1e6);

// TODO data-testid requested via SLC-33429 & SLC-30884
export class AlertsPageObject {
  alertBaseTextContainerFirst() {
    return cy.get('.styles__Container-sc-1twcur-0 > :nth-child(1)');
  }

  alertBaseTextContainerSecond() {
    return cy.get('.styles__Container-sc-1twcur-0 > :nth-child(2)');
  }

  alertConditionDropDown() {
    return cy.get('[data-testid^="alert--AlertCondition--option__"]');
    // .styles__Trigger-sc-b3idgl-0'
  }

  alertNegativeSentimentFirstSignalTitle() {
    return cy.get('.styles__Item-sc-1497swj-1:nth-child(1)');
  }

  alertNegativeSentimentSecondSignalTitle() {
    return cy.get('.styles__Item-sc-1497swj-1:nth-child(2)');
  }

  alertSentimentContainerText() {
    return cy.get('[class*=ConditionItem]');
  }

  alertTitleNameLabel() {
    return cy.getByTestId('alertPage-editableText-name');
  }

  alertTitleNameInput() {
    return cy.getByTestId('alertPage-editableText-input');
  }

  alertRemoveIcon() {
    return cy.get('.styles__RemoveButton-sc-1n5g2rt-2 > svg > path');
  }

  alertTitleHeader() {
    return cy.get('.styles__Header-sc-p9lorn-0');
  }

  deleteAlertButton() {
    return cy.getByTestId('alert--DeleteAlertButton');
  }

  deletePopupCancelText() {
    return cy.contains('Cancel');
  }

  deletePopupDeleteText() {
    return cy.contains('Delete');
  }

  createNewAlertButton() {
    return cy.getByTestId('alert--NewAlertButton');
  }

  // TODO data-testid requested via SLC-36037.
  standardAlertTypeBoxOption() {
    return cy.get('[class^="styles__AlertTypeBox-sc-"]').contains('Standard Alert');
  }

  // TODO data-testid requested via SLC-36037.
  keywordAlertTypeBoxOption() {
    return cy.get('[class^="styles__AlertTypeBox-sc-"]').contains('Keyword Alert');
  }

  // TODO data-testid requested via SLC-36037.
  keywordsExpandTriggerHeader() {
    return cy.get('[class^="styles__KeywordsContainer-sc"]').contains('Keywords');
  }

  // TODO data-testid requested via SLC-36037.
  keywordAlertCanvasEmptyContainer() {
    return cy.get('[class^="styles__CanvasEmpty-sc"]');
  }

  // TODO data-testid requested via SLC-36037.
  keywordsExpandTriggerInput() {
    return cy.get('[class^="styles__MainInput-sc"]');
  }

  // TODO data-testid requested via SLC-36037.
  keywordsExpandTriggerNoResultSpace() {
    return cy.get('[class^="styles__NoResult-sc"]');
  }

  // TODO data-testid requested via SLC-36037.
  keywordsExpandTriggerKeywordsLists() {
    return cy.get('[class^="styles__Keyword-sc"]');
  }

  // TODO data-testid requested via SLC-36037.
  keywordsExpandCanvasPopupHeader() {
    return cy.get('[class^="styles__CanvasPopupHeader-sc"]');
  }

  alertTypeBoxCreateButton() {
    return cy.getByTestId('toolkit-dialog-submit-btn').contains('Create');
  }

  duplicateAlertButton() {
    return cy.getByTestId('alert--DuplicateAlertButton');
  }

  mouseHoverTooltip() {
    return cy.get('[role="tooltip"]');
  }

  alertUnmuteTextContainer() {
    return cy.get('.styles__UnmuteDisabledMessage-sc-p9lorn-3');
  }

  alertMuteButton() {
    return cy.getByTestId('alert--muteToggle-muteAlert');
  }

  alertUnMuteButton() {
    return cy.getByTestId('alert--muteToggle-unMuteAlert');
  }

  alertConditionsHeaderTitle() {
    return cy.getByTestId('alert--AlertCondition--case_title');
    // cy.get('.styles__Title-sc-11fd6b5-4');
  }

  keywordAlertConditionsHeaderTitle() {
    return cy.getByTestId('alert--AlertCondition--alert_trigger_title');
  }

  customFieldsHeaderTitle() {
    return cy.get('.styles__SectionTitle-sc-11fd6b5-6');
  }

  alertExpandButton() {
    return cy.getByTestId('alert--AlertExpandTrigger');
  }

  alertLastCaseActivityDropDown() {
    return cy.getByTestId('alert--AlertCondition--option__').contains('Last Case Activity');
  }

  lastCaseActivityInboundRadio() {
    return cy.getByTestId('alert--AlertCondition--option_label__last_case_activity-item-btn_radio').eq(0);
  }

  lastCaseActivityOutboundRadio() {
    return cy.getByTestId('alert--AlertCondition--option_label__last_case_activity-item-btn_radio').eq(1);
  }

  alertErrorContainer() {
    return cy.get('.styles__Error-sc-16fejab-2');
  }

  muteContainerText() {
    return cy.get('._2YPKr3PldBpdUntv57Pao5');
  }

  notificationMethodFirstDropDown() {
    return cy.get('[class^=styles__MethodIcon]').parent().eq(0);
  }

  notificationMethodSecondDropDown() {
    return cy.get('[class^=styles__MethodIcon]').parent().eq(1);
  }

  notificationMethodDropDownEmailCheckbox() {
    return cy.getByTestId('alert-notification-methods-email');
  }

  notificationMethodDropDownSlackCheckbox() {
    return cy.getByTestId('alert-notification-methods-slack');
  }

  slackContainerLabel() {
    return cy.get('[class^=styles__SignInContainer]');
  }

  slackContainerTitle() {
    return cy.get('._2mbKSuv68EQx-G-zxoryzF');
  }

  slackContainerSignInTitle() {
    return cy.get('._3jhAiOquu7Y8wU5V0h_l0d > span');
  }

  slackContainerErrorTitle() {
    return cy.get('[class^=styles__WorkspaceError]');
  }

  notificationMethodFirstCheckbox() {
    return cy.get('[data-testid="notify-me-checkbox--label"] ._3VXjSok8ELo1WXxrRuvs0x');
  }

  notificationMethodSecondCheckbox() {
    return cy.get('._3VXjSok8ELo1WXxrRuvs0x');
  }

  notificationMethodThirdCheckbox() {
    return cy.get('._3VXjSok8ELo1WXxrRuvs0x');
  }

  notificationMethodFirstCheckboxStatus() {
    return cy.get('._3VXjSok8ELo1WXxrRuvs0x').eq(1);
  }

  notificationMethodSecondCheckboxStatus() {
    return cy.get('._3VXjSok8ELo1WXxrRuvs0x').eq(2);
  }

  notificationMethodThirdCheckboxStatus() {
    return cy.get('._3VXjSok8ELo1WXxrRuvs0x').eq(3);
  }

  notificationMethodSecondMailContainer() {
    return cy.get('._1PEsvNav9c1xoClF9kSNXg > ._1RZFLstJ_MSq2-Riva77G6');
  }

  notificationMethodSecondMailContainerFirstMail() {
    return cy.get(':nth-child(1) > ._1eKFoba8heHFfCGAVH8U8Z > ._1PEsvNav9c1xoClF9kSNXg > ._1RZFLstJ_MSq2-Riva77G6');
  }

  notificationMethodSecondMailContainerSecondMail() {
    return cy.get(':nth-child(2) > ._1eKFoba8heHFfCGAVH8U8Z > ._1PEsvNav9c1xoClF9kSNXg > ._1RZFLstJ_MSq2-Riva77G6');
  }

  notificationMethodMailRemoveIcon() {
    return cy.getByTestId('common-remove-button').eq(0);
  }

  notificationMethodSecondMailInput() {
    return cy.getByTestId('supportHub-caseShare-shareWithInput');
  }

  notificationMethodMailSuggestionDropDown() {
    return cy.get('._10nKQks69bCua02jFQG0hX');
  }

  notificationMethodSecondDropDownCheckbox() {
    return cy.get('._3VXjSok8ELo1WXxrRuvs0x');
  }

  alertConditionsundoButton() {
    return cy.getByTestId('alert-condition-undoButton');
  }

  alertNotificationsundoButton() {
    return cy.getByTestId('alert-notification-undoButton');
  }

  payloadDropDownTitle() {
    return cy.get('.styles__TitleTrigger-sc-1axly1l-5');
  }

  payloadInputContainer() {
    return cy.get('.Select__placeholder.css-1wa3eu0-placeholder');
  }

  payloadInput() {
    return cy.get('.Select__control.css-yk16xz-control');
  }

  payloadSuggestionDropDown() {
    return cy.get('.Select__menu.css-26l3qy-menu');
  }

  payloadContainerText() {
    return cy.get('.styles__Container-sc-yzpz5u-1');
  }

  payloadContainerRemoveIconMouseHover() {
    return cy.get('.styles__RemoveWrapper-sc-yzpz5u-0 > .styles__Button-sc-oqvoif-0');
  }

  payloadContainerRemoveIcon() {
    return cy.getByTestId('common-remove-button').eq(1);
  }

  payloadUndoButton() {
    return cy.getByTestId('alert-message-undoButton');
  }

  alertsNavigationList() {
    return cy.getByTestId('alert--AlertsNavigationList--item');
  }

  alertsNavigationListUnmuteButton() {
    return cy.getByTestId('alert-alertsNavigationList-unMuteButton');
  }

  alertsNavigationListMuteButton() {
    return cy.getByTestId('alert-alertsNavigationList-muteButton');
  }

  alertsZeroStateCreateButton() {
    return cy.getByTestId('alert--CreateNewAlert');
  }

  alertConditionDropdownOptionLabel(signalOption) {
    const formattedOptionName = signalOption.toLowerCase().replaceAll(' ', '_');
    return cy.getByTestId(`alert--AlertCondition--option__${formattedOptionName}-item-label`);
  }

  // TODO data-testid requested via SLC-30884.
  createNewAlert() {
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    this.createNewAlertButton().should('have.text', 'New Alert').click();
    this.standardAlertTypeBoxOption().click();
    this.alertTypeBoxCreateButton().click();
    cy.waitForLoaders();
  }

  // TODO data-testid requested via SLC-30884.
  deleteAlert() {
    this.deleteAlertButton().click({ force: true });
    this.deletePopupDeleteText().click({ force: true });
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(2000);
  }

  // TODO data-testid requested via SLC-30884.
  createAndDeleteAlert() {
    this.createNewAlert();
    // eslint-disable-next-line cypress/no-assigning-return-values
    const titleName = cy.getByTestId('alertPage-editableText-name').invoke('text');
    this.deleteAlert();
    this.alertTitleNameLabel().should('not.eq', titleName);
  }

  // TODO data-testid requested via SLC-30884.
  addingEmailRecipientAlert() {
    const alertName = `${randId()}`;
    this.createNewAlert();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(500);
    this.alertTitleNameLabel().dblclick();
    this.alertTitleNameInput().type(alertName);
    this.alertTitleHeader().click();
    this.notificationMethodSecondMailContainer().should('be.visible').and('have.text', 'qa.automation@supportlogic.io');
    this.notificationMethodSecondMailInput().type('qa.automation.prod2@');
    this.notificationMethodMailSuggestionDropDown().click({ force: true });
    this.notificationMethodSecondMailContainerFirstMail().should('be.visible').and('have.text', 'qa.automation@supportlogic.io');
    this.notificationMethodSecondMailContainerSecondMail().should('be.visible').and('have.text', 'qa.automation.prod2@supportlogic.io');
    this.deleteAlert();
  }

  createNewKeywordAlert() {
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    this.createNewAlertButton().should('have.text', 'New Alert').click();
    this.keywordAlertTypeBoxOption().click();
    this.alertTypeBoxCreateButton().click();
    cy.waitForLoaders();
  }
}

export const alertsPage = new AlertsPageObject();
