class HealthScore {
  healthScoreBadgeIcon() {
    return cy.getByTestId('ahs-badge');
  }

  // waiting for data-testid SLC-31066
  healthScoreTitleHeader() {
    return cy.get('[class^="styles__Header-sc-"]');
  }

  // TODO data-test id requested via SLC-30847
  feedbackButton() {
    return cy.get('[class^="AHSFeedback__CTAButton"]');
  }

  // TODO data-test id requested via SLC-30847
  feedbackIconTooltipText() {
    return cy.get('[class^=AHSFeedback__TooltipContent]');
  }

  feedbackFormPopup() {
    return cy.getByTestId('ahs-feedback-form-wrapper');
  }

  feedbackFormQuestionLabel() {
    return cy.getByTestId('ahs-feedback-form-questionGroup-2-question');
  }

  // TODO data-test id requested via SLC-30847
  feedbackFormRadioButtonTextLabel() {
    return cy.get('[class^="AHSFeedbackForm__TextLabel"]');
  }

  feedbackFormEscalatedQuestionLabel() {
    return cy.getByTestId('ahs-feedback-form-questionGroup-2');
  }

  feedbackFormEscalatedYesRadioButton() {
    return cy.getByTestId('ahs-feedback-form-questionGroup-2-option--yes');
  }

  feedbackFormEscalatedNoRadioButton() {
    return cy.getByTestId('ahs-feedback-form-questionGroup-2-option--no');
  }

  feedbackFormEscalatedNotSureRadioButton() {
    return cy.getByTestId('ahs-feedback-form-questionGroup-2-option--not_sure');
  }

  feedbackFormCommentBoxInput() {
    return cy.getByTestId('ahs-feedback-form-commentBox');
  }

  // TODO data-test id requested via SLC-30847
  feedbackActionTextLabel() {
    return cy.get('[class^="AHSFeedback__ActionFeedbexText"]');
  }

  feedbackHealthScoreGoodRadioButton() {
    return cy.getByTestId('ahs-feedback-form-questionGroup-1-option--good');
  }

  feedbackHealthScoreFairRadioButton() {
    return cy.getByTestId('ahs-feedback-form-questionGroup-1-option--fair');
  }

  feedbackHealthScoreBadRadioButton() {
    return cy.getByTestId('ahs-feedback-form-questionGroup-1-option--bad');
  }

  feedbackFormSaveButton() {
    return cy.getByTestId('ahs-feedback-form-action--save');
  }

  feedbackFormCancelButton() {
    return cy.getByTestId('ahs-feedback-form-action--cancel');
  }

  healthScoreCaseList() {
    return cy.getByTestId('ahs-caseList-item');
  }

  healthScoreShareIcon() {
    return cy.get('#ahs-toolbar [data-testid="common-button"]');
  }

  ahsShareFormBaseContainer() {
    return cy.get('#ahs-share-form');
  }

  ahsShareImageCheckbox() {
    return cy.get('[data-testid="common-checkbox--label"] input').eq(0);
  }

  ahsShareImagePreview() {
    return cy.get('img[alt="Preview"]');
  }

  ahsShareHealthScoreLinkCheckbox() {
    return cy.get('[data-testid="common-checkbox--label"] input').eq(1);
  }

  ahsShareEmailInput() {
    return cy.getByTestId('supportHub-caseShare-shareWithInput');
  }

  ahsShareMessageLabel() {
    return cy.contains('Add a message');
  }

  // TODO data-test id requested via SLC-30847
  ahsShareMessageTextArea() {
    return cy.get('._1j6GKIITUuN_TTUEOkhkoq');
  }

  ahsShareButton() {
    return cy.getByTestId('customer-insights.share-ahs.submit-button');
  }

  ahsCaseListHeaderTitle() {
    return cy.getByTestId('ahs-caseList-header-title');
  }

  ahsEscalationsStatusCard() {
    return cy.getByTestId('ahs-statsCard-content-escalations');
  }

  ahsEscalationsStatusCardValueLabel() {
    return cy.getByTestId('ahs-statsCardSection-value-wrapper-escalations');
  }

  ahsEscalationsStatusTextLabel() {
    return cy.getByTestId('ahs-statsCardSection-text-wrapper-escalations');
  }

  ahsCaseListResetShowAllButton() {
    return cy.getByTestId('ahs-caseList-header-actions--reset');
  }

  ahsCaseAgeStatusCard() {
    return cy.getByTestId('ahs-statsCard-wrapper-support_quality');
  }

  ahsCaseAgeStatusCardValueLabel() {
    return cy.getByTestId('ahs-statsCardSection-value-stripe-median-case-closure-support_quality');
  }

  ahsCaseAgeStatusCardDaysLabel() {
    return cy.getByTestId('ahs-statsCardSection-value-stripe-median-case-closure-value-support_quality');
  }

  ahsCaseAgeTrendsTextLabel() {
    return cy.getByTestId('ahs-statsCardSection-trend-text-support_quality');
  }

  ahsCaseSentimentStatusCard() {
    return cy.getByTestId('ahs-statsCard-wrapper-case_sentiment');
  }

  ahsCaseSentimentStatusCardContent() {
    return cy.getByTestId('ahs-statsCard-content-case_sentiment');
  }

  ahsCaseSentimentTrendsTextLabel() {
    return cy.getByTestId('ahs-statsCardSection-trend-text-case_sentiment');
  }

  ahsCaseActivityStatusCard() {
    return cy.getByTestId('ahs-statsCard-wrapper-account_activity');
  }

  ahsCaseActivityChart() {
    return cy.getByTestId('ahs-statsCardSection-chart-wrapper-account_activity');
  }

  ahsCaseActivityTrendsTextLabel() {
    return cy.getByTestId('ahs-statsCardSection-trend-text-account_activity');
  }

  ahsEngineeringIssuesCard() {
    return cy.getByTestId('ahs-statsCard-wrapper-engineering_issues');
  }

  ahsEngineeringIssuesChart() {
    return cy.getByTestId('ahs-statsCardSection-chart-wrapper-engineering_issues');
  }

  ahsEngineeringIssuesTrendsTextLabel() {
    return cy.getByTestId('ahs-statsCardSection-trend-text-engineering_issues');
  }
}

export const healthScore = new HealthScore();
