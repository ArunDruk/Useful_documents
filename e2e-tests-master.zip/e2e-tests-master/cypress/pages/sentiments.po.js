class Sentiments {
  headerTicketCountLabel() {
    return cy.getByTestId('sentimentsPage-headerKPI-ticketCount');
  }

  commonIncludeFilterButton(messageType) {
    const formattedMsgType = messageType.replace(' messages', '').replace(' Notes', 'Note');
    return cy.getByTestId(`sentiments--message-type-filter--is${formattedMsgType}`);
  }

  detectedSentimentCountLabel() {
    return cy.getByTestId('sentimentExplorer-chartTopHeader-dateInfo-sentimentsCount');
  }

  datePickerDropdown() {
    return cy.getByTestId('sentimentExplorer-datePickerTrigger');
  }

  endDateLabel() {
    return cy.getByTestId('sentimentExplorer-chartTopHeader-dateInfo-endDate');
  }

  datePickerApplyButton() {
    return cy.getByTestId('sentimentExplorer-startDayPicker-applyButton');
  }

  datePickerResetDaysButton() {
    return cy.getByTestId('sentimentExplorer-startDayPicker-resetDaysButton');
  }

  commonIndividualHeatMapTile() {
    return cy.get('[data-testid^=supportHub-sentimentChart]');
  }

  commonLegendFilterButton(sentimentType) {
    return cy.getByTestId(`sentiments--chart-legend-type--${sentimentType}`);
  }

  sentimentFilterLockTooltip() {
    return cy.getByTestId('sentimentExplorer-chartTopHeader-chartLegend-lockTooltip');
  }

  ticketDetailsTooltip() {
    return cy.getByTestId('supportHub-sentimentChart-highChartsTooltip-container');
  }

  ticketDetailsTooltipSentimentLabel() {
    return cy.get('[data-testid="supportHub-sentimentChart-highChartsTooltip-container"] ._1FqxTmFb6CJFh13YegX6Fb');
  }

  leftSliderButton() {
    return cy.getByTestId('sentimentExplorer-sentimentExplorerContent-leftSliderArrowBtn');
  }

  rightSliderButton() {
    return cy.getByTestId('sentimentExplorer-sentimentExplorerContent-rightSliderArrowBtn');
  }

  deltaChartInfoIcon() {
    return cy.getByTestId('sentimentExplorer-chartTopHeader-scoreTitle-deltaIcon');
  }

  infoIconTooltip() {
    return cy.getByTestId('sentimentExplorer-chartTopHeader-scoreTitle-deltaIcon-tooltip');
  }

  deltaChartTopDownArrow() {
    return cy.getByTestId('sentimentExplorer-sentimentScoreDelta-chartTimelineBtn');
  }

  deltaChartTopDownArrowTooltip() {
    return cy.getByTestId('sentimentExplorer-sentimentScoreDelta-chartTimelineBtn-tooltip');
  }

  getHeaderTicketCount() {
    return this.headerTicketCountLabel()
      .invoke('text')
      .then((ticketCounts) => parseInt(ticketCounts.replace(',', ''), 10));
  }

  getDetectedSentimentsCount() {
    return this.detectedSentimentCountLabel()
      .invoke('text')
      .then((sentimentsCount) => parseInt(sentimentsCount.replace(',', ''), 10));
  }

  getLegendFilterCount(sentimentType) {
    return this.commonLegendFilterButton(sentimentType)
      .invoke('text')
      .then((text) => parseInt(text.match(/\d+/)[0], 10));
  }

  isLegendFilterSelected(sentimentType) {
    return this.commonLegendFilterButton(sentimentType)
      .invoke('attr', 'data-status')
      .then((state) => state === 'checked');
  }

  selectLegendFilter(sentimentType) {
    this.isLegendFilterSelected(sentimentType).then((isSelected) => {
      if (!isSelected) this.commonLegendFilterButton(sentimentType).click();
    });
  }

  deselectLegendFilter(sentimentType) {
    this.isLegendFilterSelected(sentimentType).then((isSelected) => {
      if (isSelected) this.commonLegendFilterButton(sentimentType).click();
    });
  }

  isIncludeFilterChecked(filterType) {
    return this.commonIncludeFilterButton(filterType)
      .invoke('attr', 'data-status')
      .then((state) => state === 'checked');
  }

  checkIncludeFilter(filterType) {
    this.isIncludeFilterChecked(filterType).then((isChecked) => {
      if (!isChecked) this.commonIncludeFilterButton(filterType).click({ force: true });
    });
  }

  uncheckIncludeFilter(filterType) {
    this.isIncludeFilterChecked(filterType).then((isChecked) => {
      if (isChecked) this.commonIncludeFilterButton(filterType).click({ force: true });
    });
  }
}

export const sentiments = new Sentiments();
