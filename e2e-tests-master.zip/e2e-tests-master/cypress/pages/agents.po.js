export class Agents {
  // Search Agents
  agentSearchInputField() {
    return cy.getByTestId('common__favoriteSearchBar__input');
  }

  agentSearchResultListItem() {
    return cy.getByTestId('global-searchBar-searchOption-item');
  }

  removeFavoriteAgentButton() {
    return cy.getByTestId('agentsPage-agentBacklog-removeFavoriteButton');
  }

  groupByDropDownTrigger() {
    return cy.getByTestId('agentsPage-agentBacklog-groupByDropown');
  }

  groupByDropdownOption(option) {
    return cy.get('#agent-filter-popover').contains(option);
  }

  // TODO data-testid request SLC-35297
  agentCaseGroupItems() {
    return cy.get('._2W6EYP3TWiCeq6Pe9dTSoY._1ZUbFai_GM-P62TMLcNJRY');
  }

  addFavoriteButton() {
    return cy.getByTestId('myAgentsPage-addFavorite-addButton');
  }

  agentList() {
    return cy.getByTestId('agentsPage-agentBacklog-agentName');
  }

  expandFilterButton() {
    return cy.getByTestId('virtEntityTypeahed-filters__button');
  }

  myAgentsSearchInputField() {
    return cy.getByTestId('agentFavoritesPage-favoriteAddInput-searchInput');
  }

  // TODO data-testid request SLC-36316.
  myAgentsAddeventButton() {
    return cy.get('._2HnhgHT5ZHvUWuedGct9w1');
  }

  myAgentsAddeventAwayDatePicker() {
    return cy.getByTestId('agentsPage-awayWidget-AwayDatePicker');
  }

  filterByType(type) {
    cy.getByTestId(`animated-checkbox-default-group-${type}-id`).then(($el) => {
      cy.wrap($el)
        .invoke('attr', 'data-status')
        .then((status) => {
          if (status === 'unchecked') {
            cy.wrap($el).click({ force: true });
            cy.waitForLoaders();
          }
        });
    });
  }

  openCases() {
    return cy.getByTestId('agentsPage-agentBacklog-mainData');
  }
}

export const agents = new Agents();
