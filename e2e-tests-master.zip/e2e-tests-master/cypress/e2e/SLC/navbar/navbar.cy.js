import { navBar } from '../../../pages';
import { hexToRGBA } from '../../../utils';

describe('Navbar', { tags: ['staging', 'prod'] }, () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit('/');

    navBar.expand();
  });

  /*
   * NOTE: Contact developer if/when background color changes in the future.
   *
   * Verify navbar container background color matches #2A2A2A
   */
  it('C858: should verify navbar background color', () => {
    navBar.baseContainer().should('have.css', 'background-color', 'rgb(42, 42, 42)');
  });

  /*
   * NOTE: Was unable to verify on-hover background color
   * TODO: (Anyone) Add steps to verify hover state background color
   *
   * NOTE: Contact developer selected state background color (or) opacity changes in the future.
   *
   * Fetch theme color from user profile api
   *
   * Click the first navbar module item
   * Verify that background color matches the theme color with a 19% opacity
   */
  it('C859: should verify selected and hover state', () => {
    cy.request('api/users/profile').then(({ body }) => {
      navBar.commonNavbarModuleItem().first().click();
      navBar.commonNavbarModuleItem().first().should('have.css', 'background-color', hexToRGBA(body?.dashboards?.support?.theme_color, 0.19));
    });
  });

  /*
   * Collapse the navbar by clicking the toggle button in the top-right corner of the navbar
   * Verify that the 'data-state' attribute value is 'collapsed'
   * Verify that the nav items do not contain text 'Escalations Board' (Could be any module name)
   *
   * Expand the navbar by clicking the toggle button in the top-right corner of the navbar
   * Verify that the 'data-state' attribute value is 'expanded'
   * Verify that the nav items contain text 'Escalations Board' (Could be any module name)
   */
  it('C860: should be collapsible/expandable', () => {
    navBar.navbarCollapseExpandButton().click();
    navBar.navbarCollapseExpandButton().should('have.attr', 'data-state', 'collapsed');
    navBar.commonNavbarModuleItem().should('not.contain.text', 'Escalations Board');

    navBar.navbarCollapseExpandButton().click();
    navBar.navbarCollapseExpandButton().should('have.attr', 'data-state', 'expanded');
    navBar.commonNavbarModuleItem().should('contain.text', 'Escalations Board');
  });
});
