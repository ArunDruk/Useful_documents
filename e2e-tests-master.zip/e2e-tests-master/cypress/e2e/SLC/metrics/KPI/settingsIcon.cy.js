import { kpiMetrics } from '../../../../pages';
import { urlHelpers } from '../../../../utils';

const metricsSectionData = [
  { cardTitle: 'Response Time', cardTestId: 'metrics-summaryCard-sla' },
  { cardTitle: 'Efficiency', cardTestId: 'metrics-summaryCard-efficiency' },
  // TODO: Update title to respect label settings
  { cardTitle: 'Customer Experience', cardTestId: 'metrics-summaryCard-customer_experience' },
];

describe('Metrics - Overview page', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.kpiMetrics);
    kpiMetrics.summaryCard().should('be.visible');
  });

  it('C541: should show settings icon tooltip', { tags: 'Metrics' }, () => {
    metricsSectionData.forEach((sectionCard, index) => {
      cy.getByTestId(sectionCard.cardTestId).realHover();

      kpiMetrics.settingsButton().eq(index).should('be.visible').trigger('mouseover');
      // eslint-disable-next-line cypress/no-unnecessary-waiting
      cy.wait(1000);

      // TODO: Get data-testid for settings icon tooltip
      kpiMetrics.settingsTooltip().eq(index).should('be.visible').and('have.text', `Edit ${sectionCard.cardTitle} targets (in Advanced Settings)`);
    });
  });

  it('C543: should load correct settings section on click', { tags: 'Metrics' }, () => {
    metricsSectionData.forEach((sectionCard, index) => {
      cy.getByTestId(sectionCard.cardTestId).realHover();

      // TODO: Get data-testid for overview card settings icon
      kpiMetrics
        .settingsButton()
        .eq(index)
        .should('be.visible')
        .then((settingsButton) => {
          cy.wrap(settingsButton).click();
          // verify URL matches the target link
          cy.url().should('include', settingsButton.attr('href'));
          // navigate to previous page in browser history
          cy.go('back');
        });
    });
  });
});
