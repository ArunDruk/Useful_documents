import { urlHelpers } from '../../../../utils';
import { datePicker, kpiMetrics } from '../../../../pages';

describe('KPI Metrics - Calendar Tests', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.kpiMetrics);
    cy.waitForLoaders();
  });

  /**
   * Regression C9224
   * - Get current Response Time Met Case count details
   * - Select calendar to last 3 months
   * - Get current Response Time Met Case count details and verify the count details are not same
   */
  it('C9224: KPI Metrics - Overview Page (Calendar)', { tags: ['Metrics', 'staging', 'prod'] }, () => {
    // set calendar to this month (if not already)
    datePicker.datePickerTrigger().then(($btn) => {
      if (!$btn.text().includes('This month')) {
        datePicker.selectAndApplyThisMonthRadioButton();
        cy.waitForLoaders();
      }
    });
    // get current count of Response Time
    kpiMetrics
      .summaryCard()
      .eq(0)
      .then((beforeCardDetails) => {
        const beforeCountText = beforeCardDetails.text().split('have met')[0];
        datePicker.datePickerTrigger().click();
        // change calendar to last 3 months
        datePicker.selectLastMonthWithOption(3);
        datePicker.datePickerTrigger().should('have.text', 'Last 3 months');
        cy.waitForLoaders();
        // get new metric count
        kpiMetrics
          .summaryCard()
          .eq(0)
          .then((afterCardDetails) => {
            expect(afterCardDetails.text().split('have met')[0]).not.equal(beforeCountText);
          });
      });
  });

  /**
   * Regression C9228
   * - Select calendar to this month if its not, and verify the calender picker selected value is This month
   * - Select calendar to last 3 months if its not, and verify the calender picker selected value is Last 3 months
   */
  it('C9228: KPI Metrics - Calendar Apply', { tags: ['Metrics', 'staging', 'prod'] }, () => {
    datePicker.datePickerTrigger().then(($btn) => {
      if (!$btn.text().includes('This month')) {
        datePicker.selectAndApplyThisMonthRadioButton();
        cy.waitForLoaders();
        datePicker.datePickerTrigger().should('have.text', 'This month');
      } else {
        datePicker.datePickerTrigger().click();
        // change calendar to last 3 months
        datePicker.selectLastMonthWithOption(3);
        datePicker.datePickerTrigger().should('have.text', 'Last 3 months');
      }
      cy.waitForLoaders();
      kpiMetrics.summaryCard().eq(0).should('not.contain', '0 cases');
    });
  });

  /**
   * Regression C9230
   * - Select calendar to this month if its not, and click cancel button verify the calender picker value is not updated
   * - Select calendar to last 3 months if its not, and click cancel button verify the calender picker value is not updated
   */
  it('C9230: KPI Metrics - Overview Page (Cancel)', { tags: ['Metrics', 'staging', 'prod'] }, () => {
    datePicker.datePickerTrigger().then(($btn) => {
      if (!$btn.text().includes('This month')) {
        datePicker.datePickerTrigger().click();
        datePicker.thisMonthRadioButton().click();
      } else {
        datePicker.datePickerTrigger().click();
        // change calendar to last 3 months
        datePicker.selectLastMonthWithOptionWithoutApply(3);
      }
      datePicker.cancelButton().click();
      cy.waitForLoaders();
      datePicker.datePickerTrigger().should('have.text', $btn.text());
    });
  });

  /*
    Open calendar widget from Operational Metrics page
    Scroll through months forward and back on both starting and ending calendars
   */
  it('C9226: KPI Metrics - Calendar Scroll', { tags: ['Operational Metrics', 'staging', 'prod'] }, () => {
    datePicker.datePickerTrigger().click();
    datePicker.lastMonthDropdown().click();
    datePicker.scrollThroughCalendar();
  });
});
