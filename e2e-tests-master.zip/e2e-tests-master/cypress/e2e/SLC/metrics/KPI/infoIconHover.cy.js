import { kpiMetrics } from '../../../../pages';
import { labelHelper, urlHelpers } from '../../../../utils';

const infoIconTestData = [
  {
    testrailId: 'C534',
    sectionName: 'Response Time',
    tooltipText: `This panel shows a breakdown of ${labelHelper.cases.toLowerCase()} that have met or missed the Response Time target.`,
  },
  {
    testrailId: 'C535',
    sectionName: 'Efficiency',
    tooltipText: `This panel shows how your ${labelHelper.agents.toLowerCase()} are performing based on different factors such as case conversation, responder, and case owner counts.`,
  },
  {
    testrailId: 'C536',
    sectionName: 'Customer Experience',
    tooltipText: `Know how your ${labelHelper.customers.toLowerCase()} are feeling with a view into your team’s CSAT, NPS, and Sentiment Scores.`,
  },
];

describe('Metrics - Overview page', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.kpiMetrics);
    kpiMetrics.summaryCard().should('be.visible');
  });

  infoIconTestData.forEach((infoIconData, index) =>
    it(`${infoIconData.testrailId}: should hover over ${infoIconData.sectionName} info icon`, () => {
      kpiMetrics.summaryCardInfoIcon().eq(index).should('be.visible').trigger('mouseover');
      kpiMetrics.summaryCardTooltip().should('be.visible');
      kpiMetrics.summaryCardTooltip().should((element) => {
        const expectedTooltipText = element
          .text()
          .replaceAll(/\s+|\n/g, ' ')
          .trim();
        expect(expectedTooltipText).to.equal(infoIconData.tooltipText);
      });
    })
  );
});
