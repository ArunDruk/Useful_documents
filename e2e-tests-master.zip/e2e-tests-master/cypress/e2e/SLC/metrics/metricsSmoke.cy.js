import { datePicker, experientialMetrics, metrics } from '../../../pages';
import { urlHelpers } from '../../../utils';

describe('Metrics - Smoke Tests', () => {
  beforeEach(() => {
    cy.loginByApi();
  });

  it('C545: Op Metrics - Efficiency (Default)', { tags: 'Metrics' }, () => {
    cy.visit(urlHelpers.operationalMetrics.escalations);
    cy.waitForLoaders();
    // Verify the Escalation count and percentage is displayed
    metrics.escalationsTitle().eq(0).should('have.text', 'Escalations');
    metrics.activeEscalationCountLabel().should('be.visible');
    metrics.activeEscalationPercantageLabel().should('be.visible');
    // Clicking on the Date range filter and select last month
    datePicker
      .datePickerTrigger()
      .invoke('text')
      .then((currentDateRange) => {
        if (currentDateRange !== 'Last month') {
          datePicker.datePickerTrigger().click();
          datePicker.lastMonthRadioButton().click();
          datePicker.lastMonthDropdownOption(1).click();
          datePicker.applyButton().click();
        }
        metrics
          .activeEscalationPercantageLabel()
          .eq(0)
          .invoke('text')
          .then((casePercentage) => {
            // Clicking on the Date range filter and select Year to Date
            datePicker.datePickerTrigger().click();
            datePicker.lastMonthRadioButton().click();
            datePicker.thisMonthRadioButton().click();
            datePicker.applyButton().click();
            cy.waitForLoaders();
            metrics
              .activeEscalationPercantageLabel()
              .eq(0)
              .invoke('text')
              .then((newCasePercentage) => {
                expect(newCasePercentage).not.equals(casePercentage);
              });
          });
      });
  });

  it('C553: Op Metrics - Customer Experience (Default)', { tags: 'Metrics' }, () => {
    cy.visit(urlHelpers.experientialMetrics.customerExperience);

    experientialMetrics.sentimentSignalsDropdownTrigger().should('be.visible');
    cy.contains('Sentiment Signals').should('be.visible');
    // Clicking on the Date range filter and select last month
    datePicker
      .datePickerTrigger()
      .invoke('text')
      .then((currentDateRange) => {
        if (currentDateRange !== 'Last month') {
          datePicker.datePickerTrigger().click();
          datePicker.lastMonthRadioButton().click();
          datePicker.lastMonthDropdownOption(1).click();
          datePicker.applyButton().click();
        }
        experientialMetrics
          .sentimentSignalsCountLabel()
          .eq(0)
          .invoke('text')
          .then((caseDetail) => {
            // Clicking on the Date range filter and select Year to Date
            datePicker.datePickerTrigger().click();
            datePicker.thisMonthRadioButton().click();
            datePicker.applyButton().click();
            // TODO: waiting for data test-id SLC-31011
            experientialMetrics
              .sentimentSignalsCountLabel()
              .eq(0)
              .invoke('text')
              .then((newCaseDetail) => {
                expect(newCaseDetail).not.equals(caseDetail);
              });
          });
      });
  });
});
