import { urlHelpers } from '../../../../utils';
import { experientialMetrics } from '../../../../pages';

describe('Experiential Metrics - Add Charts', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.experientialMetrics.home);
    experientialMetrics.clearCharts();
  });

  afterEach(() => {
    experientialMetrics.clearCharts();
  });

  /*
   *  Check the initial chart count
   *  Click the add chart button
   *  Select the attention score chart type
   *  Select the vertical bar option
   *  Verifty the attention score chart
   *  Verify the chart count
   */
  it('C124833: Customer Experience - Add Attention Score chart - Vertical Bar', { tags: ['Metrics', 'staging', 'prod'] }, () => {
    experientialMetrics.experimentalCharts().then(($charts) => {
      const initialChartCount = $charts.length;
      experientialMetrics.experientialMetricsTabs().should('contain', 'Sentiment Signals');
      experientialMetrics.addChartButton().click();
      experientialMetrics.addChartPopup().should('contain', 'Add a Customer Experience Chart');
      experientialMetrics.addChartPopupAttentionScoreOption().click();
      experientialMetrics.addChartPopupVerticalBarOption().click();
      experientialMetrics.addChartPopup().should('contain', 'Show “Attention Score“ by...(Optional)');
      experientialMetrics.addChartPopupAddButton().click();
      experientialMetrics.experimentalCharts().should('have.length', initialChartCount + 1);
      experientialMetrics.experimentalCharts().eq(1).should('contain', 'Attention Score').realHover();
      experientialMetrics.experimentalCharts().eq(1).parent().should('contain', 'This Period').and('contain', 'Previous Period');
      experientialMetrics.chartCaseStatusDropdownTrigger('Attention Score').should('have.text', 'Closed');
    });
  });

  /*
   *  Check the initial chart count
   *  Click the add chart button
   *  Select the attention score chart type
   *  Select the trendline option
   *  Verifty the attention score chart
   *  Verify the chart count
   */
  it('C124834: Customer Experience - Add Attention Score chart - Trendline', { tags: ['Metrics', 'staging', 'prod'] }, () => {
    experientialMetrics.experimentalCharts().then(($charts) => {
      const initialChartCount = $charts.length;
      experientialMetrics.experientialMetricsTabs().should('contain', 'Sentiment Signals');
      experientialMetrics.addChartButton().click();
      experientialMetrics.addChartPopup().should('contain', 'Add a Customer Experience Chart');
      experientialMetrics.addChartPopupAttentionScoreOption().click();
      experientialMetrics.addChartPopupTrendOption().click();
      experientialMetrics.addChartPopup().should('contain', 'Show “Attention Score“ by...(Optional)');
      experientialMetrics.addChartPopupAddButton().click();
      experientialMetrics.experimentalCharts().should('have.length', initialChartCount + 1);
      experientialMetrics.experimentalCharts().eq(1).parent().should('contain', 'Attention Score');
      experientialMetrics.chartCaseStatusDropdownTrigger('Attention Score').should('have.text', 'Closed');
    });
  });

  /*
   *  Check the initial chart count
   *  Click the add chart button
   *  Select the sentiment score chart type
   *  Select the vertical bar option
   *  Verifty the attention score chart
   *  Verify the chart count
   */
  it('C124838: Customer Experience - Add Sentiment Score chart - Vertical Bar', { tags: ['Metrics', 'staging', 'prod'] }, () => {
    experientialMetrics.experimentalCharts().then(($charts) => {
      const initialChartCount = $charts.length;
      experientialMetrics.experientialMetricsTabs().should('contain', 'Sentiment Signals');
      experientialMetrics.addChartButton().click();
      experientialMetrics.addChartPopup().should('contain', 'Add a Customer Experience Chart');
      experientialMetrics.addChartPopupSentimentScoreOption().click();
      experientialMetrics.addChartPopupVerticalBarOption().click();
      experientialMetrics.addChartPopup().should('contain', 'Show “Sentiment Score“ by...(Optional)');
      experientialMetrics.addChartPopupAddButton().click();
      experientialMetrics.experimentalCharts().should('have.length', initialChartCount + 1);
      experientialMetrics.experimentalCharts().eq(1).should('contain', 'Sentiment Score').realHover();
      experientialMetrics.experimentalCharts().eq(1).parent().should('contain', 'This Period').and('contain', 'Previous Period');
      experientialMetrics.chartCaseStatusDropdownTrigger('Sentiment Score').should('have.text', 'Closed');
    });
  });

  /*
   *  Check the initial chart count
   *  Click the add chart button
   *  Select the sentiment score chart type
   *  Select the trendline option
   *  Verifty the attention score chart
   *  Verify the chart count
   */
  it('C124839: Customer Experience - Add Sentiment Score chart - Trendline', { tags: ['Metrics', 'staging', 'prod'] }, () => {
    experientialMetrics.experimentalCharts().then(($charts) => {
      const initialChartCount = $charts.length;
      experientialMetrics.experientialMetricsTabs().should('contain', 'Sentiment Signals');
      experientialMetrics.addChartButton().click();
      experientialMetrics.addChartPopup().should('contain', 'Add a Customer Experience Chart');
      experientialMetrics.addChartPopupSentimentScoreOption().click();
      experientialMetrics.addChartPopupTrendOption().click();
      experientialMetrics.addChartPopup().should('contain', 'Show “Sentiment Score“ by...(Optional)');
      experientialMetrics.addChartPopupAddButton().click();
      experientialMetrics.experimentalCharts().should('have.length', initialChartCount + 1);
      experientialMetrics.experimentalCharts().eq(1).parent().should('contain', 'Sentiment Score');
      experientialMetrics.chartCaseStatusDropdownTrigger('Sentiment Score').should('have.text', 'Closed');
    });
  });

  /*
   *  Check the initial chart count
   *  Click the add chart button
   *  Select the attention score chart type
   *  Select the vertical bar option
   *  Click cancel
   *  Verify the chart count
   */
  it('C124836: Customer Experience - Add a chart Cancellation flow', { tags: ['Metrics', 'staging', 'prod'] }, () => {
    experientialMetrics.experimentalCharts().then(($charts) => {
      const initialChartCount = $charts.length;
      experientialMetrics.experientialMetricsTabs().should('contain', 'Sentiment Signals');
      experientialMetrics.addChartButton().click();
      experientialMetrics.addChartPopup().should('contain', 'Add a Customer Experience Chart');
      experientialMetrics.addChartPopupAttentionScoreOption().click();
      experientialMetrics.addChartPopupVerticalBarOption().click();
      experientialMetrics.addChartPopup().should('contain', 'Show “Attention Score“ by...(Optional)');
      experientialMetrics.addChartPopupCancelButton().click();
      experientialMetrics.experimentalCharts().should('have.length', initialChartCount);
    });
  });

  /*
   *  Check the initial chart count
   *  Click the add chart button
   *  Select the attention score chart type
   *  Select the vertical bar option
   *  Select a group by option
   *  Verifty the attention score chart
   *  Verify the chart count
   */
  it('C124835: Customer Experience - Add Attention Score chart - Vertical Bar', { tags: ['Metrics', 'staging', 'prod'] }, () => {
    experientialMetrics.experimentalCharts().then(($charts) => {
      const initialChartCount = $charts.length;
      experientialMetrics.experientialMetricsTabs().should('contain', 'Sentiment Signals');
      experientialMetrics.addChartButton().click();
      experientialMetrics.addChartPopup().should('contain', 'Add a Customer Experience Chart');
      experientialMetrics.addChartPopupAttentionScoreOption().click();
      experientialMetrics.addChartPopupVerticalBarOption().click();
      experientialMetrics.addChartPopup().should('contain', 'Show “Attention Score“ by...(Optional)');
      experientialMetrics.addChartGroupByDropdownButton().click();
      experientialMetrics.addChartGroupByDropdownOption('priority').click();
      experientialMetrics.addChartPopupAddButton().click();
      experientialMetrics.experimentalCharts().should('have.length', initialChartCount + 1);
      experientialMetrics.chartHeader('Attention Score by Priority').should('be.visible').realHover();
      experientialMetrics.experimentalCharts().eq(1).parent().should('contain', 'This Period').and('contain', 'Previous Period');
      experientialMetrics.chartCaseStatusDropdownTrigger('Attention Score by Priority').should('have.text', 'Closed');
    });
  });

  /*
   *  Check the initial chart count
   *  Click the add chart button
   *  Select the attention score chart type
   *  Select the trendline option
   *  Select a group by option
   *  Verifty the attention score chart
   *  Verify the chart count
   */
  it('C124837: Customer Experience - Add Attention Score chart - Trendline', { tags: ['Metrics', 'staging', 'prod'] }, () => {
    experientialMetrics.experimentalCharts().then(($charts) => {
      const initialChartCount = $charts.length;
      experientialMetrics.experientialMetricsTabs().should('contain', 'Sentiment Signals');
      experientialMetrics.addChartButton().click();
      experientialMetrics.addChartPopup().should('contain', 'Add a Customer Experience Chart');
      experientialMetrics.addChartPopupAttentionScoreOption().click();
      experientialMetrics.addChartPopupTrendOption().click();
      experientialMetrics.addChartPopup().should('contain', 'Show “Attention Score“ by...(Optional)');
      experientialMetrics.addChartGroupByDropdownButton().click();
      experientialMetrics.addChartGroupByDropdownOption('priority').click();
      experientialMetrics.addChartPopupAddButton().click();
      experientialMetrics.experimentalCharts().should('have.length', initialChartCount + 1);
      experientialMetrics.chartHeader('Attention Score by Priority').should('be.visible');
      experientialMetrics.chartCaseStatusDropdownTrigger('Attention Score by Priority').should('have.text', 'Closed');
    });
  });

  /*
   *  Check the initial chart count
   *  Click the add chart button
   *  Select the Sentiment score chart type
   *  Select the vertical bar option
   *  Select a group by option
   *  Verifty the Sentiment score chart
   *  Verify the chart count
   */
  it('C124840: Customer Experience - Add Sentiment Score chart - Vertical Bar', { tags: ['Metrics', 'staging', 'prod'] }, () => {
    experientialMetrics.experimentalCharts().then(($charts) => {
      const initialChartCount = $charts.length;
      experientialMetrics.experientialMetricsTabs().should('contain', 'Sentiment Signals');
      experientialMetrics.addChartButton().click();
      experientialMetrics.addChartPopup().should('contain', 'Add a Customer Experience Chart');
      experientialMetrics.addChartPopupSentimentScoreOption().click();
      experientialMetrics.addChartPopupVerticalBarOption().click();
      experientialMetrics.addChartPopup().should('contain', 'Show “Sentiment Score“ by...(Optional)');
      experientialMetrics.addChartGroupByDropdownButton().click();
      experientialMetrics.addChartGroupByDropdownOption('priority').click();
      experientialMetrics.addChartPopupAddButton().click();
      experientialMetrics.experimentalCharts().should('have.length', initialChartCount + 1);
      experientialMetrics.chartHeader('Sentiment Score by Priority').should('be.visible').realHover();
      experientialMetrics.experimentalCharts().eq(1).parent().should('contain', 'This Period').and('contain', 'Previous Period');
      experientialMetrics.chartCaseStatusDropdownTrigger('Sentiment Score by Priority').should('have.text', 'Closed');
    });
  });

  /*
   *  Check the initial chart count
   *  Click the add chart button
   *  Select the Sentiment score chart type
   *  Select the trendline option
   *  Select a group by option
   *  Verifty the Sentiment score chart
   *  Verify the chart count
   */
  it('C124841: Customer Experience - Add Sentiment Score chart - Trendline', { tags: ['Metrics', 'staging', 'prod'] }, () => {
    experientialMetrics.experimentalCharts().then(($charts) => {
      const initialChartCount = $charts.length;
      experientialMetrics.experientialMetricsTabs().should('contain', 'Sentiment Signals');
      experientialMetrics.addChartButton().click();
      experientialMetrics.addChartPopup().should('contain', 'Add a Customer Experience Chart');
      experientialMetrics.addChartPopupSentimentScoreOption().click();
      experientialMetrics.addChartPopupTrendOption().click();
      experientialMetrics.addChartPopup().should('contain', 'Show “Sentiment Score“ by...(Optional)');
      experientialMetrics.addChartGroupByDropdownButton().click();
      experientialMetrics.addChartGroupByDropdownOption('priority').click();
      experientialMetrics.addChartPopupAddButton().click();
      experientialMetrics.experimentalCharts().should('have.length', initialChartCount + 1);
      experientialMetrics.chartHeader('Sentiment Score by Priority').should('be.visible');
      experientialMetrics.chartCaseStatusDropdownTrigger('Sentiment Score by Priority').should('have.text', 'Closed');
    });
  });

  /*
   *  Check the initial chart count
   *  Click the add chart button
   *  Select the Customer sentiment score chart type
   *  Select the vertical bar option
   *  Verifty the Customer sentiment score chart
   *  Verify the chart count
   */
  it('C124858: Customer Experience - Add Customer Sentiment Score chart - Vertical Bar', { tags: ['Metrics', 'staging'] }, () => {
    experientialMetrics.experimentalCharts().then(($charts) => {
      const initialChartCount = $charts.length;
      experientialMetrics.experientialMetricsTabs().should('contain', 'Sentiment Signals');
      experientialMetrics.addChartButton().click();
      experientialMetrics.addChartPopup().should('contain', 'Add a Customer Experience Chart');
      experientialMetrics.addChartPopupCustomerSentimentScoreOption().click();
      experientialMetrics.addChartPopupVerticalBarOption().click();
      experientialMetrics.addChartPopup().should('contain', 'Show “Customer Sentiment Score“ by...(Optional)');
      experientialMetrics.addChartPopupAddButton().click();
      experientialMetrics.experimentalCharts().should('have.length', initialChartCount + 1);
      experientialMetrics.experimentalCharts().eq(1).should('contain', 'Customer Sentiment Score');
      experientialMetrics.customerSentimentScoreVerticalBarsDropdownTrigger().should('have.text', 'All customers');
    });
  });

  /*
   *  Check the initial chart count
   *  Click the add chart button
   *  Select the Customer sentiment score chart type
   *  Select the trendline option
   *  Verifty the Customer sentiment score chart
   *  Verify the chart count
   */
  it('C124859: Customer Experience - Add Customer Sentiment Score chart - Trendline', { tags: ['Metrics', 'staging', 'prod'] }, () => {
    experientialMetrics.experimentalCharts().then(($charts) => {
      const initialChartCount = $charts.length;
      experientialMetrics.experientialMetricsTabs().should('contain', 'Sentiment Signals');
      experientialMetrics.addChartButton().click();
      experientialMetrics.addChartPopup().should('contain', 'Add a Customer Experience Chart');
      experientialMetrics.addChartPopupCustomerSentimentScoreOption().click();
      experientialMetrics.addChartPopupTrendOption().click();
      experientialMetrics.addChartPopupAddButton().click();
      experientialMetrics.experimentalCharts().should('have.length', initialChartCount + 1);
      experientialMetrics.experimentalCharts().eq(1).parent().should('contain', 'Customer Sentiment Score');
      experientialMetrics.customerSentimentScoreTrendlineDropdownTrigger().should('have.text', 'All customers (avg)');
    });
  });

  /*
   *  Check the initial chart count
   *  Click the add chart button
   *  Select the Customer sentiment score chart type
   *  Select the vertical bar option
   *  Select a group by option
   *  Verifty the Customer sentiment score chart
   *  Verify the chart count
   */
  it('C124860: Customer Experience - Add Customer Sentiment Score chart - Vertical Bar with GroupBy', { tags: ['Metrics', 'staging'] }, () => {
    experientialMetrics.experimentalCharts().then(($charts) => {
      const initialChartCount = $charts.length;
      experientialMetrics.experientialMetricsTabs().should('contain', 'Sentiment Signals');
      experientialMetrics.addChartButton().click();
      experientialMetrics.addChartPopup().should('contain', 'Add a Customer Experience Chart');
      experientialMetrics.addChartPopupCustomerSentimentScoreOption().click();
      experientialMetrics.addChartPopupVerticalBarOption().click();
      experientialMetrics.addChartPopup().should('contain', 'Show “Customer Sentiment Score“ by...(Optional)');
      experientialMetrics.addChartGroupByDropdownButton().click();
      experientialMetrics.addChartGroupByDropdownOption('rating').click();
      experientialMetrics.addChartPopupAddButton().click();
      experientialMetrics.experimentalCharts().should('have.length', initialChartCount + 1);
      experientialMetrics.chartHeader('Current Customer Sentiment Score by Customer Rating').should('be.visible');
      experientialMetrics.customerSentimentScoreVerticalBarsDropdownTrigger().should('have.text', 'All customers');
    });
  });

  /*
   *  Check the initial chart count
   *  Click the add chart button
   *  Select the Sentiment Signals chart type
   *  Verifty the Sentiment Signal chart
   *  Verify the chart count
   */
  it('C124855: Customer Experience - Add Sentiment Signal chart', { tags: ['Metrics', 'staging'] }, () => {
    experientialMetrics.experimentalCharts().then(($charts) => {
      const initialChartCount = $charts.length;
      experientialMetrics.experientialMetricsTabs().should('contain', 'Sentiment Signals');
      experientialMetrics.addChartButton().click();
      experientialMetrics.addChartPopup().should('contain', 'Add a Customer Experience Chart');
      experientialMetrics.addChartPopupSentimentSignalsOption().click();
      experientialMetrics.addChartPopupAddButton().click();
      experientialMetrics.experimentalCharts().should('have.length', initialChartCount + 1);
      experientialMetrics.chartHeader('Sentiment Signals').should('be.visible');
      experientialMetrics.chartCaseStatusDropdownTrigger('Sentiment Signals').should('contain', 'Closed');
    });
  });

  /*
   *  Check the initial chart count
   *  Click the add chart button
   *  Select the CSAT score chart type
   *  Select the vertical bar option
   *  Verifty the CSAT score chart
   *  Verify the chart count
   */
  it('C124888: Customer Experience - Add CSAT Score chart - Vertical Bar', { tags: ['Metrics', 'staging'] }, () => {
    experientialMetrics.experimentalCharts().then(($charts) => {
      const initialChartCount = $charts.length;
      experientialMetrics.experientialMetricsTabs().should('contain', 'Sentiment Signals');
      experientialMetrics.addChartButton().click();
      experientialMetrics.addChartPopup().should('contain', 'Add a Customer Experience Chart');
      experientialMetrics.addChartPopupCSATScoreOption().click();
      experientialMetrics.addChartPopupVerticalBarOption().click();
      experientialMetrics.addChartPopup().should('contain', 'Show “CSAT Score“ by...(Optional)');
      experientialMetrics.addChartPopupAddButton().click();
      experientialMetrics.experimentalCharts().should('have.length', initialChartCount + 1);
      experientialMetrics.experimentalCharts().eq(1).should('contain', 'CSAT Score').realHover();
      experientialMetrics.experimentalCharts().eq(1).parent().should('contain', 'This Period').and('contain', 'Previous Period');
      experientialMetrics.chartCaseStatusDropdownTrigger('CSAT Score').should('have.text', 'Closed');
    });
  });

  /*
   *  Check the initial chart count
   *  Click the add chart button
   *  Select the CSAT score chart type
   *  Select the vertical bar option
   *  Select a group by option
   *  Verifty the CSAT score chart
   *  Verify the chart count
   */
  it('C124889: Customer Experience - Add CSAT Score chart - Vertical Bar - With GroupBy', { tags: ['Metrics', 'staging', 'prod'] }, () => {
    experientialMetrics.experimentalCharts().then(($charts) => {
      const initialChartCount = $charts.length;
      experientialMetrics.experientialMetricsTabs().should('contain', 'Sentiment Signals');
      experientialMetrics.addChartButton().click();
      experientialMetrics.addChartPopup().should('contain', 'Add a Customer Experience Chart');
      experientialMetrics.addChartPopupCSATScoreOption().click();
      experientialMetrics.addChartPopupVerticalBarOption().click();
      experientialMetrics.addChartPopup().should('contain', 'Show “CSAT Score“ by...(Optional)');
      experientialMetrics.addChartGroupByDropdownButton().click();
      experientialMetrics.addChartGroupByDropdownOption('priority').click();
      experientialMetrics.addChartPopupAddButton().click();
      experientialMetrics.experimentalCharts().should('have.length', initialChartCount + 1);
      experientialMetrics.chartHeader('CSAT Score by Priority').should('be.visible').realHover();
      experientialMetrics.experimentalCharts().eq(1).parent().should('contain', 'This Period').and('contain', 'Previous Period');
      experientialMetrics.chartCaseStatusDropdownTrigger('CSAT Score by Priority').should('have.text', 'Closed');
    });
  });

  /*
   *  Check the initial chart count
   *  Click the add chart button
   *  Select the CSAT score chart type
   *  Select the trendline option
   *  Verifty the CSAT score chart
   *  Verify the chart count
   */
  it('C124890: Customer Experience - Add CSAT Score chart - Trendline', { tags: ['Metrics', 'staging'] }, () => {
    experientialMetrics.experimentalCharts().then(($charts) => {
      const initialChartCount = $charts.length;
      experientialMetrics.experientialMetricsTabs().should('contain', 'Sentiment Signals');
      experientialMetrics.addChartButton().click();
      experientialMetrics.addChartPopup().should('contain', 'Add a Customer Experience Chart');
      experientialMetrics.addChartPopupCSATScoreOption().click();
      experientialMetrics.addChartPopupTrendOption().click();
      experientialMetrics.addChartPopup().should('contain', 'Show “CSAT Score“ by...(Optional)');
      experientialMetrics.addChartPopupAddButton().click();
      experientialMetrics.experimentalCharts().should('have.length', initialChartCount + 1);
      experientialMetrics.experimentalCharts().eq(1).parent().should('contain', 'CSAT Score');
      experientialMetrics.chartCaseStatusDropdownTrigger('CSAT Score').should('have.text', 'Closed');
    });
  });

  /*
   *  Check the initial chart count
   *  Click the add chart button
   *  Select the CSAT score chart type
   *  Select the trendline option
   *  Select a group by option
   *  Verifty the CSAT score chart
   *  Verify the chart count
   */
  it('C124891: Customer Experience - Add CSAT Score chart - Trendline - With GroupBy', { tags: ['Metrics', 'staging', 'prod'] }, () => {
    experientialMetrics.experimentalCharts().then(($charts) => {
      const initialChartCount = $charts.length;
      experientialMetrics.experientialMetricsTabs().should('contain', 'Sentiment Signals');
      experientialMetrics.addChartButton().click();
      experientialMetrics.addChartPopup().should('contain', 'Add a Customer Experience Chart');
      experientialMetrics.addChartPopupCSATScoreOption().click();
      experientialMetrics.addChartPopupTrendOption().click();
      experientialMetrics.addChartPopup().should('contain', 'Show “CSAT Score“ by...(Optional)');
      experientialMetrics.addChartGroupByDropdownButton().click();
      experientialMetrics.addChartGroupByDropdownOption('priority').click();
      experientialMetrics.addChartPopupAddButton().click();
      experientialMetrics.experimentalCharts().should('have.length', initialChartCount + 1);
      experientialMetrics.chartHeader('CSAT Score by Priority').should('be.visible');
      experientialMetrics.chartCaseStatusDropdownTrigger('CSAT Score by Priority').should('have.text', 'Closed');
    });
  });

  /*
   *  Check the initial chart count
   *  Click the add chart button
   *  Select the NPS score chart type
   *  Select the vertical bar option
   *  Verifty the NPS score chart
   *  Verify the chart count
   */
  it('C124892: Customer Experience - Add NPS Score chart - Vertical Bar', { tags: ['Metrics', 'staging'] }, () => {
    experientialMetrics.experimentalCharts().then(($charts) => {
      const initialChartCount = $charts.length;
      experientialMetrics.experientialMetricsTabs().should('contain', 'Sentiment Signals');
      experientialMetrics.addChartButton().click();
      experientialMetrics.addChartPopup().should('contain', 'Add a Customer Experience Chart');
      experientialMetrics.addChartPopupNPSScoreOption().click();
      experientialMetrics.addChartPopupVerticalBarOption().click();
      experientialMetrics.addChartPopup().should('contain', 'Show “NPS Score“ by...(Optional)');
      experientialMetrics.addChartPopupAddButton().click();
      experientialMetrics.experimentalCharts().should('have.length', initialChartCount + 1);
      experientialMetrics.experimentalCharts().eq(1).should('contain', 'NPS Score').realHover();
      experientialMetrics.experimentalCharts().eq(1).parent().should('contain', 'This Period').and('contain', 'Previous Period');
      experientialMetrics.chartCaseStatusDropdownTrigger('NPS Score').should('have.text', 'Closed');
    });
  });

  /*
   *  Check the initial chart count
   *  Click the add chart button
   *  Select the NPS score chart type
   *  Select the vertical bar option
   *  Select a group by option
   *  Verifty the NPS score chart
   *  Verify the chart count
   */
  it('C124893: Customer Experience - Add NPS Score chart - Vertical Bar - With GroupBy', { tags: ['Metrics', 'staging', 'prod'] }, () => {
    experientialMetrics.experimentalCharts().then(($charts) => {
      const initialChartCount = $charts.length;
      experientialMetrics.experientialMetricsTabs().should('contain', 'Sentiment Signals');
      experientialMetrics.addChartButton().click();
      experientialMetrics.addChartPopup().should('contain', 'Add a Customer Experience Chart');
      experientialMetrics.addChartPopupNPSScoreOption().click();
      experientialMetrics.addChartPopupVerticalBarOption().click();
      experientialMetrics.addChartPopup().should('contain', 'Show “NPS Score“ by...(Optional)');
      experientialMetrics.addChartGroupByDropdownButton().click();
      experientialMetrics.addChartGroupByDropdownOption('priority').click();
      experientialMetrics.addChartPopupAddButton().click();
      experientialMetrics.experimentalCharts().should('have.length', initialChartCount + 1);
      experientialMetrics.chartHeader('NPS Score by Priority').should('be.visible').realHover();
      experientialMetrics.experimentalCharts().eq(1).parent().should('contain', 'This Period').and('contain', 'Previous Period');
      experientialMetrics.chartCaseStatusDropdownTrigger('NPS Score by Priority').should('have.text', 'Closed');
    });
  });

  /*
   *  Check the initial chart count
   *  Click the add chart button
   *  Select the NPS score chart type
   *  Select the trendline option
   *  Verifty the NPS score chart
   *  Verify the chart count
   */
  it('C124894: Customer Experience - Add NPS Score chart - Trendline', { tags: ['Metrics', 'staging'] }, () => {
    experientialMetrics.experimentalCharts().then(($charts) => {
      const initialChartCount = $charts.length;
      experientialMetrics.experientialMetricsTabs().should('contain', 'Sentiment Signals');
      experientialMetrics.addChartButton().click();
      experientialMetrics.addChartPopup().should('contain', 'Add a Customer Experience Chart');
      experientialMetrics.addChartPopupNPSScoreOption().click();
      experientialMetrics.addChartPopupTrendOption().click();
      experientialMetrics.addChartPopup().should('contain', 'Show “NPS Score“ by...(Optional)');
      experientialMetrics.addChartPopupAddButton().click();
      experientialMetrics.experimentalCharts().should('have.length', initialChartCount + 1);
      experientialMetrics.experimentalCharts().eq(1).parent().should('contain', 'NPS Score');
      experientialMetrics.chartCaseStatusDropdownTrigger('NPS Score').should('have.text', 'Closed');
    });
  });

  /*
   *  Check the initial chart count
   *  Click the add chart button
   *  Select the NPS score chart type
   *  Select the trendline option
   *  Select a group by option
   *  Verifty the NPS score chart
   *  Verify the chart count
   */
  it('C124895: Customer Experience - Add NPS Score chart - Trendline - With GroupBy', { tags: ['Metrics', 'staging', 'prod'] }, () => {
    experientialMetrics.experimentalCharts().then(($charts) => {
      const initialChartCount = $charts.length;
      experientialMetrics.experientialMetricsTabs().should('contain', 'Sentiment Signals');
      experientialMetrics.addChartButton().click();
      experientialMetrics.addChartPopup().should('contain', 'Add a Customer Experience Chart');
      experientialMetrics.addChartPopupNPSScoreOption().click();
      experientialMetrics.addChartPopupTrendOption().click();
      experientialMetrics.addChartPopup().should('contain', 'Show “NPS Score“ by...(Optional)');
      experientialMetrics.addChartGroupByDropdownButton().click();
      experientialMetrics.addChartGroupByDropdownOption('priority').click();
      experientialMetrics.addChartPopupAddButton().click();
      experientialMetrics.experimentalCharts().should('have.length', initialChartCount + 1);
      experientialMetrics.chartHeader('NPS Score by Priority').should('be.visible');
      experientialMetrics.chartCaseStatusDropdownTrigger('NPS Score by Priority').should('have.text', 'Closed');
    });
  });
});
