import { urlHelpers } from '../../../../utils';
import { experientialMetrics } from '../../../../pages';

describe('Experiential Metrics - Main chart', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.experientialMetrics.home);
    experientialMetrics.clearCharts();
    experientialMetrics.addAllSentiments();
  });

  after(() => {
    experientialMetrics.addAllSentiments();
  });

  /*
   *  Check Sentiment Signal chart header
   * Check the Sentiment Signal chart sub-header
   * Filter the data by Created
   * Check the updated drowpdown value
   * Check the chart labels displayed along X-axis
   */
  it('C127047: Customer Experience - Sentiment Signal Chart - Group By `Created`', { tags: ['Metrics', 'staging'] }, () => {
    experientialMetrics.expMetricsCasesShownText().parent().siblings('span').should('contain', 'Sentiment Signals');
    experientialMetrics
      .expMetricsCasesShownText()
      .then(($p) => $p.clone().children().remove().end().text().trim())
      .should('match', /Showing ([0-9]+) cases/);
    experientialMetrics.chartCaseStatusDropdownTrigger('Sentiment Signals').click();
    experientialMetrics.chartGroupByDropdownOption().should('contain', 'Created').and('contain', 'Closed').and('contain', 'in the Open State');
    experientialMetrics.chartGroupByDropdownOption('Created').click();
    experientialMetrics.chartCaseStatusDropdownTrigger('Sentiment Signals').should('contain', 'Created');

    experientialMetrics.chartSignalSortButton().should('have.length', 2);
    experientialMetrics.chartLabels().should('contain', 'Frustration').and('contain', 'Negative');
  });

  /*
   *  Check Sentiment Signal chart header
   * Check the Sentiment Signal chart sub-header
   * Filter the data by Closed
   * Check the updated drowpdown value
   * Check the chart labels displayed along X-axis
   */
  it('C127048:	Customer Experience - Sentiment Signal Chart - Group By `Closed`', { tags: ['Metrics', 'staging'] }, () => {
    experientialMetrics.expMetricsCasesShownText().parent().siblings('span').should('contain', 'Sentiment Signals');
    experientialMetrics
      .expMetricsCasesShownText()
      .then(($p) => $p.clone().children().remove().end().text().trim())
      .should('match', /Showing ([0-9]+) cases/);
    experientialMetrics.chartCaseStatusDropdownTrigger('Sentiment Signals').click();
    experientialMetrics.chartGroupByDropdownOption().should('contain', 'Created').and('contain', 'Closed').and('contain', 'in the Open State');
    experientialMetrics.chartGroupByDropdownOption('Closed').click();
    experientialMetrics.chartCaseStatusDropdownTrigger('Sentiment Signals').should('contain', 'Closed');
    experientialMetrics.chartSignalSortButton().should('have.length', 2);
    experientialMetrics.chartLabels().should('contain', 'Frustration').and('contain', 'Negative');
  });

  /*
   *  Check Sentiment Signal chart header
   * Check the Sentiment Signal chart sub-header
   * Filter the data by open state
   * Check the updated drowpdown value
   * Check the chart labels displayed along X-axis
   */
  it('C127049: Customer Experience - Sentiment Signal Chart - Group By `in the Open State`', { tags: ['Metrics', 'staging'] }, () => {
    experientialMetrics.expMetricsCasesShownText().parent().siblings('span').should('contain', 'Sentiment Signals');
    experientialMetrics
      .expMetricsCasesShownText()
      .then(($p) => $p.clone().children().remove().end().text().trim())
      .should('match', /Showing ([0-9]+) cases/);
    experientialMetrics.chartCaseStatusDropdownTrigger('Sentiment Signals').click();
    experientialMetrics.chartGroupByDropdownOption().should('contain', 'Created').and('contain', 'Closed').and('contain', 'in the Open State');
    experientialMetrics.chartGroupByDropdownOption('in the Open State').click();
    experientialMetrics.chartCaseStatusDropdownTrigger('Sentiment Signals').should('contain', 'in the Open State');
    experientialMetrics.chartSignalSortButton().should('have.length', 2);
    experientialMetrics.chartLabels().should('contain', 'Frustration').and('contain', 'Negative');
  });

  /*
   * Check Sentiment Signal chart
   * Get the first signal along the x-axis
   * Click the edit sentiments button
   * Remove the entiment
   * Check that the sentiment no longer appears on the x-axis
   */
  it('C127065: Customer Experience - Sentiment Signal chart - Edit Sentiments flow', { tags: ['Metrics', 'staging'] }, () => {
    experientialMetrics.expMetricsCasesShownText().parent().siblings('span').should('contain', 'Sentiment Signals');
    experientialMetrics
      .chartLabels()
      .find('text')
      .first()
      .text()
      .then((sentiment) => {
        experientialMetrics.chartLabels().should('contain', sentiment);
        experientialMetrics.chartsDotMenu().click();
        experientialMetrics.editSentimentsButton().click();
        experientialMetrics.sentimentLabel(sentiment).click();
        experientialMetrics.editSentimentsSaveButton().click();
        experientialMetrics.chartLabels().should('not.contain', sentiment);
      });
  });
});
