import { urlHelpers } from '../../../../utils';
import { experientialMetrics, datePicker } from '../../../../pages';

describe('Experiential Metrics - Calendar Tests', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.experientialMetrics.home);
  });

  /*
      Set calendar to this month
      Get current New Escalation count
      Select calendar to last 3 months
      Get new New Escalations count and ensure the count has changed
   */
  it('C9223: Experiential Metrics - Overview Page (Calendar) ', { tags: ['Metrics', 'staging', 'prod'] }, () => {
    experientialMetrics.chartCaseStatusDropdownTrigger('Sentiment Signals').click();
    experientialMetrics.chartGroupByDropdownOption('Created').click();
    // set calendar to this month (if not already)
    datePicker.datePickerTrigger().then(($btn) => {
      if (!$btn.text().includes('This month')) {
        datePicker.selectAndApplyThisMonthRadioButton();
      }
    });
    // get current count of New Escalations
    experientialMetrics
      .expMetricsCasesShownText()
      .eq(0)
      .then((bfrCasesShownCount) => {
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(5000);
        const beforeCasesShownCount = bfrCasesShownCount.text();
        datePicker.datePickerTrigger().click();
        // change calendar to last 3 months
        datePicker.selectLastMonthWithOption(3);
        datePicker.datePickerTrigger().should('have.text', 'Last 3 months');
        // get new metric count
        experientialMetrics
          .expMetricsCasesShownText()
          .eq(0)
          .then((afterCasesShownCount) => {
            // eslint-disable-next-line cypress/no-unnecessary-waiting
            cy.wait(5000);
            expect(afterCasesShownCount.text()).not.equal(beforeCasesShownCount);
          });
      });
  });

  /*
      Open calendar widget from Exp Metrics page
      Scroll through months forward and back on both starting and ending calendars
   */
  it('C9225: Experiential Metrics - Calendar Scroll ', { tags: ['Metrics', 'staging', 'prod'] }, () => {
    datePicker.datePickerTrigger().click();
    datePicker.scrollThroughCalendar();
  });

  /*
      Set calendar to this month and Apply
      Get current New Escalation count
      Select calendar to last 3 months and Apply
      Get new New Escalations count and ensure the count has changed so the Apply works properly
   */
  it('C9227: Experiential Metrics - Calendar Apply', { tags: ['Metrics', 'staging', 'prod'] }, () => {
    experientialMetrics.chartCaseStatusDropdownTrigger('Sentiment Signals').click();
    experientialMetrics.chartGroupByDropdownOption('Created').click();
    // set calendar to this month (if not already)
    datePicker.datePickerTrigger().then(($btn) => {
      if (!$btn.text().includes('This month')) {
        datePicker.selectAndApplyThisMonthRadioButton();
      }
    });
    // get current count of New Escalations
    experientialMetrics
      .expMetricsCasesShownText()
      .eq(0)
      .then((bfrCasesShownCount) => {
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(5000);
        const beforeCasesShownCount = bfrCasesShownCount.text();
        datePicker.datePickerTrigger().click();
        // change calendar to last 3 months
        datePicker.selectLastMonthWithOption(3);
        datePicker.datePickerTrigger().should('have.text', 'Last 3 months');
        // get new metric count
        experientialMetrics
          .expMetricsCasesShownText()
          .eq(0)
          .then((afterCasesShownCount) => {
            // eslint-disable-next-line cypress/no-unnecessary-waiting
            cy.wait(5000);
            expect(afterCasesShownCount.text()).not.equal(beforeCasesShownCount);
          });
      });
  });

  /*
      Set calendar to this month and Apply
      Get current New Escalation count
      Select calendar to last 3 months and Cancel
      Get new New Escalations count and ensure the count is the same proving the Cancel worked
   */
  it('C9229: Experiential Metrics - Overview Page (Cancel)', { tags: ['Metrics', 'staging', 'prod'] }, () => {
    experientialMetrics.chartCaseStatusDropdownTrigger('Sentiment Signals').click();
    experientialMetrics.chartGroupByDropdownOption('Created').click();
    // set calendar to this month (if not already)
    datePicker.datePickerTrigger().then(($btn) => {
      if (!$btn.text().includes('This month')) {
        datePicker.selectAndApplyThisMonthRadioButton();
      }
    });
    // get current count of New Escalations
    experientialMetrics
      .expMetricsCasesShownText()
      .eq(0)
      .then((bfrCasesShownCount) => {
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(5000);
        const beforeCasesShownCount = bfrCasesShownCount.text();
        datePicker.datePickerTrigger().click();
        // change calendar to last 3 months
        datePicker.selectLastMonthWithOptionWithoutApply(3);
        datePicker.cancelButton().click();
        // button text didn't change
        datePicker.datePickerTrigger().should('have.text', 'This month');
        // get new metric count
        experientialMetrics
          .expMetricsCasesShownText()
          .eq(0)
          .then((afterCasesShownCount) => {
            // eslint-disable-next-line cypress/no-unnecessary-waiting
            cy.wait(5000);
            expect(afterCasesShownCount.text()).equals(beforeCasesShownCount);
          });
      });
  });
});
