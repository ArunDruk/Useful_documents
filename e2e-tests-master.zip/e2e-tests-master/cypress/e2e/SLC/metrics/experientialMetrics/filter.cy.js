import { urlHelpers } from '../../../../utils';
import { experientialMetrics } from '../../../../pages';

describe('Experiential Metrics - Add Charts', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.experientialMetrics.home);
    experientialMetrics.clearCharts();
  });

  afterEach(() => {
    experientialMetrics.clearCharts();
  });

  /*
   *  Check the initial chart count
   *  Click the add chart button
   *  Select the Customer sentiment score chart type
   *  Select the vertical bar option
   *  Verifty the Customer sentiment score chart
   *  Filter the data for an individual customer
   */
  it('C124915: 	Customer sentiment score Vertical chart - Individual Customer filter', { tags: ['Metrics', 'staging'] }, () => {
    cy.slcHelpers.getCustomerDetails().then((customerDetails) => {
      const customerDetail = Cypress._.sample(customerDetails);
      experientialMetrics.experimentalCharts().then(($charts) => {
        const initialChartCount = $charts.length;
        experientialMetrics.experientialMetricsTabs().should('contain', 'Sentiment Signals');
        experientialMetrics.addChartButton().click();
        experientialMetrics.addChartPopup().should('contain', 'Add a Customer Experience Chart');
        experientialMetrics.addChartPopupCustomerSentimentScoreOption().click();
        experientialMetrics.addChartPopupVerticalBarOption().click();
        experientialMetrics.addChartPopup().should('contain', 'Show “Customer Sentiment Score“ by...(Optional)');
        experientialMetrics.addChartPopupAddButton().click();
        experientialMetrics.experimentalCharts().should('have.length', initialChartCount + 1);
        experientialMetrics.experimentalCharts().eq(1).should('contain', 'Customer Sentiment Score');
        experientialMetrics.customerSentimentScoreVerticalBarsDropdownTrigger().contains('All customers').click();
        experientialMetrics.customerFilterCheckbox('All customers').should('be.checked');
        experientialMetrics.customerFilterTextInputField().click();
        experientialMetrics.customerFilterSearchButton().should('exist');
        experientialMetrics.customerFilterCheckbox('Individual Account').should('be.checked');
        experientialMetrics.customerFilterCheckbox('Virtual Account').should('be.checked');
        experientialMetrics.customerFilterCheckbox('Virtual Group').should('be.checked');
        experientialMetrics.customerFilterTextInputField().type(customerDetail.name);
        cy.waitForLoaders();
        experientialMetrics.customerFilterSearchResult(customerDetail.name).click();
        experientialMetrics.customerSentimentScoreVerticalBarsDropdownTrigger().should('contain', '1 customer');
      });
    });
  });

  /*
   *  Check the initial chart count
   *  Click the add chart button
   *  Select the Customer sentiment score chart type
   *  Select the vertical bar option
   *  Verifty the Customer sentiment score chart
   *  Filter the data for a virtual account
   */
  it('C124916: Customer sentiment score Vertical chart - Virtual Account Customer filter ', { tags: ['Metrics', 'staging'] }, () => {
    cy.slcHelpers.getVirtualAccountCustomerDetails().then((customerDetails) => {
      const customerDetail = Cypress._.sample(customerDetails);
      experientialMetrics.experimentalCharts().then(($charts) => {
        const initialChartCount = $charts.length;
        experientialMetrics.experientialMetricsTabs().should('contain', 'Sentiment Signals');
        experientialMetrics.addChartButton().click();
        experientialMetrics.addChartPopup().should('contain', 'Add a Customer Experience Chart');
        experientialMetrics.addChartPopupCustomerSentimentScoreOption().click();
        experientialMetrics.addChartPopupVerticalBarOption().click();
        experientialMetrics.addChartPopup().should('contain', 'Show “Customer Sentiment Score“ by...(Optional)');
        experientialMetrics.addChartPopupAddButton().click();
        experientialMetrics.experimentalCharts().should('have.length', initialChartCount + 1);
        experientialMetrics.experimentalCharts().eq(1).should('contain', 'Customer Sentiment Score');
        experientialMetrics.customerSentimentScoreVerticalBarsDropdownTrigger().contains('All customers').click();
        experientialMetrics.customerFilterCheckbox('All customers').should('be.checked');
        experientialMetrics.customerFilterTextInputField().click();
        experientialMetrics.customerFilterSearchButton().should('exist').click();
        experientialMetrics.customerFilterCheckbox('Individual Account').should('be.checked');
        experientialMetrics.customerFilterCheckbox('Virtual Account').should('be.checked');
        experientialMetrics.customerFilterCheckbox('Virtual Group').should('be.checked');
        experientialMetrics.customerFilterTextInputField().type(customerDetail.name);
        cy.waitForLoaders();
        experientialMetrics.customerFilterSearchResult(customerDetail.name).click();
        experientialMetrics.customerSentimentScoreVerticalBarsDropdownTrigger().should('contain', '1 customer');
      });
    });
  });

  /*
   *  Check the initial chart count
   *  Click the add chart button
   *  Select the Customer sentiment score chart type
   *  Select the trendline option
   *  Verifty the Customer sentiment score chart
   *  Filter the data for an individual customer
   */
  it('C124917: Customer sentiment score Trendline chart - Individual Customer filter', { tags: ['Metrics', 'staging'] }, () => {
    cy.slcHelpers.getCustomerDetails().then((customerDetails) => {
      const customerDetail = Cypress._.sample(customerDetails);
      experientialMetrics.experimentalCharts().then(($charts) => {
        const initialChartCount = $charts.length;
        experientialMetrics.experientialMetricsTabs().should('contain', 'Sentiment Signals');
        experientialMetrics.addChartButton().click();
        experientialMetrics.addChartPopup().should('contain', 'Add a Customer Experience Chart');
        experientialMetrics.addChartPopupCustomerSentimentScoreOption().click();
        experientialMetrics.addChartPopupTrendOption().click();
        experientialMetrics.addChartPopupAddButton().click();
        experientialMetrics.experimentalCharts().should('have.length', initialChartCount + 1);
        experientialMetrics.experimentalCharts().eq(1).parent().should('contain', 'Customer Sentiment Score');
        experientialMetrics.customerSentimentScoreTrendlineDropdownTrigger().contains('All customers (avg)').click();
        experientialMetrics.customerFilterCheckbox('All customers').should('be.checked');
        experientialMetrics.customerFilterTextInputField().click();
        experientialMetrics.customerFilterSearchButton().should('exist');
        experientialMetrics.customerFilterCheckbox('Individual Account').should('be.checked');
        experientialMetrics.customerFilterCheckbox('Virtual Account').should('be.checked');
        experientialMetrics.customerFilterCheckbox('Virtual Group').should('be.checked');
        experientialMetrics.customerFilterTextInputField().type(customerDetail.name);
        cy.waitForLoaders();
        experientialMetrics.customerFilterSearchResult(customerDetail.name).click();
        experientialMetrics.customerSentimentScoreTrendlineDropdownTrigger().should('contain', '1 customer');
      });
    });
  });

  /*
   *  Check the initial chart count
   *  Click the add chart button
   *  Select the Customer sentiment score chart type
   *  Select the trendline option
   *  Verifty the Customer sentiment score chart
   *  Filter the data for a virtual customer
   */
  it('C124919: Customer sentiment score Trendline chart - Virtual Account Customer filter', { tags: ['Metrics', 'staging'] }, () => {
    cy.slcHelpers.getVirtualAccountCustomerDetails().then((customerDetails) => {
      const customerDetail = Cypress._.sample(customerDetails);
      experientialMetrics.experimentalCharts().then(($charts) => {
        const initialChartCount = $charts.length;
        experientialMetrics.experientialMetricsTabs().should('contain', 'Sentiment Signals');
        experientialMetrics.addChartButton().click();
        experientialMetrics.addChartPopup().should('contain', 'Add a Customer Experience Chart');
        experientialMetrics.addChartPopupCustomerSentimentScoreOption().click();
        experientialMetrics.addChartPopupTrendOption().click();
        experientialMetrics.addChartPopupAddButton().click();
        experientialMetrics.experimentalCharts().should('have.length', initialChartCount + 1);
        experientialMetrics.experimentalCharts().eq(1).parent().should('contain', 'Customer Sentiment Score');
        experientialMetrics.customerSentimentScoreTrendlineDropdownTrigger().contains('All customers (avg)').click();
        experientialMetrics.customerFilterCheckbox('All customers').should('be.checked');
        experientialMetrics.customerFilterTextInputField().click();
        experientialMetrics.customerFilterSearchButton().should('exist');
        experientialMetrics.customerFilterCheckbox('Individual Account').should('be.checked');
        experientialMetrics.customerFilterCheckbox('Virtual Account').should('be.checked');
        experientialMetrics.customerFilterCheckbox('Virtual Group').should('be.checked');
        experientialMetrics.customerFilterTextInputField().type(customerDetail.name);
        cy.waitForLoaders();
        experientialMetrics.customerFilterSearchResult(customerDetail.name).click();
        experientialMetrics.customerSentimentScoreTrendlineDropdownTrigger().should('contain', '1 customer');
      });
    });
  });
});
