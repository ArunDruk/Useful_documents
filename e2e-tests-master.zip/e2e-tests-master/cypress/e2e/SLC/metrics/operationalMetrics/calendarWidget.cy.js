import { urlHelpers } from '../../../../utils';
import { metrics, datePicker } from '../../../../pages';

describe('Operational Metrics - Calendar Tests', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.operationalMetrics.home);
  });

  /*
      Set calendar to this month
      Get current New Escalation count
      Select calendar to last 3 months
      Get new New Escalations count and ensure the count has changed
   */
  it('C530: Op Metrics - Overview Page (Calendar)', { tags: ['Metrics', 'staging', 'prod'] }, () => {
    // set calendar to this month (if not already)
    datePicker.datePickerTrigger().then(($btn) => {
      if (!$btn.text().includes('This month')) {
        datePicker.selectAndApplyThisMonthRadioButton();
      }
    });
    // get current count of New Escalations
    metrics
      .newEscalationsCount()
      .eq(0)
      .then((bfrNewEscalationsCount) => {
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(5000);
        const beforeNewEscalationsCount = bfrNewEscalationsCount.text();
        datePicker.datePickerTrigger().click();
        // change calendar to last 3 months
        datePicker.selectLastMonthWithOption(3);
        datePicker.datePickerTrigger().should('have.text', 'Last 3 months');
        // get new metric count
        metrics
          .newEscalationsCount()
          .eq(0)
          .then((afterNewEscalationsCount) => {
            // eslint-disable-next-line cypress/no-unnecessary-waiting
            cy.wait(5000);
            expect(afterNewEscalationsCount.text()).not.equal(beforeNewEscalationsCount);
          });
      });
  });

  /*
      Open calendar widget from Op Metrics page
      Scroll through months forward and back on both starting and ending calendars
   */
  it('C531: Op Metrics - Overview Page (Scroll)', { tags: ['Metrics', 'staging', 'prod'] }, () => {
    datePicker.datePickerTrigger().click();
    datePicker.scrollThroughCalendar();
  });

  /*
      Set calendar to this month and Apply
      Get current New Escalation count
      Select calendar to last 3 months and Apply
      Get new New Escalations count and ensure the count has changed so the Apply works properly
   */
  it('C532: Op Metrics - Overview Page (Apply)', { tags: ['Metrics', 'staging', 'prod'] }, () => {
    // set calendar to this month (if not already)
    datePicker.datePickerTrigger().then(($btn) => {
      if (!$btn.text().includes('This month')) {
        datePicker.selectAndApplyThisMonthRadioButton();
      }
    });
    // get current count of New Escalations
    metrics
      .newEscalationsCount()
      .eq(0)
      .then((bfrNewEscalationsCount) => {
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(5000);
        const beforeNewEscalationsCount = bfrNewEscalationsCount.text();
        datePicker.datePickerTrigger().click();
        // change calendar to last 3 months
        datePicker.selectLastMonthWithOption(3);
        datePicker.datePickerTrigger().should('have.text', 'Last 3 months');
        // get new metric count
        metrics
          .newEscalationsCount()
          .eq(0)
          .then((afterNewEscalationsCount) => {
            // eslint-disable-next-line cypress/no-unnecessary-waiting
            cy.wait(5000);
            expect(afterNewEscalationsCount.text()).not.equal(beforeNewEscalationsCount);
          });
      });
  });

  /*
      Set calendar to this month and Apply
      Get current New Escalation count
      Select calendar to last 3 months and Cancel
      Get new New Escalations count and ensure the count is the same proving the Cancel worked
   */
  it('C533: Op Metrics - Overview Page (Cancel)', { tags: ['Metrics', 'staging', 'prod'] }, () => {
    // set calendar to this month (if not already)
    datePicker.datePickerTrigger().then(($btn) => {
      if (!$btn.text().includes('This month')) {
        datePicker.selectAndApplyThisMonthRadioButton();
      }
    });
    // get current count of New Escalations
    metrics
      .newEscalationsCount()
      .eq(0)
      .then((bfrNewEscalationsCount) => {
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(5000);
        const beforeNewEscalationsCount = bfrNewEscalationsCount.text();
        datePicker.datePickerTrigger().click();
        // change calendar to last 3 months
        datePicker.selectLastMonthWithOptionWithoutApply(3);
        datePicker.cancelButton().click();
        // button text didn't change
        datePicker.datePickerTrigger().should('have.text', 'This month');
        // get new metric count
        metrics
          .newEscalationsCount()
          .eq(0)
          .then((afterNewEscalationsCount) => {
            // eslint-disable-next-line cypress/no-unnecessary-waiting
            cy.wait(5000);
            expect(afterNewEscalationsCount.text()).equals(beforeNewEscalationsCount);
          });
      });
  });
});
