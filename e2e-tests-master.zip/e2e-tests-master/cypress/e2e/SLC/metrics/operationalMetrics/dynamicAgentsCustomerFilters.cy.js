import { urlHelpers } from '../../../../utils';
import { filters, globalFilters } from '../../../../pages';

describe('Operational Metrics - Dynamic Agents/Customer Filter Tests', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.operationalMetrics.home);
  });

  /*
    - Regression - C37681
    -Traverse to Operational metrics module.
    - From the Advance Filtering bar click on the customer count shown.
    - In the customer filter modal type a valid name whose data is available.
    - Check if matching result shows up and end user is able to select from there and apply that as an filter.
     */
  it('C37681:Verify the Customer Filter for advance Filtering Bar for ops metrics', { tags: ['Metrics', 'staging'] }, () => {
    filters.customerFilterButtonDynamic().should('be.visible');
    filters.customerFilterButtonDynamic().click();
    cy.slcHelpers.getCustomerDetails().then((customerDetails) => {
      const customerDetail = Cypress._.sample(customerDetails);
      globalFilters.quickFilterSearchFieldInput().should('be.visible').type(customerDetail.name);
      globalFilters.filterAgentsHeadingText().should('be.visible');
      globalFilters.filterAgentsHeadingText().contains(customerDetail.name).click();
      globalFilters.filterApplyButton().click();
      cy.waitForLoaders();
      filters.customerFilterButtonDynamic().click();
      cy.waitForLoaders();
      filters.customerFilterButtonselectedbtn().should('have.text', '1 selected');
      filters.customerFilterButtonselectedbtn().click();
      globalFilters.filterAgentsHeadingText().should('have.text', customerDetail.name);
    });
  });

  /*
  - Regression - C134623
  - Login as a valid end user.
  - Traverse to Operational metrics module.
  - From the Advance Filtering bar click on the customer count shown.
  - check customer filter modal by typing an invalid data and check if it shows the 'No result found' message.
  - Now uncheck the filters present inside customer's filter and check even if customer is present but since they don't fall under the selected option it don't shows up.
  */
  it('C134623:Verify if Customers filter is showing no matching result found when Invalid data is entered', { tags: ['Metrics', 'staging'] }, () => {
    cy.waitForLoaders();
    filters.customerFilterButtonDynamic().should('be.visible');
    filters.customerFilterButtonDynamic().click();
    cy.waitForLoaders();
    globalFilters.quickFilterSearchFieldInput().should('be.visible').type('***');
    cy.waitForLoaders();
    globalFilters.filterApplyButton().should('be.disabled');
    cy.waitForLoaders();
    filters.customerFilterEmptyStateMessageText().should('be.visible').and('contain.text', 'No results for');
  });

  /*
  - Regression - C37678
  - Login as a valid end user.
  - Traverse to Operational metrics module.
  - From the Advance Filtering bar click on the Agents count shown.
  - In the Agent filter modal type a valid name whose data is available.
  - Check if matching result shows up and end user is able to select from there and apply that as an filter.
  */
  it('C37678:Verify the Agents Filter for advance Filtering Bar for ops metrics', { tags: ['Metrics', 'staging'] }, () => {
    cy.waitForLoaders();
    filters.agentsFilterButtonDynamic().should('be.visible');
    filters.agentsFilterButtonDynamic().click();
    cy.slcHelpers.getDetailsOfAgentsWithCases().then((agentsDetails) => {
      const agentsDetail = Cypress._.sample(agentsDetails);
      cy.waitForLoaders();
      globalFilters.quickFilterSearchFieldInput().should('be.visible').type(agentsDetail.sl_name);
      globalFilters.filterAgentsHeadingText().should('be.visible');
      globalFilters.filterAgentsHeadingText().contains(agentsDetail.sl_name).click();
      globalFilters.filterApplyButton().click();
      cy.waitForLoaders();
      filters.agentsFilterButtonDynamic().click();
      cy.waitForLoaders();
      filters.customerFilterButtonselectedbtn().should('have.text', '1 selected');
      filters.customerFilterButtonselectedbtn().click();
      globalFilters.filterAgentsHeadingText().should('have.text', agentsDetail.sl_name);
    });
  });
  /*
  - Regression - C134624
  - Login as a valid end user.
  - Traverse to Operational metrics module.
  - From the Advance Filtering bar click on the Agents count shown.
  - check Agent filter modal by typing an invalid data and check if it shows the 'No result found' message.
  */
  it('C134624:Verify the Agents Filter empty state for advance Filtering Bar for ops metrics', { tags: ['Metrics', 'staging'] }, () => {
    cy.waitForLoaders();
    filters.agentsFilterButtonDynamic().should('be.visible');
    filters.agentsFilterButtonDynamic().click();
    cy.waitForLoaders();
    globalFilters.quickFilterSearchFieldInput().should('be.visible').type('***');
    cy.waitForLoaders();
    globalFilters.filterApplyButton().should('be.disabled');
    cy.waitForLoaders();
    filters.customerFilterEmptyStateMessageText().should('be.visible').and('contain.text', 'No results for');
  });
});
