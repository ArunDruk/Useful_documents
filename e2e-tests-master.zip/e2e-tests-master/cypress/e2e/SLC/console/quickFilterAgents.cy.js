import { apiHelpers, consolePage, globalFilters, supportHub } from '../../../pages';
import { urlHelpers } from '../../../utils';

beforeEach(() => {
  cy.loginByApi();
  apiHelpers.removeDynamicFilterConsolePage();
});

afterEach(() => {
  cy.slcHelpers.disableAgentsQuickFilter();
  cy.slcHelpers.clearAgentsQuickFilter();
  apiHelpers.removeDynamicFilterConsolePage();
});

describe('console_test_suite', { tags: '@FilterTests' }, () => {
  it('C32: TimeFilter with Quickfilter agent', { tags: 'Console' }, function QuickAgentFilter() {
    cy.slcHelpers.disableAgentsQuickFilter();
    cy.slcHelpers.clearAgentsQuickFilter();
    cy.slcHelpers.deleteGlobalFilter();
    cy.visit(urlHelpers.console.home);
    cy.waitForLoaders();
    consolePage.timeFilterButton().click().contains('Last 7 days').click();
    consolePage.newCasesTab().click();
    cy.waitForLoaders();
    consolePage.groupedByDropdown().eq(2).click();
    cy.contains('Case Volume').click();
    consolePage
      .assignedCasesSortDataStatus()
      .invoke('attr', 'data-status')
      .then((sortOrder) => {
        if (sortOrder === 'asc') {
          consolePage.assignedCasesSortDirection().click();
        }
      });
    consolePage
      .assignedCasesChartListItem()
      .eq(1)
      .invoke('text')
      .then((agentName) => {
        globalFilters.filterButton().invoke('text').should('be.equal', 'Filter');
        globalFilters.filterButton().click();
        globalFilters.quickFilterDropdown().invoke('attr', 'data-status').should('be.equal', 'collapsed');
        globalFilters.quickFilterDropdown().click();
        globalFilters.quickFilterAgentLink().click();

        globalFilters.quickFilterSearchFieldInput().click().wait(2000).type(agentName).wait(3000);
        cy.waitForLoaders();
        globalFilters
          .quickFilterContainer()
          .invoke('text')
          .then((searchResult) => {
            const reg = /No results for/;
            const found = searchResult.match(reg);
            if (found) {
              this.skip('Agent Not found');
            }
          });
        globalFilters.filterAgentsHeadingText().first().click();
        globalFilters.filterApplyButton().click();
        consolePage.needAttentionTab().click({ force: true });
        consolePage.sentimentsGroupbyButton().click();
        cy.contains('Status').click();
        consolePage.caseCard().first().click();
        cy.waitForLoaders();
        supportHub.baseContainer().should('be.visible');
        supportHub.caseOwnerLabel().invoke('text').should('be.equal', agentName);
        supportHub.closeButton().click();
      });
  });
});
