import { consolePage, globalFilters } from '../../../pages';
import { urlHelpers } from '../../../utils';

beforeEach(() => {
  cy.loginByApi();
});

afterEach(() => {
  cy.slcHelpers.disableCustomersQuickFilter();
  cy.slcHelpers.clearCustomersQuickFilter();
  cy.slcHelpers.deleteGlobalFilter();
});

describe('console_test_suite', { tags: '@FilterTests' }, () => {
  //  This will fail if VG/VA is selected in the filters
  //  Todo: This will fixed in QA-790
  it('C9152: global_filter_customer', { tags: 'Console' }, function globalFilterCustomer() {
    cy.slcHelpers.disableCustomersQuickFilter();
    cy.slcHelpers.clearCustomersQuickFilter();
    cy.slcHelpers.disableAgentsQuickFilter();
    cy.slcHelpers.deleteGlobalFilter();
    cy.visit(urlHelpers.console.home);
    cy.waitForLoaders();
    consolePage.timeFilterButton().click().contains('Last 7 days').click();
    consolePage.newCasesTab().click();
    consolePage
      .unassignedCasesCardTitle()
      .first()
      .invoke('text')
      .then((customerName) => {
        globalFilters.filterButton().invoke('text').should('equal', 'Filter');
        globalFilters.filterButton().click();
        globalFilters.createANewFilterButton().invoke('text').should('include', 'Create a new filter');
        globalFilters.createANewFilterButton().click();
        globalFilters.globalFilterPopup().then(($filterPopup) => {
          globalFilters.acceptWelcomePagePopup($filterPopup);
          globalFilters.commonGlobalFilterTabs().eq(1).click();

          globalFilters.globalFilterAgentSearchTextField().eq(1).click().type(customerName).wait(3000);
          globalFilters.globalFilterAgentCaseFieldCheckboxes().eq(0).click();
          cy.contains('Create a global filter').click();
          cy.contains('Apply').click();
          globalFilters.globalFilterCloseButton().last().click();
          consolePage.timeFilterButton().click().contains('Last 7 days').click();
          consolePage.needAttentionTab().click({ force: true });
          // eslint-disable-next-line cypress/no-unnecessary-waiting
          cy.wait(2000);
          consolePage.groupedByDropdown().eq(1).click();
          consolePage.sentimentsGroupByDrodownOptionCustomer().click();
          consolePage.sentimentsTabHeaderList().first().invoke('text').should('include', customerName);
        });
      });
  });
});
