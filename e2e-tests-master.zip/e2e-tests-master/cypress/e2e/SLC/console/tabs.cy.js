import { consolePage } from '../../../pages';
import { urlHelpers } from '../../../utils';

describe('Console - Tabs', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.console.home);
    cy.waitForLoaders();
  });

  /*
   * The Console page will load with the New Cases
   * The day filter will be set to Last 7 Days and the tickets will be filtered based on the activities for the last 7 days
   * The New cases tab will load data with the Unassigned Cases,Assigned Cases and Case Distribution sections
   * The count should be greater than zero
   */
  it('C9353: Validate data present in New Cases tab (Last 7 days time filter) ', { tags: 'Console' }, () => {
    consolePage.timeFilterButton().click().contains('Last 7 days').click();
    cy.waitForLoaders();
    // Removing child elements to only get the total case count
    consolePage
      .newCasesTabCount()
      .then(($p) => Number($p.clone().children().remove().end().text().trim()))
      .should('be.gt', 0);
    consolePage.newCasesTab().click();
    cy.waitForLoaders();
    consolePage.newCasesUnassignedCasesHeader().should('be.visible');
    consolePage
      .unassignedCaseCount()
      .then(($header) => Number($header.text().replace(/\D/g, '')))
      .should('gt', 0);
    consolePage.newCasesAssignedCasesHeader().and('be.visible');
    consolePage.newCasesDistributionHeader().and('be.visible');
  });

  /* // Test Case Added to SLC-Production folder
   * Log in and load the console page
   * Select "Last 7 days" in the time filter
   * Click the positive sentiments tab
   * Validate case count in the tab is > 0
   * Validate case card is visible
   */
  it('C9239: Validate data present in Positive Sentiments tab (Last 7 days time filter)', { tags: 'Console' }, () => {
    consolePage.timeFilterButton().click().contains('Last 7 days').click();
    cy.waitForLoaders();
    consolePage
      .positiveSentimentsTabCount()
      .then(($p) => Number($p.text().replace('signals', '').replace('signal', '')))
      .should('be.gt', 0);
    consolePage.positiveSentimentsTab().scrollIntoView().click({ force: true });
    cy.waitForLoaders();
    consolePage.caseCard().eq(0).should('be.visible');
  });

  /* // Test Case Added to SLC-Production folder
   * Log in and load the console page
   * Select "Last 7 days" in the time filter
   * Click the negative sentiments tab
   * Validate case count in the tab is > 0
   * Validate case card is visible
   */
  it('C9240: Validate data present in Negative Sentiments tab (Last 7 days time filter)', { tags: 'Console' }, () => {
    consolePage.timeFilterButton().click().contains('Last 7 days').click();
    cy.waitForLoaders();
    consolePage
      .negativeSentimentsTabCount()
      .then(($p) => Number($p.text().replace('signals', '').replace('signal', '')))
      .should('be.gt', 0);
    consolePage.negativeSentimentsTab().scrollIntoView().click({ force: true });
    cy.waitForLoaders();
    consolePage.caseCard().eq(0).should('be.visible');
  });

  /* // Test Case Added to SLC-Production folder
   * Log in and load the console page
   * Select "Last 7 days" in the time filter
   * Click the need attention tab
   * Validate case count in the tab is > 0
   * Validate case card is visible
   */
  it('C9241: Validate data present in Need Attention tab (Last 7 days time filter)', { tags: 'Console' }, () => {
    consolePage.timeFilterButton().click().contains('Last 7 days').click();
    cy.waitForLoaders();
    consolePage
      .needAttentionTabCaseCount()
      .then(($p) => Number($p.text().replace('signals', '').replace('signal', '')))
      .should('be.gt', 0);
    consolePage.needAttentionTab().scrollIntoView().click({ force: true });
    cy.waitForLoaders();
    consolePage.caseCard().eq(0).should('be.visible');
  });

  /* // Test Case Added to SLC-Production folder
   * Log in and load the console page
   * Select "Last 7 days" in the time filter
   * Click the product feedback tab
   * Validate case count in the tab is > 0
   * Validate case card is visible
   */
  it('C9242: Validate data present in Product Feedback tab (Last 7 days time filter)', { tags: 'Console' }, () => {
    consolePage.timeFilterButton().click().contains('Last 7 days').click();
    cy.waitForLoaders();
    consolePage
      .productFeedbackTabCount()
      .then(($p) => Number($p.text().replace('signals', '').replace('signal', '')))
      .should('be.gt', 0);
    consolePage.productFeedbackTab().scrollIntoView().click({ force: true });
    cy.waitForLoaders();
    consolePage.caseCard().eq(0).should('be.visible');
  });

  /*
   * Log in and load the console page
   * Select "Last 7 days" in the time filter
   * Click the Likely To Escalate tab
   * Validate case count in the tab is > 0
   * Validate case card is visible
   */
  it('C9352: Validate data present in Likely To Escalate tab (Last 7 days time filter)', { tags: 'Console' }, () => {
    consolePage.timeFilterButton().click().contains('Last 7 days').click();
    consolePage
      .likelyToEscalateTabCount()
      .then(($p) => Number($p.text().replace('cases', '').replace('case', '')))
      .should('be.gt', 0);
    consolePage.lteTab().scrollIntoView().click({ force: true });
    // Update the title to 'Likely To Escalate' in future tracking via -SLC-34629
    consolePage.likelyToEscalateTitle().should('have.text', 'Likely To Escalate');
    cy.waitForLoaders();
    consolePage.escalationCaseCard().eq(0).should('be.visible');
  });

  /*
   * Log in and load the console page
   * Select "Last 7 days" in the time filter
   * Click the Likely To Escalate tab
   * Validate case card fields
   */
  it('C27885: Validate in Likely to Escalate card all data are shown correctly', { tags: 'Console' }, () => {
    consolePage.timeFilterButton().click().contains('Last 7 days').click();
    consolePage.lteTab().scrollIntoView().click({ force: true });
    consolePage.caseCardSentimentScoreCountIcon().should('be.visible');
    consolePage.caseCardAttentionScoreCountIcon().should('be.visible');
    consolePage.caseCardCaseAgeLabel().should('be.visible');
    consolePage.escalationCaseCardPriorityLabel().should('be.visible');
    consolePage.caseCardLastResponseLabel().should('be.visible');
    consolePage.caseCardScoreBadgeAhsIcon().should('not.exist');
    consolePage.caseCardEscalatedDate().should('not.exist');
  });

  /*
   * Log in and load the console page
   * Select "Last 7 days" in the time filter
   * Click the New Escalation tab
   * Validate case card fields
   */
  it('C27884: Validate New Escalations card all data are shown correctly', { tags: 'Console' }, () => {
    consolePage.timeFilterButton().click().contains('Last 7 days').click();
    consolePage.newEscalationsTab().scrollIntoView().click({ force: true });
    consolePage.caseCardSentimentScoreCountIcon().should('be.visible');
    consolePage.caseCardAttentionScoreCountIcon().should('be.visible');
    consolePage.caseCardCaseAgeLabel().should('be.visible');
    consolePage.escalationCaseCardPriorityLabel().should('be.visible');
    consolePage.caseCardLastResponseLabel().should('be.visible');
    consolePage.caseCardScoreBadgeAhsIcon().should('be.visible');
    consolePage.caseCardEscalatedDate().should('be.visible');
  });

  /*
   * Log in and load the console page
   * Select "Last 7 days" in the time filter
   * Click the Likely To Escalate tab
   * Select a group by value
   * Verify the data
   */
  it('C9351: Console - Likely to Escalate (Grouped by)', { tags: 'Console' }, () => {
    consolePage.timeFilterButton().click().contains('Last 7 days').click();
    consolePage.lteTab().scrollIntoView().click({ force: true });
    consolePage.groupByPriorityOption();
    consolePage.caseCardSentimentScoreCountIcon().should('be.visible');
    consolePage.caseCardAttentionScoreCountIcon().should('be.visible');
    consolePage.caseCardCaseAgeLabel().should('be.visible');
    consolePage.escalationCaseCardPriorityLabel().should('be.visible');
    consolePage.caseCardLastResponseLabel().should('be.visible');
    consolePage.caseCardScoreBadgeAhsIcon().should('not.exist');
    consolePage.caseCardEscalatedDate().should('not.exist');
  });

  /*
   * Log in and load the console page
   * Select "Last 7 days" in the time filter
   * Click the new escalations tab
   * Select a group by value
   * Verify the data
   */
  it('C9350: Console - New Escalations (Grouped by)', { tags: 'Console' }, () => {
    consolePage.timeFilterButton().click().contains('Last 7 days').click();
    consolePage.newEscalationsTab().scrollIntoView().click({ force: true });
    consolePage.groupByPriorityOption();
    consolePage.caseCardSentimentScoreCountIcon().should('be.visible');
    consolePage.caseCardAttentionScoreCountIcon().should('be.visible');
    consolePage.caseCardCaseAgeLabel().should('be.visible');
    consolePage.escalationCaseCardPriorityLabel().should('be.visible');
    consolePage.caseCardLastResponseLabel().should('be.visible');
    consolePage.caseCardScoreBadgeAhsIcon().should('exist');
    consolePage.caseCardEscalatedDate().should('exist');
  });

  /*
   * The New cases tab will load data with the Unassigned Cases section
   * The available queues in the system will show up as a dropdown
   * The selected queue name will show up in the dropdown title.
   * Only the tickets belonging to the selected queue will show up in the Unassigned Cases section.
   * Unassigned tickets count will show as count of tickets belonging to the selected queue of the total cases.
   */
  it('C48: Console - New Tickets -> Unassigned Cases -> Filtering by Queue', { tags: 'Console' }, () => {
    consolePage.timeFilterButton().click().contains('Last 7 days').click();
    consolePage.newCasesTab().scrollIntoView().click({ force: true });
    cy.waitForLoaders();
    consolePage
      .unassignedCaseCount()
      .text()
      .then((totalUnassignedCases) => {
        consolePage.unassignedCasesQueuesDropdownTrigger().click();
        consolePage
          .unassignedCasesCrmQueueDropdownOptions()
          .eq(1)
          .click()
          .then(($q) => {
            const queueName = $q.text();
            consolePage.unassignedCaseCount().should('not.have.text', totalUnassignedCases);
            consolePage.unassignedCaseListItemQueue().eq(0).should('contain', queueName);
          });
      });
  });
});
