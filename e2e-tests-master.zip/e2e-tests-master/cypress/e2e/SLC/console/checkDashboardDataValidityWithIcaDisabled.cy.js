import { consolePage, navBar } from '../../../pages';
import { urlHelpers } from '../../../utils';

// Skipping Enable Disable module test cases
describe.skip('Console', () => {
  beforeEach(() => {
    cy.loginByApi();

    cy.slcHelpers.disableModule('caseAssignment');
    cy.visit(urlHelpers.console.tabsWithTimeFilterLastSevenDays.newCases);
  });

  afterEach(() => cy.slcHelpers.enableModule('caseAssignment'));

  it('C2331: ICA_disabled_dashboard_shows_correct_value', { tags: ['@EnableDisableLockTests', '@NotThreadSafe'] }, () => {
    navBar.assignmentBoard().should('not.exist');

    consolePage.newCasesUnassignedLabel().then((caseCount) => {
      const unassignedCount = caseCount.text();
      const reg = /\d+/;
      const count1 = parseInt(unassignedCount.match(reg), 10);
      consolePage
        .newCasesTabHeaderList()
        .first()
        .then((cases) => {
          const count = cases.text();
          const reg1 = /\d+/;
          const count2 = parseInt(count.match(reg1), 10);
          expect(count1).to.equal(count2);
        });
    });

    cy.slcHelpers.enableModule('caseAssignment');
    cy.reload();

    navBar.assignmentBoard().should('exist');
    consolePage.newCasesUnassignedLabel().then((caseCount) => {
      const unassignedCount = caseCount.text();
      const reg = /\d+/;
      const count1 = parseInt(unassignedCount.match(reg), 10);
      consolePage
        .newCasesTabHeaderList()
        .first()
        .then((cases) => {
          const count = cases.text();
          const reg1 = /\d+/;
          const count2 = parseInt(count.match(reg1), 10);
          expect(count1).to.equal(count2);
        });
    });
  });
});
