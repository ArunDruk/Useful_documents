import { urlHelpers } from '../../../utils';
import { consolePage, globalSearch, navBar, preferences, supportHub } from '../../../pages';

describe('Console Tests', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.console.withTimeFilter.lastSevenDays);
  });

  // Smoke & Sanity C8
  it('C8: Page Load', { tags: 'Console' }, () => {
    consolePage.newCasesTab().should('exist');
  });

  // Smoke & Sanity C42
  it('C42: Console - New Tickets (Opened, Assigned)', { tags: 'Console' }, () => {
    consolePage.newCasesTab().click({ force: true });
    cy.waitForLoaders();
    // Verify Assigned Cases tab is visible
    consolePage.newCasesTabHeaderList().contains('Assigned Cases');
    // In Assigned Cases - Select the Dropdown value as Closed and verify the values
    consolePage
      .assignedCasesDropdown()
      .eq(0)
      .should('be.visible')
      .then((labelName) => {
        const drpdwnValue = labelName.text();
        if (drpdwnValue === 'closed') {
          consolePage.assignedCasesDropdown().eq(0).should('be.visible').contains('Closed');
          // In Assigned Cases - Verify the Charts
          consolePage.assignedCasesContainer().eq(0).should('be.visible');
        } else {
          consolePage.assignedCasesDropdown().eq(0).should('be.visible').click();
          consolePage.assignedCasesDropdownOptionClosed().eq(0).should('be.visible').click();
          consolePage.assignedCasesDropdown().eq(0).should('be.visible').contains('Closed');
          // In Assigned Cases - Verify the Charts
          consolePage.assignedCasesContainer().eq(0).should('be.visible');
        }
      });
    // In Assigned Cases - Select the Dropdown value as Opened and Verify the value
    consolePage
      .assignedCasesDropdown()
      .eq(0)
      .should('be.visible')
      .then((labelName) => {
        const drpdwnValue = labelName.text();
        if (drpdwnValue === 'Open') {
          consolePage.assignedCasesDropdown().eq(0).should('be.visible').contains('Open');
          // In Assigned Cases - Verify the Charts
          consolePage.assignedCasesContainer().eq(0).should('be.visible');
        } else {
          cy.reload();
          consolePage.assignedCasesDropdown().eq(0).should('be.visible').click();
          consolePage.assignedCasesDropdownOptionOpened().eq(0).should('be.visible').click();
          consolePage.assignedCasesDropdown().eq(0).should('be.visible').contains('Open');
          // In Assigned Cases - Verify the Charts
          consolePage.assignedCasesContainer().eq(0).should('be.visible');
        }
      });

    // Verify Case Distribution tab is visible
    consolePage.caseDistributionLabel().contains('Case Distribution');
    // In Case Distribution - Select the Dropdown value as Closed and verify the values
    consolePage
      .assignedCasesDropdown()
      .eq(1)
      .should('be.visible')
      .then((labelName) => {
        const drpdwnValue = labelName.text();
        if (drpdwnValue === 'closed') {
          consolePage.assignedCasesDropdown().eq(1).should('be.visible').contains('Closed');
          // In Assigned Cases - Verify the Charts
          consolePage.assignedCasesContainer().eq(1).should('be.visible');
        } else {
          consolePage.assignedCasesDropdown().eq(1).should('be.visible').click();
          consolePage.assignedCasesDropdownOptionClosed().eq(1).should('be.visible').click();
          consolePage.assignedCasesDropdown().eq(1).should('be.visible').contains('Closed');
          // In Assigned Cases - Verify the Charts
          consolePage.assignedCasesContainer().eq(1).should('be.visible');
        }
      });
    // In Case Distribution - Select the Dropdown value as Opened and Verify the value
    consolePage
      .assignedCasesDropdown()
      .eq(1)
      .should('be.visible')
      .then((labelName) => {
        const drpdwnValue = labelName.text();
        if (drpdwnValue === 'Open') {
          consolePage.assignedCasesDropdown().eq(1).should('be.visible').contains('Open');
          // In Assigned Cases - Verify the Charts
          consolePage.assignedCasesContainer().eq(1).should('be.visible');
        } else {
          consolePage.assignedCasesDropdown().eq(1).should('be.visible').click();
          consolePage.assignedCasesDropdownOptionOpened().eq(1).should('be.visible').click();
          consolePage.assignedCasesDropdown().eq(1).should('be.visible').contains('Open');
          // In Assigned Cases - Verify the Charts
          consolePage.assignedCasesContainer().eq(1).should('be.visible');
        }
      });
  });

  // Regression C70
  it('C70: Check the search functionality of tickets', { tags: 'Console' }, () => {
    consolePage.newCasesTab().click({ force: true });
    consolePage.newCasesTab().should('be.visible');
    // Verify the Search with valid Ticket Name
    globalSearch.globalSearchButton().click();
    globalSearch.globalSearchInput().type('12');
    globalSearch.globalSearchResultListItem().eq(0).click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(3000);
    supportHub.baseContainer().should('be.visible');
    supportHub.closeButton().should('be.visible').click();
    supportHub.baseContainer().should('not.exist');
    // Verify the Search with Invalid Ticket Name
    globalSearch.globalSearchButton().click();
    globalSearch.globalSearchInput().type('xyz1234');
    globalSearch.globalSearchResultListItem().should('not.exist');
    globalSearch.noResultsFoundLabel().should('have.text', 'No results found');
  });

  // Regression C6420
  it('C6420: Check if data sync happening in the dashboard', { tags: 'Console' }, () => {
    consolePage.newCasesTab().click({ force: true });
    consolePage.newCasesTab().should('be.visible');
    // Verify the data sync time is showing up in green color
    preferences.userMenuButton().click();
    preferences.dataSyncStatus().should('have.css', 'background-color').and('eq', 'rgb(133, 210, 111)');
    // Verify the data sync is not showing in red colour in the left Navbar
    navBar.dataSyncStatus().should('not.exist');
  });

  /**
   * Regression C287
   * - Select the timefilter as last 7 days to avoid no cases
   * - Click on the Negative Sentiments tab
   * - Verify the case card is visible and then verify the share icon and its hover tooltip is visible by mouse hover on the first case card
   * - Click on the first case card and verify the share tooltip is not displayed on hovering on share icon in the SH
   * - Click on the share icon in the SH and verify the assigned agent mail is displaying in the recipient field.
   * - Close the Share and SupportHub popup
   */
  it('C287: Case Sharing', { tags: ['Console', 'staging', 'prod'] }, () => {
    cy.waitForLoaders();
    consolePage.timeFilterButton().click().contains('Last 7 days').click();
    consolePage.negativeSentimentsTab().click();
    cy.waitForLoaders();
    // Selecting the Agent in GroupBy dropdown
    consolePage.sentimentsGroupbyButton().then((groupValue) => {
      if (groupValue.text() !== 'Agent') {
        consolePage.sentimentsGroupbyButton().click();
        consolePage.sentimentsGroupByDrodownOptionAgent().click();
        consolePage.consoleHeader().click();
      }
    });
    consolePage.expandAllConsoleLists();
    cy.waitForLoaders();
    consolePage
      .caseCard()
      .eq(0)
      .should('be.visible')
      .then(() => {
        consolePage.caseCard().eq(0).scrollIntoView().trigger('mouseover');
        consolePage.caseCardShareTooltip().invoke('text').should('contain', 'Share');
        consolePage.caseCard().eq(0).click();
        cy.waitForLoaders();
        supportHub.supportHubShareIcon().should('be.visible').trigger('mouseover');
        consolePage.caseCardShareTooltip().should('not.be.visible');
        supportHub.supportHubShareIcon().click();
        supportHub.supportHubSharePopupAssignedAgentMailLabel().should('exist');
        supportHub.sharePopupCloseButton().click();
        supportHub.closeButton();
      });
  });

  /**
   * Regression C9137
   * - Select the timefilter as last 7 days to avoid no cases
   * - Click on the Positive Sentiment tab
   * - Verify the GroupBy, Signal and Acknowledge dropdown are displaying
   * - Verify the Customer Name, CaseId,Detected Sentiment, Detected Sentiment Comments, Agent Icon are displaying
   * - Verify the Agent headset icon is displaying if the detected sentiment comment is in Outbound message
   */
  it('C9137: Make sure agent and reporter icons are showing correctly on the sentiment cards.', { tags: ['Console', 'staging', 'prod'] }, () => {
    cy.waitForLoaders();
    consolePage.timeFilterButton().click().contains('Last 7 days').click();
    consolePage.positiveSentimentsTab().click();
    cy.waitForLoaders();
    consolePage.positiveSentimentsTab().should('be.visible');
    consolePage.sentimentsGroupbyButton().should('be.visible');
    consolePage.sentimentSignalsdropdown().should('exist');
    consolePage.acknowledgeDropdown().should('exist');
    consolePage.collapseExpandButton().should('exist');
    consolePage.expandAllConsoleLists();
    consolePage.caseListCustomerName().should('exist');
    consolePage.caseCardTicketIdLabel().should('exist');
    consolePage.caseCardDetectedSentimentLabel().should('exist');
    consolePage.caseCardDetectedSentimentCommentsLabel().should('exist');
    consolePage.caseCardAgentAvatarIcon().should('exist');
    consolePage
      .caseCard()
      .should('be.visible')
      .then(($ele) => {
        if ($ele.find('[data-icon="headset-frame"]').length > 0) {
          consolePage.caseCardAgentHeadsetIcon().should('exist');
        }
      });
  });
});
