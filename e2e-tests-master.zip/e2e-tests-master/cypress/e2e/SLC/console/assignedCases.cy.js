import { consolePage, globalFilters } from '../../../pages';
import { urlHelpers } from '../../../utils';

describe('Console - Assigned Cases', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.console.home);
  });

  afterEach(() => {
    cy.slcHelpers.clearAgentsQuickFilter();
    cy.slcHelpers.clearCaseFieldQuickFilter();
  });
  /*
   * "No Unassigned Cases !" placeholder message should be displayed. in the Unassigned Cases section.
   */
  it('C6280: Verify the display of placeholder message under "Unassigned cases" section', { tags: ['@FilterTests', 'Console'] }, () => {
    consolePage.timeFilterButton().click().contains('Last 7 days').click();
    consolePage.newCasesTab().click();
    globalFilters.filterButton().click();
    globalFilters.quickFilterDropdown().click();
    globalFilters.quickFilterAgentLink().click();
    globalFilters.quickFilterSearchFieldInput().click().type('a');
    globalFilters.quickFilterSearchResultList().first().click();
    globalFilters.filterApplyButton().click();
    consolePage.noUnassignedCases().should('be.visible').should('contain', 'No Unassigned Cases !');
  });

  /**
   * Regression C43
   * - Select the timefilter as last 7 days to avoid no cases
   * - Click on the New Cases tab
   * - Click on the Status dropdown and select Open if Status value is Closed
   * - Verify the Assigned Cases tab title text have the case count
   * - Click on Filter and apply a quick filter with case fields Priority Medium
   * - Verify the Assigned Cases tab title text after applying filter gets updated based on filter selection
   */
  it('C43: Console - New Tickets -> Assigned Cases -> Open filter', { tags: ['@FilterTests', 'Console', 'staging'] }, () => {
    cy.waitForLoaders();
    consolePage.timeFilterButton().click().contains('Last 7 days').click();
    consolePage.newCasesTab().click();
    cy.waitForLoaders();
    consolePage
      .assignedCasesDropdown()
      .eq(0)
      .should('be.visible')
      .then((labelName) => {
        const drpdwnValue = labelName.text().trim();
        if (drpdwnValue === 'Closed') {
          consolePage.assignedCasesDropdown().eq(0).should('be.visible').click();
          consolePage.assignedCasesDropdownOptionOpened().eq(0).should('be.visible').click();
          consolePage.assignedCasesDropdown().eq(0).should('contain', 'Open');
          cy.waitForLoaders();
        }
      });
    consolePage
      .newCasesTabHeaderList()
      .contains('Assigned Cases')
      .then((bfrvalue) => {
        const beforevalue = bfrvalue.text().split('Export as...')[0];
        // selecting the quick filter case fields-Medium
        globalFilters.filterByPriorityCaseField('Medium');
        globalFilters.filterButton().click();
        cy.waitForLoaders();
        consolePage
          .newCasesTabHeaderList()
          .eq(1)
          .then((aftvalue) => {
            const aftervalue = aftvalue.text().split('Export as...')[0];
            expect(aftervalue).not.equal(beforevalue);
          });
      });
  });

  /**
   * Regression C6279
   * - Select the timefilter as last 7 days to avoid no cases
   * - Click on the New Cases tab
   * - Verify the Unassigned Case Count is not displaying as zero
   * - Select an agent name in the quick filter
   * - Verify the Unassinged Cases tab is showing with text message No unassigned cases
   * - Verify the Unassigned Cases count is displaying as Zero in the Header
   */
  it('C6279: Check empty state of the Unassigned tickets section', { tags: ['@FilterTests', 'Console'] }, () => {
    cy.waitForLoaders();
    consolePage.timeFilterButton().click().contains('Last 7 days').click();
    consolePage.newCasesTab().click();
    cy.waitForLoaders();
    consolePage.newCasesTabHeaderList().contains('Unassigned Cases').invoke('text').should('not.contain', '(0)');
    globalFilters.selectAgentInQuickFilter('a');
    globalFilters.filterButton().click();
    cy.waitForLoaders();
    consolePage.noUnassignedCases().should('be.visible').should('contain', 'No Unassigned Cases !');
    consolePage.newCasesTabHeaderList().contains('Unassigned Cases').invoke('text').should('contain', 'Unassigned Cases (0)');
  });
});
