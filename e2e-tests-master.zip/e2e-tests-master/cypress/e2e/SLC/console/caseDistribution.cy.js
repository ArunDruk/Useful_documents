import { apiHelpers, globalFilters, consolePage } from '../../../pages';
import { urlHelpers } from '../../../utils';

describe('Console - Case Distribution', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.console.home);
  });

  afterEach(() => {
    apiHelpers.removeDynamicFilterConsolePage();
    cy.slcHelpers.clearCaseFieldQuickFilter();
  });
  /*
   * If the user tries to click on the filter "Assigned" in the Ticket Distribution section
   * then the bar chart should show hide the assigned ticket
   * and should only show the tickets which are "Unassigned".
   */
  it('C54: Console - New Tickets -> Case Distribution (Assigned)', { tags: 'Console' }, () => {
    consolePage.timeFilterButton().click().contains('Last 7 days').click();
    cy.waitForLoaders();
    consolePage.newCasesTab().click();
    cy.waitForLoaders();
    consolePage.newCasesAssignedLabel().invoke('attr', 'data-testid').should('contain', 'enabled');
    consolePage.newCasesAssignedLabel().find('svg').invoke('attr', 'data-icon').should('eq', 'round-check');
    consolePage.newCasesUnassignedLabel().invoke('attr', 'data-testid').should('contain', 'enabled');
    consolePage.newCasesUnassignedLabel().find('svg').invoke('attr', 'data-icon').should('eq', 'round-check');
    consolePage.newCasesAssignedLabel().click();
    consolePage.newCasesAssignedLabel().invoke('attr', 'data-testid').should('contain', 'disabled');
    consolePage.newCasesUnassignedLabel().invoke('attr', 'data-testid').should('contain', 'enabled');
    consolePage.newCasesUnassignedLabel().find('svg').invoke('attr', 'data-icon').should('eq', 'round-check');
  });

  /*
   * If the user tries to click on the filter "Unassigned" in the Ticket Distribution section
   * then the bar chart should show hide the unassigned ticket
   * and should only show the tickets which are "Assigned".
   */
  it('C55: Console - New Tickets -> Case Distribution (Unassigned)', { tags: 'Console' }, () => {
    consolePage.timeFilterButton().click().contains('Last 7 days').click();
    cy.waitForLoaders();
    consolePage.newCasesTab().click();
    cy.waitForLoaders();
    consolePage.newCasesAssignedLabel().invoke('attr', 'data-testid').should('contain', 'enabled');
    consolePage.newCasesAssignedLabel().find('svg').invoke('attr', 'data-icon').should('eq', 'round-check');
    consolePage.newCasesUnassignedLabel().invoke('attr', 'data-testid').should('contain', 'enabled');
    consolePage.newCasesUnassignedLabel().find('svg').invoke('attr', 'data-icon').should('eq', 'round-check');
    consolePage.newCasesUnassignedLabel().click();
    consolePage.newCasesUnassignedLabel().invoke('attr', 'data-testid').should('contain', 'disabled');
    consolePage.newCasesAssignedLabel().invoke('attr', 'data-testid').should('contain', 'enabled');
    consolePage.newCasesAssignedLabel().find('svg').invoke('attr', 'data-icon').should('eq', 'round-check');
  });

  /**
   * Regression C45
   * - Select the timefilter as last 7 days to avoid no cases
   * - Click on the New Cases tab
   *  - Verify the CaseDistribution tab Unassigned Label case count
   * - Click on the Status dropdown and select Closed if Status value is Open,vice versa
   * - Verify the CaseDistribution tab Unassigned Label case count gets updated based on status selection
   */
  it('C45: Console - New Tickets -> Case Distribution -> Closed filter', { tags: ['Console', 'staging'] }, () => {
    cy.waitForLoaders();
    consolePage.timeFilterButton().click().contains('Last 7 days').click();
    consolePage.newCasesTab().click();
    cy.waitForLoaders();
    consolePage.caseDistributionUnassignedLabel().then((bfrvalue) => {
      const beforevalue = bfrvalue.text();
      consolePage
        .assignedCasesDropdown()
        .eq(1)
        .should('be.visible')
        .then((labelName) => {
          const drpdwnValue = labelName.text().trim();

          consolePage.assignedCasesDropdown().eq(1).should('be.visible').click();
          if (drpdwnValue === 'Open') {
            consolePage.assignedCasesDropdownOptionClosed().eq(1).should('be.visible').click();
            consolePage.assignedCasesDropdown().eq(1).should('contain', 'Closed');
          } else {
            consolePage.assignedCasesDropdownOptionOpened().eq(1).should('be.visible').click();
            consolePage.assignedCasesDropdown().eq(1).should('contain', 'Open');
          }
          cy.waitForLoaders();
        });
      consolePage.caseDistributionUnassignedLabel().then((aftvalue) => {
        const aftervalue = aftvalue.text();
        expect(aftervalue).not.equal(beforevalue);
      });
    });
  });

  /**
   * Regression C46
   * - Select the timefilter as last 7 days to avoid no cases
   * - Click on the New Cases tab
   * - Click on the Status dropdown and select Open if Status value is Closed
   * - Verify the CaseDistribution tab Unassigned Label case count
   * - Click on Filter and apply a quick filter with case fields Priority Medium
   * - Verify the CaseDistribution tab Unassigned Label case count after applying filter gets updated based on filter selection
   */
  it('C46: Console - New Tickets -> Case Distribution -> Open filter', { tags: ['@FilterTests', 'Console', 'staging'] }, () => {
    cy.waitForLoaders();
    consolePage.timeFilterButton().click().contains('Last 7 days').click();
    consolePage.newCasesTab().click();
    cy.waitForLoaders();
    consolePage
      .assignedCasesDropdown()
      .eq(1)
      .should('be.visible')
      .then((labelName) => {
        const drpdwnValue = labelName.text().trim();
        if (drpdwnValue === 'Closed') {
          consolePage.assignedCasesDropdown().eq(1).should('be.visible').click();
          consolePage.assignedCasesDropdownOptionOpened().eq(1).should('be.visible').click();
          consolePage.assignedCasesDropdown().eq(1).should('contain', 'Open');
          cy.waitForLoaders();
        }
      });
    consolePage.caseDistributionUnassignedLabel().then((bfrvalue) => {
      const beforevalue = bfrvalue.text();
      // selecting the quick filter case fields-Medium
      globalFilters.filterByPriorityCaseField('Medium');
      globalFilters.filterButton().click();
      cy.waitForLoaders();
      consolePage.caseDistributionUnassignedLabel().then((aftvalue) => {
        const aftervalue = aftvalue.text();
        expect(aftervalue).not.equal(beforevalue);
      });
    });
  });
});
