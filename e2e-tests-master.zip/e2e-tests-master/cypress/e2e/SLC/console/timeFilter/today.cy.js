import { consolePage } from '../../../../pages';
import { urlHelpers } from '../../../../utils';

beforeEach(() => {
  cy.loginByApi();
  cy.visit(urlHelpers.console.home);
});

describe('console_suite', () => {
  it('C29: Checking the functionality of Time filter present in this page (Today)', { tags: 'Console' }, () => {
    consolePage.timeFilterButton().click().contains('Today').click();
    consolePage
      .positiveSentimentsTab()
      .invoke('text')
      .then((text) => {
        if (!text.includes('No Signals')) {
          consolePage.positiveSentimentsTab().click({ force: true });
          consolePage.sentimentsGroupbyButton().click();
          cy.contains('Elapsed Time').click();
          consolePage.showAllDropdown().click();
          cy.contains('Show all').click();
          consolePage.collapseExpandButton().then((buttonText) => {
            const textmsg = buttonText.text();
            if (textmsg === 'Collapse All') {
              consolePage.collapseExpandButton().click().invoke('text').should('be.equal', 'Expand All');
            }
            consolePage.sentimentsTabHeaderList().last().invoke('text').should('include', 'Earlier Today');
            consolePage.sentimentsTabHeaderList().last().click();
            consolePage.caseCard().first().invoke('text').should('include', 'hour');
          });
        }
      });

    consolePage.timeFilterButton().click().contains('Today').click();
    consolePage
      .negativeSentimentsTab()
      .invoke('text')
      .then((text) => {
        if (!text.includes('No Signals')) {
          consolePage.negativeSentimentsTab().click({ force: true });
          consolePage.sentimentsGroupbyButton().click();
          cy.contains('Elapsed Time').click();
          consolePage.showAllDropdown().click();
          cy.contains('Show all').click();
          consolePage.collapseExpandButton().then((buttonText) => {
            const textmsg = buttonText.text();
            if (textmsg === 'Collapse All') {
              consolePage.collapseExpandButton().click().invoke('text').should('be.equal', 'Expand All');
            }
            consolePage.sentimentsTabHeaderList().last().invoke('text').should('include', 'Earlier Today');
            consolePage.sentimentsTabHeaderList().last().click();
            consolePage.caseCard().first().invoke('text').should('include', 'hour');
          });
        }
      });

    consolePage.timeFilterButton().click().contains('Today').click();
    consolePage
      .needAttentionTab()
      .invoke('text')
      .then((text) => {
        if (!text.includes('No Signals')) {
          consolePage.needAttentionTab().click({ force: true });
          consolePage.sentimentsGroupbyButton().click();
          cy.contains('Elapsed Time').click();
          consolePage.showAllDropdown().click();
          cy.contains('Show all').click();
          consolePage.collapseExpandButton().then((buttonText) => {
            const textmsg = buttonText.text();
            if (textmsg === 'Collapse All') {
              consolePage.collapseExpandButton().click().invoke('text').should('be.equal', 'Expand All');
            }
            consolePage.sentimentsTabHeaderList().last().invoke('text').should('include', 'Earlier Today');
            consolePage.sentimentsTabHeaderList().last().click();
            consolePage.caseCard().first().invoke('text').should('include', 'hour');
          });
        }
      });
  });
});
