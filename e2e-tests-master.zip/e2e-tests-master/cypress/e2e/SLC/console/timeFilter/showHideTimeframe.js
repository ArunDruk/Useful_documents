import { urlHelpers } from '../../../../utils';

const disableTimeframe = (timeFrame) =>
  cy.request({
    method: 'POST',
    url: '/api/company/settings/support',
    headers: { 'Content-Type': 'application/json' },
    body: {
      settings: { dashboard_restrictions: { console_time_frames: { [timeFrame]: false } }, replace: false, keys: ['dashboard_restrictions', 'console_time_frames', { timeFrame }] },
    },
  });

const enableTimeframe = (timeFrame) =>
  cy.request({
    method: 'POST',
    url: '/api/company/settings/support',
    headers: { 'Content-Type': 'application/json' },
    body: {
      settings: { dashboard_restrictions: { console_time_frames: { [timeFrame]: true } }, replace: false, keys: ['dashboard_restrictions', 'console_time_frames', { timeFrame }] },
    },
  });

beforeEach(() => {
  cy.loginByApi();
  cy.visit(urlHelpers.console.home);
});

describe('console_test_suite', () => {
  it('C36: show_hide_time_frame', { tags: 'Console' }, () => {
    disableTimeframe('today');
    cy.reload();
    cy.getByTestId('consolePage-filters-timeFilter').click().should('not.contain', 'Today');
    enableTimeframe('today');
    cy.reload();
    cy.getByTestId('consolePage-filters-timeFilter').click().contains('Today').click();
    disableTimeframe('week');
    cy.reload();
    cy.getByTestId('consolePage-filters-timeFilter').click().should('not.contain', 'Last 7 days');
    enableTimeframe('week');
    cy.reload();
    cy.getByTestId('consolePage-filters-timeFilter').click().contains('Last 7 days').click();
    disableTimeframe('yesterday');
    cy.reload();
    cy.getByTestId('consolePage-filters-timeFilter').click().should('not.contain', 'Since yesterday');
    enableTimeframe('yesterday');
    cy.reload();
    cy.getByTestId('consolePage-filters-timeFilter').click().should('contain', 'Since yesterday');
  });
});
