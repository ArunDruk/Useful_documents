import { urlHelpers } from '../../../../utils';
import { consolePage } from '../../../../pages';

beforeEach(() => {
  cy.loginByApi();
  cy.visit(urlHelpers.console.home);
  cy.waitForLoaders();
});

describe('console_suite', () => {
  it('C31: Checking the functionality of Time filter present in this page (Last 7 Days)', { tags: 'Console' }, () => {
    consolePage.timeFilterButton().click().contains('Last 7 days').click();
    consolePage.negativeSentimentsTab().scrollIntoView().click({ force: true });
    consolePage.sentimentsGroupbyButton().click();
    cy.contains('Elapsed Time').click();
    consolePage.showAllDropdown().click();
    cy.contains('Show all').click();
    consolePage.collapseExpandButton().then((buttonText) => {
      const textmsg = buttonText.text();
      if (textmsg === 'Collapse All') {
        consolePage.collapseExpandButton().click().invoke('text').should('be.equal', 'Expand All');
      }
      consolePage.sentimentsTabHeaderList().last().invoke('text').should('include', '6 Days Ago');
      consolePage.sentimentsTabHeaderList().last().click();
      consolePage.caseCard().first().invoke('text').should('include', '6 days ago');
    });

    consolePage.timeFilterButton().click().contains('Last 7 days').click();
    consolePage.needAttentionTab().scrollIntoView().click({ force: true });
    consolePage.sentimentsGroupbyButton().click();
    cy.contains('Elapsed Time').click();
    consolePage.showAllDropdown().click();
    cy.contains('Show all').click();
    consolePage.collapseExpandButton().then((buttonText) => {
      const textmsg = buttonText.text();
      if (textmsg === 'Collapse All') {
        consolePage.collapseExpandButton().click().invoke('text').should('be.equal', 'Expand All');
      }
      consolePage.sentimentsTabHeaderList().last().invoke('text').should('include', '6 Days Ago');
      consolePage.sentimentsTabHeaderList().last().click();
      consolePage.caseCard().first().invoke('text').should('include', '6 days ago');
    });
  });
});
