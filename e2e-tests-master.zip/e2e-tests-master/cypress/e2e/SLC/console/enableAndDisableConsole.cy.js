import { commonElements, consolePage } from '../../../pages';
import { urlHelpers } from '../../../utils';

beforeEach(() => {
  cy.loginByApi();
});

// Skipping Enable Disable module test cases
describe.skip('Enable and Disable Console Tests', () => {
  after(() => {
    cy.slcHelpers.enableModule('console');
    consolePage.navigationConsole().should('exist');
  });

  /**
   * Regression C33
   * Go to settings page and click on production Edition(SL Admins). Click on disable the console page . Go back to console page.
   */
  it('C33: Checking the functionality of edition builter for access type in settings page for console (Disable)', { tags: ['@EnableDisableLockTests', '@NotThreadSafe'] }, () => {
    cy.slcHelpers.disableModule('console');
    cy.visit(urlHelpers.console.home);
    commonElements.appWrapper().invoke('text').should('include', 'Console module is disabled for you');
    consolePage.navigationConsole().should('not.exist');
  });

  /**
   * Regression C35
   * Go to settings page and click on production Edition(SL Admins). Click on 'enable' the console page . Go back to console page.
   */
  it('C35: Checking the functionality of edition builter for access type in settings page for console (Enable)', { tags: ['@EnableDisableLockTests', '@NotThreadSafe'] }, () => {
    cy.slcHelpers.enableModule('console');
    cy.visit(urlHelpers.console.home);
    consolePage.navigationConsole().should('exist');
    consolePage.newCasesTab().should('exist');
  });
});
