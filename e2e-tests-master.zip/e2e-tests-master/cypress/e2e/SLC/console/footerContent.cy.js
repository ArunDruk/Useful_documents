import { consolePage } from '../../../pages';
import { urlHelpers } from '../../../utils';

beforeEach(() => {
  cy.loginByApi();
  cy.slcHelpers.disableAgentsQuickFilter();
  cy.slcHelpers.clearAgentsQuickFilter();
  cy.slcHelpers.deleteGlobalFilter();
  cy.visit(urlHelpers.console.home);
});

describe('Console - Footer Content', () => {
  /*
   * Click the New Cases tab if there are are cases
   * Validate the footer contents
   */
  it('C39: Checking the feature of footer text in the New Cases tab', { tags: 'Console' }, function footerContent() {
    // Today
    consolePage.timeFilterButton().click().contains('Today').click();
    cy.waitForLoaders();
    consolePage.newCasesTab().then(($casesToday) => {
      if ($casesToday.text().includes('No Cases')) {
        cy.log('No new cases');
      } else {
        consolePage.newCasesTab().scrollIntoView().click({ force: true });
        consolePage.newCasesTab().invoke('text').should('include', 'yesterday');

        // Since yesterday
        consolePage.timeFilterButton().click().contains('Since yesterday').click().url().should('include', 'Since+yesterday');
        consolePage.newCasesTab().then(($casesYesterday) => {
          if ($casesYesterday.text().includes('No Cases')) {
            cy.log('No new cases');
          } else {
            consolePage.newCasesTabCount().then(($caseCountYesterday) => {
              const caseCountYesterday = parseInt($caseCountYesterday.text(), 10);
              consolePage.newCasesTab().scrollIntoView().click({ force: true });
              consolePage.newCasesTab().invoke('text').should('include', 'the previous days');

              // Last 7 days
              consolePage.timeFilterButton().click().contains('Last 7 days').click().url().should('include', 'Last+7+days');
              consolePage.newCasesTab().then(($casesLastWeek) => {
                if ($casesLastWeek.text().includes('No Cases')) {
                  cy.log('No new cases');
                } else {
                  consolePage.newCasesTabCount().then(($caseCountLastWeek) => {
                    const caseCountLastWeek = parseInt($caseCountLastWeek.text(), 10);
                    consolePage.newCasesTab().scrollIntoView().click({ force: true });
                    expect(caseCountLastWeek).to.be.greaterThan(caseCountYesterday);
                    consolePage.newCasesTab().invoke('text').should('include', 'the previous 7 days');
                  });
                }
              });
            });
          }
        });
      }
    });
  });

  /*
   * Click the Positive Sentiments tab if there are are cases
   * Validate the footer contents
   */
  it('C9420: Checking the feature of footer text in the Positive Sentiments tab', { tags: 'Console' }, function footerContent() {
    // Today
    consolePage.timeFilterButton().click().contains('Today').click();
    cy.waitForLoaders();
    consolePage.positiveSentimentsTab().then(($casesToday) => {
      if ($casesToday.text().includes('No Signals')) {
        cy.log('No New Signals with Positive Sentiments');
      } else {
        consolePage.positiveSentimentsTab().scrollIntoView().click({ force: true });
        consolePage.positiveSentimentsTab().invoke('text').should('include', 'yesterday');

        // Since yesterday
        consolePage.timeFilterButton().click().contains('Since yesterday').click().url().should('include', 'Since+yesterday');
        consolePage.positiveSentimentsTab().then(($casesYesterday) => {
          if ($casesYesterday.text().includes('No Signals')) {
            cy.log('No New Signals with Positive Sentiments');
          } else {
            consolePage.positiveSentimentsTabCount().then(($caseCountYesterday) => {
              const caseCountYesterday = parseInt($caseCountYesterday.text(), 10);
              consolePage.positiveSentimentsTab().scrollIntoView().click({ force: true });
              consolePage.positiveSentimentsTab().invoke('text').should('include', 'the previous days');

              // Last 7 days
              consolePage.timeFilterButton().click().contains('Last 7 days').click().url().should('include', 'Last+7+days');
              consolePage.positiveSentimentsTab().then(($casesLastWeek) => {
                if ($casesLastWeek.text().includes('No Signals')) {
                  cy.log('No New Signals with Positive Sentiments');
                } else {
                  consolePage.positiveSentimentsTabCount().then(($caseCountLastWeek) => {
                    const caseCountLastWeek = parseInt($caseCountLastWeek.text(), 10);
                    consolePage.positiveSentimentsTab().scrollIntoView().click({ force: true });
                    expect(caseCountLastWeek).to.be.greaterThan(caseCountYesterday);
                    consolePage.positiveSentimentsTab().invoke('text').should('include', 'the previous 7 days');
                  });
                }
              });
            });
          }
        });
      }
    });
  });

  /*
   * Click the Negative Sentiments tab if there are are cases
   * Validate the footer contents
   */
  it('C9421: Checking the feature of footer text in the Negative Sentiments tab', { tags: 'Console' }, function footerContent() {
    // Today
    consolePage.timeFilterButton().click().contains('Today').click();
    cy.waitForLoaders();
    consolePage.negativeSentimentsTab().then(($casesToday) => {
      if ($casesToday.text().includes('No Signals')) {
        cy.log('No New Signals with Negative Sentiments');
      } else {
        consolePage.negativeSentimentsTab().scrollIntoView().click({ force: true });
        consolePage.negativeSentimentsTab().invoke('text').should('include', 'yesterday');

        // Since yesterday
        consolePage.timeFilterButton().click().contains('Since yesterday').click().url().should('include', 'Since+yesterday');
        consolePage.negativeSentimentsTab().then(($casesYesterday) => {
          if ($casesYesterday.text().includes('No Signals')) {
            cy.log('No New Signals with Negative Sentiments');
          } else {
            consolePage.negativeSentimentsTabCount().then(($caseCountYesterday) => {
              const caseCountYesterday = parseInt($caseCountYesterday.text(), 10);
              consolePage.negativeSentimentsTab().scrollIntoView().click({ force: true });
              consolePage.negativeSentimentsTab().invoke('text').should('include', 'the previous days');

              // Last 7 days
              consolePage.timeFilterButton().click().contains('Last 7 days').click().url().should('include', 'Last+7+days');
              consolePage.negativeSentimentsTab().then(($casesLastWeek) => {
                if ($casesLastWeek.text().includes('No Signals')) {
                  cy.log('No New Signals with Negative Sentiments');
                } else {
                  consolePage.negativeSentimentsTabCount().then(($caseCountLastWeek) => {
                    const caseCountLastWeek = parseInt($caseCountLastWeek.text(), 10);
                    consolePage.negativeSentimentsTab().scrollIntoView().click({ force: true });
                    expect(caseCountLastWeek).to.be.greaterThan(caseCountYesterday);
                    consolePage.negativeSentimentsTab().invoke('text').should('include', 'the previous 7 days');
                  });
                }
              });
            });
          }
        });
      }
    });
  });

  /*
   * Click the Need Attention tab if there are are cases
   * Validate the footer contents
   */
  it('C40: Checking the feature of footer text in the Need Attention tab', { tags: 'Console' }, function footerContent() {
    // Today
    consolePage.timeFilterButton().click().contains('Today').click();
    cy.waitForLoaders();
    consolePage.needAttentionTab().then(($casesToday) => {
      if ($casesToday.text().includes('No Signals')) {
        cy.log('No New Signals with Need Attention');
      } else {
        consolePage.needAttentionTab().scrollIntoView().click({ force: true });
        consolePage.needAttentionTab().invoke('text').should('include', 'critical issue');

        // Since yesterday
        consolePage.timeFilterButton().click().contains('Since yesterday').click().url().should('include', 'Since+yesterday');
        consolePage.needAttentionTab().then(($casesYesterday) => {
          if ($casesYesterday.text().includes('No Signals')) {
            cy.log('No New Signals with Need Attention');
          } else {
            consolePage.needAttentionTabCaseCount().then(($caseCountYesterday) => {
              const caseCountYesterday = parseInt($caseCountYesterday.text(), 10);
              consolePage.needAttentionTab().scrollIntoView().click({ force: true });
              consolePage.needAttentionTab().invoke('text').should('include', 'critical issue');

              // Last 7 days
              consolePage.timeFilterButton().click().contains('Last 7 days').click().url().should('include', 'Last+7+days');
              consolePage.needAttentionTab().then(($casesLastWeek) => {
                if ($casesLastWeek.text().includes('No Signals')) {
                  cy.log('No New Signals with Need Attention');
                } else {
                  consolePage.needAttentionTabCaseCount().then(($caseCountLastWeek) => {
                    const caseCountLastWeek = parseInt($caseCountLastWeek.text(), 10);
                    consolePage.needAttentionTab().scrollIntoView().click({ force: true });
                    expect(caseCountLastWeek).to.be.greaterThan(caseCountYesterday);
                    consolePage.needAttentionTab().invoke('text').should('include', 'critical issue');
                  });
                }
              });
            });
          }
        });
      }
    });
  });

  /* // Test Case Added to SLC-Production folder
   * Click the Product feedback tab if there are are cases
   * Validate the footer contents
   */
  it('C41: Checking the feature of footer text in the Product Feedback tab', { tags: 'Console' }, function footerContent() {
    // Today
    consolePage.timeFilterButton().click().contains('Today').click();
    cy.waitForLoaders();
    consolePage.productFeedbackTab().then(($casesToday) => {
      if ($casesToday.text().includes('No Signals')) {
        cy.log('No Signals with Product Feedback');
      } else {
        consolePage.productFeedbackTab().scrollIntoView().click({ force: true });
        consolePage.productFeedbackTab().invoke('text').should('include', 'yesterday');

        // Since yesterday
        consolePage.timeFilterButton().click().contains('Since yesterday').click().url().should('include', 'Since+yesterday');
        consolePage.productFeedbackTab().then(($casesYesterday) => {
          if ($casesYesterday.text().includes('No Signals')) {
            cy.log('No Signals with Product Feedback');
          } else {
            consolePage.productFeedbackTabCount().then(($caseCountYesterday) => {
              const caseCountYesterday = parseInt($caseCountYesterday.text(), 10);
              consolePage.productFeedbackTab().scrollIntoView().click({ force: true });
              consolePage.productFeedbackTab().invoke('text').should('include', 'the previous days');

              // Last 7 days
              consolePage.timeFilterButton().click().contains('Last 7 days').click().url().should('include', 'Last+7+days');
              consolePage.productFeedbackTab().then(($casesLastWeek) => {
                if ($casesLastWeek.text().includes('No Signals')) {
                  cy.log('No Signals with Product Feedback');
                } else {
                  consolePage.productFeedbackTabCount().then(($caseCountLastWeek) => {
                    const caseCountLastWeek = parseInt($caseCountLastWeek.text(), 10);
                    consolePage.productFeedbackTab().scrollIntoView().click({ force: true });
                    expect(caseCountLastWeek).to.be.greaterThan(caseCountYesterday);
                    consolePage.productFeedbackTab().invoke('text').should('include', 'the previous 7 days');
                  });
                }
              });
            });
          }
        });
      }
    });
  });
});
