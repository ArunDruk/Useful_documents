import { urlHelpers } from '../../../utils';
import { consolePage } from '../../../pages';

beforeEach(() => {
  cy.loginByApi();
  cy.visit(urlHelpers.console.withTimeFilter.lastSevenDays);
});

describe('Console Tests - Status Dropdown and Sort Check', () => {
  /**
   * Regression C47
   * If the user try to click on either of the status opened/closed and then just refresh the whole dashboard then the page should open the last selected changes.
   */
  it('C47: Console - New Tickets (refresh)', { tags: ['Console', 'staging', 'prod'] }, () => {
    cy.waitForLoaders();
    consolePage.newCasesTab().click();
    const headerValue = 'Assigned Cases';
    consolePage.newCasesTabHeaderList().contains(headerValue);
    consolePage.selectedStatusDropdown(headerValue).then((statusValue) => {
      const status = statusValue.text();
      consolePage.selectedStatusDropdown(headerValue).click();
      if (status === 'Open ') {
        // selecting the dropdown value as closed if current status is open
        consolePage.selectClosedInStatusDropdown(headerValue).click();
        consolePage.verifyStatusDropdownafterRefresh(headerValue, 'Closed ');
      } else {
        // selecting the dropdown value as open if current status is closed
        consolePage.selectOpenInStatusDropdown(headerValue).click();
        consolePage.verifyStatusDropdownafterRefresh(headerValue, status);
      }
    });
  });

  /**
   * Regression C49
   * If the user clicks on "switch sort direction" button the the ticket order should get reversed and vice versa should be possible.
   */
  // Skipping the issue due to SLC-34079, sort is not working for some dropdown values
  it.skip('C49: Console - New Tickets (Sort direction)', { tags: ['Console', 'staging', 'prod'] }, () => {
    cy.waitForLoaders();
    consolePage.newCasesTab().click();
    cy.waitForLoaders();
    consolePage
      .unassignedCasesSortStatus()
      .invoke('attr', 'data-status')
      .then((sortOrder) => {
        consolePage
          .unassignedCasesCardTitle()
          .eq(0)
          .should('be.visible')
          .then((custName) => {
            const beforeSort = sortOrder;
            const beforesortName = custName.text();
            consolePage.unassignedCasesSortDirection().click();
            cy.waitForLoaders();
            consolePage
              .unassignedCasesCardTitle()
              .eq(0)
              .should('be.visible')
              .then((custName1) => {
                consolePage.unassignedCasesSortStatus().invoke('attr', 'data-status').should('not.eq', beforeSort);
                expect(custName1.text()).not.to.eq(beforesortName);
              });
          });
      });
  });

  /**
   * Regression C2211
   * Test functionality of open status in distribution tab
   */
  it('C2211: Test functionality of open status in distribution tab', { tags: ['Console', 'staging', 'prod'] }, () => {
    cy.waitForLoaders();
    consolePage.newCasesTab().click();
    const headerValue = 'Case Distribution';
    consolePage.newCasesTabHeaderList().contains(headerValue);
    consolePage.selectedStatusDropdown(headerValue).then((statusValue) => {
      const status = statusValue.text();
      consolePage.selectedStatusDropdown(headerValue).click();
      if (status === 'Open ') {
        consolePage.selectedStatusDropdown(headerValue).invoke('text').should('include', status);
      } else {
        consolePage.selectOpenInStatusDropdown(headerValue).click();
        consolePage.selectedStatusDropdown(headerValue).invoke('text').should('include', 'Open ');
      }
    });
  });

  /**
   * Regression C2212
   * Test click on close status in case distribution tab
   */
  it('C2212: Test click on close status in case distribution tab', { tags: ['Console', 'staging', 'prod'] }, () => {
    cy.waitForLoaders();
    consolePage.newCasesTab().click();
    const headerValue = 'Case Distribution';
    consolePage.newCasesTabHeaderList().contains(headerValue);
    consolePage.selectedStatusDropdown(headerValue).then((statusValue) => {
      const status = statusValue.text();
      consolePage.selectedStatusDropdown(headerValue).click();
      if (status === 'Closed ') {
        consolePage.selectedStatusDropdown(headerValue).invoke('text').should('include', status);
      } else {
        consolePage.selectClosedInStatusDropdown(headerValue).click();
        consolePage.selectedStatusDropdown(headerValue).invoke('text').should('include', 'Closed ');
      }
    });
  });
});
