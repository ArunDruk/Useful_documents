import { urlHelpers } from '../../../utils';
import { consolePage, supportHub } from '../../../pages';

describe('Console Tests - GroupBy and Sentiment Signal Dropdown', () => {
  beforeEach(() => {
    cy.loginByApi();
  });

  afterEach(() => {
    consolePage.selectAllSignalsInDropdown();
    consolePage.groupByElapsedTime();
  });

  /**
   * Regression C61
   * - Navigate to the Need Attention tab and verify we have landed in expected tab
   * - Select the Agent in the GroupBy dropdown and verify the tab details are displayed as per GroupedBy
   * - Select the Priority in the GroupBy dropdown and verify the tab details are displayed as per GroupedBy
   * - Select the Elapsed Time in the GroupBy dropdown and verify the tab details are displayed as per GroupedBy
   */
  it('C61: Console - Need Attention tabs - Group By dropdown', { tags: ['Console', 'staging', 'prod'] }, () => {
    cy.visit(urlHelpers.console.tabsWithTimeFilterLastSevenDays.needAttention);
    cy.waitForLoaders();
    consolePage.needAttentionTab().should('be.visible');
    // Selecting the Agent in GroupBy dropdown
    consolePage.sentimentsGroupbyButton().then((groupValue) => {
      if (groupValue.text() !== 'Agent') {
        consolePage.sentimentsGroupbyButton().click();
        consolePage.sentimentsGroupByDrodownOptionAgent().click();
        consolePage.consoleHeader().click();
      }
      consolePage.orderByDropdownSelectName();
      consolePage.expandAllConsoleLists();
      cy.waitForLoaders();
      consolePage.groupByTabs().should('exist');
      consolePage.groupByTabOption('A').should('exist');
      consolePage.caseCard().should('exist');
    });
    // Selecting the Priority in GroupBy dropdown
    consolePage.sentimentsGroupbyButton().click();
    consolePage.sentimentsGroupByDrodownOptionPriority().click();
    consolePage.consoleHeader().click();
    cy.waitForLoaders();
    consolePage.groupByTabs().should('exist');
    consolePage.caseCard().should('exist');
    consolePage.collapseExpandButton().should('not.exist');
    consolePage
      .groupByTabOptionLabel()
      .eq(0)
      .then(($tabName) => {
        const tabName = $tabName.text().split('(')[0];
        consolePage.caseCardPriorityLabel().eq(0).should('have.text', tabName);
      });
    // Selecting the Status in GroupBy dropdown
    consolePage.sentimentsGroupbyButton().click();
    consolePage.sentimentsGroupByDrodownOptionStatus().click();
    consolePage.consoleHeader().click();
    cy.waitForLoaders();
    consolePage.groupByTabs().should('exist');
    consolePage.caseCard().should('exist');
    consolePage.collapseExpandButton().should('not.exist');
    consolePage
      .groupByTabOptionLabel()
      .eq(0)
      .then(($tabName) => {
        const tabName = $tabName.text().split('(')[0];
        consolePage.caseCardStatusLabel().eq(0).should('have.text', tabName);
      });
    // Selecting the Business Hours in GroupBy dropdown
    consolePage.sentimentsGroupbyButton().click();
    consolePage.groupByDropdownOptionBusinessHours().click();
    consolePage.consoleHeader().click();
    cy.waitForLoaders();
    consolePage.groupByTabs().should('exist');
    consolePage.caseCard().should('exist');
    consolePage.collapseExpandButton().should('not.exist');
    // Selecting the Attention Score in GroupBy dropdown
    consolePage.sentimentsGroupbyButton().click();
    consolePage.groupByDropdownOptionAttentionScore().click();
    cy.waitForLoaders();
    consolePage.groupByTabOptionLabel().eq(0).click();
    consolePage.collapseExpandButton().should('not.exist');
    cy.waitForLoaders();
    consolePage
      .groupByTabOptionLabel()
      .eq(0)
      .then(($tabName) => {
        const maxScore = $tabName.text().split('-')[0];
        const minScore = $tabName.text().split('-')[1];
        consolePage.caseCard().eq(0).click();
        cy.waitForLoaders();
        supportHub.baseContainer().should('be.visible');
        supportHub.supportHubAttentionScoreLabel().then(($attnScore) => {
          expect(parseInt($attnScore.text(), 10)).to.be.within(parseInt(minScore, 10), parseInt(maxScore, 10));
          supportHub.closeButton().click();
        });
      });
    // Selecting the Elapsed Time in GroupBy dropdown
    consolePage.groupByElapsedTime();
    cy.waitForLoaders();
    consolePage.expandAllConsoleLists();
    consolePage.groupByTabs().should('not.exist');
    consolePage.caseCard().should('exist');
    consolePage.sentimentsTabHeaderList().should('exist');
  });

  /**
   * Regression C124845
   * - Navigate to the Positive Sentiments tab and verify we have landed in expected tab
   * - Select the Agent in the GroupBy dropdown and verify the tab details are displayed as per GroupedBy
   * - Select the Priority in the GroupBy dropdown and verify the tab details are displayed as per GroupedBy
   * - Select the Elapsed Time in the GroupBy dropdown and verify the tab details are displayed as per GroupedBy
   */
  it('C124845: Console - Positive Sentiments tabs - Group By dropdown', { tags: ['Console', 'staging', 'prod'] }, () => {
    cy.visit(urlHelpers.console.tabsWithTimeFilterLastSevenDays.positiveSentiments);
    cy.waitForLoaders();
    consolePage.positiveSentimentsTab().should('be.visible');
    // Selecting the Agent in GroupBy dropdown
    consolePage.sentimentsGroupbyButton().then((groupValue) => {
      if (groupValue.text() !== 'Agent') {
        consolePage.sentimentsGroupbyButton().click();
        consolePage.sentimentsGroupByDrodownOptionAgent().click();
        consolePage.consoleHeader().click();
      }
      consolePage.orderByDropdownSelectName();
      consolePage.expandAllConsoleLists();
      cy.waitForLoaders();
      consolePage.groupByTabs().should('exist');
      consolePage.groupByTabOption('A').should('exist');
      consolePage.caseCard().should('exist');
    });
    // Selecting the Priority in GroupBy dropdown
    consolePage.sentimentsGroupbyButton().click();
    consolePage.sentimentsGroupByDrodownOptionPriority().click();
    consolePage.consoleHeader().click();
    cy.waitForLoaders();
    consolePage.groupByTabs().should('exist');
    consolePage.caseCard().should('exist');
    consolePage.collapseExpandButton().should('not.exist');
    consolePage
      .groupByTabOptionLabel()
      .eq(0)
      .then(($tabName) => {
        const tabName = $tabName.text().split('(')[0];
        consolePage.caseCardPriorityLabel().eq(0).should('have.text', tabName);
      });
    // Selecting the Status in GroupBy dropdown
    consolePage.sentimentsGroupbyButton().click();
    consolePage.sentimentsGroupByDrodownOptionStatus().click();
    consolePage.consoleHeader().click();
    cy.waitForLoaders();
    consolePage.groupByTabs().should('exist');
    consolePage.caseCard().should('exist');
    consolePage.collapseExpandButton().should('not.exist');
    consolePage
      .groupByTabOptionLabel()
      .eq(0)
      .then(($tabName) => {
        const tabName = $tabName.text().split('(')[0];
        consolePage.caseCardStatusLabel().eq(0).should('have.text', tabName);
      });
    // Selecting the Business Hours in GroupBy dropdown
    consolePage.sentimentsGroupbyButton().click();
    consolePage.groupByDropdownOptionBusinessHours().click();
    consolePage.consoleHeader().click();
    cy.waitForLoaders();
    consolePage.groupByTabs().should('exist');
    consolePage.caseCard().should('exist');
    consolePage.collapseExpandButton().should('not.exist');
    // Selecting the Sentiment Score in GroupBy dropdown
    consolePage.sentimentsGroupbyButton().click();
    consolePage.groupByDropdownOptionSentimentScore().click();
    cy.waitForLoaders();
    consolePage.groupByTabOptionLabel().eq(0).click();
    consolePage.collapseExpandButton().should('not.exist');
    cy.waitForLoaders();
    consolePage
      .groupByTabOptionLabel()
      .eq(0)
      .then(($tabName) => {
        const minScore = $tabName.text().split('-')[0];
        const maxScore = $tabName.text().split('-')[1];
        consolePage.caseCard().eq(0).click();
        cy.waitForLoaders();
        supportHub.baseContainer().should('be.visible');
        supportHub.supportHubSentimentScoreLabel().then(($sentimentScore) => {
          expect(parseInt($sentimentScore.text(), 10)).to.be.within(parseInt(minScore, 10), parseInt(maxScore, 10));
          supportHub.closeButton().click();
        });
      });
    // Selecting the Elapsed Time in GroupBy dropdown
    consolePage.groupByElapsedTime();
    cy.waitForLoaders();
    consolePage.expandAllConsoleLists();
    consolePage.groupByTabs().should('not.exist');
    consolePage.caseCard().should('exist');
    consolePage.sentimentsTabHeaderList().should('exist');
  });

  /**
   * Regression C124846
   * - Navigate to the Negative Sentiments tab and verify we have landed in expected tab
   * - Select the Agent in the GroupBy dropdown and verify the tab details are displayed as per GroupedBy
   * - Select the Priority in the GroupBy dropdown and verify the tab details are displayed as per GroupedBy
   * - Select the Elapsed Time in the GroupBy dropdown and verify the tab details are displayed as per GroupedBy
   */
  it('C124846: Console - Negative Sentiments tabs - Group By dropdown', { tags: ['Console', 'staging', 'prod'] }, () => {
    cy.visit(urlHelpers.console.tabsWithTimeFilterLastSevenDays.negativeSentiments);
    cy.waitForLoaders();
    consolePage.negativeSentimentsTab().should('be.visible');
    // Selecting the Agent in GroupBy dropdown
    consolePage.sentimentsGroupbyButton().then((groupValue) => {
      if (groupValue.text() !== 'Agent') {
        consolePage.sentimentsGroupbyButton().click();
        consolePage.sentimentsGroupByDrodownOptionAgent().click();
        consolePage.consoleHeader().click();
      }
      consolePage.orderByDropdownSelectName();
      consolePage.expandAllConsoleLists();
      cy.waitForLoaders();
      consolePage.groupByTabs().should('exist');
      consolePage.groupByTabOption('A').should('exist');
      consolePage.caseCard().should('exist');
    });
    // Selecting the Priority in GroupBy dropdown
    consolePage.sentimentsGroupbyButton().click();
    consolePage.sentimentsGroupByDrodownOptionPriority().click();
    consolePage.consoleHeader().click();
    cy.waitForLoaders();
    consolePage.groupByTabs().should('exist');
    consolePage.caseCard().should('exist');
    consolePage.collapseExpandButton().should('not.exist');
    consolePage
      .groupByTabOptionLabel()
      .eq(0)
      .then(($tabName) => {
        const tabName = $tabName.text().split('(')[0];
        consolePage.caseCardPriorityLabel().eq(0).should('have.text', tabName);
      });
    // Selecting the Status in GroupBy dropdown
    consolePage.sentimentsGroupbyButton().click();
    consolePage.sentimentsGroupByDrodownOptionStatus().click();
    consolePage.consoleHeader().click();
    cy.waitForLoaders();
    consolePage.groupByTabs().should('exist');
    consolePage.caseCard().should('exist');
    consolePage.collapseExpandButton().should('not.exist');
    consolePage
      .groupByTabOptionLabel()
      .eq(0)
      .then(($tabName) => {
        const tabName = $tabName.text().split('(')[0];
        consolePage.caseCardStatusLabel().eq(0).should('have.text', tabName);
      });
    // Selecting the Business Hours in GroupBy dropdown
    consolePage.sentimentsGroupbyButton().click();
    consolePage.groupByDropdownOptionBusinessHours().click();
    consolePage.consoleHeader().click();
    cy.waitForLoaders();
    consolePage.groupByTabs().should('exist');
    consolePage.caseCard().should('exist');
    consolePage.collapseExpandButton().should('not.exist');
    // Selecting the Sentiment Score in GroupBy dropdown
    consolePage.sentimentsGroupbyButton().click();
    consolePage.groupByDropdownOptionSentimentScore().click();
    cy.waitForLoaders();
    consolePage.groupByTabOptionLabel().eq(0).click();
    cy.waitForLoaders();
    consolePage.collapseExpandButton().should('not.exist');
    consolePage
      .groupByTabOptionLabel()
      .eq(0)
      .then(($tabName) => {
        const minScore = $tabName.text().split('-')[0];
        const maxScore = $tabName.text().split('-')[1];
        consolePage.caseCard().eq(0).click();
        cy.waitForLoaders();
        supportHub.baseContainer().should('be.visible');
        supportHub.supportHubSentimentScoreLabel().then(($sentimentScore) => {
          expect(parseInt($sentimentScore.text(), 10)).to.be.within(parseInt(minScore, 10), parseInt(maxScore, 10));
          supportHub.closeButton().click();
        });
      });
    // Selecting the Elapsed Time in GroupBy dropdown
    consolePage.groupByElapsedTime();
    cy.waitForLoaders();
    consolePage.expandAllConsoleLists();
    consolePage.groupByTabs().should('not.exist');
    consolePage.caseCard().should('exist');
    consolePage.sentimentsTabHeaderList().should('exist');
  });

  /**
   * Regression C64
   * - Navigate to the Need Attention tab and verify we have landed in expected tab
   * - Verify the Sentiment Signal dropdown text is All Signal if not select All in the Dropdown value
   * - Click on Select All Signals and veirfy the data-status is unchecked
   * - Select only one signal value and verify the case card with selected signal alone is displaying
   * - After verify Select All Signals in the Sentiment Signal dropdown
   */
  it('C64: Console - Need Attention tabs - Sentiment Signal filter', { tags: ['Console', 'staging', 'prod'] }, () => {
    cy.visit(urlHelpers.console.tabsWithTimeFilterLastSevenDays.needAttention);
    cy.waitForLoaders();
    consolePage.needAttentionTab().should('be.visible');
    consolePage
      .sentimentSignalsdropdown()
      .should('be.visible')
      .then(($value) => {
        const signalValue = $value.text();
        consolePage.sentimentSignalsdropdown().click();
        if (signalValue !== 'All Signals') {
          consolePage.sentimentSignalsAllCheckBox().click({ force: true }).invoke('attr', 'data-status').should('equal', 'checked');
        }
        consolePage.sentimentSignalsAllCheckBox().click({ force: true }).invoke('attr', 'data-status').should('equal', 'unchecked');
        consolePage
          .sentimentSignalsIndividualNameLabel()
          .eq(0)
          .should('be.visible')
          .then(($name) => {
            const signalName = $name.text();
            consolePage.sentimentSignalsIndividualCheckbox(signalName).eq(0).invoke('attr', 'data-status').should('equal', 'unchecked');
            consolePage.sentimentSignalsIndividualCheckbox(signalName).eq(0).click({ force: true }).invoke('attr', 'data-status').should('equal', 'checked');
            consolePage.sentimentSignalsdropdown().click();
            consolePage.sentimentSignalsdropdown().invoke('text').should('contain', signalName);
            consolePage.caseCardDetectedSentimentLabel().should('contain', signalName);
          });
      });
  });

  /**
   * Regression C124843
   * - Navigate to the Positive Sentiment tab and verify we have landed in expected tab
   * - Verify the Sentiment Signal dropdown text is All Signal if not select All in the Dropdown value
   * - Click on Select All Signals and veirfy the data-status is unchecked
   * - Select only one signal value and verify the case card with selected signal alone is displaying
   * - After verify Select All Signals in the Sentiment Signal dropdown
   */
  it('C124843: Console - Positive Sentiment tabs - Sentiment Signal filter', { tags: ['Console', 'staging', 'prod'] }, () => {
    cy.visit(urlHelpers.console.tabsWithTimeFilterLastSevenDays.positiveSentiments);
    cy.waitForLoaders();
    consolePage.positiveSentimentsTab().should('be.visible');
    consolePage
      .sentimentSignalsdropdown()
      .should('be.visible')
      .then(($value) => {
        const signalValue = $value.text();
        consolePage.sentimentSignalsdropdown().click();
        if (signalValue !== 'All Signals') {
          consolePage.sentimentSignalsAllCheckBox().click({ force: true }).invoke('attr', 'data-status').should('equal', 'checked');
        }
        consolePage.sentimentSignalsAllCheckBox().click({ force: true }).invoke('attr', 'data-status').should('equal', 'unchecked');
        consolePage
          .sentimentSignalsIndividualNameLabel()
          .eq(0)
          .should('be.visible')
          .then(($name) => {
            const signalName = $name.text();
            consolePage.sentimentSignalsIndividualCheckbox(signalName).eq(0).invoke('attr', 'data-status').should('equal', 'unchecked');
            consolePage.sentimentSignalsIndividualCheckbox(signalName).eq(0).click({ force: true }).invoke('attr', 'data-status').should('equal', 'checked');
            consolePage.sentimentSignalsdropdown().click();
            consolePage.sentimentSignalsdropdown().invoke('text').should('contain', signalName);
            consolePage.caseCardDetectedSentimentLabel().should('contain', signalName);
          });
      });
  });

  /**
   * Regression C124844
   * - Navigate to the Negative Sentiment tab and verify we have landed in expected tab
   * - Verify the Sentiment Signal dropdown text is All Signal if not select All in the Dropdown value
   * - Click on Select All Signals and veirfy the data-status is unchecked
   * - Select only one signal value and verify the case card with selected signal alone is displaying
   * - After verify Select All Signals in the Sentiment Signal dropdown
   */
  it('C124844: Console - Negative Sentiment tabs - Sentiment Signal filter', { tags: ['Console', 'staging', 'prod'] }, () => {
    cy.visit(urlHelpers.console.tabsWithTimeFilterLastSevenDays.negativeSentiments);
    cy.waitForLoaders();
    consolePage.negativeSentimentsTab().should('be.visible');
    consolePage
      .sentimentSignalsdropdown()
      .should('be.visible')
      .then(($value) => {
        const signalValue = $value.text();
        consolePage.sentimentSignalsdropdown().click();
        if (signalValue !== 'All Signals') {
          consolePage.sentimentSignalsAllCheckBox().click({ force: true }).invoke('attr', 'data-status').should('equal', 'checked');
        }
        consolePage.sentimentSignalsAllCheckBox().click({ force: true }).invoke('attr', 'data-status').should('equal', 'unchecked');
        consolePage
          .sentimentSignalsIndividualNameLabel()
          .eq(0)
          .should('be.visible')
          .then(($name) => {
            const signalName = $name.text();
            consolePage.sentimentSignalsIndividualCheckbox(signalName).eq(0).invoke('attr', 'data-status').should('equal', 'unchecked');
            consolePage.sentimentSignalsIndividualCheckbox(signalName).eq(0).click({ force: true }).invoke('attr', 'data-status').should('equal', 'checked');
            consolePage.sentimentSignalsdropdown().click();
            consolePage.sentimentSignalsdropdown().invoke('text').should('contain', signalName);
            consolePage.caseCardDetectedSentimentLabel().should('contain', signalName);
          });
      });
  });
});
