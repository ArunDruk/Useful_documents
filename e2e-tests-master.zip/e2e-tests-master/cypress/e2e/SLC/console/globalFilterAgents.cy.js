import { consolePage, globalFilters, supportHub } from '../../../pages';
import { urlHelpers } from '../../../utils';

beforeEach(() => {
  cy.loginByApi();
});

afterEach(() => {
  cy.slcHelpers.disableAgentsQuickFilter();
  cy.slcHelpers.clearAgentsQuickFilter();
  cy.slcHelpers.deleteGlobalFilter();
});

describe('console_test_suite', { tags: '@FilterTests' }, () => {
  //  This will fail if VG/VA is selected in the filters
  //  Todo: This will fixed in QA-790
  it('C9121: global_filter_agents', { tags: 'Console' }, function globalFilterAgent() {
    cy.slcHelpers.disableAgentsQuickFilter();
    cy.slcHelpers.clearAgentsQuickFilter();
    cy.slcHelpers.deleteGlobalFilter();
    cy.visit(urlHelpers.console.home);
    consolePage.timeFilterButton().click().contains('Last 7 days').click();
    consolePage.newCasesTab().click();
    consolePage.groupedByDropdown().eq(2).click();
    cy.contains('Case Volume').click();
    consolePage
      .assignedCasesSortDataStatus()
      .invoke('attr', 'data-status')
      .then((sortOrder) => {
        if (sortOrder === 'asc') {
          consolePage.assignedCasesSortDirection().click();
        }
      });
    consolePage
      .assignedCasesChartListItem()
      .eq(1)
      .invoke('text')
      .then((agentName) => {
        globalFilters.filterButton().invoke('text').should('equal', 'Filter');
        globalFilters.filterButton().click();
        globalFilters.createANewFilterButton().invoke('text').should('include', 'Create a new filter');
        globalFilters.createANewFilterButton().click();
        globalFilters.globalFilterPopup().then(($filterPopup) => {
          globalFilters.acceptWelcomePagePopup($filterPopup);
          globalFilters.commonGlobalFilterTabs('Agents').click();
          globalFilters.globalFilterAgentSearchTextField().eq(1).click().type(agentName).wait(3000);
          // TODO request for Data-testID
          globalFilters
            .globalFilterAgentCaseFields()
            .invoke('text')
            .then((searchResult) => {
              const reg = /We couldn’t find/;
              const found = searchResult.match(reg);
              if (found) {
                this.skip('Agent Not found');
              }
            });
          globalFilters.globalFilterAgentCaseFieldCheckboxes().eq(0).click();
          cy.contains('Create a global filter').click();
          cy.contains('Apply').click();
          globalFilters.globalFilterCloseButton().last().click();
          consolePage.needAttentionTab().click({ force: true });
          consolePage.sentimentsGroupbyButton().click();
          cy.contains('Status').click();
          consolePage.caseCard().first().click();
          supportHub.baseContainer().should('be.visible');
          supportHub.caseOwnerLabel().invoke('text').should('be.equal', agentName);
          supportHub.closeButton().click();
        });
      });
  });
});
