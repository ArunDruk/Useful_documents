import { urlHelpers } from '../../../utils';
import { consolePage } from '../../../pages';

beforeEach(() => {
  cy.loginByApi();
  cy.visit(urlHelpers.console.withTimeFilter.lastSevenDays);
  cy.slcHelpers.clearCustomersQuickFilter();
  cy.slcHelpers.clearAgentsQuickFilter();
  cy.slcHelpers.clearCaseFieldQuickFilter();
  cy.slcHelpers.deleteGlobalFilter();
});

describe('Console Test Suite', () => {
  it('C62: Should verify the functionality of Expand and Collopse button in console tabs', { tags: 'Console' }, () => {
    //  Need Attention
    consolePage.needAttentionTab().click({ force: true });
    consolePage.sentimentsGroupbyButton().click();
    cy.contains('Elapsed Time').click();
    consolePage.showAllDropdown().click();
    cy.contains('Show all').click();
    consolePage.collapseExpandButton().then((buttonText) => {
      const textmsg = buttonText.text();
      if (textmsg === 'Expand All') {
        consolePage.collapseExpandButton().click().invoke('text').should('be.equal', 'Collapse All');
        consolePage.caseCard().eq(0).should('be.visible');
        consolePage.collapseExpandButton().click().invoke('text').should('be.equal', 'Expand All');
      } else {
        consolePage.collapseExpandButton().click().invoke('text').should('be.equal', 'Expand All');
        consolePage.caseCard().should('not.exist');
        consolePage.collapseExpandButton().click().invoke('text').should('be.equal', 'Collapse All');
      }
    });

    //  Positive Sentiments
    consolePage.positiveSentimentsTab().click({ force: true });
    consolePage.sentimentsGroupbyButton().click();
    cy.contains('Elapsed Time').click();
    consolePage.showAllDropdown().click();
    cy.contains('Show all').click();
    consolePage.collapseExpandButton().then((buttonText) => {
      const textmsg = buttonText.text();
      if (textmsg === 'Expand All') {
        consolePage.collapseExpandButton().click().invoke('text').should('be.equal', 'Collapse All');
        consolePage.caseCard().eq(0).should('be.visible');
        consolePage.collapseExpandButton().click().invoke('text').should('be.equal', 'Expand All');
      } else {
        consolePage.collapseExpandButton().click().invoke('text').should('be.equal', 'Expand All');
        consolePage.caseCard().should('not.exist');
        consolePage.collapseExpandButton().click().invoke('text').should('be.equal', 'Collapse All');
      }
    });

    //  Negative Sentiments
    consolePage.negativeSentimentsTab().click({ force: true });
    consolePage.sentimentsGroupbyButton().click();
    cy.contains('Elapsed Time').click();
    consolePage.showAllDropdown().click();
    cy.contains('Show all').click();
    consolePage.collapseExpandButton().then((buttonText) => {
      const textmsg = buttonText.text();
      if (textmsg === 'Expand All') {
        consolePage.collapseExpandButton().click().invoke('text').should('be.equal', 'Collapse All');
        consolePage.caseCard().eq(0).should('be.visible');
        consolePage.collapseExpandButton().click().invoke('text').should('be.equal', 'Expand All');
      } else {
        consolePage.collapseExpandButton().click().invoke('text').should('be.equal', 'Expand All');
        consolePage.caseCard().should('not.exist');
        consolePage.collapseExpandButton().click().invoke('text').should('be.equal', 'Collapse All');
      }
    });

    //  Product Feedback
    consolePage.productFeedbackTab().click({ force: true });
    consolePage.sentimentsGroupbyButton().click();
    cy.contains('Elapsed Time').click();
    consolePage.showAllDropdown().click();
    cy.contains('Show all').click();
    consolePage.collapseExpandButton().then((buttonText) => {
      const textmsg = buttonText.text();
      if (textmsg === 'Expand All') {
        consolePage.collapseExpandButton().click().invoke('text').should('be.equal', 'Collapse All');
        consolePage.caseCard().eq(0).should('be.visible');
        consolePage.collapseExpandButton().click().invoke('text').should('be.equal', 'Expand All');
      } else {
        consolePage.collapseExpandButton().click().invoke('text').should('be.equal', 'Expand All');
        consolePage.caseCard().should('not.exist');
        consolePage.collapseExpandButton().click().invoke('text').should('be.equal', 'Collapse All');
      }
    });
  });

  /**
   * Regression C63
   * - Click on the Need Attention tab
   * - Select the Group By Elapsed Time and verify the Expand All button displaying
   * - Click on the Collapse All button and verify the case card not displaying
   * - Expand the first header list and verify the case card is displaying
   */
  it('C63: Console - Need Attention tabs (Group by) ', { tags: ['Console', 'staging', 'prod'] }, () => {
    //  Need Attention
    consolePage.needAttentionTab().click({ force: true });
    cy.waitForLoaders();
    // Selecting the Elapsed Time in GroupBy dropdown
    consolePage.groupByElapsedTime();
    cy.waitForLoaders();
    consolePage.collapseExpandButton().should('be.visible');
    consolePage.expandAllConsoleLists();
    consolePage.caseCard().should('be.visible');
    consolePage.collapseExpandButton().click().invoke('text').should('be.equal', 'Expand All');
    consolePage.caseCard().should('not.exist');
    consolePage.sentimentsTabHeaderList().eq(0).click();
    cy.waitForLoaders();
    consolePage.caseCard().should('be.visible');
  });

  /**
   * Regression C37849
   *  - Click on the Positive Sentiment tab
   * - Select the Group By Elapsed Time and verify the Expand All button displaying
   * - Click on the Collapse All button and verify the case card not displaying
   * - Expand the first header list and verify the case card is displaying
   */
  it('C37849: Console - Positive Sentiment tabs (Group by) ', { tags: ['Console', 'staging', 'prod'] }, () => {
    //  Positive Sentiments
    consolePage.positiveSentimentsTab().click({ force: true });
    cy.waitForLoaders();
    // Selecting the Elapsed Time in GroupBy dropdown
    consolePage.groupByElapsedTime();
    cy.waitForLoaders();
    consolePage.collapseExpandButton().should('be.visible');
    consolePage.expandAllConsoleLists();
    consolePage.caseCard().should('be.visible');
    consolePage.collapseExpandButton().click().invoke('text').should('be.equal', 'Expand All');
    consolePage.caseCard().should('not.exist');
    consolePage.sentimentsTabHeaderList().eq(0).click();
    cy.waitForLoaders();
    consolePage.caseCard().should('be.visible');
  });

  /**
   * Regression C37850
   *  - Click on the Negative Sentiment tab
   * - Select the Group By Elapsed Time and verify the Expand All button displaying
   * - Click on the Collapse All button and verify the case card not displaying
   * - Expand the first header list and verify the case card is displaying
   */
  it('C37850: Console - Negative Sentiment tabs (Group by)', { tags: ['Console', 'staging', 'prod'] }, () => {
    //  Negative Sentiments
    consolePage.negativeSentimentsTab().click({ force: true });
    // Selecting the Elapsed Time in GroupBy dropdown
    consolePage.groupByElapsedTime();
    cy.waitForLoaders();
    consolePage.collapseExpandButton().should('be.visible');
    consolePage.expandAllConsoleLists();
    consolePage.caseCard().should('be.visible');
    consolePage.collapseExpandButton().click().invoke('text').should('be.equal', 'Expand All');
    consolePage.caseCard().should('not.exist');
    consolePage.sentimentsTabHeaderList().eq(0).click();
    cy.waitForLoaders();
    consolePage.caseCard().should('be.visible');
  });
});
