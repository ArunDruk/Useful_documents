import { consolePage } from '../../../pages';
import { urlHelpers } from '../../../utils';

describe('Console - Unassigned Cases', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.console.home);
  });

  /*
   * Click on the filter "backlog" in the assigned section
   * The bar chart should show hide the backlog ticket and should only show the tickets of "This Period".
   */
  it('C51: Console - New Cases -> Assigned Cases (Backlog - this period)', { tags: 'Console' }, () => {
    consolePage.timeFilterButton().click().contains('Last 7 days').click();
    cy.waitForLoaders();
    consolePage.newCasesTab().click();
    /* 
      As there is no other attribute associated with enabling or disabling of the chart legends,
      the initial and after click class change is compared to make sure that the display style has changed
      along with the updated last chart result 
    */
    consolePage
      .assignedCasesBacklogLegend()
      .invoke('attr', 'class')
      .then((initialBacklogClass) => {
        consolePage.assignedCasesChartListItem().then((initialList) => {
          const initialCount = initialList.length;
          consolePage.assignedCasesBacklogLegend().find('div').first().click();
          consolePage.assignedCasesBacklogLegend().invoke('attr', 'class').should('not.eq', initialBacklogClass);
          consolePage.assignedCasesChartListItem().should('not.have.length', initialCount);
          consolePage.assignedCasesBacklogLegend().find('div').first().click();
          consolePage.assignedCasesBacklogLegend().invoke('attr', 'class').should('eq', initialBacklogClass);
          consolePage
            .assignedCasesThisPeriodLegend()
            .invoke('attr', 'class')
            .then((initialThisPeriodClass) => {
              consolePage.assignedCasesThisPeriodLegend().find('div').first().click();
              consolePage.assignedCasesThisPeriodLegend().invoke('attr', 'class').should('not.eq', initialThisPeriodClass);
              consolePage.assignedCasesThisPeriodLegend().find('div').first().click();
              consolePage.assignedCasesThisPeriodLegend().invoke('attr', 'class').should('eq', initialThisPeriodClass);
            });
        });
      });
  });

  /*
   * If the user deselct a filter then the tickets concerning same should not be visible in the dashboard.
   * If the user selects the filter as "backlog" then the filter of "This period" cannot be deselected and vice versa.
   */
  it('C52: Console - New Cases -> Assigned Cases -> Filtering backlog', { tags: 'Console' }, () => {
    consolePage.timeFilterButton().click().contains('Last 7 days').click();
    consolePage.newCasesTab().click();
    /* 
      As there is no other attribute associated with enabling or disabling of the chart legends,
      the initial and after click class change is compared to make sure that only one legend can be
      selected at a time 
    */
    consolePage
      .assignedCasesBacklogLegend()
      .invoke('attr', 'class')
      .then((initialBacklogClass) => {
        consolePage
          .assignedCasesThisPeriodLegend()
          .invoke('attr', 'class')
          .then((initialThisPeriodClass) => {
            consolePage.assignedCasesChartListItem().then((initialList) => {
              const initialCount = initialList.length;
              cy.log(initialCount);
              consolePage.assignedCasesBacklogLegend().find('div').first().click();
              consolePage.assignedCasesBacklogLegend().invoke('attr', 'class').should('not.eq', initialBacklogClass);
              consolePage.assignedCasesThisPeriodLegend().invoke('attr', 'class').should('eq', initialThisPeriodClass);
              consolePage.assignedCasesChartListItem().should('not.have.length', initialCount);

              consolePage.assignedCasesThisPeriodLegend().find('div').first().click();
              consolePage.assignedCasesBacklogLegend().invoke('attr', 'class').should('not.eq', initialBacklogClass);
              consolePage.assignedCasesThisPeriodLegend().invoke('attr', 'class').should('eq', initialThisPeriodClass);
              consolePage.assignedCasesChartListItem().should('not.have.length', initialCount);

              consolePage.assignedCasesBacklogLegend().find('div').first().click();
              consolePage.assignedCasesBacklogLegend().invoke('attr', 'class').should('eq', initialBacklogClass);
              consolePage.assignedCasesThisPeriodLegend().find('div').first().click();
              consolePage.assignedCasesThisPeriodLegend().invoke('attr', 'class').should('not.eq', initialThisPeriodClass);
            });
          });
      });
  });
});
