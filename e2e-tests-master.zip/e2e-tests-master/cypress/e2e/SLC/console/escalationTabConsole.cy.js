import { consolePage, escalations, globalSearch, supportHub } from '../../../pages';
import { urlHelpers, randId } from '../../../utils';

describe('Console New Escalations Tests', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.console.tabsWithTimeFilterLastSevenDays.newEscalations);
    cy.waitForLoaders();
  });

  /**
   * Regression C127050
   * - Login and load the console page (beforeEach)
   * - Select "Last 7 days" in the time filter and Click the New Escalation tab (beforeEach)
   * - Select the GroupBy dropdown value as Priority and Validate case card are displaying
   * - Verify the Escalation Note tooltip text if No escalation notes or with escalation notes
   * - Click on Escalation Note Icon and add escalation note
   * - Click on the Case Card and verify the added escalation note is displaying in the opened SupportHub page
   * - Reload the page, enter the CaseId in the global search
   * - Open the Case from Search result and verify the added escalation note is displaying in the opened SupportHub page
   */
  it('C127050: Validate adding Escalation Note for the cards in New Escalation tab', { tags: ['Console', 'staging'] }, () => {
    const escalationNote = `Test Escalation Note ${randId()}`;
    cy.waitForLoaders();
    consolePage.groupByPriorityOption();
    cy.waitForLoaders();
    consolePage.escalationCaseCard().eq(0).should('be.visible');
    // Verify the Escalation Note tooltip text
    consolePage
      .caseCardEscalationNotesIcon()
      .eq(0)
      .then(($count) => {
        consolePage.caseCardEscalationNotesIcon().eq(0).trigger('mouseover');
        if ($count.text() !== '') {
          consolePage.caseCardEscalationNotesTooltip().should('have.text', 'Add/View Escalation Notes');
        } else {
          consolePage.caseCardEscalationNotesTooltip().should('have.text', 'Add Escalation Notes');
        }
      });
    // Add new Escalation Notes
    consolePage.caseCardEscalationNotesIcon().eq(0).click();
    supportHub.clearEscalationNotesWelcomeScreen();
    supportHub.escalationNotesTextarea().clear().type(escalationNote).type('{enter}');
    cy.waitForLoaders();
    escalations.closeEscalationNotesPopupButton().click();
    // Open the SH and verify the added Escalation Note is displaying
    consolePage.escalationCaseCard().eq(0).click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    supportHub
      .caseIdLabel()
      .should('be.visible')
      .then(($caseNo) => {
        const caseId = $caseNo.text();
        supportHub.addEscalationNotesIconButton().scrollIntoView().click();
        supportHub.postedEscalationNoteText().first().should('be.visible').and('contain.text', escalationNote);
        escalations.closeEscalationNotesPopupButton().click();
        supportHub.closeButton().click();
        cy.reload();
        cy.visit(urlHelpers.console.home);
        cy.waitForLoaders();
        // Verify the Search with valid Case Id
        globalSearch.globalSearchButton().click();
        globalSearch.globalSearchInput().type(caseId);
        globalSearch.globalSearchResultListItem().eq(0).click();
        cy.waitForLoaders();
        // Open the SH and verify the added Escalation Note is displaying
        supportHub.baseContainer().should('be.visible');
        supportHub.addEscalationNotesIconButton().click();
        supportHub.postedEscalationNoteText().first().should('be.visible').and('contain.text', escalationNote);
        escalations.closeEscalationNotesPopupButton().click();
        supportHub.closeButton().should('be.visible').click();
      });
  });
});
