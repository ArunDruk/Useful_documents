import { currentUserName, urlHelpers } from '../../../utils';
import { selectStatusGroupBy } from './support';
import { apiHelpers, consolePage, escalations, filters, supportHub } from '../../../pages';

describe('Console Tests', () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.removeDynamicFilterConsolePage();
    cy.slcHelpers.clearCustomersQuickFilter();
    cy.slcHelpers.clearAgentsQuickFilter();
    cy.slcHelpers.clearCaseFieldQuickFilter();
    cy.slcHelpers.deleteGlobalFilter();
    cy.visit(urlHelpers.console.withTimeFilter.lastSevenDays);
  });

  afterEach(() => {
    apiHelpers.removeDynamicFilterConsolePage();
    cy.slcHelpers.clearCaseFieldQuickFilter();
  });

  /**
   * Regression C44
   * - Select the timefilter as last 7 days to avoid no cases
   * - Click on the New Cases tab
   * - Verify the Assigned Cases tab title text that have case count
   * - Click on the Status dropdown and select Open if Status value is Closed or vice versa
   * - Verify the Assigned Cases tab case count gets updated based on status selected
   */
  it('C44: Console - New Tickets -> Assigned Cases -> Closed filter', { tags: ['Console', 'staging'] }, () => {
    cy.waitForLoaders();
    consolePage.newCasesTab().click();
    cy.waitForLoaders();
    consolePage
      .newCasesTabHeaderList()
      .contains('Assigned Cases')
      .then((bfrvalue) => {
        const beforevalue = bfrvalue.text().split('Export as...')[0];
        // In Assigned Cases - Verify the Charts
        consolePage.assignedCasesContainer().eq(0).should('be.visible');
        consolePage
          .assignedCasesDropdown()
          .eq(0)
          .should('be.visible')
          .then((labelName) => {
            const drpdwnValue = labelName.text().trim();
            consolePage.assignedCasesDropdown().eq(0).should('be.visible').click();
            if (drpdwnValue === 'Open') {
              consolePage.assignedCasesDropdownOptionClosed().eq(0).should('be.visible').click();
              consolePage.assignedCasesDropdown().eq(0).should('contain', 'Closed');
            } else {
              consolePage.assignedCasesDropdownOptionOpened().eq(0).should('be.visible').click();
              consolePage.assignedCasesDropdown().eq(0).should('contain', 'Open');
            }
            cy.waitForLoaders();
          });
        consolePage
          .newCasesTabHeaderList()
          .eq(1)
          .then((aftvalue) => {
            const aftervalue = aftvalue.text().split('Export as...')[0];
            expect(aftervalue).not.equal(beforevalue);
            // In Assigned Cases - Verify the Charts
            consolePage.assignedCasesContainer().eq(0).should('be.visible');
          });
      });
  });

  // Regression C2216
  it('C2216: Test dynamic filter', { tags: 'Console' }, () => {
    selectStatusGroupBy();
    consolePage.navigationConsole().should('be.visible').click();
    consolePage.negativeSentimentsTab().click({ force: true });
    filters.addDynamicFilterButton().should('be.visible').click();
    filters.dynamicFilterHeader().then(($selected) => {
      const selectedButton = $selected.text();
      if (selectedButton.includes('selected')) {
        filters.dynamicFilterSelectedRemoveButton().click();
      }
      filters.dynamicFilterStatusCheckbox().click();
      filters.dynamicFilterSaveButton().click();
      filters.dynamicFilterDropdown().eq(0).click();
      // Todo: Iterate through all status after getting testid
      filters
        .dynamicFilterDropdownListFirstItem()
        .invoke('text')
        .then((firstStatusValue) => {
          // Todo get testID
          filters.dynamicFilterDropdownListFirstItem().click();
          filters.dynamicFilterApplyButton().click({ force: true });
          consolePage.sentimentsGroupbyButton().click();
          consolePage.sentimentsGroupByDrodownOptionStatus().click();
          consolePage.groupByTabs().contains(firstStatusValue);
        });
    });
  });

  // Regression C2217
  it('C2217: Test deselect checkbox', { tags: 'Console' }, () => {
    consolePage.navigationConsole().should('be.visible').click();
    filters.addDynamicFilterButton().should('be.visible').click();
    filters.dynamicFilterHeader().then(($selected) => {
      const selectedButton = $selected.text();
      if (selectedButton.includes('selected')) {
        filters.dynamicFilterSelectedRemoveButton().click();
      }
      filters.dynamicFilterStatusCheckbox().scrollIntoView().should('be.visible').click();
      filters.dynamicFilterStatusCheckbox().find('input').invoke('attr', 'data-status').should('equal', 'checked');
      filters.dynamicFilterSaveButton().should('be.visible').click();
      filters.dynamicFilterDropdown().should('be.visible');

      // Remove the selected dynamic filter
      filters.addDynamicFilterButton().should('be.visible').click();
      filters.dynamicFilterStatusCheckbox().scrollIntoView().should('be.visible').click();
      filters.dynamicFilterStatusCheckbox().find('input').invoke('attr', 'data-status').should('equal', 'unchecked');
      filters.dynamicFilterSaveButton().should('be.visible').click();
      filters.dynamicFilterDropdown().should('not.exist');
    });
  });

  // Regression C901
  it('C901: Console - Likely to escalate', { tags: 'Console' }, () => {
    cy.waitForLoaders();
    consolePage.newEscalationsTab().click();
    cy.waitForLoaders();
    consolePage.escalationGroupByDropdownText().then((groupValue) => {
      const dropdownValue = groupValue.text();
      if (dropdownValue !== 'Priority') {
        consolePage.groupedByDropdown().eq(1).click();
        consolePage.sentimentsGroupByDrodownOptionPriority().click();
        consolePage.groupByTabs().eq(0).should('be.visible').click();
      } else {
        consolePage.groupByTabs().eq(0).should('be.visible').click();
      }
    });
    consolePage.escalationCaseCard().eq(0).click();
    cy.contains('Escalated');
    supportHub.closeButton().should('be.visible').click();
    consolePage.lteTab().click();
    cy.waitForLoaders();
    // Was Likely to Escalate
    // consolePage.likelyToEscalateTab().should('be.visible').click();
    // Likely to Escalate
    consolePage.escalationCaseCard().eq(0).click();
    cy.contains('Likely to Escalate');
    supportHub.closeButton().should('be.visible').click();
  });

  // Regression C2155
  it('C2155: Console - Likely to escalate - acknowledgement', { tags: 'Console' }, () => {
    cy.waitForLoaders();
    consolePage.lteTab().click();
    consolePage.escalationGroupByDropdownText().then((groupValue) => {
      const dropdownValue = groupValue.text();
      if (dropdownValue !== 'Priority') {
        consolePage.groupedByDropdown().eq(1).click();
        consolePage.sentimentsGroupByDrodownOptionPriority().click();
        consolePage.groupByTabs().eq(0).should('be.visible').click();
      } else {
        consolePage.groupByTabs().eq(0).should('be.visible').click();
      }
    });
    consolePage.escalationCaseCard().eq(0).click();
    cy.waitForLoaders();
    escalations.escalationReviewTriggerButton().click();
    escalations.escalationReviewPanelHeader().should('be.visible');
    escalations.removeFromQueueButton().click();
    escalations.acknowledgePredictionOption().click();
    escalations.escalationReviewPanelFooter().should('contain.text', 'Escalation review completed by You');
    escalations.undoEscalationReviewButton().click();
    supportHub.caseCommentsContainer().first().should('contain.text', `${currentUserName} acknowledged the escalation prediction`);
    escalations.exitReviewButton().click();
    escalations.escalationReviewOkButton().click();
    supportHub.closeButton().click();
  });

  /**
   * Regression - C9124
   * - Open the console page.
   * - Select the Escalations tab
   * - Select Priority in the grouped by dropdown.
   * - Check the sentiment and attention scores of cases in the escalations cards.
   * - Click on a case card and verify the same sentiment and attention scores is displaying in the Supporthub
   */
  it('C9124: Make sure Attention/sentiment scores in the escalations card reflects the same as Supporthub', { tags: ['Console', 'staging', 'prod'] }, () => {
    cy.waitForLoaders();
    consolePage.newEscalationsTab().click();
    consolePage.escalationGroupByDropdownText().then((groupValue) => {
      const dropdownValue = groupValue.text();
      if (dropdownValue !== 'Priority') {
        consolePage.groupedByDropdown().eq(1).click();
        consolePage.sentimentsGroupByDrodownOptionPriority().click();
        consolePage.groupByTabs().eq(0).should('be.visible').click();
      } else {
        consolePage.groupByTabs().eq(0).should('be.visible').click();
      }
    });
    cy.waitForLoaders();
    consolePage
      .caseCardSentimentScoreCountIcon()
      .eq(0)
      .then(($score1) => {
        const sentimentScore = $score1.text();
        consolePage
          .caseCardAttentionScoreCountIcon()
          .eq(0)
          .then(($score2) => {
            const attentionScore = $score2.text();
            consolePage.escalationCaseCard().eq(0).click();
            cy.waitForLoaders();
            supportHub.supportHubSentimentScoreLabel().invoke('text').should('contain', sentimentScore);
            supportHub.supportHubAttentionScoreLabel().invoke('text').should('contain', attentionScore);
          });
      });
  });
});
