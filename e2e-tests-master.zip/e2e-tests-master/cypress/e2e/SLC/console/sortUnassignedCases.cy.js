import { consolePage } from '../../../pages';
import { urlHelpers } from '../../../utils';

beforeEach(() => {
  cy.loginByApi();
  cy.visit(urlHelpers.console.tabsWithTimeFilterLastSevenDays.newCases);
});

describe('console_test_suite', () => {
  it('C66: Sort_unassigned_cases', { tags: 'Console' }, () => {
    consolePage.timeFilterButton().click().contains('Last 7 days').click();
    consolePage.newCasesTab().click();
    consolePage.unassignedCasesCommonDropdownTrigger().click();
    consolePage.unassignedCasesCommonDropdownListItems().first().invoke('text').should('include', 'Name');
    consolePage.unassignedCasesCommonDropdownListItems().first().click();
    consolePage
      .unassignedCasesCardID()
      .first()
      .invoke('text')
      .then((case1) => {
        cy.wrap(case1).should('not.be.empty');
        consolePage.unassignedCasesSortDirection().click();
        consolePage
          .unassignedCasesCardID()
          .first()
          .invoke('text')
          .then((case2) => {
            expect(case2).to.not.equal(case1);
          });
      });

    cy.contains('Sentiment Score').click({ force: true }).should('have.text', 'Sentiment Score');
    consolePage
      .unassignedCasesSortStatus()
      .invoke('attr', 'data-status')
      .then((sortOrder) => {
        cy.log(sortOrder);
        if (sortOrder === 'asc') {
          consolePage.unassignedCasesSortDirection().click();
        }
      });
    consolePage
      .unassignedCaseCardSentimentScore()
      .first()
      .invoke('text')
      .then((case3) => {
        cy.wrap(case3).should('not.be.empty');
        consolePage.unassignedCasesSortDirection().click();
        consolePage
          .unassignedCaseCardSentimentScore()
          .first()
          .invoke('text')
          .then((case4) => {
            expect(parseInt(case3, 10)).to.be.greaterThan(parseInt(case4, 10));
          });
      });
    cy.contains('Attention Score').click({ force: true }).should('have.text', 'Attention Score');
    consolePage
      .unassignedCasesSortStatus()
      .invoke('attr', 'data-status')
      .then((sortOrder) => {
        if (sortOrder === 'asc') {
          consolePage.unassignedCasesSortDirection().click();
        }
      });
    consolePage
      .unassignedCaseCardNeedAttentionScore()
      .first()
      .invoke('text')
      .then((case5) => {
        cy.wrap(case5).should('not.be.empty');
        consolePage.unassignedCasesSortDirection().click();
        consolePage
          .unassignedCaseCardNeedAttentionScore()
          .first()
          .invoke('text')
          .then((case6) => {
            expect(parseInt(case5, 10)).to.be.greaterThan(parseInt(case6, 10));
          });
      });
    cy.contains('Created At').click({ force: true }).should('have.text', 'Created At');
    consolePage
      .unassignedCasesCardID()
      .first()
      .invoke('text')
      .then((case7) => {
        cy.wrap(case7).should('not.be.empty');
        consolePage.unassignedCasesSortDirection().click();
        consolePage
          .unassignedCasesCardID()
          .first()
          .invoke('text')
          .then((case8) => {
            expect(case8).to.not.equal(case7);
            consolePage.unassignedCasesCommonDropdownTrigger().click();
            consolePage.unassignedCasesCommonDropdownListItems().eq(4).click();
            consolePage
              .unassignedCasesCardID()
              .first()
              .invoke('text')
              .then((case9) => {
                cy.wrap(case9).should('not.be.empty');
                expect(case9).to.not.equal(case8);
              });
          });
      });
  });
});
