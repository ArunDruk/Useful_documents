export const selectStatusGroupBy = () =>
  cy.request({
    method: 'PUT',
    url: '/api/users/dashboard_settings',
    headers: { 'Content-Type': 'application/json' },
    body: {
      dashboardName: 'support',
      replace: false,
      settingsKey: 'console_page_settings',
      settingsSubKey: null,
      settingsValue: { ltbe_tab_grouping: 'sl_status' },
    },
  });
