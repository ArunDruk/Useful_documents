import { urlHelpers } from '../../../utils';
import { consolePage, supportHub } from '../../../pages';

describe('Console Page - Open SupportHub', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.console.withTimeFilter.lastSevenDays);
  });

  /**
   * Open the console page.
   * Click the negative sentiment tab.
   * Open any support hub and verify.
   */
  it('C2207: verifying SH negative sentiment', { tags: ['Console', 'staging', 'prod'] }, () => {
    consolePage.negativeSentimentsTab().click({ force: true });
    consolePage.groupByElapsedTime();
    consolePage.expandAllConsoleLists();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    consolePage
      .caseListCustomerName()
      .eq(0)
      .then((buttonText) => {
        const customerName = buttonText.text();
        consolePage.caseCard().eq(0).should('be.visible').click();
        cy.waitForLoaders();
        supportHub.caseCustomerNameLabel().invoke('text').should('be.equal', customerName);
        supportHub.closeButton().click();
      });
  });

  /**
   * Open the console page.
   * Click the product feedback tab.
   * Open any support hub and verify.
   */
  it('C2208: verifying SH product feedback', { tags: ['Console', 'staging', 'prod'] }, () => {
    consolePage.productFeedbackTab().click({ force: true });
    consolePage.groupByElapsedTime();
    consolePage.expandAllConsoleLists();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    consolePage
      .caseListCustomerName()
      .eq(0)
      .then((buttonText) => {
        const customerName = buttonText.text();
        consolePage.caseCard().eq(0).should('be.visible').click();
        cy.waitForLoaders();
        supportHub.caseCustomerNameLabel().invoke('text').should('be.equal', customerName);
        supportHub.closeButton().click();
      });
  });

  /**
   * Open the console page.
   * Click the need attention tab.
   * Open any support hub and verify.
   */
  it('C2209: verifying SH need attention', { tags: ['Console', 'staging', 'prod'] }, () => {
    consolePage.needAttentionTab().click({ force: true });
    consolePage.groupByElapsedTime();
    consolePage.expandAllConsoleLists();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    consolePage
      .caseListCustomerName()
      .eq(0)
      .then((buttonText) => {
        const customerName = buttonText.text();
        consolePage.caseCard().eq(0).should('be.visible').click();
        cy.waitForLoaders();
        supportHub.caseCustomerNameLabel().invoke('text').should('be.equal', customerName);
        supportHub.closeButton().click();
      });
  });

  /**
   * Open the console page.
   * Click the positive sentiment tab.
   * Open any support hub and verify.
   */
  it('C2210: verifying SH positive sentiment', { tags: ['Console', 'staging', 'prod'] }, () => {
    consolePage.positiveSentimentsTab().click({ force: true });
    consolePage.groupByElapsedTime();
    consolePage.expandAllConsoleLists();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    consolePage
      .caseListCustomerName()
      .eq(0)
      .then((buttonText) => {
        const customerName = buttonText.text();
        consolePage.caseCard().eq(0).should('be.visible').click();
        cy.waitForLoaders();
        supportHub.caseCustomerNameLabel().invoke('text').should('be.equal', customerName);
        supportHub.closeButton().click();
      });
  });

  /**
   * Open the console page.
   * Click the new cases tab.
   * Open any support hub in unassigned cases and verify.
   */
  it('C2213: verifying SH unassigned cases', { tags: ['Console', 'staging', 'prod'] }, () => {
    consolePage.newCasesTab().click({ force: true });
    consolePage.newCasesTabUnassignedHeader().then((btn2) => {
      const unassignedHeaderName = btn2.text();
      expect(unassignedHeaderName).to.include('Unassigned Cases');
    });
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    consolePage
      .unassignedCasesCardTitle()
      .eq(0)
      .then((buttonText) => {
        const customerName = buttonText.text();
        consolePage.unassignedCaseCardLists().eq(0).should('be.visible').click();
        cy.waitForLoaders();
        supportHub.caseCustomerNameLabel().invoke('text').should('be.equal', customerName);
        supportHub.closeButton().click();
      });
  });

  /**
   * Open the console page.
   * Click the likely to escalate tab.
   * Open any support hub and verify the Likely to Escalate Label is displaying.
   */
  it('C6269: Check if all tickets have LTE tag when cases are opened in supporthub', { tags: ['Console', 'staging', 'prod'] }, () => {
    cy.waitForLoaders();
    consolePage.lteTab().click();
    consolePage.escalationGroupByDropdownText().then((groupValue) => {
      const dropdownValue = groupValue.text();
      if (dropdownValue !== 'Priority') {
        consolePage.groupedByDropdown().eq(1).click();
        consolePage.sentimentsGroupByDrodownOptionPriority().click();
        consolePage.groupByTabs().eq(0).should('be.visible').click();
      } else {
        consolePage.groupByTabs().eq(0).should('be.visible').click();
      }
    });
    cy.waitForLoaders();
    consolePage.escalationCaseCard().eq(0).click();
    cy.waitForLoaders();
    supportHub.supportHubLteLabel().should('be.visible').and('have.text', 'Likely to Escalate');
    supportHub.closeButton().should('be.visible').click();
  });
});
