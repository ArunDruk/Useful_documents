import { urlHelpers } from '../../../utils';
import { commonElements, consolePage } from '../../../pages';

describe('Console Product Feedback Tests', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.console.tabsWithTimeFilterLastSevenDays.productFeedback);
  });

  /**
   * Regression C57
   * - Select the timefilter as last 7 days to avoid no cases
   * - Click on the Product Feedback tab
   * - Select Show Unacknowledged in the show dropdown and Acknowledge the case
   * - Select Show Acknowledged in the show dropdown and Verify the Acknowledge case is displaying
   * - Select Show Unacknowledged in the show dropdown and Verify the Acknowledge case is not displaying
   * - Select Show Acknowledged in the show dropdown and revert back the Acknowledgement from the case
   */
  it('C57: Validate acknowledged cases are showing correctly in Show acknowledged filter (Product feedback)', { tags: 'Console' }, () => {
    cy.waitForLoaders();
    consolePage.productFeedbackTab().should('be.visible');
    // Selecting the Elapsed Time in GroupBy dropdown
    consolePage.groupByElapsedTime();
    cy.waitForLoaders();
    consolePage
      .acknowledgeDropdown()
      .should('be.visible')
      .then(($value) => {
        const drpdwnValue = $value.text().trim();
        // Selecting the Show Unacknowledged in the show dropdown
        if (drpdwnValue !== 'Show Unacknowledged') {
          consolePage.acknowledgeDropdown().click();
          consolePage.acknowledgeDropdownValueUnack().click();
          consolePage.acknowledgeDropdown().invoke('text').should('contain', 'Show Unacknowledged');
        }
        cy.waitForLoaders();
        consolePage.expandAllConsoleLists();
        // click on the Acknowledge Icon for the First Case and Verify is it Acknowledged
        consolePage.caseCard().eq(0).scrollIntoView().trigger('mouseover');
        consolePage.sentimentAckButton().eq(0).scrollIntoView().click({ force: true });
        consolePage.caseCard().eq(0).invoke('text').should('contain', 'acknowledged by');
        consolePage
          .caseCardTicketIdLabel()
          .eq(0)
          .then((caseNo) => {
            // Selecting the Show Acknowledged and verify the Case is displayed
            consolePage.acknowledgeDropdown().click();
            consolePage.acknowledgeDropdownValueAck().click();
            cy.waitForLoaders();
            consolePage.caseCardTicketIdLabel().should('contain', caseNo.text());
            // Selecting the Show Unacknowledged and verify the Case is not displayed
            consolePage.acknowledgeDropdown().click();
            consolePage.acknowledgeDropdownValueUnack().click();
            cy.waitForLoaders();
            commonElements.appWrapper().then(($parentDiv) => {
              if ($parentDiv.find('[data-testid="common-zeroStateContainer"]').length > 0) {
                cy.get('body').should('contain', 'No tickets, try expanding your filter options');
              } else {
                consolePage.caseCardTicketIdLabel().should('not.contain', caseNo.text());
              }
            });
            cy.waitForLoaders();
            // Navigating back to Show Acknowledged and removing the Acknowlegment from the Case
            consolePage.acknowledgeDropdown().click();
            consolePage.acknowledgeDropdownValueAck().click();
            cy.waitForLoaders();
            consolePage.acknowledgeLabelWithCrossIcon().eq(0).scrollIntoView();
            consolePage.caseCard().eq(0).trigger('mouseover');
            consolePage.acknowledgeLabelTooltip().invoke('text').should('include', 'Remove acknowledgement');
            consolePage.acknowledgeLabelWithCrossIcon().eq(0).scrollIntoView().click({ force: true });
          });
      });
  });

  /**
   * Regression C56
   * - Navigate to the Product Feedback tab and verify we have landed in expected tab
   * - Select the Agent in the GroupBy dropdown and verify the tab details are displayed as per GroupedBy
   * - Select the Priority in the GroupBy dropdown and verify the tab details are displayed as per GroupedBy
   * - Select the Elapsed Time in the GroupBy dropdown and verify the tab details are displayed as per GroupedBy
   */
  it('C56: Console - Product feedback (Group by)', { tags: 'Console' }, () => {
    cy.waitForLoaders();
    consolePage.productFeedbackTab().should('be.visible');
    consolePage
      .acknowledgeDropdown()
      .should('be.visible')
      .then(($value) => {
        const drpdwnValue = $value.text().trim();
        // Selecting the Show all in the show dropdown
        if (drpdwnValue !== 'Show all') {
          consolePage.acknowledgeDropdown().click();
          consolePage.acknowledgeDropdownValueAll().click();
          consolePage.acknowledgeDropdown().invoke('text').should('contain', 'Show all');
        }
      });
    cy.waitForLoaders();
    // Selecting the Agent in GroupBy dropdown
    consolePage.sentimentsGroupbyButton().then((groupValue) => {
      if (groupValue.text() !== 'Agent') {
        consolePage.sentimentsGroupbyButton().click();
        consolePage.sentimentsGroupByDrodownOptionAgent().click();
        consolePage.consoleHeader().click();
      }
      consolePage.expandAllConsoleLists();
      cy.waitForLoaders();
      consolePage.groupByTabs().should('exist');
      consolePage.groupByTabOption('A').should('exist');
      consolePage.caseCard().should('exist');
    });
    // Selecting the Priority in GroupBy dropdown
    consolePage.sentimentsGroupbyButton().then((groupValue) => {
      if (groupValue.text() !== 'Priority') {
        consolePage.sentimentsGroupbyButton().click();
        consolePage.sentimentsGroupByDrodownOptionPriority().click();
        consolePage.consoleHeader().click();
      }
      cy.waitForLoaders();
      consolePage.groupByTabs().should('exist');
      consolePage.caseCard().should('exist');
    });
    // Selecting the Elapsed Time in GroupBy dropdown
    consolePage.groupByElapsedTime();
    cy.waitForLoaders();
    consolePage.expandAllConsoleLists();
    consolePage.groupByTabs().should('not.exist');
    consolePage.caseCard().should('exist');
  });
});
