import { commonElements, consolePage, navBar } from '../../../pages';
import { urlHelpers } from '../../../utils';

describe.skip('console_suite', () => {
  beforeEach(() => {
    cy.loginByApi();
  });

  afterEach(() => cy.slcHelpers.enableModule('console'));

  // Skipping Enable Disable module test cases
  it('C28: disable_enable_console', { tags: ['@EnableDisableLockTests', '@NotThreadSafe'] }, () => {
    cy.slcHelpers.disableModule('console');
    cy.visit(urlHelpers.console.home);
    commonElements.appWrapper().invoke('text').should('include', 'Console module is disabled for you');
    cy.slcHelpers.enableModule('console');
    cy.reload();
    consolePage.timeFilterButton().should('be.visible');
    navBar.console().should('be.visible');
  });
});
