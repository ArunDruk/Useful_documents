import { targetDatabase } from '../../../utils/labelHelper';

export const getAgentNameFromOpenCaseDetailsWithSignals = () =>
  cy
    .request({
      method: 'POST',
      url: `api/cache/${targetDatabase}/tickets/v2/data`,
      headers: { 'Content-Type': 'application/json' },
      body: {
        fieldIds: ['id', 'sl_assignee_name'],
        filters: {
          sl_is_closed: false,
          sl_has_signals: true,
        },
        limit: 50,
        sortAsc: false,
        sortKey: 'sl_created_at',
        utcOffset: 0,
        offset: 0,
      },
      filter_list: [{ column: 'sl_assignee_name', op: '<>', value: 'Unassigned' }],
    })
    .then(({ body }) =>
      /* eslint-disable-next-line */
      body.tickets.map(({ id, sl_assignee_name }) => ({
        caseID: id,
        /* eslint-disable-next-line */
        agentName: sl_assignee_name,
      }))
    );
