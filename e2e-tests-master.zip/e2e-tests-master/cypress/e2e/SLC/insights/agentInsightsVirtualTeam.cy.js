import { randId, urlHelpers } from '../../../utils';
import { agentInsights, apiHelpers } from '../../../pages';

describe('Agent Insights - Virtual Team', () => {
  let vtName = '';
  let vtId = '';
  before(() => {
    cy.loginByApi();
    apiHelpers.clearRecentlyVisitedAgentInsight();
    vtName = `Test Personal Team ${randId()}`;
    cy.slcHelpers
      .getAgentIds(2)
      .then((agentIds) => cy.slcHelpers.createVT(vtName, agentIds))
      .then((response) => {
        vtId = response.body.id;
      });
  });

  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.agentInsights.home);
  });

  after(() => {
    cy.slcHelpers.deleteVgroup(vtId);
  });

  /**
   * Regression C2235
   * - Created a virtual team
   * - Navigate to the Agent Insights and enter the created virtual team name
   * - Select the virtual team from the search result
   * - Verify the selected virtual team is displaying in the Agent Insight Page Result
   */
  it('C2235: Test virtual team', { tags: ['Support Engineers', 'staging'] }, () => {
    cy.waitForLoaders();
    agentInsights.agentInsightsSearchFieldInput().type(vtName);
    agentInsights.agentSearchResultList().eq(0).click();
    cy.waitForLoaders();
    cy.contains(vtName).should('exist');
  });
});
