import { apiHelpers } from '../../../pages';
import { urlHelpers } from '../../../utils';

beforeEach(() => {
  cy.loginByApi();
  apiHelpers.clearRecentlyVisitedCustomerInsight();
  cy.visit(urlHelpers.customerInsights.home);
});

describe('Customer Insights Tests', () => {
  // Regression C473
  it("C473: Customer's page Overview", { tags: 'Customer' }, () => {
    // Navigating to the  Virtual Account Page
    cy.getByTestId('layout-navigation-module-item--virtualAccounts').should('be.visible').click();
    // TODO: waiting for data test-id SLC-31060
    cy.get('.styles__Trigger-sc-1f56bqy-0').click();
    cy.contains('System of Records Merged Account').click();
    cy.getByTestId('animated-checkbox-default-group-System of Records Merged Account-id').invoke('attr', 'data-status').should('include', 'checked');
    // TODO: waiting for data test-id SLC-31060
    cy.get('.styles__Trigger-sc-1f56bqy-0').click();
    cy.getByTestId('virtualAccounts-sf_virtual_account-listItem-label').then(($vaName) => {
      const searchValue = $vaName.eq(0).text();
      // Navigating to the Customer Insight Page
      cy.getByTestId('layout-navigation-module-item--customerInsights').should('be.visible').click();
      // Enter the sample value in search
      cy.getByTestId('customerInsights-searchBar-searchInput')
        .should('be.visible')
        .type(searchValue)
        .then(() => {
          cy.get('.dropdown-item').eq(0).click();
        });
    });
    cy.getByTestId('tabNav__insights').should('be.visible').click();
    // click on the Overview tab
    cy.getByTestId('customersPage-tabSlider-overview').eq(1).should('be.visible').click();
    // Verify the Open subtab
    cy.getByTestId('common-buttonSwitcher-btn').eq(0).should('be.visible').click();
    cy.getByTestId('common-caseList-sideListItem').should('exist');
    // Verify the Recently Closed tab
    cy.getByTestId('common-buttonSwitcher-btn').eq(1).should('be.visible').click();
    // Need to check will this tab always have atleast one record or its based on duration
    cy.getByTestId('common-caseList-sideListItem').should('exist');
  });
});
