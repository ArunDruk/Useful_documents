import moment from 'moment';

import { urlHelpers } from '../../../utils';
import { agentInsights, datePicker, apiHelpers } from '../../../pages';

describe('Agent Insights Tests - Calendar Events', () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.clearRecentlyVisitedAgentInsight();
    cy.slcHelpers.getDetailsOfAgentsWithCases().then((agentDetails) => {
      const agentDetail = Cypress._.sample(agentDetails);

      cy.wrap(agentDetail).as('agentDetail');

      cy.visit(urlHelpers.agentInsights.home);
    });
  });

  /*
    Search for a user and go to Insights page
    Click on Calendar and go to next month and select a day
    Create and save OOO event for Vacation
    Delete OOO day
   */
  it('C496: Adding Events for Agents from their profile page.', { tags: 'Agents' }, function agentNames() {
    const dayNextMonth = moment().add(1, 'month');
    // go to Agent Insights tab and move calendar to next month
    agentInsights.agentInsightsSearchFieldInput().click().type(this.agentDetail.sl_name);
    agentInsights.agentSearchResultList().first().click();
    agentInsights.agentInsightsCalendarForwardButton().click();
    // select a date and 'Vacation' reason and Save the event
    datePicker.calendarDayButton(dayNextMonth.format('MMMM D,')).dblclick();
    agentInsights.eventDetailTextArea().type('Vacation');
    agentInsights.agentInsightsOOOSaveButton().click();
    // open it back up and delete the event (verifies it was created)
    datePicker.calendarDayButton(dayNextMonth.format('MMMM D,')).dblclick();
    agentInsights.agentInsightsOOODeleteButton().should('be.visible').click();
  });
});
