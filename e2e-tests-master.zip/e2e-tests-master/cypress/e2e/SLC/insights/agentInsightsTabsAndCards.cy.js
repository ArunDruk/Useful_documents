import { getAgentNameFromOpenCaseDetailsWithSignals } from './support';
import { urlHelpers } from '../../../utils';
import { apiHelpers } from '../../../pages';

describe('Agent Insights Tests - Tabs and Cards', () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.clearRecentlyVisitedAgentInsight();
    getAgentNameFromOpenCaseDetailsWithSignals().then((caseDetails) => {
      const caseDetail = Cypress._.sample(caseDetails);

      cy.wrap(caseDetail).as('caseDetail');

      cy.visit(urlHelpers.agentInsights.home);
    });
  });

  // Regression C2161
  it("C2161: Check if all the added tabs are visible in Agent's profile page", { tags: 'Support Engineers' }, () => {
    cy.getByTestId('agentsPage-searchBar-searchInput').should('be.visible').type('a');
    cy.getByTestId('global-searchBar-searchOption-item').eq(0).should('be.visible').click();
    cy.waitForLoaders();
    // Verify the Backlog tab is displaying
    // cy.getByTestId('agentsPage-tabSlider-backlog').eq(1).should('exist').click();
    // cy.getByTestId('global-sortableCaseList-dropdown').should('exist');
    // Verify the Open tab is displaying
    cy.getByTestId('agentsPage-tabSlider-open_cases').eq(1).should('exist').click();
    cy.getByTestId('global-sortableCaseList-dropdown').should('exist');
    // Negative Sentiments
    cy.getByTestId('agentsPage-tabSlider-negative_sentiments').eq(1).should('exist').click();
    cy.getByTestId('sentimentsFeed-lightFilter-groupBy-btn').click();
    cy.get('[data-testid="common-dropdown-sentiment_type"]').click();
    cy.getByTestId('optionsSwitcherNew-wrapper').should('exist');
    // Positive Sentiments
    cy.getByTestId('agentsPage-tabSlider-positive_sentiments').eq(1).should('exist').click();
    cy.getByTestId('sentimentsFeed-lightFilter-groupBy-btn').click();
    cy.get('[data-testid="common-dropdown-sentiment_type"]').click();
    cy.getByTestId('optionsSwitcherNew-wrapper').should('exist');
    // Closed Cases
    cy.getByTestId('agentsPage-tabSlider-closed_cases').eq(1).should('exist').click();
    // TODO: waiting for data test-id SLC-31020
    cy.get('[class^=AgentCharts__ChartsContainer]').should('exist');
    // Need Attention
    cy.getByTestId('agentsPage-tabSlider-need_attention').eq(1).should('exist').click();
    cy.getByTestId('sentimentsFeed-lightFilter-groupBy-btn').click();
    cy.get('[data-testid="common-dropdown-sl_severity_c"]').click();
    cy.getByTestId('optionsSwitcherNew-wrapper').should('exist');
    // Escalations
    cy.getByTestId('agentsPage-tabSlider-new_escalations').eq(1).should('exist').click();
    cy.getByTestId('common-dropdown-btn').click();
    cy.get('[data-testid="common-dropdown-sl_severity_c"]').click();
    cy.getByTestId('optionsSwitcherNew-wrapper').should('exist');
    // Engineering Issues
    cy.getByTestId('agentsPage-tabSlider-engineering_issues').eq(1).should('exist').click();
    cy.getByTestId('consolePage-tabsSlider-tab-count-Engineering_Issues')
      .invoke('text')
      .then((engIssueCountText) => {
        if (engIssueCountText.replace('cases', '') !== '0') {
          cy.getByTestId('agentPage-engIssues--entities__chartwrapper_title').should('be.visible').and('have.text', 'Top Entities');
        } else {
          cy.getByTestId('agentPage-engIssues--entities__empty_container').should('be.visible').and('contain.text', 'No Entities Found');
        }
      });
  });

  it('C3794: Sentiment cards loading in Agent Insights', { tags: ['Agents', 'staging', 'prod'] }, function agentSentimentsLoading() {
    cy.getByTestId('agentsPage-searchBar-searchInput').should('be.visible').click();
    cy.getByTestId('agentsPage-searchBar-searchInput').type(this.caseDetail.agentName);
    // click on the agent returned from the search
    cy.getByTestId('global-searchBar-searchOption-item').eq(0).should('be.visible').click();
    cy.waitForLoaders();
    // Negative Sentiment card - ensure it is visible (loaded)
    cy.getByTestId('agentsPage-tabSlider-negative_sentiments').eq(1).should('be.visible').click();
    // look for the ticket # on the card
    // TODO data test id requested via SLC-31020
    cy.get('._2SYhC0rfnKSZPbRvSyQrm6').should('be.visible');
  });
});
