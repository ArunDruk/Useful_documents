import { urlHelpers } from '../../../utils';
import { agentInsights, apiHelpers } from '../../../pages';

describe('Agent Insights Tests - Open New Tab in Current Window', () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.removeAllFavoriteAgents();

    cy.slcHelpers.getDetailsOfAgentsWithCases().then((agentDetails) => {
      const agentDetail = Cypress._.sample(agentDetails);

      cy.wrap(agentDetail).as('agentDetail');

      cy.visit(urlHelpers.myAgents);
    });
  });

  afterEach(() => apiHelpers.removeAllFavoriteAgents());

  /*
    Search for a user and add to favorites
    Click on button to go to user's profile in another tab
    Because we can't validate a 2nd window, get the href and open in current window to test href opens correct screen
   */
  it('C493: checking the functionality of "view profile" in favourite section', { tags: ['Agents', 'staging', 'prod'] }, function agentNames() {
    cy.getByTestId('common__favoriteSearchBar__input').click().type(this.agentDetail.sl_name);
    agentInsights.agentInAgentSearchListOnFavorites().first().click();
    // there is now a favorite button (star) visible so agent is added
    agentInsights.removeFavoriteAgentButton().should('be.visible');
    // click agent profile button and open in current window instead of new window
    agentInsights
      .agentProfileButton()
      .should('have.attr', 'href')
      .then((href) => {
        cy.visit(href);
        agentInsights.medianCaseOpenTimeLabel().should('be.visible');
      });
  });
});
