import { apiHelpers } from '../../../pages';
import { urlHelpers } from '../../../utils';

beforeEach(() => {
  cy.loginByApi();
  apiHelpers.clearRecentlyVisitedAgentInsight();
  cy.visit(urlHelpers.agentInsights.home);
});

describe('Agent Insights Tests', () => {
  // Smoke & Sanity C486
  it('C486: Agents - Favouriting', { tags: 'Support Engineers' }, () => {
    cy.getByTestId('agentsPage-searchBar-searchInput').should('be.visible').type('test');
    cy.getByTestId('global-searchBar-searchOption-item').eq(0).should('be.visible').click();
    // Click on the Favourite Icon
    cy.getByTestId('agentsPage-agentInfo-favoriteAgent-starBtn').should('be.visible').click();
    // TODO: waiting for data test-id SLC-31020
    cy.get('._262NcsdVedkn8DRq3826GK').then(($name) => {
      const agentName = $name.text();

      // Click on the favourite tab
      cy.visit(urlHelpers.myAgents);

      // verify the Agent name is displaying in the Favorite List
      cy.getByTestId('myAgentsPage-addFavorite-addButton').should('be.visible');
      cy.getByTestId('agentsPage-agentBacklog-agentName').eq(0).contains(agentName);
    });
    // Removing the Agent from Favourite
    cy.getByTestId('agentsPage-agentBacklog-removeFavoriteButton').eq(0).should('be.visible').click();
  });
});
