import { urlHelpers } from '../../../utils';
import { agentInsights, apiHelpers, supportHub } from '../../../pages';

describe('Agent Insights - SupportHub', () => {
  let agentName = '';
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.clearRecentlyVisitedAgentInsight();
    cy.slcHelpers.getDetailsOfAgentsWithCases().then((agentDetails) => {
      const agentDetail = Cypress._.sample(agentDetails);
      cy.wrap(agentDetail).as('agentDetail');
      agentName = agentDetail.sl_name;
      cy.visit(urlHelpers.agentInsights.home);
    });
  });

  /**
   * Regression C2233
   * - beforeEach - we have selected an agent name via API
   * - Navigate to the Agent Insights and enter the agent name
   * - Select the agent from the search result
   * - Click on the Open Cases tab and from the backlog cases
   * - Click on a case from the backlog sub section and verify the selected case only displaying in supportHub popup
   */
  it('C2233: Test support hub data', { tags: ['Support Engineers', 'staging'] }, () => {
    agentInsights.agentInsightsSearchFieldInput().type(agentName);
    agentInsights.agentSearchResultList().eq(0).click();
    cy.contains(agentName).should('exist');
    agentInsights.agentOpenCasesCountTab().eq(0).click();
    agentInsights
      .searchAgentOpenCasesCaseId()
      .eq(0)
      .then(($caseId) => {
        const agentCaseId = $caseId.text();
        agentInsights.searchAgentOpenCasesCaseId().eq(0).click({ force: true });
        cy.waitForLoaders();
        supportHub
          .caseIdLabel()
          .eq(0)
          .then((caseId) => {
            expect(caseId.text()).to.eq(agentCaseId);
          });
      });
  });
});
