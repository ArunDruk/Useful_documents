const predicates = [
  { column: 'sl_is_closed', op: '=', value: 'false' },
  { column: 'sl_account_id', op: '<>', value: 'null' },
  { column: 'sl_requester_id', op: '<>', value: 'null' },
];

export const getCustomerNameFromCaseDetails = () =>
  cy.slcHelpers
    .getCaseDetails({ predicates })
    // eslint-disable-next-line camelcase
    .then(({ body }) => body.map(({ sl_account_id, sl_account_name }) => ({ customerId: sl_account_id, customerName: sl_account_name })));
