import { urlHelpers } from '../../../utils';
import { apiHelpers, customerBoardPage, customerFavorites } from '../../../pages';

describe('My Customers: Table Column Sort Functionality', () => {
  let custName1 = '';
  let custName2 = '';

  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.removeAllFavoriteCustomers();
    cy.visit(urlHelpers.console.withTimeFilter.lastSevenDays);
    cy.waitForLoaders();
    cy.slcHelpers.clearCustomersQuickFilter();
    cy.slcHelpers.clearAgentsQuickFilter();
    cy.slcHelpers.clearCaseFieldQuickFilter();
    cy.slcHelpers.deleteGlobalFilter();

    apiHelpers.getCustomerDetailsWithHealthScore('40', '69').then((customerDetails) => {
      const customerDetail = Cypress._.sample(customerDetails);
      custName1 = customerDetail.name;
    });

    apiHelpers.getCustomerDetailsWithHealthScore('0', '39').then((customerDetails) => {
      const customerDetail = Cypress._.sample(customerDetails);
      custName2 = customerDetail.name;
    });
  });

  afterEach(() => apiHelpers.removeAllFavoriteCustomers());

  /*
   * // TODO - Requested API to get customers based on different ranges via - SLC- 36061
   *
   * Go to customers insights page, Add two customer names.
   * Get the Attention Score of the first Attention Score column in the list.
   * Click on Sort icon, Verify that the first Attention Score is the not same as before.
   */
  it('C127086: Verify the sort functionality of "Attention Score" column', () => {
    cy.visit(urlHelpers.customerBoard);
    customerBoardPage.customerBoardWelcomePageVisibilityCheck();
    customerBoardPage.createNewListButton().click();
    customerBoardPage.createListCustomerScoreIdLabelCheckbox().click({ force: true });
    customerBoardPage.createListAddButton().click();
    cy.waitForLoaders();
    customerBoardPage.threeDotMenuDropdown().eq(0).should('be.visible').click({ force: true });
    customerBoardPage.sortListButton().eq(0).should('be.visible').click({ force: true });
    cy.waitForLoaders();
    customerBoardPage
      .customerBoardListCustomerName()
      .eq(0)
      .then((customerName1) => {
        const customerNameFirst = customerName1.text().trim();

        customerBoardPage
          .customerBoardListCustomerName()
          .eq(8)
          .then((customerName2) => {
            const customerNameSecond = customerName2.text().trim();

            cy.visit(urlHelpers.myCustomers);
            cy.waitForLoaders();
            customerFavorites.addFavoriteButton().click();
            customerFavorites.searchTextfield().type(customerNameFirst);
            customerFavorites.searchTextFieldResultListFirst().click();
            // eslint-disable-next-line cypress/no-unnecessary-waiting
            cy.wait(1000);
            cy.waitForLoaders();
            customerFavorites.addFavoriteButton().click();
            customerFavorites.searchTextfield().type(customerNameSecond);
            customerFavorites.searchTextFieldResultListFirst().click();
            // eslint-disable-next-line cypress/no-unnecessary-waiting
            cy.wait(1000);
            cy.waitForLoaders();
            customerFavorites
              .favoritesTableAttentionScoreColumn()
              .first()
              .then(($attentionScore) => {
                const attentionScoreBeforeSort = $attentionScore.text();

                customerFavorites.favoritesTableSortColumnIcon().eq(2).trigger('mouseover').click();
                customerFavorites.favoritesTableSortColumnIcon().eq(2).trigger('mouseout');
                // eslint-disable-next-line cypress/no-unnecessary-waiting
                cy.wait(1000);
                cy.waitForLoaders();
                customerFavorites.favoritesTableAttentionScoreColumn().first().invoke('text').should('not.eq', attentionScoreBeforeSort);
                customerFavorites.favoritesTableSortColumnIcon().eq(2).trigger('mouseover').click();
                customerFavorites.favoritesTableSortColumnIcon().eq(2).trigger('mouseout');
                // eslint-disable-next-line cypress/no-unnecessary-waiting
                cy.wait(1000);
                cy.waitForLoaders();
                customerFavorites.favoritesTableAttentionScoreColumn().first().invoke('text').should('eq', attentionScoreBeforeSort);
              });
          });
      });
  });

  /*
   * // TODO - Requested API to get customers based on different ranges via - SLC- 36061
   *
   * Go to customers insights page, Add two customer names.
   * Get the Sentiment Score of the first Sentiment Score column in the list.
   * Click on Sort icon, Verify that the first Sentiment Score is the not same as before.
   */
  it('C127087: Verify the sort functionality of "Sentiment Score" column', () => {
    cy.visit(urlHelpers.customerBoard);
    customerBoardPage.customerBoardWelcomePageVisibilityCheck();
    customerBoardPage.createNewListButton().click();
    customerBoardPage.createListCustomerScoreIdLabelCheckbox().click({ force: true });
    customerBoardPage.createListAddButton().click();
    cy.waitForLoaders();
    customerBoardPage.threeDotMenuDropdown().eq(0).should('be.visible').click({ force: true });
    customerBoardPage.sortListButton().eq(0).should('be.visible').click({ force: true });
    cy.waitForLoaders();
    customerBoardPage
      .customerBoardListCustomerName()
      .eq(0)
      .then((customerName1) => {
        const customerNameFirst = customerName1.text().trim();

        customerBoardPage
          .customerBoardListCustomerName()
          .eq(8)
          .then((customerName2) => {
            const customerNameSecond = customerName2.text().trim();

            cy.visit(urlHelpers.myCustomers);
            cy.waitForLoaders();
            customerFavorites.zeroStateAddFavoriteButton().click();
            customerFavorites.searchTextfield().type(customerNameFirst);
            customerFavorites.searchTextFieldResultListFirst().click();
            // eslint-disable-next-line cypress/no-unnecessary-waiting
            cy.wait(1000);
            customerFavorites.addFavoriteButton().click();
            customerFavorites.searchTextfield().type(customerNameSecond);
            customerFavorites.searchTextFieldResultListFirst().click();
            // eslint-disable-next-line cypress/no-unnecessary-waiting
            cy.wait(1000);
            customerFavorites
              .favoritesTableSentimentScoreColumn()
              .first()
              .then(($sentimentScore) => {
                const sentimentScoreBeforeSort = $sentimentScore.text();

                customerFavorites.favoritesTableSortColumnIcon().eq(3).trigger('mouseover').click({ force: true });
                customerFavorites.favoritesTableSortColumnIcon().eq(3).trigger('mouseout');
                // eslint-disable-next-line cypress/no-unnecessary-waiting
                cy.wait(1000);
                cy.waitForLoaders();
                customerFavorites.favoritesTableSentimentScoreColumn().first().invoke('text').should('not.eq', sentimentScoreBeforeSort);
                customerFavorites.favoritesTableSortColumnIcon().eq(3).trigger('mouseover').click({ force: true });
                customerFavorites.favoritesTableSortColumnIcon().eq(3).trigger('mouseout');
                // eslint-disable-next-line cypress/no-unnecessary-waiting
                cy.wait(1000);
                cy.waitForLoaders();
                customerFavorites.favoritesTableSentimentScoreColumn().first().invoke('text').should('eq', sentimentScoreBeforeSort);
              });
          });
      });
  });

  /*
   * Go to customers insights page, Add two customer names.
   * Get the Health Score of the first Health Score column in the list.
   * Click on Sort icon, Verify that the first Health Score is the not same as before.
   */
  it('C127088: Verify the sort functionality of "Health Score" column', () => {
    cy.visit(urlHelpers.myCustomers);
    cy.waitForLoaders();
    customerFavorites.zeroStateAddFavoriteButton().click();
    customerFavorites.searchTextfield().type(custName1);
    customerFavorites.searchTextFieldResultListFirst().click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    customerFavorites.addFavoriteButton().click();
    customerFavorites.searchTextfield().type(custName2);
    customerFavorites.searchTextFieldResultListFirst().click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    cy.waitForLoaders();

    customerFavorites
      .favoritesTableHealthScoreColumn()
      .first()
      .then(($healthScore) => {
        const healthScoreBeforeSort = $healthScore.text();

        customerFavorites.favoritesTableSortColumnIcon().eq(4).trigger('mouseover').click();
        customerFavorites.favoritesTableSortColumnIcon().eq(4).trigger('mouseout');
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(1000);
        cy.waitForLoaders();
        customerFavorites.favoritesTableHealthScoreColumn().first().invoke('text').should('not.eq', healthScoreBeforeSort);
        customerFavorites.favoritesTableSortColumnIcon().eq(4).trigger('mouseover').click();
        customerFavorites.favoritesTableSortColumnIcon().eq(4).trigger('mouseout');
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(1000);
        cy.waitForLoaders();
        customerFavorites.favoritesTableHealthScoreColumn().first().invoke('text').should('eq', healthScoreBeforeSort);
      });
  });

  /*
   * Go to customers insights page, Add two customer names.
   * Get the Customer Score of the first Customer Score column in the list.
   * Click on Sort icon, Verify that the first Customer Score is the not same as before.
   */
  it('C127085: Verify the sort functionality of "Customer Score" column', () => {
    cy.visit(urlHelpers.customerBoard);
    customerBoardPage.customerBoardWelcomePageVisibilityCheck();
    customerBoardPage.createNewListButton().click();
    customerBoardPage.createListCustomerScoreIdLabelCheckbox().click({ force: true });
    customerBoardPage.createListAddButton().click();
    cy.waitForLoaders();
    customerBoardPage.threeDotMenuDropdown().eq(0).should('be.visible').click({ force: true });
    customerBoardPage.sortListButton().eq(0).should('be.visible').click({ force: true });
    cy.waitForLoaders();
    customerBoardPage
      .customerBoardListCustomerName()
      .eq(0)
      .then((customerName1) => {
        const customerNameFirst = customerName1.text().trim();

        customerBoardPage
          .customerBoardListCustomerName()
          .eq(8)
          .then((customerName2) => {
            const customerNameSecond = customerName2.text().trim();

            cy.visit(urlHelpers.myCustomers);
            cy.waitForLoaders();
            customerFavorites.zeroStateAddFavoriteButton().click();
            customerFavorites.searchTextfield().type(customerNameFirst);
            customerFavorites.searchTextFieldResultListFirst().click();
            // eslint-disable-next-line cypress/no-unnecessary-waiting
            cy.wait(1000);
            customerFavorites.addFavoriteButton().click();
            customerFavorites.searchTextfield().type(customerNameSecond);
            customerFavorites.searchTextFieldResultListFirst().click();
            // eslint-disable-next-line cypress/no-unnecessary-waiting
            cy.wait(1000);
            cy.waitForLoaders();
            customerFavorites
              .favoritesTableCustomerScoreColumn()
              .first()
              .then(($customerScore) => {
                const customerScoreBeforeSort = $customerScore.text().trim();

                customerFavorites.favoritesTableSortColumnIcon().eq(1).trigger('mouseover').click();
                customerFavorites.favoritesTableSortColumnIcon().eq(1).trigger('mouseout');
                // eslint-disable-next-line cypress/no-unnecessary-waiting
                cy.wait(1000);
                cy.waitForLoaders();
                customerFavorites.favoritesTableCustomerScoreColumn().first().invoke('text').should('not.eq', customerScoreBeforeSort);
                customerFavorites.favoritesTableSortColumnIcon().eq(1).trigger('mouseover').click();
                customerFavorites.favoritesTableSortColumnIcon().eq(1).trigger('mouseout');
                // eslint-disable-next-line cypress/no-unnecessary-waiting
                cy.wait(1000);
                cy.waitForLoaders();
                customerFavorites.favoritesTableCustomerScoreColumn().first().invoke('text').should('eq', customerScoreBeforeSort);
              });
          });
      });
  });
});
