import { urlHelpers } from '../../../utils';
import { apiHelpers, consolePage, customerFavorites, customerInsights, supportHub } from '../../../pages';

describe('My Customers: Table Column Validations', () => {
  beforeEach(() => {
    cy.intercept('PUT', 'api/users/dashboard_settings').as('editFavoriteCustomers');

    cy.loginByApi();
    apiHelpers.removeAllFavoriteCustomers();
    apiHelpers.sortCustomerScoreByAllTimeInMyCustomersPage();
    apiHelpers.sortAttentionScoreBy180DaysInMyCustomersPage();
    apiHelpers.sortSentimentScoreBy180DaysInMyCustomersPage();
    apiHelpers.sortNewCasesBy30DaysInMyCustomersPage();

    // Note: If fetched customer id is not valid/active, the tests will fail
    apiHelpers.getOpenCaseDetails().then((caseDetails) => {
      const caseDetail = Cypress._.sample(caseDetails);

      cy.wrap(caseDetail).as('caseDetail');
      cy.visit(urlHelpers.myCustomers);
    });
  });

  /*
   * Go to customers insights page, Add any customer name.
   * Validate that Customer Score column should be displayed with score from 0 to 100.
   * Hover over the i icon, Validate that tooltip text.
   * Validate that the inverted triangle columns, 'Time Period', 'All time', 'Last 3 months', 'Last 6 months'.
   * Select each options and validate that Customer Score column should be displayed with score from 0 to 100.
   */
  it('C127071: Verify the "Customer Score" column', function verifyCustomerScore() {
    apiHelpers.addCustomerToFavorite(this.caseDetail.customerId);
    cy.visit(urlHelpers.myCustomers);
    cy.waitForLoaders();
    customerFavorites.favoritesTableCustomerNameLabel().should('have.text', this.caseDetail.customerName);
    customerFavorites.favoritesTableCustomerScoreHeaderTitle().should('be.visible');
    customerFavorites.favoritesTableCustomerScoreHeaderTitle().should('have.text', 'Customer Score');
    customerFavorites.favoritesTableTooltipTriggerIcon().first().trigger('mouseover');
    customerFavorites.favoritesTableTooltipTriggerIcon().first().click();
    customerFavorites.customerScoreTooltipHeaderFirst().invoke('text').should('include', 'What does this column show?');
    customerFavorites.customerScoreTooltipHeaderFirst().invoke('text').should('include', 'Customer score based on all cases that were created for all time.');
    customerFavorites.customerScoreTooltipHeaderSecond().invoke('text').should('include', 'What is a Customer Score?');
    customerFavorites
      .customerScoreTooltipHeaderSecond()
      .invoke('text')
      .should(
        'include',
        "This is an aggregated score derived from the sentiments of this customer's cases. Recent cases and more important cases (as identified by the attention score) have greater influence on the Customer Score."
      );
    customerFavorites.favoritesTableDropdownMenuTrigger().first().should('be.visible').click();
    customerFavorites.favoritesTableDropdownOption().eq(0).should('have.text', 'Time Period');
    customerFavorites.favoritesTableDropdownOption().eq(1).should('have.text', 'All time');
    customerFavorites.favoritesTableDropdownOption().eq(2).should('have.text', 'Last 3 months');
    customerFavorites.favoritesTableDropdownOption().eq(3).should('have.text', 'Last 6 months');
    customerFavorites.favoritesTableDropdownOption().eq(2).click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    customerFavorites.favoritesTableHeaderSubtitle().eq(0).invoke('text').should('include', 'Last 3 months'.trim());
    customerFavorites.favoritesTableDropdownMenuTrigger().first().should('be.visible').click();
    customerFavorites.favoritesTableDropdownOption().eq(3).click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    customerFavorites.favoritesTableHeaderSubtitle().eq(0).invoke('text').should('include', 'Last 6 months'.trim());

    customerFavorites
      .favoritesTableCustomerScoreColumn()
      .first()
      .then(($customerScore) => {
        const customerScoreText = $customerScore.text().trim();

        if (customerScoreText !== '-') {
          const customerScoreValue = parseInt(customerScoreText, 10);

          if (Number.isNaN(customerScoreValue)) {
            expect(customerScoreValue).to.be.at.least(0).and.to.be.at.most(100);
          }
        }
      });
  });

  /*
   * Go to customers insights page, Add any customer name.
   * Validate that Attention Score column should be displayed with score from 0 to 100.
   * Hover over the i icon, Validate that tooltip text.
   * Validate that the inverted triangle columns, 'Time Period', 'Last 30 days', 'Last 60 days', 'Last 180 days'.
   * Select each options and validate that Attention Score column should be displayed with score from 0 to 100.
   */
  it('C127072: Verify the "Attention Score" column', function verifyAttentionScore() {
    const expectedTooltipText =
      'What is an Attention Score?An Attention Score represents the need for attention on acase, with very high values representing critical situations such as production downtime.It spikes whencustomers signify that an issue is important to them and naturally decreases with outbound communication.The default score is between 28 and 40, defined based on the case initial priority; higher values indicate more attention needed.';

    apiHelpers.addCustomerToFavorite(this.caseDetail.customerId);
    cy.visit(urlHelpers.myCustomers);
    cy.waitForLoaders();
    customerFavorites.favoritesTableCustomerNameLabel().should('have.text', this.caseDetail.customerName);
    customerFavorites
      .favoritesTableAttentionScoreColumn()
      .first()
      .then(($attentionScore) => {
        const attentionScore = $attentionScore.text();

        expect(parseInt(attentionScore, 10)).to.be.at.least(parseInt(0, 10)).and.to.be.at.most(parseInt(100, 10));
        customerFavorites.favoritesTableAttentionScoreHeaderTitle().should('have.text', 'Attention Score');
        customerFavorites.favoritesTableTooltipTriggerIcon().eq(1).trigger('mouseover');
        customerFavorites.attentionScoreTooltipHeaderFirst().invoke('text').should('include', 'What does this column show?');
        customerFavorites
          .attentionScoreTooltipHeaderFirst()
          .invoke('text')
          .should('include', 'Average of the attention score across all cases that were created in the last 180 days.');
        customerFavorites.attentionScoreTooltipHeaderSecond().invoke('text').should('include', 'What is an Attention Score?');
        customerFavorites.attentionScoreTooltipHeaderSecond().invoke('text').should('include', expectedTooltipText);
        customerFavorites.favoritesTableTooltipTriggerIcon().eq(1).trigger('mouseout');
        customerFavorites.favoritesTableDropdownMenuTrigger().eq(1).should('be.visible').click();
        customerFavorites.favoritesTableDropdownOption().eq(0).should('have.text', 'Time Period');
        customerFavorites.favoritesTableDropdownOption().eq(1).should('have.text', 'Last 30 days');
        customerFavorites.favoritesTableDropdownOption().eq(2).should('have.text', 'Last 60 days');
        customerFavorites.favoritesTableDropdownOption().eq(3).should('have.text', 'Last 180 days');
        customerFavorites.favoritesTableDropdownOption().eq(1).click({ force: true });
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(1000);
        customerFavorites.favoritesTableHeaderSubtitle().eq(1).invoke('text').should('include', 'Last 30 days'.trim());
        expect(parseInt(attentionScore, 10)).to.be.at.least(parseInt(0, 10)).and.to.be.at.most(parseInt(100, 10));
        customerFavorites.favoritesTableDropdownMenuTrigger().eq(1).should('be.visible').click();
        customerFavorites.favoritesTableDropdownOption().eq(2).click();
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(1000);
        customerFavorites.favoritesTableHeaderSubtitle().eq(1).invoke('text').should('include', 'Last 60 days'.trim());
        expect(parseInt(attentionScore, 10)).to.be.at.least(parseInt(0, 10)).and.to.be.at.most(parseInt(100, 10));
      });
  });

  /*
   * Go to customers insights page, Add any customer name.
   * Validate that Sentiment Score column should be displayed with score from 0 to 100.
   * Hover over the i icon, Validate that tooltip text.
   * Validate that the inverted triangle columns, 'Time Period', 'Last 30 days', 'Last 60 days', 'Last 180 days'.
   * Select each options and validate that Sentiment  Score column should be displayed with score from 0 to 100.
   */
  it('C127073: Verify the "Sentiment Score" column', function verifySentimentScore() {
    const expectedTooltipText1 =
      'A Sentiment Score represents your customer’s perceived sentiment for a case.The default score is 70; higher values indicate more positive sentiment.';

    const expectedTooltipText2 =
      'The score increases with positive, inbound sentiments and polite, outbound responses.Order matters - receiving positive sentiment after there has been negative sentiment will have a bigger boost to the Sentiment Score.The cadence and timing of communication to and from your customer is also considered.';

    apiHelpers.addCustomerToFavorite(this.caseDetail.customerId);
    cy.visit(urlHelpers.myCustomers);
    cy.waitForLoaders();
    customerFavorites.favoritesTableCustomerNameLabel().should('have.text', this.caseDetail.customerName);
    customerFavorites
      .favoritesTableSentimentScoreColumn()
      .first()
      .then(($sentimentScore) => {
        const sentimentScore = $sentimentScore.text();

        expect(parseInt(sentimentScore, 10)).to.be.at.least(parseInt(0, 10)).and.to.be.at.most(parseInt(100, 10));
        customerFavorites.favoritesTableSentimentScoreHeaderTitle().should('be.visible');
        customerFavorites.favoritesTableSentimentScoreHeaderTitle().should('have.text', 'Sentiment Score');
        customerFavorites.favoritesTableTooltipTriggerIcon().eq(2).trigger('mouseover');
        customerFavorites
          .sentimentScoreTooltipHeaderFirst()
          .invoke('text')
          .should('include', 'What does this column show?Average of the sentiment score across all cases that were created in the last 180 days.');
        customerFavorites.sentimentScoreTooltipHeaderSecond().eq(0).invoke('text').should('include', 'What is a Sentiment Score?');
        customerFavorites.sentimentScoreTooltipHeaderSecond().eq(0).invoke('text').should('include', expectedTooltipText1);
        customerFavorites.sentimentScoreTooltipHeaderSecond().eq(1).invoke('text').should('include', 'How does the score change over time?');
        customerFavorites.sentimentScoreTooltipHeaderSecond().eq(1).invoke('text').should('include', expectedTooltipText2);
        customerFavorites.favoritesTableTooltipTriggerIcon().eq(2).trigger('mouseout');
        customerFavorites.favoritesTableDropdownMenuTrigger().eq(2).should('be.visible').click();
        customerFavorites.favoritesTableDropdownOption().eq(0).should('have.text', 'Time Period');
        customerFavorites.favoritesTableDropdownOption().eq(1).should('have.text', 'Last 30 days');
        customerFavorites.favoritesTableDropdownOption().eq(2).should('have.text', 'Last 60 days');
        customerFavorites.favoritesTableDropdownOption().eq(3).should('have.text', 'Last 180 days');
        customerFavorites.favoritesTableDropdownOption().eq(1).click({ force: true });
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(1000);
        customerFavorites.favoritesTableHeaderSubtitle().eq(2).invoke('text').should('include', 'Last 30 days'.trim());
        expect(parseInt(sentimentScore, 10)).to.be.at.least(parseInt(0, 10)).and.to.be.at.most(parseInt(100, 10));
        customerFavorites.favoritesTableDropdownMenuTrigger().eq(2).should('be.visible').click();
        customerFavorites.favoritesTableDropdownOption().eq(2).click();
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(1000);
        customerFavorites.favoritesTableHeaderSubtitle().eq(2).invoke('text').should('include', 'Last 60 days'.trim());
        expect(parseInt(sentimentScore, 10)).to.be.at.least(parseInt(0, 10)).and.to.be.at.most(parseInt(100, 10));
      });
  });

  /*
   * Go to customers insights page, Add any customer name.
   * Validate that Health Score column should be displayed with score from 0 to 100.
   * Hover over the i icon, Validate that tooltip text which includes 'Bad', 'Fair', 'Good'.
   */
  it('C127074: Verify the "Health Score" column', function verifyHealthScore() {
    const expectedTooltipText1 =
      'Indicates the account has a fair amount of active severity-1/\n                sev-2 escalated cases that take longer to resolve or close. \n                Possibly requiring engineering intervention. The average case sentiment is also poor.';

    const expectedTooltipText2 =
      'Indicates the account has fewer active severity-1/severity-2 and escalated cases. \n                The average case sentiment score and resolution/closure times are slightly better than those \n                relative to an Unhealthy account but still worse than a Healthy account’s expected.';

    const expectedTooltipText3 =
      'Indicates the account has Normal/Low severity cases (do not critically impact business operations)\n                while also being closed relatively quickly. Also, the fewer number of cases\n                being created with an overall good sentiment during the handling of such cases.';

    apiHelpers.addCustomerToFavorite(this.caseDetail.customerId);
    cy.visit(urlHelpers.myCustomers);
    cy.waitForLoaders();
    customerFavorites.favoritesTableCustomerNameLabel().should('have.text', this.caseDetail.customerName);
    customerFavorites
      .favoritesTableHealthScoreColumn()
      .first()
      .then(($healthScore) => {
        const healthScore = $healthScore.text();

        expect(parseInt(healthScore, 10)).to.be.at.least(parseInt(0, 10)).and.to.be.at.most(parseInt(100, 10));
        customerFavorites.favoritesTableHealthScoreHeaderTitle().should('be.visible');
        customerFavorites.favoritesTableHealthScoreHeaderTitle().should('have.text', 'Health Score');
        customerFavorites.favoritesTableTooltipTriggerIcon().eq(3).trigger('mouseover');
        customerFavorites.healthScoreTooltipHeaderFirst().invoke('text').should('include', 'KYS and how it is calculated');
        customerFavorites.healthScoreTooltipHeaderSecond().eq(0).invoke('text').should('include', 'Bad');
        customerFavorites.healthScoreTooltipHeaderThird().eq(0).invoke('text').should('include', expectedTooltipText1);
        customerFavorites.healthScoreTooltipHeaderSecond().eq(1).invoke('text').should('include', 'Fair');
        customerFavorites.healthScoreTooltipHeaderThird().eq(1).invoke('text').should('include', expectedTooltipText2);
        customerFavorites.healthScoreTooltipHeaderSecond().eq(2).invoke('text').should('include', 'Good');
        customerFavorites.healthScoreTooltipHeaderThird().eq(2).invoke('text').should('include', expectedTooltipText3);
        customerFavorites.favoritesTableTooltipTriggerIcon().eq(3).trigger('mouseout');
        customerFavorites.favoritesTableCustomerNameLabel().click();
        customerInsights.healthScoreTab().should('have.text', 'Health Score');
        customerInsights.insightsTab().should('have.text', 'Insights');
        customerInsights.insightsTab().click();
        customerFavorites.favoritesTableHealthScoreColumn().first().invoke('text').should('eq', healthScore);
        customerFavorites.myCustomersPageBackTocustomersLinkButton().should('be.visible').click();
        cy.waitForLoaders();
        customerFavorites.myCustomersPageHeaderTitle().invoke('text').should('include', 'My Customers');
      });
  });

  /*
   * Go to customers insights page, Add any customer name.
   * Validate that New Cases column should be displayed and should have numerical characters.
   * Click on the number, Validate that Case list should be displayed and it should contain only the open cases.
   * Validate that Number on the case list and number in the column should match.
   */
  it('C127076: Verify the "New Cases" column', function verifyNewCases() {
    apiHelpers.addCustomerToFavorite(this.caseDetail.customerId);
    cy.visit(urlHelpers.myCustomers);
    cy.waitForLoaders();
    customerFavorites.favoritesTableCustomerNameLabel().should('have.text', this.caseDetail.customerName);
    customerFavorites.favoritesTableNewCasesHeaderTitle().should('have.text', 'New Cases');
    customerFavorites.favoritesTableCasesCountColumn().first().invoke('text').should('match', /\d+/);
    customerFavorites.favoritesTableHeaderSubtitle().eq(3).invoke('text').should('include', 'Last 30 days'.trim());
    customerFavorites.favoritesTableDropdownMenuTrigger().eq(3).should('be.visible').click();
    customerFavorites.favoritesTableDropdownOption().eq(0).should('have.text', 'Time Period');
    customerFavorites.favoritesTableDropdownOption().eq(1).should('have.text', 'Last 30 days');
    customerFavorites.favoritesTableDropdownOption().eq(2).should('have.text', 'Last 60 days');
    customerFavorites.favoritesTableDropdownOption().eq(3).should('have.text', 'Last 180 days');
    customerFavorites.favoritesTableDropdownOption().eq(1).click({ force: true });
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    customerFavorites.favoritesTableHeaderSubtitle().eq(3).invoke('text').should('include', 'Last 30 days'.trim());
    customerFavorites.favoritesTableDropdownMenuTrigger().eq(3).should('be.visible').click();
    customerFavorites.favoritesTableDropdownOption().eq(2).click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    customerFavorites.favoritesTableHeaderSubtitle().eq(3).invoke('text').should('include', 'Last 60 days'.trim());
    customerFavorites.favoritesTableDropdownMenuTrigger().eq(3).should('be.visible').click();
    customerFavorites.favoritesTableDropdownOption().eq(3).click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    customerFavorites.favoritesTableHeaderSubtitle().eq(3).invoke('text').should('include', 'Last 180 days'.trim());
  });

  /*
   * Go to customers insights page, Add any customer name.
   * Validate that Open Cases column should be displayed and should have numerical characters.
   * Click on the number, Validate that Case list should be displayed and it should contain only the open cases.
   * Validate that Number on the case list and number in the column should match.
   */
  it('C127077: Verify the "Open Cases" column', function verifyOpenCases() {
    apiHelpers.addCustomerToFavorite(this.caseDetail.customerId);
    cy.visit(urlHelpers.myCustomers);
    cy.waitForLoaders();
    customerFavorites.favoritesTableCustomerNameLabel().should('have.text', this.caseDetail.customerName);
    customerFavorites.favoritesTableOpenCasesHeaderTitle().should('have.text', 'Open Cases');
    customerFavorites.favoritesTableCasesCountColumn().eq(1).invoke('text').should('match', /\d+/);
    customerFavorites
      .favoritesTableCasesCountColumn()
      .eq(1)
      .then(($caseCount) => {
        const openCaseCount = $caseCount.text();

        customerFavorites.favoritesTableCasesCountColumn().eq(1).click();
        cy.waitForLoaders();
        customerFavorites.favoritesTableTicketsPopupHeaderTitle().should('be.visible').and('have.text', 'Open Cases');
        customerFavorites.favoritesTableTicketsPopupCasesCount().should('be.visible').and('have.text', openCaseCount);
        consolePage.unassignedCasesCardTitle().first().click();
        cy.waitForLoaders();
        supportHub.baseContainer().should('be.visible');
        supportHub.caseFieldStatusLabel().invoke('text').should('not.equal', 'Closed');
        supportHub.closeButton().click();
      });
  });

  /*
   * Go to customers insights page, Add any customer name.
   * Validate that Active Escalations column should be displayed and should have numerical characters.
   * Click on the number, Validate that Case list should be displayed and it should contain only the Active Escalations cases.
   * Validate that Number on the case list and number in the column should match.
   */
  it('C127091: Verify the "Active Escalations" column', function verifyActiveEscalationsCases() {
    apiHelpers.addCustomerToFavorite(this.caseDetail.customerId);
    cy.visit(urlHelpers.myCustomers);
    cy.waitForLoaders();
    customerFavorites.favoritesTableCustomerNameLabel().should('have.text', this.caseDetail.customerName);
    customerFavorites.favoritesTableActiveEscalationsCasesHeaderTitle().should('have.text', 'Active Escalations');
    customerFavorites.favoritesTableCasesCountColumn().eq(2).invoke('text').should('match', /\d+/);
    customerFavorites.favoritesTableCasesCountColumn().eq(2).click();
    cy.waitForLoaders();
    customerFavorites.favoritesTableTicketsPopupHeaderTitle().should('be.visible').and('have.text', 'Active Escalations');
    customerFavorites
      .caseListEscalatedLabel()
      .eq(0)
      .invoke('text')
      .should('match', /Escalated|Escalated\sToday/);
  });

  /*
   * Go to customers insights page, Add any customer name.
   * Validate that Total Escalations column should be displayed and should have numerical characters.
   * Click on the number, Validate that Case list should be displayed and it should contain only the Total Escalations cases.
   * Validate that Number on the case list and number in the column should match.
   */
  it('C127093: Verify the "Total Escalations" column', function verifyTotalEscalationsCases() {
    apiHelpers.addCustomerToFavorite(this.caseDetail.customerId);
    cy.visit(urlHelpers.myCustomers);
    cy.waitForLoaders();
    customerFavorites.favoritesTableCustomerNameLabel().should('have.text', this.caseDetail.customerName);
    customerFavorites.favoritesTableTotalEscalationsCasesHeaderTitle().should('have.text', 'Total Escalations');
    customerFavorites.favoritesTableCasesCountColumn().eq(3).invoke('text').should('match', /\d+/);
    customerFavorites.favoritesTableCasesCountColumn().eq(3).click();
    cy.waitForLoaders();
    customerFavorites.favoritesTableTicketsPopupHeaderTitle().should('be.visible').and('have.text', 'Total Escalations');
    customerFavorites
      .caseListEscalatedLabel()
      .eq(0)
      .invoke('text')
      .should('match', /Escalated|Escalated\sToday/);
  });
});
