import { urlHelpers } from '../../../utils';
import { apiHelpers, consolePage, customerFavorites } from '../../../pages';

describe('My Customers: Table Column Sort Functionality', () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.removeAllFavoriteCustomers();
    cy.visit(urlHelpers.console.withTimeFilter.lastSevenDays);
    cy.waitForLoaders();
    cy.slcHelpers.clearCustomersQuickFilter();
    cy.slcHelpers.clearAgentsQuickFilter();
    cy.slcHelpers.clearCaseFieldQuickFilter();
    cy.slcHelpers.deleteGlobalFilter();
    consolePage.negativeSentimentsTab().then(($casesToday) => {
      if ($casesToday.text().includes('No Cases')) {
        cy.log('No new cases');
        this.skip();
      } else {
        consolePage.negativeSentimentsTab().scrollIntoView().click({ force: true });
        consolePage.selectAllSignalsInDropdown();
        consolePage.selectShowAllInDropdown();
        consolePage.groupByElapsedTime();
        cy.waitForLoaders();

        consolePage
          .caseListCustomerName()
          .eq(0)
          .then((titleTextFirst) => {
            const titleNameFirst = titleTextFirst.text().trim();
            consolePage
              .caseListCustomerName()
              .eq(1)
              .then((titleTextSecond) => {
                const titleNameSecond = titleTextSecond.text().trim();

                cy.visit(urlHelpers.myCustomers);
                cy.waitForLoaders();
                customerFavorites.addFavoriteButton().click();
                customerFavorites.searchTextfield().type(titleNameFirst);
                customerFavorites.searchTextFieldResultListFirst().click();
                // eslint-disable-next-line cypress/no-unnecessary-waiting
                cy.wait(1000);
                customerFavorites.addFavoriteButton().click();
                customerFavorites.searchTextfield().type(titleNameSecond);
                customerFavorites.searchTextFieldResultListFirst().click();
                // eslint-disable-next-line cypress/no-unnecessary-waiting
                cy.wait(1000);
              });
          });
      }
    });
  });

  /*
   * Go to customers insights page, Add two customer names.
   * Validate that New Cases column should be displayed and should have numerical characters.
   * Get the Case Count of the first new cases column in the list.
   * Click on Sort icon, Verify that the first new cases column is the not same as before.
   */
  it('C127089: Verify the sort functionality of "New cases" column', () => {
    customerFavorites.favoritesTableCasesCountColumn().first().invoke('text').should('match', /\d+/);
    customerFavorites
      .favoritesTableCasesCountColumn()
      .first()
      .text()
      .then((caseCountBeforeSort) => {
        customerFavorites.favoritesTableSortColumnIcon().eq(4).click({ force: true });
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(1000);
        customerFavorites.favoritesTableCasesCountColumn().first().should('not.have.text', caseCountBeforeSort);
        customerFavorites.favoritesTableSortColumnIcon().eq(4).click({ force: true });
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(1000);
        customerFavorites.favoritesTableCasesCountColumn().first().should('have.text', caseCountBeforeSort);
      });
  });

  /*
   * Go to customers insights page, Add two customer names.
   * Validate that Open Cases column should be displayed and should have numerical characters.
   * Get the Case Count of the first Open cases column in the list.
   * Click on Sort icon, Verify that the first Open cases column is the not same as before.
   */
  it('C127090: Verify the sort functionality of "Open cases" column', () => {
    customerFavorites.favoritesTableCasesCountColumn().eq(1).invoke('text').should('match', /\d+/);
    customerFavorites
      .favoritesTableCasesCountColumn()
      .eq(1)
      .text()
      .then((caseCountBeforeSort) => {
        customerFavorites.favoritesTableSortColumnIcon().eq(6).click({ force: true });
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(1000);
        customerFavorites.favoritesTableCasesCountColumn().eq(1).should('not.have.text', caseCountBeforeSort);
        customerFavorites.favoritesTableSortColumnIcon().eq(6).click({ force: true });
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(1000);
        customerFavorites.favoritesTableCasesCountColumn().eq(1).should('have.text', caseCountBeforeSort);
      });
  });

  /*
   * Go to customers insights page, Add two customer names.
   * Validate that Active Escalations Cases column should be displayed and should have numerical characters.
   * Get the Case Count of the first Open cases column in the list.
   * Click on Sort icon, Verify that the first Active Escalations cases column is the not same as before.
   */
  it('C127092: Verify the sort functionality of "Active Escalations" column', () => {
    customerFavorites.favoritesTableCasesCountColumn().eq(2).invoke('text').should('match', /\d+/);
    customerFavorites
      .favoritesTableCasesCountColumn()
      .eq(2)
      .text()
      .then((caseCountBeforeSort) => {
        customerFavorites.favoritesTableSortColumnIcon().eq(7).click({ force: true });
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(1000);
        customerFavorites.favoritesTableCasesCountColumn().eq(2).should('not.have.text', caseCountBeforeSort);
        customerFavorites.favoritesTableSortColumnIcon().eq(7).click({ force: true });
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(1000);
        customerFavorites.favoritesTableCasesCountColumn().eq(2).should('have.text', caseCountBeforeSort);
      });
  });

  /*
   * Go to customers insights page, Add two customer names.
   * Validate that Total Escalations Cases column should be displayed and should have numerical characters.
   * Get the Case Count of the first Open cases column in the list.
   * Click on Sort icon, Verify that the first Total Escalations cases column is the not same as before.
   */
  it('C127098: Verify the sort functionality of "Total Escalations" column', () => {
    customerFavorites.favoritesTableCasesCountColumn().eq(3).invoke('text').should('match', /\d+/);
    customerFavorites
      .favoritesTableCasesCountColumn()
      .eq(3)
      .text()
      .then((caseCountBeforeSort) => {
        customerFavorites.favoritesTableSortColumnIcon().eq(8).click({ force: true });
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(1000);
        customerFavorites.favoritesTableCasesCountColumn().eq(3).should('not.have.text', caseCountBeforeSort);
        customerFavorites.favoritesTableSortColumnIcon().eq(8).click({ force: true });
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(1000);
        customerFavorites.favoritesTableCasesCountColumn().eq(3).should('have.text', caseCountBeforeSort);
      });
  });
});
