export const randId = () => Cypress._.random(0, 1e6);

export const switchToBoardView = () => cy.getByTestId('escalationsPage-layoutSwitcher-boardView').click();

export const expandBoard = (containerTestId) => {
  cy.getByTestId(containerTestId)
    .invoke('attr', 'data-status')
    .then((state) => {
      if (state === 'collapsed') {
        cy.getByTestId(containerTestId).click();
      }
    });
};

export const setDateFilterToRightNow = () =>
  cy.request({
    method: 'PUT',
    url: '/api/users/dashboard_settings',
    headers: { 'Content-Type': 'application/json' },
    body: {
      dashboardName: 'support',
      settingsKey: 'escalations_page_settings',
      settingsSubKey: 'calendar',
      settingsValue: { shortcut: 'all-time' },
      replace: true,
    },
  });

export const getEscalationPageSettings = () => cy.request('api/company/settings/support').then(({ body }) => body.activeCompanySettings.escalations_page_settings);

export const resetListViewColumns = () =>
  cy.request({
    method: 'PUT',
    url: 'api/users/dashboard_settings',
    body: {
      dashboardName: 'support',
      settingsKey: 'escalations_page_settings',
      settingsSubKey: null,
      settingsValue: { selected_columns_fields: [] },
      replace: false,
    },
  });
