import { urlHelpers } from '../../../utils';
import { apiHelpers, commonElements, escalations, escalationSettings, settingsSidebar } from '../../../pages';

describe('Escalations - Settings', () => {
  afterEach(() => apiHelpers.showLikelyToEscalateQueue(true));

  /*
   * IMPORTANT NOTE: THIS TEST ONLY WORKS WITH AN ADMIN LOGIN
   *
   * Visit the settings - escalations section via URL
   *
   * Check the visibility of the following texts in the page,
   *   - Escalations
   *   - SL Admin
   *   - SupportLogic Admins only
   *   - Show the Likely to Escalate queue
   *
   * Verify the visibility of the escalations section in the sidebar
   */
  it('C232: should have escalations section enabled for admin users', { tags: ['staging'] }, () => {
    cy.loginByApi();
    cy.visit(`${urlHelpers.controlCenter.settingsHome}/escalations`);

    commonElements.settingsDashboardEditorContainer().should('contain', 'Escalations');
    commonElements.settingsDashboardEditorContainer().should('contain', 'SL Admin');

    commonElements.settingsDashboardEditorContainer().should('contain', 'SupportLogic Admins only');
    commonElements.settingsDashboardEditorContainer().should('contain', 'Show the Likely to Escalate queue');

    settingsSidebar.escalationsSection().should('be.visible');
  });

  /*
   * IMPORTANT NOTE: THIS TEST ONLY WORKS WITH AN NON-ADMIN LOGIN
   *
   * Visit the settings - escalations section via URL
   *
   * Check that the of the following texts does not exist,
   *   - Escalations
   *   - SL Admin
   *   - SupportLogic Admins only
   *   - Show the Likely to Escalate queue
   *
   * Verify the escalations section does not exist
   */
  it('C233: should not have escalations section for non-admin users', { tags: ['staging'] }, () => {
    cy.loginByApi(Cypress.env('normalUserEmail'));
    cy.visit(`${urlHelpers.controlCenter.settingsHome}/escalations`);

    commonElements.settingsDashboardEditorContainer().should('not.contain', 'Escalations');
    commonElements.settingsDashboardEditorContainer().should('not.contain', 'SL Admin');

    commonElements.settingsDashboardEditorContainer().should('not.contain', 'SupportLogic Admins only');
    commonElements.settingsDashboardEditorContainer().should('not.contain', 'Show the Likely to Escalate queue');

    settingsSidebar.escalationsSection().should('not.exist');
  });

  /*
   * IMPORTANT NOTE: THIS TEST ONLY WORKS WITH AN ADMIN LOGIN
   *
   * Visit the settings - escalations section via URL
   * Click the 'Show the Likely to Escalate queue' toggle button
   * Verify the 'Saved' text is displayed
   *
   * Visit the Escalations Board page
   *
   * Verify the LTE container header contains '(not enabled)' label
   * Verify the display of lock icon and contact admin message inside the container
   */
  it('C235: should check settings `Show likely to escalate queue` functionality', { tags: ['@NotThreadSafe'] }, () => {
    cy.loginByApi();
    cy.visit(`${urlHelpers.controlCenter.settingsHome}/escalations`);

    escalationSettings.showLteToggleButton().click();
    commonElements.savedIndicatorLabel().should('be.visible').and('have.attr', 'data-status', 'success');

    cy.visit(urlHelpers.escalationBoard);

    escalations.lteContainerHeader().should('contain', '(not enabled)');
    escalations.lteContainer().within(() => {
      commonElements.lockIcon().should('be.visible');
      commonElements.contactAdminMessage().should('be.visible');
    });
  });
});
