import moment from 'moment';

import { urlHelpers } from '../../../utils';
import { datePicker } from '../../../pages';
import { getEscalationPageSettings, setDateFilterToRightNow } from './support';

const expectedDateFormat = 'MM/DD/YY';

describe('Escalations - Datepicker', () => {
  beforeEach(function beforeEachHook() {
    cy.loginByApi();
    // Skip if the calendar widget is disabled
    getEscalationPageSettings().then((settings) => {
      if (!settings.calendar_widget_enabled) this.skip();
    });

    cy.visit(urlHelpers.escalationBoard);
  });

  afterEach(() => setDateFilterToRightNow());

  /*
   * Verify that the date picker value defaults to 'Right now'
   */
  it('C259: should default to "Right now"', { tags: ['escalations', 'staging', 'prod'] }, () => {
    datePicker.datePickerTrigger().should('be.visible').and('have.text', 'Right now');
  });

  /*
   * Open the datepicker
   * Verify all the components are visible
   *
   * Click 'This month' radio button
   * Click apply button
   *
   * Verify that the datepicker value matches 'This month'
   * Verify the datepicker popover does not exist
   */
  it('C263: should check visibility of calendar components', { tags: ['staging'] }, () => {
    datePicker.datePickerTrigger().click();

    datePicker.nextMonthButton().should('be.visible').and('have.length', 2);
    datePicker.previousMonthButton().should('be.visible').and('have.length', 2);
    datePicker.calendarDayButton(' 1,').should('be.visible').and('have.length.at.least', 2);

    datePicker.fromDateTextField().should('be.visible');
    datePicker.toDateTextField().should('be.visible');

    datePicker.rightNowRadioButton().should('be.visible');
    datePicker.thisMonthRadioButton().should('be.visible');
    datePicker.lastMonthRadioButton().should('be.visible');
    datePicker.yearToDateRadioButton().should('be.visible');
    datePicker.quarterRadioButton().should('be.visible');

    datePicker.cancelButton().should('be.visible');
    datePicker.applyButton().should('be.visible');

    datePicker.thisMonthRadioButton().click();
    datePicker.applyButton().click();

    datePicker.datePickerTrigger().should('have.text', 'This month');
    datePicker.datePickerPopover().should('not.exist');
  });

  /*
   * Open the datepicker
   *
   * In the datepicker left panel:
   * Open the month dropdown and select the month 2 months before now
   * Clear and type last year's value in the year textfield
   * Select the date 1
   *
   * Repeat the above steps for the right panel
   * Click apply button
   *
   * Verify that the datepicker value matches the expected date label
   */
  it('C264: should allow changing month and year using month dropdown and year textfield', { tags: ['escalations', 'staging', 'prod'] }, () => {
    const monthBeforeLastMonth = moment().subtract(2, 'months').format('MMM');
    const lastMonth = moment().subtract(1, 'month').format('MMM');
    const lastYear = moment().subtract(1, 'year').format('YYYY');
    const firstDateOfMonth = ' 1,';

    // expected date format 'Apr 1, 2022 - May 1, 2022'
    const expectedDate = `${monthBeforeLastMonth + firstDateOfMonth} ${lastYear} - ${lastMonth + firstDateOfMonth} ${lastYear}`;

    datePicker.datePickerTrigger().click();
    cy.waitForLoaders();
    datePicker.visibleMonthDropdown().first().click();
    datePicker.monthDropdownOptions(monthBeforeLastMonth).click();
    cy.waitForLoaders();
    datePicker.visibleYearTextField().first().clear().type(lastYear);
    datePicker.calendarDayButton(firstDateOfMonth).first().click({ force: true });
    cy.waitForLoaders();
    datePicker.visibleMonthDropdown().last().click();
    datePicker.monthDropdownOptions(lastMonth).click();
    cy.waitForLoaders();
    datePicker.visibleYearTextField().last().clear().type(lastYear);
    datePicker.calendarDayButton(firstDateOfMonth).last().click({ force: true });
    cy.waitForLoaders();
    datePicker.applyButton().click();

    datePicker.datePickerTrigger().should('have.text', expectedDate);
  });

  /*
   * Open datepicker
   * Type today's date in the 'From' field
   * Type exact date from last year in the 'To' field
   *
   * Verify only 1 error message is displayed with the expected text
   */
  it('C265: should show error when To date is before From date', { tags: ['escalations', 'staging', 'prod'] }, () => {
    datePicker.datePickerTrigger().click();

    datePicker.fromDateTextField().type(moment().format(expectedDateFormat));
    datePicker.toDateTextField().type(moment().subtract(1, 'year').format(expectedDateFormat));

    datePicker.inputErrorMessageLabel().should('be.visible').and('have.length', 1).and('have.text', 'To date cannot be before From date.');
  });

  /*
   * Open datepicker
   *
   * Type today's date in the 'From' field
   * Verify only 1 error message is displayed with the expected text
   *
   * Clear the 'From' field
   * Repeat the above 2 steps for 'To' field
   */
  it('C266: should show error on leaving From (or) To field empty', { tags: ['escalations', 'staging', 'prod'] }, () => {
    const errorMessage = 'Please enter a date.';

    datePicker.datePickerTrigger().click();
    // From Field
    datePicker.toDateTextField().type(moment().format(expectedDateFormat));
    datePicker.inputErrorMessageLabel().should('be.visible').and('have.length', 1).and('have.text', errorMessage);

    // To Field
    datePicker.toDateTextField().clear();
    datePicker.fromDateTextField().type(moment().format(expectedDateFormat));
    datePicker.inputErrorMessageLabel().should('be.visible').and('have.length', 1).and('have.text', errorMessage);
  });

  /*
   * Open datepicker
   *
   * Type today's date in the 'From' field
   * Type a future date in the 'To' field
   *
   * Verify only 1 error message is displayed with the expected text
   */
  it('C267: should show error on leaving From (or) To field empty', { tags: ['escalations', 'staging', 'prod'] }, () => {
    datePicker.datePickerTrigger().click();

    datePicker.fromDateTextField().type(moment().format(expectedDateFormat));
    datePicker.toDateTextField().type(moment().add(1, 'year').format(expectedDateFormat));

    datePicker.inputErrorMessageLabel().should('be.visible').and('have.length', 1).and('have.text', 'To date cannot be after Today.');
  });

  /*
   * Open datepicker
   *
   * Type a date that's 10 years ago in 'From' field
   * Type today's date in 'To' field
   *
   * Verify an error message is displayed with the expected text
   */
  it('C268: should show error when From date is 10 years before To date', { tags: ['escalations', 'staging', 'prod'] }, () => {
    datePicker.datePickerTrigger().click();

    datePicker.fromDateTextField().type(moment().subtract(10, 'years').format(expectedDateFormat));
    datePicker.toDateTextField().type(moment().format(expectedDateFormat));

    datePicker.inputErrorMessageLabel().should('be.visible').and('have.text', 'From date cannot be beyond 10 years.');
  });

  /*
   * Verify that the datepicker button is visible
   * Open the datepicker
   *
   * Verify the visibility of the datepicker popover & the from field
   */
  it('C2226: should verify visibility of datepicker button & popover', { tags: ['escalations', 'staging', 'prod'] }, () => {
    datePicker.datePickerTrigger().should('be.visible');
    datePicker.datePickerTrigger().click();

    datePicker.datePickerPopover().should('be.visible');
    datePicker.fromDateTextField().should('be.visible');
  });
});
