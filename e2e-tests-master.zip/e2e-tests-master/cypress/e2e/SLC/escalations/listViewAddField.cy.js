import { resetListViewColumns, setDateFilterToRightNow } from './support';
import { targetDatabase, urlHelpers } from '../../../utils';

beforeEach(() => {
  cy.intercept('POST', `api/cache/${targetDatabase}/tickets/v2/data`).as('waitForCachedTicketsData');
  cy.intercept('PUT', 'api/users/dashboard_settings').as('addNewFieldsToTable');

  cy.loginByApi();
  resetListViewColumns();
  setDateFilterToRightNow();
  cy.visit(urlHelpers.escalationReport);

  cy.wait('@waitForCachedTicketsData');
});

afterEach(() => resetListViewColumns());

it('C2319: should verify add field button tooltip', { tags: 'Escalations' }, () => {
  cy.getByTestId('escalations-listView-addFieldBtn').trigger('mouseover');
  cy.get('[class*=PopperContainer]').should('have.text', 'Add a field');
});

it('C3786: should add all fields and verify add field button is still displayed', { tags: 'Escalations' }, () => {
  // open add field popup
  cy.getByTestId('escalations-listView-addFieldBtn').click();
  cy.getByTestId('escalation-addField-searchInput').should('be.visible');
  // add all the unchecked fields except the last one
  cy.get('[data-testid^=escalation-addField-option][data-status=unchecked]').then((uncheckedFields) => {
    cy.wrap(uncheckedFields.slice(0, -1)).click({ force: true, multiple: true });
  });
  // close the popup by clicking the listView switcher and verify the visibility of the Add Field + button
  cy.getByTestId('escalations-listView-addFieldBtn').click({ force: true });
  cy.getByTestId('escalations-listView-addFieldBtn').scrollIntoView().should('be.visible');
  // reopen the add field popup
  cy.getByTestId('escalations-listView-addFieldBtn').click({ force: true });
  cy.getByTestId('escalation-addField-searchInput').should('be.visible');
  // Add the last unchecked field
  cy.get('[data-testid^=escalation-addField-option][data-status=unchecked]').should('have.length', 1).click({ force: true });
  cy.wait('@addNewFieldsToTable');
  // Re-verify the visibility of the Add Field + button
  cy.getByTestId('escalations-listView-addFieldBtn').click({ force: true });
  cy.getByTestId('escalations-listView-addFieldBtn').scrollIntoView().should('be.visible');
});
