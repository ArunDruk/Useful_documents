import { agentInsights, consolePage, customerInsights, navBar } from '../../../pages';
import { urlHelpers } from '../../../utils';
import { getOpenCaseDetails } from '../supportHub/support';

// Skipping Enable Disable module test cases
describe.skip('Escalations - Enable/Disable', () => {
  // TODO: Remove once https://supportlogic.atlassian.net/browse/SLC-34704 is fixed
  // eslint-disable-next-line no-unused-vars,consistent-return
  Cypress.on('uncaught:exception', (err, runnable) => {
    if (err.message.includes("Cannot read properties of undefined (reading 'current')")) {
      return false;
    }
  });

  beforeEach(() => {
    cy.loginByApi();
    cy.slcHelpers.disableModule('escalationsBoard');
    cy.slcHelpers.disableModule('escalationsReport');

    cy.visit(urlHelpers.console.withTimeFilter.lastSevenDays);
  });

  afterEach(() => {
    cy.slcHelpers.enableModule('escalationsBoard');
    cy.slcHelpers.enableModule('escalationsReport');
  });

  /*
   * Disable the Escalations Board & Escalation Report modules (beforeEach code)
   * Verify the related navbar items does not exist
   *
   * Goto console page (beforeEach code) and verify LTE & New Escalations tabs does not exist
   *
   * Goto customer insights page
   * Switch to the insights tab
   * Verify the LTE & New Escalations tabs does not exist
   *
   * Goto agents insights page and verify escalations tab does not exist
   * // TODO: Yet to clarify the new behavior with Tali Bartal
   * Goto metrics -> efficiency page and verify escalations sub tab is not present
   *
   * Enable the module via API and re-visit default page
   * // TODO: Yet to clarify the metrics page new behavior with Tali Bartal
   * Now check the presence of escalations in navbar, customer & agents insights and metrics page.
   */
  it('C231: should enable & disable escalations module', { tags: ['@EnableDisableLockTests', '@NotThreadSafe'] }, () => {
    navBar.escalationsBoard().should('not.exist');
    navBar.escalationsReport().should('not.exist');

    consolePage.newEscalationsTab().should('not.exist');
    consolePage.lteTab().should('not.exist');

    getOpenCaseDetails().then((caseDetails) => {
      const caseDetail = Cypress._.sample(caseDetails);

      cy.visit(urlHelpers.customerInsights.customerPage(caseDetail.customerId));
      customerInsights.insightsTab().click();

      customerInsights.commonTabCard('Likely to Escalate').should('not.exist');
      customerInsights.commonTabCard('New Escalations').should('not.exist');

      cy.visit(urlHelpers.agentInsights.agentPage(caseDetail.agentId));

      agentInsights.getTabsByName('Likely to Escalate').should('not.exist');
      agentInsights.getTabsByName('New Escalations').should('not.exist');
    });

    // TODO: Yet to clarify the new behavior with Tali Bartal
    // cy.visit(urlHelpers.operationalMetrics.escalations);
    // metrics.escalationSubTab().should('not.exist');

    cy.slcHelpers.enableModule('escalationsBoard');
    cy.slcHelpers.enableModule('escalationsReport');
    cy.visit(urlHelpers.console.withTimeFilter.lastSevenDays);

    // enable flow
    navBar.escalationsBoard().should('exist');
    navBar.escalationsReport().should('exist');

    consolePage.newEscalationsTab().should('exist');
    consolePage.lteTab().should('exist');

    getOpenCaseDetails().then((caseDetails) => {
      const caseDetail = Cypress._.sample(caseDetails);

      cy.visit(urlHelpers.customerInsights.customerPage(caseDetail.customerId));
      customerInsights.insightsTab().click();
      cy.waitForLoaders();

      customerInsights.commonTabCard('Likely to Escalate').should('exist');
      customerInsights.commonTabCard('New Escalations').should('exist');

      cy.visit(urlHelpers.agentInsights.agentPage(caseDetail.agentId));
      cy.waitForLoaders();

      agentInsights.getTabsByName('Likely to Escalate').should('exist');
      agentInsights.getTabsByName('New Escalations').should('exist');
    });

    // TODO: Yet to clarify the new behavior with Tali Bartal
    // cy.visit(urlHelpers.metrics.efficiency);
    // metrics.escalationSubTab().should('exist');
  });
});
