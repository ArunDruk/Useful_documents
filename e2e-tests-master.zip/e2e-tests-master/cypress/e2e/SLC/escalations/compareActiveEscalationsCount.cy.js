import { urlHelpers } from '../../../utils';
import { setDateFilterToRightNow } from './support';
import { datePicker, escalations, metrics } from '../../../pages';

describe('Escalations Board', () => {
  beforeEach(() => {
    cy.loginByApi();
    setDateFilterToRightNow();

    cy.visit(urlHelpers.escalationBoard);
  });

  /*
   * NOTE: This TC requires a range of values instead of an exact match
   *       It was very flaky in selenium
   *
   * Get the count from active escalations column
   *
   * Visit the Operational Metrics - Escalations page
   * Set the date filter to 'This month'
   *
   * Verify that the count in escalation board is within active escalations count in the top right corner of the main chart
   */
  it('C2225: should compare active escalations count with Ops Metrics Efficiency section', { tags: ['escalations', 'staging', 'prod'] }, () => {
    escalations
      .activeEscalationsHeaderCount()
      .invoke('text')
      .then((activeEscCount) => {
        cy.visit(urlHelpers.operationalMetrics.escalations);

        datePicker
          .datePickerTrigger()
          .invoke('text')
          .then((selectedValue) => {
            if (selectedValue !== 'This month') datePicker.selectAndApplyThisMonthRadioButton();
          });

        metrics
          .activeEscalationCountLabel()
          .eq(0)
          .invoke('text')
          .then((metricsActiveEscCount) => {
            const expectedCount = parseInt(activeEscCount.replace(',', ''), 10);
            const actualCount = parseInt(metricsActiveEscCount.replace(',', ''), 10);

            expect(expectedCount).to.be.within(actualCount - 20, actualCount + 20);
          });
      });
  });
});
