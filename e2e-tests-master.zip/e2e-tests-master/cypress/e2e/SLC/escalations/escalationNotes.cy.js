import moment from 'moment-timezone';

import { randId, urlHelpers } from '../../../utils';
import { escalations, supportHub } from '../../../pages';

describe('Escalations - notes', () => {
  beforeEach(function beforeEachHook() {
    cy.intercept('POST', 'api/escalation-notes').as('postEscalationNote');

    cy.loginByApi();
    cy.visit(urlHelpers.escalationBoard);

    escalations
      .activeEscalationsHeaderCount()
      .invoke('text')
      .then((caseCount) => {
        if (caseCount === '0') this.skip();
      });

    escalations.expandContainer(escalations.activeEscalationsContainer);
  });

  /*
   * Click the escalation notes button on the 1st case card.
   * Type the desired note text
   * Close the escalation notes popup and reopen it
   *
   * Verify that the previously typed data is still there
   */
  it('C244: should check escalations notes draft feature', { tags: ['staging', 'prod'] }, () => {
    const escalationNoteText = `Test Escalation Notes Draft ${randId()}`;

    escalations.escalationNotesButton().first().click();
    supportHub.clearEscalationNotesWelcomeScreen();
    escalations.escalationNotesTextarea().clear().type(escalationNoteText);

    escalations.closeEscalationNotesPopupButton().click();
    escalations.escalationNotesButton().children('svg').should('have.attr', 'data-icon', 'edit-light');
    escalations.escalationNotesButton().first().click();
    escalations.escalationNotesTextarea().should('have.text', escalationNoteText);
  });

  /*
   * Note: Fails due to SLC-33659
   * TODO: Update once it's fixed (Task ID: QA-791)
   *
   * Click the escalation notes button on the 1st case card.
   * Type the desired note text
   * Close the escalation notes popup and reopen it
   *
   * Verify that the previously typed data is still there
   * Wait 60s (Skipped for now)
   * Press enter without changing the text
   *
   * Verify that the note is added correctly and has the recent time
   */
  it.skip('C245: should check escalations notes draft feature', { tags: ['staging'] }, () => {
    const escalationNoteText = `Test Escalation Notes Draft ${randId()}`;

    escalations.escalationNotesButton().first().click();
    supportHub.clearEscalationNotesWelcomeScreen();
    escalations.escalationNotesTextarea().clear().type(escalationNoteText);

    escalations.closeEscalationNotesPopupButton().click();
    escalations.escalationNotesButton().first().click();
    escalations.escalationNotesTextarea().should('have.text', escalationNoteText);
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(60000).then(() => {
      escalations.escalationNotesTextarea().type('{Enter}');
      cy.wait('@postEscalationNote');

      escalations.existingEscalationNoteTexts().first().should('contain.text', moment().format('H:mm A')).and('contain.text', escalationNoteText);
    });
  });

  /*
   * NOTE: Only verifying the flow in SH since it's difficult to find the exact case in other modules
   *
   * Click the escalation notes button on the first case card
   * Clear the textarea & type the escalation note text and press ENTER
   * Wait for the API call to fire
   *
   * Verify that the first added escalation note is visible & contains the expected text
   * close the escalation notes popup
   *
   * Open first active escalation case in SupportHub
   * Open the escalation notes popup
   * Verify that the first added escalation note is visible & contains the expected text
   */
  it('C258: should check escalations notes data flow', { tags: ['staging'] }, () => {
    const escalationNoteText = `Test Escalation Notes ${randId()}`;

    escalations.escalationNotesButton().first().click();
    supportHub.clearEscalationNotesWelcomeScreen();
    escalations.escalationNotesTextarea().clear().type(escalationNoteText).type('{Enter}');
    cy.wait('@postEscalationNote');

    escalations.existingEscalationNoteTexts().first().should('be.visible').and('contain.text', escalationNoteText);
    escalations.closeEscalationNotesPopupButton().click();

    escalations.activeEscalationsCaseCard().first().click();
    cy.waitForLoaders();

    supportHub.addEscalationNotesIconButton().click();
    supportHub.postedEscalationNoteText().first().should('be.visible').and('contain.text', escalationNoteText);
  });

  /*
   * Click the escalation notes button on the 1st case card.
   * Type the desired note text
   * Close the escalation notes popup and reopen it
   *
   * Login with a different user
   * Open the escalation notes popup for the first Active Escalation case in the escalations board page
   *
   * Verify that the draft note of the previous user is not there
   */
  it('C6276: should not show draft created by one user to another', { tags: ['staging'] }, () => {
    const escalationNoteText = `Test Escalation Notes Draft ${randId()}`;

    escalations.escalationNotesButton().first().click();
    supportHub.clearEscalationNotesWelcomeScreen();
    escalations.escalationNotesTextarea().clear().type(escalationNoteText);
    escalations.closeEscalationNotesPopupButton().click();

    cy.loginByApi(Cypress.env('normalUserEmail'));
    cy.visit(urlHelpers.escalationBoard);
    escalations.expandContainer(escalations.activeEscalationsContainer);

    escalations.escalationNotesButton().first().click();
    supportHub.clearEscalationNotesWelcomeScreen();
    escalations.escalationNotesTextarea().should('not.have.text', escalationNoteText);
  });
});
