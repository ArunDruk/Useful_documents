import { labelHelper, urlHelpers } from '../../../utils';
import { escalationReport } from '../../../pages';

describe('Escalations - Escalations Report Tooltips', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.escalationReport);
  });

  /* // Test Case Added to SLC-Production folder
   * Hover over the i icon in the 'Escalation status' column header
   * Verify the tooltip is visible with the below text,

   A case can have one of the following escalation statuses:

   Escalated
   The ticket is an active escalation

   Escalation Request
   An escalation request was made from the customer side or from your company side

   Escalation Request[Declined]
   Someone Declined this request (by clicking the Decline button)

   Likely to Escalate
   The ticket is currently likely to escalate (predicted by SupportLogic!)

   Likely to Escalate (Disagreed)
   Someone disagreed with this prediction (by clicking the Disagree button)

   Likely to Escalate (Snoozed)
   Someone snoozed this prediction (by clicking the Snooze button)

   Likely to Escalate
   (Acknowledged)
   Someone acknowledged this prediction (by clicking the Acknowledge button)

   Resolved
   The ticket is resolved
   */
  it('C2315: should verify escalation status info icon tooltip', { tags: ['staging'] }, () => {
    escalationReport.commonTableHeaderInfoIcon('Escalation Status').trigger('mouseover');

    escalationReport.escalationStatusTooltip().should('be.visible');
    escalationReport.escalationStatusTooltipTitle().should('be.visible').and('contain', 'A case can have one of the following escalation statuses:');
    escalationReport.escalationStatusTooltipRow().should('be.visible').and('have.length', 8);
    escalationReport.escalationStatusTooltipRow().eq(0).should('contain', 'Escalated').and('contain', 'The case is an active escalation');
    escalationReport
      .escalationStatusTooltipRow()
      .eq(1)
      .should('contain', 'Escalation Request')
      .and('contain', 'An escalation request was made from the customer side or from your company side');
    escalationReport
      .escalationStatusTooltipRow()
      .eq(2)
      .should('contain', 'Escalation Request')
      .and('contain', '(Declined)')
      .and('contain', 'Someone declined this request (by clicking the Decline button)');
    escalationReport
      .escalationStatusTooltipRow()
      .eq(3)
      .should('contain', 'Likely to Escalate')
      .and('contain', 'The case is currently likely to escalate (predicted by SupportLogic!)');
    escalationReport
      .escalationStatusTooltipRow()
      .eq(4)
      .should('contain', 'Likely to Escalate')
      .and('contain', '(Disagreed)')
      .and('contain', 'Someone disagreed with this prediction (by clicking the Disagree button)');
    escalationReport
      .escalationStatusTooltipRow()
      .eq(5)
      .should('contain', 'Likely to Escalate')
      .and('contain', '(Snoozed)')
      .and('contain', 'Someone snoozed this prediction (by clicking the Snooze button)');
    escalationReport
      .escalationStatusTooltipRow()
      .eq(6)
      .should('contain', 'Likely to Escalate')
      .and('contain', '(Acknowledged)')
      .and('contain', 'Someone acknowledged this prediction (by clicking the Acknowledge button)');
    escalationReport.escalationStatusTooltipRow().eq(7).should('contain', 'Resolved').and('contain', 'The case is resolved');
  });

  /*
   * Hover over the i icon in the 'Days to escalation' column header
   * Verify the tooltip is visible with the text "This is duration from when the case was created to when it was escalated"
   */
  it('C2317: should verify days to escalation info icon tooltip', { tags: ['staging'] }, () => {
    escalationReport.commonTableHeaderInfoIcon('Days to escalation').trigger('mouseover');

    escalationReport.infoIconTooltip().should('be.visible');
    escalationReport.infoIconTooltip().should('have.text', `This is duration from when the ${labelHelper.case} was created to when it was escalated`);
  });

  /*
   * Hover over the i icon in the 'Days spent in the escalated state' column header
   * Verify the tooltip is visible with the text "This is how long the case has been escalated"
   */
  it('C2318: should verify days spent in the escalated state info icon tooltip', { tags: ['staging'] }, () => {
    escalationReport.commonTableHeaderInfoIcon('Days spent in the escalated state').trigger('mouseover');

    escalationReport.infoIconTooltip().should('be.visible');
    escalationReport.infoIconTooltip().should('have.text', `This is how long the ${labelHelper.case} has been escalated`);
  });
});
