import { expandBoard, getEscalationPageSettings, randId, setDateFilterToRightNow } from './support';
import { targetDatabase, labelHelper, urlHelpers } from '../../../utils';
import { escalations, supportHub } from '../../../pages';

describe('Escalations - Board view tests', () => {
  beforeEach(() => {
    cy.intercept('GET', 'api/v2/case/escalation/prediction').as('fetchPredictedCases');
    cy.intercept(`api/cache/${targetDatabase}/tickets/v2/byCaseIds`).as('getByCaseIds');
    cy.intercept('POST', 'api/escalation-notes').as('postEscalationNote');

    cy.loginByApi();
    cy.visit(urlHelpers.escalationBoard);

    setDateFilterToRightNow();
    getEscalationPageSettings().then((settings) => {
      cy.wrap(settings.escalations_predictions_enabled).as('isLteEnabled');
      cy.wrap(settings.show_resolved_queue).as('hasResolvedQueue');
    });

    cy.wait('@fetchPredictedCases');
    cy.wait('@getByCaseIds');
  });

  it('C2220: should load escalation board view', { tags: 'Escalations' }, function checkPageLoading() {
    if (this.isLteEnabled) {
      escalations.lteContainer().should('be.visible');
    }
    escalations.escalationRequestsContainer().should('be.visible');
    escalations.activeEscalationsContainer().should('be.visible');
    if (this.hasResolvedQueue) {
      escalations.resolvedEscalationsContainer().should('be.visible');
    }
  });

  it('C241: should add escalation notes', { tags: 'Escalations' }, () => {
    const escalationNoteText = `Test Escalation Note ${randId()}`;

    expandBoard('escalation-list-container-activeEscalations');
    cy.getByTestId('escalationCard-notes-btn-activeEscalations').first().click({ force: true });
    cy.getByTestId('supportHub-escalationNoteDialog-editNoteInput').should('be.visible').type(`${escalationNoteText}{enter}`);
    cy.wait('@postEscalationNote');

    cy.getByTestId('supportHub-escalationNoteDialog-editNoteInput').should('not.have.text', escalationNoteText);
    cy.contains(escalationNoteText).should('be.visible');
  });

  it('C271: should verify each board has data or empty state', { tags: 'Escalations' }, function checkDataLoading() {
    const boardTestIdSuffixes = { LTE: 'escalationPredictions', escalationRequests: 'escalationRequests', activeEscalations: 'activeEscalations' };

    const escalationBoardContainerSelector = (boardTestIdSuffix) => `escalation-list-container-${boardTestIdSuffix}`;
    const escalationBoardHeaderSelector = (boardTestIdSuffix) => `escalation-list-header-${boardTestIdSuffix}`;

    if (this.hasResolvedQueue) boardTestIdSuffixes.resolvedEscalations = 'resolvedEscalations';

    Object.values(boardTestIdSuffixes).forEach((board) => {
      expandBoard(escalationBoardContainerSelector(board));

      if (board === boardTestIdSuffixes.LTE && !this.isLteEnabled) {
        cy.getByTestId(escalationBoardHeaderSelector(board)).should('contain.text', 'not enabled');
      } else {
        // TODO: Replace header count selector with testid. SLC-30756
        cy.getByTestId(escalationBoardHeaderSelector(board))
          .find('span')
          .first()
          .invoke('text')
          .then((headerText) => {
            if (headerText === '0') {
              cy.getByTestId(escalationBoardContainerSelector(board)).should('contain.text', 'Awesome work!');
            } else {
              cy.get(`[data-testid^=escalation-card-list-${board}]`).should('be.visible');
            }
          });
      }
    });
  });

  /*
   * Collapse the container (Only when it's expanded)
   * Verify the data-status attribute value is collapsed and case cards are not visible
   *
   * Expand the container (Only when it's collapsed)
   * Verify the data-status attribute value is expanded and case cards are visible (when count is not 0)
   */
  it('C240: should expand & collapse tickets list', { tags: ['staging', 'prod'] }, () => {
    const escalationTypes = [
      {
        containerElement: escalations.lteContainer,
        headerCountElement: escalations.lteHeaderCount,
        caseCardElement: escalations.lteCaseCard,
      },
      {
        containerElement: escalations.escalationRequestsContainer,
        headerCountElement: escalations.escalationRequestsHeaderCount,
        caseCardElement: escalations.escalationRequestsCaseCard,
      },
      {
        containerElement: escalations.activeEscalationsContainer,
        headerCountElement: escalations.activeEscalationsHeaderCount,
        caseCardElement: escalations.activeEscalationsCaseCard,
      },
      {
        containerElement: escalations.resolvedEscalationsContainer,
        headerCountElement: escalations.resolvedEscalationsHeaderCount,
        caseCardElement: escalations.resolvedEscalationsCaseCard,
      },
    ];

    escalationTypes.forEach(({ containerElement, headerCountElement, caseCardElement }) => {
      escalations.collapseContainer(containerElement);
      containerElement().should('have.attr', 'data-status', 'collapsed');
      caseCardElement().should('not.be.visible');

      escalations.expandContainer(containerElement);
      containerElement().should('have.attr', 'data-status', 'expanded');
      headerCountElement()
        .invoke('text')
        .then((count) => {
          if (count !== '0') caseCardElement().should('be.visible');
        });
    });
  });

  /* // Test Case Added to SLC-Production folder
   * Hover over the i icon in the LTE header
   * Verify tooltip is displayed with the expected text
   */
  it('C261: should verify LTE column info icon tooltip', { tags: ['staging', 'prod'] }, () => {
    const caseLabel = labelHelper.cases.toLowerCase();
    const expectedTooltipText = `Among the eligible prediction ${caseLabel} (i.e., ${caseLabel} that have been open for more than 12 hours but less than 30 days), the ${caseLabel} identified in this column have been predicted as "Likely to Escalate".`;

    escalations.lteHeaderInfoIcon().trigger('mouseover');
    escalations.lteInfoIconTooltip().should('be.visible').and('have.text', expectedTooltipText);
  });

  /*
   * Hover over the escalation notes button in Active Escalation case card
   *
   * Verify the tooltip visibility
   * Verify the tooltip content based on whether the ticket already has notes
   */
  it('C242: should verify active escalations - add escalation notes button tooltip', { tags: ['staging'] }, () => {
    escalations
      .escalationNotesButton()
      .first()
      .then((notesBtn) => {
        escalations.escalationNotesButton().first().realHover({ pointer: 'mouse' });
        escalations.escalationNotesButtonTooltip().should('be.visible');

        if (!notesBtn.text()) {
          escalations.escalationNotesButtonTooltip().should('contain', 'Add Escalation Notes');
        } else {
          escalations.escalationNotesButtonTooltip().should('contain', 'Add/View Escalation Notes');
        }
      });
  });

  /*
   * Open the first active escalation case in SupportHub
   * Verify that the Escalation Status label is visible and is either Escalated or Escalated Today
   */
  it('C9119: should verify escalated/escalated today tag in SH for active escalation cases', { tags: ['staging'] }, () => {
    escalations.activeEscalationsCaseCard().first().click();
    cy.waitForLoaders();

    supportHub.escalationStatusLabel().should('be.visible');
    supportHub
      .escalationStatusLabel()
      .invoke('text')
      .should('match', /Escalated|Escalated\sToday/);
  });
});
