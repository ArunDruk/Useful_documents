import { currentUserName, labelHelper, randId, urlHelpers } from '../../../../utils';
import { setDateFilterToRightNow } from '../support';
import { escalations, supportHub } from '../../../../pages';

describe('Escalation Review - Escalation Notes', () => {
  beforeEach(() => {
    cy.intercept('POST', 'api/escalation-notes').as('postEscalationNote');
    cy.intercept('POST', 'api/v2/object/action').as('updateObjectAction');

    cy.loginByApi();
    setDateFilterToRightNow();
    cy.visit(urlHelpers.escalationBoard);

    escalations.lteCaseCard().eq(1).click();
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
  });

  /*
   * Open an LTE case in SupportHub (in beforeEach)
   * Click the 'Start escalation review' button
   * Click the 'Add escalation notes' button
   * Type a message that's upto than 70 characters and click the send button
   *
   * Verify the success message is displayed in the review panel
   * Verify the newly added escalation note is visible in the timeline with info about the user who added it.
   * Verify 'Show More' and 'Show Less' buttons are not displayed
   */
  it('C9347: should show new escalation notes in timeline', { tags: ['escalations', 'staging'] }, () => {
    const actionType = 'ESCALATION_NOTE';
    const noteText = `Testing escalation notes in escalation review ${randId()}`;

    escalations.escalationReviewTriggerButton().click();
    escalations.reviewPanelEscalationNotesButton().click();
    escalations.reviewPanelEscalationNotesTextarea().type(noteText);
    escalations.reviewPanelEscalationNotesSendButton().click();
    cy.wait('@postEscalationNote');
    cy.wait('@updateObjectAction');

    escalations.reviewPanelActionCompleteBanner().should('be.visible').and('have.text', `Escalation note added to the ${labelHelper.case} successfully`);

    supportHub.timelineActionComment(actionType).first().should('be.visible');
    supportHub.timelineActionComment(actionType).first().should('contain', `${currentUserName} added an escalation note`).and('contain', noteText);

    supportHub
      .timelineActionComment(actionType)
      .first()
      .within(() => {
        supportHub.timelineCommentShowMoreButton().should('not.exist');
        supportHub.timelineCommentShowLessButton().should('not.exist');
      });
  });

  /*
   * Open an LTE case in SupportHub (in beforeEach)
   * Click the 'Start escalation review' button
   * Click the 'Add escalation notes' button
   * Type a message that's longer than 70 characters and click the send button
   *
   * Verify the success message is displayed in the review panel
   * Verify the newly added escalation note is,
   *    - Visible
   *    - Has a truncated part of the expected value (60 chars)
   *    - 'Show More' button is visible
   *
   * Click the 'Show More' button and verify the complete note text is displayed with the 'Show Less' button
   * Click the 'Show Less' button and verify the truncated note text is displayed again with the 'Show More' button
   */
  it("C9402: should display 'Show more/Show less' button in timeline for long escalation notes", { tags: ['escalations', 'staging'] }, () => {
    const actionType = 'ESCALATION_NOTE';
    const noteText = `Testing show more/show less button in SupportHub timeline for escalation notes longer than 70 characters ${randId()}`;

    escalations.escalationReviewTriggerButton().click();
    escalations.reviewPanelEscalationNotesButton().click();
    escalations.reviewPanelEscalationNotesTextarea().type(noteText);
    escalations.reviewPanelEscalationNotesSendButton().click();
    cy.wait('@postEscalationNote');
    cy.wait('@updateObjectAction');

    escalations.reviewPanelActionCompleteBanner().should('be.visible').and('have.text', `Escalation note added to the ${labelHelper.case} successfully`);
    supportHub
      .timelineActionComment(actionType)
      .first()
      .within(() => {
        cy.root().should('be.visible').and('contain', noteText.substring(0, 60)).and('contain', 'Show More');
        supportHub.timelineCommentShowMoreButton().should('be.visible').click();

        cy.root().scrollIntoView();
        cy.root().should('be.visible').and('contain', noteText);

        supportHub.timelineCommentShowLessButton().should('be.visible').click();

        cy.root().scrollIntoView();
        cy.root().should('be.visible').and('contain', noteText.substring(0, 60));

        supportHub.timelineCommentShowMoreButton().should('be.visible');
      });
  });
});
