import moment from 'moment-timezone';

import { currentUserName, urlHelpers } from '../../../../utils';
import { escalations, supportHub } from '../../../../pages';

describe('Escalations - Review', () => {
  beforeEach(() => {
    cy.intercept('POST', 'api/v2/object/action').as('postEscalationReview');
    cy.intercept('PUT', 'api/v2/case/escalation/review/*').as('updateEscalationStatus');

    cy.loginByApi();
    cy.visit(urlHelpers.escalationBoard);

    escalations.expandContainer(escalations.lteContainer);
  });

  /*
   * Open first LTE case in SupportHub
   * Fetch & store the case ID
   *
   * Click the 'Start/Continue Escalation Review' button
   * Verify the escalation review panel is visible
   *
   * Click the 'Remove from Queue' button
   * Click the 'Acknowledge prediction' button
   *
   * Verify that the 'undo' button is visible in review panel footer
   * Verify review panel footer contains 'Escalation review completed by You' text
   * Verify new case comment with '{userName} acknowledged the escalation prediction' text got added
   * Close SupportHub
   *
   * Expand the 'Reviewed Cases' container
   * Click the acknowledged sub tab
   * Verify the acknowledged case is present and visible and contains 'You acknowledged a few seconds ago' text
   *
   * Re-open the case in SupportHub
   * Undo the acknowledgement from the review panel
   *
   * Verify 'Remove from Queue' button is visible & the case comment is removed
   * Close SupportHub & verify case is removed from reviewed cases -> acknowledged tab
   */
  it('C247: should acknowledge LTE prediction', { tags: ['staging'] }, () => {
    const expectedTimelineComment = `${currentUserName} acknowledged the escalation prediction`;

    escalations.lteCaseCard().first().click();
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
    supportHub
      .caseIdLabel()
      .invoke('text')
      .then((caseId) => cy.wrap(caseId).as('caseId'));

    escalations.escalationReviewTriggerButton().last().click();
    escalations.escalationReviewPanelHeader().should('be.visible');

    escalations.removeFromQueueButton().click();
    escalations.acknowledgePredictionOption().click();
    cy.wait('@postEscalationReview');
    cy.wait('@updateEscalationStatus');

    escalations.undoEscalationReviewButton().should('be.visible');
    escalations.escalationReviewPanelFooter().should('contain.text', 'Escalation review completed by You');
    supportHub.caseCommentsContainer().first().should('contain.text', expectedTimelineComment);
    supportHub.closeButton().click();

    escalations.expandContainer(escalations.reviewedCasesContainer);
    escalations.reviewedTicketsAcknowledgedTab().click();
    cy.get('@caseId').then((caseId) => {
      escalations.reviewedCasesCaseCard(caseId).should('be.visible').and('contain.text', 'You acknowledged a few seconds ago').click();
      cy.waitForLoaders();
    });

    // Undo flow
    escalations.escalationReviewTriggerButton().last().click();
    escalations.undoEscalationReviewButton().click();
    cy.wait('@postEscalationReview');
    cy.wait('@updateEscalationStatus');

    escalations.removeFromQueueButton().should('be.visible');
    supportHub.caseCommentsContainer().first().should('not.contain.text', expectedTimelineComment);
    supportHub.closeButton().click();

    cy.get('@caseId').then((caseId) => escalations.reviewedCasesCaseCard(caseId).should('not.exist'));
  });

  /*
   * Open first LTE case in SupportHub
   * Fetch & store the case ID
   *
   * Click the 'Start/Continue Escalation Review' button
   * Verify the escalation review panel is visible
   *
   * Click the 'Remove from Queue' button
   * Click the 'snooze prediction' button
   * Select the 12 hours option
   *
   * Verify that the 'undo' button is visible in review panel footer
   * Verify review panel footer contains 'Escalation review snoozed by You' text
   * Verify new case comment with '{userName} snoozed the escalation prediction until (desired time)' text got added
   * Close SupportHub
   *
   * Expand the 'Reviewed Cases' container
   * Click the snoozed sub tab
   * Verify the snoozed case is present and visible and contains 'You snoozed a few seconds ago' text
   *
   * Re-open the case in SupportHub
   * Undo the snoozing from the review panel
   *
   * Verify 'Remove from Queue' button is visible & the case comment is removed
   * Close SupportHub & verify case is removed from reviewed cases -> snoozed tab
   */
  it('C248: should snooze LTE prediction for 12 hours', { tags: ['staging'] }, () => {
    // name is not included in validation text
    // minutes part of the time is omitted due to +/- 1min difference errors when tried
    const snoozeEndTime = moment().add(12, 'hours').format('MMMM D, YYYY h');
    const expectedTimelineComment = `${currentUserName} snoozed this escalation prediction until ${snoozeEndTime}`;

    escalations.lteCaseCard().first().click();

    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
    supportHub
      .caseIdLabel()
      .invoke('text')
      .then((caseId) => cy.wrap(caseId).as('caseId'));

    escalations.escalationReviewTriggerButton().last().click();
    escalations.escalationReviewPanelHeader().should('be.visible');

    escalations.removeFromQueueButton().click();
    escalations.snoozeItForOption().click();
    escalations.snoozeForTwelveHoursOption().click();
    cy.wait('@postEscalationReview');
    cy.wait('@updateEscalationStatus');

    escalations.undoEscalationReviewButton().should('be.visible');
    escalations.escalationReviewPanelFooter().should('contain.text', 'Escalation review snoozed by You');
    supportHub.caseCommentsContainer().first().should('contain.text', expectedTimelineComment);
    supportHub.closeButton().click();

    escalations.expandContainer(escalations.reviewedCasesContainer);
    escalations.reviewedTicketsSnoozedTab().click();
    cy.get('@caseId').then((caseId) => {
      escalations.reviewedCasesCaseCard(caseId).should('be.visible').and('contain.text', 'You snoozed a few seconds ago').click();
      cy.waitForLoaders();
    });

    // Undo flow
    escalations.escalationReviewTriggerButton().last().click();
    escalations.undoEscalationReviewButton().click();
    cy.wait('@postEscalationReview');
    cy.wait('@updateEscalationStatus');

    escalations.removeFromQueueButton().should('be.visible');
    supportHub.caseCommentsContainer().first().should('not.contain.text', expectedTimelineComment);
    supportHub.closeButton().click();

    cy.get('@caseId').then((caseId) => escalations.reviewedCasesCaseCard(caseId).should('not.exist'));
  });

  /*
   * Open first LTE case in SupportHub
   * Fetch & store the case ID
   *
   * Click the 'Start/Continue Escalation Review' button
   * Verify the escalation review panel is visible
   *
   * Click the 'Remove from Queue' button
   * Click the 'Disagree prediction' button
   *
   * Verify that the 'undo' button is visible in review panel footer
   * Verify review panel footer contains 'Escalation review disagreed by You' text
   * Verify new case comment with '{userName} disagreed the escalation prediction' text got added
   * Close SupportHub
   *
   * Expand the 'Reviewed Cases' container
   * Click the disagreed sub tab
   * Verify the disagreed case is present and visible and contains 'You disagreed a few seconds ago' text
   *
   * Re-open the case in SupportHub
   * Undo the disagreement from the review panel
   *
   * Verify 'Remove from Queue' button is visible & the case comment is removed
   * Close SupportHub & verify case is removed from reviewed cases -> disagreed tab
   */
  it('C251: should disagree with LTE prediction', { tags: ['staging'] }, () => {
    // name is not included in validation text
    const expectedTimelineComment = `${currentUserName} disagreed with the escalation prediction`;

    escalations.lteCaseCard().first().click();

    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
    supportHub
      .caseIdLabel()
      .invoke('text')
      .then((caseId) => cy.wrap(caseId).as('caseId'));

    escalations.escalationReviewTriggerButton().last().click();
    escalations.escalationReviewPanelHeader().should('be.visible');

    escalations.removeFromQueueButton().click();
    escalations.disagreeWithPredictionOption().click();
    escalations.escalationReviewOkButton().click();
    cy.wait('@postEscalationReview');
    cy.wait('@updateEscalationStatus');

    escalations.undoEscalationReviewButton().should('be.visible');
    escalations.escalationReviewPanelFooter().should('contain.text', 'Escalation review disagreed by You');
    supportHub.caseCommentsContainer().first().should('contain.text', expectedTimelineComment);
    supportHub.closeButton().click();

    escalations.expandContainer(escalations.reviewedCasesContainer);
    escalations.reviewedTicketsDisagreedTab().click();
    cy.get('@caseId').then((caseId) => {
      escalations.reviewedCasesCaseCard(caseId).should('be.visible').and('contain.text', 'You disagreed a few seconds ago').click();
      cy.waitForLoaders();
    });

    // Undo flow
    escalations.escalationReviewTriggerButton().last().click();
    escalations.undoEscalationReviewButton().click();
    cy.wait('@postEscalationReview');
    cy.wait('@updateEscalationStatus');

    escalations.removeFromQueueButton().should('be.visible');
    // name is not included in validation text
    supportHub.caseCommentsContainer().first().should('not.contain.text', expectedTimelineComment);
    supportHub.closeButton().click();

    cy.get('@caseId').then((caseId) => escalations.reviewedCasesCaseCard(caseId).should('not.exist'));
  });

  /*
   * Open first LTE case in SupportHub
   * Fetch & store the case ID
   *
   * Click the 'Start/Continue Escalation Review' button
   * Verify the escalation review panel is visible
   *
   * Click the 'Remove from Queue' button
   * Click the 'snooze prediction' button
   * Select the 3 days option
   *
   * Verify that the 'undo' button is visible in review panel footer
   * Verify review panel footer contains 'Escalation review snoozed by You' text
   * Verify new case comment with '{userName} snoozed the escalation prediction until (desired time)' text got added
   * Close SupportHub
   *
   * Expand the 'Reviewed Cases' container
   * Click the snoozed sub tab
   * Verify the snoozed case is present and visible and contains 'You snoozed a few seconds ago' text
   *
   * Re-open the case in SupportHub
   * Undo the snoozing from the review panel
   *
   * Verify 'Remove from Queue' button is visible & the case comment is removed
   * Close SupportHub & verify case is removed from reviewed cases -> snoozed tab
   */
  it('C27821: should snooze LTE prediction for 3 days', { tags: ['staging'] }, () => {
    // name is not included in validation text
    // minutes part of the time is omitted due to +/- 1min difference errors when tried
    const snoozeEndTime = moment().add(3, 'days').format('MMMM D, YYYY h');
    const expectedTimelineComment = `${currentUserName} snoozed this escalation prediction until ${snoozeEndTime}`;

    escalations.lteCaseCard().first().click();

    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
    supportHub
      .caseIdLabel()
      .invoke('text')
      .then((caseId) => cy.wrap(caseId).as('caseId'));

    escalations.escalationReviewTriggerButton().last().click();
    escalations.escalationReviewPanelHeader().should('be.visible');

    escalations.removeFromQueueButton().click();
    escalations.snoozeItForOption().click();
    escalations.snoozeForThreeDaysOption().click();
    cy.wait('@postEscalationReview');
    cy.wait('@updateEscalationStatus');

    escalations.undoEscalationReviewButton().should('be.visible');
    escalations.escalationReviewPanelFooter().should('contain.text', 'Escalation review snoozed by You');
    supportHub.caseCommentsContainer().first().should('contain.text', expectedTimelineComment);
    supportHub.closeButton().click();

    escalations.expandContainer(escalations.reviewedCasesContainer);
    escalations.reviewedTicketsSnoozedTab().click();
    cy.get('@caseId').then((caseId) => {
      escalations.reviewedCasesCaseCard(caseId).should('be.visible').and('contain.text', 'You snoozed a few seconds ago').click();
      cy.waitForLoaders();
    });

    // Undo flow
    escalations.escalationReviewTriggerButton().last().click();
    escalations.undoEscalationReviewButton().click();
    cy.wait('@postEscalationReview');
    cy.wait('@updateEscalationStatus');

    escalations.removeFromQueueButton().should('be.visible');
    supportHub.caseCommentsContainer().first().should('not.contain.text', expectedTimelineComment);
    supportHub.closeButton().click();

    cy.get('@caseId').then((caseId) => escalations.reviewedCasesCaseCard(caseId).should('not.exist'));
  });

  /*
   * Open first LTE case in SupportHub
   * Fetch & store the case ID
   *
   * Click the 'Start/Continue Escalation Review' button
   * Verify the escalation review panel is visible
   *
   * Click the 'Remove from Queue' button
   * Click the 'snooze prediction' button
   * Select the 1 day option
   *
   * Verify that the 'undo' button is visible in review panel footer
   * Verify review panel footer contains 'Escalation review snoozed by You' text
   * Verify new case comment with '{userName} snoozed the escalation prediction until (desired time)' text got added
   * Close SupportHub
   *
   * Expand the 'Reviewed Cases' container
   * Click the snoozed sub tab
   * Verify the snoozed case is present and visible and contains 'You snoozed a few seconds ago' text
   *
   * Re-open the case in SupportHub
   * Undo the snoozing from the review panel
   *
   * Verify 'Remove from Queue' button is visible & the case comment is removed
   * Close SupportHub & verify case is removed from reviewed cases -> snoozed tab
   */
  it('C27822: should snooze LTE prediction for 1 day', { tags: ['staging'] }, () => {
    // name is not included in validation text
    // minutes part of the time is omitted due to +/- 1min difference errors when tried
    const snoozeEndTime = moment().add(1, 'day').format('MMMM D, YYYY h');
    const expectedTimelineComment = `${currentUserName} snoozed this escalation prediction until ${snoozeEndTime}`;

    escalations.lteCaseCard().first().click();

    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
    supportHub
      .caseIdLabel()
      .invoke('text')
      .then((caseId) => cy.wrap(caseId).as('caseId'));

    escalations.escalationReviewTriggerButton().last().click();
    escalations.escalationReviewPanelHeader().should('be.visible');

    escalations.removeFromQueueButton().click();
    escalations.snoozeItForOption().click();
    escalations.snoozeForOneDayOption().click();
    cy.wait('@postEscalationReview');
    cy.wait('@updateEscalationStatus');

    escalations.undoEscalationReviewButton().should('be.visible');
    escalations.escalationReviewPanelFooter().should('contain.text', 'Escalation review snoozed by You');
    supportHub.caseCommentsContainer().first().should('contain.text', expectedTimelineComment);
    supportHub.closeButton().click();

    escalations.expandContainer(escalations.reviewedCasesContainer);
    escalations.reviewedTicketsSnoozedTab().click();
    cy.get('@caseId').then((caseId) => {
      escalations.reviewedCasesCaseCard(caseId).should('be.visible').and('contain.text', 'You snoozed a few seconds ago').click();
      cy.waitForLoaders();
    });

    // Undo flow
    escalations.escalationReviewTriggerButton().last().click();
    escalations.undoEscalationReviewButton().click();
    cy.wait('@postEscalationReview');
    cy.wait('@updateEscalationStatus');

    escalations.removeFromQueueButton().should('be.visible');
    supportHub.caseCommentsContainer().first().should('not.contain.text', expectedTimelineComment);
    supportHub.closeButton().click();

    cy.get('@caseId').then((caseId) => escalations.reviewedCasesCaseCard(caseId).should('not.exist'));
  });
});
