import { urlHelpers } from '../../../../utils';
import { apiHelpers, escalations } from '../../../../pages';

const testData = [
  { testRailId: 'C9210', actionType: 'CONTACT_AGENT' },
  { testRailId: 'C37737', actionType: 'CASE_NOTE' },
  { testRailId: 'C37738', actionType: 'SHARE_CASE' },
  { testRailId: 'C37739', actionType: 'REASSIGN' },
  { testRailId: 'C37740', actionType: 'CONTACT_CUSTOMER' },
  { testRailId: 'C37741', actionType: 'UPDATE_CASE_FIELD' },
  { testRailId: 'C37742', actionType: 'CUSTOMER_NOTE' },
  { testRailId: 'C37743', actionType: 'ESCALATION_NOTE' },
];

describe('Escalation Review - Settings', { tags: ['@NotThreadSafe'] }, () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.escalationBoard);

    escalations.expandContainer(escalations.lteContainer);
    escalations
      .lteCaseIds()
      .first()
      .then((caseId) => cy.wrap(caseId.text()).as('caseId'));
  });

  afterEach(() => apiHelpers.enableEscalationReviewActions(testData.map((item) => item.actionType)));

  /*
   * REPEAT THESE STEPS FOR ALL 8 ACTIONS
   *
   * Disable a recommended action
   * Open an LTE case in SupportHub
   * Click the 'Start Review' button
   *
   * Verify the disabled action button is not visible
   *
   * Re-enable the recommended action and check if it is visible
   */
  testData.forEach((item) => {
    it(`${item.testRailId}: should verify enable/disable of ${item.actionType.replace('_', '').toLowerCase()} recommended action`, function reviewActionSettings() {
      apiHelpers.disableEscalationReviewActions(item.actionType);
      cy.visit(urlHelpers.supportHubCasePage(this.caseId));

      escalations.escalationReviewTriggerButton().click();
      escalations.commonReviewPanelActionTrigger(item.actionType).should('not.exist');

      apiHelpers.enableEscalationReviewActions(item.actionType);
      cy.visit(urlHelpers.supportHubCasePage(this.caseId));

      escalations.escalationReviewTriggerButton().click();
      escalations.commonReviewPanelActionTrigger(item.actionType).should('be.visible');
    });
  });
});
