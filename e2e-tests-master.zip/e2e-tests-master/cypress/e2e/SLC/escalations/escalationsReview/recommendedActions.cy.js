import { currentUserName, randId, urlHelpers } from '../../../../utils';
import { setDateFilterToRightNow } from '../support';
import { escalations, pluginErrorPopup, supportHub } from '../../../../pages';
import { getUserInitials } from '../../supportHub/support';

describe('Escalations Review - Recommended actions', () => {
  beforeEach(() => {
    cy.intercept('POST', 'api/mail*').as('waitForCaseShare');
    cy.intercept('POST', 'api/v0/support/case_notes').as('addCaseNote');
    cy.intercept('POST', 'api/v0/support/case_owners/*').as('updateOwner');

    cy.loginByApi();
    setDateFilterToRightNow();
    cy.visit(urlHelpers.escalationBoard);

    escalations.lteCaseCard().eq(0).click();
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders({ waitForGlobalLoader: true });

    escalations.escalationReviewTriggerButton().click();
    escalations.escalationReviewPanelHeader().should('be.visible');
  });

  /*
   * TODO: Needs modification after https://supportlogic.atlassian.net/browse/SLC-35098
   *
   * Open an LTE ticket in SH and click the 'Start Escalation Review' button
   * Click the 'Contact the agent' button
   * Type the message you want to share and click 'Send'
   *
   * Verify that a success banner is displayed with the expected text
   * Wait for 3-4 seconds
   * Verify the 'Contact the agent' button is displayed with the time of last contact
   * Verify the shared message is displayed as a comment in the timeline
   */
  it('C27888: should verify contact agent workflow', { tags: ['staging'] }, () => {
    const actionType = 'CONTACT_AGENT';
    const expectedText = `Test Escalation Review Contact Agent workflow ${randId()}`;

    escalations.reviewPanelContactAgentButton().click();
    escalations.reviewPanelContactAgentTextarea().should('be.visible');
    escalations.reviewPanelContactAgentTextarea().type(expectedText);
    escalations.reviewPanelContactAgentSendButton().click();

    escalations.reviewPanelActionCompleteBanner().should('be.visible').and('have.text', 'Message sent to the agent successfully');
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(4000);

    // TODO: Add ' ago' to the end of the expected text once https://supportlogic.atlassian.net/browse/SLC-32349 is fixed
    escalations.reviewPanelContactAgentButton().should('be.visible').and('contain', 'You contacted a few seconds');
    supportHub.timelineActionComment(actionType).first().should('be.visible').and('have.text', `${currentUserName} contacted the agent`);
    supportHub.shareActionTimelineCommentContainer().first().should('contain', 'Shared this case with').and('contain', 'email').and('contain', expectedText);
  });

  /*
   * TODO: Needs modification after https://supportlogic.atlassian.net/browse/SLC-35098
   *
   * Open an LTE ticket in SH and click the 'Start Escalation Review' button
   * Click the 'Leave a case note' button
   * Type the message you want to share and click 'Send'
   *
   * Wait for the case note API call to happen
   * If SFDC plugin is displayed,
   *    Verify the visibility of the 'Maybe later' button
   * Else,
   * Verify that a success banner is displayed with the expected text
   * Wait for 3-4 seconds
   * Verify the 'Leave a case note' button is displayed with the time of last contact
   * Verify the shared message is displayed as a comment in the timeline
   */
  it('C27889: should verify add case note workflow', { tags: ['staging'] }, () => {
    const actionType = 'CASE_NOTE';
    const expectedText = `Test Escalation Review Case note workflow ${randId()}`;

    escalations.reviewPanelLeaveCaseNoteButton().click();
    supportHub.caseNotesTextarea().type(expectedText);
    supportHub.caseNotesSaveButton().click();

    cy.wait('@addCaseNote').then(({ response }) => {
      if (response.statusCode !== 200) {
        pluginErrorPopup.maybeLaterButton().should('be.visible');
      } else {
        escalations.reviewPanelActionCompleteBanner().should('be.visible').and('have.text', 'Internal note added to the case successfully');
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(4000);

        // TODO: Add ' ago' to the end of the expected text once https://supportlogic.atlassian.net/browse/SLC-32349 is fixed
        escalations.reviewPanelLeaveCaseNoteButton().should('be.visible').and('contain', 'You added a internal note a few seconds');
        supportHub.timelineActionComment(actionType).first().should('be.visible').and('have.text', `${currentUserName} left a case note`);
        supportHub
          .caseCommentByText(expectedText)
          .first()
          .within((element) => {
            cy.wrap(element).should('be.visible');

            supportHub.privateCaseNoteIcon().should('be.visible');
          });
      }
    });
  });

  /*
   * TODO: Needs modification after https://supportlogic.atlassian.net/browse/SLC-35098
   *
   * Open an LTE ticket in SH and click the 'Start Escalation Review' button
   * Click the 'Share this case' button
   * Choose the medium and recipient name
   * Type the message you want to share and click 'Send'
   *
   * Verify that a success banner is displayed with the expected text
   * Wait for 3-4 seconds
   * Verify the 'Share this case' button is displayed with the time of last contact
   * Verify the shared message is displayed as a comment in the timeline
   */
  it('C27890: should verify email ticket sharing workflow', { tags: ['staging'] }, () => {
    const actionType = 'SHARE_CASE';
    const expectedText = `Test Escalation Review share case via email workflow ${randId()}`;

    escalations.reviewPanelShareCaseButton().click();
    supportHub.sharePopupEmailButton().click();
    supportHub.sharePopupRecipientTextfield().type(Cypress.env('userEmail'));
    supportHub.sharePopupMessageTextarea().type(expectedText);
    supportHub.reviewPanelShareOptionSendButton().click();
    cy.wait('@waitForCaseShare');

    escalations.reviewPanelActionCompleteBanner().should('be.visible').and('have.text', 'Case has been shared successfully');
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(4000);

    escalations
      .reviewPanelShareCaseButton()
      .should('be.visible')
      .and('contain', `You shared this case with ${getUserInitials(currentUserName)}`);

    supportHub
      .timelineActionComment(actionType)
      .should('be.visible')
      .and('contain', `${currentUserName} shared this case with ${getUserInitials(currentUserName)}`);

    supportHub.shareActionTimelineCommentContainer().first().should('contain', 'Shared this case with').and('contain', 'email').and('contain', expectedText);
  });

  /*
   * TODO: Needs modification after https://supportlogic.atlassian.net/browse/SLC-35098
   *
   * Open an LTE ticket in SH and click the 'Start Escalation Review' button
   * Click the 'Re-assign the case' button
   * Search and assign the case to the user of your choice
   *
   * Wait for the case note API call to happen
   * If SFDC plugin is displayed,
   *    Verify the visibility of the 'Maybe later' button
   * Else,
   * Verify that a success banner is displayed with the expected text
   * Wait for 3-4 seconds
   * Verify the 'Re-assign the case' button is displayed with the time of last contact
   * Verify the shared message is displayed as a comment in the timeline as a private case note
   * Verify the case owner name on the left side matches with the new agent name
   */
  it('C27891: should verify case reassign workflow', { tags: ['staging'] }, () => {
    const actionType = 'REASSIGN';

    cy.slcHelpers.getAgentDetails().then((agentDetails) => {
      const agentDetail = Cypress._.sample(agentDetails);
      const agentName = agentDetail.sl_name;

      escalations.reviewPanelReassignCaseButton().click();
      supportHub.reviewPanelReassignAgentSearchButton().click();
      supportHub.reviewPanelReassignAgentSearchTextfield().type(agentName);
      supportHub.reviewPanelReassignAgentAssignBtn().first().click({ force: true });

      cy.wait('@updateOwner').then(({ response }) => {
        if (response.statusCode !== 200) {
          pluginErrorPopup.maybeLaterButton().should('be.visible');
        } else {
          escalations.reviewPanelActionCompleteBanner().should('be.visible').and('have.text', 'Case has been re-assigned successfully');
          // eslint-disable-next-line cypress/no-unnecessary-waiting
          cy.wait(4000);

          escalations.reviewPanelReassignCaseButton().should('be.visible').and('contain', 'You re-assigned the case to');
          supportHub.timelineActionComment(actionType).should('be.visible').and('contain', `${currentUserName} re-assigned this case to ${agentName}`);
          supportHub.caseOwnerLabel().should('contain', agentName);
        }
      });
    });
  });

  /*
   * TODO: Needs modification after https://supportlogic.atlassian.net/browse/SLC-35098
   *
   * Open an LTE ticket in SH and click the 'Start Escalation Review' button
   * Click the 'Contact the customer' button
   * Type the message you want to share and click 'Send'
   *
   * Wait for the case note API call to happen
   * If SFDC plugin is displayed,
   *    Verify the visibility of the 'Maybe later' button
   * Else,
   * Verify that a success banner is displayed with the expected text
   * Wait for 3-4 seconds
   * Verify the 'Contact the customer' button is displayed with the time of last contact
   * Verify the shared message is displayed as a comment in the timeline as a public case note
   */
  it('C27892: should verify contact customer workflow', { tags: ['staging'] }, () => {
    const actionType = 'CONTACT_CUSTOMER';
    const expectedText = `Test Escalation Review Contact Customer workflow ${randId()}`;

    escalations.reviewPanelContactCustomerButton().click();
    supportHub.caseNotesTextarea().type(expectedText);
    supportHub.caseNotesSaveButton().click();

    cy.wait('@addCaseNote').then(({ response }) => {
      if (response.statusCode !== 200) {
        pluginErrorPopup.maybeLaterButton().should('be.visible');
      } else {
        escalations.reviewPanelActionCompleteBanner().should('be.visible').and('have.text', 'Sent an external reply to the customer successfully');
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(4000);

        // TODO: Add ' ago' to the end of the expected text once https://supportlogic.atlassian.net/browse/SLC-32349 is fixed
        escalations.reviewPanelContactCustomerButton().should('be.visible').and('contain', 'You added a message a few seconds');
        supportHub.timelineActionComment(actionType).first().should('be.visible').and('have.text', `${currentUserName} left a message for the customer`);
        supportHub.caseCommentByText(expectedText).should('be.visible');
      }
    });
  });
});
