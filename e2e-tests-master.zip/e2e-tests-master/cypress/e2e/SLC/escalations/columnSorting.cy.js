import { escalations } from '../../../pages';
import { targetDatabase, urlHelpers } from '../../../utils';
import { getEscalationPageSettings, setDateFilterToRightNow } from './support';

describe('Escalations - Column Sorting', { tags: ['staging', 'prod'] }, () => {
  beforeEach(() => {
    cy.intercept('GET', 'api/v2/case/escalation/prediction').as('fetchPredictedCases');
    cy.intercept(`api/cache/${targetDatabase}/tickets/v2/byCaseIds`).as('getByCaseIds');

    cy.loginByApi();
    cy.visit(urlHelpers.escalationBoard);

    setDateFilterToRightNow();
    getEscalationPageSettings().then((settings) => {
      cy.wrap(settings.escalations_predictions_enabled).as('isLteEnabled');
      cy.wrap(settings.show_resolved_queue).as('hasResolvedQueue');
    });

    cy.wait('@fetchPredictedCases');
    cy.wait('@getByCaseIds');
  });

  it('C253: should sort LTE column cases', function lteSort() {
    if (!this.isLteEnabled) this.skip();

    const containerName = 'escalationPredictions';

    escalations.sortByOldestCase(containerName).should('be.true');
    escalations.sortByMostLikelyToEscalate(containerName).should('be.true');
    escalations.sortByMostRecentResponse(containerName).should('be.true');
    escalations.sortByLowestCaseSentiment(containerName).should('be.true');
    escalations.sortByHighestAttentionNeeded(containerName).should('be.true');
  });

  it('C254: should sort Escalation Requests column cases', () => {
    const containerName = 'escalationRequests';

    escalations.sortByOldestCase(containerName).should('be.true');
    escalations.sortByHighestPriority(containerName).should('be.true');
    escalations.sortByMostRecentRequest(containerName).should('be.true');
    escalations.sortByMostRecentResponse(containerName).should('be.true');
    escalations.sortByLowestCaseSentiment(containerName).should('be.true');
    escalations.sortByHighestAttentionNeeded(containerName).should('be.true');
  });

  it('C256: should sort Active Escalations column cases', () => {
    const containerName = 'activeEscalations';

    escalations.sortByOldestCase(containerName).should('be.true');
    escalations.sortByHighestPriority(containerName).should('be.true');
    escalations.sortByMostRecentResponse(containerName).should('be.true');
    escalations.sortByMostRecentEscalation(containerName).should('be.true');
    escalations.sortByLowestCaseSentiment(containerName).should('be.true');
    escalations.sortByHighestAttentionNeeded(containerName).should('be.true');
  });

  it('C257: should sort Resolved column cases', () => {
    const containerName = 'resolvedEscalations';

    escalations.expandContainer(escalations.resolvedEscalationsContainer);

    escalations.sortByOldestCase(containerName).should('be.true');
    escalations.sortByClosedDate(containerName).should('be.true');
    escalations.sortByLowestCaseSentiment(containerName).should('be.true');
    escalations.sortByHighestAttentionNeeded(containerName).should('be.true');
  });
});
