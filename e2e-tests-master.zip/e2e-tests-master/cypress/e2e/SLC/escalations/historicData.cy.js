import { urlHelpers } from '../../../utils';
import { setDateFilterToRightNow } from './support';
import { datePicker, escalations } from '../../../pages';

describe('Escalations - Historic Data', () => {
  beforeEach(() => {
    cy.loginByApi();
    setDateFilterToRightNow();

    cy.visit(urlHelpers.escalationBoard);
  });

  /*
   * Navigate to Escalation Board and Click on the calendar widget and select any time period other than Right Now like "This month"
   * Hover over the i icon and verify the tooltip
   * Navigate to Escalation report
   * Hover over the i icon and verify the tooltip
   * Click on the calendar widget and select "Right Now"
   * Hover over the i icon and verify the tooltip
   */
  it('C2327: Verify the display of "Historical data" in escalation report and board', { tags: ['escalations', 'staging'] }, () => {
    datePicker.datePickerTrigger().click();
    datePicker.thisMonthRadioButton().click();
    datePicker.applyButton().click();
    cy.waitForLoaders();
    escalations.escalationBoardContainer().should('contain', ' open cases in the selected period');
    escalations.historicDataTooltipIcon().first().trigger('mouseover');
    escalations
      .tooltipText()
      .parent()
      .should('have.text', `You are currently using the historical mode.Change your calendar to 'Right Now' to act on likely to escalate cases and escalation requests.`);

    cy.visit(urlHelpers.escalationReport);
    cy.waitForLoaders();
    escalations.escalationReportContainer().should('contain', ' open cases in the selected period');
    escalations.historicDataTooltipIcon().first().trigger('mouseover');
    escalations
      .tooltipText()
      .parent()
      .should('have.text', `You are currently using the historical mode.Change your calendar to 'Right Now' to act on likely to escalate cases and escalation requests.`);

    datePicker.datePickerTrigger().click();
    datePicker.rightNowRadioButton().click();
    datePicker.applyButton().click();
    cy.waitForLoaders();
    escalations.escalationReportContainer().should('contain', ' are likely to escalate');
    escalations.currentDataTooltipIcon().first().trigger('mouseover');
    escalations
      .tooltipText()
      .parent()
      .should('not.have.text', `You are currently using the historical mode.Change your calendar to 'Right Now' to act on likely to escalate cases and escalation requests.`);
  });
});
