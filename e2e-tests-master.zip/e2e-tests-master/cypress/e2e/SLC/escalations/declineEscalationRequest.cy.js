import { urlHelpers } from '../../../utils';
import { escalations } from '../../../pages';

describe('Escalations - Decline Escalation Request', () => {
  beforeEach(function beforeEachHook() {
    cy.intercept('POST', 'api/v2/object/action').as('objectAction');

    cy.loginByApi();
    cy.visit(urlHelpers.escalationBoard);

    escalations
      .escalationRequestsContainer()
      .invoke('text')
      .then((caseCount) => {
        if (caseCount === '0') this.skip();
      });

    escalations.expandContainer(escalations.activeEscalationsContainer);
  });

  /*
   * TODO: This test will fail due to a qa-automation specific bug (https://supportlogic.atlassian.net/browse/SLC-35015)
   *
   * Fetch the case ID label from the first Escalation Requests case card
   * Click the decline button on the first Escalation Requests case card
   * wait for the object action API request
   *
   * Expand the Reviewed Cases column
   * Click the Disagreed sub-tab
   * Verify that the declined case is visible
   *
   * Undo the disagreement
   * wait for the object action API request
   *
   * Verify that the case is not in disagreed list & is displayed in the Escalation Requests column
   */
  it('C2334: should display declined tickets in escalation board & escalation report', { tags: ['escalations', 'staging'] }, () => {
    escalations
      .escalationRequestsCaseCardCaseId()
      .first()
      .invoke('text')
      .then((caseId) => {
        escalations.escalationRequestsDeclineRequestButton().first().click();
        cy.wait('@objectAction');

        escalations.expandContainer(escalations.reviewedCasesContainer);
        escalations.reviewedTicketsDisagreedTab().click();
        escalations.reviewedCasesCaseCard(caseId).should('be.visible');

        escalations.reviewedCasesUndoButtonByCaseId(caseId).click();
        cy.wait('@objectAction');

        escalations.reviewedCasesCaseCard(caseId).should('not.exist');
        escalations.escalationRequestsCaseCard().first().should('contain.text', caseId).and('be.visible');
      });
  });
});
