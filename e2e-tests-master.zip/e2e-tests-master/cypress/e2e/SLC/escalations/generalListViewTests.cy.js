import path from 'path';
import { setDateFilterToRightNow } from './support';
import { targetDatabase, urlHelpers } from '../../../utils';

beforeEach(() => {
  cy.intercept('GET', 'api/v2/case/escalation/prediction').as('fetchPredictedCases');
  cy.intercept(`api/cache/${targetDatabase}/tickets/v2/byCaseIds`).as('getByCaseIds');
  cy.intercept('POST', 'api/escalation-notes').as('postEscalationNote');

  cy.loginByApi();
  cy.visit(urlHelpers.escalationReport);
  setDateFilterToRightNow();

  cy.wait('@fetchPredictedCases');
  cy.wait('@getByCaseIds');
});

it('C236: should load escalation report list view', { tags: 'Escalations' }, () => {
  cy.getByTestId('escalations-listView-exportAsCsvBtn').should('be.visible');
  cy.getByTestId('escalations-listView-addFieldBtn').scrollIntoView().should('be.visible');
});

it('C239: should download file on export', { tags: 'Escalations' }, () => {
  const expectedFileName = 'escalations.csv';
  const downloadsFolder = Cypress.config('downloadsFolder');

  cy.getByTestId('escalations-listView-exportAsCsvBtn').should('be.visible').click();
  cy.readFile(path.join(downloadsFolder, expectedFileName)).should('exist');
});
