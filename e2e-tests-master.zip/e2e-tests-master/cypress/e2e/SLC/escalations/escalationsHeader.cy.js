import { labelHelper, urlHelpers } from '../../../utils';
import { escalations } from '../../../pages';

describe('Escalations - Header', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.escalationBoard);
  });

  /*
   * Verify the header text is visible and of the format `X out of Y cases (Z%) are likely to escalate`
   * Verify the header text is exactly the same between the escalations board & escalations report module
   */
  it('C9372: should verify header message', { tags: ['escalations', 'staging'] }, () => {
    escalations.headerText().should('be.visible');
    escalations
      .headerText()
      .invoke('text')
      .then(($escText) => {
        const escalateText = $escText.replace(',', '');
        expect(escalateText.trim()).to.match(RegExp(`(\\d+) out of (\\d+) ${labelHelper.cases} \\((\\d{1,2}.\\d{1,2})%\\) are likely to escalate`));
      });
    // .should('match', RegExp(`(\\d+) out of (\\d+) ${labelHelper.cases} \\((\\d{1,2}.\\d{1,2})%\\) are likely to escalate`));
    escalations
      .headerText()
      .invoke('text')
      .then((headerText) => {
        cy.visit(urlHelpers.escalationReport);

        escalations.headerText().should('have.text', headerText);
      });
  });

  /*
   * Verify the visibility of header i icon
   * Hover over it and verify a tooltip is displayed with the expected text
   *
   * Verify the same in the escalations report module
   */
  it('C9401: should verify header info icon tooltip', { tags: ['escalations', 'staging'] }, () => {
    const expectedTooltipText = `To attain optimal results our prediction model focuses on ${labelHelper.cases} that have been open for more than 12 hours but less than 30 days.`;

    escalations.headerInfoIcon().should('be.visible').trigger('mouseover');
    escalations.headerInfoIconTooltip().should('be.visible').and('have.text', expectedTooltipText);

    cy.visit(urlHelpers.escalationReport);

    escalations.headerInfoIcon().should('be.visible').trigger('mouseover');
    escalations.headerInfoIconTooltip().should('be.visible').and('have.text', expectedTooltipText);
  });
});
