import { getAgentNameFromCaseDetails } from './support';
import { urlHelpers } from '../../../utils';
import { agentInsights, apiHelpers } from '../../../pages';

describe('Search for agents', () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.clearRecentlyVisitedAgentInsight();
    getAgentNameFromCaseDetails().then((caseDetails) => {
      const caseDetail = Cypress._.sample(caseDetails);

      cy.wrap(caseDetail).as('caseDetail');

      cy.visit(urlHelpers.agentInsights.home);
    });
  });

  it('C484: search agents for invalid agent and ensure get proper message', { tags: ['Agents', 'staging', 'prod'] }, () => {
    agentInsights.agentInsightsSearchFieldInput().click();
    agentInsights.agentInsightsSearchFieldInput().type('zztop');
    agentInsights.noAgentsFoundLabel().should('be.visible').and('have.text', 'No agents found');
  });

  it('C2218: search agents and ensure get list', { tags: ['Agents', 'staging', 'prod'] }, function searchAgent() {
    agentInsights.agentInsightsSearchFieldInput().click();
    agentInsights.agentInsightsSearchFieldInput().type(this.caseDetail.agentName);
    agentInsights.agentSearchResultList().should('be.visible');
  });

  // TODO - This test will be flaky due to elastic wait. Please skip with a TODO till Iskander's wrapper gets in.
  it('C2219: search agents for valid virtual team', { tags: ['Agents', 'staging', 'prod'] }, () => {
    const vtName = 'C9413 VT DO NOT DELETE';
    /* Temp Fix due to Elastic wait - comment below lines and last delete vt line, added static vtName in above line, removed randId from Import utils line
    const vtName = `Test Personal Team ${randId()}`;

    cy.slcHelpers
      .getAgentIds(5)
      .then((agentIds) => cy.slcHelpers.createVT(vtName, agentIds))
      .wait(30000) // wait for the VT to appear in the elastic index
      .then((response) => {
        */
    agentInsights.agentInsightsSearchFieldInput().click();
    agentInsights.agentInsightsSearchFieldInput().type(vtName);
    agentInsights.agentSearchResultList().should('be.visible').and('have.text', vtName);
    /* cy.slcHelpers.deleteVgroup(response.body.id);
      });
      */
  });
});
