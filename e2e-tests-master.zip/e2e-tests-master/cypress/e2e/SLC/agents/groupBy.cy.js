import { getAgentNameFromCaseDetails } from './support';
import { urlHelpers } from '../../../utils';
import { agents, apiHelpers } from '../../../pages';

describe('Agents - Group By', () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.removeAllFavoriteAgents();
    getAgentNameFromCaseDetails().then((caseDetails) => {
      const caseDetail = Cypress._.sample(caseDetails);

      cy.wrap(caseDetail).as('caseDetail');

      cy.visit(urlHelpers.myAgents);
    });
  });

  afterEach(() => apiHelpers.removeAllFavoriteAgents());

  /*
   * Visit the My Agents page
   * Look up an agent
   * Click the group by trigger
   * Select the Case Age
   */
  it('C37839: Agent Favourites page - Group by Case Age', { tags: ['Agents', 'staging'] }, function searchAgent() {
    agents.agentSearchInputField().click();
    agents.agentSearchInputField().type(this.caseDetail.agentName);
    agents.agentSearchResultListItem().first().click();

    agents.groupByDropDownTrigger().click();
    agents.groupByDropdownOption('Case Age').click();
    agents.agentCaseGroupItems().should('contain', '< 30 Days').and('contain', '30-60 Days').and('contain', '> 60 Days');
  });

  /*
   * Visit the My Agents page
   * Look up an agent
   * Click the group by trigger
   * Select the Case Priority option
   */
  it('C37840: Agent Favourites page - Group by Case Priority', { tags: ['Agents', 'staging'] }, function searchAgent() {
    agents.agentSearchInputField().click();
    agents.agentSearchInputField().type(this.caseDetail.agentName);
    agents.agentSearchResultListItem().first().click();

    agents.groupByDropDownTrigger().click();
    agents.groupByDropdownOption('Case Priority').click();
    agents.agentCaseGroupItems().should('contain', 'High').and('contain', 'Medium').and('contain', 'Low');
  });

  /*
   * Visit the My Agents page
   * Look up an agent
   * Click the group by trigger
   * Select the Case Inactivity option
   */
  it('C37841: Agent Favourites page - Group by Case Inactivity', { tags: ['Agents', 'staging'] }, function searchAgent() {
    agents.agentSearchInputField().click();
    agents.agentSearchInputField().type(this.caseDetail.agentName);
    agents.agentSearchResultListItem().first().click();

    agents.groupByDropDownTrigger().click();
    agents.groupByDropdownOption('Case Inactivity').click();
    agents.agentCaseGroupItems().should('contain', '< 30 Days').and('contain', '30-60 Days').and('contain', '> 60 Days');
  });

  /*
   * Visit the My Agents page
   * Look up an agent
   * Click the group by trigger
   * Select the Last Outbound Comment option
   */
  it('C37842: Agent Favourites page - Group by Last Outbound comment', { tags: ['Agents', 'staging'] }, function searchAgent() {
    agents.agentSearchInputField().click();
    agents.agentSearchInputField().type(this.caseDetail.agentName);
    agents.agentSearchResultListItem().first().click();

    agents.groupByDropDownTrigger().click();
    agents.groupByDropdownOption('Last outbound comment').click();
    agents.agentCaseGroupItems().should('contain', '< 30 Days').and('contain', '30-60 Days').and('contain', '> 60 Days').and('contain', 'No Outbound');
  });
});
