const predicates = [
  { column: 'sl_is_closed', op: '=', value: 'false' },
  { column: 'sl_assignee_name', op: '<>', value: 'null' },
];

export const getAgentNameFromCaseDetails = () =>
  cy.slcHelpers
    .getCaseDetails({ predicates })
    // eslint-disable-next-line camelcase
    .then(({ body }) => body.map(({ sl_assignee_name }) => ({ agentName: sl_assignee_name })));
