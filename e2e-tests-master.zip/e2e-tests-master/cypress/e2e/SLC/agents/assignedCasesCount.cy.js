import { agentInsights, agents, consolePage, apiHelpers } from '../../../pages';
import { urlHelpers } from '../../../utils';

describe('Agents - Assigned Cases', () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.removeAllFavoriteAgents();
    cy.visit(urlHelpers.console.home);
  });

  afterEach(() => {
    cy.slcHelpers.clearAgentsQuickFilter();
    cy.slcHelpers.clearCaseFieldQuickFilter();
  });

  /*
   * Visit the console module
   * Get the backlog and this period open case count for the first agent appearing in the chart
   * Navigate to the agents page and verify the count
   * Navigate to the agent insights page and verify the count
   */
  it('C6427: Verify that the Backlog cases count is same in agent, console and CRM', { tags: ['@FilterTests', 'Console'] }, () => {
    consolePage.timeFilterButton().click().contains('Last 7 days').click();
    consolePage.newCasesTab().click();
    consolePage
      .assignedCasesChartListItem()
      .first()
      .text()
      .then((agentName) => {
        cy.waitForLoaders();
        consolePage
          .assignedCasesBacklogChartElements()
          .first()
          .realHover()
          .then(() => {
            consolePage
              .highchartsTooltip()
              .text()
              .then((backlogCountText) => {
                const backlogCount = parseInt(backlogCountText, 10);
                consolePage
                  .assignedCasesThisPeriodChartElements()
                  .first()
                  .realHover()
                  .then(() => {
                    consolePage
                      .highchartsTooltip()
                      .text()
                      .then((thisPeriodCountText) => {
                        const thisPeriodCount = parseInt(thisPeriodCountText, 10);
                        cy.visit(urlHelpers.myAgents);
                        agents.agentSearchInputField().click().type(agentName);
                        agents.agentSearchResultListItem().first().click();
                        cy.waitForLoaders();
                        agents.openCases().should('contain', backlogCount + thisPeriodCount);

                        cy.visit(urlHelpers.agentInsights.home);
                        agentInsights.agentInsightsSearchFieldInput().type(agentName);
                        agentInsights.agentSearchResultListNameLabel().should('contain', agentName).click();
                        cy.waitForLoaders();
                        agentInsights.agentNameLabel().should('have.text', agentName);
                        agentInsights.agentOpenCasesCountTab().should('contain', backlogCount + thisPeriodCount);
                      });
                  });
              });
          });
      });
  });
});
