import { getAgentNameFromCaseDetails } from './support';
import { urlHelpers } from '../../../utils';
import { agents, apiHelpers, preferences } from '../../../pages';

describe('Agent Favorites in Preferences', () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.removeAllFavoriteAgents();

    getAgentNameFromCaseDetails().then((caseDetails) => {
      const caseDetail = Cypress._.sample(caseDetails);

      cy.wrap(caseDetail).as('caseDetail');

      cy.visit(urlHelpers.myAgents);
    });
  });

  afterEach(() => apiHelpers.removeAllFavoriteAgents());

  // If the dashboard user adds new support engineer then, inside the preference tab for support
  // engineers then it should reflect in the support engineer page also.
  it('C489: add agent to group', { tags: ['Agents', 'staging', 'prod'] }, function addAgentToGroup() {
    // search for and add agent
    agents.agentSearchInputField().click().type(this.caseDetail.agentName);
    agents.agentSearchResultListItem().first().click();
    // selects profile dropdown
    preferences.userMenuButton().click();
    // selects Preferences
    preferences.userMenuPreferenceButton().click();
    preferences.preferenceFavoriteAgentsTab().click();
    // verify count shows 1 agent added
    preferences.preferenceFavoriteAgentsTitle().should('have.text', '1 Favorite Agent');
  });

  // If the dashboard user deletes support engineer then, inside preference tab for support
  //   engineers then it should reflect in the support engineer page also.
  it('C490: delete agent from group', { tags: ['Agents', 'staging', 'prod'] }, function deleteFavoriteAgent() {
    // search for and add agent
    agents.agentSearchInputField().click().type(this.caseDetail.agentName);
    agents.agentSearchResultListItem().first().click();
    // selects profile dropdown
    preferences.userMenuButton().click();
    // selects Preferences
    preferences.userMenuPreferenceButton().click();
    preferences.preferenceFavoriteAgentsTab().click();
    // verify count shows 1 agent added
    preferences.preferenceFavoriteAgentsTitle().should('have.text', '1 Favorite Agent');
    // close preferences popup
    preferences.preferencePopupCloseButton().click();
    cy.visit(urlHelpers.myAgents);
    // remove agent from favorites (no more favorites)
    agents.removeFavoriteAgentButton().click();
    // selects profile dropdown
    preferences.userMenuButton().click();
    // selects Preferences
    preferences.userMenuPreferenceButton().click();
    preferences.preferenceFavoriteAgentsTab().click();
    // verify count shows 0 favorites (removed it)
    preferences.preferenceFavoriteAgentsTitle().should('have.text', '0 Favorite Agents');
  });

  // If the dashboard user deletes any already created  group inside preference tab for support engineers then it should
  // reflect in the support engineer page also.
  // TODO - This test will be flaky due to elastic wait. Please skip with a TODO till Iskander's wrapper gets in.
  it('C491: remove agent virtual team from favorites', { tags: ['Agents', 'staging', 'prod'] }, function removeVTFromFavorites() {
    // search for and add agent
    const vtName = 'C9413 VT DO NOT DELETE';
    /* Temp Fix due to Elastic wait - comment below lines and last delete vt line, added static vtName in above line, removed randId from Import utils line
    const vtName = `Test Personal Team ${randId()}`;
    cy.slcHelpers
      .getAgentIds(5)
      .then((agentIds) => cy.slcHelpers.createVT(vtName, agentIds))
      .wait(30000) // wait for the VT to appear in the elastic index
      .then((response) => {
      */
    agents.agentSearchInputField().click().type(vtName);
    agents.agentSearchResultListItem().first().click();
    // selects profile dropdown
    preferences.userMenuButton().click();
    // selects Preferences
    preferences.userMenuPreferenceButton().click();
    preferences.preferenceFavoriteAgentsTab().click();
    // verify count shows 1 agent added
    preferences.preferenceFavoriteAgentsTitle().should('have.text', '1 Favorite Agent');
    // close preferences popup
    preferences.preferencePopupCloseButton().click();
    cy.visit(urlHelpers.myAgents);
    // remove agent from favorites (no more favorites)
    agents.removeFavoriteAgentButton().click();
    // selects profile dropdown
    preferences.userMenuButton().click();
    // selects Preferences
    preferences.userMenuPreferenceButton().click();
    preferences.preferenceFavoriteAgentsTab().click();
    // verify count shows 0 favorites (removed it)
    preferences.preferenceFavoriteAgentsTitle().should('have.text', '0 Favorite Agents');
    /* cy.slcHelpers.deleteVgroup(response.body.id);
      });
      */
  });
});
