import { getAgentNameFromCaseDetails } from './support';
import { urlHelpers } from '../../../utils';
import { agents, apiHelpers } from '../../../pages';

describe('Agents - Add or remove favorite agents with existing favorites', () => {
  let agent1;
  let agent2;

  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.removeAllFavoriteAgents();
    getAgentNameFromCaseDetails().then((caseDetails) => {
      const uniqueAgentCaseObj = Cypress._.uniqBy(caseDetails, (caseDetail) => caseDetail.agentName);

      agent1 = uniqueAgentCaseObj[0].agentName;
      agent2 = uniqueAgentCaseObj[1].agentName;

      cy.visit(urlHelpers.myAgents);
      agents.agentSearchInputField().click().type(agent1);
      agents.expandFilterButton().click();
      agents.filterByType('Individual Agent');
      agents.agentSearchResultListItem().first().click();
    });
  });

  afterEach(() => apiHelpers.removeAllFavoriteAgents());

  /*
   * Visit the My Agents page
   * Enter an agent name in the search box
   * Verify that the agent name appears in search results
   * Click the search result
   * Verify that the Agent appears on the My Agents page
   */
  it('C6941: Agent Favouriting(from the favourites tab)', { tags: ['Agents', 'staging'] }, () => {
    agents.addFavoriteButton().click();
    agents.myAgentsSearchInputField().click().type(agent2);
    agents.expandFilterButton().click();
    agents.filterByType('Individual Agent');
    agents.agentSearchResultListItem().first().click();
    agents.agentList().first().should('contain', agent2);
  });

  /*
   * Visit the My Agents page
   * Enter an agent name in the search box
   * Verify that the agent name appears in search results
   * Click the search result
   * Verify that the Agent appears on the My Agents page
   * Remove the agent from favorites
   * Verify that the Agent does not appear on the My Agents page
   */
  it('C37843: Agent Favourites - Remove an agent from Favourites', { tags: ['Agents', 'staging'] }, function removeFavoriteAgent() {
    agents.addFavoriteButton().click();
    agents.myAgentsSearchInputField().click().type(agent2);
    agents.expandFilterButton().click();
    agents.filterByType('Individual Agent');
    agents.agentSearchResultListItem().first().click();
    agents.agentList().first().should('contain', agent2);
    agents.removeFavoriteAgentButton().first().click();
    agents.agentList().first().should('not.contain', agent2);
  });

  /*
   * Visit the My Agents page
   * Enter a virtual team name in the search box
   * Verify that the name appears in search results
   * Click the search result
   * Verify that the Virtual team appears on the My Agents page
   */
  it('C37844: Agent Favourite - Adding a Virtual Team as Favourite', function validateMedianMetrics() {
    // Using static data as due to SLC-34290, a new newly created virtual queue cannot always be found
    // this case will be modified once the elastic wrapper is implemented to use realtime data
    const vtName = 'DO NOT DELETE';
    agents.addFavoriteButton().click();
    agents.myAgentsSearchInputField().type(vtName);
    agents.expandFilterButton().click();
    agents.filterByType('Virtual Team');
    agents.agentSearchResultListItem().first().should('contain', vtName).click();
    agents.agentList().first().should('contain', vtName);
    agents.addFavoriteButton().click();
    agents.myAgentsSearchInputField().type(vtName);
    agents.agentSearchResultListItem().first().should('contain', vtName).and('contain', 'Added to Favorites');
  });
});
