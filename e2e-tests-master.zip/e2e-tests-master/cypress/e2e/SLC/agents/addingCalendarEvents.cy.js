import moment from 'moment';
import { getAgentNameFromCaseDetails } from './support';
import { urlHelpers } from '../../../utils';
import { agents, alertsPage, agentInsights, apiHelpers, datePicker } from '../../../pages';

describe('My Agents - Events', { tags: ['Agent Insights', 'staging'] }, () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.removeAllFavoriteAgents();
    getAgentNameFromCaseDetails().then((caseDetails) => {
      const caseDetail = Cypress._.sample(caseDetails);
      cy.wrap(caseDetail).as('caseDetail');
      cy.visit(urlHelpers.myAgents);
    });
  });

  afterEach(() => apiHelpers.removeAllFavoriteAgents());

  /*
   * Visit the My Agents page.
   * Fetch details for an agent with active cases.
   * Enter the agent name in the search box, Click the search result.
   * Click the Add event button and select the current day in the away date picker
   * Add an Out of office event for today and validate that it should be reflected.
   */
  it('C134617: Checking the functionality of Adding Events for the Agents in my agents. (Today)', function addingEvent() {
    const dayToday = moment().add(0, 'days');

    agents.agentSearchInputField().click().type(this.caseDetail.agentName);
    agents.agentSearchResultListItem().should('be.visible');
    agents.agentSearchResultListItem().first().click();
    cy.waitForLoaders();
    agents.myAgentsAddeventButton().first().trigger('mouseover', { force: true });
    agents.myAgentsAddeventButton().click({ force: true });
    agents.myAgentsAddeventAwayDatePicker().first().click();
    datePicker.calendarDayButton(dayToday.format('MMMM D,')).click();
    agentInsights.eventDetailTextArea().type('OOO');
    agentInsights.agentInsightsOOOSaveButton().click();
    cy.waitForLoaders();
    agentInsights.OOOStatus().trigger('mouseover');
    alertsPage.mouseHoverTooltip().should('contain', 'Returning').and('contain', 'OOO');
    agentInsights.OOOStatus().should('contain', '!Out of office');
    agentInsights.OOOStatus().click();
    agentInsights.agentInsightsOOODeleteButton().should('be.visible').click();
  });
});
