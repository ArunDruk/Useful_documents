import { getAgentNameFromCaseDetails } from './support';
import { urlHelpers } from '../../../utils';
import { agents, apiHelpers } from '../../../pages';

describe('Search for and favoriting agents', () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.removeAllFavoriteAgents();

    getAgentNameFromCaseDetails().then((caseDetails) => {
      const caseDetail = Cypress._.sample(caseDetails);

      cy.wrap(caseDetail).as('caseDetail');

      cy.visit(urlHelpers.myAgents);
    });
  });

  afterEach(() => apiHelpers.removeAllFavoriteAgents());

  //   the favorite page shows any favorite agents
  it('C3787: favorites page shows favorites list', { tags: ['Agents', 'staging', 'prod'] }, function favoriteAgentList() {
    agents.agentSearchInputField().click().type(this.caseDetail.agentName);
    agents.agentSearchResultListItem().should('be.visible');
    agents.agentSearchResultListItem().first().click();
    // check for the existence of the dropdown list in the table - proves the table has loaded
    agents.groupByDropDownTrigger().should('be.visible');
  });

  //   Then search for the agent in the search box,  click on one of the suggestions and it will be added to
  //   the Favorites list .
  it('C492: add agent to favorites from favorites page search', { tags: ['Agents', 'staging', 'prod'] }, function addFavoriteAgent() {
    // search for and add agent
    agents.agentSearchInputField().click().type(this.caseDetail.agentName);
    agents.agentSearchResultListItem().first().click();
    // there is now a favorite button (star) visible so agent is added
    agents.removeFavoriteAgentButton().should('be.visible');
  });

  // // When the support engineer is removed from the favourite tag then it will also clear out from the favourites page.
  it('C487: remove agent from favorites', { tags: ['Agents', 'staging', 'prod'] }, function removeFavoriteAgent() {
    // search for and add agent
    agents.agentSearchInputField().click().type(this.caseDetail.agentName);
    agents.agentSearchResultListItem().first().click();
    // remove agent from favorites
    agents.removeFavoriteAgentButton().click();
    // this text only appears when there are no favorites listed
    cy.contains('Add an agent to All favorites!').should('be.visible');
  });
});
