import { urlHelpers } from '../../../../utils';

describe('AHS_MyCustomers_test_suite', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.myCustomers);
  });

  /**
   * Regression C6509
   * - Verify the display of AHS column in Customer favorites
   */
  it('C6509: Verify the display of AHS column in Customer favorites', { tags: ['AHS', 'staging', 'prod'] }, () => {
    cy.get('#fav-customers-table').invoke('text').should('include', 'Health Score');
  });
});
