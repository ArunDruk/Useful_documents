import { urlHelpers } from '../../../../utils';
import { customerBoardPage, healthScore } from '../../../../pages';

describe('AHS_test_suite', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.customerBoard);
  });

  afterEach(() => {
    cy.waitForLoaders();
    customerBoardPage.deleteCaseList();
  });

  /** // Test Case Added to SLC-Production folder
   * Regression C6510
   * - Should be able to create list based and HS icon should be displayed
   */
  it('C6510: Verify the display of AHS list in customer board', { tags: ['AHS', 'staging'] }, () => {
    const createdCardTitle = customerBoardPage.createHealthScoreCaseList('Fair');
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(3000);
    customerBoardPage.expandButton().eq(0).click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(3000);
    customerBoardPage
      .customerBoardExpandPopupListTitleLabel()
      .eq(0)
      .then((titleValue) => {
        expect(titleValue.text()).to.include(createdCardTitle);
      });
    healthScore.healthScoreBadgeIcon().should('exist');
    customerBoardPage.expandPopupCloseIcon().click();
  });
});
