import { apiHelpers, customerInsights, consolePage, datePicker, healthScore } from '../../../../pages';
import { urlHelpers } from '../../../../utils';

// TODO: Simplify this test case for better understanding
describe('AHS_CustomerInsights_test_suite', () => {
  let custName = '';
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.clearRecentlyVisitedCustomerInsight();
    cy.visit(urlHelpers.customerInsights.home);
    apiHelpers.getCustomerDetailsWithHealthScore('0', '99').then((customerDetails) => {
      const customerDetail = Cypress._.sample(customerDetails);
      custName = customerDetail.name;
    });
  });

  /** // Test Case Added to SLC-Production folder
   * Regression C6508
   * - Navigate to the Customer insight page, search for cutomer and click enter
   * - Click on the date picker and selet year to date (to get cases)
   * - Click on the Escalation tab and then click on the Active Escalation sub tab
   * - Verify the AHS Icon is displaying and score below 100
   */
  it('C6508: AHS_Verify the display of AHS in escalation card in customer insight page.', { tags: ['AHS', 'staging', 'prod'] }, function customerEscalations() {
    customerInsights.searchTextfield().clear().type(custName).wait(2000).type('{enter}');
    cy.waitForLoaders();
    customerInsights.healthScoreTab().click().invoke('attr', 'data-active').should('include', 'true');
    customerInsights.healthScoreTab().invoke('text').should('include', 'Health Score');
    customerInsights.insightsTab().click().invoke('attr', 'data-active').should('include', 'true');
    customerInsights.insightsTab().invoke('text').should('include', 'Insights');
    datePicker.datePickerTrigger().click();
    datePicker.yearToDateRadioButton().click();
    datePicker.applyButton().click();
    cy.waitForLoaders();
    customerInsights.commonTabCard('New Escalations').last().click({ force: true });
    consolePage.groupedByDropdown().eq(0).click();
    cy.contains('Priority').click();
    cy.waitForLoaders();
    consolePage.caseCardScoreBadgeAhsIcon().first().invoke('attr', 'class').should('include', 'AHSBadge');
    consolePage
      .caseCardScoreBadgeAhsIcon()
      .first()
      .invoke('text')
      .should('not.be.empty')
      .then((ahsValue) => {
        expect(parseInt(ahsValue, 10)).lessThan(100);
      });
  });

  /**
   * Regression C9371
   * - In the Customer health score tab, make sure the customer have escalation time.
   */
  it('C9371: AHS - Verify escalated time showing in the Customer Health Score', { tags: ['AHS', 'staging', 'prod'] }, () => {
    customerInsights.searchTextfield().clear().type(custName).wait(2000).type('{enter}');
    cy.waitForLoaders();
    // Navigate to the Health Score Page
    customerInsights.healthScoreTab().should('be.visible').click();
    cy.waitForLoaders();
    // Click on the Escalation tab
    healthScore.ahsEscalationsStatusCard().should('be.visible').click();
    healthScore.ahsCaseListHeaderTitle().should('contain', 'Escalations');
    healthScore.ahsEscalationsStatusTextLabel().should('contain.text', 'Longest open escalation');
  });

  /**
   * Regression C6437
   * - Navigate to the customerInsight page and search with the Individual Customer
   * - Health Score tab should be displayed
   * - AHS window should be displayed with share icon
   * - Health score should be displayed and it should with 0 to 100
   */
  it('C6437: AHS_Verify the display of AHS in Customer Insight page for Individual Customer', { tags: ['AHS', 'staging'] }, () => {
    cy.waitForLoaders();
    customerInsights.searchTextfield().clear().type(custName).wait(2000).type('{enter}');
    cy.waitForLoaders();
    customerInsights.healthScoreTab().should('exist');
    healthScore.ahsCaseListHeaderTitle().should('exist');
    healthScore.healthScoreShareIcon().should('exist');
    customerInsights.insightsTab().should('be.visible').click();
    healthScore.healthScoreBadgeIcon().should('exist');
    healthScore
      .healthScoreBadgeIcon()
      .first()
      .invoke('text')
      .should('not.be.empty')
      .then((ahsValue) => {
        expect(parseInt(ahsValue, 10)).lessThan(100);
      });
  });

  /**
   * Regression C9404
   * - Navigate to the customerInsight page and search with the Individual Reporters
   * - Health Score tab should not be displayed
   * - Only customer score should be displayed
   * - Health Score should not be displayed in insights tab
   *
   */
  it('C9404: AHS_Verify the display of AHS in Customer Insight page for Individual Reporters', { tags: ['AHS', 'staging'] }, () => {
    apiHelpers.getIndividualReporterDetails().then((reporterDetails) => {
      const reporterName = Cypress._.sample(reporterDetails);
      customerInsights.searchTextfield().clear().type(reporterName.sl_name).wait(2000).type('{enter}');
      cy.waitForLoaders();
      customerInsights.healthScoreTab().should('not.exist');
      customerInsights.insightTabDataViewContainer().should('exist');
      healthScore.healthScoreBadgeIcon().should('not.exist');
      customerInsights.insightTabCustomerScoreLabel().should('exist');
      customerInsights
        .insightTabCustomerScoreLabel()
        .invoke('text')
        .should('not.be.empty')
        .then((custValue) => {
          expect(parseInt(custValue, 10)).lessThan(100);
        });
    });
  });
});
