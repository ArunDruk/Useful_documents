import { consolePage, healthScore } from '../../../../pages';
import { urlHelpers } from '../../../../utils';

describe('AHS_Escalations_test_suite', () => {
  beforeEach(() => {
    cy.loginByApi();
  });

  /**
   * Regression C6504
   * - Navigate to the Escalations Board page
   * - Verify the AHS Icon is displaying and score below 100
   */
  it('C6504: Verify the display of AHS in Escalation Board', { tags: ['AHS', 'staging', 'prod'] }, () => {
    cy.visit(urlHelpers.escalationBoard);
    cy.waitForLoaders();
    consolePage.caseCardScoreBadgeAhsIcon().first().invoke('attr', 'class').should('include', 'AHSBadge');
    consolePage
      .caseCardScoreBadgeAhsIcon()
      .first()
      .invoke('text')
      .should('not.be.empty')
      .then((ahsValue) => {
        expect(parseInt(ahsValue, 10)).lessThan(100);
      });
  });

  /**
   * Regression C6511
   * - Navigate to the Escalations Report page
   * - Verify the AHS Icon is displaying and score below 100
   */
  it('C6511: Verify the display of AHS in Escalation Report', { tags: ['AHS', 'staging', 'prod'] }, () => {
    cy.visit(urlHelpers.escalationReport);
    cy.waitForLoaders();
    healthScore.healthScoreBadgeIcon().last().invoke('attr', 'class').should('include', 'AHSBadge');
    healthScore
      .healthScoreBadgeIcon()
      .last()
      .invoke('text')
      .should('not.be.empty')
      .then((ahsValue) => {
        expect(parseInt(ahsValue, 10)).lessThan(100);
      });
  });
});
