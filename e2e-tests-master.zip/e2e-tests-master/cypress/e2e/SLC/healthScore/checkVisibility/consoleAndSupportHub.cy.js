import { consolePage, healthScore } from '../../../../pages';
import { urlHelpers } from '../../../../utils';

describe('AHS_Console_SupportHub_test_suite', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.console.withTimeFilter.lastSevenDays);
  });

  // TODO: Skipping the test cases until new escalation is implemented (need to select the dropdown as per changes)
  /**
   * Regression C6506
   * - Visit Console page
   * - Click on New Escalations
   * - Validate the Health score is showing in the case cards in new escalations tab.
   */
  it.skip('C6506: Verify the display of AHS in Console Escalation card', { tags: ['AHS', 'staging', 'prod'] }, function consoleEscalations() {
    consolePage
      .consoleSliderContainer()
      .invoke('text')
      .then((escalationTab) => {
        const reg = /Escalations/;
        const found = escalationTab.match(reg);
        if (!found) {
          this.skip('Escalations tab Not found');
        }
      });
    consolePage.escalationsTab().click();
    consolePage.groupedByDropdown().last().click();
    cy.contains('Escalation State').click();
    consolePage.caseCardScoreBadgeAhsIcon().first().invoke('attr', 'class').should('include', 'AHSBadge');
    consolePage
      .caseCardScoreBadgeAhsIcon()
      .first()
      .invoke('text')
      .should('not.be.empty')
      .then((ahsValue) => {
        expect(parseInt(ahsValue, 10)).lessThan(100);
      });
  });

  /** // Test Case Added to SLC-Production folder
   * Regression C6436
   * - Click on New Cases tab and click on Case list
   * - In the opened SupportHub , Verify the display of Health score
   */
  it('C6436: Verify the display of AHS in SupportHub', { tags: ['AHS', 'staging', 'prod'] }, () => {
    consolePage.timeFilterButton().click().contains('Last 7 days').click();
    consolePage.newCasesTab().click();
    consolePage.unassignedCaseCardLists().first().click();
    healthScore.healthScoreBadgeIcon().first().invoke('attr', 'class').should('include', 'AHSBadge');
    healthScore
      .healthScoreBadgeIcon()
      .first()
      .invoke('text')
      .should('not.be.empty')
      .then((ahsValue) => {
        expect(parseInt(ahsValue, 10)).lessThan(100);
      });
  });
});
