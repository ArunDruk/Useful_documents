import { caseAssignment, healthScore } from '../../../../pages';
import { urlHelpers } from '../../../../utils';

describe('AHS_ICA_test_suite', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.caseAssignment);
  });

  /**
   * Regression C6512
   * - Navigate to the Case Assignment page
   * - Click on the Unassigned tab and click on the case card from the list
   * - Verify the AHS Icon is displaying and score below 100
   */
  it('C6512: AHS_Verify the display of AHS in ICA_unassigned', { tags: ['AHS', 'staging', 'prod'] }, () => {
    caseAssignment.unassignedTab().click();
    cy.waitForLoaders();
    caseAssignment.caseListItemCard().first().click();
    healthScore.healthScoreBadgeIcon().first().invoke('attr', 'class').should('include', 'AHSBadge');
    healthScore
      .healthScoreBadgeIcon()
      .first()
      .invoke('text')
      .should('not.be.empty')
      .then((ahsValue) => {
        expect(parseInt(ahsValue, 10)).lessThan(100);
      });
  });

  /**
   * Regression C9354
   * - Navigate to the Case Assignment page
   * - Click on the Assigned tab and click on the case card from the list
   * - Verify the AHS Icon is displaying and score below 100
   */
  it('C9354: AHS_Verify the display of AHS in ICA module_Assigned tab', { tags: ['AHS', 'staging', 'Prod'] }, function ICAassigned() {
    caseAssignment
      .assignedTodayTab()
      .click()
      .then((caseCount) => {
        const count = caseCount.text();
        const reg = /\d+/;
        const result = count.match(reg);
        const num = parseInt(result[0], 10);
        if (num === 0) {
          this.skip('No cases in ICA Assigned tab');
        }
        caseAssignment.caseListItemCard().first().click();
        healthScore.healthScoreBadgeIcon().first().invoke('attr', 'class').should('include', 'AHSBadge');
        healthScore
          .healthScoreBadgeIcon()
          .first()
          .invoke('text')
          .should('not.be.empty')
          .then((ahsValue) => {
            expect(parseInt(ahsValue, 10)).lessThan(100);
          });
      });
  });
});
