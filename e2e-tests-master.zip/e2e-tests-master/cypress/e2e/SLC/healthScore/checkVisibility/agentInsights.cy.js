import { agentInsights, datePicker, consolePage, apiHelpers } from '../../../../pages';
import { urlHelpers } from '../../../../utils';

describe('AHS_Agent_Insights_test_suite', () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.clearRecentlyVisitedAgentInsight();
    cy.visit(urlHelpers.agentInsights.home);
  });

  /**
   * Regression C6507
   * - Navigate to the agent insight page, search for agent and click enter
   * - Click on the date picker and selet year to date (to get cases)
   * - Click on the Escalation tab and then click on the Active Escalation sub tab
   * - Verify the AHS Icon is displaying and score below 100
   */
  it('C6507: Verify the display of AHS in agents insights', { tags: ['AHS', 'staging', 'prod'] }, function AgentsInsights() {
    agentInsights.agentInsightsSearchFieldInput().clear().type('a').wait(2000).type('{enter}');
    cy.waitForLoaders();
    agentInsights.agentActivityTab().click().invoke('attr', 'data-active').should('include', 'true');
    cy.waitForLoaders();
    datePicker.setToYearToDateOption();
    cy.waitForLoaders();
    agentInsights.getTabsByName('New Escalations').first().click();
    cy.waitForLoaders();
    consolePage.groupedByDropdown().click();
    cy.contains('Priority').click();
    consolePage.caseCardScoreBadgeAhsIcon().first().invoke('attr', 'class').should('include', 'AHSBadge');
    consolePage
      .caseCardScoreBadgeAhsIcon()
      .first()
      .invoke('text')
      .should('not.be.empty')
      .then((ahsValue) => {
        expect(parseInt(ahsValue, 10)).lessThan(100);
      });
  });
});
