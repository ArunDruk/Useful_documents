import { apiHelpers, customerInsights, healthScore, virtualAccount } from '../../../../pages';
import { urlHelpers } from '../../../../utils';

describe('AHS_VirtualAccount_test_suite', () => {
  const vaName = 'C9405 VA DO NOT DELETE';
  const vgName = 'C9405 VG DO NOT DELETE';
  let vaMergedName = '';
  before(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.virtualAccounts);
    apiHelpers.clearRecentlyVisitedCustomerInsight();
    cy.waitForLoaders();
    /* TODO: Temp Fix due to Elastic wait - comment below 2 lines and after (), added static vaName vgName
    vaName = virtualAccount.createVirtualAccount('Personal');
    vgName = virtualAccount.createVirtualGroup('Personal');
    */
    virtualAccount
      .searchResultSystemOfRecordsMergedAccountList()
      .eq(0)
      .then((acctName) => {
        vaMergedName = acctName.text();
      });
  });

  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.customerInsights.home);
  });

  /* TODO: Temp Fix due to Elastic wait - commented after(), 2lines in before(), added static vaName vgName
  after(() => {
    cy.visit(urlHelpers.virtualAccounts);
    cy.waitForLoaders();
    virtualAccount.searchVaNameInput().click();
    virtualAccount.deleteVirtualGroup(vgName);
    virtualAccount.deleteVirtualAccount(vaName);
  });
  */

  /**
   * Regression C9405
   * - Navigate to the customerInsight page and search with the Virtual Account
   * - Health Score should be NOT displayed in insights tab
   * - Customer Sentiment score should be displayed
   */
  it('C9405: AHS_Verify the display of AHS in Customer Insight page for Virtual Accounts', { tags: ['AHS', 'staging'] }, () => {
    cy.waitForLoaders();
    customerInsights.searchTextfield().clear().type(vaName).wait(2000).type('{enter}');
    cy.waitForLoaders();
    customerInsights.healthScoreTab().should('not.exist');
    healthScore.healthScoreBadgeIcon().should('not.exist');
    customerInsights.insightTabDataViewContainer().should('exist');
    customerInsights.insightTabCustomerScoreLabel().should('exist');
    customerInsights
      .insightTabCustomerScoreLabel()
      .invoke('text')
      .should('not.be.empty')
      .then((custValue) => {
        expect(parseInt(custValue, 10)).lessThan(100);
      });
  });

  /**
   * Regression C9406
   * - Navigate to the customerInsight page and search with the Virtual Group
   * - Health Score tab should not be displayed
   * - Health Score should be displayed in insights tab and it should with 0 to 100
   */
  it('C9406: AHS_Verify the display of AHS in Customer Insight page for Virtual Group', { tags: ['AHS', 'staging'] }, () => {
    cy.waitForLoaders();
    customerInsights.searchTextfield().clear().type(vgName).wait(2000).type('{enter}');
    cy.waitForLoaders();
    customerInsights.healthScoreTab().should('not.exist');
    customerInsights.insightTabDataViewContainer().should('exist');
    healthScore.healthScoreBadgeIcon().should('exist');
    healthScore
      .healthScoreBadgeIcon()
      .first()
      .invoke('text')
      .should('not.be.empty')
      .then((ahsValue) => {
        expect(parseInt(ahsValue, 10)).lessThan(100);
      });
  });

  /**
   * Regression C9407
   * - Navigate to the customerInsight page and search with the Salesforce merged customer
   * - AHS window should be displayed with share icon
   * - Health score should be displayed and it should with 0 to 100
   */
  it('C9407: AHS_Verify the display of AHS in Customer Insight page for Salesforce merged customer ', { tags: ['AHS', 'staging'] }, () => {
    cy.waitForLoaders();
    customerInsights.searchTextfield().clear().type(vaMergedName).wait(2000).type('{enter}');
    cy.waitForLoaders();
    cy.waitForLoaders();
    customerInsights.healthScoreTab().should('exist');
    healthScore.healthScoreShareIcon().should('exist');
    customerInsights.insightsTab().should('be.visible').click();
    healthScore.healthScoreBadgeIcon().should('exist');
    healthScore
      .healthScoreBadgeIcon()
      .first()
      .invoke('text')
      .should('not.be.empty')
      .then((ahsValue) => {
        expect(parseInt(ahsValue, 10)).lessThan(100);
      });
  });
});
