import { customerInsights, healthScore, supportHub, apiHelpers } from '../../../pages';
import { urlHelpers } from '../../../utils';

describe('AHS Tests Share Functionality', () => {
  let custName = '';
  before(() => {
    cy.loginByApi();
    apiHelpers.clearRecentlyVisitedCustomerInsight();
    // Getting Customer name with Health Score Fair
    apiHelpers.getCustomerDetailsWithHealthScore('40', '69').then((customerDetails) => {
      const customerDetail = Cypress._.sample(customerDetails);
      custName = customerDetail.name;
    });
  });

  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.customerInsights.home);
  });

  /**
   * Regression C6540
   * - Navigate to Customer insight page and search for a Customer
   * - Click on any ticket and click on the health score icon
   * - In Health Score details popup share icon should not displayed
   */
  it('C6540: AHS_Verify the display of sharing icon and tooltip', { tags: ['AHS', 'staging'] }, () => {
    customerInsights
      .searchTextfield()
      .should('be.visible')
      .type(custName)
      .then(() => {
        customerInsights.searchResultListCustomerNameLabel().contains(custName).click();
      });
    cy.waitForLoaders();
    customerInsights.healthScoreTab().should('be.visible').click();
    cy.waitForLoaders();
    healthScore.healthScoreShareIcon().should('exist').trigger('mouseover');
    cy.contains('Share').should('exist');
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(3000);
    healthScore.healthScoreCaseList().eq(0).should('be.visible').click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
    healthScore.healthScoreBadgeIcon().should('be.visible').click();
    healthScore.healthScoreShareIcon().eq(1).should('not.exist');
    supportHub.closeButton().click();
  });

  /**
   * Regression C6541
   * - Navigate to Customer insight page and search for a Customer
   * - Click on the "Share" icon.
   */
  it('C6541: AHS_Verify the display of Share Support Health', { tags: ['AHS', 'staging'] }, () => {
    customerInsights
      .searchTextfield()
      .should('be.visible')
      .type(custName)
      .then(() => {
        customerInsights.searchResultsList().eq(0).click();
      });
    cy.waitForLoaders();
    customerInsights.healthScoreTab().should('be.visible').click();
    cy.waitForLoaders();
    healthScore.healthScoreShareIcon().should('exist').scrollIntoView().click();
    healthScore.ahsShareImageCheckbox().invoke('attr', 'data-status').should('include', 'checked');
    healthScore.ahsShareImagePreview().should('be.visible');
    healthScore.ahsShareHealthScoreLinkCheckbox().invoke('attr', 'data-status').should('include', 'unchecked');
    supportHub.sharePopupEmailButton().should('be.visible');
    healthScore.ahsShareMessageTextArea().should('be.visible');
    healthScore.ahsShareButton().should('be.visible');
  });

  /**
   * Regression C124911
   * - Navigate to Customer insight page and search for a Customer
   * - Click on the "Share" icon.
   * - Uncheck Image Preview, HS link and clear message, enter the valid email Address and verify the share button is not enabled
   */
  it('C124911: AHS_Verify the "Share" button state', { tags: ['AHS', 'staging'] }, () => {
    customerInsights
      .searchTextfield()
      .should('be.visible')
      .type(custName)
      .then(() => {
        customerInsights.searchResultsList().eq(0).click();
      });
    cy.waitForLoaders();
    customerInsights.healthScoreTab().should('be.visible').click();
    cy.waitForLoaders();
    healthScore.healthScoreShareIcon().should('exist').scrollIntoView().click();
    // Request for data-status in SLC-31066
    // healthScore.ahsShareButton().should('be.enabled');
    healthScore.ahsShareButton().invoke('attr', 'class').should('contain', '_3n5pWj9_evoRsCyt1G8wLC');
    healthScore.ahsShareImageCheckbox().invoke('attr', 'data-status').should('include', 'checked');
    healthScore.ahsShareImagePreview().should('be.visible');
    healthScore.ahsShareHealthScoreLinkCheckbox().invoke('attr', 'data-status').should('include', 'unchecked');
    supportHub.sharePopupEmailButton().should('be.visible').type('test1@gmail.com{enter}');
    // healthScore.ahsShareButton().should('be.enabled');
    healthScore.ahsShareButton().invoke('attr', 'class').should('not.contain', '_3n5pWj9_evoRsCyt1G8wLC');
    healthScore.ahsShareMessageTextArea().should('be.visible').clear();
    healthScore.ahsShareImageCheckbox().click({ force: true }).invoke('attr', 'data-status').should('include', 'unchecked');
    // healthScore.ahsShareButton().should('be.disabled');
    healthScore.ahsShareButton().invoke('attr', 'class').should('contain', '_3n5pWj9_evoRsCyt1G8wLC');
  });
});
