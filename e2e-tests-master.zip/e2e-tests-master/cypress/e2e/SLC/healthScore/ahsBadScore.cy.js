import { customerInsights, healthScore, apiHelpers } from '../../../pages';
import { urlHelpers } from '../../../utils';

describe('AHS Tests with Bad Score', () => {
  let custName = '';
  before(() => {
    cy.loginByApi();
    apiHelpers.clearRecentlyVisitedCustomerInsight();
    // Getting Customer name with Health Score Bad
    apiHelpers.getCustomerDetailsWithHealthScore('0', '39').then((customerDetails) => {
      const customerDetail = Cypress._.sample(customerDetails);
      custName = customerDetail.name;
    });
  });

  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.customerInsights.home);
  });

  /**
   * Regression C6451
   * Open BAD health score in a Customer insight page
   * Click on "Agree"
   * Select "YES" for "Should this account be escalated?"
   * Do not Enter comments and Save button
   * click on "edit" link
   */
  it('C6451: AHS_Verify the agree workflow for BAD when escalated without comments', { tags: ['AHS', 'staging'] }, () => {
    customerInsights
      .searchTextfield()
      .should('be.visible')
      .type(custName)
      .then(() => {
        customerInsights.searchResultListCustomerNameLabel().contains(custName).click();
      });
    cy.waitForLoaders();
    customerInsights.healthScoreTab().should('be.visible').click();
    cy.waitForLoaders();
    healthScore
      .feedbackButton()
      .eq(1)
      .should('be.visible')
      .then(($btn) => {
        if ($btn.text() === 'edit') {
          healthScore.feedbackButton().eq(1).click();
        }
      });
    healthScore.feedbackButton().eq(0).click();
    healthScore
      .feedbackFormPopup()
      .should('be.visible')
      .then(() => {
        // Select the Yes in Escalation and without comment
        healthScore.feedbackFormEscalatedYesRadioButton().click();
        healthScore.feedbackFormCommentBoxInput().clear();
        healthScore.feedbackFormSaveButton().should('be.visible').click();
      });
    healthScore.feedbackActionTextLabel().should('be.visible').should('include.text', 'You agreed with this assessment');
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    healthScore
      .feedbackButton()
      .eq(1)
      .should('be.visible')
      .then(($btn) => {
        if ($btn.text() === 'edit') {
          healthScore.feedbackButton().eq(1).click();
        }
      });
    healthScore.feedbackButton().eq(0).click();
    // Verify the feedback popup displaying and Message field is displaying as empty
    healthScore
      .feedbackFormPopup()
      .should('be.visible')
      .then(() => {
        healthScore.feedbackFormCommentBoxInput().should('be.empty');
        healthScore.feedbackFormCancelButton().should('be.visible').click();
      });
  });

  /**
   * Regression C6452
   * Open BAD health score in a Customer insight page
   * Click on "Agree"
   * Select "YES" for "Should this account be escalated?"
   * Enter comments and Save button
   * click on "edit" link
   */
  it('C6452: Verify the agree workflow for BAD when escalated with comments', { tags: ['AHS', 'staging'] }, () => {
    customerInsights
      .searchTextfield()
      .should('be.visible')
      .type(custName)
      .then(() => {
        customerInsights.searchResultListCustomerNameLabel().contains(custName).click();
      });
    cy.waitForLoaders();
    customerInsights.healthScoreTab().should('be.visible').click();
    cy.waitForLoaders();
    healthScore
      .feedbackButton()
      .eq(1)
      .should('be.visible')
      .then(($btn) => {
        if ($btn.text() === 'edit') {
          healthScore.feedbackButton().eq(1).click();
        }
      });
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    healthScore.feedbackButton().eq(0).click();
    healthScore
      .feedbackFormPopup()
      .should('be.visible')
      .then(() => {
        // Select the Yes in Escalation and with comment
        healthScore.feedbackFormEscalatedYesRadioButton().click();
        healthScore.feedbackFormCommentBoxInput().clear().type('Cypress Test');
        healthScore.feedbackFormSaveButton().should('be.visible').click();
      });
    healthScore.feedbackActionTextLabel().should('be.visible').should('include.text', 'You agreed with this assessment');
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    healthScore
      .feedbackButton()
      .eq(1)
      .should('be.visible')
      .then(($btn) => {
        if ($btn.text() === 'edit') {
          healthScore.feedbackButton().eq(1).click();
        }
      });
    healthScore.feedbackButton().eq(0).click();
    // Verify the feedback popup displaying and Message field is displaying as empty
    healthScore
      .feedbackFormPopup()
      .should('be.visible')
      .then(() => {
        healthScore.feedbackFormCommentBoxInput().should('not.be.empty').contains('Cypress Test');
        healthScore.feedbackFormCancelButton().should('be.visible').click();
      });
  });
});
