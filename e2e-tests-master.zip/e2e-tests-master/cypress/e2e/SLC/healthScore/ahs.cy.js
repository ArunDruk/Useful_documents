import { customerInsights, healthScore, apiHelpers } from '../../../pages';
import { urlHelpers } from '../../../utils';

describe('AHS Tests with Fair Score', () => {
  let custName = '';
  before(() => {
    cy.loginByApi();
    apiHelpers.clearRecentlyVisitedCustomerInsight();
    // Getting Customer name with Health Score Fair
    apiHelpers.getCustomerDetailsWithHealthScore('40', '69').then((customerDetails) => {
      const customerDetail = Cypress._.sample(customerDetails);
      custName = customerDetail.name;
    });
  });

  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.customerInsights.home);
    // cy.intercept('POST', '/api/v2/availability/query').as('availability');
  });

  /**
   * Regression C6446
   * - Open health score in a Customer insight page
   * - Click on any panel in the heath score window
   * - Click on Reset /Show all link in the top right corner
   */
  it('C6446: AHS_Verify the functionality of Reset /Show all button', { tags: ['AHS', 'staging'] }, () => {
    customerInsights
      .searchTextfield()
      .should('be.visible')
      .type(custName)
      .then(() => {
        customerInsights.searchResultsList().eq(0).click();
      });
    cy.waitForLoaders();
    // Navigate to the Health Score Page
    customerInsights.healthScoreTab().should('be.visible').click();
    // Verify the Contribution Cases tab not having the Reset / ShowAll button
    healthScore.ahsCaseListHeaderTitle().should('contain', 'Contributing cases');
    healthScore.ahsCaseListResetShowAllButton().should('not.exist');
    // Click on the Escalation tab
    healthScore.ahsEscalationsStatusCardValueLabel().should('be.visible').click();
    // Verify the Reset /Show All button
    healthScore.ahsCaseListHeaderTitle().should('contain', 'Escalations');
    healthScore.ahsCaseListResetShowAllButton().should('be.visible').click();
    // Verify the Contribution Cases tab not having the Reset / ShowAll button
    healthScore.ahsCaseListHeaderTitle().should('contain', 'Contributing cases');
    healthScore.ahsCaseListResetShowAllButton().should('not.exist');
  });

  /**
   * Regression C6447
   * - Hover over the thumb up
   * - Hover over the thumb down
   */
  it('C6447: AHS_Verify the display of tooltip for agree and Disagree button', { tags: ['AHS', 'staging'] }, () => {
    customerInsights
      .searchTextfield()
      .should('be.visible')
      .type(custName)
      .then(() => {
        customerInsights.searchResultsList().eq(0).click();
      });
    cy.waitForLoaders();
    // Navigate to the Health Score Page
    customerInsights.healthScoreTab().should('be.visible').click();
    cy.waitForLoaders();
    healthScore
      .feedbackButton()
      .eq(1)
      .then(($btn) => {
        if ($btn.text() === 'edit') {
          healthScore.feedbackButton().eq(1).click();
        }
      });
    // mouse hover on the agree Icon
    healthScore.feedbackButton().eq(0).should('be.visible').trigger('mouseover');
    healthScore.feedbackIconTooltipText().should('be.visible').should('have.text', 'Agree with Health Score');
    healthScore.feedbackButton().eq(0).click();
    healthScore.feedbackFormCancelButton().should('be.visible').click();
    // Mouse hover on the Disagree Icon
    healthScore.feedbackButton().eq(1).should('be.visible').trigger('mouseover');
    healthScore.feedbackIconTooltipText().should('be.visible').should('have.text', 'Disagree with Health Score');
  });

  /**
   * Regression C6448
   * - Click on "Agree with health score" button.
   * - Enter any comments and select one of the escalation options
   * - Click on "Cancel" button
   * - Click on "Agree with health score" button.
   */
  it('C6448: AHS_Verify the agree workflow cancel workflow', { tags: ['AHS', 'staging'] }, () => {
    customerInsights
      .searchTextfield()
      .should('be.visible')
      .type(custName)
      .then(() => {
        customerInsights.searchResultsList().eq(0).click();
      });
    cy.waitForLoaders();
    // Navigate to the Health Score Page
    customerInsights.healthScoreTab().should('be.visible').click();
    cy.waitForLoaders();
    healthScore
      .feedbackButton()
      .eq(1)
      .then(($btn) => {
        if ($btn.text() === 'edit') {
          healthScore.feedbackButton().eq(1).click();
        }
      });
    // Click on the Agree Icon
    healthScore.feedbackButton().eq(0).click();
    // Verify the feedback popup displaying
    healthScore
      .feedbackFormPopup()
      .should('be.visible')
      .then(() => {
        healthScore.feedbackFormCommentBoxInput().clear().type('cancel');
        healthScore.feedbackFormEscalatedQuestionLabel().should('be.visible');
        healthScore.feedbackFormCancelButton().should('be.visible').click();
      });
    // Click on the Escalation tab
    healthScore.ahsEscalationsStatusCard().should('be.visible').click();
    // Verify the feedback popup not displaying
    healthScore.feedbackFormPopup().should('not.exist');
    // Click on the Agree Icon
    healthScore.feedbackButton().eq(0).click();
    // Verify the feedback popup displaying and Message field is displaying as empty
    healthScore
      .feedbackFormPopup()
      .should('be.visible')
      .then(() => {
        healthScore.feedbackFormCommentBoxInput().should('not.contain', 'cancel');
        healthScore.feedbackFormCancelButton().should('be.visible').click();
      });
  });

  /**
   *  Regression C6449
   * Select customer with "Fair" score
   * Click on "agree with health assessment" icon
   * Select "Not sure" for "Should this account be escalated?"
   * Do not Enter comments and Save button
   */
  it('C6449: AHS_Verify the agree workflow FAIR score , Not sure escalation and without comments', { tags: ['AHS', 'staging'] }, () => {
    customerInsights
      .searchTextfield()
      .should('be.visible')
      .type(custName)
      .then(() => {
        customerInsights.searchResultsList().eq(0).click();
      });
    cy.waitForLoaders();
    customerInsights.healthScoreTab().should('be.visible').click();
    cy.waitForLoaders();
    healthScore
      .feedbackButton()
      .eq(1)
      .then(($btn) => {
        if ($btn.text() === 'edit') {
          healthScore.feedbackButton().eq(1).click();
        }
      });
    healthScore.feedbackButton().eq(0).click();
    healthScore
      .feedbackFormPopup()
      .should('be.visible')
      .then(() => {
        // Select the Not Sure in Escalation and without comment
        healthScore.feedbackFormEscalatedNotSureRadioButton().click();
        healthScore.feedbackFormCommentBoxInput().clear();
        healthScore.feedbackFormSaveButton().should('be.visible').click();
      });
    healthScore.feedbackActionTextLabel().should('be.visible').contains('You agreed with this assessment');
    healthScore.feedbackButton().then(($btn) => {
      if ($btn.text() === 'edit') {
        healthScore.feedbackButton().eq(1).click();
      }
    });
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    healthScore.feedbackButton().eq(0).click();
    // Verify the feedback popup displaying and Message field is displaying as empty
    healthScore
      .feedbackFormPopup()
      .should('be.visible')
      .then(() => {
        healthScore.feedbackFormCommentBoxInput().should('be.empty');
        healthScore.feedbackFormCancelButton().click();
      });
  });

  /**
   *  Regression C6456
   * Open FAIR health score in a Customer insight page
   * Click on "Agree"
   * Select "Not Sure" for "Should this account be escalated?"
   * Enter comments and Save button
   */
  it('C6456: AHS_Verify the agree workflow FAIR score , Not sure escalation and with comments', { tags: ['AHS', 'staging'] }, () => {
    customerInsights
      .searchTextfield()
      .should('be.visible')
      .type(custName)
      .then(() => {
        customerInsights.searchResultsList().eq(0).click();
      });
    cy.waitForLoaders();
    customerInsights.healthScoreTab().should('be.visible').click();
    healthScore
      .feedbackButton()
      .eq(1)
      .then(($btn) => {
        if ($btn.text() === 'edit') {
          healthScore.feedbackButton().eq(1).click();
        }
      });
    healthScore.feedbackButton().eq(0).click();
    healthScore
      .feedbackFormPopup()
      .should('be.visible')
      .then(() => {
        // Select the Not Sure in Escalation and with comment
        healthScore.feedbackFormEscalatedNotSureRadioButton().click();
        healthScore.feedbackFormCommentBoxInput().clear().type('Cypress Test');
        healthScore.feedbackFormSaveButton().should('be.visible').click();
      });
    cy.waitForLoaders();
    healthScore.feedbackActionTextLabel().should('be.visible').contains('You agreed with this assessment');
    healthScore.feedbackButton().then(($btn) => {
      if ($btn.text() === 'edit') {
        healthScore.feedbackButton().eq(1).click();
      }
    });
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    healthScore.feedbackButton().eq(0).click();
    // Verify the feedback popup displaying and Message field is displaying as empty
    healthScore
      .feedbackFormPopup()
      .should('be.visible')
      .then(() => {
        healthScore.feedbackFormCommentBoxInput().should('not.be.empty');
        healthScore.feedbackFormCancelButton().should('be.visible').click();
      });
  });

  /**
   *  Regression C6453
   * Open FAIR health score in a Customer insight page
   * Click on "Agree"
   * Select "YES" for "Should this account be escalated?"
   * Do not Enter comments and Save button
   * click on "edit" link
   */
  it('C6453: AHS_Verify the agree workflow for FAIR when escalated without comments', { tags: ['AHS', 'staging'] }, () => {
    customerInsights
      .searchTextfield()
      .should('be.visible')
      .type(custName)
      .then(() => {
        customerInsights.searchResultsList().eq(0).click();
      });
    cy.waitForLoaders();
    customerInsights.healthScoreTab().should('be.visible').click();
    cy.waitForLoaders();
    healthScore
      .feedbackButton()
      .eq(1)
      .should('be.visible')
      .then(($btn) => {
        if ($btn.text() === 'edit') {
          healthScore.feedbackButton().eq(1).click();
        }
      });
    healthScore.feedbackButton().eq(0).click();
    healthScore
      .feedbackFormPopup()
      .should('be.visible')
      .then(() => {
        // Select the Yes in Escalation and without comment
        healthScore.feedbackFormEscalatedYesRadioButton().click();
        healthScore.feedbackFormCommentBoxInput().clear();
        healthScore.feedbackFormSaveButton().should('be.visible').click();
      });
    healthScore.feedbackActionTextLabel().should('be.visible').should('include.text', 'You agreed with this assessment');
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    healthScore
      .feedbackButton()
      .eq(1)
      .should('be.visible')
      .then(($btn) => {
        if ($btn.text() === 'edit') {
          healthScore.feedbackButton().eq(1).click();
        }
      });
    healthScore.feedbackButton().eq(0).click();
    // Verify the feedback popup displaying and Message field is displaying as empty
    healthScore
      .feedbackFormPopup()
      .should('be.visible')
      .then(() => {
        healthScore.feedbackFormCommentBoxInput().should('be.empty');
        healthScore.feedbackFormCancelButton().should('be.visible').click();
      });
  });

  /**
   * Regression C6454
   * Open FAIR health score in a Customer insight page
   * Click on "Agree"
   * Select "YES" for "Should this account be escalated?"
   * Enter comments and Save button
   * click on "edit" link
   */
  it('C6454: AHS_Verify the agree workflow for FAIR when escalated with comments', { tags: ['AHS', 'staging'] }, () => {
    customerInsights
      .searchTextfield()
      .should('be.visible')
      .type(custName)
      .then(() => {
        customerInsights.searchResultsList().eq(0).click();
      });
    cy.waitForLoaders();
    customerInsights.healthScoreTab().should('be.visible').click();
    cy.waitForLoaders();
    healthScore
      .feedbackButton()
      .eq(1)
      .should('be.visible')
      .then(($btn) => {
        if ($btn.text() === 'edit') {
          healthScore.feedbackButton().eq(1).click();
        }
      });
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    healthScore.feedbackButton().eq(0).click();
    healthScore
      .feedbackFormPopup()
      .should('be.visible')
      .then(() => {
        // Select the Yes in Escalation and with comment
        healthScore.feedbackFormEscalatedYesRadioButton().click();
        healthScore.feedbackFormCommentBoxInput().clear().type('Cypress Test');
        healthScore.feedbackFormSaveButton().should('be.visible').click();
      });
    healthScore.feedbackActionTextLabel().should('be.visible').should('include.text', 'You agreed with this assessment');
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    healthScore
      .feedbackButton()
      .eq(1)
      .should('be.visible')
      .then(($btn) => {
        if ($btn.text() === 'edit') {
          healthScore.feedbackButton().eq(1).click();
        }
      });
    healthScore.feedbackButton().eq(0).click();
    // Verify the feedback popup displaying and Message field is displaying as empty
    healthScore
      .feedbackFormPopup()
      .should('be.visible')
      .then(() => {
        healthScore.feedbackFormCommentBoxInput().should('not.be.empty').contains('Cypress Test');
        healthScore.feedbackFormCancelButton().should('be.visible').click();
      });
  });

  /**
   *  Regression C6458
   * Open FAIR health score in a Customer insight page
   * Click on "Disagree"
   */
  it('C6458: AHS_Verify the disagree workflow when score is FAIR', { tags: ['AHS', 'staging'] }, () => {
    customerInsights
      .searchTextfield()
      .should('be.visible')
      .type(custName)
      .then(() => {
        customerInsights.searchResultsList().eq(0).click();
      });
    cy.waitForLoaders();
    customerInsights.healthScoreTab().should('be.visible').click();
    cy.waitForLoaders();
    healthScore
      .feedbackButton()
      .eq(1)
      .should('be.visible')
      .then(($btn) => {
        if ($btn.text() === 'edit') {
          healthScore.feedbackButton().eq(1).click();
        }
      });
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    healthScore.feedbackButton().eq(1).click();
    healthScore
      .feedbackFormPopup()
      .should('be.visible')
      .then(() => {
        // Verify "Fair (currently assessed)" should be selected.
        healthScore.feedbackFormRadioButtonTextLabel().eq(1).should('have.text', 'Fair (currently assessed)');
        // Verify "Should this account be escalated?" should be editable.
        healthScore.feedbackFormQuestionLabel().should('contain', 'Should this account be escalated?');
        // Select the Yes in Escalation and with comment
        healthScore.feedbackFormEscalatedNotSureRadioButton().click();
        healthScore.feedbackFormCommentBoxInput().clear().type('Cypress Test');
        healthScore.feedbackFormSaveButton().should('be.visible').click();
      });
    healthScore.feedbackActionTextLabel().should('be.visible').should('include.text', 'You assessed the health as fair');
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    healthScore
      .feedbackButton()
      .eq(1)
      .should('be.visible')
      .then(($btn) => {
        if ($btn.text() === 'edit') {
          healthScore.feedbackButton().eq(1).click();
        }
      });
    healthScore.feedbackButton().eq(1).click();
    // Verify the feedback popup displaying and Message field is not displaying as empty
    healthScore
      .feedbackFormPopup()
      .should('be.visible')
      .then(() => {
        healthScore.feedbackFormCommentBoxInput().should('not.be.empty').contains('Cypress Test');
        healthScore.feedbackFormCancelButton().should('be.visible').click();
      });
  });

  /**
   * Regression C6440
   * - Open health score in a Customer insight page
   * - Click on Escalation panel in the heath score window
   * - Verify its corresponding contributing tickets are displaying
   */
  it('C6440: AHS_Verify the Escalation panel details and its corresponding contributing tickets', { tags: ['AHS', 'staging'] }, () => {
    customerInsights
      .searchTextfield()
      .should('be.visible')
      .type(custName)
      .then(() => {
        customerInsights.searchResultsList().eq(0).click();
      });
    cy.waitForLoaders();
    // Navigate to the Health Score Page
    customerInsights.healthScoreTab().should('be.visible').click();
    // Verify the Contribution Cases tab not having the Reset / ShowAll button
    healthScore.ahsCaseListHeaderTitle().should('contain', 'Contributing cases');
    healthScore.ahsCaseListResetShowAllButton().should('not.exist');
    // Click on the Escalation tab
    healthScore.ahsEscalationsStatusCardValueLabel().should('be.visible').click();
    // eslint-disable-next-line prefer-regex-literals
    healthScore.ahsEscalationsStatusCardValueLabel().invoke('text').should('match', RegExp(`(\\d+)active escalation`));
    healthScore
      .ahsEscalationsStatusTextLabel()
      .invoke('text')
      .then(($daysCount) => {
        if ($daysCount.includes('days')) {
          // eslint-disable-next-line prefer-regex-literals
          expect($daysCount).to.match(RegExp(`Longest open escalation is (\\d+) days old`));
        } else {
          // eslint-disable-next-line prefer-regex-literals
          expect($daysCount).to.match(RegExp(`Longest open escalation is (?:less than a|a) day old`));
        }
      });
    // Verify the contributing Escalation tickets
    healthScore.ahsCaseListHeaderTitle().should('contain', 'Escalations');
    healthScore.healthScoreCaseList().should('exist');
    healthScore.ahsCaseListResetShowAllButton().should('be.visible').click();
  });

  /**
   * Regression C6441
   * - Open health score in a Customer insight page
   * - Click on Case Age panel in the heath score window
   * - Verify its corresponding contributing tickets are displaying
   */
  it('C6441: AHS_Verify the Case Age panel details and its corresponding contributing tickets', { tags: ['AHS', 'staging'] }, () => {
    customerInsights
      .searchTextfield()
      .should('be.visible')
      .type(custName)
      .then(() => {
        customerInsights.searchResultsList().eq(0).click();
      });
    cy.waitForLoaders();
    // Navigate to the Health Score Page
    customerInsights.healthScoreTab().should('be.visible').click();
    // Verify the Contribution Cases tab not having the Reset / ShowAll button
    healthScore.ahsCaseListHeaderTitle().should('contain', 'Contributing cases');
    healthScore.ahsCaseListResetShowAllButton().should('not.exist');
    // Click on the Case Age tab
    healthScore.ahsCaseAgeStatusCardDaysLabel().should('be.visible').click();
    // eslint-disable-next-line prefer-regex-literals
    healthScore.ahsCaseAgeStatusCardDaysLabel().invoke('text').should('match', RegExp(`(?:\\d+.\\d+|\\d+)`));
    // eslint-disable-next-line prefer-regex-literals
    healthScore.ahsCaseAgeTrendsTextLabel().invoke('text').should('match', RegExp(`(?:(\\d+.\\d+)|\\d+)% since 30 days`));
    // Verify the contributing Case Age tickets
    healthScore.ahsCaseListHeaderTitle().should('contain', 'Case Age');
    healthScore.healthScoreCaseList().should('exist');
    healthScore.ahsCaseListResetShowAllButton().should('be.visible').click();
  });

  /**
   * Regression C6443
   * - Open health score in a Customer insight page
   * - Click on Case Sentiment panel in the heath score window
   * - Verify its corresponding contributing tickets are displaying
   */
  it('C6443: AHS_Verify the Case Sentiment details and its corresponding contributing tickets', { tags: ['AHS', 'staging'] }, () => {
    customerInsights
      .searchTextfield()
      .should('be.visible')
      .type(custName)
      .then(() => {
        customerInsights.searchResultsList().eq(0).click();
      });
    cy.waitForLoaders();
    // Navigate to the Health Score Page
    customerInsights.healthScoreTab().should('be.visible').click();
    // Verify the Contribution Cases tab not having the Reset / ShowAll button
    healthScore.ahsCaseListHeaderTitle().should('contain', 'Contributing cases');
    healthScore.ahsCaseListResetShowAllButton().should('not.exist');
    // Click on the Case Sentiment tab
    healthScore.ahsCaseSentimentStatusCard().should('be.visible').click();
    healthScore.ahsCaseSentimentStatusCardContent().should('be.visible');
    // eslint-disable-next-line prefer-regex-literals
    healthScore.ahsCaseSentimentTrendsTextLabel().invoke('text').should('match', RegExp(`(?:(\\d+.\\d+)|\\d+)% since 30 days`));
    // Verify the contributing Case Sentiment tickets
    healthScore.ahsCaseListHeaderTitle().should('contain', 'Case Sentiment');
    healthScore.healthScoreCaseList().should('exist');
    healthScore.ahsCaseListResetShowAllButton().should('be.visible').click();
  });

  /**
   * Regression C6444
   * - Open health score in a Customer insight page
   * - Click on Case Activity panel in the heath score window
   * - Verify its corresponding contributing tickets are displaying
   */
  it('C6444: AHS_Verify the Case Activity details and its corresponding contributing tickets', { tags: ['AHS', 'staging'] }, () => {
    customerInsights
      .searchTextfield()
      .should('be.visible')
      .type(custName)
      .then(() => {
        customerInsights.searchResultsList().eq(0).click();
      });
    cy.waitForLoaders();
    // Navigate to the Health Score Page
    customerInsights.healthScoreTab().should('be.visible').click();
    // Verify the Contribution Cases tab not having the Reset / ShowAll button
    healthScore.ahsCaseListHeaderTitle().should('contain', 'Contributing cases');
    healthScore.ahsCaseListResetShowAllButton().should('not.exist');
    // Click on the Case Activity tab
    healthScore.ahsCaseActivityStatusCard().should('be.visible').click();
    healthScore.ahsCaseActivityChart().should('be.visible');
    // eslint-disable-next-line prefer-regex-literals
    healthScore.ahsCaseActivityTrendsTextLabel().invoke('text').should('match', RegExp(`(?:(\\d+.\\d+)|\\d+)% since 30 days`));
    // Verify the contributing Case Activity tickets
    healthScore.ahsCaseListHeaderTitle().should('contain', 'Case Activity');
    healthScore.healthScoreCaseList().should('exist');
    healthScore.ahsCaseListResetShowAllButton().should('be.visible').click();
  });

  /**
   * Regression C6445
   * - Open health score in a Customer insight page
   * - Click on Engineering Issues panel in the heath score window
   * - Verify its corresponding contributing tickets are displaying
   */
  it('C6445: AHS_Verify the Engineering Issues details and its corresponding contributing tickets', { tags: ['AHS', 'staging'] }, () => {
    customerInsights
      .searchTextfield()
      .should('be.visible')
      .type(custName)
      .then(() => {
        customerInsights.searchResultsList().eq(0).click();
      });
    cy.waitForLoaders();
    // Navigate to the Health Score Page
    customerInsights.healthScoreTab().should('be.visible').click();
    // Verify the Contribution Cases tab not having the Reset / ShowAll button
    healthScore.ahsCaseListHeaderTitle().should('contain', 'Contributing cases');
    healthScore.ahsCaseListResetShowAllButton().should('not.exist');
    // Click on the Engineering Issues tab
    healthScore.ahsEngineeringIssuesCard().should('be.visible').click();
    healthScore.ahsEngineeringIssuesChart().should('be.visible');
    // eslint-disable-next-line prefer-regex-literals
    healthScore.ahsEngineeringIssuesTrendsTextLabel().invoke('text').should('match', RegExp(`(?:(\\d+.\\d+)|\\d+)% since 30 days`));
    // Verify the contributing Engineering Issues tickets
    healthScore.ahsCaseListHeaderTitle().should('contain', 'Engineering Issues');
    healthScore.healthScoreCaseList().should('exist');
    healthScore.ahsCaseListResetShowAllButton().should('be.visible').click();
  });
});
