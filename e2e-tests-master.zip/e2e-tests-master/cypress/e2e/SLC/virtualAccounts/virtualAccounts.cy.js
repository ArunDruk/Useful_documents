import { virtualAccount } from '../../../pages';
import { urlHelpers } from '../../../utils';

const randId = () => Cypress._.random(0, 1e6);
const createVA = (name, agentIds) =>
  cy.request({
    method: 'POST',
    url: 'api/v2/group',
    headers: { 'Content-Type': 'application/json' },
    body: {
      name,
      gtype: 'virtual_account',
      is_public: false,
      owner: Cypress.env('userEmail'),
      created_by: Cypress.env('userEmail'),
      account_ids: [],
      crm_user_ids: agentIds,
      email_user_ids: [],
      child_ids: [],
      sl_custom_fields: {},
    },
  });

const getVaMembersCount = (targetName) =>
  cy
    .request({
      method: 'POST',
      url: '/api/v2/group/search?page_number=0&page_size=1000',
      headers: { 'Content-Type': 'application/json' },
      body: {
        selected: ['name', 'child_ids', 'crm_user_ids'],
        ordering: [],
        predicates: [
          { column: 'name', op: '=', value: targetName },
          { column: 'owner', op: 'in', value: Cypress.env('userEmail') },
        ],
      },
    })
    .then(({ body }) => body[0].crm_user_ids.length);

describe('Virtual Accounts', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.virtualAccounts);

    cy.intercept('POST', 'api/v2/group').as('createGroup');
    cy.intercept('search/virtual_groups/_search*').as('search');
  });

  describe('Creating virtual account', () => {
    it('C735: should create personal VA', () => {
      const vaName = `Test Personal Account ${randId()}`;

      virtualAccount.createVaButton().click();
      virtualAccount.vaAccountTypePersonalButton().click();
      virtualAccount.vaCreatePopupNameInput().type(vaName);
      virtualAccount.vaCreatePopupSubmitOrNextButton().click();

      virtualAccount.vaCreatePopupSearchCustomerNameInput().type('a');
      cy.wait('@search');

      virtualAccount.vaCreatePopupCustomerSearchResultList().eq(0).click();
      virtualAccount.vaCreatePopupCustomerSearchResultList().eq(1).click();

      virtualAccount.vaCreatePopupSubmitOrNextButton().click();

      cy.wait('@createGroup');

      virtualAccount.searchVaNameInput().type(vaName);
      virtualAccount.virtualAccountNameListItem(vaName).should('be.visible');
      // Delete the Created Virtual Account
      virtualAccount.deleteVirtualAccount(vaName);
    });

    it("C37785: shouldn't allow creating duplicated items", () => {
      const vaName = `Test Personal Account ${randId()}`;

      cy.slcHelpers
        .getAgentIds()
        .then((agentIds) => createVA(vaName, agentIds))
        .then((response) => {
          // Tmp workaround to refetch newly created VA
          cy.visit(urlHelpers.virtualAccounts);

          virtualAccount.createVaButton().click();
          virtualAccount.vaAccountTypePersonalButton().click();
          virtualAccount.vaCreatePopupNameInput().type(vaName);

          virtualAccount.vaNameErrorLabel().should('have.text', 'This name is already taken.');
          virtualAccount.vaCreatePopupSubmitOrNextButton().should('be.disabled');
          cy.slcHelpers.deleteVgroup(response.body.id);
        });
    });
  });

  describe('Personal virtual account tests', () => {
    it('C743: We should be able to edit the new personal account', () => {
      // https://supportlogic.atlassian.net/browse/SLC-31170
      const vaName = `Test Personal Account ${randId()}`;

      cy.slcHelpers
        .getAgentIds()
        .then((agentIds) => createVA(vaName, agentIds))
        .then((response) => {
          // Tmp workaround to refetch newly created VA
          cy.visit(urlHelpers.virtualAccounts);

          getVaMembersCount(vaName).then((beforeCount) => {
            virtualAccount.searchVaNameInput().type(`${vaName}{enter}`);

            virtualAccount.editVirtualAccount(vaName);

            virtualAccount.vaCreatePopupSearchCustomerNameInput().type('a');
            cy.wait('@search');
            virtualAccount.vaCreatePopupCustomerSearchResultList().eq(5).click();
            virtualAccount.editVirtualGroupSaveButton().scrollIntoView().should('be.visible').click();
            // eslint-disable-next-line cypress/no-unnecessary-waiting
            cy.wait(2000);
            getVaMembersCount(vaName).should('eq', beforeCount + 1);
          });
          cy.slcHelpers.deleteVgroup(response.body.id);
        });
    });

    it('C2191: Create copy of VA/VT ', () => {
      const vaName = `Test Personal Account ${randId()}`;

      cy.slcHelpers
        .getAgentIds()
        .then((agentIds) => createVA(vaName, agentIds))
        .then((response) => {
          // Tmp workaround to refetch newly created VA
          cy.visit(urlHelpers.virtualAccounts);

          virtualAccount.searchVaNameInput().type(`${vaName}{enter}`);
          virtualAccount.cloneVirtualAccount(vaName);

          virtualAccount.editVirtualGroupSaveButton().scrollIntoView().click();
          virtualAccount.searchVaNameInput().clear().type(`${vaName} Copy 1`);
          cy.contains(`${vaName} Copy 1`).should('be.visible');
          cy.slcHelpers.deleteVgroup(response.body.id);
        });
      // Delete the Created Copy Virtual Account
      virtualAccount.deleteVirtualAccount(`${vaName} Copy 1`);
    });

    it('C2260: Test virtual account group loaded  ', () => {
      const vaName = `Test Personal Account ${randId()}`;

      cy.slcHelpers
        .getAgentIds()
        .then((agentIds) => createVA(vaName, agentIds))
        .then((response) => {
          // Tmp workaround to refetch newly created VA
          cy.visit(urlHelpers.virtualAccounts);
          virtualAccount.virtualAccountLists().should('have.length.greaterThan', 0);
          cy.slcHelpers.deleteVgroup(response.body.id);
        });
    });
  });
});
