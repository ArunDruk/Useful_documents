import { urlHelpers } from '../../../utils';
import { virtualAccount } from '../../../pages/index';

describe('Validating Virtual Account', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.virtualAccounts);
  });

  /**
   * Regression C736
   * - Click on the plus and type an already taken name for VA account (Plus)
   */
  it('C736: Check creation of VA (Plus)', { tags: ['Virtual Accounts', 'staging'] }, () => {
    const vaName = virtualAccount.createVirtualAccount('Personal');
    virtualAccount.createVaButton().scrollIntoView().click();
    virtualAccount.vaAccountTypePersonalButton().click();
    virtualAccount.vaCreatePopupNameInput().type(vaName);
    virtualAccount.vaNameErrorLabel().should('have.text', 'This name is already taken.');
    virtualAccount.vaCreatePopupCancelOrBackButton().click();
    virtualAccount.deleteVirtualAccount(vaName);
  });

  /**
   * Regression C737
   * - Click on the plus and leave name for VA account blank
   */
  it('C737: Check creation of VA (Blank)', { tags: ['Virtual Accounts', 'staging', 'prod'] }, () => {
    virtualAccount.createVaButton().scrollIntoView().click();
    virtualAccount.vaAccountTypePersonalButton().click();
    virtualAccount.vaCreatePopupNameInput().type('123').clear();
    virtualAccount.vaNameErrorLabel().should('have.text', 'Name cannot be empty.');
    virtualAccount.vaCreatePopupCancelOrBackButton().click();
  });

  /**
   * Regression C738
   * - click on plus and give suitable and valid name for VA account and add only one customer/reporter
   */
  it('C738: Check creation of VA (2 accounts needed)', { tags: ['Virtual Accounts', 'staging', 'prod'] }, () => {
    cy.intercept('POST', 'api/v2/group').as('createGroup');
    cy.intercept('search/virtual_groups/_search*').as('search');
    virtualAccount.createVaButton().scrollIntoView().click();
    virtualAccount.vaAccountTypePersonalButton().should('be.visible').click();
    const vaName = `Test Personal VirtualAccoun`;
    virtualAccount.vaCreatePopupNameInput().type(vaName);
    virtualAccount.vaCreatePopupSubmitOrNextButton().should('be.visible').click();
    virtualAccount.vaCreatePopupSearchCustomerNameInput().should('be.visible').type('a');
    cy.wait('@search');
    virtualAccount.vaCreatePopupCustomerSearchResultList().eq(0).click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(2000);
    virtualAccount.vaCreatePopupSubmitOrNextButton().should('be.disabled');
    virtualAccount.vaCreatePopupCancelOrBackButton().click();
    virtualAccount.vaCreatePopupCancelOrBackButton().click();
  });

  /**
   * Regression C2261
   * - Test page is having  expected url and title
   */
  it('C2261: Test page is having  expected url and title', { tags: ['Virtual Accounts', 'staging', 'prod'] }, () => {
    cy.url().should('include', 'virtual-accounts');
    cy.contains('Virtual Accounts and Groups').should('exist');
  });

  /**
   * Regression C2262
   * - Test page has loaded successfully
   */
  it('C2262: Test page has loaded successfully', { tags: ['Virtual Accounts', 'staging', 'prod'] }, () => {
    virtualAccount.createVaButton().should('exist');
    virtualAccount.virtualGroupCreateButton().should('exist');
    cy.contains('Virtual Accounts and Groups').should('exist');
  });

  /**
   * Regression C2263
   * - Test functionality of selecting one agents account
   */
  it('C2263: Test functionality of selecting one agents account', { tags: ['Virtual Accounts', 'staging', 'prod'] }, () => {
    cy.intercept('POST', 'api/v2/group').as('createGroup');
    cy.intercept('search/virtual_groups/_search*').as('search');
    virtualAccount.createVaButton().scrollIntoView().click();
    virtualAccount.vaAccountTypeGlobalButton().should('be.visible').click();
    const vaName = `Test Global VirtualAccount`;
    virtualAccount.vaCreatePopupNameInput().type(vaName);
    virtualAccount.vaCreatePopupSubmitOrNextButton().should('be.visible').click();
    virtualAccount.vaCreatePopupSearchCustomerNameInput().should('be.visible').type('a');
    cy.wait('@search');
    virtualAccount.vaCreatePopupCustomerSearchResultList().eq(0).click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(2000);
    virtualAccount.vaCreatePopupSubmitOrNextButton().should('be.disabled');
    virtualAccount.vaCreatePopupCancelOrBackButton().click();
    virtualAccount.vaCreatePopupCancelOrBackButton().click();
  });
});
