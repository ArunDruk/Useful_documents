import { urlHelpers } from '../../../utils';
import { virtualAccount, preferences } from '../../../pages/index';
import { getOpenCaseDetails } from '../customerInsights/support';

describe('Creating Virtual Account', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.virtualAccounts);
    cy.waitForLoaders();
  });

  /**
   * Regression C734
   * - Go to VA page and click on the button "Create a Virtual account"
   */
  it('C734: Check creation of VA', { tags: ['Virtual Accounts', 'staging'] }, () => {
    const vaTeamName = virtualAccount.createVirtualAccount('Global');
    virtualAccount.deleteVirtualAccount(vaTeamName);
  });

  /**
   * Regression C739
   * - click on plus and give suitable and valid name for VA account and add more than one customer/reporter
   */
  it('C739: Check creation of VA (Apply)', { tags: ['Virtual Accounts', 'staging'] }, () => {
    const vaName = virtualAccount.createVirtualAccount('Personal');
    virtualAccount.verifyVirtualAccountIsPresent(vaName);
    virtualAccount.deleteVirtualAccount(vaName);
  });

  /**
   * Regression C744
   * - Click on the preferences and try to add the added VA/ created VA in the va section
   */
  // This is skipped as Newly created Vgroup will take time to reflect in elastic search
  // Iskander is working on this
  it('C744: Check if the created VA can be added in the favourite list', { tags: ['Virtual Accounts', 'staging'] }, () => {
    // Temp Fix due to Elastic wait - comment below line and last delete va line, added static vaName,
    const vaName = 'C9405 VA DO NOT DELETE'; // virtualAccount.createVirtualAccount('Personal');
    preferences.selectFavoriteCustomerInPreference(vaName);
    preferences.removeRecentlyFavoriteCustomersInPreference();
    // virtualAccount.deleteVirtualAccount(vaName);
  });

  /**
   * Regression C740
   * - Create a VA with name similar to other VA with multiple spaces between words
   */
  it('C740: Check the influence of space while VA account', { tags: ['Virtual Accounts', 'staging'] }, () => {
    const vaName = virtualAccount.createVirtualAccount('Personal');
    virtualAccount.verifyVirtualAccountIsPresent(vaName);
    const vaName1 = `${vaName.replace(' ', '   ')}   `;
    virtualAccount.createVaButton().scrollIntoView().click();
    virtualAccount.vaAccountTypePersonalButton().click();
    virtualAccount.vaCreatePopupNameInput().type(vaName1);
    virtualAccount.vaNameErrorLabel().should('have.text', 'This name is already taken.');
    virtualAccount.vaCreatePopupCancelOrBackButton().click();
    virtualAccount.deleteVirtualAccount(vaName);
  });

  /**
   * Regression C742
   * - Click on the delete icon appearing on the right side of any one VA
   */
  it('C742: Check if the created VA gets deleted', { tags: ['Virtual Accounts', 'staging'] }, () => {
    const vaName = virtualAccount.createVirtualAccount('Personal');
    virtualAccount.deleteVirtualAccount(vaName);
  });

  /**
   * Regression C741
   * - Getting the existing customer name via API
   * - Click on "Create a VA " and enter the same name as that of one of the customer/reproter present in the database
   * - Click on Next and select two customer from the search, then click on create button
   * - Verify the Virtual Account is created with exisitng customer name
   * - After: Deleting the created virtual account
   */
  it('C741: check creating a VA with the same name as that of one of the customer present in the database', { tags: ['Virtual Accounts', 'staging'] }, () => {
    // Added a temp fix until "getCustomerDetails" API is fixed
    getOpenCaseDetails().then((caseDetails) => {
      const caseDetail = Cypress._.sample(caseDetails);
      const vaName = caseDetail.customerName;
      cy.intercept('POST', 'api/v2/group').as('createGroup');
      cy.intercept('search/virtual_groups/_search*').as('search');
      virtualAccount.createVaButton().scrollIntoView().click();
      virtualAccount.vaAccountTypePersonalButton().should('be.visible').click();
      virtualAccount.vaCreatePopupNameInput().type(vaName);
      virtualAccount.vaCreatePopupSubmitOrNextButton().should('be.visible').click();
      // Added as a temp fix until the "getCustomerNameFromCaseDetails" API is fixed
      virtualAccount.vaCreatePopupSearchCustomerNameInput().should('be.visible').type('a');
      cy.wait('@search');
      virtualAccount.vaCreatePopupCustomerSearchResultList().eq(0).click();
      // eslint-disable-next-line cypress/no-unnecessary-waiting
      cy.wait(2000);
      virtualAccount.vaCreatePopupCustomerSearchResultList().eq(1).click();
      virtualAccount.vaCreatePopupSubmitOrNextButton().should('be.visible').click();
      cy.wait('@createGroup');
      virtualAccount.verifyVirtualAccountIsPresent(vaName);
      virtualAccount.deleteVirtualAccount(vaName);
    });
  });

  /**
   * Regression C9188
   * - Creating 2 virtual accounts and click on the delete icon in the first VA
   * - click delete icon in the second VA and click confirm delete icon
   * - Verify the first VA exist and the second VA alone gets deleted
   * - After verify delete the second VA
   */
  it('C9188: Check if the created VA gets deleted', { tags: ['Virtual Accounts', 'staging'] }, () => {
    const vaName = virtualAccount.createVirtualAccount('Personal');
    const vaName1 = virtualAccount.createVirtualAccount('Personal');
    virtualAccount.deleteVirtualAccountButton(vaName).click();
    virtualAccount.deleteVirtualAccountButton(vaName1).wait(1000).click();
    virtualAccount.confirmDeleteVaPopupButton().click();
    virtualAccount.searchResultVaNameList().should('not.contain', vaName1);
    virtualAccount.searchResultVaNameList().should('contain', vaName);
    virtualAccount.deleteVirtualAccount(vaName);
  });
});
