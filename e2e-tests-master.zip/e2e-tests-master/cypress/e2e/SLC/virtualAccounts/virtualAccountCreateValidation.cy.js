import { urlHelpers } from '../../../utils';
import { virtualAccount } from '../../../pages/index';

describe('Virtual Accounts - Create flow validation test cases', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.virtualAccounts);
  });

  /*
   * Go to Virtual Accounts page.
   * Click on "Create a Virtual Group" button and select "Personal VG" and Enter a unique name
   * Created personal VG should be displayed in the VA page.
   * Click on "Create a Virtual Group" button and select "Personal VG".
   * Enter the same name used recently.
   * Validate that 'This name is already taken' error message should be displayed
   */
  it('C124842: Verify duplicate name is not allowed when creating personal VG', { tags: ['Virtual Accounts', 'staging'] }, () => {
    const vgName = virtualAccount.createVirtualGroup('Personal');

    virtualAccount.virtualGroupCreateButton().scrollIntoView().click();
    virtualAccount.virtualGroupAccountTypePersonalButton().click();
    virtualAccount.vaCreatePopupNameInput().type(vgName);
    virtualAccount.vaNameErrorLabel().should('have.text', 'This name is already taken.');
    virtualAccount.vaCreatePopupCancelOrBackButton().click();
    virtualAccount.deleteVirtualGroup(vgName);
  });

  /*
   * Go to Virtual Accounts page.
   * Click on "Create a Virtual Group" button and select "Global VG" and Enter a unique name
   * Created Global VG should be displayed in the VA page.
   * Click on "Create a Virtual Group" button and select "Global VG".
   * Enter the same name used recently.
   * Validate that 'This name is already taken' error message should be displayed
   */
  it('C124848: Verify duplicate name is not allowed when creating Global VG', { tags: ['Virtual Accounts', 'staging'] }, () => {
    const vgName = virtualAccount.createVirtualGroup('Global');

    virtualAccount.virtualGroupCreateButton().scrollIntoView().click();
    virtualAccount.virtualGroupAccountTypeGlobalButton().click();
    virtualAccount.vaCreatePopupNameInput().type(vgName);
    virtualAccount.vaNameErrorLabel().should('have.text', 'This name is already taken.');
    virtualAccount.vaCreatePopupCancelOrBackButton().click();
    virtualAccount.deleteVirtualGroup(vgName);
  });

  /*
   * Go to Virtual Accounts page.
   * Click on "Create a Virtual Account" button and select "Personal VA" and Enter a unique name
   * Created Personal VA should be displayed in the VA page.
   * Click on "Create a Virtual Group" button and select "Personal VG".
   * Enter the same name used recently.
   * Validate that 'This name is already taken' error message should be displayed
   */
  it('C124853: Verify duplicate name is not allowed when creating personal VG flow-2', { tags: ['Virtual Accounts', 'staging'] }, () => {
    const vaName = virtualAccount.createVirtualAccount('Personal');

    virtualAccount.virtualGroupCreateButton().scrollIntoView().click();
    virtualAccount.virtualGroupAccountTypePersonalButton().click();
    virtualAccount.vaCreatePopupNameInput().type(vaName);
    virtualAccount.vaNameErrorLabel().should('have.text', 'This name is already taken.');
    virtualAccount.vaCreatePopupCancelOrBackButton().click();
    virtualAccount.deleteVirtualAccount(vaName);
  });

  /*
   * Go to Virtual Accounts page.
   * Click on "Create a Virtual Account" button and select "Global VA" and Enter a unique name
   * Created Global VA should be displayed in the VA page.
   * Click on "Create a Virtual Group" button and select "Global VG".
   * Enter the same name used recently.
   * Validate that 'This name is already taken' error message should be displayed
   */
  it('C124854: Verify duplicate name is not allowed when creating Global VG flow-2', { tags: ['Virtual Accounts', 'staging'] }, () => {
    const vaName = virtualAccount.createVirtualAccount('Global');

    virtualAccount.virtualGroupCreateButton().scrollIntoView().click();
    virtualAccount.virtualGroupAccountTypeGlobalButton().click();
    virtualAccount.vaCreatePopupNameInput().type(vaName);
    virtualAccount.vaNameErrorLabel().should('have.text', 'This name is already taken.');
    virtualAccount.vaCreatePopupCancelOrBackButton().click();
    virtualAccount.deleteVirtualAccount(vaName);
  });

  /*
   * Go to Virtual Accounts page.
   * Click on "Create a Virtual Account" button and select "Global VA" and Enter a unique name
   * Created Global VA should be displayed in the VA page.
   * Click on "Create a Virtual Account" button and select "Global VA".
   * Enter the same name used recently.
   * Validate that 'This name is already taken' error message should be displayed
   */
  it('C124847: Verify duplicate name is not allowed when creating Global VA', { tags: ['Virtual Accounts', 'staging'] }, () => {
    const vaName = virtualAccount.createVirtualAccount('Global');

    virtualAccount.createVaButton().scrollIntoView().click();
    virtualAccount.vaAccountTypeGlobalButton().click();
    virtualAccount.vaCreatePopupNameInput().type(vaName);
    virtualAccount.vaNameErrorLabel().should('have.text', 'This name is already taken.');
    virtualAccount.vaCreatePopupCancelOrBackButton().click();
    virtualAccount.deleteVirtualAccount(vaName);
  });
});
