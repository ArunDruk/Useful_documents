import { urlHelpers } from '../../../utils';
import { virtualAccount } from '../../../pages';

describe('Virtual Account Filter Search', () => {
  let globalVA = '';
  let personalVA = '';
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.virtualAccounts);
    cy.waitForLoaders();
    globalVA = virtualAccount.createVirtualAccount('Global');
    personalVA = virtualAccount.createVirtualAccount('Personal');
  });

  afterEach(() => {
    virtualAccount.deleteVirtualAccount(globalVA);
    virtualAccount.deleteVirtualAccount(personalVA);
  });
  /**
   * Regression C6698
   * - Enter the value in virtual account search field and verify matching VA list is displaying
   * - Enter the search value, select filter value as Personal -> verify Personal is selected in filter and verify matching VA list is displaying
   * - Enter the search value, select filter value as Global -> verify Global is selected in filter and verify matching VA list is displaying
   * - Enter the search value, select filter value as System of records -> verify System of records is selected in filter and verify matching VA list is displaying
   */
  it('C6698: Virtual Account filtering in search', { tags: ['Virtual Accounts', 'staging'] }, () => {
    // Verify the Search Result have the Virtual Account
    virtualAccount.searchVaNameInput().type('Te');
    virtualAccount.searchResultVaNameList().should('contain', 'Te');
    // selecting the Filter value as Personal Virtual Account
    virtualAccount.vaFilterTrigger().click();
    cy.contains('Personal Virtual').click();
    virtualAccount.vaFilterPersonalVirtualAccountCheckboxStatus().should('include', 'checked');
    virtualAccount.vaFilterTrigger().click();
    // Verify the Search Result have the Virtual Account
    virtualAccount.searchVaNameInput().clear().type('Te');
    virtualAccount.searchResultVaNameList().should('exist');
    // selecting the Filter value as Global Virtual Account
    virtualAccount.vaFilterTrigger().click();
    cy.contains('Personal Virtual').click();
    cy.contains('Global Virtual').click();
    virtualAccount.vaFilterGlobalVirtualAccountCheckboxStatus().should('include', 'checked');
    virtualAccount.vaFilterTrigger().click();
    // Verify the Search Result have the Virtual Account
    virtualAccount.searchVaNameInput().clear().type('Te');
    virtualAccount.searchResultVaNameList().should('exist');
    // selecting the Filter value as System of Records Merged Account
    virtualAccount.vaFilterTrigger().click();
    cy.contains('Global Virtual').click();
    cy.contains('System of Records').click();
    virtualAccount.vaFilterSystemOfRecordsMergedAccountCheckboxStatus().should('include', 'checked');
    virtualAccount.vaFilterTrigger().click();
    // Verify the Search Result have the Virtual Account
    virtualAccount.searchVaNameInput().clear().type('a');
    virtualAccount.searchResultSystemOfRecordsMergedAccountList().should('exist');
    virtualAccount.searchVaNameInput().clear();
    virtualAccount.vaFilterTrigger().click();
    cy.contains('System of Records').click();
    virtualAccount.vaFilterTrigger().click();
  });
});
