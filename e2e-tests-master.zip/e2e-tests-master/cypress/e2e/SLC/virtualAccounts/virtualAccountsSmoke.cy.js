import { urlHelpers } from '../../../utils';

const randId = () => Cypress._.random(0, 1e6);

beforeEach(() => {
  cy.loginByApi();
  cy.visit(urlHelpers.virtualAccounts);
  cy.intercept('POST', 'api/v2/group').as('createGroup');
  cy.intercept('search/virtual_groups/_search*').as('search');
});

describe('Creating virtual account', () => {
  // TODO: Fix failure when there are no Virtual Groups
  // Smoke & Sanity C2260
  it.skip('C2260: Test virtual account group loaded', { tags: 'Virtual Accounts' }, () => {
    cy.getByTestId('layout-navigation-module-item--virtualAccounts').should('be.visible').click();
    // Verify the existing Virtual Group is displaying
    cy.getByTestId('virtualAccounts-logical_group-listItem').should('exist');
    // Verify the Existing Virtual Account is displaying
    cy.getByTestId('virtualAccounts-customer_group-listItem').should('exist');
  });

  // Smoke & Sanity C2259
  // TODO: Due to dynamic data loads in tab need to include condition or partial validation
  it.skip('C2259: Test virtual account', { tags: 'Virtual Accounts' }, () => {
    cy.getByTestId('layout-navigation-module-item--virtualAccounts').should('be.visible').click();
    // Click on the Create Virtual Account
    cy.getByTestId('virtualAccounts-groupList-customer_group-createButton').scrollIntoView().should('be.visible').click();
    // Selecting the Personal Account
    cy.getByTestId('virtualAccounts-chooseAccountType-personal_account').should('be.visible').click();
    // Enter the VA Name
    const vaName = `CypressTest ${randId()}`;
    cy.getByTestId('virtualAccounts-nameInput-searchInput').type(vaName);
    // Click on Next button
    cy.getByTestId('virtualAccounts-createAccount-submitButton').should('be.visible').click();
    // Enter the Customer name and select customer
    cy.getByTestId('virtualAccounts-searchBox-searchInput').should('be.visible').type('b');
    cy.wait('@search');
    cy.getByTestId('virtualAccounts-searchList-resultItem').eq(0).click();
    cy.getByTestId('virtualAccounts-searchBox-searchInput').should('be.visible').clear().type('c');
    cy.wait('@search');
    cy.getByTestId('virtualAccounts-searchList-resultItem').eq(0).click();
    // Click on Create button
    cy.getByTestId('virtualAccounts-createAccount-submitButton').should('be.visible').click();
    cy.wait('@createGroup');
    // Verify the Search Result have the Virtual Account
    cy.getByTestId('virtualAccounts-groupList-customer_group-searchInput').clear().type(vaName);
    cy.getByTestId('virtualAccounts-customer_group-listItem-label').should('have.text', vaName);
    // TODO: Added Static wait due to sometime there is delay in the created VA displaying in search Input
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(3000);
    // Navigate to Customer Insight page
    cy.getByTestId('layout-navigation-module-item--customerInsights').should('be.visible').click();
    // Enter the sample value in search
    cy.getByTestId('customerInsights-searchBar-searchInput')
      .should('be.visible')
      .type(vaName)
      .then(() => {
        cy.get('#customers-module-searchbar div').then(($button) => {
          const searchResult = $button.text();
          if (searchResult.localeCompare('No customers found')) {
            // Navigate to Virtual Account Page
            cy.getByTestId('layout-navigation-module-item--virtualAccounts').should('be.visible').click();
            // Verify the Search Result have the Virtual Account
            cy.getByTestId('virtualAccounts-groupList-customer_group-searchInput').clear().type(vaName);
            cy.getByTestId('virtualAccounts-customer_group-listItem-label').should('have.text', vaName);
            // Navigate to Customer Insight page
            cy.getByTestId('layout-navigation-module-item--customerInsights').should('be.visible').click();
            // eslint-disable-next-line cypress/no-unnecessary-waiting
            cy.wait(5000);
            cy.getByTestId('customerInsights-searchBar-searchInput').should('be.visible').type(vaName);
            cy.getByTestId('customerInsights-searchBar-searchOption-item').should('be.visible').eq(0).click();
          } else {
            cy.getByTestId('customerInsights-searchBar-searchOption-item').should('be.visible').eq(0).click();
          }
        });
      });
    // Overview
    cy.getByTestId('customersPage-tabSlider-overview').eq(1).should('be.visible').click();
    cy.getByTestId('common-buttonSwitcher-btn').eq(0).should('be.visible').click();
    cy.getByTestId('common-caseList-sideListItem').should('exist');
    // Need Attention
    cy.getByTestId('customersPage-tabSlider-need_attention').eq(1).should('exist').click();
    cy.getByTestId('sentimentsFeed-lightFilter-groupBy-btn').click();
    cy.get('[data-testid="common-dropdown-sentiment_type"]').click();
    cy.getByTestId('optionsSwitcherNew-wrapper').should('exist');
    // Escalations
    cy.getByTestId('customersPage-tabSlider-escalations').eq(1).should('exist').click();
    cy.getByTestId('common-dropdown-btn').click();
    cy.get('[data-testid="common-dropdown-sl_severity_c"]').click();
    cy.getByTestId('optionsSwitcherNew-wrapper').should('exist');
    // Negative Sentiments
    cy.getByTestId('customersPage-tabSlider-negative_sentiments').eq(1).should('exist').click();
    cy.getByTestId('sentimentsFeed-lightFilter-groupBy-btn').click();
    cy.get('[data-testid="common-dropdown-sentiment_type"]').click();
    cy.getByTestId('optionsSwitcherNew-wrapper').should('exist');
    // Positive Sentiments
    cy.getByTestId('customersPage-tabSlider-positive_sentiments').eq(1).should('exist').click();
    cy.getByTestId('sentimentsFeed-lightFilter-groupBy-btn').click();
    cy.get('[data-testid="common-dropdown-sentiment_type"]').click();
    cy.getByTestId('optionsSwitcherNew-wrapper').should('exist');
    // Engineering Issues
    cy.getByTestId('customersPage-tabSlider-engineering_issues').eq(1).should('exist').click();
    // TODO: waiting for data test-id SLC-31066
    cy.get('[class^=EngIssuesTab__EngIssueWrapper]').should('exist');
    // Product Feedback
    cy.getByTestId('customersPage-tabSlider-product_feedback').eq(1).should('exist').click();
    cy.getByTestId('sentimentsFeed-lightFilter-groupBy-btn').click();
    cy.get('[data-testid="common-dropdown-sentiment_type"]').click();
    cy.getByTestId('optionsSwitcherNew-wrapper').should('exist');
    // Feature Request
    cy.getByTestId('customersPage-tabSlider-feature_requests').eq(1).should('exist').click();
    cy.getByTestId('sentimentsFeed-lightFilter-groupBy-btn').click();
    cy.get('[data-testid="common-dropdown-business_hours"]').click();
    cy.getByTestId('optionsSwitcherNew-wrapper').should('exist');
    // Delete the Created Virtual Account
    cy.getByTestId('layout-navigation-module-item--virtualAccounts').should('be.visible').click();
    cy.getByTestId('virtualAccounts-groupList-customer_group-searchInput').clear().type(vaName);
    cy.getByTestId('virtualAccounts-customer_group-listItem-label').should('have.text', vaName);
    cy.getByTestId('virtualAccounts-listItem-customer_group-delete').click();
    cy.getByTestId('common-button').contains('Delete').click();
  });
});
