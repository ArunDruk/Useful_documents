import { navBar, virtualAccount } from '../../../pages';
import { urlHelpers } from '../../../utils';

// Skipping Enable Disable module test cases
describe.skip('Enable and Disable Virtual Account Tests', () => {
  beforeEach(() => {
    cy.loginByApi();
  });

  after(() => {
    cy.slcHelpers.enableModule('virtualAccounts');
    navBar.virtualAccounts().should('exist');
  });

  /**
   * Regression C732
   * Go to settings page and click on production Edition(SL Admins). Click on disable the Virtual Account page . Go back to Virtual Account page.
   */
  it('C732: Check the functionality of VA enable and disable mode (Disabled)', { tags: ['@EnableDisableLockTests', '@NotThreadSafe'] }, () => {
    cy.slcHelpers.disableModule('virtualAccounts');
    cy.visit(urlHelpers.virtualAccounts);
    cy.getByTestId('Virtual_Accounts-disable-modal-message').invoke('text').should('include', 'Virtual Accounts module is disabled for you');
    navBar.virtualAccounts().should('not.exist');
  });

  /**
   * Regression C731
   * Go to settings page and click on production Edition(SL Admins). Click on 'enable' the Virtual Account page . Go back to Virtual Account page.
   */
  it('C731: Check the functionality of VA enable and disable mode', { tags: ['@EnableDisableLockTests', '@NotThreadSafe'] }, () => {
    cy.slcHelpers.enableModule('virtualAccounts');
    cy.visit(urlHelpers.virtualAccounts);
    navBar.virtualAccounts().should('exist');
    virtualAccount.virtualGroupCreateButton().should('exist');
  });
});
