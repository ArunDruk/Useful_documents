import { urlHelpers } from '../../../utils';
import { virtualAccount, preferences } from '../../../pages';

describe('Creating Virtual Group', () => {
  let vgName = '';
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.virtualAccounts);
  });

  /**
   * Regression C746
   * - select two or more VA to create a VG
   */
  it('C746: Check if VG can be created', { tags: ['Virtual Accounts', 'staging'] }, () => {
    vgName = virtualAccount.createVirtualGroup('Global');
    virtualAccount.deleteVirtualGroup(vgName);
  });

  /**
   * Regression C747
   * - Click on the delete icon appearing on the right side of the VG
   */
  it('C747: Check if the created VG gets deleted', { tags: ['Virtual Accounts', 'staging'] }, () => {
    vgName = virtualAccount.createVirtualGroup('Global');
    virtualAccount.deleteVirtualGroup(vgName);
  });

  /**
   * Regression C748
   *  - click on the edit button present in the right hand side of the VG account and click on that
   */
  it('C748: Chek if the VG gets edited', { tags: ['Virtual Accounts', 'staging'] }, () => {
    // TODO: Temp Fix due to Elastic wait - comment below line and last delete va line, added static vaName,
    const vaName = 'C9405 VA DO NOT DELETE'; // virtualAccount.createVirtualAccount('Personal');
    vgName = virtualAccount.createVirtualGroup('Personal');
    virtualAccount.editVirtualGroupButton(vgName).click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(3000);
    virtualAccount.vaCreatePopupSearchCustomerNameInput().clear().type(vaName);
    virtualAccount.vaCreatePopupCustomerSearchResultList().eq(0).click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(2000);
    virtualAccount.editVirtualGroupSaveButton().scrollIntoView().click();
    virtualAccount.selectedVAListInVirtualGroupLabel(vgName).invoke('text').should('contain', vaName);
    virtualAccount.deleteVirtualGroup(vgName);
    // virtualAccount.deleteVirtualAccount(vaName);
  });

  /**
   * Regression C749
   * - Click on the preferences and try to add the added VA/ created VA in the va section
   */
  // This is skipped as Newly created Vgroup will take time to reflect in elastic search
  // Iskander is working on this
  it('C749: Check if the created VG can be added in the favourite list', { tags: ['Virtual Accounts', 'staging'] }, () => {
    // Temp Fix due to Elastic wait - comment below line and last delete vg line, added static vgName,
    vgName = 'C9405 VG DO NOT DELETE'; // virtualAccount.createVirtualGroup('Personal');
    preferences.selectFavoriteCustomerInPreference(vgName);
    preferences.removeRecentlyFavoriteCustomersInPreference();
    //  virtualAccount.deleteVirtualGroup(vgName);
  });
});
