import { consolePage, globalFilters, backlogPage, escalations } from '../../../pages/index';
import { urlHelpers } from '../../../utils';
import { setDateFilterToRightNow } from '../escalations/support';

describe('Global Filters Tests in Modules', { tags: '@FilterTests' }, () => {
  let customerName = '';
  before(() => {
    cy.loginByApi();
    cy.slcHelpers.clearCustomersQuickFilter();
    cy.slcHelpers.clearAgentsQuickFilter();
    cy.slcHelpers.clearCaseFieldQuickFilter();
    cy.slcHelpers.deleteGlobalFilter();
    cy.slcHelpers.getCustomerDetails().then((customerDetails) => {
      const customerDetail = Cypress._.sample(customerDetails);
      customerName = customerDetail.name;
      cy.visit(urlHelpers.console.withTimeFilter.lastSevenDays);
      cy.waitForLoaders();
      globalFilters.filterByCustomerGlobalFilter(customerName);
    });
  });

  beforeEach(() => {
    cy.loginByApi();
  });

  after(() => {
    cy.slcHelpers.clearCustomersQuickFilter();
    cy.slcHelpers.clearAgentsQuickFilter();
    cy.slcHelpers.clearCaseFieldQuickFilter();
    cy.slcHelpers.deleteGlobalFilter();
  });

  /*
   * Open the Console page.
   * Validate the global filter affects the console page.
   */
  it('C677: Check the Global filter functionality in console  page ', { tags: ['Filters', 'staging'] }, () => {
    cy.visit(urlHelpers.console.withTimeFilter.lastSevenDays);
    cy.waitForLoaders();
    consolePage.needAttentionTab().click({ force: true });
    consolePage.caseListCustomerName().eq(0).should('have.text', customerName);
  });

  /*
   * Open the Case Board page.
   * Validate the global filter affects the case board page.
   */
  it('C678: Check the Global filter functionality in case board  page ', { tags: ['Filters', 'staging'] }, () => {
    cy.waitForLoaders();
    cy.visit(urlHelpers.backlog);
    backlogPage.backlogWelcomePageVisibilityCheck();
    cy.waitForLoaders();
    backlogPage.backlogListCustomerName().eq(0).should('have.text', customerName);
    backlogPage.backlogListCustomerName().eq(1).should('have.text', customerName);
  });

  /*
   * Open the Escalations page.
   * validate the global filter affects the escalations page.
   */
  it('C683: Check the Global filter functionality in escalation page ', { tags: ['Filters', 'staging'] }, () => {
    cy.visit(urlHelpers.escalationBoard);
    cy.waitForLoaders();
    setDateFilterToRightNow();
    escalations.expandContainer(escalations.lteContainer);
    escalations.expandContainer(escalations.activeEscalationsContainer);
    escalations.expandContainer(escalations.escalationRequestsContainer);
    escalations.escalationCaseCardCustomerName().eq(0).should('have.text', customerName);
  });
});
