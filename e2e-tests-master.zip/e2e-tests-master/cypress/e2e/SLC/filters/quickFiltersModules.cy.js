import { consolePage, globalFilters } from '../../../pages/index';
import { urlHelpers } from '../../../utils';

describe('Quick Filters Tests', { tags: '@FilterTests' }, () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.slcHelpers.clearCustomersQuickFilter();
    cy.slcHelpers.clearAgentsQuickFilter();
    cy.slcHelpers.clearCaseFieldQuickFilter();
    cy.slcHelpers.deleteGlobalFilter();
    cy.visit(urlHelpers.console.home);
    cy.waitForLoaders();
  });

  afterEach(() => {
    cy.slcHelpers.clearCustomersQuickFilter();
    cy.slcHelpers.clearAgentsQuickFilter();
    cy.slcHelpers.clearCaseFieldQuickFilter();
    cy.slcHelpers.deleteGlobalFilter();
  });

  /*
   *Go to Console page.
   *Navigate to the module with "Global filters".
   *Under Quick filter, Click on the "Customers" and Customer window is displayed.
   *Click on the "Selected" button, Previously selected customer list with check-box will be displayed.
   *Uncheck an option and validate.
   */
  it('C6267: Check global/quick filter selected window when data is changed ', { tags: ['Filters', 'staging'] }, () => {
    cy.intercept('PUT', 'api/users/dashboard_settings/deep/support/filter_ui_settings_v2/quick_filter_customers').as('applyCustomerQuickFilter');
    consolePage.negativeSentimentsTab().click({ force: true });
    consolePage.groupByElapsedTime();
    consolePage.expandAllConsoleLists();
    consolePage
      .caseListCustomerName()
      .eq(0)
      .then((buttonText) => {
        const customerName = buttonText.text();

        globalFilters.selectCustomerInQuickFilter(customerName);
        globalFilters.clickFilterToExpand();
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(2000);
        globalFilters.clickQuickFilterToExpand();
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(2000);
        globalFilters.quickFilterCustomerLink().click();
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(2000);
        globalFilters.quickFilterCustomerSelectedButton().click();
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(2000);
        globalFilters.quickFilterSearchResultFirst().eq(0).click();
        globalFilters.filterApplyButton().click();

        cy.wait('@applyCustomerQuickFilter');
        cy.waitForLoaders();
        consolePage.consoleHeader().click();
        consolePage.needAttentionTab().click({ force: true });
        consolePage.caseListCustomerName().eq(0).should('not.have.text', customerName);
      });
  });
});
