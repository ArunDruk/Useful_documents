import { consolePage, globalFilters, filters, trends, metrics, sentiments, topics } from '../../../pages/index';
import { urlHelpers } from '../../../utils';
import { setStatusAsPrimaryTopic, setPriorityAsSecondaryTopic } from '../topics/support';

describe('Global Filters Tests in Analytics', { tags: '@FilterTests' }, () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.slcHelpers.clearCustomersQuickFilter();
    cy.slcHelpers.clearAgentsQuickFilter();
    cy.slcHelpers.clearCaseFieldQuickFilter();
    cy.slcHelpers.deleteGlobalFilter();
  });

  afterEach(() => {
    cy.slcHelpers.clearCustomersQuickFilter();
    cy.slcHelpers.clearAgentsQuickFilter();
    cy.slcHelpers.clearCaseFieldQuickFilter();
    cy.slcHelpers.deleteGlobalFilter();
  });
  /*
   * Open the Trends page.
   * validate the global filter affects the trends page.
   */
  it('C680: Check the Global filter functionality in trends page ', { tags: ['Filters', 'staging'] }, () => {
    cy.visit(urlHelpers.trends);
    cy.waitForLoaders();
    trends.negativeSentimentsTab().click({ force: true });
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(2000);
    consolePage.groupByElapsedTime();
    consolePage.expandAllConsoleLists();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(2000);
    consolePage
      .caseListCustomerName()
      .eq(0)
      .then(($custName) => {
        consolePage.negativeSentimentsTabCount().then(($bfrValue) => {
          const beforeValue = $bfrValue.text();
          const customerName = $custName.text().trim();
          globalFilters.filterByCustomerGlobalFilter(customerName);
          cy.waitForLoaders();
          consolePage.caseListCustomerName().should('contain.text', customerName);
          consolePage.negativeSentimentsTabCount().invoke('text').should('not.contain', beforeValue);
        });
      });
  });

  /**
   * Regression C679
   * - Navigate to Ops metrics section and pre value of escalation
   * - Select a Global filter
   * - Verify Ops metrics page values was filtered (check pre and post values for Escalation)
   */
  it('C679:	Verify that global filter applies site wide (Ops Metrics)', { tags: ['Filters', 'staging'] }, () => {
    cy.visit(urlHelpers.operationalMetrics.home);
    cy.waitForLoaders();
    metrics
      .newEscalationsCount()
      .eq(0)
      .then((bfrNewEscalationsCount) => {
        cy.waitForLoaders();
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(2000);
        const beforeNewEscalationsCount = bfrNewEscalationsCount.text();
        // create first filter and ensure name is default
        cy.slcHelpers.getCustomerDetails().then((customerDetails) => {
          const customerDetail = Cypress._.sample(customerDetails);
          const customerName = customerDetail.name;
          cy.waitForLoaders();
          globalFilters.filterByCustomerGlobalFilter(customerName);
        });
        cy.waitForLoaders();
        // get new metric count
        metrics
          .newEscalationsCount()
          .eq(0)
          .then((afterNewEscalationsCount) => {
            cy.waitForLoaders();
            // eslint-disable-next-line cypress/no-unnecessary-waiting
            cy.wait(2000);
            expect(afterNewEscalationsCount.text()).not.equal(beforeNewEscalationsCount);
          });
      });
  });

  /**
   * Regression C682
   * - Navigate to Experiential metrics section sentiments page and case count
   * - Select a Global filter
   * - Verify Sentiments page values was filtered (check pre and post values of case count)
   */
  it('C682: Verify that global filter applies site wide (Sentiment)', { tags: ['Filters', 'staging'] }, () => {
    cy.visit(urlHelpers.experientialMetrics.sentiments);
    filters.getStartedButtonSentimentsModule();
    cy.waitForLoaders();
    sentiments
      .headerTicketCountLabel()
      .eq(0)
      .then((bfrCaseCount) => {
        cy.waitForLoaders();
        const beforeCaseCount = bfrCaseCount.text();
        cy.slcHelpers.getCustomerDetails().then((customerDetails) => {
          const customerDetail = Cypress._.sample(customerDetails);
          const customerName = customerDetail.name;
          cy.waitForLoaders();
          globalFilters.filterByCustomerGlobalFilter(customerName);
        });
        cy.waitForLoaders();
        // get new case count
        sentiments
          .headerTicketCountLabel()
          .eq(0)
          .then((afterCaseCount) => {
            cy.waitForLoaders();
            expect(afterCaseCount.text()).not.equal(beforeCaseCount);
          });
      });
  });

  /**
   * Regression C681
   * - Navigate to Topics section page and case count
   * - Select a Global filter
   * - Verify Topics page values was filtered (check pre and post values of case count)
   */
  it('C681: Verify that global filter applies site wide (Topics)', { tags: ['Filters', 'staging'] }, () => {
    cy.visit(urlHelpers.topics);
    setStatusAsPrimaryTopic();
    setPriorityAsSecondaryTopic();
    cy.waitForLoaders();
    topics
      .topicsHeaderTicketCount()
      .eq(0)
      .then((bfrCaseCount) => {
        cy.waitForLoaders();
        const beforeCaseCount = bfrCaseCount.text();
        cy.slcHelpers.getCustomerDetails().then((customerDetails) => {
          const customerDetail = Cypress._.sample(customerDetails);
          const customerName = customerDetail.name;
          cy.waitForLoaders();
          globalFilters.filterByCustomerGlobalFilter(customerName);
        });
        cy.waitForLoaders();
        // get new case count
        topics
          .topicsHeaderTicketCount()
          .eq(0)
          .then((afterCaseCount) => {
            cy.waitForLoaders();
            expect(afterCaseCount.text()).not.equal(beforeCaseCount);
          });
      });
  });
});
