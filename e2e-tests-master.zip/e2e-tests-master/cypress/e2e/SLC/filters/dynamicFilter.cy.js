import { backlogPage, apiHelpers, topics, filters } from '../../../pages/index';
import { urlHelpers } from '../../../utils';

describe('Dynamic Filters Tests', { tags: '@FilterTests' }, () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.slcHelpers.clearCustomersQuickFilter();
    cy.slcHelpers.clearAgentsQuickFilter();
    cy.slcHelpers.clearCaseFieldQuickFilter();
    cy.slcHelpers.deleteGlobalFilter();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    apiHelpers.removeDynamicFilterBacklogPage();
    apiHelpers.setToDefaultListBacklog();
    cy.visit(urlHelpers.backlog);
    cy.waitForLoaders();
    backlogPage.backlogWelcomePageVisibilityCheck();
  });

  afterEach(() => {
    apiHelpers.setToDefaultListBacklog();
    apiHelpers.removeDynamicFilterBacklogPage();
  });

  /*
   * Navigate to any page with Dynamic Filter.
   * Click on the Dynamic Filter icon.
   * Choose any field in "Dynamic Filter Settings" window and save.
   * Data should be displayed on the selected value.
   */
  it('C656: Check functionality of dynamic filter ', { tags: ['Filters', 'staging'] }, () => {
    filters.addDynamicFilterButton().click();
    filters.dynamicFilterWelcomePopupVisibilityCheck();
    topics.dynamicFilterPriorityCheckbox().click();
    topics.dynamicFilterSaveButton().click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(3000);
    topics.dynamicFilterDropdown().eq(0).should('be.visible').click();
    cy.waitForLoaders();
    filters.dynamicFilterPriorityPopupHeader().then(($selected) => {
      const selectedButton = $selected.text();
      if (selectedButton.includes('selected')) {
        filters.dynamicFilterPriorityPopupSelectedRemoveButton().click();
      }
      filters.dynamicFilterDropdownListFirstItem().should('be.visible').contains('Medium').click({ force: true });
      // eslint-disable-next-line cypress/no-unnecessary-waiting
      cy.wait(1000);
      filters.dynamicFilterDropdownApplyButton().should('be.visible').click();
      cy.waitForLoaders();
      backlogPage.backlogListPriorityLabel().eq(0).should('have.text', 'Medium');
    });
  });
});
