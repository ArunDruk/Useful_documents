export const switchToMyGlobalFilterView = () => {
  cy.getByTestId('filters-scoreFilters-dropdown').then(($btn) => {
    const filterButton = $btn.text();
    if (filterButton === 'Create a new filter...Quick Filter') {
      cy.getByTestId('filters-scoreFilters-createNewFilter').click();
    } else {
      cy.getByTestId('layout-header-filter-manageGlobalBtn').click();
      cy.contains('Create a new filter').click();
    }
  });
};
