import { getAgentNameFromCaseDetails } from '../agents/support';
import { urlHelpers } from '../../../utils';
import { globalFilters, agentInsights, apiHelpers, consolePage } from '../../../pages/index';

describe('Quick Filter by Favorite Agents', { tags: '@FilterTests' }, () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.removeAllFavoriteAgents();
    getAgentNameFromCaseDetails().then((caseDetails) => {
      const caseDetail = Cypress._.sample(caseDetails);

      cy.wrap(caseDetail).as('caseDetail');

      cy.visit(urlHelpers.myAgents);
    });
  });

  afterEach(() => {
    apiHelpers.removeAllFavoriteAgents();
    cy.slcHelpers.clearAgentsQuickFilter();
  });

  /*
  1. From Agent Favorites page, search for and add a Favorite Agent
  2. From Console page, check # of New Cases (for comparison)
  3. Go to Global globalFilters and filter by Favorite Agents
  4. Verify Console page shows less tickets in New Tickets tile
   */

  //   Global quick filter for agents
  it('C635: Checking the inner functionality of the agent filter', { tags: ['Agents', 'staging'] }, function addFilter() {
    // search for and add agent to favorites
    agentInsights.agentSearchFromFavoritesFieldInput().should('be.visible').click().type(this.caseDetail.agentName);
    // ensure Individual Agent is checked
    agentInsights.selectIndividualAgentCheckboxInFavAgent();
    agentInsights.agentSearchFromFavoritesResultList().first().click();
    // there is now a favorite button (star) visible so agent is added
    // SLC-32375 asks to make the name verifiable instead of just checking for the favorite button's presence
    agentInsights.removeFavoriteAgentButton().should('be.visible');

    cy.visit(urlHelpers.console.home);
    consolePage.newCasesTab().click();
    consolePage.newCasesTab().click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(3000);
    // get before count of New cases
    consolePage
      .newCasesTabHeaderList()
      .eq(0)
      .then((bfrvalue) => {
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(5000);
        const beforevalue = bfrvalue.text();
        // add quick filter for an agent
        globalFilters.addFavoriteAgentQuickFilter();
        // check after count of new cases against before count
        cy.getByTestId('consolePage-tabsSlider-tab-Tickets').should('be.visible').click();
        cy.getByTestId('consolePage_lists-header')
          .eq(0)
          .then((aftervalue) => {
            expect(aftervalue.text()).not.equal(beforevalue);
          });
      });
    cy.slcHelpers.clearAgentsQuickFilter();
  });
});
