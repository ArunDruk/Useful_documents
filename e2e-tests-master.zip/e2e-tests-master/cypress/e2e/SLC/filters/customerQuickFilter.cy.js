import { getCustomerNameFromCaseDetails } from '../customers/support';
import { urlHelpers } from '../../../utils';
import { globalFilters, customerFavorites, apiHelpers, consolePage } from '../../../pages/index';

describe('Quick Filter by Favorite Customers', { tags: '@FilterTests' }, () => {
  beforeEach(() => {
    cy.intercept('POST', 'search/virtual_groups/_search*').as('searchCustomer');
    cy.intercept('PUT', 'api/users/dashboard_settings').as('editFavoriteCustomers');

    cy.loginByApi();
    apiHelpers.resetFavoriteCustomers();
    apiHelpers.removeAllCustomGlobalCustomerFilters();
    // Note: If fetched customer id is not valid/active, the tests will fail
    getCustomerNameFromCaseDetails().then((caseDetails) => {
      const caseDetail = Cypress._.sample(caseDetails);

      cy.wrap(caseDetail).as('caseDetail');

      cy.visit(urlHelpers.myCustomers);
    });
  });

  afterEach(() => {
    apiHelpers.resetFavoriteCustomers();
    apiHelpers.removeAllCustomGlobalCustomerFilters();
  });

  /*
  1. From Customer Favorites page, search for and add a Favorite Customer
  2. From Console page, check # of New Cases (for comparison)
  3. Go to Global globalFilters and filter by Favorite Customers
  4. Verify Console page shows less tickets in New Tickets tile
   */

  it('C630: Checking the functionality of Quick Filter-> Customer filter (Favorited)', { tags: ['Customers', 'staging'] }, function addFilter() {
    cy.waitForLoaders();
    customerFavorites.zeroStateAddFavoriteButton().click();
    // search for customer name and add to favorites
    cy.getByTestId('customers-addFavorite-searchInput').type(this.caseDetail.customerName);
    cy.wait('@searchCustomer');
    customerFavorites.searchResultsListItem().click();

    cy.visit(urlHelpers.console.home);
    cy.waitForLoaders();
    consolePage.setTimeFilterToLastSevenDays();
    consolePage.newCasesTab().click();
    cy.waitForLoaders();
    // get before count of New cases
    consolePage
      .newCasesTabHeaderList()
      .contains('Assigned Cases')
      .then((bfrvalue) => {
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(5000);
        const beforevalue = bfrvalue.text();
        // add quick filter for a customer
        globalFilters.addFavoriteCustomerQuickFilter();
        cy.waitForLoaders();
        // check after count of new cases against before count
        consolePage.newCasesTab().should('be.visible').click();
        consolePage
          .newCasesTabHeaderList()
          .contains('Assigned Cases')
          .then((aftervalue) => {
            expect(aftervalue.text()).not.equal(beforevalue);
          });
      });
    apiHelpers.removeAllCustomGlobalCustomerFilters();
  });
});
