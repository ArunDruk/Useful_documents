import { switchToMyGlobalFilterView } from './support';
import { globalFilters, agentInsights, apiHelpers, customerFavorites, preferences } from '../../../pages';
import { urlHelpers } from '../../../utils';

describe('Filters Tests', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.console.home);
  });

  // Regression C625
  it("C625: Checking the functionality of Global filter present in whole dashboard' (Select all)", { tags: 'Filters' }, () => {
    // click on filter icon and click on manage link
    cy.getByTestId('layout-header-filter-toggle').should('be.visible').click().invoke('attr', 'data-status').should('include', 'expanded');
    switchToMyGlobalFilterView();
    cy.getByTestId('globall-filter-tab-Case Fields').click();
    globalFilters
      .caseFieldsAgeHeaderDialogBox()
      .should('be.visible')
      .then(($btn) => {
        const filterValue = $btn.text();
        globalFilters.caseFieldsAgeHeaderDialogBox().click();
        // TODO - Request for data test-id via -SLC-33672.
        cy.get('.LIxWkpr6AVc1nGkxGY0nQ ._2ZzYNQThmudfmsMxcCLlnO').contains('Select all').click();
        cy.get('._2JLf4lSn-I9BJfa6mCXVXo ._23RMyCCNmoPnqOkIUl5hqQ').then(($count) => {
          const fieldLength = $count.length;
          cy.get('[class^="styles__SelectedValuesItem-sc"] ._23RMyCCNmoPnqOkIUl5hqQ').should('have.length', fieldLength);
          globalFilters.globalFilterSelectedValueCountLabel().should('have.text', `${fieldLength}selected`);
          cy.get('[class^="styles__SelectedValuesLabel-sc"]').should('contain', filterValue);
        });
      });
    cy.contains('Cancel').click();
  });

  // Regression C624
  it("C624: Checking the functionality of Global filter present in whole dashboard' (Reset)", { tags: 'Filters' }, () => {
    // click on filter icon and click on manage link
    cy.getByTestId('layout-header-filter-toggle').should('be.visible').click().invoke('attr', 'data-status').should('include', 'expanded');
    switchToMyGlobalFilterView();
    cy.getByTestId('globall-filter-tab-Case Fields').click();
    globalFilters
      .caseFieldsAgeHeaderDialogBox()
      .should('be.visible')
      .then(($btn) => {
        const filterValue = $btn.text();
        globalFilters.caseFieldsAgeHeaderDialogBox().click();
        // TODO - Request for data test-id via -SLC-33672.
        cy.get('.LIxWkpr6AVc1nGkxGY0nQ ._2ZzYNQThmudfmsMxcCLlnO').contains('Select all').click();
        cy.get('[class^="styles__SelectedValuesItem-sc"] ._23RMyCCNmoPnqOkIUl5hqQ').should('exist');
        cy.get('[class^="styles__SelectedValuesLabel-sc"]').should('contain', filterValue);
        cy.get('._2wG7Xk_n4ar6imoA0Wmjl0 div').contains('Reset').click();
        cy.get('[class^="styles__SelectedValuesItem-sc"] ._23RMyCCNmoPnqOkIUl5hqQ').should('not.exist');
      });
    cy.contains('Cancel').click();
  });

  // Regression C626
  it("C626: Checking the functionality of Global filter present in whole dashboard' (Expand)", { tags: 'Filters' }, () => {
    // click on filter icon and click on manage link
    cy.getByTestId('layout-header-filter-toggle').should('be.visible').click().invoke('attr', 'data-status').should('include', 'expanded');
    switchToMyGlobalFilterView();
    cy.getByTestId('globall-filter-tab-Case Fields').click();
    globalFilters
      .caseFieldsAgeHeaderDialogBox()
      .should('be.visible')
      .then(() => {
        globalFilters.globalFilterCaseFieldSelectedValueButton().should('not.exist');
        globalFilters.caseFieldsAgeHeaderDialogBox().click();
        globalFilters.globalFilterCaseFieldSelectedValueButton().should('be.visible');
      });
    cy.contains('Cancel').click();
  });

  // Regression C227
  // TODO: Needs a rewrite making use of API and convert to POM
  it.skip('C227: Checking the data flow between "Favourited" functionality of the clients filter and "Favourite clients" selection in preference tab', { tags: 'Filters' }, () => {
    // Clicking on Customer Favorites
    cy.visit(urlHelpers.myCustomers);
    cy.getByTestId('customers-addFavorite-addButton').click();
    cy.getByTestId('customers-addFavorite-searchInput').type('a');
    cy.get('#customers-module-add-favorite-item-0').should('be.visible').click();
    cy.get('[class^="NameColumn__Title-sc-"]')
      .eq(0)
      .then(($custName) => {
        const custName = $custName.text();

        cy.visit(urlHelpers.console.home);

        // click on filter icon and click on Quick filter Expand
        cy.getByTestId('layout-header-filter-toggle').should('be.visible').click().invoke('attr', 'data-status').should('include', 'expanded');
        cy.getByTestId('filters-scoreFilters-quickFilterBtn').should('be.visible').click().invoke('attr', 'data-status').should('include', 'expanded');
        // click Customer in Quick filters
        cy.getByTestId('filters-scoreFilters-customers').click();
        cy.getByTestId('filters-scoreFilters-searchOptionFilter-wrapper').should('be.visible').contains('Favorites').click();
        cy.waitForLoaders();
        cy.getByTestId('common-scrollList').then(($btn) => {
          expect($btn.text()).contains(custName);
        });
      });
    // Clicking on Customer Favorites and Remove Favorited Customer
    cy.visit(urlHelpers.myCustomers);
    cy.waitForLoaders();
    customerFavorites.removeFavoriteButton().click();

    // "Favourite clients" selection in preference tab
    cy.visit(urlHelpers.console.home);
    cy.waitForLoaders();
    preferences.userMenuButton().click();
    preferences.userMenuPreferenceButton().click();
    preferences.preferenceFavoriteCustomersTab().click();
    preferences.favoriteCustomerSearchInput().type('a');
    preferences
      .favoriteCustomerSearchResultList()
      .eq(0)
      .then(($custName1) => {
        const custName1 = $custName1.text();
        preferences.favoriteCustomerSearchResultList().eq(0).click();
        preferences.preferencePopupCloseButton().click();
        // click on filter icon and click on Quick filter Expand
        globalFilters.clickFilterToExpand();
        globalFilters.clickQuickFilterToExpand();
        // click Customer in Quick filters
        globalFilters.quickFilterCustomerLink().click();
        globalFilters.quickFilterCustomerFavoritesLink().should('be.visible').contains('Favorites').click();
        cy.waitForLoaders();
        globalFilters.quickFilterFavoritesListItem().then(($btn1) => {
          expect($btn1.text()).contains(custName1);
        });
        // Clicking on Customer Favorites and Remove Favorited Customer
        preferences.removeRecentlyFavoriteCustomersInPreference();
      });
  });
});

describe('Global Filter Welcome Screen', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.console.home);
    cy.slcHelpers.clearCustomersQuickFilter();
    cy.slcHelpers.clearAgentsQuickFilter();
    cy.slcHelpers.clearCaseFieldQuickFilter();
    cy.slcHelpers.deleteGlobalFilter();
  });

  afterEach(() => {
    cy.slcHelpers.clearCustomersQuickFilter();
    cy.slcHelpers.clearAgentsQuickFilter();
    cy.slcHelpers.clearCaseFieldQuickFilter();
    cy.slcHelpers.deleteGlobalFilter();
  });

  /*
   1.  As a new user, Click on the filter button and then select the highlighted text 'create a new filter' text
   2.  Get welcome screen and then can go to create global filter screen
   3.  As an existing user, Click on the filter button and then select the highlighted text 'create a new filter' text
   4.  Goes` straight to create global filter screen`
   */
  it("C659: Checking the functionality of the 'create a new filter' clickable text", { tags: ['Filters', 'staging'] }, () => {
    // changes setting so the welcome screen shows up
    apiHelpers.setToWelcomePageGlobalFilters();

    // Ensure get welcome screen then go to create global filter screen
    cy.visit(urlHelpers.console.home);
    globalFilters.filterButton().click();
    globalFilters.createANewFilterButton().click();
    globalFilters.globalFilterWelcomeScreenLetsGetStartedButton().click();
    globalFilters.globalFilterHeaderText().should('be.visible');
    globalFilters.globalFilterCancelButton().click();
    // Repeat steps and ensure it skips the welcome screen on 2nd time
    globalFilters.filterButton();
    globalFilters.createANewFilterButton().click();
    globalFilters.globalFilterHeaderText().should('be.visible');
    globalFilters.globalFilterCancelButton().click();
  });
});

describe('Filter Button Tests', { tags: '@FilterTests' }, () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.removeAllFavoriteAgents();
    cy.slcHelpers.clearCustomersQuickFilter();
    cy.slcHelpers.clearAgentsQuickFilter();
    cy.slcHelpers.clearCaseFieldQuickFilter();
    cy.slcHelpers.deleteGlobalFilter();

    cy.slcHelpers.getDetailsOfAgentsWithCases().then((agentDetails) => {
      const agentDetail = Cypress._.sample(agentDetails);

      cy.wrap(agentDetail).as('caseDetail');

      cy.visit(urlHelpers.myAgents);
    });
  });

  afterEach(() => {
    apiHelpers.removeAllFavoriteAgents();
    cy.slcHelpers.clearCustomersQuickFilter();
    cy.slcHelpers.clearAgentsQuickFilter();
    cy.slcHelpers.clearCaseFieldQuickFilter();
    cy.slcHelpers.deleteGlobalFilter();
  });

  /*
   1. Add a favorite agent
   2. Create quick filter with favorite agent
   3. Add a global filter
   4.  Verify 'Filter' button has toggled to say 'Custom'
   */
  it('C676: Check how the filter is shown when multiple filter is selected', { tags: ['Filters', 'staging'] }, function favoriteAgentList() {
    agentInsights.agentSearchFieldInput().click().type(this.caseDetail.sl_name);
    agentInsights.agentSearchResultList().first().click();
    agentInsights.removeFavoriteAgentButton().should('be.visible');

    cy.visit(urlHelpers.console.home);

    // add quick filter
    globalFilters.addFavoriteAgentQuickFilter();

    // add global filter
    // TODO Once working - move this to the po file!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    globalFilters.addGlobalFilterCaseAgeLT30Days();
    globalFilters.filterButton().should('be.visible').contains('Custom');
  });
});
