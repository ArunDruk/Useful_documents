import { globalFilters } from '../../../pages/index';
import { urlHelpers } from '../../../utils';

describe('Global Filters Tests', { tags: '@FilterTests' }, () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.slcHelpers.clearCaseFieldQuickFilter();

    cy.visit(urlHelpers.console.home);
  });

  afterEach(() => cy.slcHelpers.clearCaseFieldQuickFilter());

  /*
   1.  Go to Quick Filters -> Case Fields
   2.  Select a few filter options
   3.  Click Reset button and verify they are removed
   */
  it('C9212: Quick Filter- Check the functionality of Filters case field selected state (Reset)', { tags: ['Filters', 'staging'] }, () => {
    globalFilters.clickFilterToExpand();
    globalFilters.clickQuickFilterToExpand();
    // go to globalFilters for Agents
    globalFilters.quickFilterCaseFieldsLink().should('be.visible').click();
    globalFilters.quickFilterCaseFieldsAgeButton().contains('Age').click();
    // select 2 filter values
    globalFilters.quickFilterCaseFieldsAgeLT30DaysButton().click();
    globalFilters.quickFilterCaseFieldsAgeL30To60DaysButton().click();
    // selected number button is shown
    globalFilters.quickFilterCaseFieldsNumberSelectedButton().should('be.visible');
    globalFilters.quickFilterSelectedValuesResetButton().click();
    // selected number button should not be shown after Reset
    globalFilters.quickFilterCaseFieldsNumberSelectedButton().should('not.exist');
  });
});
