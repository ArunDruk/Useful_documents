import { consolePage, globalFilters } from '../../../pages/index';
import { urlHelpers } from '../../../utils';

describe('Global Filters Tests', { tags: '@FilterTests' }, () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.console.home);
    cy.slcHelpers.clearCustomersQuickFilter();
    cy.slcHelpers.clearAgentsQuickFilter();
    cy.slcHelpers.clearCaseFieldQuickFilter();
    cy.slcHelpers.deleteGlobalFilter();
  });

  afterEach(() => {
    cy.slcHelpers.clearCustomersQuickFilter();
    cy.slcHelpers.clearAgentsQuickFilter();
    cy.slcHelpers.clearCaseFieldQuickFilter();
    cy.slcHelpers.deleteGlobalFilter();
  });

  /*
    1.  Click on Filters Button
    2.  Click on Create a New Filter link
    3.  Ensure the 'Selected values will appear here' text is visible
  */
  it('C673: Check the empty state in the Global filter page ', { tags: ['Filters', 'staging'] }, () => {
    globalFilters.goToGlobalFilterCreationPage();
    globalFilters.globalFiltersSelectedValuesWillAppearHereText().should('have.text', 'Selected values will appear here');
  });

  /*
    1.  Create a new global filter
    2.  Ensure  'Global Filter 1' is the default name
    3.  Go to create a 2nd global filter.
    3.  Ensure 'Global Filter 2' is the default name
  */
  it('C660: Check for a new global filter set up there should be a default name and its edit functionality (Create) ', { tags: ['Filters', 'staging'] }, () => {
    // create first filter and ensure name is default
    globalFilters.goToGlobalFilterCreationPage();
    globalFilters.globalFilterName().first().should('have.text', 'Global Filter 1');
    globalFilters.selectAgeLT30DaysInGlobalFilter();
    globalFilters.globalFilterCreateButton().should('be.visible').click();
    globalFilters.globalFilterListPopupCloseButton().click();
    // open screen to create 2nd filter and ensure new default name is shown
    cy.visit(urlHelpers.console.home);
    globalFilters.filterButton().click();
    globalFilters.globalFiltersManageLink().click();
    globalFilters.createANewFilterButtonFromPopupScreen().click();
    globalFilters.globalFilterName().should('have.text', 'Global Filter 2');
  });

  /*
    1.  Go to screen to create Global Filter
    2.  Validate default name and that you can edit the name
  */
  it('C661: Check for a new Global filter set up there should be a default name and its edit functionality (Edit) ', { tags: ['Filters', 'staging'] }, () => {
    // create first filter and ensure name is default
    globalFilters.goToGlobalFilterCreationPage();
    globalFilters.globalFilterName().first().should('have.text', 'Global Filter 1');
    globalFilters.globalFilterName().first().click().clear().type('New Global Filter Name');
  });

  /*
      Go to create a global filter
      See that 'Create a global filter' is disabled
      Enter filter values
      See that 'Create a global filter' is enabled
   */
  it('C663: Check the Global Filter is getting created when there are at least 1 value selected', { tags: ['Filters', 'staging'] }, () => {
    globalFilters.goToGlobalFilterCreationPage();
    globalFilters.globalFilterCreateButton().should('be.disabled');
    // enter values for the filter which will enable the 'Create a new filter' button
    globalFilters.selectAgeLT30DaysInGlobalFilter();
    globalFilters.globalFilterCreateButton().should('be.enabled');
  });

  /*
      Go to create a global filter
      Enter 2 different filter values
      See that filter is created
   */
  it('C664: Check the Global Filter is getting created when there are more than 1 value selected (Multiple)', { tags: ['Filters', 'staging'] }, () => {
    globalFilters.goToGlobalFilterCreationPage();
    globalFilters.globalFilterCreateButton().should('be.disabled');
    // enter 1st value for the filter which will the 'Create a new filter' button
    globalFilters.selectAgeLT30DaysInGlobalFilter();
    // // enter 2nd value for the filter
    globalFilters.globalFilterCaseFieldSelectedValueButton().eq(1).click();
    globalFilters.globalFilterCreateButton().should('be.visible').click();
    // see the new filter on the next screen
    globalFilters.globalFilterCreatedNameText().should('have.text', 'Global Filter 1');
  });

  /*
      Go to create a global filter
      Enter filter values
      Cancel filter creation
      Verify filter was not created
   */
  it('C665: Check whether the ongoing process of creating Global Filter is getting discarded', { tags: ['Filters', 'staging'] }, () => {
    globalFilters.goToGlobalFilterCreationPage();
    // enter values for the filter
    globalFilters.selectAgeLT30DaysInGlobalFilter();
    globalFilters.globalFilterCancelButton().click();
    cy.visit(urlHelpers.console.home);
    // this will fail if there is a created filter
    globalFilters.goToGlobalFilterCreationPage();
  });

  /*
      Go to create a global filter
      Enter filter values
      Reset filter values
      Verify selections are removed
   */
  it('C670: Check the functionality of Filters case field selected state (Reset) ', { tags: ['Filters', 'staging'] }, () => {
    globalFilters.goToGlobalFilterCreationPage();
    globalFilters.globalFilterCreateButton().should('be.disabled');
    // enter 1st value for the filter which will the 'Create a new filter' button
    globalFilters.selectAgeLT30DaysInGlobalFilter();
    // enter 2nd value for the filter
    globalFilters.globalFilterCaseFieldSelectedValueButton().eq(1).click();
    // click Reset button
    globalFilters.globalFilterSelectedValuesResetButton().click();
    // Where the values were shown, now shows default message
    globalFilters.globalFiltersSelectedValuesWillAppearHereText().should('have.text', 'Selected values will appear here');
  });

  /*
  Create 1 global filter
  Create 2nd global filter
  Ensure selected filter name shows in Filter box
  Ensure dashboard was filtered (check pre and post values for New Cases)
   */
  it('C674: Check if user is able to create more than one global filter', { tags: ['Filters', 'staging'] }, () => {
    // TODO - add steps to take count of New Cases
    consolePage.newCasesTab().click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(3000);
    // get before count of New cases
    consolePage
      .newCasesTabHeaderList()
      .eq(0)
      .then((bfrvalue) => {
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(5000);
        const beforevalue = bfrvalue.text();
        // add 2 global filters and apply 1 of them
        globalFilters.addGlobalFilterCaseAgeLT30Days();
        cy.visit(urlHelpers.console.home);
        globalFilters.filterButton().click();
        globalFilters.globalFiltersManageLink().click();
        globalFilters.createANewFilterButtonFromPopupScreen().click();
        globalFilters.selectAgeLT30DaysInGlobalFilter();
        globalFilters.globalFilterCreateButton().should('be.visible').click();
        globalFilters.globalFilterListPopupCloseButton().click();
        globalFilters.filterButton().should('be.visible').contains('Global Filter 1');
        // check after count of new cases against before count
        consolePage.newCasesTab().click();
        consolePage
          .newCasesTabHeaderList()
          .eq(0)
          .then((aftervalue) => {
            expect(aftervalue.text()).not.equal(beforevalue);
          });
      });
  });

  /*
     Create a global filter
     Delete the global filter
     Ensure filter is deleted
  */
  it('C675: Check if the created Global Filter is getting deleted', { tags: ['Filters', 'staging'] }, () => {
    globalFilters.goToGlobalFilterCreationPage();
    globalFilters.globalFilterCreateButton().should('be.disabled');
    globalFilters.selectAgeLT30DaysInGlobalFilter();
    globalFilters.globalFilterCreateButton().should('be.visible').click();
    // see the new filter on the next screen
    globalFilters.globalFilterCreatedNameText().should('have.text', 'Global Filter 1');
    globalFilters.globalFilterCreatedNameText().click();
    // check mouseover text and delete
    globalFilters.globalFilterDeleteButton().should('be.visible').trigger('mouseover');
    globalFilters.globalFilterDeleteButtonMouseoverText().should('be.visible');
    globalFilters.globalFilterDeleteButton().click();
    globalFilters.globalFilterAreYouSurePopupDeletePopup().click();
    globalFilters.globalFilterListPopupCloseButton().click();
    // open screen to create 2nd filter and ensure new default name is shown
    cy.visit(urlHelpers.console.home);
    // this will fail if there are any filters still there (this proves it was deleted)
    globalFilters.goToGlobalFilterCreationPage();
  });
});
