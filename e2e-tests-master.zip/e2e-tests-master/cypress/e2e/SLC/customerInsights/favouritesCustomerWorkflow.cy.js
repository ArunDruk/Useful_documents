import { getOpenCaseDetails } from './support';
import { urlHelpers } from '../../../utils';
import { apiHelpers, customerFavorites, customerInsights } from '../../../pages';

describe('Customer Insights: Favourite customer workflow', () => {
  beforeEach(() => {
    cy.loginByApi();
    getOpenCaseDetails().then((caseDetails) => {
      const caseDetail = Cypress._.sample(caseDetails);

      cy.wrap(caseDetail).as('caseDetail');
      // visit the overview tab of specified customer
      cy.visit(urlHelpers.customerInsights.customerPage(caseDetail.customerId));
      customerInsights.searchTextfield().should('be.visible').and('have.value', caseDetail.customerName);
      customerInsights.insightsTab().click();
    });
  });

  afterEach(() => apiHelpers.removeAllFavoriteCustomers());

  /*
   * Go to customer insight page.
   * Search for any customer name and click enter.
   * Click the insights tab, Valdiate the display of Health score and Insights Tabs.
   * Click on favorite icon and validate that it reflects on the my customers page.
   */
  it('C37856: Verify the workflow of adding favourite customer from Customer insight page', { tags: ['Customers', 'staging'] }, function addingFavoriteCustomer() {
    customerInsights.healthScoreTab().should('be.visible').and('have.text', 'Health Score');
    customerInsights.healthScoreTab().invoke('attr', 'data-active').should('include', 'false');
    customerInsights.insightsTab().should('be.visible').and('have.text', 'Insights');
    customerInsights.insightsTab().invoke('attr', 'data-active').should('include', 'true');
    customerInsights.customerNameLabel().should('be.visible').and('have.text', this.caseDetail.customerName);
    customerInsights.favoriteButton().should('be.visible');
    customerInsights.favoriteButton().invoke('attr', 'data-status').should('include', 'unchecked');
    customerInsights.favoriteButton().click();
    customerInsights.favoriteButton().invoke('attr', 'data-status').should('include', 'checked');
    cy.visit(urlHelpers.myCustomers);
    customerFavorites.favoritesTableCustomerNameLabel().invoke('text').should('be.equal', this.caseDetail.customerName);
  });

  /*
   * Go to customer insight page.
   * Search for any customer name and click enter.
   * Click the insights tab, Valdiate the display of Health score and Insights Tabs.
   * Click on favorite icon and validate that it reflects on the my customers page.
   * Go to customer insight page, search for the same customer.
   * Uncheck favorite icon for that customer and validate that it reflects on the my customers page.
   */
  it('C124864: Verify the workflow of removing favourite customer from Customer insight page', { tags: ['Customers', 'staging'] }, function addingAndRemovingFavoriteCustomer() {
    customerInsights.healthScoreTab().should('be.visible').and('have.text', 'Health Score');
    customerInsights.healthScoreTab().invoke('attr', 'data-active').should('include', 'false');
    customerInsights.insightsTab().should('be.visible').and('have.text', 'Insights');
    customerInsights.insightsTab().invoke('attr', 'data-active').should('include', 'true');
    customerInsights.customerNameLabel().should('be.visible').and('have.text', this.caseDetail.customerName);
    customerInsights.favoriteButton().should('be.visible');
    customerInsights.favoriteButton().invoke('attr', 'data-status').should('include', 'unchecked');
    customerInsights.favoriteButton().click();
    customerInsights.favoriteButton().invoke('attr', 'data-status').should('include', 'checked');
    cy.visit(urlHelpers.myCustomers);
    customerFavorites.favoritesTableCustomerNameLabel().invoke('text').should('be.equal', this.caseDetail.customerName);
    cy.visit(urlHelpers.customerInsights.home);
    customerInsights.searchTextfield().type(this.caseDetail.customerName);
    customerInsights.searchTextfield().should('be.visible').and('have.value', this.caseDetail.customerName);
    customerInsights.searchResultsList().click();
    cy.waitForLoaders();
    customerInsights.insightsTab().click();
    cy.waitForLoaders();
    customerInsights.favoriteButton().invoke('attr', 'data-status').should('include', 'checked');
    customerInsights.favoriteButton().click();
    customerInsights.favoriteButton().invoke('attr', 'data-status').should('include', 'unchecked');
    cy.visit(urlHelpers.myCustomers);
    cy.get('body').should('not.contain', this.caseDetail.customerName);
  });
});
