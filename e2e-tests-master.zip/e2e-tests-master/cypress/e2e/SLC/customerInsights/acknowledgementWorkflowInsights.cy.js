import { getOpenCaseDetails } from './support';
import { urlHelpers } from '../../../utils';
import { consolePage, customerInsights } from '../../../pages';

describe('Customer Insights: Acknowledgement Workflow', () => {
  beforeEach(() => {
    cy.loginByApi();
    getOpenCaseDetails().then((caseDetails) => {
      const caseDetail = Cypress._.sample(caseDetails);

      cy.wrap(caseDetail).as('caseDetail');
      // visit the overview tab of specified customer
      cy.visit(urlHelpers.customerInsights.customerPage(caseDetail.customerId));
      customerInsights.searchTextfield().should('be.visible').and('have.value', caseDetail.customerName);
      customerInsights.insightsTab().click();
      cy.waitForLoaders();
    });
  });

  afterEach(() => {
    consolePage.selectAllSignalsInDropdown();
    consolePage.selectShowAllInDropdown();
    consolePage.groupByElapsedTime();
  });

  /*
   * Go to customer insights page.
   * Search for any customer name and click enter.
   * Click the insights tab, Click on the Need Attention tab, Click the Elasped Time option in the groupedby dropdown.
   * While hovering on cases 'Acknowledge' tick mark is showing. Click the tick mark.
   * Validate that Acknowledged by QA with Cross icon should be displayed.
   * Click the Show Acknowledged option in the dropdown, Click on Cross icon in a feed.
   * Validate that Acknowledged by QA with Cross icon should not be displayed.
   */
  it('C124947: Verify the acknowledgement workflow in  Need attention tab', { tags: ['Customers', 'staging'] }, () => {
    customerInsights.commonTabCard('need_attention').eq(1).click();
    consolePage.selectAllSignalsInDropdown();
    consolePage.selectShowAllInDropdown();
    consolePage.groupByElapsedTime();
    consolePage.expandAllConsoleLists();
    consolePage.consoleTabsShowingHeaderTitle().should('exist');
    consolePage.consoleTabsShowingHeaderTitle().invoke('text').should('contain', `Showing`);
    consolePage.consoleSentimentsTabsHeaderTitle().should('exist');
    consolePage.consoleSentimentsTabsHeaderTitle().invoke('text').should('contain', `Need Attention`);
    cy.waitForLoaders();
    consolePage.acknowledgeDropdown().click({ force: true });
    consolePage.acknowledgeDropdownValueAll().should('be.visible').and('contain', `Show all`);
    consolePage.acknowledgeDropdownValueAck().should('be.visible').and('contain', `Show Acknowledged`);
    consolePage.acknowledgeDropdownValueUnack().should('be.visible').and('contain', `Show Unacknowledged`);
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    consolePage.caseCard().eq(0).scrollIntoView().trigger('mouseover');
    consolePage.sentimentAckButton().eq(0).scrollIntoView().click({ force: true });
    consolePage
      .caseCardHeaderText()
      .invoke('text')
      .should('match', /acknowledged\s*byQA/);
    consolePage.acknowledgeLabelWithCrossIcon().eq(0).scrollIntoView().should('be.visible');
    consolePage.selectShowAcknowledgedInDropdown();
    consolePage.caseCard().eq(0).invoke('text').should('contain', 'acknowledged by');
    consolePage
      .caseCardTicketIdLabel()
      .eq(0)
      .then((caseNo) => {
        const caseID = caseNo.text();

        consolePage.acknowledgeLabelWithCrossIcon().eq(0).scrollIntoView().should('be.visible');
        consolePage.acknowledgeLabelWithCrossIcon().eq(0).trigger('mouseover');
        consolePage.acknowledgeLabelTooltip().invoke('text').should('include', 'Remove acknowledgement');
        consolePage.acknowledgeLabelWithCrossIcon().eq(0).scrollIntoView().click();
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(1000);
        consolePage.selectShowUnacknowledgedInDropdown();
        cy.get('body').should('contain', caseID);
        consolePage.selectShowAcknowledgedInDropdown();
        cy.get('body').should('not.contain', caseID);
      });
  });

  /*
   * Go to customer insights page.
   * Search for any customer name and click enter.
   * Click the insights tab, Click on the Negative sentiment tab, Click the Elasped Time option in the groupedby dropdown.
   * While hovering on cases 'Acknowledge' tick mark is showing. Click the tick mark.
   * Validate that Acknowledged by QA with Cross icon should be displayed.
   * Click the Show Acknowledged option in the dropdown, Click on Cross icon in a feed.
   * Validate that Acknowledged by QA with Cross icon should not be displayed.
   */
  it('C124943: Verify the acknowledgement workflow in Negative Sentiment tab', { tags: ['Customers', 'staging'] }, () => {
    customerInsights.commonTabCard('negative_sentiments').eq(1).click();
    consolePage.selectAllSignalsInDropdown();
    consolePage.selectShowAllInDropdown();
    consolePage.groupByElapsedTime();
    consolePage.expandAllConsoleLists();
    consolePage.consoleTabsShowingHeaderTitle().should('exist');
    consolePage.consoleTabsShowingHeaderTitle().invoke('text').should('contain', `Showing`);
    consolePage.consoleSentimentsTabsHeaderTitle().should('exist');
    consolePage.consoleSentimentsTabsHeaderTitle().invoke('text').should('contain', `Negative Sentiments`);
    cy.waitForLoaders();
    consolePage.acknowledgeDropdown().click({ force: true });
    consolePage.acknowledgeDropdownValueAll().should('be.visible').and('contain', `Show all`);
    consolePage.acknowledgeDropdownValueAck().should('be.visible').and('contain', `Show Acknowledged`);
    consolePage.acknowledgeDropdownValueUnack().should('be.visible').and('contain', `Show Unacknowledged`);
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    consolePage.caseCard().eq(0).scrollIntoView().trigger('mouseover');
    consolePage.sentimentAckButton().eq(0).scrollIntoView().click({ force: true });
    consolePage
      .caseCardHeaderText()
      .invoke('text')
      .should('match', /acknowledged\s*byQA/);
    consolePage.acknowledgeLabelWithCrossIcon().eq(0).scrollIntoView().should('be.visible');
    consolePage.selectShowAcknowledgedInDropdown();
    consolePage.caseCard().eq(0).invoke('text').should('contain', 'acknowledged by');
    consolePage
      .caseCardTicketIdLabel()
      .eq(0)
      .then((caseNo) => {
        const caseID = caseNo.text();

        consolePage.acknowledgeLabelWithCrossIcon().eq(0).scrollIntoView().should('be.visible');
        consolePage.acknowledgeLabelWithCrossIcon().eq(0).trigger('mouseover');
        consolePage.acknowledgeLabelTooltip().invoke('text').should('include', 'Remove acknowledgement');
        consolePage.acknowledgeLabelWithCrossIcon().eq(0).scrollIntoView().click();
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(1000);
        consolePage.selectShowUnacknowledgedInDropdown();
        cy.get('body').should('contain', caseID);
        consolePage.selectShowAcknowledgedInDropdown();
        cy.get('body').should('not.contain', caseID);
      });
  });

  /*
   * Go to customer insights page.
   * Search for any customer name and click enter.
   * Click the insights tab, Click on the Positive sentiment tab, Click the Elasped Time option in the groupedby dropdown.
   * While hovering on cases 'Acknowledge' tick mark is showing. Click the tick mark.
   * Validate that Acknowledged by QA with Cross icon should be displayed.
   * Click the Show Acknowledged option in the dropdown, Click on Cross icon in a feed.
   * Validate that Acknowledged by QA with Cross icon should not be displayed.
   */
  it('C124944: Verify the acknowledgement workflow in Positive Sentiment tab', { tags: ['Customers', 'staging'] }, () => {
    customerInsights.commonTabCard('positive_sentiments').eq(1).click();
    consolePage.selectAllSignalsInDropdown();
    consolePage.selectShowAllInDropdown();
    consolePage.groupByElapsedTime();
    consolePage.expandAllConsoleLists();
    consolePage.consoleTabsShowingHeaderTitle().should('exist');
    consolePage.consoleTabsShowingHeaderTitle().invoke('text').should('contain', `Showing`);
    consolePage.consoleSentimentsTabsHeaderTitle().should('exist');
    consolePage.consoleSentimentsTabsHeaderTitle().invoke('text').should('contain', `Positive Sentiments`);
    cy.waitForLoaders();
    consolePage.acknowledgeDropdown().click({ force: true });
    consolePage.acknowledgeDropdownValueAll().should('be.visible').and('contain', `Show all`);
    consolePage.acknowledgeDropdownValueAck().should('be.visible').and('contain', `Show Acknowledged`);
    consolePage.acknowledgeDropdownValueUnack().should('be.visible').and('contain', `Show Unacknowledged`);
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    consolePage.caseCard().eq(0).scrollIntoView().trigger('mouseover');
    consolePage.sentimentAckButton().eq(0).scrollIntoView().click({ force: true });
    consolePage
      .caseCardHeaderText()
      .invoke('text')
      .should('match', /acknowledged\s*byQA/);
    consolePage.acknowledgeLabelWithCrossIcon().eq(0).scrollIntoView().should('be.visible');
    consolePage.selectShowAcknowledgedInDropdown();
    consolePage.caseCard().eq(0).invoke('text').should('contain', 'acknowledged by');
    consolePage
      .caseCardTicketIdLabel()
      .eq(0)
      .then((caseNo) => {
        const caseID = caseNo.text();

        consolePage.acknowledgeLabelWithCrossIcon().eq(0).scrollIntoView().should('be.visible');
        consolePage.acknowledgeLabelWithCrossIcon().eq(0).trigger('mouseover');
        consolePage.acknowledgeLabelTooltip().invoke('text').should('include', 'Remove acknowledgement');
        consolePage.acknowledgeLabelWithCrossIcon().eq(0).scrollIntoView().click();
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(1000);
        consolePage.selectShowUnacknowledgedInDropdown();
        cy.get('body').should('contain', caseID);
        consolePage.selectShowAcknowledgedInDropdown();
        cy.get('body').should('not.contain', caseID);
      });
  });

  /*
   * Go to customer insights page.
   * Search for any customer name and click enter.
   * Click the insights tab, Click on the Product Feedback tab, Click the Elasped Time option in the groupedby dropdown.
   * While hovering on cases 'Acknowledge' tick mark is showing. Click the tick mark.
   * Validate that Acknowledged by QA with Cross icon should be displayed.
   * Click the Show Acknowledged option in the dropdown, Click on Cross icon in a feed.
   * Validate that Acknowledged by QA with Cross icon should not be displayed.
   */
  it('C124945: Verify the acknowledgement workflow in Product Feedback tab', { tags: ['Customers', 'staging'] }, () => {
    customerInsights.commonTabCard('product_feedback').eq(1).click();
    consolePage.selectAllSignalsInDropdown();
    consolePage.selectShowAllInDropdown();
    consolePage.groupByElapsedTime();
    consolePage.expandAllConsoleLists();
    consolePage.consoleTabsShowingHeaderTitle().should('exist');
    consolePage.consoleTabsShowingHeaderTitle().invoke('text').should('contain', `Showing`);
    consolePage.consoleSentimentsTabsHeaderTitle().should('exist');
    consolePage.consoleSentimentsTabsHeaderTitle().invoke('text').should('contain', `Product Feedback`);
    cy.waitForLoaders();
    consolePage.acknowledgeDropdown().click({ force: true });
    consolePage.acknowledgeDropdownValueAll().should('be.visible').and('contain', `Show all`);
    consolePage.acknowledgeDropdownValueAck().should('be.visible').and('contain', `Show Acknowledged`);
    consolePage.acknowledgeDropdownValueUnack().should('be.visible').and('contain', `Show Unacknowledged`);
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    consolePage.caseCard().eq(0).scrollIntoView().trigger('mouseover');
    consolePage.sentimentAckButton().eq(0).scrollIntoView().click({ force: true });
    consolePage
      .caseCardHeaderText()
      .invoke('text')
      .should('match', /acknowledged\s*byQA/);
    consolePage.acknowledgeLabelWithCrossIcon().eq(0).scrollIntoView().should('be.visible');
    consolePage.selectShowAcknowledgedInDropdown();
    consolePage.caseCard().eq(0).invoke('text').should('contain', 'acknowledged by');
    consolePage
      .caseCardTicketIdLabel()
      .eq(0)
      .then((caseNo) => {
        const caseID = caseNo.text();
        consolePage.acknowledgeLabelWithCrossIcon().eq(0).scrollIntoView().should('be.visible');
        consolePage.acknowledgeLabelWithCrossIcon().eq(0).trigger('mouseover');
        consolePage.acknowledgeLabelTooltip().invoke('text').should('include', 'Remove acknowledgement');
        consolePage.acknowledgeLabelWithCrossIcon().eq(0).scrollIntoView().click();
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(1000);
        consolePage.selectShowUnacknowledgedInDropdown();
        cy.get('body').should('contain', caseID);
        consolePage.selectShowAcknowledgedInDropdown();
        cy.get('body').should('not.contain', caseID);
      });
  });
});
