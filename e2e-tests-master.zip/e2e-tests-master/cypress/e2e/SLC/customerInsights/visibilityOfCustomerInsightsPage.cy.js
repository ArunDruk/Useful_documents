import { getOpenCaseDetails } from './support';
import { urlHelpers } from '../../../utils';
import { alertsPage, apiHelpers, consolePage, customerInsights, healthScore } from '../../../pages';

describe('Customer Insights: visibility of customer insight page', () => {
  beforeEach(() => {
    cy.loginByApi();
    getOpenCaseDetails().then((caseDetails) => {
      const caseDetail = Cypress._.sample(caseDetails);

      cy.wrap(caseDetail).as('caseDetail');
      cy.visit(urlHelpers.customerInsights.customerPage(caseDetail.customerId));
      customerInsights.searchTextfield().should('be.visible').and('have.value', caseDetail.customerName);
      customerInsights.insightsTab().click();
    });
  });

  afterEach(() => apiHelpers.removeAllFavoriteCustomers());

  /*
   * Go to customer insight page.
   * Search for any customer name and click enter.
   * Click the insights tab, Valdiate the display of Health score and Insights Tabs.
   * Click on favorite icon and validate that it reflects on the my customers page
   */
  it('C37857: Verify that display of Customer insight page ', { tags: ['Customers', 'staging', 'prod'] }, function customerInsightPageDisplay() {
    const expectedTooltipText = `Agents interacting with this customer will see the notes added here. For example, you can add a note saying “this customer has started a POC with us.”New notes will be sent to agents as real-time alerts.`;

    customerInsights.healthScoreTab().should('be.visible').and('have.text', 'Health Score');
    customerInsights.healthScoreTab().invoke('attr', 'data-active').should('include', 'false');
    customerInsights.insightsTab().should('be.visible').and('have.text', 'Insights');
    customerInsights.insightsTab().invoke('attr', 'data-active').should('include', 'true');
    customerInsights.customerNameLabel().should('be.visible').and('have.text', this.caseDetail.customerName);
    healthScore.healthScoreBadgeIcon().first().should('be.visible').trigger('mouseover');
    consolePage.consoleTabsHeaderTitleTooltip().should('have.text', 'Health Score');
    healthScore.healthScoreBadgeIcon().first().should('be.visible').trigger('mouseout');
    customerInsights.favoriteButton().should('be.visible');
    customerInsights.shareButton().should('be.visible').trigger('mouseover');
    consolePage.consoleTabsHeaderTitleTooltip().should('have.text', 'Share');
    customerInsights.shareButton().should('be.visible').trigger('mouseout');
    customerInsights.customerNotesTextarea().should('be.visible');
    customerInsights.customerNotesHintPopOver().should('be.visible').trigger('mouseover');
    alertsPage.mouseHoverTooltip().invoke('text').should('contain', expectedTooltipText);
  });
});
