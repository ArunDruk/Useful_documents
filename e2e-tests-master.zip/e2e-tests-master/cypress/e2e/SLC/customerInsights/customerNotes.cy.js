import { getOpenCaseDetails } from './support';
import { randId, urlHelpers } from '../../../utils';
import { apiHelpers, customerInsights, supportHub } from '../../../pages';

describe('Customer Insights: Customer Notes', () => {
  beforeEach(() => {
    cy.intercept('POST', 'api/customer-notes').as('postCustomerNote');

    cy.loginByApi();
    // Note: If fetched customer id is not valid/active, the tests will fail
    getOpenCaseDetails().then((caseDetails) => {
      const caseDetail = Cypress._.sample(caseDetails);

      cy.wrap(caseDetail).as('caseDetail');

      cy.visit(urlHelpers.customerInsights.customerPage(caseDetail.customerId));
      customerInsights.searchTextfield().should('be.visible').and('have.value', caseDetail.customerName);

      customerInsights.insightsTab().click();
    });
  });

  it('C457: should add customer notes', { tags: 'Customer' }, function insightsCustomerNotes() {
    const noteText = `Test customer notes ${randId()}`;

    customerInsights.customerNotesTextarea().type(noteText);
    customerInsights.customerNotesAddButton().click();

    cy.wait('@postCustomerNote').then(({ response }) => {
      const noteId = response.body.note.id;

      cy.visit(urlHelpers.supportHubCasePage(this.caseDetail.caseId));
      supportHub.customerNotesTriggerButton().click();

      supportHub.customerNotesNoteText(noteId).should('have.text', noteText);
      apiHelpers.deleteCustomerNote(noteId);
    });
  });
});
