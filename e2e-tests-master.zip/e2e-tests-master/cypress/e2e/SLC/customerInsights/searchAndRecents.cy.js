import { getOpenCaseDetails } from './support';
import { urlHelpers } from '../../../utils';
import { apiHelpers, customerInsights } from '../../../pages';

describe('Customer Insights: Search', () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.clearRecentlyVisitedCustomerInsight();
    // Note: If fetched customer id is not valid/active, the tests will fail
    getOpenCaseDetails().then((caseDetails) => {
      const caseDetail = Cypress._.sample(caseDetails);

      cy.wrap(caseDetail).as('caseDetail');

      cy.visit(urlHelpers.customerInsights.home);
      customerInsights.searchTextfield().should('be.visible').and('have.value', '');
    });
  });

  it('C460: should search for a customer', { tags: 'Customer' }, function searchCustomer() {
    // search for a customer
    customerInsights.searchFor(this.caseDetail.customerName);
    // verify customer name is displayed as a suggestion & click on it
    customerInsights.searchResultsList().should('be.visible').and('have.length.at.least', 1).first().should('have.text', this.caseDetail.customerName).click({ force: true });
    customerInsights.insightsTab().click();

    // verify star button is displayed
    customerInsights.favoriteButton().should('be.visible');
    // verify searched customer name is displayed
    customerInsights.customerNameLabel().should('be.visible').and('have.text', this.caseDetail.customerName);
    // verify at least 1 tab is visible
    customerInsights.allTabs().should('be.visible').and('have.length.at.least', 1);
    cy.scrollTo('bottom', { ensureScrollable: false });
    // verify add customer notes feature is visible
    customerInsights.customerNotesTextarea().should('be.visible');
  });

  it('C461: should show recently searched items', { tags: 'Customer' }, function recentSearches() {
    // search for a customer
    customerInsights.searchFor(this.caseDetail.customerName);

    // verify customer name is displayed as a suggestion & click on it
    customerInsights.searchResultsList().should('be.visible').and('have.length.at.least', 1).first().should('have.text', this.caseDetail.customerName).click({ force: true });
    cy.waitForLoaders();
    // clear search by re-visiting insights page
    cy.visit(urlHelpers.customerInsights.home);
    cy.waitForLoaders();
    // verify at least 1 recent search history is visible
    // and matches the last searched customer name
    customerInsights.recentlyVisitedItem().should('be.visible').and('have.lengthOf.at.least', 1).and('include.text', this.caseDetail.customerName);
  });
});
