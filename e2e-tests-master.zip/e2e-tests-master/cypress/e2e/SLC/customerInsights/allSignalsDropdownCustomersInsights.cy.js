import { getOpenCaseDetails } from './support';
import { urlHelpers } from '../../../utils';
import { consolePage, customerInsights } from '../../../pages';

describe('Customer Insights: All Signals Dropdown workflow', () => {
  beforeEach(() => {
    cy.loginByApi();
    getOpenCaseDetails().then((caseDetails) => {
      const caseDetail = Cypress._.sample(caseDetails);

      cy.wrap(caseDetail).as('caseDetail');
      // visit the overview tab of specified customer
      cy.visit(urlHelpers.customerInsights.customerPage(caseDetail.customerId));
      customerInsights.searchTextfield().should('be.visible').and('have.value', caseDetail.customerName);
      customerInsights.insightsTab().click();
    });
  });

  afterEach(() => {
    consolePage.selectAllSignalsInDropdown();
    consolePage.groupByElapsedTime();
  });

  /*
   * Go to customers insights page, Search any customer name.
   * Navigate to the Need Attention tab and verify we have landed in expected tab
   * Verify the Sentiment Signal dropdown text is All Signal if not select All in the Dropdown value
   * Click on Select All Signals and veirfy the data-status is unchecked
   * Select only one signal value and verify the case card with selected signal alone is displaying
   * After verify Select All Signals in the Sentiment Signal dropdown
   */
  it('C124856: Customer Insights - Need Attention tabs - Sentiment Signal filter', { tags: ['Customers', 'staging'] }, () => {
    customerInsights.commonTabCard('need_attention').eq(1).click();
    consolePage.selectAllSignalsInDropdown();
    consolePage.selectShowAllInDropdown();
    consolePage.groupByElapsedTime();
    consolePage.expandAllConsoleLists();
    consolePage.consoleTabsShowingHeaderTitle().should('be.exist');
    consolePage.consoleTabsShowingHeaderTitle().invoke('text').should('contain', `Showing`);
    consolePage.consoleSentimentsTabsHeaderTitle().should('be.exist');
    consolePage.consoleSentimentsTabsHeaderTitle().invoke('text').should('contain', `Need Attention`);
    consolePage.sentimentsTabsSignalsDropdown().click();
    consolePage.signalsDropdownSentimentSignalHeader().invoke('text').should('contain', `Sentiment Signal`);
    consolePage.signalsDropdownSentimentSignalCheckbox().invoke('attr', 'data-status').should('eq', 'checked');
    cy.waitForLoaders();
    consolePage
      .sentimentSignalsdropdown()
      .should('be.visible')
      .then(($value) => {
        const signalValue = $value.text();
        consolePage.sentimentSignalsdropdown().click();
        if (signalValue !== 'All Signals') {
          consolePage.sentimentSignalsAllCheckBox().click({ force: true }).invoke('attr', 'data-status').should('equal', 'checked');
        }
        consolePage.sentimentSignalsAllCheckBox().click({ force: true }).invoke('attr', 'data-status').should('equal', 'unchecked');
        consolePage.sentimentSignalsdropdown().click();
        consolePage
          .sentimentSignalsIndividualNameLabel()
          .eq(0)
          .should('be.visible')
          .then(($name) => {
            const signalName = $name.text();
            consolePage.sentimentSignalsIndividualCheckbox(signalName).eq(0).invoke('attr', 'data-status').should('equal', 'unchecked');
            consolePage.sentimentSignalsIndividualCheckbox(signalName).eq(0).click({ force: true }).invoke('attr', 'data-status').should('equal', 'checked');
            cy.waitForLoaders();
            consolePage.sentimentSignalsdropdown().click();
            consolePage.sentimentSignalsdropdown().invoke('text').should('contain', signalName);
            consolePage.caseCardDetectedSentimentLabel().should('contain', signalName);
          });
      });
  });

  /*
   * Go to customers insights page, Search any customer name.
   * Navigate to the Negative Sentiment tab and verify we have landed in expected tab
   * Verify the Sentiment Signal dropdown text is All Signal if not select All in the Dropdown value
   * Click on Select All Signals and veirfy the data-status is unchecked
   * Select only one signal value and verify the case card with selected signal alone is displaying
   * After verify Select All Signals in the Sentiment Signal dropdown
   */
  it('C124857: Customer Insights - Negative Sentiment Tab - Sentiment Signal filter', { tags: ['Customers', 'staging'] }, () => {
    customerInsights.commonTabCard('negative_sentiments').eq(1).click();
    consolePage.selectAllSignalsInDropdown();
    consolePage.selectShowAllInDropdown();
    consolePage.groupByElapsedTime();
    consolePage.expandAllConsoleLists();
    consolePage.consoleTabsShowingHeaderTitle().should('be.exist');
    consolePage.consoleTabsShowingHeaderTitle().invoke('text').should('contain', `Showing`);
    consolePage.consoleSentimentsTabsHeaderTitle().should('be.exist');
    consolePage.consoleSentimentsTabsHeaderTitle().invoke('text').should('contain', `Negative Sentiments`);
    consolePage.sentimentsTabsSignalsDropdown().click();
    consolePage.signalsDropdownSentimentSignalHeader().invoke('text').should('contain', `Sentiment Signal`);
    consolePage.signalsDropdownSentimentSignalCheckbox().invoke('attr', 'data-status').should('eq', 'checked');
    cy.waitForLoaders();
    consolePage
      .sentimentSignalsdropdown()
      .should('be.visible')
      .then(($value) => {
        const signalValue = $value.text();
        consolePage.sentimentSignalsdropdown().click();
        if (signalValue !== 'All Signals') {
          consolePage.sentimentSignalsAllCheckBox().click({ force: true }).invoke('attr', 'data-status').should('equal', 'checked');
        }
        consolePage.sentimentSignalsAllCheckBox().click({ force: true }).invoke('attr', 'data-status').should('equal', 'unchecked');
        consolePage.sentimentSignalsdropdown().click();
        consolePage
          .sentimentSignalsIndividualNameLabel()
          .eq(0)
          .should('be.visible')
          .then(($name) => {
            const signalName = $name.text();
            consolePage.sentimentSignalsIndividualCheckbox(signalName).eq(0).invoke('attr', 'data-status').should('equal', 'unchecked');
            consolePage.sentimentSignalsIndividualCheckbox(signalName).eq(0).click({ force: true }).invoke('attr', 'data-status').should('equal', 'checked');
            cy.waitForLoaders();
            consolePage.sentimentSignalsdropdown().click();
            consolePage.sentimentSignalsdropdown().invoke('text').should('contain', signalName);
            consolePage.caseCardDetectedSentimentLabel().should('contain', signalName);
          });
      });
  });

  /*
   * Go to customers insights page, Search any customer name.
   * Navigate to the Positive Sentiment tab and verify we have landed in expected tab
   * Verify the Sentiment Signal dropdown text is All Signal if not select All in the Dropdown value
   * Click on Select All Signals and veirfy the data-status is unchecked
   * Select only one signal value and verify the case card with selected signal alone is displaying
   * After verify Select All Signals in the Sentiment Signal dropdown
   */
  it('C124862: Console - Positive Sentiment Tab - Sentiment Signal filter', { tags: ['Customers', 'staging'] }, () => {
    customerInsights.commonTabCard('positive_sentiments').eq(1).click();
    consolePage.selectAllSignalsInDropdown();
    consolePage.selectShowAllInDropdown();
    consolePage.groupByElapsedTime();
    consolePage.expandAllConsoleLists();
    consolePage.consoleTabsShowingHeaderTitle().should('be.exist');
    consolePage.consoleTabsShowingHeaderTitle().invoke('text').should('contain', `Showing`);
    consolePage.consoleSentimentsTabsHeaderTitle().should('be.exist');
    consolePage.consoleSentimentsTabsHeaderTitle().invoke('text').should('contain', `Positive Sentiments`);
    consolePage.sentimentsTabsSignalsDropdown().click();
    consolePage.signalsDropdownSentimentSignalHeader().invoke('text').should('contain', `Sentiment Signal`);
    consolePage.signalsDropdownSentimentSignalCheckbox().invoke('attr', 'data-status').should('eq', 'checked');
    cy.waitForLoaders();
    consolePage
      .sentimentSignalsdropdown()
      .should('be.visible')
      .then(($value) => {
        const signalValue = $value.text();
        consolePage.sentimentSignalsdropdown().click();
        if (signalValue !== 'All Signals') {
          consolePage.sentimentSignalsAllCheckBox().click({ force: true }).invoke('attr', 'data-status').should('equal', 'checked');
        }
        consolePage.sentimentSignalsAllCheckBox().click({ force: true }).invoke('attr', 'data-status').should('equal', 'unchecked');
        consolePage.sentimentSignalsdropdown().click();
        consolePage
          .sentimentSignalsIndividualNameLabel()
          .eq(0)
          .should('be.visible')
          .then(($name) => {
            const signalName = $name.text();
            consolePage.sentimentSignalsIndividualCheckbox(signalName).eq(0).invoke('attr', 'data-status').should('equal', 'unchecked');
            consolePage.sentimentSignalsIndividualCheckbox(signalName).eq(0).click({ force: true }).invoke('attr', 'data-status').should('equal', 'checked');
            cy.waitForLoaders();
            consolePage.sentimentSignalsdropdown().click();
            consolePage.sentimentSignalsdropdown().invoke('text').should('contain', signalName);
            consolePage.caseCardDetectedSentimentLabel().should('contain', signalName);
          });
      });
  });

  /*
   * Go to customers insights page, Search any customer name.
   * Navigate to the Product Feedback tab and verify we have landed in expected tab
   * Verify the Sentiment Signal dropdown text is All Signal if not select All in the Dropdown value
   * Click on Select All Signals and veirfy the data-status is unchecked
   * Select only one signal value and verify the case card with selected signal alone is displaying
   * After verify Select All Signals in the Sentiment Signal dropdown
   */
  it('C124863: Console - Product Feedback tabs - Sentiment Signal filter', { tags: ['Customers', 'staging', 'prod'] }, () => {
    customerInsights.commonTabCard('product_feedback').eq(1).click();
    consolePage.selectAllSignalsInDropdown();
    consolePage.selectShowAllInDropdown();
    consolePage.groupByElapsedTime();
    consolePage.expandAllConsoleLists();
    consolePage.consoleTabsShowingHeaderTitle().should('be.exist');
    consolePage.consoleTabsShowingHeaderTitle().invoke('text').should('contain', `Showing`);
    consolePage.consoleSentimentsTabsHeaderTitle().should('be.exist');
    consolePage.consoleSentimentsTabsHeaderTitle().invoke('text').should('contain', `Product Feedback`.trim());
    consolePage.sentimentsTabsSignalsDropdown().click();
    consolePage.signalsDropdownSentimentSignalHeader().invoke('text').should('contain', `Sentiment Signal`);
    consolePage.signalsDropdownSentimentSignalCheckbox().invoke('attr', 'data-status').should('eq', 'checked');
    cy.waitForLoaders();
    consolePage
      .sentimentSignalsdropdown()
      .should('be.visible')
      .then(($value) => {
        const signalValue = $value.text();
        consolePage.sentimentSignalsdropdown().click();
        if (signalValue !== 'All Signals') {
          consolePage.sentimentSignalsAllCheckBox().click({ force: true }).invoke('attr', 'data-status').should('equal', 'checked');
        }
        consolePage.sentimentSignalsAllCheckBox().click({ force: true }).invoke('attr', 'data-status').should('equal', 'unchecked');
        cy.waitForLoaders();
        consolePage.sentimentSignalsdropdown().click();
        consolePage
          .sentimentSignalsIndividualNameLabel()
          .eq(0)
          .should('be.visible')
          .then(($name) => {
            const signalName = $name.text();
            consolePage.sentimentSignalsIndividualCheckbox(signalName).eq(0).invoke('attr', 'data-status').should('equal', 'unchecked');
            consolePage.sentimentSignalsIndividualCheckbox(signalName).eq(0).click({ force: true }).invoke('attr', 'data-status').should('equal', 'checked');
            consolePage.sentimentSignalsdropdown().click();
            consolePage.sentimentSignalsdropdown().invoke('text').should('contain', 'All Signals');
            consolePage.caseCardDetectedSentimentLabel().should('contain', signalName);
          });
      });
  });
});
