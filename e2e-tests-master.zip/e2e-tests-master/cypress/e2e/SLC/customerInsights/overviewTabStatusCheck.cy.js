import { urlHelpers } from '../../../utils';
import { customerInsights, supportHub } from '../../../pages';

describe('Customer Insights - Case Status (Overview Tab)', () => {
  beforeEach(() => {
    cy.intercept('POST', 'api/cache/qa-automation/tickets/sortByWithData').as('sortBy');

    cy.loginByApi();
    cy.slcHelpers.getCustomerDetails().then((customerDetails) => {
      const customerDetail = Cypress._.sample(customerDetails);

      cy.visit(urlHelpers.customerInsights.customerPageTabs(customerDetail.native_id, 'tickets'));
      customerInsights.searchTextfield().should('be.visible').and('have.value', customerDetail.name);
      customerInsights.insightsTab().click();
    });
  });

  /*
   * Go to Customer Insights Page, Search search for any customer account.
   * Click the 'Open' tab in recent cases section
   * Open any ticket in the open tab.
   * Validate that case field status is not 'Closed'.
   */
  it('C124865: Verify the status in overview-open cases tab', { tags: ['Customer Insights', 'staging'] }, () => {
    customerInsights.overviewTabOpenTab().click();
    cy.waitForLoaders();
    customerInsights.overviewTabCaseListItem().first().click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
    supportHub.caseFieldStatusLabel().invoke('text').should('not.equal', 'Closed');
    supportHub.closeButton().click();
  });

  /*
   * Go to Customer Insights Page, Search search for any customer account.
   * Click the 'Open' tab in recent cases section
   * Open any ticket in the open tab.
   * Validate that case field status is 'Closed'.
   */
  it('C124866: Verify the status in overview-Recently closed cases tab', { tags: ['Customer Insights', 'staging'] }, () => {
    customerInsights.overviewTabRecentlyClosedTab().click();
    cy.waitForLoaders();
    customerInsights.overviewTabCaseListItem().first().click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
    supportHub.caseFieldStatusLabel().invoke('text').should('equal', 'Closed');
    supportHub.closeButton().click();
  });
});
