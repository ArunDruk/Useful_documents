import { urlHelpers } from '../../../utils';
import { consolePage, customerInsights, supportHub } from '../../../pages';

describe('Customer Insights: Visibility of the LTE tab', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.console.withTimeFilter.lastSevenDays);
    cy.slcHelpers.clearCustomersQuickFilter();
    cy.slcHelpers.clearAgentsQuickFilter();
    cy.slcHelpers.clearCaseFieldQuickFilter();
    cy.slcHelpers.deleteGlobalFilter();
  });

  /*
   * Go to console page, Click LTE tab.
   * Get any customer name in the list.
   * Go to customer insights page.
   * Search for that customer name and click enter.
   * Click the insights tab, Click on the LTE tab.
   * Validate the display of LTE header title , Open any SH and check 'Likely to Escalate' status label is displayed.
   */
  it('C37820: Verify the display of LTE tab', { tags: ['Customers', 'staging'] }, () => {
    consolePage.lteTab().click({ force: true });
    consolePage.consoleEscalatedTabHeaderTitle().should('be.exist');
    // Update the title to 'Likely To Escalate' in future tracking via -SLC-34629
    consolePage.consoleEscalatedTabHeaderTitle().invoke('text').should('contain', `Escalations`);
    consolePage.groupByPriorityOption();
    cy.waitForLoaders();
    consolePage
      .caseCardCustomerName()
      .eq(0)
      .then((labelText) => {
        const customerName = labelText.text();
        cy.visit(urlHelpers.customerInsights.home);
        customerInsights.searchTextfield().type(customerName);
        customerInsights.searchTextfield().should('be.visible').and('have.value', customerName);
        customerInsights.searchResultsList().click();
        cy.waitForLoaders();
        customerInsights.insightsTab().click();
        cy.waitForLoaders();
        customerInsights.commonTabCard('Likely_to_Escalate').eq(1).click();
        cy.waitForLoaders();
        consolePage.consoleEscalatedTabHeaderTitle().should('be.exist');
        // Update the title to 'Likely To Escalate' in future tracking via -SLC-34629
        consolePage.consoleEscalatedTabHeaderTitle().invoke('text').should('contain', `Escalations`);
        consolePage.escalationCaseCard().eq(0).click();
        cy.waitForLoaders();
        supportHub.baseContainer().should('be.visible');
        cy.waitForLoaders();
        supportHub.supportHubLteLabel().invoke('text').should('contain', `Likely to Escalate`);
        supportHub.closeButton().click();
      });
  });
});
