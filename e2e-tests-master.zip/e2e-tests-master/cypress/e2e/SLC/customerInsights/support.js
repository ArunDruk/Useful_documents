const predicates = [
  { column: 'sl_is_closed', op: '=', value: 'false' },
  { column: 'sl_account_id', op: '<>', value: 'null' },
  { column: 'sl_requester_id', op: '<>', value: 'null' },
];

export const getOpenCaseDetails = () =>
  cy.slcHelpers
    .getCaseDetails({ predicates })
    // eslint-disable-next-line camelcase
    .then(({ body }) => body.map(({ id, sl_account_id, sl_account_name }) => ({ caseId: id, customerId: sl_account_id, customerName: sl_account_name })));
