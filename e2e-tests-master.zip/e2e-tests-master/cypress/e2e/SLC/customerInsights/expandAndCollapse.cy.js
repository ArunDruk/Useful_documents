import { getOpenCaseDetails } from './support';
import { urlHelpers } from '../../../utils';
import { consolePage, customerInsights } from '../../../pages';

describe('Customer Insights: Expand All Collapse All Functionality Check', () => {
  beforeEach(() => {
    cy.loginByApi();
    getOpenCaseDetails().then((caseDetails) => {
      const caseDetail = Cypress._.sample(caseDetails);

      cy.wrap(caseDetail).as('caseDetail');
      cy.visit(urlHelpers.customerInsights.customerPage(caseDetail.customerId));
      customerInsights.searchTextfield().should('be.visible').and('have.value', caseDetail.customerName);
      customerInsights.insightsTab().click();
    });
  });

  /*
   * Go to customers insights page, Search any customer name.
   * Navigate to the Need Attention tab and verify we have landed in expected tab
   * Verify the Sentiment Signal dropdown text is All Signal if not select All in the Dropdown value
   * Select 'Elasped Time' in thed dropdown, Click 'Collapse all' button and validate case card is not exist.
   * Click 'Expand all' button and validate case card is exist.
   */
  it('C127057: Customer Insights - Need Attention tab - Expand all <-> Collapse all Functionality Check', { tags: ['Customers', 'staging'] }, function needAttentionExpandAll() {
    customerInsights.healthScoreTab().should('be.visible').and('have.text', 'Health Score');
    customerInsights.insightsTab().should('be.visible').and('have.text', 'Insights');
    customerInsights.customerNameLabel().should('be.visible').and('have.text', this.caseDetail.customerName);
    customerInsights.favoriteButton().should('be.visible');
    customerInsights.commonTabCard('need_attention').eq(1).click();
    consolePage.selectAllSignalsInDropdown();
    consolePage.selectShowAllInDropdown();
    consolePage.groupByElapsedTime();
    consolePage.expandAllConsoleLists();
    cy.waitForLoaders();
    consolePage.collapseExpandButton().should('be.visible').and('have.text', 'Collapse All');
    consolePage.caseCard().should('be.visible');
    consolePage.caseListCustomerName().should('be.visible');
    consolePage.collapseExpandButton().click();
    cy.waitForLoaders();
    consolePage.collapseExpandButton().should('be.visible').and('have.text', 'Expand All');
    consolePage.caseCard().should('not.exist');
    consolePage.caseListCustomerName().should('not.exist');
  });

  /*
   * Go to customers insights page, Search any customer name.
   * Navigate to the Negative Sentiment tab and verify we have landed in expected tab
   * Verify the Sentiment Signal dropdown text is All Signal if not select All in the Dropdown value
   * Select 'Elasped Time' in thed dropdown, Click 'Collapse all' button and validate case card is not exist.
   * Click 'Expand all' button and validate case card is exist.
   */
  it(
    'C127058: Customer Insights - Negative Sentiment tab - Expand all <-> Collapse all Functionality Check',
    { tags: ['Customers', 'staging'] },
    function negativeSentimentExpandAll() {
      customerInsights.healthScoreTab().should('be.visible').and('have.text', 'Health Score');
      customerInsights.insightsTab().should('be.visible').and('have.text', 'Insights');
      customerInsights.customerNameLabel().should('be.visible').and('have.text', this.caseDetail.customerName);
      customerInsights.favoriteButton().should('be.visible');
      customerInsights.commonTabCard('need_attention').eq(1).click();
      consolePage.selectAllSignalsInDropdown();
      consolePage.selectShowAllInDropdown();
      consolePage.groupByElapsedTime();
      consolePage.expandAllConsoleLists();
      cy.waitForLoaders();
      consolePage.collapseExpandButton().should('be.visible').and('have.text', 'Collapse All');
      consolePage.caseCard().should('be.visible');
      consolePage.caseListCustomerName().should('be.visible');
      consolePage.collapseExpandButton().click();
      cy.waitForLoaders();
      consolePage.collapseExpandButton().should('be.visible').and('have.text', 'Expand All');
      consolePage.caseCard().should('not.exist');
      consolePage.caseListCustomerName().should('not.exist');
    }
  );

  /*
   * Go to customers insights page, Search any customer name.
   * Navigate to the Positive Sentiment tab and verify we have landed in expected tab
   * Verify the Sentiment Signal dropdown text is All Signal if not select All in the Dropdown value
   * Select 'Elasped Time' in thed dropdown, Click 'Collapse all' button and validate case card is not exist.
   * Click 'Expand all' button and validate case card is exist.
   */
  it(
    'C127059: Customer Insights - Positive Sentiment tabs - Expand all <-> Collapse all Functionality Check',
    { tags: ['Customers', 'staging'] },
    function positiveSentimentExpandAll() {
      customerInsights.healthScoreTab().should('be.visible').and('have.text', 'Health Score');
      customerInsights.insightsTab().should('be.visible').and('have.text', 'Insights');
      customerInsights.customerNameLabel().should('be.visible').and('have.text', this.caseDetail.customerName);
      customerInsights.favoriteButton().should('be.visible');
      customerInsights.commonTabCard('need_attention').eq(1).click();
      consolePage.selectAllSignalsInDropdown();
      consolePage.selectShowAllInDropdown();
      consolePage.groupByElapsedTime();
      consolePage.expandAllConsoleLists();
      cy.waitForLoaders();
      consolePage.collapseExpandButton().should('be.visible').and('have.text', 'Collapse All');
      consolePage.caseCard().should('be.visible');
      consolePage.caseListCustomerName().should('be.visible');
      consolePage.collapseExpandButton().click();
      cy.waitForLoaders();
      consolePage.collapseExpandButton().should('be.visible').and('have.text', 'Expand All');
      consolePage.caseCard().should('not.exist');
      consolePage.caseListCustomerName().should('not.exist');
    }
  );

  /*
   * Go to customers insights page, Search any customer name.
   * Navigate to the Product Feedback tab and verify we have landed in expected tab
   * Verify the Sentiment Signal dropdown text is All Signal if not select All in the Dropdown value
   * Select 'Elasped Time' in thed dropdown, Click 'Collapse all' button and validate case card is not exist.
   * Click 'Expand all' button and validate case card is exist.
   */
  it(
    'C127060: Customer Insights - Product Feedback tabs - Expand all <-> Collapse all Functionality Check',
    { tags: ['Customers', 'staging'] },
    function productFeedbackExpandAll() {
      customerInsights.healthScoreTab().should('be.visible').and('have.text', 'Health Score');
      customerInsights.insightsTab().should('be.visible').and('have.text', 'Insights');
      customerInsights.customerNameLabel().should('be.visible').and('have.text', this.caseDetail.customerName);
      customerInsights.favoriteButton().should('be.visible');
      customerInsights.commonTabCard('need_attention').eq(1).click();
      consolePage.selectAllSignalsInDropdown();
      consolePage.selectShowAllInDropdown();
      consolePage.groupByElapsedTime();
      consolePage.expandAllConsoleLists();
      cy.waitForLoaders();
      consolePage.collapseExpandButton().should('be.visible').and('have.text', 'Collapse All');
      consolePage.caseCard().should('be.visible');
      consolePage.caseListCustomerName().should('be.visible');
      consolePage.collapseExpandButton().click();
      cy.waitForLoaders();
      consolePage.collapseExpandButton().should('be.visible').and('have.text', 'Expand All');
      consolePage.caseCard().should('not.exist');
      consolePage.caseListCustomerName().should('not.exist');
    }
  );
});
