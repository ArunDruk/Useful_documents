import { getOpenCaseDetails } from './support';
import { urlHelpers } from '../../../utils';
import { apiHelpers, customerFavorites, supportHub } from '../../../pages';

describe('Customer Insights: Favorites', () => {
  beforeEach(() => {
    cy.intercept('PUT', 'api/users/dashboard_settings').as('editFavoriteCustomers');

    cy.loginByApi();
    apiHelpers.removeAllFavoriteCustomers();
    // Note: If fetched customer id is not valid/active, the tests will fail
    getOpenCaseDetails().then((caseDetails) => {
      const caseDetail = Cypress._.sample(caseDetails);

      cy.wrap(caseDetail).as('caseDetail');

      cy.visit(urlHelpers.myCustomers);
    });
  });

  it('C462: should add customer to favorites table', { tags: ['My Customers', 'staging'] }, function addFavorite() {
    customerFavorites.zeroStateAddFavoriteButton().click();
    customerFavorites.searchFor(this.caseDetail.customerName);

    customerFavorites.searchResultsListItem().should('be.visible').and('have.length.at.least', 1).first().should('have.text', this.caseDetail.customerName).click();
    cy.wait('@editFavoriteCustomers');

    customerFavorites.favoritesTableCustomerNameLabel().should('have.text', this.caseDetail.customerName);
  });

  it('C463: should remove customer from favorites table', { tags: 'Customer' }, function removeFavorite() {
    customerFavorites.zeroStateAddFavoriteButton().click();
    customerFavorites.searchFor(this.caseDetail.customerName);

    customerFavorites.searchResultsListItem().should('be.visible').and('have.length.at.least', 1).first().should('have.text', this.caseDetail.customerName).click();
    cy.wait('@editFavoriteCustomers');

    customerFavorites.favoritesTableCustomerNameLabel().should('have.text', this.caseDetail.customerName);
    customerFavorites.removeFavoriteButton().should('be.visible').click();
    cy.wait('@editFavoriteCustomers');

    // TODO: Get data-testid for empty state Add Favorite button
    customerFavorites.zeroStateAddFavoriteButton().should('be.visible');
  });

  /*
   * Add customer to the favorite table using API
   * Revisit the page
   * Click the count label with non-empty value (in any of the 4 columns)
   * Verify case list table item is visible and click the first one
   * Verify SH container is visible
   */
  it('C3795: should open SupportHub from favorites table', function openingSupportHub() {
    apiHelpers.addCustomerToFavorite(this.caseDetail.customerId);
    cy.visit(urlHelpers.myCustomers);

    customerFavorites.caseCountLabel().first().click();
    customerFavorites.caseListItem().should('be.visible').first().click();

    supportHub.baseContainer().should('be.visible');
  });
});
