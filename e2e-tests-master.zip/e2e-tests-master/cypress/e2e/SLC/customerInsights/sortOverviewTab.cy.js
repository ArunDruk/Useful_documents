import { arrayEquals, urlHelpers } from '../../../utils';
import { customerInsights } from '../../../pages';
import sortTimePhrases from '../../../utils/sortTimePhrases';

const sortByOptions = [
  { optionName: 'Created Date', targetElement: customerInsights.overviewTabCaseListItemTimeLabel, sortInDescending: false },
  { optionName: 'Recent Activity', targetElement: customerInsights.overviewTabCaseListItemTimeLabel, sortInDescending: false },
  { optionName: 'Sentiment Score', targetElement: customerInsights.overviewTabCaseListItemSentimentScoreLabel, sortInDescending: true },
  { optionName: 'Attention Score', targetElement: customerInsights.overviewTabCaseListItemAttentionScoreLabel, sortInDescending: true },
];

const sortByOptionsRecentlyClosedTab = [
  { optionName: 'Created Date', targetElement: customerInsights.overviewTabCaseListItemTimeLabel, sortInDescending: false },
  { optionName: 'Closed Date', targetElement: customerInsights.overviewTabCaseListItemTimeLabel, sortInDescending: false },
  { optionName: 'Recent Activity', targetElement: customerInsights.overviewTabCaseListItemTimeLabel, sortInDescending: false },
  { optionName: 'Sentiment Score', targetElement: customerInsights.overviewTabCaseListItemSentimentScoreLabel, sortInDescending: true },
  { optionName: 'Attention Score', targetElement: customerInsights.overviewTabCaseListItemAttentionScoreLabel, sortInDescending: true },
];

describe('Customer Insights - Sorting (Overview Tab)', () => {
  beforeEach(() => {
    cy.intercept('POST', 'api/cache/qa-automation/tickets/sortByWithData').as('sortBy');

    cy.loginByApi();
    cy.slcHelpers.getCustomerDetails().then((customerDetails) => {
      const customerDetail = Cypress._.sample(customerDetails);

      cy.visit(urlHelpers.customerInsights.customerPageTabs(customerDetail.native_id, 'tickets'));

      customerInsights.searchTextfield().should('be.visible').and('have.value', customerDetail.name);
      customerInsights.insightsTab().click();
    });
  });

  /*
   * Click the 'Open' tab in recent cases section
   *
   * Select each sort option
   * Change the sort direction to descending (for created date & recent activity, descending -> from recent by design as per Iskander)
   * Verify that the cases are sorted correctly based on the selected value
   *
   * Change the sort direction to ascending (for created date & recent activity, ascending -> from the oldest by design as per Iskander)
   * Verify that the cases are sorted correctly based on the selected value
   */
  it('C474: should verify sort by functionality', { tags: ['Customer Insights', 'staging', 'prod'] }, () => {
    customerInsights.overviewTabOpenTab().click();

    sortByOptions.forEach((option) => {
      customerInsights.sortCasesBy(option.optionName);
      // cy.wait('@sortBy');
      cy.waitForLoaders();
      customerInsights.switchSortDirection();
      option
        .targetElement()
        .text()
        .then(async (targetValue) => arrayEquals(targetValue, sortTimePhrases(targetValue, option.sortInDescending)))
        .should('be.true');

      customerInsights.switchSortDirection('asc');
      option
        .targetElement()
        .text()
        .then(async (targetValue) => arrayEquals(targetValue, sortTimePhrases(targetValue, !option.sortInDescending)))
        .should('be.true');
    });
  });

  /*
   * NOTE: This script will fail if case count is less than 2
   *
   * Click the 'Open' tab in recent cases section
   *
   * For each sort by option,
   *  Select the option
   *  Change sort order to ascending
   *  Get the Case ID of the first case in the list
   *
   *  Change the sort order to descending
   *  Verify that the first case ID is now different
   *
   *  Again, change the sort order back to ascending
   *  Verify that the first case ID is the same as before
   */
  it('C475: should verify sort order', { tags: ['Customer Insights', 'staging', 'prod'] }, () => {
    customerInsights.overviewTabOpenTab().click();

    // eslint-disable-next-line array-callback-return
    sortByOptions.map(({ optionName }) => {
      customerInsights.sortCasesBy(optionName);
      // cy.wait('@sortBy');
      cy.waitForLoaders();
      customerInsights.switchSortDirection('asc');

      customerInsights
        .overviewTabCaseListItemCaseIdLabel()
        .first()
        .text()
        .then((caseIdBeforeSort) => {
          customerInsights.switchSortDirection();
          customerInsights.overviewTabCaseListItemCaseIdLabel().first().should('not.have.text', caseIdBeforeSort);

          customerInsights.switchSortDirection('asc');
          customerInsights.overviewTabCaseListItemCaseIdLabel().first().should('have.text', caseIdBeforeSort);
        });
    });
  });

  /*
   * Click the 'Recenlty Closed' tab in recent cases section
   *
   * Select each sort option
   * Change the sort direction to descending (for created date & recent activity, descending -> from recent by design as per Iskander)
   * Verify that the cases are sorted correctly based on the selected value
   *
   * Change the sort direction to ascending (for created date & recent activity, ascending -> from the oldest by design as per Iskander)
   * Verify that the cases are sorted correctly based on the selected value
   */
  it('C37824: verify recently closed sort by functionality', { tags: ['Customer Insights', 'staging', 'prod'] }, () => {
    customerInsights.overviewTabRecentlyClosedTab().click();

    sortByOptionsRecentlyClosedTab.forEach((option) => {
      customerInsights.sortCasesBy(option.optionName);
      // cy.wait('@sortBy');
      cy.waitForLoaders();
      customerInsights.switchSortDirection();
      option
        .targetElement()
        .text()
        .then(async (targetValue) => arrayEquals(targetValue, sortTimePhrases(targetValue, option.sortInDescending)))
        .should('be.true');

      customerInsights.switchSortDirection('asc');
      option
        .targetElement()
        .text()
        .then(async (targetValue) => arrayEquals(targetValue, sortTimePhrases(targetValue, !option.sortInDescending)))
        .should('be.true');
    });
  });

  /*
   * NOTE: This script will fail if case count is less than 2
   *
   * Click the 'Recently closed' tab in recent cases section
   *
   * For each sort by option,
   *  Select the option
   *  Change sort order to ascending
   *  Get the Case ID of the first case in the list
   *
   *  Change the sort order to descending
   *  Verify that the first case ID is now different
   *
   *  Again, change the sort order back to ascending
   *  Verify that the first case ID is the same as before
   */
  it('C37825: verify recently closed cases sort order', { tags: ['Customer Insights', 'staging', 'prod'] }, () => {
    customerInsights.overviewTabRecentlyClosedTab().click();

    // eslint-disable-next-line array-callback-return
    sortByOptionsRecentlyClosedTab.map(({ optionName }) => {
      customerInsights.sortCasesBy(optionName);
      // cy.wait('@sortBy');
      cy.waitForLoaders();
      customerInsights.switchSortDirection('asc');

      customerInsights
        .overviewTabCaseListItemCaseIdLabel()
        .first()
        .text()
        .then((caseIdBeforeSort) => {
          customerInsights.switchSortDirection();
          customerInsights.overviewTabCaseListItemCaseIdLabel().first().should('not.have.text', caseIdBeforeSort);

          customerInsights.switchSortDirection('asc');
          customerInsights.overviewTabCaseListItemCaseIdLabel().first().should('have.text', caseIdBeforeSort);
        });
    });
  });
});
