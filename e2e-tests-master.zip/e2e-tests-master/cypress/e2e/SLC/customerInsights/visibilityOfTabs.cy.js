import { getOpenCaseDetails } from './support';
import { urlHelpers } from '../../../utils';
import { consolePage, customerInsights, supportHub } from '../../../pages';

describe('Customer Insights: Visibility of the tabs', () => {
  beforeEach(() => {
    cy.loginByApi();
    getOpenCaseDetails().then((caseDetails) => {
      const caseDetail = Cypress._.sample(caseDetails);

      cy.wrap(caseDetail).as('caseDetail');
      // visit the overview tab of specified customer
      cy.visit(urlHelpers.customerInsights.customerPage(caseDetail.customerId));
      customerInsights.searchTextfield().should('be.visible').and('have.value', caseDetail.customerName);
      customerInsights.insightsTab().click();
    });
  });

  /*
   * Go to customer insight page.
   * Search for any customer name and click enter.
   * Click the insights tab, Click on the overview cases tab, Click the open status.
   * Validate the display of open status, sortorderbutton, all the sort dropdown options.
   */
  it('C37822: verify the display of overview tab [ open status ]', { tags: ['Customers', 'staging', 'prod'] }, function overviewTabOpenStatus() {
    customerInsights.commonTabCard('overview').eq(1).click();
    customerInsights.overviewTabRecentCasesHeader().should('be.visible').and('contain', `Recent Cases`);
    customerInsights.overviewTabOpenTab().should('be.visible').and('contain', `Open`);
    customerInsights.overviewTabOpenTab().click();
    customerInsights.overviewTabSortOrderButton().realHover();
    customerInsights.overviewTabSortOrderButtonTooltip().should('have.text', 'Switch sort direction');
    customerInsights.overviewTabStatusChartTitle().should('be.visible').and('contain', `Status`);
    customerInsights.overviewTabPriorityChartTitle().should('be.visible').and('contain', `Priority`);
    customerInsights.overviewTabSortByDropdown().click();
    customerInsights.overviewTabSortByDropdownCreatedAtOption().should('be.visible').and('contain', `Created Date`);
    customerInsights.overviewTabSortByDropdownRecentActivityOption().should('be.visible').and('contain', `Recent Activity`);
    customerInsights.overviewTabSortByDropdownSentimentScoreOption().should('be.visible').and('contain', `Sentiment Score`);
    customerInsights.overviewTabSortByDropdownAttentionScoreOption().should('be.visible').and('contain', `Attention Score`);
  });

  /*
   * Go to customer insight page.
   * Search for any customer name and click enter.
   * Click the insights tab, Click on the overview cases tab, Click the recently closed status.
   * Validate the display of open status, sortorderbutton, all the sort dropdown options.
   */
  it('C37823: Verify the display of Overview tab [ Recently closed status ]', { tags: ['Customers', 'staging', 'prod'] }, function overviewTabRecentlyClosedStatus() {
    customerInsights.commonTabCard('overview').eq(1).click();
    customerInsights.overviewTabRecentCasesHeader().should('be.visible').and('contain', `Recent Cases`);
    customerInsights.overviewTabRecentlyClosedTab().should('be.visible').and('contain', `Recently Closed`);
    customerInsights.overviewTabRecentlyClosedTab().click();
    customerInsights.overviewTabSortOrderButton().realHover();
    customerInsights.overviewTabSortOrderButtonTooltip().should('have.text', 'Switch sort direction');
    customerInsights.overviewTabStatusChartTitle().should('be.visible').and('contain', `Status`);
    customerInsights.overviewTabPriorityChartTitle().should('be.visible').and('contain', `Priority`);
    customerInsights.overviewTabSortByDropdown().click();
    customerInsights.overviewTabSortByDropdownCreatedAtOption().should('be.visible').and('contain', `Created Date`);
    customerInsights.overviewTabSortByDropdownClosedAtOption().should('be.visible').and('contain', `Closed Date`);
    customerInsights.overviewTabSortByDropdownRecentActivityOption().should('be.visible').and('contain', `Recent Activity`);
    customerInsights.overviewTabSortByDropdownSentimentScoreOption().should('be.visible').and('contain', `Sentiment Score`);
    customerInsights.overviewTabSortByDropdownAttentionScoreOption().should('be.visible').and('contain', `Attention Score`);
  });

  /*
   * Go to customer insights page.
   * Search for any customer name and click enter.
   * Click the insights tab, Click on the need attention tab, Click the Attention score option in the groupedby dropdown.
   * Validate the display of Need Attention header title , Open any SH and check Attention score label is displayed.
   */
  it('C37821: Verify the display of Need attention tab', { tags: ['Customers', 'staging'] }, () => {
    customerInsights.commonTabCard('need_attention').eq(1).click();
    consolePage.consoleTabsShowingHeaderTitle().should('be.exist');
    consolePage.consoleTabsShowingHeaderTitle().invoke('text').should('contain', `Showing`);
    consolePage.consoleSentimentsTabsHeaderTitle().should('be.exist');
    consolePage.consoleSentimentsTabsHeaderTitle().invoke('text').should('contain', `Need Attention`);
    consolePage.sentimentsTabsSignalsDropdown().click();
    consolePage.signalsDropdownSentimentSignalHeader().invoke('text').should('contain', `Sentiment Signal`);
    consolePage.signalsDropdownSentimentSignalCheckbox().invoke('attr', 'data-status').should('eq', 'checked');
    cy.waitForLoaders();
    consolePage.acknowledgeDropdown().click({ force: true });
    consolePage.acknowledgeDropdownValueAll().should('be.visible').and('contain', `Show all`);
    consolePage.acknowledgeDropdownValueAck().should('be.visible').and('contain', `Show Acknowledged`);
    consolePage.acknowledgeDropdownValueUnack().should('be.visible').and('contain', `Show Unacknowledged`);
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    consolePage.groupedByDropdown().eq(0).click();
    consolePage.consoleGroupedByDropdownAttentionScoreOption().click();
    cy.waitForLoaders();
    consolePage.consoleSubTabsOptionSwitcher().eq(0).click();
    cy.waitForLoaders();
    consolePage.caseCard().eq(0).click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
    supportHub.supportHubAttentionScoreLabel().then(($attentionScore) => {
      const attentionScore = $attentionScore.text();

      expect(parseInt(attentionScore, 10)).to.be.at.least(parseInt(80, 10)).and.to.be.at.most(parseInt(100, 10));
      supportHub.closeButton().click();
    });
  });

  /*
   * Go to customer insights page.
   * Search for any customer name and click enter.
   * Click the insights tab, Click on the Negative Sentiment tab, Click the Sentiment score option in the groupedby dropdown.
   * Validate the display of Negative Sentiment header title , Open any SH and check Sentiment score label is displayed.
   */
  it('C37826: Verify the display of Negative Sentiment tab', { tags: ['Customers', 'staging'] }, () => {
    customerInsights.commonTabCard('negative_sentiments').eq(1).click();
    consolePage.consoleTabsShowingHeaderTitle().should('be.exist');
    consolePage.consoleTabsShowingHeaderTitle().invoke('text').should('contain', `Showing`);
    consolePage.consoleSentimentsTabsHeaderTitle().should('be.exist');
    consolePage.consoleSentimentsTabsHeaderTitle().invoke('text').should('contain', `Negative Sentiments`);
    consolePage.sentimentsTabsSignalsDropdown().click();
    consolePage.signalsDropdownSentimentSignalHeader().invoke('text').should('contain', `Sentiment Signal`);
    consolePage.signalsDropdownSentimentSignalCheckbox().invoke('attr', 'data-status').should('eq', 'checked');
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    consolePage.acknowledgeDropdown().click({ force: true });
    consolePage.acknowledgeDropdownValueAll().should('be.visible').and('contain', `Show all`);
    consolePage.acknowledgeDropdownValueAck().should('be.visible').and('contain', `Show Acknowledged`);
    consolePage.acknowledgeDropdownValueUnack().should('be.visible').and('contain', `Show Unacknowledged`);
    consolePage.groupBySentimentScoreOption();
    cy.waitForLoaders();
    consolePage
      .consoleSubTabsOptionSwitcher()
      .eq(0)
      .then(($scoreRange) => {
        const minScoreRange = $scoreRange.text().split('-')[0];
        const maxScoreRange = $scoreRange.text().split('-')[1];

        consolePage.consoleSubTabsOptionSwitcher().eq(0).click();
        cy.waitForLoaders();
        consolePage.caseCard().eq(0).click();
        cy.waitForLoaders();
        supportHub.baseContainer().should('be.visible');
        cy.waitForLoaders();
        supportHub.supportHubSentimentScoreLabel().then(($sentimentScore) => {
          const sentimentScore = $sentimentScore.text();

          expect(parseInt(sentimentScore, 10)).to.be.at.least(parseInt(minScoreRange, 10)).and.to.be.at.most(parseInt(maxScoreRange, 10));
          supportHub.closeButton().click();
        });
      });
  });

  /*
   * Go to customer insights page.
   * Search for any customer name and click enter.
   * Click the insights tab, Click on the Positive Sentiment tab, Click the Sentiment score option in the groupedby dropdown.
   * Validate the display of Positive Sentiment header title , Open any SH and check Sentiment score label is displayed.
   */
  it('C37827: Verify the display of Positive Sentiment tab', { tags: ['Customers', 'staging'] }, () => {
    customerInsights.commonTabCard('positive_sentiments').eq(1).click();
    consolePage.consoleTabsShowingHeaderTitle().should('be.exist');
    consolePage.consoleTabsShowingHeaderTitle().invoke('text').should('contain', `Showing`);
    consolePage.consoleSentimentsTabsHeaderTitle().should('be.exist');
    consolePage.consoleSentimentsTabsHeaderTitle().invoke('text').should('contain', `Positive Sentiments`);
    consolePage.sentimentsTabsSignalsDropdown().click();
    consolePage.signalsDropdownSentimentSignalHeader().invoke('text').should('contain', `Sentiment Signal`);
    consolePage.signalsDropdownSentimentSignalCheckbox().invoke('attr', 'data-status').should('eq', 'checked');
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    consolePage.acknowledgeDropdown().click({ force: true });
    consolePage.acknowledgeDropdownValueAll().should('be.visible').and('contain', `Show all`);
    consolePage.acknowledgeDropdownValueAck().should('be.visible').and('contain', `Show Acknowledged`);
    consolePage.acknowledgeDropdownValueUnack().should('be.visible').and('contain', `Show Unacknowledged`);
    consolePage.groupBySentimentScoreOption();
    cy.waitForLoaders();
    consolePage
      .consoleSubTabsOptionSwitcher()
      .eq(0)
      .then(($scoreRange) => {
        const minScoreRange = $scoreRange.text().split('-')[0];
        const maxScoreRange = $scoreRange.text().split('-')[1];

        consolePage.consoleSubTabsOptionSwitcher().eq(0).click();
        cy.waitForLoaders();
        consolePage.caseCard().eq(0).click();
        cy.waitForLoaders();
        supportHub.baseContainer().should('be.visible');
        cy.waitForLoaders();
        supportHub.supportHubSentimentScoreLabel().then(($sentimentScore) => {
          const sentimentScore = $sentimentScore.text();

          expect(parseInt(sentimentScore, 10)).to.be.at.least(parseInt(minScoreRange, 10)).and.to.be.at.most(parseInt(maxScoreRange, 10));
          supportHub.closeButton().click();
        });
      });
  });

  /*
   * Go to customer insight page.
   * Search for any customer name and click enter.
   * Click the insights tab, Click on the Product Feedback tab, Click the Sentiment score option in the groupedby dropdown.
   * Validate the display of Product Feedback header title , Open any SH and check Sentiment score label is displayed.
   */
  it('C37828: Verify the display of Product Feedback  tab', { tags: ['Customers', 'staging'] }, () => {
    customerInsights.commonTabCard('product_feedback').eq(1).click();
    consolePage.consoleTabsShowingHeaderTitle().should('be.exist');
    consolePage.consoleTabsShowingHeaderTitle().invoke('text').should('contain', `Showing`);
    consolePage.consoleSentimentsTabsHeaderTitle().should('be.exist');
    consolePage.consoleSentimentsTabsHeaderTitle().invoke('text').should('eq', `Product Feedback`.trim());
    consolePage.sentimentsTabsSignalsDropdown().click();
    consolePage.signalsDropdownSentimentSignalHeader().invoke('text').should('contain', `Sentiment Signal`);
    consolePage.signalsDropdownSentimentSignalCheckbox().invoke('attr', 'data-status').should('eq', 'checked');
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    consolePage.groupedByDropdown().contains('Show all').click({ force: true });
    consolePage.acknowledgeDropdownValueAll().should('be.visible').and('contain', `Show all`);
    consolePage.acknowledgeDropdownValueAck().should('be.visible').and('contain', `Show Acknowledged`);
    consolePage.acknowledgeDropdownValueUnack().should('be.visible').and('contain', `Show Unacknowledged`);
    consolePage.groupBySentimentScoreOption();
    cy.waitForLoaders();
    consolePage
      .consoleSubTabsOptionSwitcher()
      .eq(0)
      .then(($scoreRange) => {
        const minScoreRange = $scoreRange.text().split('-')[0];
        const maxScoreRange = $scoreRange.text().split('-')[1];

        consolePage.consoleSubTabsOptionSwitcher().eq(0).click();
        cy.waitForLoaders();
        consolePage.caseCard().eq(0).click();
        cy.waitForLoaders();
        supportHub.baseContainer().should('be.visible');
        cy.waitForLoaders();
        supportHub.supportHubSentimentScoreLabel().then(($sentimentScore) => {
          const sentimentScore = $sentimentScore.text();

          expect(parseInt(sentimentScore, 10)).to.be.at.least(parseInt(minScoreRange, 10)).and.to.be.at.most(parseInt(maxScoreRange, 10));
          supportHub.closeButton().click();
        });
      });
  });

  /*
   * Go to customer insight page.
   * Search for any customer name and click enter.
   * Click the insights tab, Click on the Engineering Issues tab.
   * Validate the display of Top Entities, Status, Priority chart title.
   */
  it('C37829: Verify the display of Engineering Issues  tab', { tags: ['Customers', 'staging'] }, () => {
    customerInsights.commonTabCard('Engineering_Issues').eq(1).click();
    cy.waitForLoaders();
    consolePage.engIssuesChartWrapperEntities().invoke('text').should('contain', `Top Entities`);
    consolePage.engIssuesChartWrapperStatus().invoke('text').should('contain', `Status`);
    consolePage.engIssuesChartWrapperPriority().invoke('text').should('contain', `Priority`);
  });

  /*
   * Go to customer insights page.
   * Search for any customer name and click enter.
   * Click the insights tab, Click on the new escalation tab, Click the Status option in the groupedby dropdown.
   * Validate the display of Escalation header title , Open any SH and check Escalated status label is displayed.
   */
  it('C37717: Verify the display of New escalation tab', { tags: ['Customers', 'staging'] }, () => {
    customerInsights.commonTabCard('new_escalations').eq(1).click();
    consolePage.consoleEscalatedTabHeaderTitle().should('be.exist');
    consolePage.consoleEscalatedTabHeaderTitle().invoke('text').should('contain', `Escalations`);
    consolePage.groupByStatusOption();
    cy.waitForLoaders();
    consolePage.newEscalationEscalatedOptionSwitcher().click();
    consolePage.newEscalationEscalatedOptionSwitcher().should('be.visible').and('contain', `Escalated`);
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    consolePage.newEscalationEscalatedOptionSwitcher().should('be.visible').realHover();
    consolePage.consoleTabsHeaderTitleTooltip().should('have.text', 'Escalated');
    cy.waitForLoaders();
    consolePage.escalationCaseCard().eq(0).click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
    supportHub.escalationStatusLabel().invoke('text').should('contain', `Escalated`);
    supportHub.closeButton().click();
  });
});
