import moment from 'moment';

import { getOpenCaseDetails } from './support';
import { urlHelpers } from '../../../utils';
import { customerInsights, datePicker, supportHub } from '../../../pages';

describe('Customer Insights: Calendar widget', () => {
  beforeEach(() => {
    cy.loginByApi();
    getOpenCaseDetails().then((caseDetails) => {
      const caseDetail = Cypress._.sample(caseDetails);

      // visit the overview tab of specified customer
      cy.visit(urlHelpers.customerInsights.customerPageTabs(caseDetail.customerId, 'tickets'));
      customerInsights.searchTextfield().should('be.visible').and('have.value', caseDetail.customerName);

      customerInsights.insightsTab().click();

      datePicker.datePickerTrigger().click();
      datePicker.commonShortcutsRadioButton().should('be.visible');
    });
  });

  it('C470: should scroll through months in datepicker', { tags: ['staging', 'prod'] }, () => {
    // the datepicker has 2 sections, left side -> FROM date & right side -> TO date
    // since testid is the same for both we're using the index values
    const calendarSections = { from: 0, to: 1 };

    Object.values(calendarSections).forEach((sectionIndex) => {
      datePicker
        .visibleMonthDropdown()
        .eq(sectionIndex)
        .invoke('text')
        .then((currentSelectedMonth) => {
          // previous month
          datePicker.previousMonthButton().eq(sectionIndex).click();
          // eslint-disable-next-line cypress/no-unnecessary-waiting
          cy.wait(1000);
          datePicker.visibleMonthDropdown().eq(sectionIndex).should('contain.text', moment(currentSelectedMonth, 'MMM').subtract(1, 'months').format('MMM'));
          // next month
          datePicker.nextMonthButton().eq(sectionIndex).click();
          // eslint-disable-next-line cypress/no-unnecessary-waiting
          cy.wait(1000);
          datePicker.visibleMonthDropdown().eq(sectionIndex).should('contain.text', currentSelectedMonth);
        });
    });
  });

  /*
   * Select 'Last 3 months' option in datepicker
   *
   * Click the open tab in Overview tab
   * Select 'Created Date' as 'sort by' option
   * Change the sort order to 'descending'
   *
   * Click the first ticket in the case list table
   * Collapse all case comments
   *
   */
  it('C471: should apply selected datepicker value', { tags: ['staging', 'prod'] }, () => {
    const caseCreationTime = [
      moment().subtract(3, 'months').format('MMM'),
      moment().subtract(2, 'months').format('MMM'),
      moment().subtract(1, 'months').format('MMM'),
      moment().format('MMM'),
    ];

    datePicker
      .datePickerTrigger()
      .invoke('text')
      .then((currentValue) => {
        if (currentValue !== 'Last 3 months') {
          // Note: The validation of correct data loading is excluded, as suggested by Jacob Mathew
          datePicker.selectLastMonthWithOption(3);
          datePicker.datePickerTrigger().should('have.text', 'Last 3 months');
        }
      });
    cy.waitForLoaders();
    customerInsights.overviewTabOpenTab().click();
    customerInsights.sortCasesBy('Created Date');
    customerInsights.overviewTabSortOrderButton().click();

    customerInsights.overviewTabCaseListItem().first().click();
    cy.waitForLoaders();

    supportHub.gotoCaseDescriptionButton().click();
    supportHub.caseCommentsHeaderCollapseButton().last().click();

    supportHub
      .caseCommentsHeader()
      .last()
      .contains(RegExp(caseCreationTime.join('|')));
  });

  it('C472: should cancel datepicker selection and close popup', { tags: ['staging', 'prod'] }, () => {
    datePicker.thisMonthRadioButton().click();
    datePicker.cancelButton().click();

    // verify popup is closed
    datePicker.thisMonthRadioButton().should('not.exist');
    // verify selected value is not applied
    datePicker.datePickerTrigger().should('not.have.text', 'This month');
  });
});
