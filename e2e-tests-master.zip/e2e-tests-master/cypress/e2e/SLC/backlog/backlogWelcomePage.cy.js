import { urlHelpers } from '../../../utils';
import { backlogPage, apiHelpers } from '../../../pages';

describe('Welcome Screen Functionality', () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.setToDefaultListBacklog();
  });

  afterEach(() => apiHelpers.setToDefaultListBacklog());

  /**
   * Open the backlog page.
   * Check the welcome note text-"Case Backlog".
   * Check the 'default lists set' and 'create custom list' options should be seen in the page.
   */
  it('C74: Welcome screen visibility for new user', { tags: ['Case Board', 'staging'] }, () => {
    apiHelpers.setToWelcomePageBacklog();
    cy.visit(urlHelpers.backlog);
    backlogPage.welcomePageVisibility();
  });

  /**
   * Open the backlog page.
   * The new user the welcome page which will have the buttons to create
   a "Default list Set" or "Create custom list" provided by the system.
   * Delete all case lists in case board.
   * Click on create Default List button.
   * Check the titles of the each list.
   */
  it('C524: Checking the functionality of default lists set button in welcome page ', { tags: ['Case Board', 'staging'] }, () => {
    cy.visit(urlHelpers.backlog);
    for (let i = 0; i < 4; i += 1) {
      // eslint-disable-next-line cypress/no-unnecessary-waiting
      cy.wait(500);
      backlogPage.deleteBacklogList();
    }
    backlogPage.welcomePageDefaultListsSet();
  });

  /**
   * Open the backlog page.
   * The new user the welcome page which will have the buttons to create
   a "Default list Set" or "Create custom list" provided by the system.
   * Delete all case lists in case board.
   * Click on create create list button,add a name to the case list & click next button.
   * Select sentiment count in the Rank Cases By option and create a list.
   * Check the titles of the each list.
   */
  it('C525: Checking the functionality of create custom list button in welcome page', { tags: ['Case Board', 'staging'] }, () => {
    cy.visit(urlHelpers.backlog);
    for (let i = 0; i < 4; i += 1) {
      // eslint-disable-next-line cypress/no-unnecessary-waiting
      cy.wait(500);
      backlogPage.deleteBacklogList();
    }
    backlogPage.welcomePageCreateCustomList();
  });
});
