import path from 'path';
import { randId, urlHelpers } from '../../../utils';
import { apiHelpers, backlogPage } from '../../../pages';

describe('Case Board Tests', () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.setToDefaultListBacklog();

    cy.visit(urlHelpers.backlog);
  });

  afterEach(() => apiHelpers.setToDefaultListBacklog());

  // Smoke & Sanity C507
  it('C507: Case Board Load', { tags: 'Case Board' }, () => {
    cy.getByTestId('layout-navigation-module-item--cases').should('be.visible');
    cy.getByTestId('casesPage-casesList-listTitle').should('be.visible');
  });

  // Regression C508
  it('C508: Adding a new case list', { tags: 'Case Board' }, () => {
    const caseName = `Test Case Board ${randId()}`;

    // Clicking on the Create New List button
    cy.getByTestId('caseBoard--floating-action-button').click();

    // Entering the Case List Name and click Next
    cy.getByTestId('caseBoard--list-form--listNameInput').type(caseName);
    backlogPage.createNewListSubmitButton().should('be.enabled').and('have.text', 'Next').click();
    backlogPage.createNewListSubmitButton().click();
    // Select the Rank case radio button and click Create
    cy.getByTestId('caseBoard--list-form--tabs--rank--items--sentimentScore').click();
    backlogPage.createNewListSubmitButton().should('be.enabled').and('have.text', 'Create').click();
    // Verify the Added Case is displaying in the List
    cy.getByTestId('casesPage-casesList-listTitle').eq(0).contains(caseName);
  });

  // Regression C92
  it('C92: Check if the created list gets deleted', { tags: 'Case Board' }, () => {
    const caseName = `Test Case Board ${randId()}`;

    // Clicking on the Create New List button
    cy.getByTestId('caseBoard--floating-action-button').click();
    // Entering the Case List Name and click Next
    cy.getByTestId('caseBoard--list-form--listNameInput').type(caseName);

    backlogPage.createNewListSubmitButton().should('be.enabled').and('have.text', 'Next').click();
    backlogPage.createNewListSubmitButton().click();
    // Select the Rank case radio button and click Create
    cy.getByTestId('caseBoard--list-form--tabs--rank--items--sentimentScore').click();
    backlogPage.createNewListSubmitButton().should('be.enabled').and('have.text', 'Create').click();
    // Verify the Added Case is displaying in the List
    cy.getByTestId('casesPage-casesList-listTitle').eq(0).contains(caseName);
    // Click on the three dots present in the list
    cy.getByTestId('caseBoard--list--menu').eq(0).should('be.visible').click();
    // Click on the Delete list
    cy.getByTestId('caseBoard--list--menu--delete-list').eq(0).should('be.visible').click();
    // Click Confirm Delete
    cy.getByTestId('casesPage-casesList-removePopup-confirmDeleteBtn').should('have.text', 'Delete').click();
    // Verify the Deleted Case List not exist
    cy.getByTestId('layout-navigation-module-item--cases').should('be.visible').click();
    cy.getByTestId('casesPage-casesList-listTitle').eq(0).should('not.contain', caseName);
  });

  // Regression C521
  it('C521: Checking the functionality of downloading the created list in csv format', { tags: 'Case Board' }, () => {
    // Getting the case name
    cy.getByTestId('casesPage-casesList-listTitle')
      .eq(0)
      .then(($btn) => {
        // store the button's text
        const caseName1 = $btn.text().split('Sorted');
        const expectedFileName = `case ${caseName1[0]}.csv`;
        const downloadsFolder = Cypress.config('downloadsFolder');
        // Click on the three dots present in the list
        cy.getByTestId('caseBoard--list--menu').eq(0).should('be.visible').click();
        // Click on the Download CSV button
        cy.getByTestId('caseBoard--list--menu--download-csv').eq(0).should('be.visible').click();
        // Verify the file is exported in CSV format
        cy.readFile(path.join(downloadsFolder, expectedFileName)).should('exist');
        // TODO: Verify of the values in the download file will be added in the Phase-2
      });
  });
});
