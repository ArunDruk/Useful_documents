import { urlHelpers } from '../../../utils';
import { backlogPage, apiHelpers } from '../../../pages';

describe('Verifying backlog list', () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.setToDefaultListBacklog();

    cy.visit(urlHelpers.backlog);
  });

  afterEach(() => apiHelpers.setToDefaultListBacklog());

  /**
   * Open the backlog page.
   * Click on add(plus) button.
   * Check if the user enters a name of the list and press "enter" button will take you to the next page in create a list flow in backlog page.
   * Select any rank system and create a list.
   */
  it('C511: Create a list enter button functionality', { tags: ['Case Board', 'staging'] }, () => {
    backlogPage.verifyNewListEnterKeyPress();
    backlogPage.deleteBacklogList();
  });

  /**
   * Open the backlog page.
   * Click on add(plus) button.
   * Check is no name is added the NEXT button should remain disabled.
   * Select any rank system and create a list.
   */
  it('C512: Create a list next button functionality', { tags: ['Case Board', 'staging'] }, () => {
    backlogPage.createNewList();
    backlogPage.deleteBacklogList();
  });

  /**
   * Open the backlog page.
   * Click on add(plus) button.
   * Add a name to the case list & click next button.
   * Checks if the user don't select any rank system then th CREATE button should be
   disable until and unless something is selected in create a list flow in backlog page.
   * Select any rank system ,CREATE button is visible now and click and create a list.
   */
  it('C514: Create a list rank cases by functionality check ', { tags: ['Case Board', 'staging'] }, () => {
    backlogPage.verifyNewListRankCasesByFlow();
    backlogPage.deleteBacklogList();
  });

  /**
   * Open the backlog page.
   * Click on add(plus) button.
   * Add a name to the case list & click next button.
   * Select sentiment count in the Rank Cases By option and create a list.
   * Check the sentiment count should be in descending order in the lists.
   */
  it('C2193: Create a list with sentiment count', { tags: ['Case Board', 'staging'] }, () => {
    backlogPage.verifyNewListWithSentimentCount();
    backlogPage.deleteBacklogList();
  });
});
