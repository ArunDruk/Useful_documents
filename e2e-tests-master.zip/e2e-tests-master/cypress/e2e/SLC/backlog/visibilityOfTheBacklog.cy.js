import { urlHelpers } from '../../../utils';

// Skipping Enable Disable module test cases
describe.skip('Case Board Page - Disable, Enable functionality check', { tags: ['@EnableDisableLockTests', '@NotThreadSafe'] }, () => {
  beforeEach(() => {
    cy.loginByApi();
  });

  /*
   Enable_Disable_backlog:
   Test steps:
   1. Disabled the backlog and check that backlog option is disabled.
   2. Enabled the backlog and check that backlog option is visible.
   */
  it('C71: Disable the Case Board', { tags: 'Case Board' }, () => {
    cy.slcHelpers.disableModule('cases');
    cy.visit(urlHelpers.backlog);
    cy.getByTestId('Case_Backlog-disable-modal-message').invoke('text').should('include', 'Case Backlog module is disabled for you');
    cy.getByTestId('caseBoard--floating-action-button').should('not.exist');

    cy.slcHelpers.enableModule('cases');
    cy.visit(urlHelpers.backlog);
    cy.getByTestId('caseBoard--floating-action-button').should('be.visible');
  });

  it('C73: Enable the Case Board', { tags: 'Case Board' }, () => {
    cy.slcHelpers.enableModule('cases');
    cy.visit(urlHelpers.backlog);
    cy.getByTestId('caseBoard--floating-action-button').should('be.visible');
  });
});
