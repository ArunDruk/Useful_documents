import { urlHelpers } from '../../../utils';
import { backlogPage, apiHelpers } from '../../../pages';

describe('Verifying sort in backlog list', () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.setToDefaultListBacklog();

    cy.visit(urlHelpers.backlog);
  });

  afterEach(() => apiHelpers.setToDefaultListBacklog());

  /**
   * Open the backlog page.
   * Click on three dot option.
   * Click the change switch sort direction.
   * Check that sort is happening in the respective list.
   */
  it('C2338: Sort functionality check in the list', { tags: ['Case Board', 'staging'] }, () => {
    backlogPage.verifyListSortOrder();
  });
});
