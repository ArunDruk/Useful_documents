import { urlHelpers } from '../../../utils';
import { backlogPage, apiHelpers } from '../../../pages';

describe('Verifying Renaming,SH Open Functionality', () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.setToDefaultListBacklog();
    cy.visit(urlHelpers.backlog);
  });

  afterEach(() => apiHelpers.setToDefaultListBacklog());

  /**
   * Open the backlog page.
   * Click on add(plus) button.
   * Add a name to the case list & click next button.
   * Select sentiment count in the Rank Cases By option and create a list.
   * Click three dot option and click edit list and rename the list.
   * Check the changed names is reflected in the list.
   */
  it('C526: Checking the functionality of renaming the created list ', { tags: ['Case Board', 'staging'] }, () => {
    backlogPage.createNewList();
    backlogPage.editNameBacklogList();
    backlogPage.deleteBacklogList();
  });

  /**
   * Open the backlog page.
   * Click on add(plus) button.
   * Add a name to the case list & click next button.
   * Select sentiment count in the Rank Cases By option and create a list.
   * Click on a case in any case list.
   * The support hub should open for the ticket where the click happened.
   */
  it('C528: Check if supporthub open when clicked on a ticket', { tags: ['Case Board', 'staging'] }, () => {
    backlogPage.createNewList();
    backlogPage.verifyBacklogSupportHub();
    backlogPage.deleteBacklogList();
  });
});
