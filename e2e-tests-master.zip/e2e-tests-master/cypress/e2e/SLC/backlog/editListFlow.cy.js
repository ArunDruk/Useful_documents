import { urlHelpers } from '../../../utils';
import { backlogPage, apiHelpers } from '../../../pages';

describe('Backlog list - Edit functionality', () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.setToDefaultListBacklog();
    cy.visit(urlHelpers.backlog);
  });

  afterEach(() => apiHelpers.setToDefaultListBacklog());

  /**
   * Open the backlog page.
   * Click on three dot option.
   * Click the edit list option.
   * Click the cancel button.
   * Check that edit list modal is closed and no changes is happened.
   */
  it('C95: Edit list flow cancel option functionality check', { tags: ['Case Board', 'staging'] }, () => {
    backlogPage.verifyListEditCancellingFlow();
  });

  /**
   * Open the backlog page.
   * Click on three dot option.
   * Click the edit list option.
   * Edit the name and change rank case by option.
   * Check that changes reflected correctly in the list.
   */
  it('C96: Edit list flow functionality check', { tags: ['Case Board', 'staging'] }, () => {
    backlogPage.verifyListEditFLow();
  });
});
