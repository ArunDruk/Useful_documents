import { urlHelpers } from '../../../utils';
import { apiHelpers } from '../../../pages';

describe('Case Board Page - Expand functionality check', () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.setToDefaultListBacklog();

    cy.visit(urlHelpers.backlog);
  });

  afterEach(() => apiHelpers.setToDefaultListBacklog());

  it('C91: Expand functionality in the Case Board', { tags: 'Case Board' }, () => {
    /*
     Expand_functionality_check:
     Test steps:
     1. Open the backlog and case lists are populated.
     2. Press Expand option under any list.
     3. Open any case and close.
     4. Close the Expand view.
     */
    cy.getByTestId('casesPage-casesList-listTitle-titleName')
      .eq(1)
      .then(($btn) => {
        const expectedName = $btn.text();

        cy.getByTestId('caseBoard--list--expand').eq(1).click();
        cy.getByTestId('casesPage-casesList-listTitle-titleName').should('be.visible').invoke('text').should('include', expectedName);
        cy.getByTestId('casesPage-casesList-listTitle-titleName')
          .eq(1)
          .then(($btnExpanded) => {
            const titleNameExpanded = $btnExpanded.text();

            expect(titleNameExpanded).to.eq(expectedName);
            cy.getByTestId('casesPage-casesList-caseListExpanded-closeBtn').click();
          });
        // cy.getByTestId('casesPage-casesList-listTitle').eq(0).contains('Sentiment Score');
      });
  });
});
