import { urlHelpers } from '../../../utils';
import { backlogPage, apiHelpers } from '../../../pages';

describe('Backlog list - Delete functionality', () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.setToDefaultListBacklog();
    cy.visit(urlHelpers.backlog);
  });

  afterEach(() => apiHelpers.setToDefaultListBacklog());

  /**
   * Open the backlog page.
   * Click on three dot option,click the delete option.
   * Click the Cancel button in the delete pop up window.
   * Check that pop up window is closed and no changes is happened.
   */
  it('C93: Cancel button functionality check in the delete pop up window ', { tags: ['Case Board', 'staging'] }, () => {
    backlogPage.verifyCancelInDeletePopUp();
  });

  /**
   * Open the backlog page.
   * Click on three dot option.
   * Click the delete option,Click the delete button in the delete pop up window
   * check that respective list is deleted.
   */
  it('C520: Delete functionality check in the delete pop up window', { tags: ['Case Board', 'staging'] }, () => {
    backlogPage.listFullTitleNameLabel().eq(0).contains('Sentiment Score');
    backlogPage.deleteBacklogList();
    backlogPage.listFullTitleNameLabel().eq(0).not('Sentiment Score');
  });
});
