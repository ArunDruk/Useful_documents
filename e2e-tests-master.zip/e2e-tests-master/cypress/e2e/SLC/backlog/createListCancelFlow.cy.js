import { urlHelpers } from '../../../utils';
import { backlogPage, apiHelpers } from '../../../pages';

describe('Backlog list - Cancel functionality', () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.setToDefaultListBacklog();
    cy.visit(urlHelpers.backlog);
  });

  afterEach(() => apiHelpers.setToDefaultListBacklog());

  /**
   * Open the backlog page.
   * Click on add(plus) button.
   * Add a name to the case list & click next button.
   * Select an option from Rank Cases By & click cancel button.
   * Page should retain the previous state.
   */
  it(' C2195: Cancel button functionality check in the create a list flow after naming ', { tags: ['Case Board', 'staging'] }, () => {
    backlogPage.verifyNewListCancelAfterNaming();
  });

  /**
   * Open the backlog page.
   * Click on add(plus) button,without entering anything cancel the process
   * Page should retain the previous state.
   */
  it('C510: Cancel button functionality checks in the create a list flow ', { tags: ['Case Board', 'staging'] }, () => {
    backlogPage.verifyNewListCancel();
  });
});
