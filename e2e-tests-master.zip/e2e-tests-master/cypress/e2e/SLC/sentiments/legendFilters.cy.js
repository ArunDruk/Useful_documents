import { urlHelpers } from '../../../utils';
import { apiHelpers, filters, sentiments } from '../../../pages';

// TODO: Get 'signal-type' attr for all plots in the heatmap
describe('Sentiments-Legend filters', () => {
  beforeEach(() => {
    cy.loginByApi();

    apiHelpers.resetLegendFilters();
    cy.visit(urlHelpers.experientialMetrics.sentiments);
  });

  afterEach(() => apiHelpers.resetLegendFilters());

  /*
   * Select 'All' case status filter
   * Get 'Negative sentiments' legend filter's count
   * Skip test if count is 0
   * Select the target filter while deselecting the rest
   * Verify that the heatmap is visible the number of plots is equal to the count in the legend filter
   */
  it('C445: should apply only "Negative sentiments"', () => {
    filters.allCaseStatusFilterButton().click();
    cy.waitForLoaders();

    sentiments.getLegendFilterCount('negative').then((count) => {
      if (count === 0) this.skip();

      sentiments.selectLegendFilter('negative');
      sentiments.deselectLegendFilter('positive');
      sentiments.deselectLegendFilter('product feedback');

      sentiments.commonIndividualHeatMapTile().should('be.visible').and('have.length', count);
    });
  });

  /*
   * Select 'All' case status filter
   * Get 'Positive sentiments' legend filter's count
   * Skip test if count is 0
   * Select the target filter while deselecting the rest
   * Verify that the heatmap is visible the number of plots is equal to the count in the legend filter
   */
  it('C446: should apply only "Positive sentiments"', () => {
    filters.allCaseStatusFilterButton().click();
    cy.waitForLoaders();

    sentiments.getLegendFilterCount('positive').then((count) => {
      if (count === 0) this.skip();

      sentiments.selectLegendFilter('positive');
      sentiments.deselectLegendFilter('negative');
      sentiments.deselectLegendFilter('product feedback');

      sentiments.commonIndividualHeatMapTile().should('be.visible').and('have.length', count);
    });
  });

  /*
   * Select 'All' case status filter
   * Get 'Product Feedback' legend filter's count
   * Skip test if count is 0
   * Select the target filter while deselecting the rest
   * Verify that the heatmap is visible the number of plots is equal to the count in the legend filter
   */
  it('C447: should apply only "Product Feedback"', () => {
    filters.allCaseStatusFilterButton().click();
    cy.waitForLoaders();

    sentiments.getLegendFilterCount('product feedback').then((count) => {
      if (count === 0) this.skip();

      sentiments.deselectLegendFilter('negative');
      sentiments.deselectLegendFilter('positive');
      sentiments.selectLegendFilter('product feedback');

      sentiments.commonIndividualHeatMapTile().should('be.visible').and('have.length', count);
    });
  });

  /*
   * Select 'All' case status filter
   * Deselect Negative Sentiments legend filter and verify the same
   * Verify heatmap tile count is equal to positive + prod feedback count
   * Reset all filters to true and revisit the page
   * Repeat steps 2 & 3 but for positive sentiment
   * And, repeat only step 2 but for product feedback
   */
  it('C448: should be able to select multiple combinations of filters', () => {
    filters.allCaseStatusFilterButton().click();
    cy.waitForLoaders();

    sentiments.deselectLegendFilter('negative');
    sentiments.isLegendFilterSelected('negative').should('be.false');
    sentiments.getLegendFilterCount('positive').then((positiveSentimentCount) => {
      sentiments.getLegendFilterCount('product feedback').then((prodFeedbackCount) => {
        sentiments.commonIndividualHeatMapTile().should('have.length', positiveSentimentCount + prodFeedbackCount);
      });
    });
    apiHelpers.resetLegendFilters();
    cy.visit(urlHelpers.experientialMetrics.sentiments);

    sentiments.deselectLegendFilter('positive');
    sentiments.isLegendFilterSelected('positive').should('be.false');
    apiHelpers.resetLegendFilters();
    cy.visit(urlHelpers.experientialMetrics.sentiments);

    sentiments.deselectLegendFilter('product feedback');
    sentiments.isLegendFilterSelected('product feedback').should('be.false');
  });

  /*
   * Select 'All' case status filter
   * Deselect all 3 legend filters
   * Verify a tooltip is displayed saying at least one must be checked
   * Verify the last legend filter that got tried to deselect is still selected
   * Verify heatmap tile count is equal to the selected filter count
   */
  it('C449: should not allow deselecting all at once', () => {
    filters.allCaseStatusFilterButton().click();
    cy.waitForLoaders();

    sentiments.deselectLegendFilter('product feedback');
    sentiments.deselectLegendFilter('positive');
    sentiments.deselectLegendFilter('negative');

    sentiments.sentimentFilterLockTooltip().should('be.visible').and('have.text', 'At least one tab must be checked');
    sentiments.isLegendFilterSelected('negative').should('be.true');
    sentiments.getLegendFilterCount('negative').then((negativeSentimentCount) => {
      sentiments.commonIndividualHeatMapTile().should('have.length', negativeSentimentCount);
    });
  });
});
