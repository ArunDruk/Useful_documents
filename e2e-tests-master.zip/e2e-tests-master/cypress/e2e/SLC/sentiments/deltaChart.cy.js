import moment from 'moment';

import { labelHelper, urlHelpers } from '../../../utils';
import { filters, sentiments } from '../../../pages';

describe('Sentiments-Delta Chart', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.experientialMetrics.sentiments);
  });

  /*
   * Hover over i icon next to Sentiment Score Delta Chart Title
   * Verify that a tooltip with the given text is displayed
   */
  it('C453: should display tooltip on hovering over delta chart i icon', () => {
    const caseLabel = labelHelper.case.toLowerCase();
    const casesLabel = labelHelper.cases.toLowerCase();
    const expectedTooltipText = `Sentiment Score Delta reflects the average difference between the Sentiment \
Score of ${casesLabel} before and after the sentiments depicted in the chart below were detected.If multiple \
sentiments appear within one comment, the delta reflects the net change in Sentiment Score for the comment as a \
whole. If multiple comments from one ${caseLabel} appear in the chart, the change in Sentiment Score for all comments \
is included.Positive sentiments tend to increase Sentiment Score and Negative sentiments tend to decrease Sentiment Score. \
Very Negative values tend to cause the score to decrease more than Negative, and so on.It is worth noting that the same \
type of sentiment could have different deltas in different ${casesLabel}. Negative sentiments in a ${caseLabel} where \
Sentiment Score is already very low may not decrease it as much as Negative sentiments in a ${caseLabel} where Sentiment \
Score is very high, and vice versa.`;

    sentiments.deltaChartInfoIcon().realHover({ pointer: 'mouse' });
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);

    sentiments.infoIconTooltip().should('be.visible').and('have.text', expectedTooltipText);
  });

  /*
   * Select 'All' case status filter
   * Hover over the topdown arrow to the right of Sentiment Score Delta chart title
   * Verify tooltip is displayed and has the same start & end date as the datepicker
   */
  it('C454: should top down arrow', () => {
    // get the start and end date for the last 29 days
    const startDate = moment().subtract(29, 'days').format('DD MMM');
    const endDate = moment().format('DD MMM');

    filters.allCaseStatusFilterButton().click();
    cy.waitForLoaders();

    sentiments.deltaChartTopDownArrow().realHover({ pointer: 'mouse' });
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);

    // TODO: Add validations for sentiments & case count once SLC-28608 is fixed
    sentiments.deltaChartTopDownArrowTooltip().should('be.visible').and('contain.text', `${startDate}-${endDate}`);
  });
});
