import moment from 'moment';

import { targetDatabase, urlHelpers } from '../../../utils';
import { datePicker, sentiments } from '../../../pages';

describe('Sentiments-Date Picker', () => {
  beforeEach(() => {
    cy.intercept('POST', `api/cache/${targetDatabase}/spans/data`).as('fetchSpansData');

    cy.loginByApi();
    cy.visit(urlHelpers.experientialMetrics.sentiments);
  });

  /*
   * Open Date Picker
   * Select the date that was 29 days ago from today (It's 29 and not 23 because of the viewport sizes)
   * Click Apply button
   * Verify date picker dropdown has the date that was selected
   * Verify end date label is 'Today'
   */
  it('C442: should check date filter', () => {
    const startOfMonth = moment().subtract(29, 'days');

    sentiments.datePickerDropdown().click();
    datePicker.calendarDayButton(startOfMonth.format('MMMM D,')).click();
    sentiments.datePickerApplyButton().click();
    cy.wait('@fetchSpansData');

    sentiments.datePickerDropdown().should('have.text', startOfMonth.format('MMM D, YYYY'));
    sentiments.endDateLabel().should('have.text', 'Today');
  });

  /*
   * Open Date Picker
   * Click the left arrow twice
   * Select the 1st day of the month that's in view
   * Click Apply button
   * Verify date picker dropdown doesn't have the expected date (current date - N days)
   * Again open date picker and reset to the last N days
   * Verify date picker dropdown has the expected start date (current date - N days)
   * Verify end date label is 'Today'
   */
  it('C443: should reset to last N days', () => {
    const expectedStartDate = moment().subtract(29, 'days').format('MMM D, YYYY');

    sentiments.datePickerDropdown().click();
    datePicker.previousMonthButton().click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    datePicker.previousMonthButton().click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    datePicker.calendarDayButton(' 1,').click();
    sentiments.datePickerApplyButton().click();
    cy.wait('@fetchSpansData');

    sentiments.datePickerDropdown().should('not.have.text', expectedStartDate);

    sentiments.datePickerDropdown().click();
    sentiments.datePickerResetDaysButton().click();
    cy.wait('@fetchSpansData');

    sentiments.datePickerDropdown().should('have.text', expectedStartDate);
    sentiments.endDateLabel().should('have.text', 'Today');
  });
});
