import { urlHelpers } from '../../../utils';
import { filters, sentiments } from '../../../pages';

describe('Sentiments Smoke', { tags: ['smoke', 'sanity'] }, () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.experientialMetrics.sentiments);
  });

  it('C2270: should load heatmap chart', () => {
    sentiments.getDetectedSentimentsCount().then((sentimentCount) => {
      if (sentimentCount !== 0) {
        sentiments.commonIndividualHeatMapTile().should('be.visible');
      } else {
        cy.contains('No sentiments found').should('be.visible');
      }
    });
  });

  it('C2271: should load sentiments page', () => {
    filters.allCaseStatusFilterButton().should('be.visible');
    sentiments.datePickerDropdown().should('be.visible');
    sentiments.commonLegendFilterButton('negative').should('be.visible');
    sentiments.deltaChartInfoIcon().should('be.visible');
  });
});
