import { urlHelpers } from '../../../utils';
import { filters, sentiments, supportHub } from '../../../pages';

describe('Sentiments-Include Filter', { tags: ['sentiments', 'staging', 'prod'] }, () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.experientialMetrics.sentiments);
  });

  /*
   * Select 'All' case status filter
   * Check 'Incoming messages' in the include filter and uncheck the other two options
   * Click the first heatmap tile
   * Verify Inbound count is not 0 in SupportHub timeline
   *
   * Repeat the above steps for Outbound & case note options
   * NOTE: Ignore validation if no sentiments are found for case notes
   */
  it('C456: should filter cases by inbound, outbound & case notes', () => {
    cy.waitForLoaders();
    filters.getStartedButtonSentimentsModule();
    filters.allCaseStatusFilterButton().click();
    cy.waitForLoaders();
    sentiments.checkIncludeFilter('Incoming messages');
    sentiments.uncheckIncludeFilter('Outgoing messages');
    sentiments.uncheckIncludeFilter('Case Notes');
    sentiments.commonIndividualHeatMapTile().first().click();
    cy.waitForLoaders();
    supportHub.timelineStatsLabel().should('not.have.text', '0 Inbound');
    supportHub.closeButton().click();
    filters.allCaseStatusFilterButton().click();
    cy.waitForLoaders();
    sentiments.checkIncludeFilter('Outgoing messages');
    sentiments.uncheckIncludeFilter('Incoming messages');
    sentiments.uncheckIncludeFilter('Case Notes');
    sentiments.commonIndividualHeatMapTile().first().click();
    cy.waitForLoaders();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(3000);
    supportHub.timelineStatsLabel().should('not.have.text', '0 Outbound');
    supportHub.closeButton().click();
    filters.allCaseStatusFilterButton().click();
    cy.waitForLoaders();
    sentiments.checkIncludeFilter('Case Notes');
    sentiments.uncheckIncludeFilter('Incoming messages');
    sentiments.uncheckIncludeFilter('Outgoing messages');
    cy.get('body').then((body) => {
      if (body.find('[data-testid^=supportHub-sentimentChart]').length) {
        sentiments.commonIndividualHeatMapTile().first().click();
        cy.waitForLoaders();

        supportHub.timelineStatsLabel().should('not.contain.text', '0 Internal Notes');
        supportHub.closeButton().click();
      }
    });
  });
});
