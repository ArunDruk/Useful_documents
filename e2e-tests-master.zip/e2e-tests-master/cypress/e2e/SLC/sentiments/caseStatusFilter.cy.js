import { urlHelpers } from '../../../utils';
import { filters, sentiments, supportHub } from '../../../pages';

describe('Sentiments-Case Status Filter', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.experientialMetrics.sentiments);
  });

  /*
   * Check header ticket count is visible
   * Click 'All' case status filter and get count
   * Click 'Open' case status filter
   * Click an individual entry in the graph and verify case status is not 'Closed'
   * Get open tickets count
   * Click 'Closed' case status filter and get count
   * Log all 3 counts
   * Verify Open count = All - Closed ticket count (to escape stale cache using a range)
   */
  it('C439: should check "Open" case status filter', () => {
    sentiments.headerTicketCountLabel().should('be.visible');

    filters.allCaseStatusFilterButton().click();
    cy.waitForLoaders();

    sentiments.getHeaderTicketCount().then((allCaseCount) => {
      filters.openCaseStatusFilterButton().click();
      cy.waitForLoaders();

      sentiments.commonIndividualHeatMapTile().first().click();
      cy.waitForLoaders();
      supportHub.baseContainer().should('be.visible');
      supportHub.nowHeaderLabel().should('not.contain.text', 'Closed');
      supportHub.closeButton().click();

      sentiments.getHeaderTicketCount().then((openCaseCount) => {
        filters.closedCaseStatusFilterButton().click();
        cy.waitForLoaders();

        sentiments.getHeaderTicketCount().then((closedCaseCount) => {
          const expectedCount = allCaseCount - closedCaseCount;

          cy.log(`All count = ${allCaseCount}`);
          cy.log(`Open count = ${openCaseCount}`);
          cy.log(`Closed count = ${closedCaseCount}`);

          expect(openCaseCount).to.be.within(expectedCount - 10, expectedCount + 10);
        });
      });
    });
  });

  /*
   * Check header ticket count is visible
   * Click 'All' case status filter and get count
   * Click 'Open' case status filter and get count
   * Click 'Closed' case status filter
   * Click an individual entry in the graph and verify case status is 'Closed'
   * Get closed tickets count
   * Log all 3 counts
   * Verify Closed count = All - Open ticket count (to escape stale cache using a range)
   */
  it('C440: should check "Closed" case status filter', () => {
    sentiments.headerTicketCountLabel().should('be.visible');

    filters.allCaseStatusFilterButton().click();
    cy.waitForLoaders();

    sentiments.getHeaderTicketCount().then((allCaseCount) => {
      filters.openCaseStatusFilterButton().click();
      cy.waitForLoaders();

      sentiments.getHeaderTicketCount().then((openCaseCount) => {
        filters.closedCaseStatusFilterButton().click();
        cy.waitForLoaders();

        sentiments.commonIndividualHeatMapTile().first().click();
        cy.waitForLoaders();
        supportHub.baseContainer().should('be.visible');
        supportHub.nowHeaderLabel().should('contain.text', 'Closed');
        supportHub.closeButton().click();

        sentiments.getHeaderTicketCount().then((closedCaseCount) => {
          const expectedCount = allCaseCount - openCaseCount;

          cy.log(`All count = ${allCaseCount}`);
          cy.log(`Open count = ${openCaseCount}`);
          cy.log(`Closed count = ${closedCaseCount}`);

          expect(closedCaseCount).to.be.within(expectedCount - 10, expectedCount + 10);
        });
      });
    });
  });

  /*
   * Check header ticket count is visible
   * Click 'All' case status filter and get count
   * Click 'Open' case status filter and get count
   * Click 'Closed' case status filter and get count
   * Log all 3 counts
   * Verify All count = Open + Closed ticket count (to escape stale cache using a range)
   */
  it('C441: should check "All" case status filter', () => {
    sentiments.headerTicketCountLabel().should('be.visible');

    filters.allCaseStatusFilterButton().click();
    cy.waitForLoaders();

    sentiments.getHeaderTicketCount().then((allCaseCount) => {
      filters.openCaseStatusFilterButton().click();
      cy.waitForLoaders();

      sentiments.getHeaderTicketCount().then((openCaseCount) => {
        filters.closedCaseStatusFilterButton().click();
        cy.waitForLoaders();

        sentiments.getHeaderTicketCount().then((closedCaseCount) => {
          const expectedCount = openCaseCount + closedCaseCount;

          cy.log(`All count = ${allCaseCount}`);
          cy.log(`Open count = ${openCaseCount}`);
          cy.log(`Closed count = ${closedCaseCount}`);

          expect(allCaseCount).to.be.within(expectedCount - 10, expectedCount + 10);
        });
      });
    });
  });
});
