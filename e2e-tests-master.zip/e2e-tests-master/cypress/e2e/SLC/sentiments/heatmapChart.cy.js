import moment from 'moment';

import { filters, sentiments, supportHub } from '../../../pages';
import { urlHelpers } from '../../../utils';

describe('Sentiments-Heatmap Chart', { tags: ['sentiments', 'staging', 'prod'] }, () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.experientialMetrics.sentiments);
  });

  /*
   * Select 'All' case status filter
   * Open the last tile in SupportHub
   * Fetch the case id and close SH
   * Hover over the last tile in the sentiment heatmap chart
   * Verify ticket details tooltip is visible and has the case id
   */
  it('C450: should display ticket details tooltip on hovering over heatmap tile', () => {
    filters.allCaseStatusFilterButton().click();
    cy.waitForLoaders();

    sentiments.commonIndividualHeatMapTile().last().click({ force: true });
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();

    supportHub
      .caseIdLabel()
      .invoke('text')
      .then((caseId) => {
        supportHub.closeButton().click();

        sentiments.commonIndividualHeatMapTile().last().realHover({ pointer: 'mouse' });
        sentiments.ticketDetailsTooltip().should('be.visible').and('contain.text', caseId);
      });
  });

  /*
   * Select 'All' case status filter
   * Hover over the first heatmap tile
   * Fetch the detected sentiment text from the ticket details tooltip
   * Click the first heatmap tile.
   * Verify SupportHub is visible
   * Verify that the detected sentiment is present in the sentiment card section
   */
  it('C452: should open ticket from heatmap tile', () => {
    filters.allCaseStatusFilterButton().click();
    cy.waitForLoaders();

    sentiments.commonIndividualHeatMapTile().first().trigger('mouseover');
    sentiments
      .ticketDetailsTooltipSentimentLabel()
      .invoke('text')
      .then((sentimentText) => {
        sentiments.commonIndividualHeatMapTile().first().click();
        cy.waitForLoaders();

        supportHub.baseContainer().should('be.visible');
        supportHub.sentimentCardSentimentLabelByText(sentimentText).should('exist');
      });
  });

  it('C455: should linearly scroll through graph with arrow buttons', () => {
    const expectedStartDateOnLeftScroll = moment().subtract(59, 'days').format('MMM D, YYYY');
    const expectedStartDateOnRightScroll = moment().subtract(29, 'days').format('MMM D, YYYY');

    sentiments.leftSliderButton().click();
    cy.waitForLoaders();

    sentiments.datePickerDropdown().should('have.text', expectedStartDateOnLeftScroll);

    sentiments.rightSliderButton().click();
    cy.waitForLoaders();

    sentiments.datePickerDropdown().should('have.text', expectedStartDateOnRightScroll);
  });
});
