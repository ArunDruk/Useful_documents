import { assignmentHourShiftBarSelector, workingHourShiftBarSelector, getShiftId, randId } from './support';
import { urlHelpers } from '../../../utils';
import { datePicker, shiftManagement } from '../../../pages';

beforeEach(() => {
  cy.intercept('POST', 'api/v2/group/search?*').as('waitForShifts');
  cy.intercept('POST', 'api/v2/availability/query').as('waitForAvailability');

  cy.loginByApi();
  cy.visit(urlHelpers.shiftCalendar);

  cy.wait('@waitForShifts');
  cy.wait('@waitForAvailability');
});

it('C6583: should create shift from UI', { tags: 'Shifts' }, () => {
  const shiftName = `Test shift ${randId()}`;

  shiftManagement.addShiftButton().click();
  shiftManagement.createShiftDialogNameTextField().type(shiftName);
  // enter custom assignment hours start & end time
  shiftManagement.createShiftDialogAssignmentHourFromTextField().clear().type('11:00 AM');
  shiftManagement.createShiftDialogAssignmentHourToTextField().clear().type('8:00 PM');
  // enter custom working hours start & end time
  shiftManagement.createShiftDialogWorkingHoursFromTextField().clear().type('2:00 PM');
  shiftManagement.createShiftDialogWorkingHoursToTextField().clear().type('11:00 PM');
  // deselect Thu, Fri
  shiftManagement.createShiftDialogtWeekdayInputField('thu').click();
  shiftManagement.createShiftDialogtWeekdayInputField('fri').click();

  shiftManagement.createShiftDialogCreateButton().click();

  cy.get(assignmentHourShiftBarSelector(shiftName)).should('exist').should('have.length', 3);
  cy.get(assignmentHourShiftBarSelector(shiftName)).first().rightclick();
  shiftManagement
    .createShiftDialogInfoIconTooltip()
    .should('be.visible')
    .and('contain.text', shiftName)
    .and('contain.text', 'Mon-Wed')
    .and('contain.text', '11:00 AM-08:00 PM')
    .and('contain.text', '02:00 PM-11:00 PM');

  getShiftId(shiftName).then((shiftId) => cy.slcHelpers.deleteVgroup(shiftId));
});

it('C6586: should select & deselect occurrences', { tags: 'Shifts' }, () => {
  const shiftName = `Test shift ${randId()}`;

  shiftManagement.addShiftButton().click();
  shiftManagement.createShiftDialogNameTextField().type(shiftName);
  // deselect Mon, Wed & Fri
  shiftManagement.createShiftDialogtWeekdayInputField('mon').click();
  shiftManagement.createShiftDialogtWeekdayInputField('wed').click();
  shiftManagement.createShiftDialogtWeekdayInputField('fri').click();
  // select Sat
  shiftManagement.createShiftDialogtWeekdayInputField('sat').click();

  shiftManagement.createShiftDialogCreateButton().click();

  cy.get(assignmentHourShiftBarSelector(shiftName)).should('exist').should('have.length', 3);
  cy.get(assignmentHourShiftBarSelector(shiftName)).first().rightclick();
  shiftManagement.createShiftDialogInfoIconTooltip().should('be.visible').and('contain.text', shiftName).and('contain.text', 'Tue,Thu,Sat');

  getShiftId(shiftName).then((shiftId) => cy.slcHelpers.deleteVgroup(shiftId));
});

it('C6585: should customize assignment & working hours', { tags: 'Shifts' }, () => {
  const shiftName = `Test shift ${randId()}`;

  shiftManagement.addShiftButton().click();
  shiftManagement.createShiftDialogNameTextField().type(shiftName);
  // enter custom assignment hours start & end time
  shiftManagement.createShiftDialogCustomizeAssignmentHoursCheckbox().check({ force: true });
  shiftManagement.createShiftDialogAssignmentHoursTueFromSlot1().clear().type('12:00 pm');
  shiftManagement.createShiftDialogAssignmentHoursTueToSlot1().clear().type('9:00 pm');
  // enter custom working hours start & end time
  shiftManagement.createShiftDialogCustomizeWorkingHoursCheckbox().check({ force: true });
  shiftManagement.createShiftDialogWorkingHoursFriFromSlot1().clear().type('11:00 am');
  shiftManagement.createShiftDialogWorkingHoursFriToSlot1().clear().type('8:00 pm');

  shiftManagement.createShiftDialogCreateButton().click({ force: true });

  cy.get(assignmentHourShiftBarSelector(shiftName)).should('exist');
  cy.get(assignmentHourShiftBarSelector(shiftName)).eq(1).rightclick();
  shiftManagement
    .createShiftDialogInfoIconTooltip()
    .should('be.visible')
    .and('contain.text', shiftName)
    .and('contain.text', 'Mon 09:00 AM-05:00 PM')
    .and('contain.text', 'Tue 12:00 PM-09:00 PM')
    .and('contain.text', 'Thu 09:00 AM-05:00 PM')
    .and('contain.text', 'Fri 11:00 AM-08:00 PM');

  getShiftId(shiftName).then((shiftId) => cy.slcHelpers.deleteVgroup(shiftId));
});

/*
 * Visit the Shift Management module
 * Add a new shift
 * Change the timezone
 * Verify that the new shift only appear for this week and not next week
 * Revert the timezone to local
 * Verify that the shift alignment changes as per the timezone change
 */
it('C13304: Add shift from non local timezone and switching to local timezone', { tags: 'Shifts' }, () => {
  const shiftName = `Test shift ${randId()}`;

  shiftManagement.timezoneSwitcherTrigger().click();
  shiftManagement.timezoneSwitcherSearchTextField().clear().type('Tokyo');
  shiftManagement.timezoneSwitcherSearchResultListItem().eq(1).click();
  cy.waitForLoaders();

  shiftManagement.addShiftButton().click();
  shiftManagement.createShiftDialogNameTextField().type(shiftName);

  shiftManagement.createShiftDialogAssignmentHourFromTextField().clear().type('6:00 AM');
  shiftManagement.createShiftDialogAssignmentHourToTextField().clear().type('4:00 PM');

  shiftManagement.copyAssignmentHoursButton().click({ force: true });

  shiftManagement.createShiftDialogtWeekdayInputField('sun').click();
  shiftManagement.createShiftDialogtWeekdayInputField('fri').click();

  shiftManagement.createShiftDialogCreateButton().click();

  datePicker.datePickerTrigger().eq(0).click();
  datePicker.lastWeekRadioButton().click();
  datePicker.applyButton().click();
  datePicker.datePickerTrigger().parent().should('have.text', 'Last week');

  cy.get(assignmentHourShiftBarSelector(shiftName)).should('not.exist');

  datePicker.datePickerTrigger().eq(0).click();
  datePicker.thisWeekRadioButton().click();
  datePicker.applyButton().click();
  datePicker.datePickerTrigger().parent().should('have.text', 'This week');

  // checking the shift bar alignment before changing the timezone
  cy.get(assignmentHourShiftBarSelector(shiftName))
    .first()
    .parent()
    .then((before) => {
      const alignmentBefore = before[0].style.left;
      // changing the timezone
      shiftManagement.timezoneSwitcherTrigger().click({ force: true });
      shiftManagement.timezoneSwitcherSearchTextField().clear().type('Calcutta');
      shiftManagement.timezoneSwitcherSearchResultListItem().last().click();
      cy.waitForLoaders();
      // checking that the bar is shifted when the timezone is changed
      cy.get(assignmentHourShiftBarSelector(shiftName))
        .first()
        .parent()
        .then((after) => {
          const alignmentAfter = after[0].style.left;
          assert.notEqual(alignmentBefore, alignmentAfter);
        });
      cy.get(assignmentHourShiftBarSelector(shiftName)).should('exist').first().click();
      shiftManagement.createShiftDialogAssignmentHourFromTextField().invoke('val').should('equal', '02:30 am');
      shiftManagement.createShiftDialogAssignmentHourToTextField().invoke('val').should('equal', '12:30 pm');
    });

  getShiftId(shiftName).then((shiftId) => cy.slcHelpers.deleteVgroup(shiftId));
});

/*
 * Visit the Shift Management module
 * Add a new shift
 * Change the timezone
 * Edit the shift and extend the working and assignment hours by 1 hour each
 * Verify that the shift bar width changes
 */
it('C13302: Edit a shift from a different timezone', { tags: 'Shifts' }, () => {
  const shiftName = `Test shift ${randId()}`;

  shiftManagement.timezoneSwitcherTrigger().click({ force: true });
  shiftManagement.timezoneSwitcherSearchTextField().clear().type('Calcutta');
  shiftManagement.timezoneSwitcherSearchResultListItem().last().click();
  cy.waitForLoaders();

  shiftManagement.addShiftButton().click();
  shiftManagement.createShiftDialogNameTextField().type(shiftName);

  shiftManagement.createShiftDialogAssignmentHourFromTextField().clear().type('6:00 AM');
  shiftManagement.createShiftDialogAssignmentHourToTextField().clear().type('4:00 PM');

  shiftManagement.copyAssignmentHoursButton().click({ force: true });

  shiftManagement.createShiftDialogtWeekdayInputField('sun').click();
  shiftManagement.createShiftDialogtWeekdayInputField('fri').click();

  shiftManagement.createShiftDialogCreateButton().click();
  cy.waitForLoaders();

  shiftManagement.timezoneSwitcherTrigger().click({ force: true });
  shiftManagement.timezoneSwitcherSearchTextField().clear().type('Tokyo');
  shiftManagement.timezoneSwitcherSearchResultListItem().eq(1).click();
  cy.waitForLoaders();

  // checking the shift bar width before updating hours
  cy.get(assignmentHourShiftBarSelector(shiftName))
    .first()
    .parent()
    .then((before) => {
      const widthBefore = parseInt(before[0].style.width.replace('%', ''), 10);
      // updating hours
      cy.get(assignmentHourShiftBarSelector(shiftName)).should('exist').first().click();
      shiftManagement.createShiftDialogAssignmentHourFromTextField().invoke('val').should('equal', '09:30 am');
      shiftManagement.createShiftDialogAssignmentHourToTextField().invoke('val').should('equal', '07:30 pm');
      shiftManagement
        .createShiftDialogAssignmentHourToTextField()
        .invoke('val')
        .then((endTime) => {
          const updatedEndTime = parseFloat(endTime, 10) + 1;

          shiftManagement.createShiftDialogAssignmentHourToTextField().clear().type(`${updatedEndTime}:00 PM`);
          shiftManagement.copyAssignmentHoursButton().click({ force: true });
          shiftManagement.createShiftDialogSaveButton().click();
          cy.waitForLoaders();

          // checking that the bar width has increased when an hour is added
          cy.get(assignmentHourShiftBarSelector(shiftName))
            .first()
            .parent()
            .should((after) => {
              const widthAfter = parseInt(after[0].style.width.replace('%', ''), 10);
              expect(widthBefore).to.be.below(widthAfter);
            });
        });

      getShiftId(shiftName).then((shiftId) => cy.slcHelpers.deleteVgroup(shiftId));
    });
});

/*
 * Visit the Shift Management module
 * Change the timezone
 * Add a shift
 * Edit the shift and update the start and end time of working and assignment hours by 1 hour each
 * Verify that the shift bar width chages
 */
it('C13303: Add and edit a shift from a non local timezone', { tags: 'Shifts' }, () => {
  const shiftName = `Test shift ${randId()}`;

  shiftManagement.timezoneSwitcherTrigger().click({ force: true });
  shiftManagement.timezoneSwitcherSearchTextField().clear().type('Tokyo');
  shiftManagement.timezoneSwitcherSearchResultListItem().eq(1).click();
  cy.waitForLoaders();

  shiftManagement.addShiftButton().click();
  shiftManagement.createShiftDialogNameTextField().type(shiftName);

  shiftManagement.createShiftDialogAssignmentHourFromTextField().clear().type('6:00 AM');
  shiftManagement.createShiftDialogAssignmentHourToTextField().clear().type('4:00 PM');

  shiftManagement.copyAssignmentHoursButton().click({ force: true });

  shiftManagement.createShiftDialogtWeekdayInputField('sun').click();
  shiftManagement.createShiftDialogtWeekdayInputField('fri').click();

  shiftManagement.createShiftDialogCreateButton().click();
  cy.waitForLoaders();

  // checking the shift bar width before updating hours
  cy.get(assignmentHourShiftBarSelector(shiftName))
    .first()
    .parent()
    .then((before) => {
      const widthBefore = parseInt(before[0].style.width.replace('%', ''), 10);
      // updating hours
      cy.get(assignmentHourShiftBarSelector(shiftName)).should('exist').first().click();

      shiftManagement
        .createShiftDialogAssignmentHourFromTextField()
        .invoke('val')
        .then((startTime) => {
          const updatedStartTime = parseFloat(startTime, 10) - 1;
          shiftManagement.createShiftDialogAssignmentHourFromTextField().clear().type(`${updatedStartTime}:00 AM`);

          shiftManagement
            .createShiftDialogAssignmentHourToTextField()
            .invoke('val')
            .then((endTime) => {
              const updatedEndTime = parseFloat(endTime, 10) + 1;

              shiftManagement.createShiftDialogAssignmentHourToTextField().clear().type(`${updatedEndTime}:00 PM`);
              shiftManagement.copyAssignmentHoursButton().click({ force: true });
              shiftManagement.createShiftDialogSaveButton().click();
              cy.waitForLoaders();

              // checking that the bar width has increased when an hour is added
              cy.get(assignmentHourShiftBarSelector(shiftName))
                .first()
                .parent()
                .should((after) => {
                  const widthAfter = parseInt(after[0].style.width.replace('%', ''), 10);
                  expect(widthBefore).to.be.below(widthAfter);
                });
            });

          getShiftId(shiftName).then((shiftId) => cy.slcHelpers.deleteVgroup(shiftId));
        });
    });
});

/*
 * Visit the Shift Management module
 * Add a shift with assignment hours as 6AM-4PM and assignment hours as 5AM-5PM
 * Click the working hours trigger
 * Verify the shift bar width for assignment and working hours
 */
it('C6816: Enabling Working hour in shift calendar', { tags: 'Shifts' }, () => {
  const shiftName = `Test shift ${randId()}`;

  shiftManagement.addShiftButton().click();
  shiftManagement.createShiftDialogNameTextField().type(shiftName);

  shiftManagement.createShiftDialogAssignmentHourFromTextField().clear().type('6:00 AM');
  shiftManagement.createShiftDialogAssignmentHourToTextField().clear().type('4:00 PM');

  shiftManagement.createShiftDialogWorkingHoursFromTextField().clear().type('5:00 AM');
  shiftManagement.createShiftDialogWorkingHoursToTextField().clear().type('5:00 PM');
  shiftManagement.createShiftDialogtWeekdayInputField('fri').click();
  shiftManagement.createShiftDialogtWeekdayInputField('sun').click();
  shiftManagement.createShiftDialogCreateButton().click();
  cy.waitForLoaders();

  // checking the shift bar width before enabling working hours
  cy.get(assignmentHourShiftBarSelector(shiftName))
    .first()
    .parent()
    .then((before) => {
      const widthBefore = parseInt(before[0].style.width.replace('%', ''), 10);
      // updating hours
      cy.get(assignmentHourShiftBarSelector(shiftName)).should('exist').first().click();
      shiftManagement.createShiftDialogAssignmentHourFromTextField().invoke('val').should('equal', '06:00 am');
      shiftManagement.createShiftDialogAssignmentHourToTextField().invoke('val').should('equal', '04:00 pm');
      shiftManagement.createShiftDialogWorkingHoursFromTextField().invoke('val').should('equal', '05:00 am');
      shiftManagement.createShiftDialogWorkingHoursToTextField().invoke('val').should('equal', '05:00 pm');

      shiftManagement.workingHoursTrigger().click();
      cy.waitForLoaders();

      cy.get(workingHourShiftBarSelector(shiftName))
        .first()
        .should((after) => {
          const widthAfter = parseInt(after[0].style.width.replace('%', ''), 10);
          expect(widthBefore).to.be.below(widthAfter);
        });

      getShiftId(shiftName).then((shiftId) => cy.slcHelpers.deleteVgroup(shiftId));
    });
});

/*
 * Visit the Shift Management module
 * Create a shift with default values
 * Verify the default values
 * Update the shift to add and remove days
 * Verify the updated values
 */
it('C37658: Add a shift with Weekday occurrence (Default)', { tags: 'Shifts' }, () => {
  const shiftName = `Test shift ${randId()}`;

  shiftManagement.addShiftButton().click();
  shiftManagement.createShiftDialogNameTextField().type(shiftName);

  shiftManagement
    .createShiftDialogColorPickerDropdown()
    .invoke('attr', 'data-color')
    .then((defaultColor) => {
      shiftManagement.createShiftDialogCreateButton().click();
      cy.waitForLoaders();

      cy.get(assignmentHourShiftBarSelector(shiftName)).should('exist').should('have.length', 5);
      cy.get(assignmentHourShiftBarSelector(shiftName)).parent().invoke('attr', 'style').should('contain', defaultColor);

      datePicker.datePickerTrigger().eq(0).click();
      datePicker.lastWeekRadioButton().click();
      datePicker.applyButton().click();
      datePicker.datePickerTrigger().parent().should('have.text', 'Last week');

      cy.get(assignmentHourShiftBarSelector(shiftName)).should('not.exist');

      datePicker.datePickerTrigger().eq(0).click();
      datePicker.thisWeekRadioButton().click();
      datePicker.applyButton().click();
      datePicker.datePickerTrigger().parent().should('have.text', 'This week');

      cy.get(assignmentHourShiftBarSelector(shiftName)).should('exist').first().click();
      // checking default hours
      shiftManagement.createShiftDialogAssignmentHourFromTextField().invoke('val').should('equal', '09:00 am');
      shiftManagement.createShiftDialogAssignmentHourToTextField().invoke('val').should('equal', '05:00 pm');
      shiftManagement.createShiftDialogWorkingHoursFromTextField().invoke('val').should('equal', '09:00 am');
      shiftManagement.createShiftDialogWorkingHoursToTextField().invoke('val').should('equal', '05:00 pm');

      // checking default days
      shiftManagement.createShiftDialogtWeekdayInputField('mon').invoke('attr', 'data-status').should('equal', 'checked');
      shiftManagement.createShiftDialogtWeekdayInputField('tue').invoke('attr', 'data-status').should('equal', 'checked');
      shiftManagement.createShiftDialogtWeekdayInputField('wed').invoke('attr', 'data-status').should('equal', 'checked');
      shiftManagement.createShiftDialogtWeekdayInputField('thu').invoke('attr', 'data-status').should('equal', 'checked');
      shiftManagement.createShiftDialogtWeekdayInputField('fri').invoke('attr', 'data-status').should('equal', 'checked');
      shiftManagement.createShiftDialogtWeekdayInputField('sat').invoke('attr', 'data-status').should('equal', 'unchecked');
      shiftManagement.createShiftDialogtWeekdayInputField('sun').invoke('attr', 'data-status').should('equal', 'unchecked');

      // updating days
      shiftManagement.createShiftDialogtWeekdayInputField('sun').click();
      shiftManagement.createShiftDialogtWeekdayInputField('sat').click();
      shiftManagement.createShiftDialogtWeekdayInputField('mon').click();
      shiftManagement.createShiftDialogtWeekdayInputField('wed').click();
      shiftManagement.createShiftDialogtWeekdayInputField('fri').click();

      shiftManagement.createShiftDialogSaveButton().click();
      cy.waitForLoaders();

      datePicker.datePickerTrigger().eq(0).click();
      datePicker.nextWeekRadioButton().click();
      datePicker.applyButton().click();
      datePicker.datePickerTrigger().parent().should('have.text', 'Next week');

      cy.get(assignmentHourShiftBarSelector(shiftName)).should('exist').should('have.length', 4);

      cy.get(assignmentHourShiftBarSelector(shiftName)).should('exist').first().click();

      shiftManagement.createShiftDialogAssignmentHourFromTextField().invoke('val').should('equal', '09:00 am');
      shiftManagement.createShiftDialogAssignmentHourToTextField().invoke('val').should('equal', '05:00 pm');
      shiftManagement.createShiftDialogWorkingHoursFromTextField().invoke('val').should('equal', '09:00 am');
      shiftManagement.createShiftDialogWorkingHoursToTextField().invoke('val').should('equal', '05:00 pm');

      // checking updated days
      shiftManagement.createShiftDialogtWeekdayInputField('mon').invoke('attr', 'data-status').should('equal', 'unchecked');
      shiftManagement.createShiftDialogtWeekdayInputField('tue').invoke('attr', 'data-status').should('equal', 'checked');
      shiftManagement.createShiftDialogtWeekdayInputField('wed').invoke('attr', 'data-status').should('equal', 'unchecked');
      shiftManagement.createShiftDialogtWeekdayInputField('thu').invoke('attr', 'data-status').should('equal', 'checked');
      shiftManagement.createShiftDialogtWeekdayInputField('fri').invoke('attr', 'data-status').should('equal', 'unchecked');
      shiftManagement.createShiftDialogtWeekdayInputField('sat').invoke('attr', 'data-status').should('equal', 'checked');
      shiftManagement.createShiftDialogtWeekdayInputField('sun').invoke('attr', 'data-status').should('equal', 'checked');

      getShiftId(shiftName).then((shiftId) => cy.slcHelpers.deleteVgroup(shiftId));
    });
});

/*
 * Visit the Shift Management module
 * Create a shift with custom values
 * Verify custom hours and days
 */
it('C37659: Add a shift with custom Weekday selection in occurrence', { tags: 'Shifts' }, () => {
  const shiftName = `Test shift ${randId()}`;

  shiftManagement.addShiftButton().click();
  shiftManagement.createShiftDialogNameTextField().type(shiftName);

  shiftManagement.createShiftDialogAssignmentHourFromTextField().clear().type('6:00 AM');
  shiftManagement.createShiftDialogAssignmentHourToTextField().clear().type('4:00 PM');

  shiftManagement.copyAssignmentHoursButton().click({ force: true });

  shiftManagement.createShiftDialogtWeekdayInputField('sun').click();
  shiftManagement.createShiftDialogtWeekdayInputField('fri').click();

  shiftManagement.createShiftDialogColorPickerDropdown().click();
  shiftManagement.createShiftDialogColorItem().last().click();

  shiftManagement
    .createShiftDialogColorPickerDropdown()
    .invoke('attr', 'data-color')
    .then((selectedColor) => {
      shiftManagement.createShiftDialogCreateButton().click();
      cy.waitForLoaders();

      cy.get(assignmentHourShiftBarSelector(shiftName)).parent().invoke('attr', 'style').should('contain', selectedColor);

      datePicker.datePickerTrigger().eq(0).click();
      datePicker.lastWeekRadioButton().click();
      datePicker.applyButton().click();
      datePicker.datePickerTrigger().parent().should('have.text', 'Last week');

      cy.get(assignmentHourShiftBarSelector(shiftName)).should('not.exist');

      datePicker.datePickerTrigger().eq(0).click();
      datePicker.thisWeekRadioButton().click();
      datePicker.applyButton().click();
      datePicker.datePickerTrigger().parent().should('have.text', 'This week');

      cy.get(assignmentHourShiftBarSelector(shiftName)).should('exist').first().click();
      // checking custom hours
      shiftManagement.createShiftDialogAssignmentHourFromTextField().invoke('val').should('equal', '06:00 am');
      shiftManagement.createShiftDialogAssignmentHourToTextField().invoke('val').should('equal', '04:00 pm');
      shiftManagement.createShiftDialogWorkingHoursFromTextField().invoke('val').should('equal', '06:00 am');
      shiftManagement.createShiftDialogWorkingHoursToTextField().invoke('val').should('equal', '04:00 pm');

      // checking custom days
      shiftManagement.createShiftDialogtWeekdayInputField('mon').invoke('attr', 'data-status').should('equal', 'checked');
      shiftManagement.createShiftDialogtWeekdayInputField('tue').invoke('attr', 'data-status').should('equal', 'checked');
      shiftManagement.createShiftDialogtWeekdayInputField('wed').invoke('attr', 'data-status').should('equal', 'checked');
      shiftManagement.createShiftDialogtWeekdayInputField('thu').invoke('attr', 'data-status').should('equal', 'checked');
      shiftManagement.createShiftDialogtWeekdayInputField('fri').invoke('attr', 'data-status').should('equal', 'unchecked');
      shiftManagement.createShiftDialogtWeekdayInputField('sat').invoke('attr', 'data-status').should('equal', 'unchecked');
      shiftManagement.createShiftDialogtWeekdayInputField('sun').invoke('attr', 'data-status').should('equal', 'checked');

      shiftManagement.createShiftDialogSaveButton().click();
      cy.waitForLoaders();

      datePicker.datePickerTrigger().eq(0).click();
      datePicker.nextWeekRadioButton().click();
      datePicker.applyButton().click();
      datePicker.datePickerTrigger().parent().should('have.text', 'Next week');

      cy.get(assignmentHourShiftBarSelector(shiftName)).should('exist').should('have.length', 5);

      getShiftId(shiftName).then((shiftId) => cy.slcHelpers.deleteVgroup(shiftId));
    });
});

/*
 * Visit the Shift Management module
 * Create a shift with default values
 * Verify the default values
 * Update the timezone
 * Update the shift to add and remove days
 * Verify the updated values
 */
it('C37660: Add a shift with default occurrence and edit occurrence in different timezone', { tags: 'Shifts' }, () => {
  shiftManagement.timezoneSwitcherTrigger().click({ force: true });
  shiftManagement.timezoneSwitcherSearchTextField().clear().type('Calcutta');
  shiftManagement.timezoneSwitcherSearchResultListItem().last().click();
  const shiftName = `Test shift ${randId()}`;

  shiftManagement.addShiftButton().click();
  shiftManagement.createShiftDialogNameTextField().type(shiftName);
  shiftManagement.createShiftDialogCreateButton().click();
  cy.waitForLoaders();

  // checking the shift bar alignment before changing the timezone
  cy.get(assignmentHourShiftBarSelector(shiftName))
    .first()
    .parent()
    .then((before) => {
      const alignmentBefore = before[0].style.left;
      // changing the timezone
      shiftManagement.timezoneSwitcherTrigger().click({ force: true });
      shiftManagement.timezoneSwitcherSearchTextField().clear().type('Tokyo');
      shiftManagement.timezoneSwitcherSearchResultListItem().last().click();
      cy.waitForLoaders();
      // checking that the bar is shifted when the timezone is changed
      cy.get(assignmentHourShiftBarSelector(shiftName))
        .first()
        .parent()
        .then((after) => {
          const alignmentAfter = after[0].style.left;
          assert.notEqual(alignmentBefore, alignmentAfter);
        });
      cy.get(assignmentHourShiftBarSelector(shiftName)).should('exist').first().click();
      shiftManagement.createShiftDialogAssignmentHourFromTextField().invoke('val').should('equal', '12:30 pm');
      shiftManagement.createShiftDialogAssignmentHourToTextField().invoke('val').should('equal', '08:30 pm');
      shiftManagement.createShiftDialogWorkingHoursFromTextField().invoke('val').should('equal', '12:30 pm');
      shiftManagement.createShiftDialogWorkingHoursToTextField().invoke('val').should('equal', '08:30 pm');

      // updating days
      shiftManagement.createShiftDialogtWeekdayInputField('sun').click();
      shiftManagement.createShiftDialogtWeekdayInputField('sat').click();
      shiftManagement.createShiftDialogtWeekdayInputField('mon').click();
      shiftManagement.createShiftDialogtWeekdayInputField('wed').click();
      shiftManagement.createShiftDialogtWeekdayInputField('fri').click();

      shiftManagement.createShiftDialogSaveButton().click();
      cy.waitForLoaders();

      datePicker.datePickerTrigger().eq(0).click();
      datePicker.nextWeekRadioButton().click();
      datePicker.applyButton().click();
      datePicker.datePickerTrigger().parent().should('have.text', 'Next week');

      cy.get(assignmentHourShiftBarSelector(shiftName)).should('exist').should('have.length', 4);

      cy.get(assignmentHourShiftBarSelector(shiftName)).should('exist').first().click();

      shiftManagement.createShiftDialogAssignmentHourFromTextField().invoke('val').should('equal', '12:30 pm');
      shiftManagement.createShiftDialogAssignmentHourToTextField().invoke('val').should('equal', '08:30 pm');
      shiftManagement.createShiftDialogWorkingHoursFromTextField().invoke('val').should('equal', '12:30 pm');
      shiftManagement.createShiftDialogWorkingHoursToTextField().invoke('val').should('equal', '08:30 pm');

      // checking updated days
      shiftManagement.createShiftDialogtWeekdayInputField('mon').invoke('attr', 'data-status').should('equal', 'unchecked');
      shiftManagement.createShiftDialogtWeekdayInputField('tue').invoke('attr', 'data-status').should('equal', 'checked');
      shiftManagement.createShiftDialogtWeekdayInputField('wed').invoke('attr', 'data-status').should('equal', 'unchecked');
      shiftManagement.createShiftDialogtWeekdayInputField('thu').invoke('attr', 'data-status').should('equal', 'checked');
      shiftManagement.createShiftDialogtWeekdayInputField('fri').invoke('attr', 'data-status').should('equal', 'unchecked');
      shiftManagement.createShiftDialogtWeekdayInputField('sat').invoke('attr', 'data-status').should('equal', 'checked');
      shiftManagement.createShiftDialogtWeekdayInputField('sun').invoke('attr', 'data-status').should('equal', 'checked');

      getShiftId(shiftName).then((shiftId) => cy.slcHelpers.deleteVgroup(shiftId));
    });
});
