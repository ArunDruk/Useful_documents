import moment from 'moment-timezone';
import { assignmentHourShiftBarSelector, getShiftId, randId } from './support';
import { urlHelpers } from '../../../utils';
import { shiftManagement } from '../../../pages';

beforeEach(() => {
  cy.intercept('POST', 'api/v2/group/search?*').as('waitForShifts');
  cy.intercept('POST', 'api/v2/availability/query').as('waitForAvailability');

  cy.loginByApi();
  cy.visit(urlHelpers.shiftCalendar);

  cy.wait('@waitForShifts');
  cy.wait('@waitForAvailability');
});

it('C6712: should create single day shift with multiple time slots', { tags: 'Shifts' }, () => {
  const shiftName = `Test shift ${randId()}`;

  shiftManagement.addShiftButton().click();
  shiftManagement.createShiftDialogNameTextField().type(shiftName);
  // enter custom assignment hours start & end time
  shiftManagement.createShiftDialogCustomizeAssignmentHoursCheckbox().check({ force: true });
  shiftManagement.createShiftDialogAssignmentHoursTueFromSlot1().clear().type('9:00 am');
  shiftManagement.createShiftDialogAssignmentHoursTueToSlot1().clear().type('12:00 pm');
  // add second slot
  shiftManagement.createShiftDialogAssignmentHoursTueAddSlotButton1().click({ force: true });
  shiftManagement.createShiftDialogAssignmentHoursTueFromSlot2().clear().type('2:00 pm');
  shiftManagement.createShiftDialogAssignmentHoursTueToSlot2().clear().type('7:00 pm');

  shiftManagement.createShiftDialogCreateButton().click({ force: true });

  cy.get(assignmentHourShiftBarSelector(shiftName)).should('exist').and('have.length', 6);
  cy.get(assignmentHourShiftBarSelector(shiftName)).eq(1).rightclick();
  shiftManagement
    .createShiftDialogInfoIconTooltip()
    .should('be.visible')
    .and('contain.text', shiftName)
    .and('contain.text', 'Mon 09:00 AM-05:00 PM')
    .and('contain.text', 'Tue 09:00 AM-12:00 PM')
    .and('contain.text', 'Tue 02:00 PM-07:00 PM')
    .and('contain.text', 'Mon-Fri 09:00 AM-05:00 PM');

  getShiftId(shiftName).then((shiftId) => cy.slcHelpers.deleteVgroup(shiftId));
});

// Cross-over shifts have a known issue
it.skip('C6711: should create shift extending to next day', { tags: 'Shifts' }, () => {
  const shiftName = `Test shift ${randId()}`;

  shiftManagement.addShiftButton().click();
  shiftManagement.createShiftDialogNameTextField().type(shiftName);
  // enter custom assignment hours start & end time
  shiftManagement.createShiftDialogAssignmentHourFromTextField.clear().type('8:00 PM');
  shiftManagement.createShiftDialogAssignmentHourToTextField.click();
  cy.contains('04:00 am Next Day').click();

  const tomorrowDateString = moment().add(1, 'day').format('ddd, MMM DD');
  cy.contains(tomorrowDateString).should('be.visible');

  shiftManagement.createShiftDialogCreateButton().click();

  cy.get(assignmentHourShiftBarSelector(shiftName)).should('exist').and('have.length', 10);
  cy.get(assignmentHourShiftBarSelector(shiftName)).first().rightclick();
  shiftManagement
    .createShiftDialogInfoIconTooltip()
    .should('be.visible')
    .and('contain.text', shiftName)
    .and('contain.text', 'Mon-Fri 08:00 PM-04:00 AM')
    .and('contain.text', 'Mon-Fri 09:00 AM-05:00 PM');

  getShiftId(shiftName).then((shiftId) => cy.slcHelpers.deleteVgroup(shiftId));
});

// Cross-over shifts have a known issue
it.skip('C6713: should create next day shift with multiple time slots', { tags: 'Shifts' }, () => {
  const shiftName = `Test shift ${randId()}`;

  shiftManagement.addShiftButton().click();
  shiftManagement.createShiftDialogNameTextField().type(shiftName);
  // enter custom assignment hours start & end time
  shiftManagement.createShiftDialogCustomizeAssignmentHoursCheckbox().check({ force: true });
  shiftManagement.createShiftDialogAssignmentHoursTueFromSlot1().clear().type('4:00 pm');
  shiftManagement.createShiftDialogAssignmentHoursTueToSlot1().clear().type('8:00 pm');
  // add second slot
  shiftManagement.createShiftDialogAssignmentHoursTueAddSlotButton1().click({ force: true });
  shiftManagement.createShiftDialogAssignmentHoursTueFromSlot2().clear().type('9:00 pm');
  shiftManagement.createShiftDialogAssignmentHoursTueToSlot2().click();
  cy.contains('02:00 am Next Day').click();

  shiftManagement.createShiftDialogCreateButton().click();

  cy.get(assignmentHourShiftBarSelector(shiftName)).should('exist').and('have.length', 7);
  cy.get(assignmentHourShiftBarSelector(shiftName)).first().rightclick();
  shiftManagement
    .createShiftDialogInfoIconTooltip()
    .should('be.visible')
    .and('contain.text', shiftName)
    .and('contain.text', 'Mon 09:00 AM-05:00 PM')
    .and('contain.text', 'Tue 04:00 PM-08:00 PM')
    .and('contain.text', 'Tue 09:00 PM-02:00 AM')
    .and('contain.text', 'Mon-Fri 09:00 AM-05:00 PM');

  getShiftId(shiftName).then((shiftId) => cy.slcHelpers.deleteVgroup(shiftId));
});
