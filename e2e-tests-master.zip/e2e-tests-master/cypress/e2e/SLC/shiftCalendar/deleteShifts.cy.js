import { assignmentHourShiftBarSelector, createShift, deleteAvailability, randId } from './support';
import { urlHelpers } from '../../../utils';
import { datePicker, shiftManagement } from '../../../pages';

describe('Delete Shifts', () => {
  beforeEach(() => {
    const shiftName = `Test shift ${randId()}`;

    cy.intercept('POST', 'api/v2/group/search?*').as('waitForShifts');
    cy.intercept('POST', 'api/v2/availability/query').as('waitForAvailability');
    cy.intercept('PUT', 'api/v2/group').as('deleteShiftEntirely');
    cy.intercept('POST', 'api/v2/availability/schedule/block').as('deleteTodayShift');
    cy.intercept('PUT', 'api/v2/availability/schedule/weekly_time_interval/*').as('deleteShiftTodayAndFollowing');

    cy.loginByApi();
    createShift(shiftName).then(({ shiftId, shiftSid, availabilitySid }) => {
      cy.wrap(shiftName).as('shiftName');
      cy.wrap(shiftId).as('shiftId');
      cy.wrap(shiftSid).as('shiftSid');
      cy.wrap(availabilitySid).as('availabilitySid');
    });

    cy.visit(urlHelpers.shiftCalendar);
    cy.wait('@waitForShifts');
    cy.wait('@waitForAvailability');

    datePicker.datePickerTrigger().click();
    datePicker.nextWeekRadioButton().click();
    datePicker.applyButton().click();
    datePicker.datePickerTrigger().parent().should('have.text', 'Next week');

    cy.get(assignmentHourShiftBarSelector(shiftName)).eq(0).scrollIntoView().should('be.visible');
    cy.get(assignmentHourShiftBarSelector(shiftName)).first().click();
    shiftManagement.createShiftDialogDeleteButton().click();
  });

  afterEach(function afterEachHook() {
    deleteAvailability(this.availabilitySid);
  });

  it('C6703: should cancel shift deletion', { tags: 'Shifts' }, () => {
    shiftManagement.deleteDialogCancelButton().click();
    shiftManagement.deleteDialogTodayRadioButton().should('not.exist');
  });

  /*
   * Regression - C6704
   * - Navigate to the ShiftManagement page
   * - Create a shift
   * - Now delete the shift for today
   * -That should delete the data for today and rest should be visible.
   * - First asserting whether the shift for today is deleted or not.
   * - Also asserting whether rest of the shift is visible or not.
   */
  it('C6704: should delete shift for Today', { tags: 'Shifts' }, function deleteShift() {
    let lcount;
    cy.get(assignmentHourShiftBarSelector(this.shiftName)).then((listing) => {
      lcount = Cypress.$(listing).length;
    });
    shiftManagement.deleteDialogTodayRadioButton().click();
    shiftManagement.deleteDialogDeleteButton().click();
    cy.wait('@deleteTodayShift');
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    cy.wait('@waitForAvailability');
    cy.reload().then(() => {
      datePicker.datePickerTrigger().click();
      datePicker.nextWeekRadioButton().click();
      datePicker
        .applyButton()
        .click()
        .then(() => {
          cy.get(assignmentHourShiftBarSelector(this.shiftName)).should('have.length', lcount - 1);
        });
    });
    datePicker.datePickerTrigger().click();
    datePicker.thisWeekRadioButton().click();
    datePicker.applyButton().click();
    cy.get(assignmentHourShiftBarSelector(this.shiftName)).should('exist');
    cy.slcHelpers.deleteVgroup(this.shiftId);
  });

  it('C6705: should delete shift for Today and following days', { tags: 'Shifts' }, function deleteShift() {
    shiftManagement.createShiftDialogDeleteButton().click();
    shiftManagement.deleteDialogTodayAndFollowingRadioButton().click();
    shiftManagement.deleteDialogDeleteButton().click();
    cy.wait('@deleteShiftTodayAndFollowing');
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    cy.wait('@waitForAvailability');
    shiftManagement
      .agentAssignmentCalendarNameSelector(this.shiftName)
      .eq(0)
      .scrollIntoView()
      .contains(this.shiftName)
      .should((elem) => {
        expect(elem.text()).to.not.equal(this.shiftName);
      });
    cy.get(assignmentHourShiftBarSelector(this.shiftName)).should('exist');
    cy.slcHelpers.deleteVgroup(this.shiftId);
  });

  it('C6706: should delete shift entirely', { tags: 'Shifts' }, function deleteShift() {
    shiftManagement.deleteDialogDeleteAllRadioButton().click();
    shiftManagement.deleteDialogDeleteButton().click();
    cy.wait('@deleteShiftEntirely');

    cy.get(assignmentHourShiftBarSelector(this.shiftName)).should('not.exist');
  });
});
