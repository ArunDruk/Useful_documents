import moment from 'moment-timezone';
import { assignmentHourShiftBarSelector, createShift, customTimeIntervalList, deleteAvailability, randId } from './support';
import { urlHelpers } from '../../../utils';
import { shiftManagement } from '../../../pages';

const targetTimeFormat = 'hh:mm A';
const targetTimezone = 'America/Los_Angeles'; // Do not use this in UI

beforeEach(() => {
  cy.intercept('POST', 'api/v2/group/search?*').as('waitForShifts');
  cy.intercept('POST', 'api/v2/availability/query').as('waitForAvailability');

  cy.loginByApi();
});

afterEach(function afterEachHook() {
  deleteAvailability(this.availabilitySid);
  cy.slcHelpers.deleteVgroup(this.shiftId);
});

it('C6847: should display correct timings after changing TZ for normal shift', { tags: 'Shifts' }, () => {
  const shiftName = `Test shift ${randId()}`;
  const expectedStartTime = moment('9:00 AM', 'hh:mm a').tz(targetTimezone).format(targetTimeFormat);
  const expectedEndTime = moment('5:00 PM', 'hh:mm a').tz(targetTimezone).format(targetTimeFormat);

  createShift(shiftName).then(({ shiftId, availabilitySid }) => {
    cy.wrap(shiftId).as('shiftId');
    cy.wrap(availabilitySid).as('availabilitySid');

    cy.visit(urlHelpers.shiftCalendar);

    cy.wait('@waitForShifts');
    cy.wait('@waitForAvailability');

    shiftManagement.timezoneSwitcherTrigger().click();
    shiftManagement.timezoneSwitcherSearchTextField().type('Los Angeles');
    shiftManagement.timezoneSwitcherSearchResultListItem().should('have.length.at.least', 2).eq(1).click();

    cy.get(assignmentHourShiftBarSelector(shiftName)).should('have.length', 7);
    cy.get(assignmentHourShiftBarSelector(shiftName)).first().rightclick();
    shiftManagement.createShiftDialogInfoIconTooltip().should('be.visible').and('contain.text', shiftName).and('contain.text', `Mon-Sun ${expectedStartTime}-${expectedEndTime}`);
  });
});

it('C6848: should display correct timings after changing TZ for custom shift', { tags: 'Shifts' }, () => {
  const shiftName = `Test shift ${randId()}`;
  const expectedStartTime = moment('9:00 AM', 'hh:mm a').tz(targetTimezone).format(targetTimeFormat);
  const expectedEndTime = moment('12:00 PM', 'hh:mm a').tz(targetTimezone).format(targetTimeFormat);
  const expectedStartTime1 = moment('1:00 PM', 'hh:mm a').tz(targetTimezone).format(targetTimeFormat);
  const expectedEndTime1 = moment('5:00 PM', 'hh:mm a').tz(targetTimezone).format(targetTimeFormat);

  createShift(shiftName, customTimeIntervalList).then(({ shiftId, availabilitySid }) => {
    cy.wrap(shiftId).as('shiftId');
    cy.wrap(availabilitySid).as('availabilitySid');

    cy.visit(urlHelpers.shiftCalendar);

    cy.wait('@waitForShifts');
    cy.wait('@waitForAvailability');

    shiftManagement.timezoneSwitcherTrigger().click();
    shiftManagement.timezoneSwitcherSearchTextField().type('Los Angeles');
    shiftManagement.timezoneSwitcherSearchResultListItem().should('have.length.at.least', 2).eq(1).click();

    cy.get(assignmentHourShiftBarSelector(shiftName)).should('have.length', 8);
    cy.get(assignmentHourShiftBarSelector(shiftName)).first().rightclick();
    shiftManagement
      .createShiftDialogInfoIconTooltip()
      .should('be.visible')
      .and('contain.text', shiftName)
      .and('contain.text', `Tue ${expectedStartTime}-${expectedEndTime}`)
      .and('contain.text', `Tue ${expectedStartTime1}-${expectedEndTime1}`);
  });
});
