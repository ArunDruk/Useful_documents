import { assignmentHourShiftBarSelector, createShift, randId } from './support';
import { urlHelpers } from '../../../utils';
import { shiftManagement } from '../../../pages';

beforeEach(() => {
  const shiftName = `Test shift ${randId()}`;
  cy.wrap(shiftName).as('shiftName');

  cy.intercept('POST', 'api/v2/group/search?*').as('waitForShifts');
  cy.intercept('POST', 'api/v2/availability/query').as('waitForAvailability');

  cy.loginByApi();
  cy.visit(urlHelpers.shiftCalendar);

  cy.wait('@waitForShifts');
  cy.wait('@waitForAvailability');
});

it('C6931: should create shift with the default color', { tags: 'Shifts' }, function defaultColorShift() {
  shiftManagement.addShiftButton().click();
  shiftManagement.createShiftDialogNameTextField().type(this.shiftName);
  shiftManagement
    .createShiftDialogColorPickerDropdown()
    .invoke('attr', 'data-color')
    .then((selectedShiftColor) => {
      shiftManagement.createShiftDialogCreateButton().click();
      cy.get(assignmentHourShiftBarSelector(this.shiftName)).parent().invoke('attr', 'style').should('contain', selectedShiftColor);
    });
});

it('C6932: should create shift with a different color', { tags: 'Shifts' }, function differentColorShift() {
  shiftManagement.addShiftButton().click();
  shiftManagement.createShiftDialogNameTextField().type(this.shiftName);
  shiftManagement.createShiftDialogColorPickerDropdown().click();
  shiftManagement.createShiftDialogColorItem().first().click();
  shiftManagement
    .createShiftDialogColorPickerDropdown()
    .invoke('attr', 'data-color')
    .then((selectedShiftColor) => {
      shiftManagement.createShiftDialogCreateButton().click();
      cy.get(assignmentHourShiftBarSelector(this.shiftName)).parent().invoke('attr', 'style').should('contain', selectedShiftColor);
    });
});

it('C6933: should change shift bar color after creation', { tags: 'Shifts' }, function editShiftColor() {
  createShift(this.shiftName).then(() => {
    cy.reload();

    cy.get(assignmentHourShiftBarSelector(this.shiftName)).first().click();
    shiftManagement
      .createShiftDialogColorPickerDropdown()
      .invoke('attr', 'data-color')
      .then((selectedShiftColor) => {
        shiftManagement.createShiftDialogColorPickerDropdown().click();
        shiftManagement.createShiftDialogColorItem().first().click();
        shiftManagement.createShiftDialogSaveButton().click();

        cy.get(assignmentHourShiftBarSelector(this.shiftName)).parent().invoke('attr', 'style').should('not.contain', selectedShiftColor);
      });
  });
});
