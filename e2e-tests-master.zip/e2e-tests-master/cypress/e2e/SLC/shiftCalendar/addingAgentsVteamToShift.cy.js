import { createShift, deleteAvailability, randId } from './support';
import { urlHelpers } from '../../../utils';
import { shiftManagement, virtualAccount } from '../../../pages';

beforeEach(() => {
  const shiftName = `Test shift ${randId()}`;

  cy.intercept('PUT', 'api/v2/group').as('assignAgents');
  cy.intercept('search/virtual_groups/_search*').as('search');

  cy.loginByApi();
  createShift(shiftName).then(({ shiftId, shiftSid, availabilitySid }) => {
    cy.wrap(shiftName).as('shiftName');
    cy.wrap(shiftId).as('shiftId');
    cy.wrap(shiftSid).as('shiftSid');
    cy.wrap(availabilitySid).as('availabilitySid');
  });

  cy.visit(urlHelpers.shiftCalendar);
});

afterEach(function afterEachHook() {
  deleteAvailability(this.availabilitySid);
  cy.slcHelpers.deleteVgroup(this.shiftId);
});

it('C6701: should add an agent to a shift', { tags: 'Shifts' }, function addAgent() {
  shiftManagement.noAgentAssignAgentsButton(this.shiftName).first().click();

  virtualAccount.vaCreatePopupSearchCustomerNameInput().type('a');
  cy.wait('@search');

  virtualAccount.vaCreatePopupCustomerSearchResultList().eq(0).click();
  shiftManagement.assignAgentPopoverSubmitButton().click();
  cy.wait('@assignAgents');
  cy.waitForLoaders();
  shiftManagement.assignAgentsButton(this.shiftName).first().should('have.text', 1);
});

it('C6702: should add multiple agents to a shift', { tags: 'Shifts' }, function addMultipleAgents() {
  shiftManagement.noAgentAssignAgentsButton(this.shiftName).first().click();

  virtualAccount.vaCreatePopupSearchCustomerNameInput().type('a');
  cy.wait('@search');

  virtualAccount.vaCreatePopupCustomerSearchResultList().eq(0).click();
  virtualAccount.vaCreatePopupCustomerSearchResultList().eq(1).click();

  shiftManagement.assignAgentPopoverSubmitButton().click();
  cy.wait('@assignAgents');
  cy.waitForLoaders();

  shiftManagement.assignAgentsButton(this.shiftName).first().should('have.text', '2');
});

// TODO: (ikhalikov) exp. kickoff wait wrapper for elastic
it.skip('C6738: should add virtual team to a shift', { tags: 'Shifts' }, function addVirtualTeam() {
  const vtName = `Test Personal Team ${randId()}`;

  cy.slcHelpers
    .getAgentIds(5)
    .then((agentIds) => cy.slcHelpers.createVT(vtName, agentIds))
    .wait(30000) // wait for the VT to appear in the elastic index
    .then((response) => {
      cy.reload();

      shiftManagement.noAgentAssignAgentsButton(this.shiftName).first().click();

      virtualAccount.vaCreatePopupSearchCustomerNameInput().type(vtName);
      cy.wait('@search');

      virtualAccount.vaCreatePopupCustomerSearchResultList().eq(0).click();
      virtualAccount.vaCreatePopupCustomerSearchResultListAddButton().wait(1000).click().wait(1000);

      shiftManagement.assignAgentPopoverSubmitButton().click();
      cy.wait('@assignAgents');

      shiftManagement.assignAgentsButton(this.shiftName).first().should('have.text', '5');
      cy.slcHelpers.deleteVgroup(response.body.id);
    });
});
