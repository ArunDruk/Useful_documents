import { urlHelpers } from '../../../utils';
import { shiftManagement } from '../../../pages';

beforeEach(() => {
  cy.intercept('POST', 'api/v2/group/search?*').as('waitForShifts');
  cy.intercept('POST', 'api/v2/availability/query').as('waitForAvailability');

  cy.loginByApi();
  cy.visit(urlHelpers.shiftCalendar);

  cy.wait('@waitForShifts');
  cy.wait('@waitForAvailability');

  shiftManagement.addShiftButton().click();
  // hard wait for the popup to appear
  // eslint-disable-next-line cypress/no-unnecessary-waiting
  cy.wait(2000);
});

it('C6817: should verify create modal defaults to today', { tags: 'Shifts' }, () => {
  shiftManagement.createShiftDialogAssignmentHrsDateLabel().should('be.visible');
  shiftManagement.createShiftDialogWorkingHrsDateLabel().should('be.visible');
});

it('C6699: should cancel & close shift creation modal', { tags: 'Shifts' }, () => {
  shiftManagement.createShiftDialogCancelButton().click();

  shiftManagement.createShiftDialogCreateButton().should('not.exist');
});
