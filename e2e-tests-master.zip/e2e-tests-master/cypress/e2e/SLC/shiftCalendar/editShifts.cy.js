import { assignmentHourShiftBarSelector, createShift, randId } from './support';
import { urlHelpers } from '../../../utils';
import { shiftManagement } from '../../../pages';

beforeEach(() => {
  const shiftName = `Test shift ${randId()}`;

  cy.intercept('POST', 'api/v2/group/search?*').as('waitForShifts');
  cy.intercept('POST', 'api/v2/availability/query').as('waitForAvailability');
  cy.intercept('PUT', 'api/v2/group').as('saveEditedShift');

  cy.loginByApi();
  createShift(shiftName).then(({ shiftId }) => {
    cy.wrap(shiftName).as('shiftName');
    cy.wrap(shiftId).as('shiftId');
  });

  cy.visit(urlHelpers.shiftCalendar);
  cy.wait('@waitForShifts');
  cy.wait('@waitForAvailability');
});

// TODO: (praveen) find root cause of unhandled promise rejection error from application
// afterEach(function afterEachHook() {
//   cy.slcHelpers.deleteVgroup(this.shiftId);
// });

it('C6587: should edit shift', { tags: 'Shifts' }, function editShift() {
  cy.get(assignmentHourShiftBarSelector(this.shiftName)).should('exist').first().click();

  shiftManagement.createShiftDialogNameTextField().clear().type(`${this.shiftName} edit`);
  shiftManagement.createShiftDialogSaveButton().click();
  cy.wait('@saveEditedShift');

  cy.get(assignmentHourShiftBarSelector(`${this.shiftName} edit`)).should('be.visible');
});

it('C6700: should cancel & close shift edit modal', { tags: 'Shifts' }, function cancelEditShift() {
  cy.get(assignmentHourShiftBarSelector(this.shiftName)).should('exist').first().click();

  shiftManagement.createShiftDialogNameTextField().clear().type(`${this.shiftName} edit`);
  shiftManagement.createShiftDialogCancelButton().click();

  shiftManagement.createShiftDialogSaveButton().should('not.exist');

  cy.get(assignmentHourShiftBarSelector(`${this.shiftName} edit`)).should('not.exist');
});
