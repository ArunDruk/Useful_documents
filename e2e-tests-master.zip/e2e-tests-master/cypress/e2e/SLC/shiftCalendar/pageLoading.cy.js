import { urlHelpers } from '../../../utils';
import { shiftManagement } from '../../../pages';

beforeEach(() => {
  cy.intercept('POST', 'api/v2/group/search?*').as('waitForShifts');
  cy.intercept('POST', 'api/v2/availability/query').as('waitForAvailability');

  cy.loginByApi();
  cy.visit(urlHelpers.shiftCalendar);
});

it('C6582: should verify shift calendar components have loaded successfully', { tags: 'Shifts' }, () => {
  // cy.getByTestId('caseAssignmentPage-SettingsBtn').click();
  cy.wait('@waitForShifts');
  cy.wait('@waitForAvailability');

  cy.url().should('include', 'shift-management');

  shiftManagement.addShiftButton().should('be.visible');

  shiftManagement.shiftBar().should('be.visible');
});
