import moment from 'moment-timezone';
import { urlHelpers } from '../../../utils';
import { agentInsights, datePicker, shiftManagement } from '../../../pages';

const regex = /Selected as start date\. (.*), \d*/;
const datepickerShortcuts = [
  { testrailId: 'C6707', name: 'Last week', testid: 'globalDateRangePicker-Shortcut-past_week' },
  { testrailId: 'C6708', name: 'This week', testid: 'globalDateRangePicker-Shortcut-current_week' },
  { testrailId: 'C6709', name: 'Next week', testid: 'globalDateRangePicker-Shortcut-next_week' },
];

beforeEach(() => {
  cy.intercept('POST', 'api/v2/group/search?*').as('waitForShifts');
  cy.intercept('POST', 'api/v2/availability/query').as('waitForAvailability');

  cy.loginByApi();
  cy.visit(urlHelpers.shiftCalendar);

  cy.wait('@waitForShifts');
  cy.wait('@waitForAvailability');
});

datepickerShortcuts.forEach((shortcut) => {
  it(`${shortcut.testrailId}: should select ${shortcut.name} shortcut`, () => {
    if (shortcut.name === 'This week') {
      datePicker.datePickerTrigger().click();
      datePicker.nextWeekRadioButton().click();
      datePicker.applyButton().click();
    }
    datePicker.datePickerTrigger().click();
    cy.getByTestId(shortcut.testid)
      .click()
      .then(() => {
        shiftManagement
          .datePickerSelectedStartDate()
          .first()
          .then(($startDateEl) => {
            const startDateLabel = $startDateEl.attr('aria-label');
            const startDate = startDateLabel.match(regex)[1].split(',')[1].trim();
            const expectedStartDate = moment(startDate, 'MMMM D').format('MMMM DD');

            datePicker.applyButton().click();
            datePicker.datePickerTrigger().should('have.text', shortcut.name);
            agentInsights.calendarDate().first().should('contain.text', expectedStartDate);
          });
      });
  });
});

it('C6710: should select a custom week', { tags: 'Shifts' }, () => {
  datePicker.datePickerTrigger().click();
  datePicker.nextMonthButton().click().click();
  datePicker
    .calendarDay()
    .first()
    .click({ force: true })
    .then(($startDateEl) => {
      const startDateLabel = $startDateEl.attr('aria-label');
      const startDate = startDateLabel.match(regex)[1].split(',')[1].trim();
      const expectedStartDate = moment(startDate, 'MMMM D').format('MMMM DD');

      datePicker.applyButton().click();
      agentInsights.calendarDate().first().should('contain.text', expectedStartDate);
    });
});
