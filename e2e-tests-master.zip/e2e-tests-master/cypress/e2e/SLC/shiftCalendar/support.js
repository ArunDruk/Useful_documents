export const randId = () => Cypress._.random(0, 1e6);

export const fixedTimeIntervalList = [
  { start_time: 1980, end_time: 2460 },
  { start_time: 3420, end_time: 3900 },
  { start_time: 4860, end_time: 5340 },
  { start_time: 6300, end_time: 6780 },
  { start_time: 7740, end_time: 8220 },
  { start_time: 9180, end_time: 9660 },
  { start_time: 540, end_time: 1020 },
];

export const customTimeIntervalList = [
  { start_time: 1980, end_time: 2460 },
  { start_time: 3420, end_time: 3600 },
  { start_time: 3660, end_time: 3900 },
  { start_time: 4860, end_time: 5340 },
  { start_time: 6300, end_time: 6780 },
  { start_time: 7740, end_time: 8220 },
  { start_time: 9180, end_time: 9660 },
  { start_time: 540, end_time: 1020 },
];

export const createAvailability = (name, sID, timeIntervals) => {
  const { timeZone } = Intl.DateTimeFormat().resolvedOptions();
  return cy.request({
    method: 'POST',
    url: 'api/v2/availability',
    headers: { 'Content-Type': 'application/json' },
    body: {
      availability_status: null,
      name: `${sID} ${name}`,
      object_target: {
        object_id: sID,
        object_type: 'VGROUP',
      },
      purpose: 'TICKET_ASSIGNMENT_AVAILABILITY',
      schedule_list: [
        {
          timezone: timeZone,
          schedule_type: 'AGENT_ASSIGNMENT_AVAILABILITY_SOFT',
          weekly_time_interval_list: timeIntervals,
        },
        {
          timezone: timeZone,
          schedule_type: 'AGENT_ASSIGNMENT_AVAILABILITY_HARD',
          weekly_time_interval_list: timeIntervals,
        },
      ],
    },
  });
};

export const createShift = (name, timeIntervals = fixedTimeIntervalList, agentIds = []) =>
  cy
    .request({
      method: 'POST',
      url: 'api/v2/group',
      headers: { 'Content-Type': 'application/json' },
      body: {
        name,
        gtype: 'virtual_shift',
        is_public: false,
        owner: Cypress.env('userEmail'),
        created_by: Cypress.env('userEmail'),
        account_ids: [],
        crm_user_ids: agentIds,
        email_user_ids: [],
        child_ids: [],
      },
    })
    .then(({ body: { id: shiftId, s_id: shiftSid } }) =>
      createAvailability(name, shiftSid, timeIntervals).then(({ body }) => ({ shiftId, shiftSid, availabilitySid: body.data[0].s_id }))
    );

export const deleteAvailability = (sID) => cy.request('DELETE', `api/v2/availability/${sID}`);

export const getShiftId = (name) =>
  cy
    .request({
      method: 'POST',
      url: 'api/v2/group/search',
      headers: { 'Content-Type': 'application/json' },
      body: {
        selected: ['id'],
        ordering: [
          {
            column: 'created_at',
            direction: 'desc',
          },
        ],
        predicates: [
          {
            column: 'name',
            op: '=',
            value: name,
          },
          {
            column: 'gtype',
            op: '=',
            value: 'virtual_shift',
          },
        ],
      },
    })
    .then(({ body }) => body.map(({ id }) => id));

export const assignmentHourShiftBarSelector = (shiftName) => `[data-visible=true] > [data-testid='assignmentHours-shiftBar-${shiftName}']`;
export const workingHourShiftBarSelector = (shiftName) => `[data-testid='workingHours-shiftBar-${shiftName}']`;
