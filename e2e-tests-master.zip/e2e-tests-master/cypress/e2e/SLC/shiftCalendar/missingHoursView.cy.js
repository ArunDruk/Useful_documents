import moment from 'moment-timezone';
import { assignmentHourShiftBarSelector, getShiftId, randId } from './support';
import { urlHelpers } from '../../../utils';
import { shiftManagement } from '../../../pages';

beforeEach(() => {
  cy.intercept('POST', 'api/v2/group/search?*', { fixture: 'shifts/vgroup' }).as('waitForShifts');
  cy.intercept('POST', 'api/v2/availability/query', { fixture: 'shifts/availability' }).as('waitForAvailability');

  cy.loginByApi();
  cy.visit(urlHelpers.shiftCalendar);

  cy.wait('@waitForShifts');
  cy.wait('@waitForAvailability');
});

it('C6899: should enable missing hours view', { tags: 'Shifts' }, () => {
  shiftManagement.missingHoursVisibilityToggle().then((elem) => {
    if (Cypress.$(elem).attr('data-status') === 'hide') cy.wrap(elem).click();
  });

  shiftManagement.noAssignmentHourInfoIconButton().should('be.visible');
  shiftManagement.noAssignmentHour().should('be.visible');
});

// TODO: Requires a complete rewrite due to new changes
it.skip('C6900: should create shift from missing assignment hour tooltip', { tags: 'Shifts' }, () => {
  const shiftName = `Test shift ${randId()}`;

  shiftManagement.missingHoursVisibilityToggle().then((elem) => {
    if (Cypress.$(elem).attr('data-status') === 'hide') cy.wrap(elem).click();
  });
  cy.get('[data-testid=agentAssignmentCalendar-noAssignmentHour] > div')
    .invoke('attr', 'data-for')
    .then((label) => {
      shiftManagement.noAssignmentHourInfoIconButton().first().click();
      cy.getByTestId('agentAssignmentCalendar-noAssignmentHour-blankTimeInterval')
        .invoke('text')
        .then((timeInterval) => {
          cy.getByTestId('agentAssignmentCalendar-noAssignmentHour-blankTimeIntervalWeekday')
            .invoke('text')
            .then((missingOccurrencesLabel) => {
              const startTime = timeInterval.split('-')[0].trim();
              const endTime = timeInterval.split('-')[1].trim();
              const expectedDate = moment(label.split('-')[2], 'MMMM DD').format('ddd, MMM DD');
              const missingOccurrences = missingOccurrencesLabel.split(',');

              const getStartTimeString = (format = 'hh:mm a') => moment(startTime, 'HH:mm A').format(format);
              const getEndTimeString = (format = 'hh:mm a') => moment(endTime, 'HH:mm A').format(format);

              cy.getByTestId('agentAssignmentCalendar-noAssignmentHour-createShiftBtn').first().click();

              // TODO: get testid for create popup date label
              cy.get('div[class*=PopperContainer]').should('have.text', expectedDate);
              cy.getByTestId('agentShift--formDetails--assignmenthour_textinput_from').should('have.value', getStartTimeString());
              cy.getByTestId('agentShift--formDetails--workinghours_textinput_from').should('have.value', getStartTimeString());

              cy.getByTestId('agentShift--formDetails--assignmenthour_textinput_to').should('have.value', getEndTimeString());
              cy.getByTestId('agentShift--formDetails--workinghours_textinput_to').should('have.value', getEndTimeString());

              missingOccurrences.forEach((occurrence) => {
                cy.getByTestId(`agentShift--formDetails--weekday__${occurrence.toLowerCase()}`).invoke('attr', 'data-status').should('eq', 'checked');
              });

              shiftManagement.createShiftDialogNameTextField().type(shiftName);
              shiftManagement.createShiftDialogCreateButton().click();

              cy.get(assignmentHourShiftBarSelector(shiftName)).should('exist');
              cy.get(assignmentHourShiftBarSelector(shiftName)).first().rightclick();
              shiftManagement
                .createShiftDialogInfoIconTooltip()
                .should('be.visible')
                .and('contain.text', shiftName)
                .and('contain.text', `${getStartTimeString('hh:mm A')}-${getEndTimeString('hh:mm A')}`);

              getShiftId(shiftName).then((shiftId) => cy.slcHelpers.deleteVgroup(shiftId));
            });
        });
    });
});
