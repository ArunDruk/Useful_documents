import { urlHelpers } from '../../../utils';
import { assignmentQueues, virtualAccount, virtualTeam } from '../../../pages/index';

describe('Validating Virtual Team', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.assignmentQueues);
  });

  /**
   * Regression C2340
   * - Login as a valid user in the dashboard.
   * - Now check which team or org is added in the default team section of Assignment Queue page.
   * - If no default team exist - creating a virtual team and set it as default team
   * - Go to Virtual teams module and search for the default team that is added and then hover over it.
   * - Once delete icon is visible, click on it.
   * - The modal should popup and should have content as shown in expected result section.
   * - If no default team exist
   *  - creating a virtual team and set it as default team
   *  - Verifying the above steps and then remove from default team list and deleting the created virtual team
   */
  it('C2340: Check when any VT /VO is added as default team for ICA then while deleting the team it  shows message', { tags: ['Virtual Team', 'staging'] }, () => {
    cy.waitForLoaders();
    assignmentQueues
      .defaultTeamValueWrapper()
      .eq(0)
      .scrollIntoView()
      .then(($wrapper) => {
        // TODO: For data-testid, refer https://supportlogic.atlassian.net/browse/SLC-34063
        const teamIsExist = $wrapper.find('[class^="styles__AddDefaultTeamBtnWrapper-sc-"]').length;
        if (teamIsExist !== 0) {
          // If no default team exist - adding a VirtualTeam
          // cy.visit(urlHelpers.virtualTeams);
          const vtName = 'C2340 DO NOT DELETE'; // virtualTeam.createVirtualTeam('Global');
          // Temp fix to avoid failures due to elastic search

          // cy.wait(7000);
          // Set the created virtual Team as default team,
          // cy.visit(urlHelpers.assignmentQueues);
          cy.waitForLoaders();
          assignmentQueues.defaultTeamAddButton().click();
          assignmentQueues.addDefaultTeamPopupSearchInput().clear().type(vtName);
          assignmentQueues.addDefaultTeamPopupSearchResultList().eq(0).click();
          // Verify the validation on deleting the virtual team , deleted the virtual team
          cy.visit(urlHelpers.virtualTeams);
          cy.waitForLoaders();
          virtualTeam.searchVirtualTeamInput().scrollIntoView().type(vtName);
          virtualTeam.deleteVirtualTeamButton().click();
          virtualTeam.deleteWarningMessageLabel().should('contain', 'this group is used as a Default Team for ICA. More details in Settings > Case Assignment');
          // virtualTeam.confirmDeleteVirtualTeamPopupButton().click();
          virtualTeam.editVirtualTeamCancelButton().click();
          // Removed Virtual Team from default team
          cy.visit(urlHelpers.assignmentQueues);
          cy.waitForLoaders();
          assignmentQueues.defaultTeamRemoveIcon().scrollIntoView().click();
          assignmentQueues.defaultTeamRemovePopupYesButton().click();
          assignmentQueues.defaultTeamAddButton().should('be.visible');
        } else {
          // If default team exist - taking the team name and  Verify the validation on trying to deleting the default team
          assignmentQueues.defaultTeamValueLabel().then(($teamName) => {
            const defaultTeam = $teamName.text();
            cy.visit(urlHelpers.virtualTeams);
            cy.waitForLoaders();
            virtualTeam.searchVirtualTeamInput().scrollIntoView().type(defaultTeam);
            virtualTeam.deleteVirtualTeamButton().click();
            virtualTeam.deleteWarningMessageLabel().should('contain', 'this group is used as a Default Team for ICA. More details in Assignment Queues page.');
            virtualAccount.cancelDeleteVaPopupButton().click();
          });
        }
      });
  });
});
