import { urlHelpers } from '../../../utils';
import { virtualTeam } from '../../../pages/index';

describe('Creating Virtual Team', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.virtualTeams);
  });

  /**
   * Regression C6595
   * - A virtual team will be created with the name given and the agents selected in step 7 as the members of the Virtual team
   */
  it('C6595: Create a Global virtual team', { tags: ['Virtual Team', 'staging'] }, () => {
    const vtName = virtualTeam.createVirtualTeam('Global');
    virtualTeam.deleteVirtualTeam(vtName);
  });

  /**
   * Regression C9189
   * - Create a virtual Team and then click on the copy icon
   * - Edit the Virtual Team in the Copied and click on Save button
   * - Verify the edited Virtual Team is exist in the Virutal Team list
   * - Delete the created virtual team
   */
  it('C9189: Create copy of VT', { tags: ['Virtual Team', 'staging'] }, () => {
    const vtName = virtualTeam.createVirtualTeam('Personal');
    const vtName1 = `${vtName} Testing`;
    virtualTeam.copyVirtualTeamButton(vtName).click();
    virtualTeam.editVirtualTeamNameButton().contains(`${vtName} Copy 1`).click();
    virtualTeam.editVirtualTeamNameInput().clear().type(vtName1).type('{Enter}');
    virtualTeam.editVirtualTeamSaveButton().scrollIntoView().click();
    virtualTeam.searchResultVirtualTeamList().should('contain', vtName1);
    // Delete the Created Copy Virtual Team
    virtualTeam.deleteVirtualTeam(vtName1);
    virtualTeam.deleteVirtualTeam(vtName);
  });

  /**
   * Regression C9412
   * - A virtual team will be created with the name given and the agents selected as the members of the Virtual team
   * - Verifying of selected agent is present within the create function
   * - Verify the created Virtual team is present in the Virtual team list
   * - Deleting the created virtual Team after verifying
   */
  it('C9412: Create a Personal Virtual Team', { tags: ['Virtual Team', 'staging'] }, () => {
    cy.waitForLoaders();
    virtualTeam.createVirtualTeamButton().should('exist');
    virtualTeam.createVirtualOrgsButton().should('exist');
    const vtName = virtualTeam.createVirtualTeam('Personal');
    virtualTeam.searchResultVirtualTeamList().should('contain', vtName);
    virtualTeam.deleteVirtualTeam(vtName);
  });

  /**
   * Regression C11803
   * - A virtual team will be created with the name given and the agents selected as the members of the Virtual team
   * - Verifying of selected agent is present within the create function
   * - Verify the created Virtual team is present in the Virtual team list
   * - Deleting the created virtual Team after verifying
   */
  it('C11803: Delete a Global VT', { tags: ['Virtual Team', 'staging'] }, () => {
    const vtName = virtualTeam.createVirtualTeam('Global');
    virtualTeam.searchResultVirtualTeamList().should('contain', vtName);
    virtualTeam.deleteVirtualTeam(vtName);
  });

  /**
   * Regression C11805
   * - A virtual team will be created with the name given and the agents selected as the members of the Virtual team
   * - Verifying of selected agent is present within the create function
   * - Verify the created Virtual team is present in the Virtual team list
   * - Deleting the created virtual Team after verifying
   */
  it('C11805: Delete a Personal VT', { tags: ['Virtual Team', 'staging'] }, () => {
    const vtName = virtualTeam.createVirtualTeam('Personal');
    virtualTeam.searchResultVirtualTeamList().should('contain', vtName);
    virtualTeam.deleteVirtualTeam(vtName);
  });

  /**
   * Regression C11807
   * - A virtual team will be created with the name given, Global team type and the agents selected as the members of the Virtual team
   * - Verifying of selected agent is present within the create function
   * - Verify the created Virtual team is present in the Virtual team list
   * - Verify the created Virtual team is displaying on selecting the filter value as Global Virtual Team
   * - Click on Edit in Virtual team and add new agent
   * - Verify the newly added agent is present in the virtual team within the addNewAgent function
   * - Deleting the created virtual Team after verifying
   */
  it('C11807: Edit a Global VT and add agents to the Virtual Team', { tags: ['Virtual Team', 'staging'] }, () => {
    const vtName = virtualTeam.createVirtualTeam('Global');
    virtualTeam.searchResultVirtualTeamList().should('contain', vtName);
    // selecting the Filter value as Global Virtual Team
    virtualTeam.vtFilterTrigger().click();
    cy.contains('Global Virtual').click();
    virtualTeam.vtFilterGlobalVirtualTeamCheckboxStatus().should('include', 'checked');
    virtualTeam.searchResultVirtualTeamList().should('contain', vtName);
    cy.contains('Global Virtual').click();
    virtualTeam.vtFilterTrigger().click();
    // Clicking on Edit
    virtualTeam.editVirtualTeamButton(vtName).click();
    virtualTeam.addNewAgentInVirtualTeam(vtName);
    virtualTeam.deleteVirtualTeam(vtName);
  });

  /**
   * Regression C27909
   * - A virtual team will be created with the name given, Global team type and the agents selected as the members of the Virtual team
   * - Verifying of selected agent is present within the create function
   * - Verify the created Virtual team is present in the Virtual team list
   * - Click on Edit in Virtual team and Edit the Virtual Team Name
   * - Verify the virtual Team Name gets updated
   * - Deleting the created virtual Team after verifying
   */
  it('C27909: Edit a Global VT to rename the Virtual team', { tags: ['Virtual Team', 'staging'] }, () => {
    const vtName = virtualTeam.createVirtualTeam('Global');
    const vtName1 = `${vtName} Edited`;
    virtualTeam.searchResultVirtualTeamList().should('contain', vtName);
    // Clicking on Edit
    virtualTeam.editVirtualTeamButton(vtName).click();
    virtualTeam.editVirtualTeamNameButton().contains(vtName).click();
    virtualTeam.editVirtualTeamNameInput().clear().type(vtName1).type('{Enter}');
    virtualTeam.editVirtualTeamSaveButton().scrollIntoView().click();
    virtualTeam.searchResultVirtualTeamList().should('have.text', vtName1);
    virtualTeam.searchResultVirtualTeamList().should('not.have.text', vtName);
    virtualTeam.deleteVirtualTeam(vtName1);
  });

  /**
   * Regression C27915
   * - A virtual team will be created with the name given, Global team type and the agents selected as the members of the Virtual team
   * - Verifying of selected agent is present within the create function
   * - Verify the created Virtual team is present in the Virtual team list
   * - Click on Edit in Virtual team, Remove a agent and add new agent
   * - Verify the newly added agent is present in the virtual team within the addNewAgent function
   * - Verify the Removed Agent is not present in the virtual team list
   * - Deleting the created virtual Team after verifying
   */
  it('C27915: Edit a global VT to remove agents from a Virtual Team', { tags: ['Virtual Team', 'staging'] }, () => {
    const vtName = virtualTeam.createVirtualTeam('Global');
    virtualTeam.searchResultVirtualTeamList().should('contain', vtName);
    // Clicking on Edit
    virtualTeam.editVirtualTeamButton(vtName).click();
    virtualTeam
      .editVirtualTeamSelectedAgentNameLabel()
      .eq(0)
      .then(($agentName) => {
        const agent1 = $agentName.text();
        virtualTeam.editVirtualTeamSelectedAgentRemoveIcon().eq(0).click();
        virtualTeam.addNewAgentInVirtualTeam(vtName);
        virtualTeam.editVirtualTeamSelectedAgentNameLabel().should('not.contain', agent1);
      });
    virtualTeam.deleteVirtualTeam(vtName);
  });

  /**
   * Regression C27921
   * - A virtual team will be created with the name given, Global team type and the agents selected as the members of the Virtual team
   * - Verifying of selected agent is present within the create function
   * - Verify the created Virtual team is present in the Virtual team list
   * - Click on Edit in Virtual team and verify the Save button is disabled
   * - Add new agent and verify the Save button is enabled
   * - Remove a agent and verify the Save button is enabled if there is more than 1 agent is selected
   * - Remove another agent and verify the save button is disabled if there is less than 2 agent is selected
   * - Add new agent and Verify the newly added agent is present in the virtual team within the addNewAgent function
   * - Deleting the created virtual Team after verifying
   */
  it('C27921: Edit Global VT - removing agents to reduce count of agents below two', { tags: ['Virtual Team', 'staging'] }, () => {
    cy.intercept('search/virtual_groups/_search*').as('search');
    const vtName = virtualTeam.createVirtualTeam('Global');
    virtualTeam.searchResultVirtualTeamList().should('contain', vtName);
    // Clicking on Edit
    virtualTeam.editVirtualTeamButton(vtName).click();
    virtualTeam.editVirtualTeamSaveButton().should('be.disabled');
    cy.slcHelpers.getAgentDetails().then((agentDetails) => {
      virtualTeam.vtCreatePopupSearchCustomerNameInput().should('be.visible').clear().type(agentDetails[0].sl_name);
      cy.wait('@search');
      virtualTeam.vtEditCustomerNameInSearchResultList().eq(0).click();
      virtualTeam.editVirtualTeamSaveButton().should('be.enabled');
      virtualTeam.editVirtualTeamSelectedAgentRemoveIcon().last().click();
      virtualTeam.editVirtualTeamSaveButton().should('be.enabled');
      virtualTeam.editVirtualTeamSelectedAgentRemoveIcon().last().wait(1000).click();
      virtualTeam.editVirtualTeamSaveButton().should('be.disabled');
      virtualTeam.addNewAgentInVirtualTeam(vtName);
    });
    virtualTeam.deleteVirtualTeam(vtName);
  });
});
