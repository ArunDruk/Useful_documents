import { urlHelpers } from '../../../utils';
import { virtualAccount, virtualTeam } from '../../../pages/index';

describe('Virtual Team - Create flow validation test cases', () => {
  const vtName = ['C9413 VT DO NOT DELETE', 'C2340 DO NOT DELETE'];

  let voName = '';
  let deleteFlag = 'False';

  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.virtualTeams);
    cy.waitForLoaders();
  });

  afterEach(() => {
    if (deleteFlag === 'True') {
      virtualTeam.deleteVirtualOrgs(voName);
      deleteFlag = 'False';
    }
  });

  /*
   * Go to Virtual Team page.
   * Click on "Create a Virtual Team" button and select "Personal VT" and Enter a unique name.
   * Created personal VG should be displayed in the VA page.
   * Click on "Create a Virtual Team" button and select "Personal VT".
   * Enter the same name used recently.
   * Validate that 'This name is already taken' error message should be displayed.
   */
  it('C124849: Verify duplicate name is not allowed when creating personal VT', { tags: ['Virtual Team', 'staging'] }, () => {
    const vtName1 = virtualTeam.createVirtualTeam('Personal');

    virtualTeam.createVirtualTeamButton().scrollIntoView().click();
    virtualTeam.teamTypePersonalButton().click();
    virtualTeam.virtualTeamNameInput().type(vtName1);
    virtualAccount.vaNameErrorLabel().should('have.text', 'This name is already taken.');
    virtualAccount.vaCreatePopupCancelOrBackButton().click();
    virtualTeam.deleteVirtualTeam(vtName1);
  });

  /*
   * Go to Virtual Team page.
   * Click on "Create a Virtual Org" button and select "Personal Org" and Enter a unique name
   * Created personal VG should be displayed in the VA page.
   * Click on "Create a Virtual Org" button and select "Personal Org".
   * Enter the same name used recently.
   * Validate that 'This name is already taken' error message should be displayed
   */
  it('C124850: Verify duplicate name is not allowed when creating personal Org', { tags: ['Virtual Team', 'staging'] }, () => {
    voName = virtualTeam.createVirtualOrgs('Personal', vtName);

    virtualTeam.verifyVirtualOrgsIsPresent(voName);
    virtualTeam.createVirtualOrgsButton().scrollIntoView().click();
    virtualTeam.OrgsTypePersonalButton().click();
    virtualTeam.virtualTeamNameInput().type(voName);
    virtualAccount.vaNameErrorLabel().should('have.text', 'This name is already taken.');
    virtualAccount.vaCreatePopupCancelOrBackButton().click();
    deleteFlag = 'True';
    virtualTeam.deleteVirtualOrgs(voName);
    deleteFlag = 'False';
  });

  /*
   * Go to Virtual Team page.
   * Click on "Create a Virtual Team" button and select "Global VT" and Enter a unique name.
   * Created personal VG should be displayed in the VA page.
   * Click on "Create a Virtual Team" button and select "Global VT".
   * Enter the same name used recently.
   * Validate that 'This name is already taken' error message should be displayed.
   */
  it('C124851: Verify duplicate name is not allowed when creating global VT', { tags: ['Virtual Team', 'staging'] }, () => {
    const vtName1 = virtualTeam.createVirtualTeam('Global');

    virtualTeam.createVirtualTeamButton().scrollIntoView().click();
    virtualTeam.teamTypeGlobalButton().click();
    virtualTeam.virtualTeamNameInput().type(vtName1);
    virtualAccount.vaNameErrorLabel().should('have.text', 'This name is already taken.');
    virtualAccount.vaCreatePopupCancelOrBackButton().click();
    virtualTeam.deleteVirtualTeam(vtName1);
  });

  /*
   * Go to Virtual Team page.
   * Click on "Create a Virtual Org" button and select "Global Org" and Enter a unique name.
   * Created personal VG should be displayed in the VA page.
   * Click on "Create a Virtual Org" button and select "Global Org".
   * Enter the same name used recently.
   * Validate that 'This name is already taken' error message should be displayed.
   */
  it('C124852: Verify duplicate name is not allowed when creating global Org', { tags: ['Virtual Team', 'staging'] }, () => {
    voName = virtualTeam.createVirtualOrgs('Global', vtName);

    virtualTeam.verifyVirtualOrgsIsPresent(voName);
    virtualTeam.createVirtualOrgsButton().scrollIntoView().click();
    virtualTeam.OrgsTypeGlobalButton().click();
    virtualTeam.virtualTeamNameInput().type(voName);
    virtualAccount.vaNameErrorLabel().should('have.text', 'This name is already taken.');
    virtualAccount.vaCreatePopupCancelOrBackButton().click();
    deleteFlag = 'True';
    virtualTeam.deleteVirtualOrgs(voName);
    deleteFlag = 'False';
  });

  /*
   * Go to Virtual Team page.
   * Click on "Create a Virtual Team" button and select "Personal VT" and Enter a unique name
   * Created personal VG should be displayed in the VA page.
   * Click on "Create a Virtual Org" button and select "Personal Org".
   * Enter the same name used recently.
   * Validate that 'This name is already taken' error message should be displayed
   */
  it('C124913: Verify duplicate name is not allowed when creating personal Org flow-2', { tags: ['Virtual Team', 'staging'] }, () => {
    const vtName1 = virtualTeam.createVirtualTeam('Personal');

    virtualTeam.createVirtualOrgsButton().scrollIntoView().click();
    virtualTeam.OrgsTypePersonalButton().click();
    virtualTeam.virtualTeamNameInput().type(vtName1);
    virtualAccount.vaNameErrorLabel().should('have.text', 'This name is already taken.');
    virtualAccount.vaCreatePopupCancelOrBackButton().click();
    virtualTeam.deleteVirtualTeam(vtName1);
  });

  /*
   * Go to Virtual Team page.
   * Click on "Create a Virtual Team" button and select "Global VT" and Enter a unique name
   * Created personal VG should be displayed in the VA page.
   * Click on "Create a Virtual Org" button and select "Global Org".
   * Enter the same name used recently.
   * Validate that 'This name is already taken' error message should be displayed
   */
  it('C124914: Verify duplicate name is not allowed when creating global Org flow-2', { tags: ['Virtual Team', 'staging'] }, () => {
    const vtName1 = virtualTeam.createVirtualTeam('Global');

    virtualTeam.createVirtualOrgsButton().scrollIntoView().click();
    virtualTeam.OrgsTypeGlobalButton().click();
    virtualTeam.virtualTeamNameInput().type(vtName1);
    virtualAccount.vaNameErrorLabel().should('have.text', 'This name is already taken.');
    virtualAccount.vaCreatePopupCancelOrBackButton().click();
    virtualTeam.deleteVirtualTeam(vtName1);
  });
});
