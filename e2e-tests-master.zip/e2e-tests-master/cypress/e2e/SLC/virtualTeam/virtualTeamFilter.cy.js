import { urlHelpers } from '../../../utils';
import { consolePage, globalFilters } from '../../../pages/index';

describe('Virtual Team Filter', () => {
  beforeEach(() => {
    cy.loginByApi();
    // cy.visit(urlHelpers.virtualTeams);
  });

  /**
   * Regression C6596
   * - The Console page-> Backlog section should show only the details of the agents who belong to the VT whose filter is applied.
   */
  // This is skipped as Newly created Vgroup will take time to reflect in elastic search
  // Iskander is working on this
  it('C6596: Virtual team filter in Console page', { tags: ['Virtual Team', '@FilterTests'] }, () => {
    // Temp Fix due to Elastic wait - comment below line and last delete vt line, added static vtName, removed virtualTeam from import
    const vtName = 'C9413 VT DO NOT DELETE'; // virtualTeam.createVirtualTeam('Global');
    // Navigating to the Console page
    cy.visit(urlHelpers.console.home);
    cy.waitForLoaders();
    consolePage.newCasesTab().click();
    const beforeValue = consolePage.getListsHeaderTitle();
    globalFilters.selectAgentInQuickFilter(vtName);
    consolePage.newCasesTab().click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(3000);
    consolePage
      .newCasesTabHeaderList()
      .eq(0)
      .then((afterValue) => {
        expect(afterValue.text()).not.equal(beforeValue[0]);
      });
    cy.slcHelpers.clearAgentsQuickFilter();
    // Deleting the Created Virtual Team
    /* cy.visit(urlHelpers.virtualTeams);
    // virtualTeam.deleteVirtualTeam(vtName);
    */
  });
});
