import { randId, urlHelpers } from '../../../utils';
import { virtualTeam, virtualAccount } from '../../../pages/index';

describe('Virtual Team- Cancel', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.virtualTeams);
  });

  /**
   * Regression - C37683
   * - Navigate to the Virtual team page
   * - Click on create virtual team button
   * - Select the team type as personal and enter the vtName, click Next button
   * - Select two agent and verify the selected agent are displayed and Create button is enabled
   * - Click on the back button and verify the create popup first tab is displaying
   * - Click on cancel button and verify the virtual team is not created
   */
  it('C37683: Virtual Team - Cancel VT creation workflow', { tags: ['Virtual Team', 'staging'] }, () => {
    cy.waitForLoaders();
    cy.intercept('search/virtual_groups/_search*').as('search');
    virtualTeam.createVirtualTeamButton().scrollIntoView().should('be.visible').click();
    virtualTeam.teamTypePersonalButton().should('be.visible').click();
    const vtName = `Test Personal Team ${randId()}`;
    virtualTeam.virtualTeamNameInput().type(vtName);
    virtualTeam.vtCreatePopupNextOrSubmitButton().should('be.visible').click();
    virtualTeam.vtCreatePopupSearchCustomerNameInput().should('be.visible').type('a');
    cy.wait('@search');
    virtualTeam.vtCreatePopupCustomerSearchResultList().eq(0).click();
    virtualTeam.vtCreatePopupNextOrSubmitButton().should('be.disabled');
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(2000);
    virtualTeam.vtCreatePopupCustomerSearchResultList().eq(1).click();
    virtualTeam.vtCreatePopupNextOrSubmitButton().should('be.enabled');
    virtualAccount.vaCreatePopupCancelOrBackButton().click();
    virtualTeam.virtualTeamNameInput().invoke('attr', 'value').should('contain', vtName);
    virtualAccount.vaCreatePopupCancelOrBackButton().click();
    virtualTeam.verifyVirtualTeamIsNotPresent(vtName);
  });
});
