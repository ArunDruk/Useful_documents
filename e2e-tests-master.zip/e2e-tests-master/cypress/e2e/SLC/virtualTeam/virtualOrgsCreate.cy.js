import { urlHelpers } from '../../../utils';
import { virtualTeam } from '../../../pages/index';

describe('Creating Virtual Team', () => {
  const vtName = ['C9413 VT DO NOT DELETE', 'C2340 DO NOT DELETE'];
  // const vtId = [];
  let voName = '';
  let deleteFlag = 'False';

  /* TODO: Temp Fix due to Elastic wait - comment below before () after () and vtId, added static vtName, removed randId from Import utils line
  // creating 2 virtual team
  before(() => {
    cy.loginByApi();
    for (let i = 0; i < 2; i += 1) {
      vtName[i] = `Test Global Team ${randId()}`;
      cy.slcHelpers
        .getAgentIds(5)
        .then((agentIds) => cy.slcHelpers.createVT(vtName[i], agentIds))
        .then((response) => {
          vtId[i] = response.body.id;
        });
    }
  });

  after(() => {
    cy.slcHelpers.deleteVgroup(vtId[0]);
    cy.slcHelpers.deleteVgroup(vtId[1]);
  });
  */

  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.virtualTeams);
  });

  afterEach(() => {
    if (deleteFlag === 'True') {
      virtualTeam.deleteVirtualOrgs(voName);
      deleteFlag = 'False';
    }
  });

  /**
   * Regression C9413
   * - A virtual Orgs will be created with the  given name, type Global and the Virtual team selected as the members of the Virtual Orgs
   * - Verify the created Virtual Orgs is present in the Virtual Orgs list (within the verifyVirtualOrgsIsPresent function)
   * - afterEach - Deleting the created virtual Orgs after verifying
   * - after() - Deleting the created 2 virtual team
   */
  it('C9413: Create a Global Virtual Organisation', { tags: ['Virtual Team', 'staging'] }, () => {
    cy.waitForLoaders();
    voName = virtualTeam.createVirtualOrgs('Global', vtName);
    deleteFlag = 'True';
    virtualTeam.verifyVirtualOrgsIsPresent(voName);
  });

  /**
   * Regression C9414
   * - A virtual Orgs will be created with the given name, type Personal and the Virtual team selected as the members of the Virtual Orgs
   * - Verify the created Virtual Orgs is present in the Virtual Orgs list (within the verifyVirtualOrgsIsPresent function)
   * - afterEach - Deleting the created virtual Orgs after verifying
   * - after() - Deleting the created 2 virtual team
   */
  it('C9414: Create a Personal Virtual Organisation', { tags: ['Virtual Team', 'staging'] }, () => {
    cy.waitForLoaders();
    voName = virtualTeam.createVirtualOrgs('Personal', vtName);
    deleteFlag = 'True';
    virtualTeam.verifyVirtualOrgsIsPresent(voName);
  });

  /**
   * Regression C11804
   * - A virtual Orgs will be created with the given name, type Global and the Virtual team selected as the members of the Virtual Orgs
   * - Verify the created Virtual Orgs is present in the Virtual Orgs list (within the verifyVirtualOrgsIsPresent function)
   * - Deleting the created virtual Orgs after verifying
   * - after() - Deleting the created 2 virtual team
   */
  it('C11804: Delete a Global VO', { tags: ['Virtual Team', 'staging'] }, () => {
    cy.waitForLoaders();
    voName = virtualTeam.createVirtualOrgs('Global', vtName);
    deleteFlag = 'True';
    virtualTeam.verifyVirtualOrgsIsPresent(voName);
    virtualTeam.deleteVirtualOrgs(voName);
    deleteFlag = 'False';
  });

  /**
   * Regression C11806
   * - A virtual Orgs will be created with the given name, type Personal and the Virtual team selected as the members of the Virtual Orgs
   * - Verify the created Virtual Orgs is present in the Virtual Orgs list (within the verifyVirtualOrgsIsPresent function)
   * - Deleting the created virtual Orgs after verifying
   * - after() - Deleting the created 2 virtual team
   */
  it('C11806: Delete a Personal VO', { tags: ['Virtual Team', 'staging'] }, () => {
    cy.waitForLoaders();
    voName = virtualTeam.createVirtualOrgs('Personal', vtName);
    virtualTeam.verifyVirtualOrgsIsPresent(voName);
    deleteFlag = 'True';
    virtualTeam.deleteVirtualOrgs(voName);
    deleteFlag = 'False';
  });
});
