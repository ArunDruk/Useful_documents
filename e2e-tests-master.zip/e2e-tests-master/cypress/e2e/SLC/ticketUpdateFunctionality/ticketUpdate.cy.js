import { urlHelpers } from '../../../utils';
import { consolePage, customerFavorites, pluginErrorPopup, supportHub } from '../../../pages';

describe('Ticket Update Functionality Tests', () => {
  beforeEach(function beforeEachHook() {
    // if (!Cypress.config().baseUrl.includes('qa-automation')) this.skip();

    cy.loginByApi();
    cy.visit(urlHelpers.console.home);
  });

  // Regression C194
  it('C194: Check the "mark as favourite" icon', { tags: 'Ticket Update Functionality' }, () => {
    cy.getByTestId('consolePage-tabsSlider-tab-Tickets').click();
    cy.waitForLoaders();

    cy.getByTestId('common-caseList-defaultItem-cardTitle').eq(0).click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(3000);
    cy.getByTestId('supportHub-SHContainer').should('be.visible');
    cy.getByTestId('supportHub-caseCustomer-CustomerName')
      .should('be.visible')
      .then(() => {
        cy.getByTestId('supportHub-caseCustomer-favoriteCaseTrigger')
          .invoke('attr', 'data-status')
          .then((favIcon) => {
            if (favIcon === 'unchecked') {
              // code for click fav and navigate to fav page
              cy.getByTestId('supportHub-caseCustomer-favoriteCaseTrigger').click().invoke('attr', 'data-status').should('contain', 'checked');
              cy.getByTestId('supportHub-actionWrapper-closeDialog').should('be.visible').click();
              cy.getByTestId('supportHub-SHContainer').should('not.exist');
            } else {
              // code for already fav so nav to code
              cy.getByTestId('supportHub-caseCustomer-favoriteCaseTrigger').invoke('attr', 'data-status').should('contain', 'checked');
              cy.getByTestId('supportHub-actionWrapper-closeDialog').should('be.visible').click();
              cy.getByTestId('supportHub-SHContainer').should('not.exist');
            }
          });
        // Navigating to the Customer favourites page
        cy.visit(urlHelpers.myCustomers);
        cy.waitForLoaders();
        customerFavorites.removeFavoriteButton().eq(0).click();
      });
  });

  // Regression C191
  it("C191: Check the 'Mark as Acknowledge' feature", { tags: 'Ticket Update Functionality' }, () => {
    cy.getByTestId('consolePage-tabsSlider-tab-Negative_Sentiments').should('be.visible').click();
    cy.getByTestId('sentimentsFeed-lightFilter-groupBy-btn').click();
    cy.get('[data-testid="common-dropdown-sentiment_type"]').click();
    cy.getByTestId('consolePage-tabs-case-card').eq(1).click();
    cy.waitForLoaders();
    cy.getByTestId('supportHub-SHContainer').should('be.visible');
    cy.waitForLoaders();
    cy.getByTestId('supportHub-sentiment-card')
      .eq(0)
      .should('be.visible')
      .then(($btn) => {
        $btn.trigger('mouseover');
        cy.getByTestId('supportHub-sentiment-acknowledge').eq(0).click();
        cy.getByTestId('supportHub-sentiment-acknowledgedWatermarkIcon').should('be.visible');
        cy.getByTestId('supportHub-sentiment-acknowledgeContainer').should('contain.text', 'Acknowledged by');
        cy.getByTestId('supportHub-sentiment-removeAcknowledge').eq(0).click({ force: true });
      });
  });
});

describe('Ticket Update Functionality Case Notes', () => {
  beforeEach(function beforeEachHook() {
    // This cannot be executed in qa-automation
    // if (Cypress.config().baseUrl.includes('qa-automation')) this.skip();

    cy.intercept('POST', 'api/v0/support/case_notes').as('addCaseNote');

    cy.loginByApi();
    cy.visit(urlHelpers.console.tabsWithTimeFilterLastSevenDays.newCases);
  });

  // Regression C193
  it('C193: Check the "add a note" feature', { tags: 'Ticket Update Functionality' }, () => {
    consolePage.unassignedCaseCardLists().eq(0).click();
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();

    supportHub.addPrivateCaseNote('case notes added for Testing');
    cy.wait('@addCaseNote').then(({ response }) => {
      if (response.statusCode !== 200) {
        pluginErrorPopup.maybeLaterButton().should('be.visible');
      } else {
        supportHub.commonCaseCommentText().should('contain.text', 'case notes added for Testing');
        // Closing the SupportHub popup
        supportHub.closeButton().should('be.visible').click();
        supportHub.baseContainer().should('not.exist');
      }
    });
  });
});
