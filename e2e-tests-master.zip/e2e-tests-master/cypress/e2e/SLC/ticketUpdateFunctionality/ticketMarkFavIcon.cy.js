import { urlHelpers } from '../../../utils';
import { consolePage, supportHub, apiHelpers } from '../../../pages/index';

beforeEach(() => {
  cy.loginByApi();
  cy.visit(urlHelpers.console.home);
  apiHelpers.removeAllFavoriteCustomers();
  // if (!Cypress.config().baseUrl.includes('qa-automation')) this.skip();
});

describe('Ticket Update Functionality Tests', () => {
  /**
   * Regression C195
   * - when the user clicks on the favourite icon from the ticket to remove the client from favourite section,
   * the client should also get removed from the  favourite section in 'Clients' page.
   */
  it('C195: Check the "mark as favourite" icon (unmark)', { tags: ['Ticket Update Functionality', 'staging'] }, () => {
    consolePage.newCasesTab().click();
    consolePage.unassignedCasesCardTitle().eq(0).click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
    supportHub
      .caseCustomerNameLabel()
      .should('be.visible')
      .then(() => {
        supportHub
          .favoriteButton()
          .invoke('attr', 'data-status')
          .then((favIcon) => {
            if (favIcon === 'unchecked') {
              supportHub.favoriteButton().click().invoke('attr', 'data-status').should('contain', 'checked');
              supportHub.favoriteButton().click().invoke('attr', 'data-status').should('contain', 'unchecked');
              supportHub.closeButton().should('be.visible').click();
              supportHub.baseContainer().should('not.exist');
            } else {
              supportHub.favoriteButton().click().invoke('attr', 'data-status').should('contain', 'unchecked');
              supportHub.closeButton().should('be.visible').click();
              supportHub.baseContainer().should('not.exist');
            }
          });
        // Navigating to the Customer favourites page
        cy.visit(urlHelpers.myCustomers);
        cy.contains('You have no Favorites at this time.').should('exist');
      });
  });
});
