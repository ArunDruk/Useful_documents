import { urlHelpers } from '../../../utils';
import { consolePage, supportHub } from '../../../pages/index';

beforeEach(() => {
  cy.loginByApi();
  cy.visit(urlHelpers.console.home);
  // if (!Cypress.config().baseUrl.includes('qa-automation')) this.skip();
});

describe('Ticket Update Functionality Tests', () => {
  /**
   * Regression C197
   * - The details mentioned in "Open for" will show for how long the ticket is open, starting from the day its first raised.
   */
  it("C197: Check the 'Ticket History' Data", { tags: ['Ticket Update Functionality', 'staging', 'prod'] }, () => {
    consolePage.newCasesTab().click();
    consolePage.unassignedCasesCardTitle().eq(0).click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(3000);
    supportHub
      .baseContainer()
      .should('be.visible')
      .then(() => {
        supportHub.highlightsPopupCaseCreationTimeText().should('exist');
      });
  });
  /**
   * Regression C198
   * - The details mentioned in "Client Wait Time" will show the detail of for how long in total the customer waited for a response during the lifetime of the case.
   * Meaning if the customer waited for a respone for 2 hours and again after his reply he had to wait another 1 hour then the Customer Wait Time = 3 hrs.
   */
  it("C198: Check the 'Ticket History' Data (Client wait time)", { tags: ['Ticket Update Functionality', 'staging', 'prod'] }, () => {
    consolePage.newCasesTab().click();
    consolePage.unassignedCasesCardTitle().eq(0).click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(3000);
    supportHub
      .baseContainer()
      .should('be.visible')
      .then(() => {
        supportHub.highlightsPopupCaseCustomerWaitTimeText().should('exist');
      });
  });
});
