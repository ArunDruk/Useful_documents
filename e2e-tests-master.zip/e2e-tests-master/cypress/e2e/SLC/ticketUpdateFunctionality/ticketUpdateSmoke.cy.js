import { urlHelpers } from '../../../utils';
import { pluginErrorPopup } from '../../../pages';
import { getUnassignedOpenCaseDetails } from '../supportHub/support';

describe('Ticket Update Functionality Tests', () => {
  beforeEach(function beforeEachHook() {
    // Ticket update tests should not be run against staging or prod
    // if (!Cypress.config().baseUrl.includes('foundry')) this.skip();

    cy.intercept('POST', 'api/v0/support/case_statuses/*').as('updateStatus');
    cy.intercept('POST', 'api/v0/support/case_priorities/*').as('updatePriority');
    cy.intercept('POST', 'api/v0/support/case_owners/*').as('updateOwner');
    cy.intercept('POST', 'api/v2/ticket/assignment/recommendation').as('recommendations');

    cy.loginByApi();
    getUnassignedOpenCaseDetails().then((caseDetails) => {
      const caseDetail = Cypress._.sample(caseDetails);

      cy.wrap(caseDetail.id).as('caseId');

      cy.visit(urlHelpers.supportHubCasePage(caseDetail.id));
    });
  });

  it('C173: should update case status', { tags: 'SupportHub' }, function updateCaseStatus() {
    cy.getByTestId('supportHub-caseField-status').click();
    cy.get('[data-testid=supportHub-caseStatus-statusTagTooltip][data-status=unchecked]')
      .first()
      .then((elem) => {
        const newCaseStatus = elem.text();

        cy.wrap(elem).click();
        cy.wait('@updateStatus').then(({ response }) => {
          if (response.statusCode !== 200) {
            pluginErrorPopup.maybeLaterButton().should('be.visible');
          } else {
            cy.getByTestId('supportHub-caseField-status').should('have.text', newCaseStatus);
          }
        });
      });
  });

  it('C175: should update case priority', { tags: 'SupportHub' }, function updateCasePriority() {
    cy.getByTestId('supportHub-caseField-priority').click();
    cy.get('[data-testid=supportHub-caseField-priorityTooltip][data-status=unchecked]')
      .first()
      .then((elem) => {
        const newCasePriority = elem.text().toLocaleLowerCase();

        cy.wrap(elem).click();
        cy.wait('@updatePriority').then(({ response }) => {
          if (response.statusCode !== 200) {
            pluginErrorPopup.maybeLaterButton().should('be.visible');
          } else {
            cy.getByTestId('supportHub-caseField-priority').then(($priority) => {
              const priority = $priority.text().toLocaleLowerCase();
              expect(priority).to.eq(newCasePriority);
            });
          }
        });
      });
  });
});
