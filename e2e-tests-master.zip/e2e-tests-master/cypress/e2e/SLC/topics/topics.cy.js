import path from 'path';
import { targetDatabase, urlHelpers } from '../../../utils';
import { setStatusAsPrimaryTopic, setPriorityAsSecondaryTopic } from './support';
import { datePicker, filters, topics } from '../../../pages';

describe('Patterns and Outliers Tests', () => {
  beforeEach(() => {
    // TODO: Remove this code once SLC-32860 is fixed
    Cypress.on('uncaught:exception', () => false);

    cy.intercept('POST', `api/cache/${targetDatabase}/tickets/data`).as('ticketsData');
    cy.intercept('POST', `api/cache/${targetDatabase}/tickets/groupBy`).as('ticketsGroupBy');

    cy.loginByApi();
    setStatusAsPrimaryTopic();
    setPriorityAsSecondaryTopic();
    cy.slcHelpers.clearCustomersQuickFilter();
    cy.slcHelpers.clearAgentsQuickFilter();
    cy.slcHelpers.clearCaseFieldQuickFilter();
    cy.slcHelpers.deleteGlobalFilter();

    cy.visit(urlHelpers.topics);
  });

  // Smoke & Sanity C201
  it('C201: Checking the functionality of ticket status filter (All)', { tags: 'Topics' }, () => {
    // Selecting the Topic dropdown value
    topics.topicsFirstTopicDropdown().should('be.visible').click();
    topics.topicsFirstTopicDropdownListItems().should('be.visible');
    topics.topicsTopicDropdownFirstItem().should('be.visible').click();
    // Click on Case Status - Open
    topics.topicsCaseStatusOpenButton().should('be.visible').click();
    cy.waitForLoaders();

    topics.topicsHeaderTicketCount().then(($btn) => {
      // Getting the Open case count
      const openCount = $btn.text().replace(',', '');

      // Click on Case Status - Closed
      topics.topicsCaseStatusClosedButton().should('be.visible').click();
      cy.waitForLoaders();

      topics.topicsHeaderTicketCount().then(($btn1) => {
        const closedCount = $btn1.text().replace(',', '');

        const totalCount = parseInt(openCount, 10) + parseInt(closedCount, 10);
        // Clicking on the Case Status - All
        topics.topicsCaseStatusAllButton().should('be.visible').click();
        cy.waitForLoaders();

        // Compare the case count of All is Greater than Open cases
        topics.topicsHeaderTicketCount().then(($btn2) => {
          const allCount = $btn2.text().replace(',', '');
          expect(parseInt(allCount, 10)).to.be.equal(totalCount);
        });
      });
    });
  });

  // Regression C205
  it('C205: Checking the functionality of "TOPIC" Group By option', { tags: 'Topics' }, () => {
    // Selecting the Topic dropdown value
    topics.topicsFirstTopicDropdown().click();
    topics.topicsFirstTopicDropdownListItems().should('be.visible');
    topics.topicsTopicDropdownFirstItem().click();
    // verify the Secondary Dropdown
    topics.topicsSecondTopicDropdown().should('be.visible').click();
    topics.topicsFirstTopicDropdownListItems().should('be.visible');
    topics.topicsTopicDropdownFirstItem().click();

    topics
      .topicSearchInputField()
      .first()
      .invoke('attr', 'value')
      .then((firstDropdownValue) => {
        topics.topicsSecondTopicDropdown().should('be.visible').click();
        topics.topicsFirstTopicDropdownListItems().should('be.visible');

        topics.topicsTopicDropdownFirstItem().find('a').should('have.text', firstDropdownValue).and('have.class', 'disabled');
      });
  });

  // Regression C202
  it('C202: Checking the functionality of "Sort By" filter', { tags: 'Topics' }, () => {
    // Click on the Sort by filter Icon
    topics.sortByDropdown().should('be.visible').click();
    topics.topicsSortByNumberOfCasesDropdownValue().contains('Number of cases(High-low)');
    topics.topicsSortByPercentChangeDropdownValue().contains('% Change(High-low)');
  });

  // Regression C203
  it('C203: Checking the functionality of "Sort By" filter (Number of tickets)', { tags: 'Topics' }, () => {
    // Click on the Sort by filter Icon
    topics.sortByDropdown().then(($btnValue) => {
      const selectedValue = $btnValue.text();
      if (selectedValue === 'Number of cases (High-low)') {
        topics.sortByDropdown().click();
        topics.topicsSortByPercentChangeDropdownValue().should('be.visible').click();
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(1000);
        topics.sortByDropdown().click();
        topics.topicsSortByNumberOfCasesDropdownValue().click();
      } else {
        topics.sortByDropdown().click();
        topics.topicsSortByNumberOfCasesDropdownValue().click();
      }
    });

    cy.url().should('include', 'sortBy=cases');
  });

  // Regression C2254
  it('C2254: Test export csv', { tags: 'Topics' }, () => {
    // Clicking on the Case List in the Secondary Tabs
    topics.topicsCaseListTab().click();
    const expectedFileName = `topics-case-list.csv`;
    const downloadsFolder = Cypress.config('downloadsFolder');
    // Click on the Export Icon
    cy.contains('Export as CSV').should('be.visible').click();
    // Verify the file is exported in CSV format
    cy.readFile(path.join(downloadsFolder, expectedFileName)).should('exist');
  });

  // Regression C2256
  // We have logged bug for the Calendar SLC-35136
  it('C2256: Test calendar', { tags: 'Topics' }, () => {
    // Clicking on the Date range filter and select last month
    datePicker.datePickerTrigger().should('be.visible').click();
    datePicker.thisMonthRadioButton().click();
    datePicker.lastMonthRadioButton().click();
    datePicker.lastMonthDropdownOption(1).click();
    datePicker.applyButton().click();
    datePicker.datePickerTrigger().should('contain.text', 'Last month');
    // Clicking on the Date range filter and select year to date
    datePicker.datePickerTrigger().should('be.visible').click();
    datePicker.lastMonthRadioButton().click();
    datePicker.yearToDateRadioButton().click();
    datePicker.applyButton().click();
    datePicker.datePickerTrigger().should('contain.text', 'Year to date');
    // Clicking on the Date range filter and select Q1 Quarter
    datePicker.datePickerTrigger().should('be.visible').click();
    datePicker.thisMonthRadioButton().click();
    datePicker.quarterRadioButton().click();
    datePicker.applyButton().click();
    datePicker.datePickerTrigger().should('contain.text', 'Q1');
    // Clicking on the Date range filter and select this month
    datePicker.datePickerTrigger().should('be.visible').click();
    datePicker.yearToDateRadioButton().click();
    datePicker.thisMonthRadioButton().click();
    datePicker.applyButton().click();
    datePicker.datePickerTrigger().should('contain.text', 'This month');
  });

  // Regression C2257
  it('C2257: Test topic selection', { tags: 'Topics' }, () => {
    // Selecting the two topics
    // Adding status as dynamic filter
    filters.addDynamicFilterButton().click();
    filters.dynamicFilterHeader().then(($selected) => {
      const selectedButton = $selected.text();
      if (selectedButton.includes('selected')) {
        filters.dynamicFilterSelectedRemoveButton().click();
      }
      topics.dynamicFilterStatusCheckbox().click();
      topics.dynamicFilterSaveButton().click();
      // eslint-disable-next-line cypress/no-unnecessary-waiting
      cy.wait(3000);
      topics.dynamicFilterDropdown().eq(0).click();
      // Verifying status field in first topic card
      filters
        .dynamicFilterDropdownListFirstItem()
        .invoke('text')
        .then((topicOneFirstValue) => {
          filters.dynamicFilterDropdownCancelButton().click();
          topics.topicsPageCardTile().contains(topicOneFirstValue);
        });
    });
    // Adding priority as dynamic filter
    filters.addDynamicFilterButton().click();
    filters.dynamicFilterHeader().then(($selected) => {
      // cy.get('.styles__CustomFieldsWrapper-sc-38d0do-21.cpSRqb').then(($selected) => {
      const selectedButton = $selected.text();
      if (selectedButton.includes('selected')) {
        filters.dynamicFilterSelectedRemoveButton().click();
      }
      topics.dynamicFilterPriorityCheckbox().click();
      topics.dynamicFilterSaveButton().click();
      // eslint-disable-next-line cypress/no-unnecessary-waiting
      cy.wait(3000);
      topics.dynamicFilterDropdown().eq(0).click();
      // Verifying priority field in second topic list
      filters
        .dynamicFilterDropdownListFirstItem()
        .invoke('text')
        .then((topicSecondFirstValue) => {
          filters.dynamicFilterDropdownCancelButton().click();
          topics.topicPriorities().contains(topicSecondFirstValue);
        });
    });
  });

  /**
   * Regression C217
   * - Navigate to Topics section page and case count
   * - Select the Date Filter last 3 months if current selection is This month or vice versa and click on cancel
   * - Verify Topics page values was not changed (check pre and post values of case count)
   */
  it('C217: Checking the functionality of searching "Tickets created within" date range filter (Cancel)', { tags: ['Topics', 'staging'] }, () => {
    cy.waitForLoaders();
    topics
      .topicsHeaderTicketCount()
      .eq(0)
      .then((bfrCaseCount) => {
        cy.waitForLoaders();
        const beforeCaseCount = bfrCaseCount.text();
        datePicker.datePickerTrigger().then(($datePicker) => {
          if ($datePicker.text().trim() === 'This month') {
            datePicker.datePickerTrigger().click();
            datePicker.yearToDateRadioButton().click();
          } else {
            datePicker.datePickerTrigger().click();
            datePicker.thisMonthRadioButton().click();
          }
          datePicker.cancelButton().click();
          cy.waitForLoaders();
          cy.waitForLoaders();
          // get new case count
          topics
            .topicsHeaderTicketCount()
            .eq(0)
            .then((afterCaseCount) => {
              cy.waitForLoaders();
              expect(afterCaseCount.text()).equal(beforeCaseCount);
            });
        });
      });
  });

  /**
   * Regression C216
   * - Navigate to Topics section page and case count
   * - Select the Date Filter last 3 months if current selection is This month or vice versa and then click apply
   * - Verify Topics page values was filtered (check pre and post values of case count)
   */
  it('C216: Checking the functionality of searching "Tickets created within" date range filter (Apply)', { tags: ['Topics', 'staging'] }, () => {
    cy.waitForLoaders();
    topics
      .topicsHeaderTicketCount()
      .eq(0)
      .then((bfrCaseCount) => {
        cy.waitForLoaders();
        const beforeCaseCount = bfrCaseCount.text();
        datePicker.datePickerTrigger().then(($datePicker) => {
          if ($datePicker.text().trim() === 'This month') {
            datePicker.selectAndApplyLast3MonthsRadioButton();
          } else {
            datePicker.selectAndApplyThisMonthRadioButton();
          }
          cy.waitForLoaders();
          cy.waitForLoaders();
          // get new case count
          topics
            .topicsHeaderTicketCount()
            .eq(0)
            .then((afterCaseCount) => {
              cy.waitForLoaders();
              expect(afterCaseCount.text()).not.equal(beforeCaseCount);
            });
        });
      });
  });
});
