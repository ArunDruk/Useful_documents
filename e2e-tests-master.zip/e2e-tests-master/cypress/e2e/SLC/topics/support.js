export const setStatusAsPrimaryTopic = () =>
  cy.request({
    method: 'PUT',
    url: '/api/users/dashboard_settings',
    headers: { 'Content-Type': 'application/json' },
    body: {
      dashboardName: 'support',
      replace: false,
      settingsKey: 'topics_page_settings',
      settingsSubKey: null,
      settingsValue: { selected_topics: { primary: 'sl_status' } },
    },
  });

export const setPriorityAsSecondaryTopic = () =>
  cy.request({
    method: 'PUT',
    url: '/api/users/dashboard_settings',
    headers: { 'Content-Type': 'application/json' },
    body: {
      dashboardName: 'support',
      replace: false,
      settingsKey: 'topics_page_settings',
      settingsSubKey: null,
      settingsValue: { selected_topics: { secondary: 'sl_priority' } },
    },
  });
