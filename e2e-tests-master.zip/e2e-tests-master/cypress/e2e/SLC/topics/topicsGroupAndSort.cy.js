import { targetDatabase, urlHelpers } from '../../../utils';
import { setStatusAsPrimaryTopic, setPriorityAsSecondaryTopic } from './support';
import { topics, datePicker } from '../../../pages';

describe('Topics Group and Sort Tests', () => {
  beforeEach(() => {
    cy.loginByApi();
    setStatusAsPrimaryTopic();
    setPriorityAsSecondaryTopic();
    cy.visit(urlHelpers.topics);
  });

  before(() => {
    // TODO: Remove this code once SLC-32860 is fixed
    Cypress.on('uncaught:exception', () => false);

    cy.intercept('POST', `api/cache/${targetDatabase}/tickets/data`).as('ticketsData');
    cy.intercept('POST', `api/cache/${targetDatabase}/tickets/groupBy`).as('ticketsGroupBy');
  });

  /*
    Get values of how many tickets are shown when choose each:  Open, Closed and All status
    Ensure open and closed ticket counts added together = total count
   */
  it('C199: Checking the functionality of ticket status filter (open)', { tags: ['Topics', 'staging', 'prod'] }, () => {
    // Click on Case Status - Open
    topics.topicsCaseStatusOpenButton().should('be.visible').click();
    cy.waitForLoaders();
    topics.topicsHeaderTicketCount().then(($btn) => {
      // Getting the Open case count
      const openCount = $btn.text().replace(',', '');

      // Click on Case Status - Closed
      topics.topicsCaseStatusClosedButton().should('be.visible').click();
      cy.waitForLoaders();

      topics.topicsHeaderTicketCount().then(($btn1) => {
        const closedCount = $btn1.text().replace(',', '');

        const totalCount = parseInt(openCount, 10) + parseInt(closedCount, 10);
        // Clicking on the Case Status - All
        topics.topicsCaseStatusAllButton().should('be.visible').click();
        cy.waitForLoaders();

        // Compare the case count of All is Greater than Open cases
        topics.topicsHeaderTicketCount().then(($btn2) => {
          const allCount = $btn2.text().replace(',', '');
          expect(parseInt(allCount, 10)).to.be.equal(totalCount);
        });
      });
    });
  });

  /*
    Get values of how many tickets are shown when choose each:  Open, Closed and All status
    Ensure open and closed ticket counts added together = total count
   */
  it('C200: Checking the functionality of ticket status filter (Close)', { tags: ['Topics', 'staging', 'prod'] }, () => {
    // Click on Case Status - Open
    topics.topicsCaseStatusOpenButton().should('be.visible').click();
    cy.waitForLoaders();
    topics.topicsHeaderTicketCount().then(($btn) => {
      // Getting the Open case count
      const openCount = $btn.text().replace(',', '');

      // Click on Case Status - Closed
      topics.topicsCaseStatusClosedButton().should('be.visible').click();
      cy.waitForLoaders();

      topics.topicsHeaderTicketCount().then(($btn1) => {
        const closedCount = $btn1.text().replace(',', '');

        const totalCount = parseInt(openCount, 10) + parseInt(closedCount, 10);
        // Clicking on the Case Status - All
        topics.topicsCaseStatusAllButton().should('be.visible').click();
        cy.waitForLoaders();

        // Compare the case count of All is Greater than Open cases
        topics.topicsHeaderTicketCount().then(($btn2) => {
          const allCount = $btn2.text().replace(',', '');
          expect(parseInt(allCount, 10)).to.be.equal(totalCount);
        });
      });
    });
  });

  /*
    Select each item in the Sort By dropdown
    Ensure the current Sort By option shows the newly changed option
   */
  it('C204: Checking the functionality of "Sort By" filter (% change)', { tags: ['Topics', 'staging', 'prod'] }, () => {
    topics.topicsSortByDropdownArrow().click();
    topics.topicsSortByNumberOfCasesDropdownValue().click();
    // click elsewhere to collapse dropdown
    topics.topicsFirstTopicDropdown().click();
    // Ensure new value was chosen
    topics.topicsSortByCurrentValue().contains('Number of cases');
    topics.topicsSortByDropdownArrow().click();
    topics.topicsSortByPercentChangeDropdownValue().click();
    // click elsewhere to collapse dropdown
    topics.topicsFirstTopicDropdown().click();
    // Ensure new value was chosen
    topics.topicsSortByCurrentValue().contains('% Change');
  });

  /*
    Status is set as first Topic and Priority is set as 2nd (per BeforeEach)
    Type 'prio' into first Topic and ensure Priority is suggested
    Type 'stat' into second Topic and ensure Status is suggested
   */
  it('C209:checking the functionality of "TOPIC" Group By option (Type)', { tags: ['Topics', 'staging', 'prod'] }, () => {
    topics.topicsFirstTopicDropdown().should('be.visible').click().type('{selectall}prio');
    topics.topicsTopicDropdownFirstItem().contains('Priority').click();
    topics.topicsSecondTopicDropdown().should('be.visible').click().type('{selectall}stat');
    topics.topicsTopicDropdownFirstItem().contains('Status').click();
  });

  /*
    Status is set as first Topic and Priority is set as 2nd (per BeforeEach)
    Type 'prio' into first Topic and ensure Priority is suggested
    Select in then type in 'prio' again and ensure it finds no matches (it is removed from the options).
    Type 'stat' into second Topic and ensure Status is suggested
    Select in then type in 'stat' again and ensure it finds no matches (it is removed from the options).
   */
  it('C206:checking the functionality of "TOPIC" Group By option (Apply)', { tags: ['Topics', 'staging', 'prod'] }, () => {
    topics.topicsFirstTopicDropdown().should('be.visible').click().type('{selectall}prio');
    topics.topicsTopicDropdownFirstItem().contains('Priority').click();
    // type in again
    topics.topicsFirstTopicDropdown().should('be.visible').click().type('{selectall}prio');
    topics.topicsTropicDropdownNoMatchesFound().contains('No matches found.');

    topics.topicsSecondTopicDropdown().should('be.visible').click().type('{selectall}stat');
    topics.topicsTopicDropdownFirstItem().contains('Status').click();
    // type in again
    topics.topicsSecondTopicDropdown().should('be.visible').click().type('{selectall}stat');
    topics.topicsTropicDropdownNoMatchesFound().contains('No matches found.');
  });

  /**
   * Regression C214
   * - Set Calendar to Last 3 months and apply
   * - Get the current Case Count and change the calendar to this month and Apply
   * - Get New Case count and ensure the count has changed so the Apply works properly
   */
  it('C214: Checking the functionality of searching "Tickets created within" date range filter', { tags: ['Topics', 'staging', 'prod'] }, () => {
    // set calendar to this month (if not already)
    datePicker.datePickerTrigger().then(($btn) => {
      if (!$btn.text().includes('Last 3 months')) {
        // change calendar to last 3 months
        datePicker.datePickerTrigger().click();
        datePicker.selectLastMonthWithOption(3);
        datePicker.datePickerTrigger().should('have.text', 'Last 3 months');
        cy.waitForLoaders();
      }
    });
    topics.topicsHeaderTicketCount().then(($btn) => {
      const beforeCount = $btn.text().replace(',', '');
      // change calendar to this month
      datePicker.selectAndApplyThisMonthRadioButton();
      cy.waitForLoaders();
      topics.topicsHeaderTicketCount().then(($btn1) => {
        const afterCount = $btn1.text().replace(',', '');
        expect(afterCount).not.equal(beforeCount);
      });
    });
  });

  /**
   * Regression C215
   * - Open calendar widget from Topics page
   * - Scroll through months forward and back on both starting and ending calendars
   */
  it('C215: Checking the functionality of searching "Tickets created within" date range filter (Arrow nav)', { tags: ['Topics', 'staging', 'prod'] }, () => {
    datePicker.datePickerTrigger().click();
    datePicker.lastMonthDropdown().click();
    datePicker.scrollThroughCalendar();
  });
});
