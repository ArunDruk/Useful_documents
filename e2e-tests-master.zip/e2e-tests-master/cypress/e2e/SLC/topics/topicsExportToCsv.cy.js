import path from 'path';
import { targetDatabase, urlHelpers } from '../../../utils';
import { setStatusAsPrimaryTopic, setPriorityAsSecondaryTopic } from './support';
import { topics } from '../../../pages';

describe('Topics Export Tests', () => {
  beforeEach(() => {
    cy.loginByApi();
    setStatusAsPrimaryTopic();
    setPriorityAsSecondaryTopic();
    cy.visit(urlHelpers.topics);
  });

  before(() => {
    // TODO: Remove this code once SLC-32860 is fixed
    Cypress.on('uncaught:exception', () => false);

    cy.intercept('POST', `api/cache/${targetDatabase}/tickets/data`).as('ticketsData');
    cy.intercept('POST', `api/cache/${targetDatabase}/tickets/groupBy`).as('ticketsGroupBy');
  });

  /**
   * - Go to Sentiments tab
   * - Export as CSV
   * - Validate the file exists
   */
  it('C211: Test export csv', { tags: ['Topics', 'staging'] }, () => {
    topics.topicsPageCardTile().eq(0).click();
    cy.waitForLoaders();
    topics
      .topicsPageCardTileTitle()
      .eq(0)
      .then((title) => {
        const cardTitle = title.text();
        // Clicking on the Sentiments tab in the Secondary Tabs
        topics.topicsSentimentsTab().click();
        topics.topicsThreeDotsToExportButton().click();
        // Click on the Export Icon
        topics.topicsExportCountByCasesButton().click();
        const expectedFileName = `topics-${cardTitle}-All.csv`;
        const downloadsFolder = Cypress.config('downloadsFolder');
        // Verify the file is exported in CSV format
        cy.readFile(path.join(downloadsFolder, expectedFileName)).should('exist');
      });
  });

  /**
   * Regression C213
   * - Go to Responder tab
   * - Export as CSV
   * - Validate the file exists
   */
  it('C213: Checking the functionality of "Topics split by" (Responder count)', { tags: ['Topics', 'staging'] }, () => {
    topics.topicsPageCardTile().eq(0).click();
    cy.waitForLoaders();
    topics
      .topicsPageCardTileTitle()
      .eq(0)
      .then((title) => {
        const cardTitle = title.text();
        // Clicking on the Sentiments tab in the Secondary Tabs
        topics.responderTab().click();
        topics.topicsThreeDotsToExportButton().click();
        // Click on the Export Icon
        topics.topicsExportCountByCasesButton().click();
        const expectedFileName = `topics-${cardTitle}-All.csv`;
        const downloadsFolder = Cypress.config('downloadsFolder');
        // Verify the file is exported in CSV format
        cy.readFile(path.join(downloadsFolder, expectedFileName)).should('exist');
      });
  });
});
