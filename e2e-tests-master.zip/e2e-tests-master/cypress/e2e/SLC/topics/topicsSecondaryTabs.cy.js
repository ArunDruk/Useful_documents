import moment from 'moment-timezone';
import { targetDatabase, urlHelpers } from '../../../utils';
import { setStatusAsPrimaryTopic, setPriorityAsSecondaryTopic } from './support';
import { consolePage, supportHub, topics } from '../../../pages';

describe('Trend Analytics (Topics) Tests', () => {
  beforeEach(() => {
    // TODO: Remove this code once SLC-32860 is fixed
    Cypress.on('uncaught:exception', () => false);

    cy.intercept('POST', `api/cache/${targetDatabase}/tickets/data`).as('ticketsData');
    cy.intercept('POST', `api/cache/${targetDatabase}/tickets/groupBy`).as('ticketsGroupBy');

    cy.loginByApi();
    setStatusAsPrimaryTopic();
    setPriorityAsSecondaryTopic();
    cy.visit(urlHelpers.topics);
  });

  /**  Regression C218
   * - Visit Topics page
   * - Verify both topics are already populated with case field values.
   * - Click on the Case List tab in the charts section.
   * - Click on the first case in the list
   * - The case SH should open correctly
   */
  it('C218: Secondary Tabs (Case list)', { tags: 'Topics' }, () => {
    // Clicking on the Case List in the Secondary Tabs
    topics.topicsCaseListTab().click();
    cy.waitForLoaders();
    cy.contains('Export as CSV').should('be.visible');
    topics.topicsCaseListGroupBy().should('contain', 'Customer');
    topics
      .topicsCaseListGroupBy()
      .should('be.visible')
      .then(() => {
        // first customer name
        topics
          .topicsCaseListCustomerName()
          .eq(1)
          .then((custName) => {
            const beforeSort = custName.text();
            topics.topicsCaseListGroupBy().scrollIntoView().click();
            topics
              .topicsCaseListCustomerName()
              .eq(1)
              .invoke('text')
              .then((custName1) => {
                expect(custName1).to.not.equal(beforeSort);
                topics.topicsCaseListCustomerName().eq(1).click();
                cy.waitForLoaders();
                supportHub.baseContainer().should('be.visible');
                cy.waitForLoaders();
                supportHub.caseCustomerNameLabel().should('be.visible');
              });
          });
      });
  });

  /**  Regression C37655
   * - Visit Topics page
   * - Click on the Case List tab in the charts section.
   * - Click on All in the Seconday Topics Grid
   * - Click on the first case in the list
   * - Verify the Breadcrumbs is displaying as expected
   */
  it('C37655: Validate the display of Breadcrumbs shows correctly', { tags: 'Topics' }, () => {
    // Clicking on the Case List in the Secondary Tabs
    topics.topicsCaseListTab().click();
    cy.waitForLoaders();
    cy.contains('Export as CSV').should('be.visible');
    topics.topicNameSecondaryTableRowList().contains('All').click();
    // first customer name
    topics
      .topicsCaseListCustomerName()
      .eq(1)
      .should('be.visible')
      .then(() => {
        topics.topicsCaseListCustomerName().eq(1).click();
        cy.waitForLoaders();
        supportHub.baseContainer().should('be.visible');
        cy.waitForLoaders();
        supportHub
          .caseIdLabel()
          .invoke('text')
          .then(($caseId) => {
            supportHub.breadcrumbContent().invoke('text').should('contain', `Patterns and OutliersAllCase List${$caseId}`);
          });
        cy.waitForLoaders();
        supportHub.closeButton().click();
      });
  });

  /*
   * - Visit Topics page
   * - Verify both topics are already populated with case field values.
   * - Click on the first response tab in the charts section.
   * - Set the dropdown value to Agents
   * - Verify that the error page is not shown
   */
  it('C219: Secondary Tabs (First response time)', { tags: 'Topics' }, () => {
    const currentMonth = moment().format('MMM');

    topics.firstResponseTab().click();
    cy.waitForLoaders();

    topics.xAxis().should('contain', 'Ticket Created At');
    topics.xAxisLabels().should('contain.text', currentMonth);
    topics.yAxis().should('contain', 'First Response Time (days)');

    topics.secondaryTabDropdown().click();
    topics.firstResponseDropdownOptionAgents().click();
    topics.errorMessage().should('not.exist');
  });

  /*
   * - Visit Topics page
   * - Verify both topics are already populated with case field values.
   * - Click on the Conversation tab in the charts section.
   * - Set the dropdown value to Agents
   * - Verify that the error page is not shown
   */
  it('C220: Secondary Tabs (Conversation count)', { tags: 'Topics' }, () => {
    const currentMonth = moment().format('MMM');

    topics.conversationsTab().click();
    cy.waitForLoaders();

    topics.xAxis().should('contain', 'Ticket Created At');
    topics.xAxisLabels().should('contain.text', currentMonth);
    topics.yAxis().should('contain', 'Conversations Count');

    topics.secondaryTabDropdown().click();
    topics.conversationCountDropdownOptionAgents().click();
    topics.errorMessage().should('not.exist');
  });

  /*
   * - Visit Topics page
   * - Verify both topics are already populated with case field values.
   * - Click on the Responder in the charts section.
   * - Set the dropdown value to Agents
   * - Verify that the error page is not shown
   */
  it('C221: Secondary Tabs (Responder)', { tags: 'Topics' }, () => {
    const currentMonth = moment().format('MMM');

    topics.responderTab().click();
    cy.waitForLoaders();

    topics.xAxis().should('contain', 'Ticket Created At');
    topics.xAxisLabels().should('contain.text', currentMonth);
    topics.yAxis().should('contain', 'Responders Count');

    topics.secondaryTabDropdown().click();
    topics.responderCountDropdownOptionAgents().click();
    topics.errorMessage().should('not.exist');
  });

  /*
   * - Visit Topics page
   * - Verify both topics are already populated with case field values.
   * - Click on the Keywords tab in the charts section.
   * - Click the first chart element
   * - Click a case card
   * - Verify that the supporthub modal loads
   */
  it('C222: Secondary Tabs (Keywords)', { tags: 'Topics' }, () => {
    topics.keywordsTab().click();
    cy.waitForLoaders();

    topics.chartElements().first().click();

    consolePage
      .unassignedCasesCardTitle()
      .eq(0)
      .then((buttonText) => {
        const customerName = buttonText.text();
        consolePage.unassignedCaseCardLists().eq(0).should('be.visible').click();
        cy.waitForLoaders();
        supportHub.caseCustomerNameLabel().invoke('text').should('be.equal', customerName);
        supportHub.closeButton().click();
      });
  });

  /*
   * - Visit Topics page
   * - Verify both topics are already populated with case field values.
   * - Click on the Sentiments Score tab in the charts section.
   * - Set the dropdown value to Agents
   * - Verify that the error page is not shown
   */
  it('C223: Secondary Tabs (Sentiments score)', { tags: 'Topics' }, () => {
    const currentMonth = moment().format('MMM');

    topics.sentimentsTab().click();
    cy.waitForLoaders();

    topics.xAxis().should('contain', 'Ticket Created At');
    topics.xAxisLabels().should('contain.text', currentMonth);
    topics.yAxis().should('contain', 'Sentiment Score');

    topics.secondaryTabDropdown().click();
    topics.sentimentDropdownOptionAgents().click();
    topics.errorMessage().should('not.exist');
  });

  /*
   * - Visit Topics page
   * - Verify both topics are already populated with case field values.
   * - Click on the Sentiments tab in the charts section.
   * - Set the dropdown value to Agents
   * - Verify that the error page is not shown
   */
  it('C3774: Sentiments Count tab loading', { tags: 'Topics' }, () => {
    const currentMonth = moment().format('MMM');

    topics.topicsSentimentsTab().click();
    cy.waitForLoaders();

    topics.xAxis().should('contain', 'Ticket Created At');
    topics.xAxisLabels().should('contain.text', currentMonth);
    topics.yAxis().should('contain', 'Sentiment Count');

    topics.secondaryTabDropdown().click();
    topics.sentimentCountDropdownOptionAgents().click();
    topics.errorMessage().should('not.exist');
  });
});
