import { urlHelpers } from '../../../utils';
import { consolePage, trends } from '../../../pages';

describe('Trends: Expand All Collapse All Functionality Check', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.trends);
    cy.waitForLoaders();
  });

  afterEach(() => {
    consolePage.selectAllSignalsInDropdown();
    consolePage.selectShowAllInDropdown();
    consolePage.groupByElapsedTime();
  });

  /*
   * Go to Text Analysis page.
   * Navigate to the Need Attention tab and verify we have landed in expected tab.
   * Verify the Sentiment Signal dropdown text is All Signal if not select All in the Dropdown value.
   * Select 'Elasped Time' in thed dropdown, Click 'Collapse all' button and validate case card is not exist.
   * Click 'Expand all' button and validate case card is exist.
   */
  it(
    'C127061: Text Analysis - Need Attention tab - Expand all <-> Collapse all Functionality Check',
    { tags: ['Customers', 'staging', 'prod'] },
    function needAttentionExpandAll() {
      trends.needAttentionTab().should('be.visible').click();
      consolePage.selectAllSignalsInDropdown();
      consolePage.selectShowAllInDropdown();
      consolePage.groupByElapsedTime();
      consolePage.expandAllConsoleLists();
      consolePage.selectAllSignalsInDropdown();
      consolePage.selectShowAllInDropdown();
      consolePage.groupByElapsedTime();
      consolePage.expandAllConsoleLists();
      cy.waitForLoaders();
      consolePage.collapseExpandButton().should('be.visible').and('have.text', 'Collapse All');
      consolePage.caseCard().should('be.visible');
      consolePage.caseListCustomerName().should('be.visible');
      consolePage.collapseExpandButton().click();
      cy.waitForLoaders();
      consolePage.collapseExpandButton().should('be.visible').and('have.text', 'Expand All');
      consolePage.caseCard().should('not.exist');
      consolePage.caseListCustomerName().should('not.exist');
    }
  );

  /*
   * Go to Text Analysis page.
   * Navigate to the Negative Sentiment tab and verify we have landed in expected tab.
   * Verify the Sentiment Signal dropdown text is All Signal if not select All in the Dropdown value.
   * Select 'Elasped Time' in thed dropdown, Click 'Collapse all' button and validate case card is not exist.
   * Click 'Expand all' button and validate case card is exist.
   */
  it(
    'C127062: Text Analysis - Negative Sentiment tab - Expand all <-> Collapse all Functionality Check',
    { tags: ['Customers', 'staging', 'prod'] },
    function negativeSentimentExpandAll() {
      trends.negativeSentimentsTab().should('be.visible').click();
      consolePage.selectAllSignalsInDropdown();
      consolePage.selectShowAllInDropdown();
      consolePage.groupByElapsedTime();
      consolePage.expandAllConsoleLists();
      cy.waitForLoaders();
      consolePage.collapseExpandButton().should('be.visible').and('have.text', 'Collapse All');
      consolePage.caseCard().should('be.visible');
      consolePage.caseListCustomerName().should('be.visible');
      consolePage.collapseExpandButton().click();
      cy.waitForLoaders();
      consolePage.collapseExpandButton().should('be.visible').and('have.text', 'Expand All');
      consolePage.caseCard().should('not.exist');
      consolePage.caseListCustomerName().should('not.exist');
    }
  );

  /*
   * Go to Text Analysis page.
   * Navigate to the Positive Sentiment tab and verify we have landed in expected tab.
   * Verify the Sentiment Signal dropdown text is All Signal if not select All in the Dropdown value.
   * Select 'Elasped Time' in thed dropdown, Click 'Collapse all' button and validate case card is not exist.
   * Click 'Expand all' button and validate case card is exist.
   */
  it(
    'C127063: Text Analysis - Positive Sentiment tabs - Expand all <-> Collapse all Functionality Check',
    { tags: ['Customers', 'staging', 'prod'] },
    function positiveSentimentExpandAll() {
      trends.positiveSentimentsTab().should('be.visible').click();
      consolePage.selectAllSignalsInDropdown();
      consolePage.selectShowAllInDropdown();
      consolePage.groupByElapsedTime();
      consolePage.expandAllConsoleLists();
      cy.waitForLoaders();
      consolePage.collapseExpandButton().should('be.visible').and('have.text', 'Collapse All');
      consolePage.caseCard().should('be.visible');
      consolePage.caseListCustomerName().should('be.visible');
      consolePage.collapseExpandButton().click();
      cy.waitForLoaders();
      consolePage.collapseExpandButton().should('be.visible').and('have.text', 'Expand All');
      consolePage.caseCard().should('not.exist');
      consolePage.caseListCustomerName().should('not.exist');
    }
  );

  /*
   * Go to Text Analysis page.
   * Navigate to the Product Feedback tab and verify we have landed in expected tab.
   * Verify the Sentiment Signal dropdown text is All Signal if not select All in the Dropdown value.
   * Select 'Elasped Time' in thed dropdown, Click 'Collapse all' button and validate case card is not exist.
   * Click 'Expand all' button and validate case card is exist.
   */
  it(
    'C127064: Text Analysis - Product Feedback tabs - Expand all <-> Collapse all Functionality Check',
    { tags: ['Customers', 'staging', 'prod'] },
    function productFeedbackExpandAll() {
      trends.productFeedbackTab().should('be.visible').click();
      consolePage.selectAllSignalsInDropdown();
      consolePage.selectShowAllInDropdown();
      consolePage.groupByElapsedTime();
      consolePage.expandAllConsoleLists();
      cy.waitForLoaders();
      consolePage.collapseExpandButton().should('be.visible').and('have.text', 'Collapse All');
      consolePage.caseCard().should('be.visible');
      consolePage.caseListCustomerName().should('be.visible');
      consolePage.collapseExpandButton().click();
      cy.waitForLoaders();
      consolePage.collapseExpandButton().should('be.visible').and('have.text', 'Expand All');
      consolePage.caseCard().should('not.exist');
      consolePage.caseListCustomerName().should('not.exist');
    }
  );
});
