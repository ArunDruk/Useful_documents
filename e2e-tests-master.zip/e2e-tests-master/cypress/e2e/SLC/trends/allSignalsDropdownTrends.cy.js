import { urlHelpers } from '../../../utils';
import { consolePage, trends } from '../../../pages';

describe('Trends: All Signals Dropdown workflow', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.trends);
    cy.waitForLoaders();
  });

  afterEach(() => {
    consolePage.selectAllSignalsInDropdown();
    consolePage.selectShowAllInDropdown();
    consolePage.groupByElapsedTime();
  });

  /*
   * Go to Text Analysis page.
   * Navigate to the Need Attention tab and verify we have landed in expected tab
   * Verify the Sentiment Signal dropdown text is All Signal if not select All in the Dropdown value
   * Click on Select All Signals and veirfy the data-status is unchecked
   * Select only one signal value and verify the case card with selected signal alone is displaying
   * After verify Select All Signals in the Sentiment Signal dropdown
   */
  it('C124867: Trends - Need Attention tabs - Sentiment Signal filter', { tags: ['Customers', 'staging', 'prod'] }, () => {
    trends.needAttentionTab().should('be.visible').click();
    consolePage.selectAllSignalsInDropdown();
    consolePage.selectShowAllInDropdown();
    consolePage.groupByElapsedTime();
    consolePage.expandAllConsoleLists();
    consolePage.consoleTabsShowingHeaderTitle().should('be.exist');
    consolePage.consoleTabsShowingHeaderTitle().invoke('text').should('contain', `Showing`);
    consolePage.consoleSentimentsTabsHeaderTitle().should('be.exist');
    consolePage.consoleSentimentsTabsHeaderTitle().invoke('text').should('contain', `Need Attention`);
    consolePage.sentimentsTabsSignalsDropdown().click();
    consolePage.signalsDropdownSentimentSignalHeader().invoke('text').should('contain', `Sentiment Signal`);
    consolePage.signalsDropdownSentimentSignalCheckbox().invoke('attr', 'data-status').should('eq', 'checked');
    cy.waitForLoaders();
    consolePage
      .sentimentSignalsdropdown()
      .should('be.visible')
      .then(($value) => {
        const signalValue = $value.text();
        consolePage.sentimentSignalsdropdown().click();
        if (signalValue !== 'All Signals') {
          consolePage.sentimentSignalsAllCheckBox().click({ force: true }).invoke('attr', 'data-status').should('equal', 'checked');
        }
        consolePage.sentimentSignalsAllCheckBox().click({ force: true }).invoke('attr', 'data-status').should('equal', 'unchecked');
        consolePage.sentimentSignalsdropdown().click();
        consolePage
          .sentimentSignalsIndividualNameLabel()
          .eq(0)
          .should('be.visible')
          .then(($name) => {
            const signalName = $name.text();
            consolePage.sentimentSignalsIndividualCheckbox(signalName).eq(0).invoke('attr', 'data-status').should('equal', 'unchecked');
            consolePage.sentimentSignalsIndividualCheckbox(signalName).eq(0).click({ force: true }).invoke('attr', 'data-status').should('equal', 'checked');
            cy.waitForLoaders();
            consolePage.sentimentSignalsdropdown().click();
            consolePage.sentimentSignalsdropdown().invoke('text').should('contain', signalName);
            consolePage.caseCardDetectedSentimentLabel().should('contain', signalName);
          });
      });
  });

  /*
   * Go to Text Analysis insights page.
   * Navigate to the Negative Sentiment tab and verify we have landed in expected tab
   * Verify the Sentiment Signal dropdown text is All Signal if not select All in the Dropdown value
   * Click on Select All Signals and veirfy the data-status is unchecked
   * Select only one signal value and verify the case card with selected signal alone is displaying
   * After verify Select All Signals in the Sentiment Signal dropdown
   */
  it('C124868: Trends - Negative Sentiment Tab - Sentiment Signal filter', { tags: ['Customers', 'staging', 'prod'] }, () => {
    trends.negativeSentimentsTab().should('be.visible').click();
    consolePage.selectAllSignalsInDropdown();
    consolePage.selectShowAllInDropdown();
    consolePage.groupByElapsedTime();
    consolePage.expandAllConsoleLists();
    cy.waitForLoaders();
    consolePage.consoleTabsShowingHeaderTitle().should('be.exist');
    consolePage.consoleTabsShowingHeaderTitle().invoke('text').should('contain', `Showing`);
    consolePage.consoleSentimentsTabsHeaderTitle().should('be.exist');
    consolePage.consoleSentimentsTabsHeaderTitle().invoke('text').should('contain', `Negative Sentiments`);
    consolePage.sentimentsTabsSignalsDropdown().click();
    consolePage.signalsDropdownSentimentSignalHeader().invoke('text').should('contain', `Sentiment Signal`);
    consolePage.signalsDropdownSentimentSignalCheckbox().invoke('attr', 'data-status').should('eq', 'checked');
    cy.waitForLoaders();
    consolePage
      .sentimentSignalsdropdown()
      .should('be.visible')
      .then(($value) => {
        const signalValue = $value.text();
        consolePage.sentimentSignalsdropdown().click();
        if (signalValue !== 'All Signals') {
          consolePage.sentimentSignalsAllCheckBox().click({ force: true }).invoke('attr', 'data-status').should('equal', 'checked');
        }
        consolePage.sentimentSignalsAllCheckBox().click({ force: true }).invoke('attr', 'data-status').should('equal', 'unchecked');
        consolePage.sentimentSignalsdropdown().click();
        consolePage
          .sentimentSignalsIndividualNameLabel()
          .eq(0)
          .should('be.visible')
          .then(($name) => {
            const signalName = $name.text();
            consolePage.sentimentSignalsIndividualCheckbox(signalName).eq(0).invoke('attr', 'data-status').should('equal', 'unchecked');
            consolePage.sentimentSignalsIndividualCheckbox(signalName).eq(0).click({ force: true }).invoke('attr', 'data-status').should('equal', 'checked');
            cy.waitForLoaders();
            consolePage.sentimentSignalsdropdown().click();
            consolePage.sentimentSignalsdropdown().invoke('text').should('contain', signalName);
            consolePage.caseCardDetectedSentimentLabel().should('contain', signalName);
          });
      });
  });

  /*
   * Go to Text Analysis page.
   * Navigate to the Positive Sentiment tab and verify we have landed in expected tab
   * Verify the Sentiment Signal dropdown text is All Signal if not select All in the Dropdown value
   * Click on Select All Signals and veirfy the data-status is unchecked
   * Select only one signal value and verify the case card with selected signal alone is displaying
   * After verify Select All Signals in the Sentiment Signal dropdown
   */
  it('C124869: Trends - Positive Sentiment Tab - Sentiment Signal filter', { tags: ['Customers', 'staging', 'prod'] }, () => {
    trends.positiveSentimentsTab().should('be.visible').click();
    consolePage.selectAllSignalsInDropdown();
    consolePage.selectShowAllInDropdown();
    consolePage.groupByElapsedTime();
    consolePage.expandAllConsoleLists();
    consolePage.consoleTabsShowingHeaderTitle().should('be.exist');
    consolePage.consoleTabsShowingHeaderTitle().invoke('text').should('contain', `Showing`);
    consolePage.consoleSentimentsTabsHeaderTitle().should('be.exist');
    consolePage.consoleSentimentsTabsHeaderTitle().invoke('text').should('contain', `Positive Sentiments`);
    consolePage.sentimentsTabsSignalsDropdown().click();
    consolePage.signalsDropdownSentimentSignalHeader().invoke('text').should('contain', `Sentiment Signal`);
    consolePage.signalsDropdownSentimentSignalCheckbox().invoke('attr', 'data-status').should('eq', 'checked');
    cy.waitForLoaders();
    consolePage
      .sentimentSignalsdropdown()
      .should('be.visible')
      .then(($value) => {
        const signalValue = $value.text();
        consolePage.sentimentSignalsdropdown().click();
        if (signalValue !== 'All Signals') {
          consolePage.sentimentSignalsAllCheckBox().click({ force: true }).invoke('attr', 'data-status').should('equal', 'checked');
        }
        consolePage.sentimentSignalsAllCheckBox().click({ force: true }).invoke('attr', 'data-status').should('equal', 'unchecked');
        consolePage.sentimentSignalsdropdown().click();
        consolePage
          .sentimentSignalsIndividualNameLabel()
          .eq(0)
          .should('be.visible')
          .then(($name) => {
            const signalName = $name.text();
            consolePage.sentimentSignalsIndividualCheckbox(signalName).eq(0).invoke('attr', 'data-status').should('equal', 'unchecked');
            consolePage.sentimentSignalsIndividualCheckbox(signalName).eq(0).click({ force: true }).invoke('attr', 'data-status').should('equal', 'checked');
            cy.waitForLoaders();
            consolePage.sentimentSignalsdropdown().click();
            consolePage.sentimentSignalsdropdown().invoke('text').should('contain', signalName);
            consolePage.caseCardDetectedSentimentLabel().should('contain', signalName);
          });
      });
  });

  /*
   * Go to Text Analysis page.
   * Navigate to the Product Feedback tab and verify we have landed in expected tab
   * Verify the Sentiment Signal dropdown text is All Signal if not select All in the Dropdown value
   * Click on Select All Signals and veirfy the data-status is unchecked
   * Select only one signal value and verify the case card with selected signal alone is displaying
   * After verify Select All Signals in the Sentiment Signal dropdown
   */
  it('C124870: Trends - Product Feedback tabs - Sentiment Signal filter', { tags: ['Customers', 'staging', 'prod'] }, () => {
    trends.productFeedbackTab().should('be.visible').click();
    consolePage.selectAllSignalsInDropdown();
    consolePage.selectShowAllInDropdown();
    consolePage.groupByElapsedTime();
    consolePage.expandAllConsoleLists();
    consolePage.consoleTabsShowingHeaderTitle().should('be.exist');
    consolePage.consoleTabsShowingHeaderTitle().invoke('text').should('contain', `Showing`);
    consolePage.consoleSentimentsTabsHeaderTitle().should('be.exist');
    consolePage.consoleSentimentsTabsHeaderTitle().invoke('text').should('contain', `Product Feedback`.trim());
    consolePage.sentimentsTabsSignalsDropdown().click();
    consolePage.signalsDropdownSentimentSignalHeader().invoke('text').should('contain', `Sentiment Signal`);
    consolePage.signalsDropdownSentimentSignalCheckbox().invoke('attr', 'data-status').should('eq', 'checked');
    cy.waitForLoaders();
    consolePage
      .sentimentSignalsdropdown()
      .should('be.visible')
      .then(($value) => {
        const signalValue = $value.text();
        consolePage.sentimentSignalsdropdown().click();
        if (signalValue !== 'All Signals') {
          consolePage.sentimentSignalsAllCheckBox().click({ force: true }).invoke('attr', 'data-status').should('equal', 'checked');
        }
        consolePage.sentimentSignalsAllCheckBox().click({ force: true }).invoke('attr', 'data-status').should('equal', 'unchecked');
        cy.waitForLoaders();
        consolePage.sentimentSignalsdropdown().click();
        consolePage
          .sentimentSignalsIndividualNameLabel()
          .eq(0)
          .should('be.visible')
          .then(($name) => {
            const signalName = $name.text();
            consolePage.sentimentSignalsIndividualCheckbox(signalName).eq(0).invoke('attr', 'data-status').should('equal', 'unchecked');
            consolePage.sentimentSignalsIndividualCheckbox(signalName).eq(0).click({ force: true }).invoke('attr', 'data-status').should('equal', 'checked');
            consolePage.sentimentSignalsdropdown().click();
            consolePage.sentimentSignalsdropdown().invoke('text').should('contain', 'All Signals');
            consolePage.caseCardDetectedSentimentLabel().should('contain', signalName);
          });
      });
  });
});
