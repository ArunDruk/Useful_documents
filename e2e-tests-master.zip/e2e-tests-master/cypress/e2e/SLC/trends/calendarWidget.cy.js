import moment from 'moment-timezone';

import { urlHelpers } from '../../../utils';
import { datePicker, trends } from '../../../pages';

describe('Trends - Calendar Widget', { tags: ['trends', 'staging', 'prod'] }, () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.trends);

    // set the datepicker to 'This month' (if not already)
    datePicker.datePickerTrigger().then(($btn) => {
      if (!$btn.text().includes('Last 3 months')) {
        datePicker.selectAndApplyLast3MonthsRadioButton();
      }
    });

    datePicker.datePickerTrigger().click();
  });

  /*
   * Select 'Last N months' shortcut if current value is 'This month'
   * Select 'This month' shortcut
   * Click the Apply button
   *
   * Verify that the main chart x-axis labels contain the current month name
   */
  it('C344: should select a date range', () => {
    datePicker.thisMonthRadioButton().click();
    datePicker.applyButton().click();
    cy.waitForLoaders();

    trends.chartXAxisLabels().should('contain.text', moment().format('MMM'));
  });

  /*
   * Get the left side month label from datepicker
   * Click 1 on the datepicker left panel
   * Click 10 on the datepicker left panel
   * Click the Apply button
   *
   * Verify that the main chart x-axis label contains `1. {monthName}` and `10. {monthName}`
   */
  it('C346: should select a custom date range', () => {
    datePicker
      .visibleMonthDropdown()
      .first()
      .invoke('text')
      .then((selectedMonth) => {
        datePicker.calendarDayButton(' 1').first().click({ force: true });
        datePicker.calendarDayButton(' 10').first().click();
        datePicker.applyButton().click();
        cy.waitForLoaders();

        trends.chartXAxisLabels().first().should('contain.text', `1. ${selectedMonth.trim()}`).and('contain.text', `10. ${selectedMonth.trim()}`);
      });
  });
});
