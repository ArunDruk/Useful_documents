import { urlHelpers } from '../../../utils';
import { consolePage, filters, supportHub, trends } from '../../../pages';

describe('Trends - Search', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.trends);
  });

  /*
   * Search for the keyword 'test'
   *
   * Verify that the searched text chip exists and has a dashed border style
   */
  it('C321: should verify searched keyword has dotted border style chip', { tags: ['trends', 'staging'] }, () => {
    trends.searchForKeyword('test');
    cy.waitForLoaders();
    trends.currentlySearchedTextChips().should('exist');
    // trends.currentlySearchedTextChips().find('[data-testid=common-select-value]').should('have.css', 'border-style', 'dashed');
  });

  /*
   * Click the 'All' case status filter
   * Get the current case count from the KPI header
   *
   * Search for the keyword 'test'
   * Verify searched text chip exists
   * Click the 'Any of these phrases' radio button in the search popup
   * Click the 'All' case status filter to close the search popup
   *
   * Verify that the current KPI header count does not match the previous count
   */
  it('C322: Checking the functionality of the "Free text search" in search box', { tags: ['trends', 'staging'] }, () => {
    filters.allCaseStatusFilterButton().should('be.visible').click();
    cy.waitForLoaders();

    // Getting the all case count before search keyword
    trends
      .headerTicketCountLabel()
      .invoke('text')
      .then((caseCountBeforeSearch) => {
        // Enter Sample Value in Search field
        trends.searchForKeyword('test');
        trends.currentlySearchedTextChips().should('exist');
        trends.searchPopupAnyRadioButton().click();
        // Clicking on the Case Status - All
        filters.allCaseStatusFilterButton().click();
        cy.waitForLoaders();

        trends.headerTicketCountLabel().should('not.have.text', caseCountBeforeSearch);
      });
  });

  /*
   * Search for the keyword 'the'
   * Click the 'All' case status filter to close the search popup
   *
   * Verify that all tabs have data by checking case count text is not '0 cases'
   *
   * Go to the negative sentiments tab
   * Set the group by value to Elapsed Time
   * Click the expand all button (if cases list is collapsed)
   *
   * Open the first available case in SupportHub
   * Search the case comments section for the exact keyword used in the trends search field
   * Verify that the search yields results
   */
  it('C360: should show data in tabs on free-text search', { tags: ['trends', 'staging'] }, () => {
    const searchText = 'the';

    trends.searchForKeyword(searchText);
    filters.allCaseStatusFilterButton().click();

    trends.mainChartSearchedTextChips().should('be.visible').and('have.length', 1).and('have.text', searchText);

    trends.commonTabCaseCountLabel().each((countText) => {
      expect(countText.text()).to.not.equal('0cases');
    });

    trends.negativeSentimentsTab().click();
    trends.groupTabDataByElapsedTime();
    consolePage.expandAllConsoleLists();

    consolePage.caseCard().first().click();
    cy.waitForLoaders();

    supportHub.searchButton().click();
    supportHub.searchTextfield().type(searchText);

    cy.contains('[data-search-result]', RegExp(searchText, 'i')).first().should('be.visible');
  });
});
