import { urlHelpers } from '../../../utils';
import { datePicker, trends } from '../../../pages';

describe('Trends - Main Chart', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.trends);
  });

  /*
   * Filter the chart data for this month
   * Set the group by value to Priority
   * Click chart tooltips along the x-axis
   * Verify that the tooltip contains counts priority-wise
   */
  it('C348: Trends Chart (Tooltip)', { tags: ['trends', 'staging'] }, () => {
    datePicker.datePickerTrigger().then(($btn) => {
      if (!$btn.text().includes('This month')) {
        datePicker.selectAndApplyThisMonthRadioButton();
        cy.waitForLoaders();
      }
    });

    trends.groupByDropdownTrigger().click();
    trends.groupByDropdownOptions('Priority').click();

    trends
      .chartXAxisLabels()
      .first()
      .find('text')
      .each(($row) => {
        cy.wrap($row)
          .invoke('attr', 'x')
          .then((x) => {
            trends.chartTracker().realMouseMove(x, 70);
            trends.verifyMainChartTooltipPriorities();
          });
      });
  });
});
