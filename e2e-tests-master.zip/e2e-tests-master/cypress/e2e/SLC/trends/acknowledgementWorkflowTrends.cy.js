import { urlHelpers } from '../../../utils';
import { consolePage, customerBoardPage, datePicker, trends } from '../../../pages';

describe('Text Analysis: Acknowledgement Workflow', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.trends);
    datePicker.datePickerTrigger().then(($btn) => {
      if (!$btn.text().includes('Last 3 months')) {
        datePicker.selectAndApplyLast3MonthsRadioButton();
        cy.waitForLoaders();
      }
    });
    cy.waitForLoaders();
  });

  afterEach(() => {
    consolePage.selectAllSignalsInDropdown();
    consolePage.selectShowAllInDropdown();
    consolePage.groupByElapsedTime();
  });

  /*
   * Go to Text Analysis page.
   * Click on the Need Attention tab, Click the Elasped Time option in the groupedby dropdown.
   * While hovering on cases 'Acknowledge' tick mark is showing. Click the tick mark.
   * Validate that Acknowledged by QA with Cross icon should be displayed.
   * Click the Show Acknowledged option in the dropdown, Click on Cross icon in a feed.
   * Validate that Acknowledged by QA with Cross icon should not be displayed.
   */
  it('C124942: Verify the acknowledgement workflow in Need attention tab', { tags: ['Customers', 'staging'] }, () => {
    trends.needAttentionTab().should('be.visible').click();
    consolePage.selectAllSignalsInDropdown();
    consolePage.selectShowAllInDropdown();
    consolePage.groupByElapsedTime();
    consolePage.expandAllConsoleLists();
    consolePage.consoleTabsShowingHeaderTitle().should('exist');
    consolePage.consoleTabsShowingHeaderTitle().invoke('text').should('contain', `Showing`);
    consolePage.consoleSentimentsTabsHeaderTitle().should('exist');
    consolePage.consoleSentimentsTabsHeaderTitle().invoke('text').should('contain', `Need Attention`);
    cy.waitForLoaders();
    consolePage.acknowledgeDropdown().click({ force: true });
    consolePage.acknowledgeDropdownValueAll().should('be.visible').and('contain', `Show all`);
    consolePage.acknowledgeDropdownValueAck().should('be.visible').and('contain', `Show Acknowledged`);
    consolePage.acknowledgeDropdownValueUnack().should('be.visible').and('contain', `Show Unacknowledged`);
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    consolePage.consoleSentimentsTabsHeaderTitle().scrollIntoView().click();
    consolePage.caseCard().eq(0).scrollIntoView().trigger('mouseover');
    consolePage.sentimentAckButton().eq(0).scrollIntoView().click({ force: true });
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    consolePage
      .caseCardHeaderText()
      .invoke('text')
      .should('match', /acknowledged\s*byQA/);
    consolePage.acknowledgeLabelWithCrossIcon().eq(0).scrollIntoView().should('be.visible');
    consolePage.selectShowAcknowledgedInDropdown();
    cy.waitForLoaders();
    customerBoardPage.appContentContainer().scrollTo('top');
    consolePage.caseCard().eq(0).invoke('text').should('contain', 'acknowledged by');
    consolePage
      .caseCardTicketIdLabel()
      .eq(0)
      .then((caseNo) => {
        const caseID = caseNo.text();

        consolePage.acknowledgeLabelWithCrossIcon().eq(0).scrollIntoView().should('be.visible');
        consolePage.acknowledgeLabelWithCrossIcon().eq(0).scrollIntoView().trigger('mouseover');
        consolePage.acknowledgeLabelTooltip().invoke('text').should('include', 'Remove acknowledgement');
        consolePage.acknowledgeLabelWithCrossIcon().eq(0).scrollIntoView().click();
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(1000);
        consolePage.selectShowUnacknowledgedInDropdown();
        cy.get('body').should('contain', caseID);
        consolePage.selectShowAcknowledgedInDropdown();
        cy.get('body').should('not.contain', caseID);
      });
  });

  /*
   * Go to Text Analysis page.
   * Click on the Negative Sentiment tab, Click the Elasped Time option in the groupedby dropdown.
   * While hovering on cases 'Acknowledge' tick mark is showing. Click the tick mark.
   * Validate that Acknowledged by QA with Cross icon should be displayed.
   * Click the Show Acknowledged option in the dropdown, Click on Cross icon in a feed.
   * Validate that Acknowledged by QA with Cross icon should not be displayed.
   */
  it('C124948: Verify the acknowledgement workflow in Negative Sentiment tab', { tags: ['Customers', 'staging'] }, () => {
    trends.negativeSentimentsTab().should('be.visible').click();
    consolePage.selectAllSignalsInDropdown();
    consolePage.selectShowAllInDropdown();
    consolePage.groupByElapsedTime();
    consolePage.expandAllConsoleLists();
    consolePage.consoleTabsShowingHeaderTitle().should('exist');
    consolePage.consoleTabsShowingHeaderTitle().invoke('text').should('contain', `Showing`);
    consolePage.consoleSentimentsTabsHeaderTitle().should('be.exist');
    consolePage.consoleSentimentsTabsHeaderTitle().invoke('text').should('contain', `Negative Sentiments`);
    cy.waitForLoaders();
    consolePage.acknowledgeDropdown().click({ force: true });
    consolePage.acknowledgeDropdownValueAll().should('be.visible').and('contain', `Show all`);
    consolePage.acknowledgeDropdownValueAck().should('be.visible').and('contain', `Show Acknowledged`);
    consolePage.acknowledgeDropdownValueUnack().should('be.visible').and('contain', `Show Unacknowledged`);
    consolePage.groupByElapsedTime();
    consolePage.expandAllConsoleLists();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    consolePage.consoleSentimentsTabsHeaderTitle().scrollIntoView().click();
    consolePage.caseCard().eq(0).scrollIntoView().trigger('mouseover');
    consolePage.sentimentAckButton().eq(0).scrollIntoView().click({ force: true });
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    consolePage
      .caseCardHeaderText()
      .invoke('text')
      .should('match', /acknowledged\s*byQA/);
    consolePage.acknowledgeLabelWithCrossIcon().eq(0).scrollIntoView().should('be.visible');
    consolePage.selectShowAcknowledgedInDropdown();
    cy.waitForLoaders();
    customerBoardPage.appContentContainer().scrollTo('top');
    consolePage.caseCard().eq(0).invoke('text').should('contain', 'acknowledged by');
    consolePage
      .caseCardTicketIdLabel()
      .eq(0)
      .then((caseNo) => {
        const caseID = caseNo.text();

        consolePage.acknowledgeLabelWithCrossIcon().eq(0).scrollIntoView().should('be.visible');
        consolePage.acknowledgeLabelWithCrossIcon().eq(0).scrollIntoView().trigger('mouseover');
        consolePage.acknowledgeLabelTooltip().invoke('text').should('include', 'Remove acknowledgement');
        consolePage.acknowledgeLabelWithCrossIcon().eq(0).scrollIntoView().click();
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(1000);
        consolePage.selectShowUnacknowledgedInDropdown();
        cy.get('body').should('contain', caseID);
        consolePage.selectShowAcknowledgedInDropdown();
        cy.get('body').should('not.contain', caseID);
      });
  });

  /*
   * Go to Text Analysis page.
   * Click on the Positive Sentiment tab, Click the Elasped Time option in the groupedby dropdown.
   * While hovering on cases 'Acknowledge' tick mark is showing. Click the tick mark.
   * Validate that Acknowledged by QA with Cross icon should be displayed.
   * Click the Show Acknowledged option in the dropdown, Click on Cross icon in a feed.
   * Validate that Acknowledged by QA with Cross icon should not be displayed.
   */
  it('C124949: Verify the acknowledgement workflow in Positive Sentiment tab', { tags: ['Customers', 'staging'] }, () => {
    trends.positiveSentimentsTab().should('be.visible').click();
    consolePage.selectAllSignalsInDropdown();
    consolePage.selectShowAllInDropdown();
    consolePage.groupByElapsedTime();
    consolePage.expandAllConsoleLists();
    consolePage.consoleTabsShowingHeaderTitle().should('exist');
    consolePage.consoleTabsShowingHeaderTitle().invoke('text').should('contain', `Showing`);
    consolePage.consoleSentimentsTabsHeaderTitle().should('be.exist');
    consolePage.consoleSentimentsTabsHeaderTitle().invoke('text').should('contain', `Positive Sentiments`);
    cy.waitForLoaders();
    consolePage.acknowledgeDropdown().click({ force: true });
    consolePage.acknowledgeDropdownValueAll().should('be.visible').and('contain', `Show all`);
    consolePage.acknowledgeDropdownValueAck().should('be.visible').and('contain', `Show Acknowledged`);
    consolePage.acknowledgeDropdownValueUnack().should('be.visible').and('contain', `Show Unacknowledged`);
    consolePage.groupByElapsedTime();
    consolePage.expandAllConsoleLists();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    consolePage.consoleSentimentsTabsHeaderTitle().scrollIntoView().click();
    consolePage.caseCard().eq(0).scrollIntoView().trigger('mouseover');
    consolePage.sentimentAckButton().eq(0).scrollIntoView().click({ force: true });
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    consolePage
      .caseCardHeaderText()
      .invoke('text')
      .should('match', /acknowledged\s*byQA/);
    consolePage.acknowledgeLabelWithCrossIcon().eq(0).scrollIntoView().should('be.visible');
    consolePage.selectShowAcknowledgedInDropdown();
    cy.waitForLoaders();
    customerBoardPage.appContentContainer().scrollTo('top');
    consolePage.caseCard().eq(0).invoke('text').should('contain', 'acknowledged by');
    consolePage
      .caseCardTicketIdLabel()
      .eq(0)
      .then((caseNo) => {
        const caseID = caseNo.text();

        consolePage.acknowledgeLabelWithCrossIcon().eq(0).scrollIntoView().should('be.visible');
        consolePage.acknowledgeLabelWithCrossIcon().eq(0).scrollIntoView().trigger('mouseover');
        consolePage.acknowledgeLabelTooltip().invoke('text').should('include', 'Remove acknowledgement');
        consolePage.acknowledgeLabelWithCrossIcon().eq(0).scrollIntoView().click();
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(1000);
        consolePage.selectShowUnacknowledgedInDropdown();
        cy.get('body').should('contain', caseID);
        consolePage.selectShowAcknowledgedInDropdown();
        cy.get('body').should('not.contain', caseID);
      });
  });

  /*
   * Go to Text Analysis page.
   * Click on the Product Feedback tab, Click the Elasped Time option in the groupedby dropdown.
   * While hovering on cases 'Acknowledge' tick mark is showing. Click the tick mark.
   * Validate that Acknowledged by QA with Cross icon should be displayed.
   * Click the Show Acknowledged option in the dropdown, Click on Cross icon in a feed.
   * Validate that Acknowledged by QA with Cross icon should not be displayed.
   */
  it('C124950: Verify the acknowledgement workflow in Product Feedback tab', { tags: ['Customers', 'staging'] }, () => {
    trends.productFeedbackTab().should('be.visible').click();
    consolePage.selectAllSignalsInDropdown();
    consolePage.selectShowAllInDropdown();
    consolePage.groupByElapsedTime();
    consolePage.expandAllConsoleLists();
    consolePage.consoleTabsShowingHeaderTitle().should('exist');
    consolePage.consoleTabsShowingHeaderTitle().invoke('text').should('contain', `Showing`);
    consolePage.consoleSentimentsTabsHeaderTitle().should('be.exist');
    consolePage.consoleSentimentsTabsHeaderTitle().invoke('text').should('contain', `Product Feedback`);
    cy.waitForLoaders();
    consolePage.acknowledgeDropdown().click({ force: true });
    consolePage.acknowledgeDropdownValueAll().should('be.visible').and('contain', `Show all`);
    consolePage.acknowledgeDropdownValueAck().should('be.visible').and('contain', `Show Acknowledged`);
    consolePage.acknowledgeDropdownValueUnack().should('be.visible').and('contain', `Show Unacknowledged`);
    consolePage.groupByElapsedTime();
    consolePage.expandAllConsoleLists();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    consolePage.consoleSentimentsTabsHeaderTitle().scrollIntoView().click();
    consolePage.caseCard().eq(0).scrollIntoView().trigger('mouseover');
    consolePage.sentimentAckButton().eq(0).scrollIntoView().click({ force: true });
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    consolePage
      .caseCardHeaderText()
      .invoke('text')
      .should('match', /acknowledged\s*byQA/);
    consolePage.acknowledgeLabelWithCrossIcon().eq(0).scrollIntoView().should('be.visible');
    consolePage.selectShowAcknowledgedInDropdown();
    cy.waitForLoaders();
    customerBoardPage.appContentContainer().scrollTo('top');
    consolePage.caseCard().eq(0).invoke('text').should('contain', 'acknowledged by');
    consolePage
      .caseCardTicketIdLabel()
      .eq(0)
      .then((caseNo) => {
        const caseID = caseNo.text();

        consolePage.acknowledgeLabelWithCrossIcon().eq(0).scrollIntoView().should('be.visible');
        consolePage.acknowledgeLabelWithCrossIcon().eq(0).scrollIntoView().trigger('mouseover');
        consolePage.acknowledgeLabelTooltip().invoke('text').should('include', 'Remove acknowledgement');
        consolePage.acknowledgeLabelWithCrossIcon().eq(0).scrollIntoView().click();
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(1000);
        consolePage.selectShowUnacknowledgedInDropdown();
        cy.get('body').should('contain', caseID);
        consolePage.selectShowAcknowledgedInDropdown();
        cy.get('body').should('not.contain', caseID);
      });
  });
});
