import { urlHelpers } from '../../../utils';
import { consolePage, supportHub, trends } from '../../../pages';

describe('Trends - Tab data', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.trends);
  });

  /*
   * TODO: Handle zero state & validate zero-state placeholder
   *
   * Loop over all the tabs
   * Exclude 'Overview' & 'Escalations' tabs (since these tabs only have charts)
   * Click each tab
   *
   * Click 'Expand All' button if it's visible
   *
   * Click the case cards to open SupportHub
   * Verify SupportHub modal is visible
   * Close SupportHub
   */
  it("C2277: should verify all tabs' tickets opens up in SH", { tags: ['trends', 'staging', 'prod'] }, () => {
    trends.commonTabs().each((element) => {
      if (!(element.text().includes('Overview') || element.text().includes('Escalations'))) {
        cy.wrap(element).click();
        cy.waitForLoaders();

        // TODO: Define & upgrade to POM style
        cy.get('body').then((body) => {
          const collapseExpandButton = '[data-testid=consolePage-sentimentTab_expand-collapse-button]';

          if (body.find(collapseExpandButton).text() === 'Expand All') cy.get(collapseExpandButton).click();
        });

        consolePage.caseCard().first().click();
        cy.waitForLoaders();
        supportHub.baseContainer().should('be.visible');
        supportHub.closeButton().click();
      }
    });
  });

  /*
   * Click the overview tab
   *
   * Get the count of charts currently present
   * Click the first item in the top entity horizontal bar chart
   *
   * Verify that a rectangle highlighter is visible (NOTE: not sure how to validate if it's in the right plot)
   * Verify the chart count is unchanged after clicking the top entity
   *
   * Click the remove button to the left of the selected top entity
   * Verify the visibility of the 'Restore' button next to the 'Top Entity' title
   * Verify the chart count is still unchanged after removing the top entity selection
   *
   * Click the 'Restore' button
   * Verify the chart count is still unchanged after restoring the top entity
   */
  it("C357: should verify overview tab graph count doesn't change on clicking top entity", { tags: ['trends', 'staging'] }, () => {
    trends.overviewTab().click();

    trends.tabChartContainers().then((expectedChartCount) => {
      trends.topEntityListItem().first().click();

      trends.selectedTopEntityHighlight().should('be.visible');
      trends.tabChartContainers().should('have.length', expectedChartCount.length);

      trends.selectedTopEntityRemoveButton().click();
      trends.topEntityRestoreButton().should('be.visible');
      trends.tabChartContainers().should('have.length', expectedChartCount.length);

      trends.topEntityRestoreButton().click();
      trends.tabChartContainers().should('have.length', expectedChartCount.length);
    });
  });

  /*
   * Click the Escalations tab
   *
   * Get the count of charts currently present
   * Click the first item in the top entity horizontal bar chart
   *
   * Verify that a rectangle highlighter is visible (NOTE: not sure how to validate if it's in the right plot)
   * Verify the chart count is unchanged after clicking the top entity
   *
   * Click the remove button to the left of the selected top entity
   * Verify the visibility of the 'Restore' button next to the 'Top Entity' title
   * Verify the chart count is still unchanged after removing the top entity selection
   *
   * Click the 'Restore' button
   * Verify the chart count is still unchanged after restoring the top entity
   */
  it("C3772: should verify escalations tab graph count doesn't change on clicking top entity", { tags: ['trends', 'staging'] }, () => {
    trends.escalationsTab().click();

    trends.tabChartContainers().then((expectedChartCount) => {
      trends.topEntityListItem().first().click();
      trends.selectedTopEntityHighlight().should('be.visible');

      trends.tabChartContainers().should('have.length', expectedChartCount.length);

      trends.selectedTopEntityRemoveButton().click();
      trends.topEntityRestoreButton().should('be.visible');

      trends.tabChartContainers().should('have.length', expectedChartCount.length);

      trends.topEntityRestoreButton().click();

      trends.tabChartContainers().should('have.length', expectedChartCount.length);
    });
  });
});
