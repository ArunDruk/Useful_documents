import moment from 'moment-timezone';
import path from 'path';

import { urlHelpers } from '../../../utils';
import { apiHelpers, trends } from '../../../pages';

describe('Trends - Group By & Export', { tags: ['trends', 'staging'] }, () => {
  beforeEach(() => {
    cy.intercept('PUT', 'api/users/dashboard_settings').as('updateGroupBy');

    cy.loginByApi();
    cy.visit(urlHelpers.trends);
  });

  /*
   * NOTE: This test does not verify the data in the exported files
   *
   * Get the current value of the group by dropdown
   *
   * Click the menu button (3 vertical dots) in the top right corner of the main chart
   * Ensure the menu options popup is displayed
   *
   * Click the export CSV & Image checkboxes if they're not checked
   * Click the export button at the bottom of the menu options popup
   *
   * Verify the existence of the downloaded CSV & Image files
   */
  it('C351: should export chart data as CSV & Image', () => {
    trends
      .groupByDropdownTrigger()
      .invoke('text')
      .then((currentGroupByValue) => {
        const downloadsFolder = Cypress.config('downloadsFolder');
        const expectedCsvFileName = `Trends_by_${currentGroupByValue}-${moment().format('YYYY-MM-DD')}.csv`;
        const expectedImageFileName = `Trends_by_${currentGroupByValue}-${moment().format('YYYY-MM-DD')}.png`;

        trends.chartMenuButton().click();
        trends.chartMenuPopup().should('be.visible');

        trends.chartMenuOptionCsvExportCheckbox().then((element) => {
          if (element.attr('data-status') === 'unchecked') cy.wrap(element, { log: false }).click({ force: true });
        });
        trends
          .chartMenuOptionImageExportCheckbox()
          .first()
          .then((element) => {
            if (element.attr('data-status') === 'unchecked') cy.wrap(element, { log: false }).click({ force: true });
          });
        trends.chartMenuOptionExportButton().first().click();

        cy.readFile(path.join(downloadsFolder, expectedCsvFileName)).should('exist');
        cy.readFile(path.join(downloadsFolder, expectedImageFileName)).should('exist');
      });
  });

  /*
   * Set 'Priority' as the group by value via API
   * Reload the page
   *
   * Open the group by dropdown
   * Select 'Status' from the dropdown options
   *
   * Verify the chart legend card header text matches 'Status' */
  it('C353: should group chart by selected value', () => {
    apiHelpers.setTrendsGroupByValue('sl_priority');
    cy.visit(urlHelpers.trends);

    trends.openGroupByDropdown();
    trends.groupByDropdownOptions('Status').click();
    cy.wait('@updateGroupBy');

    trends.chartLegendCardHeaderLabel().should('have.text', 'Status');
  });
});
