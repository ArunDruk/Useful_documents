import moment from 'moment-timezone';

import { urlHelpers } from '../../../utils';
import { datePicker, trends, filters } from '../../../pages';

describe('Trends - Main Chart', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.trends);
  });

  /*
   * Get the current sentiment score from the main chart legend
   *
   * Click the first item in the legend
   * Verify that the clicked legend is disabled
   * Verify the sentiment score is different from the previous value
   */
  it('C354: should verify chart legend deselect functionality', { tags: ['trends', 'staging'] }, () => {
    filters.allCaseStatusFilterButton().click();
    cy.waitForLoaders();

    trends
      .chartLegendSentimentScoreLabel()
      .invoke('text')
      .then((sentimentScoreBeforeDeselect) => {
        trends.chartLegendItems().first().click();
        cy.waitForLoaders();

        // TODO: Replace with data-status attribute
        trends.chartLegendItems().first().should('have.attr', 'data-status', 'disabled');
        cy.waitForLoaders();
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(2000);
        trends.chartLegendSentimentScoreLabel().should('not.have.text', sentimentScoreBeforeDeselect);
      });
  });

  /*
   * Set the datepicker to 'This month' if not already selected
   *
   * Click the left arrow button on the main chart
   * Verify the datepicker value & chart X axis label contains the previous month name
   *
   * Click the right arrow button on the main chart
   * Verify the datepicker value & chart X axis label contains the current month name
   */
  it('C355: should verify chart traverse button functionality', { tags: ['trends', 'staging'] }, () => {
    const lastMonth = moment().subtract(1, 'month').format('MMM');
    const currentMonth = moment().format('MMM');

    datePicker.datePickerTrigger().then(($btn) => {
      if (!$btn.text().includes('This month')) {
        datePicker.selectAndApplyThisMonthRadioButton();
        cy.waitForLoaders();
      }
    });

    trends.chartLeftTraverseButton().click();
    cy.waitForLoaders();

    datePicker.datePickerTrigger().should('include.text', lastMonth);
    trends.chartXAxisLabels().should('contain.text', lastMonth);

    trends.chartRightTraverseButton().click();
    cy.waitForLoaders();

    datePicker.datePickerTrigger().should('include.text', currentMonth);
    trends.chartXAxisLabels().should('contain.text', currentMonth);
  });

  /*
   * Set datepicker to 'This month' if not already selected
   *
   * Click the chart menu button
   * Verify the 'daily' roll up is selected and all other options are disabled
   *
   * Set datepicker to 'last 3 months' if not already selected
   *
   * Click the chart menu button
   * Verify the 'daily' roll up is disabled and 'Weekly' is selected by default
   */
  it('C2163: should verify chart roll up functionality', { tags: ['trends', 'staging'] }, () => {
    datePicker.datePickerTrigger().then(($btn) => {
      if (!$btn.text().includes('This month')) {
        datePicker.selectAndApplyThisMonthRadioButton();
        cy.waitForLoaders();
      }
    });

    trends.chartMenuButton().click();
    // TODO: Replace with data-status attribute
    trends.chartMenuRollUpOptions('Daily').should('have.class', 'zNYYJIgaEmYPPBnrkhSv-');
    // TODO: Replace with data-status attribute
    trends.chartMenuRollUpOptions('Weekly').should('have.class', '_2JvJaRwGxl803L3_NBSbRn');
    trends.chartMenuRollUpOptions('Monthly').should('have.class', '_2JvJaRwGxl803L3_NBSbRn');
    trends.chartMenuRollUpOptions('Quarterly').should('have.class', '_2JvJaRwGxl803L3_NBSbRn');

    datePicker.datePickerTrigger().then(($btn) => {
      if (!$btn.text().includes('Last 3 months')) {
        datePicker.selectAndApplyLast3MonthsRadioButton();
        cy.waitForLoaders();
      }
    });

    trends.chartMenuButton().click();
    // TODO: Replace with data-status attribute
    trends.chartMenuRollUpOptions('Daily').should('have.class', '_2JvJaRwGxl803L3_NBSbRn');
    // TODO: Replace with data-status attribute
    trends.chartMenuRollUpOptions('Weekly').should('have.class', 'zNYYJIgaEmYPPBnrkhSv-');
  });
});
