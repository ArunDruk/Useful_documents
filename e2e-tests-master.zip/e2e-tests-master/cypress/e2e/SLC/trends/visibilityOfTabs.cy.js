import { urlHelpers } from '../../../utils';
import { consolePage, datePicker, trends, supportHub } from '../../../pages';

describe('Text Analysis: Visibility of the tabs', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.trends);
    datePicker.datePickerTrigger().then(($btn) => {
      if (!$btn.text().includes('Last 3 months')) {
        datePicker.selectAndApplyLast3MonthsRadioButton();
        cy.waitForLoaders();
      }
    });
    cy.waitForLoaders();
  });

  /*
   * Go to Text Analysis page.
   * Click the Need attention tab, Validate that dropdown are exist and verify all the options in each dropdown.
   * Click 'Attention Score' in the groupby dropdown. Open any SH and validate the check Sentiment score label is displayed in correct range.
   */
  it('C37852: Verify the display of Need attention tab', { tags: ['trends', 'staging', 'prod'] }, () => {
    trends.needAttentionTab().should('be.visible').click();
    consolePage.selectAllSignalsInDropdown();
    consolePage.selectShowAllInDropdown();
    cy.waitForLoaders();
    consolePage.consoleTabsShowingHeaderTitle().should('be.exist');
    consolePage.consoleTabsShowingHeaderTitle().invoke('text').should('contain', `Showing`);
    consolePage.consoleSentimentsTabsHeaderTitle().should('be.exist');
    consolePage.consoleSentimentsTabsHeaderTitle().invoke('text').should('contain', `Need Attention`);
    consolePage.sentimentsTabsSignalsDropdown().click();
    consolePage.signalsDropdownSentimentSignalHeader().invoke('text').should('contain', `Sentiment Signal`);
    consolePage.signalsDropdownSentimentSignalCheckbox().invoke('attr', 'data-status').should('eq', 'checked');
    cy.waitForLoaders();
    consolePage.acknowledgeDropdown().click({ force: true });
    consolePage.acknowledgeDropdownValueAll().should('be.visible').and('contain', `Show all`);
    consolePage.acknowledgeDropdownValueAck().should('be.visible').and('contain', `Show Acknowledged`);
    consolePage.acknowledgeDropdownValueUnack().should('be.visible').and('contain', `Show Unacknowledged`);
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    consolePage.groupedByDropdown().eq(0).click();
    consolePage.consoleGroupedByDropdownAttentionScoreOption().click();
    cy.waitForLoaders();
    consolePage.consoleSubTabsOptionSwitcher().eq(0).click();
    cy.waitForLoaders();
    consolePage.caseCard().eq(0).click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
    supportHub.supportHubAttentionScoreLabel().then(($attentionScore) => {
      const attentionScore = $attentionScore.text();

      expect(parseInt(attentionScore, 10)).to.be.at.least(parseInt(80, 10)).and.to.be.at.most(parseInt(100, 10));
      supportHub.closeButton().click();
    });
  });

  /*
   * Go to Text Analysis page.
   * Click the Negative Sentiment tab, Validate that dropdown are exist and verify all the options in each dropdown.
   * Click 'Sentiment Score' in the groupby dropdown. Open any SH and validate the check Attention score label is displayed in correct range.
   */
  it('C37853: Verify the display of Negative Sentiment tab', { tags: ['Customers', 'staging', 'prod'] }, function overviewTabRecentlyClosedStatus() {
    trends.negativeSentimentsTab().should('be.visible').click();
    consolePage.selectAllSignalsInDropdown();
    consolePage.selectShowAllInDropdown();
    consolePage.groupBySentimentScoreOption();
    cy.waitForLoaders();
    consolePage.consoleTabsShowingHeaderTitle().should('be.exist');
    consolePage.consoleTabsShowingHeaderTitle().invoke('text').should('contain', `Showing`);
    consolePage.consoleSentimentsTabsHeaderTitle().should('be.exist');
    consolePage.consoleSentimentsTabsHeaderTitle().invoke('text').should('contain', `Negative Sentiments`);
    consolePage.sentimentsTabsSignalsDropdown().click();
    consolePage.signalsDropdownSentimentSignalHeader().invoke('text').should('contain', `Sentiment Signal`);
    consolePage.signalsDropdownSentimentSignalCheckbox().invoke('attr', 'data-status').should('eq', 'checked');
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    consolePage.acknowledgeDropdown().click({ force: true });
    consolePage.acknowledgeDropdownValueAll().should('be.visible').and('contain', `Show all`);
    consolePage.acknowledgeDropdownValueAck().should('be.visible').and('contain', `Show Acknowledged`);
    consolePage.acknowledgeDropdownValueUnack().should('be.visible').and('contain', `Show Unacknowledged`);
    consolePage
      .consoleSubTabsOptionSwitcher()
      .eq(0)
      .then(($scoreRange) => {
        const minScoreRange = $scoreRange.text().split('-')[0];
        const maxScoreRange = $scoreRange.text().split('-')[1];

        consolePage.consoleSubTabsOptionSwitcher().eq(0).click();
        cy.waitForLoaders();
        consolePage.caseCard().eq(0).click();
        cy.waitForLoaders();
        supportHub.baseContainer().should('be.visible');
        cy.waitForLoaders();
        supportHub.supportHubSentimentScoreLabel().then(($sentimentScore) => {
          const sentimentScore = $sentimentScore.text();

          expect(parseInt(sentimentScore, 10)).to.be.at.least(parseInt(minScoreRange, 10)).and.to.be.at.most(parseInt(maxScoreRange, 10));
          supportHub.closeButton().click();
        });
      });
  });

  /*
   * Go to Text Analysis page.
   * Click the Positive Sentiment tab, Validate that dropdown are exist and verify all the options in each dropdown.
   * Click 'Sentiment Score' in the groupby dropdown. Open any SH and validate the check Attention score label is displayed in correct range.
   */
  it('C37854: Verify the display of Positive sentiment tab', { tags: ['Customers', 'staging', 'prod'] }, function overviewTabRecentlyClosedStatus() {
    trends.positiveSentimentsTab().should('be.visible').click();
    consolePage.selectAllSignalsInDropdown();
    consolePage.selectShowAllInDropdown();
    consolePage.groupBySentimentScoreOption();
    cy.waitForLoaders();
    consolePage.consoleTabsShowingHeaderTitle().should('be.exist');
    consolePage.consoleTabsShowingHeaderTitle().invoke('text').should('contain', `Showing`);
    consolePage.consoleSentimentsTabsHeaderTitle().should('be.exist');
    consolePage.consoleSentimentsTabsHeaderTitle().invoke('text').should('contain', `Positive Sentiments`);
    consolePage.sentimentsTabsSignalsDropdown().click();
    consolePage.signalsDropdownSentimentSignalHeader().invoke('text').should('contain', `Sentiment Signal`);
    consolePage.signalsDropdownSentimentSignalCheckbox().invoke('attr', 'data-status').should('eq', 'checked');
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    consolePage.acknowledgeDropdown().click({ force: true });
    consolePage.acknowledgeDropdownValueAll().should('be.visible').and('contain', `Show all`);
    consolePage.acknowledgeDropdownValueAck().should('be.visible').and('contain', `Show Acknowledged`);
    consolePage.acknowledgeDropdownValueUnack().should('be.visible').and('contain', `Show Unacknowledged`);
    consolePage
      .consoleSubTabsOptionSwitcher()
      .eq(0)
      .then(($scoreRange) => {
        const minScoreRange = $scoreRange.text().split('-')[0];
        const maxScoreRange = $scoreRange.text().split('-')[1];

        consolePage.consoleSubTabsOptionSwitcher().eq(0).click();
        cy.waitForLoaders();
        consolePage.caseCard().eq(0).click();
        cy.waitForLoaders();
        supportHub.baseContainer().should('be.visible');
        cy.waitForLoaders();
        supportHub.supportHubSentimentScoreLabel().then(($sentimentScore) => {
          const sentimentScore = $sentimentScore.text();

          expect(parseInt(sentimentScore, 10)).to.be.at.least(parseInt(minScoreRange, 10)).and.to.be.at.most(parseInt(maxScoreRange, 10));
          supportHub.closeButton().click();
        });
      });
  });

  /*
   * Go to Text Analysis page.
   * Click the Product Feedback tab, Validate that dropdown are exist and verify all the options in each dropdown.
   * Click 'Sentiment Score' in the groupby dropdown. Open any SH and validate the check Attention score label is displayed in correct range.
   */
  it('C37855: Verify the display of Product Feedback tab', { tags: ['Customers', 'staging', 'prod'] }, function overviewTabRecentlyClosedStatus() {
    trends.productFeedbackTab().should('be.visible').click();
    consolePage.selectAllSignalsInDropdown();
    consolePage.selectShowAllInDropdown();
    consolePage.groupBySentimentScoreOption();
    cy.waitForLoaders();
    consolePage.consoleTabsShowingHeaderTitle().should('be.exist');
    consolePage.consoleTabsShowingHeaderTitle().invoke('text').should('contain', `Showing`);
    consolePage.consoleSentimentsTabsHeaderTitle().should('be.exist');
    consolePage.consoleSentimentsTabsHeaderTitle().invoke('text').should('eq', `Product Feedback`.trim());
    consolePage.sentimentsTabsSignalsDropdown().click();
    consolePage.signalsDropdownSentimentSignalHeader().invoke('text').should('contain', `Sentiment Signal`);
    consolePage.signalsDropdownSentimentSignalCheckbox().invoke('attr', 'data-status').should('eq', 'checked');
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    consolePage.groupedByDropdown().contains('Show all').click({ force: true });
    consolePage.acknowledgeDropdownValueAll().should('be.visible').and('contain', `Show all`);
    consolePage.acknowledgeDropdownValueAck().should('be.visible').and('contain', `Show Acknowledged`);
    consolePage.acknowledgeDropdownValueUnack().should('be.visible').and('contain', `Show Unacknowledged`);
    consolePage
      .consoleSubTabsOptionSwitcher()
      .eq(0)
      .then(($scoreRange) => {
        const minScoreRange = $scoreRange.text().split('-')[0];
        const maxScoreRange = $scoreRange.text().split('-')[1];

        consolePage.consoleSubTabsOptionSwitcher().eq(0).click();
        cy.waitForLoaders();
        consolePage.caseCard().eq(0).click();
        cy.waitForLoaders();
        supportHub.baseContainer().should('be.visible');
        cy.waitForLoaders();
        supportHub.supportHubSentimentScoreLabel().then(($sentimentScore) => {
          const sentimentScore = $sentimentScore.text();

          expect(parseInt(sentimentScore, 10)).to.be.at.least(parseInt(minScoreRange, 10)).and.to.be.at.most(parseInt(maxScoreRange, 10));
          supportHub.closeButton().click();
        });
      });
  });
});
