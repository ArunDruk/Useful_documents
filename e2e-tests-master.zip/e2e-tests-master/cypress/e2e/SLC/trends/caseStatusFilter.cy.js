import { urlHelpers } from '../../../utils';
import { filters, trends } from '../../../pages';

describe('Trends - Case Status Filter', { tags: ['trends', 'staging', 'prod'] }, () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.trends);
  });

  /*
   * Check header ticket count is visible
   *
   * Click 'All' case status filter and get tickets count
   * Click 'Open' case status filter and get tickets count
   * Click 'Closed' case status filter and get tickets count
   *
   * Log all 3 counts
   * Verify Open count = All - Closed ticket count (to escape stale cache using a range)
   */
  it('C325: should check "Open" case status filter', () => {
    trends.headerTicketCountLabel().should('be.visible');

    filters.allCaseStatusFilterButton().click();
    cy.waitForLoaders();

    trends.getHeaderTicketCount().then((allCaseCount) => {
      filters.openCaseStatusFilterButton().click();
      cy.waitForLoaders();

      trends.getHeaderTicketCount().then((openCaseCount) => {
        filters.closedCaseStatusFilterButton().click();
        cy.waitForLoaders();

        trends.getHeaderTicketCount().then((closedCaseCount) => {
          const expectedCount = allCaseCount - closedCaseCount;

          cy.log(`All count = ${allCaseCount}`);
          cy.log(`Open count = ${openCaseCount}`);
          cy.log(`Closed count = ${closedCaseCount}`);

          expect(openCaseCount).to.be.within(expectedCount - 10, expectedCount + 10);
        });
      });
    });
  });

  /*
   * Check header ticket count is visible
   *
   * Click 'All' case status filter and get tickets count
   * Click 'Open' case status filter and get tickets count
   * Click 'Closed' case status filter and get tickets count
   *
   * Log all 3 counts
   * Verify Closed count = All - Open ticket count (to escape stale cache using a range)
   */
  it('C326: should check "Closed" case status filter', () => {
    trends.headerTicketCountLabel().should('be.visible');

    filters.allCaseStatusFilterButton().click();
    cy.waitForLoaders();

    trends.getHeaderTicketCount().then((allCaseCount) => {
      filters.openCaseStatusFilterButton().click();
      cy.waitForLoaders();

      trends.getHeaderTicketCount().then((openCaseCount) => {
        filters.closedCaseStatusFilterButton().click();
        cy.waitForLoaders();

        trends.getHeaderTicketCount().then((closedCaseCount) => {
          const expectedCount = allCaseCount - openCaseCount;

          cy.log(`All count = ${allCaseCount}`);
          cy.log(`Open count = ${openCaseCount}`);
          cy.log(`Closed count = ${closedCaseCount}`);

          expect(closedCaseCount).to.be.within(expectedCount - 10, expectedCount + 10);
        });
      });
    });
  });

  /*
   * Check header ticket count is visible
   *
   * Click 'All' case status filter and get tickets count
   * Click 'Open' case status filter and get tickets count
   * Click 'Closed' case status filter and get tickets count
   *
   * Log all 3 counts
   * Verify All count = Open + Closed ticket count (to escape stale cache using a range)
   */
  it('C327: should check "All" case status filter', () => {
    trends.headerTicketCountLabel().should('be.visible');

    filters.allCaseStatusFilterButton().click();
    cy.waitForLoaders();

    trends.getHeaderTicketCount().then((allCaseCount) => {
      filters.openCaseStatusFilterButton().click();
      cy.waitForLoaders();

      trends.getHeaderTicketCount().then((openCaseCount) => {
        filters.closedCaseStatusFilterButton().click();
        cy.waitForLoaders();

        trends.getHeaderTicketCount().then((closedCaseCount) => {
          const expectedCount = openCaseCount + closedCaseCount;

          cy.log(`All count = ${allCaseCount}`);
          cy.log(`Open count = ${openCaseCount}`);
          cy.log(`Closed count = ${closedCaseCount}`);

          expect(allCaseCount).to.be.within(expectedCount - 10, expectedCount + 10);
        });
      });
    });
  });
});
