import { urlHelpers } from '../../../utils';
import { alertsPage } from '../../../pages';

describe('Alerts - Delete', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.alerts);
  });

  it('C757: should delete an alert', { tags: ['Alerts', 'staging'] }, () => {
    alertsPage.createNewAlert();
    alertsPage
      .alertTitleNameLabel()
      .invoke('text')
      .then((alertName) => {
        alertsPage.deleteAlert();
        alertsPage.alertTitleNameLabel().should('not.have.text', alertName);
      });
  });
});
