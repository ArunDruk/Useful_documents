import { urlHelpers } from '../../../utils';
import { alertsPage } from '../../../pages';

beforeEach(() => {
  cy.loginByApi();
  cy.visit(urlHelpers.alerts);
});

describe('Alert page - Duplicating an Alert functionality checks', () => {
  /*
   * Open the Alert page, Create one new alert.
   * Hover over & click on duplicate button and checks functionality.
   * Check the alert messages condition for the duplicate an alert.
   * Check the rename and adding new condition works fine.
   */
  it('C756: duplicating an Alert functionality checks', { tags: ['Alerts'] }, () => {
    alertsPage.createNewAlert();
    alertsPage.duplicateAlertButton().trigger('mouseover');
    alertsPage.mouseHoverTooltip().should('be.visible').should('have.text', 'Duplicate alert');
    alertsPage.duplicateAlertButton().click();
    alertsPage.alertTitleNameLabel().invoke('text').should('include', 'Copy');
    alertsPage.alertUnmuteTextContainer().invoke('text').should('include', 'This alert has identical conditions ');
    alertsPage.alertUnMuteButton().trigger('mouseover');
    alertsPage.mouseHoverTooltip().should('be.visible').should('have.text', 'To un-mute, please update conditions');
    alertsPage.alertConditionDropDown().eq(0).should('be.visible').click();
    alertsPage.alertNegativeSentimentFirstSignalTitle().dblclick();
    alertsPage.alertUnmuteTextContainer().should('not.exist');
    alertsPage.alertTitleNameLabel().dblclick();
    alertsPage.alertTitleNameInput().type(' new 1');
    alertsPage.alertTitleHeader().click();
    alertsPage.alertTitleNameLabel().invoke('text').should('include', 'new 1');
    alertsPage.deleteAlert();
  });
});
