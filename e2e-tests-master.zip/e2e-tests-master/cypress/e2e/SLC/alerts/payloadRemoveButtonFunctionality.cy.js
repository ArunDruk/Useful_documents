import { urlHelpers } from '../../../utils';
import { alertsPage } from '../../../pages';

describe('Payload Remove Icon Functionality', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.alerts);
  });

  afterEach(() => alertsPage.deleteAlert());

  /**
   * Open the Alert page.
   * Create one new alert.
   * Go to the alert Payload section.
   * Add some condition in the Payload section, the remove iconwill appear.
   * Click on the remove icon and checks the particular condition is removed.
   */
  it('C761: Payload Remove Icon Functionality Check', { tags: ['Alerts', 'staging'] }, () => {
    alertsPage.createNewAlert();
    alertsPage.payloadDropDownTitle().should('have.text', 'Payload');
    alertsPage.payloadInputContainer().contains('add additional alert conditions');
    alertsPage.payloadInput().type('/Negat');
    alertsPage.payloadSuggestionDropDown().click();
    alertsPage.payloadContainerText().should('have.text', 'Negative Sentiment');
    alertsPage.payloadContainerRemoveIconMouseHover().trigger('mouseover');
    alertsPage.mouseHoverTooltip().should('be.visible').should('have.text', 'Remove');
    alertsPage.payloadContainerRemoveIcon().click({ force: true });
    alertsPage.payloadContainerText().should('not.exist');
  });
});
