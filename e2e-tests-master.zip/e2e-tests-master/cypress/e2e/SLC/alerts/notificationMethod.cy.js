import { urlHelpers } from '../../../utils';
import { alertsPage } from '../../../pages';

describe('Alert page - Notification Method selection & deselection functionality_check', () => {
  const expectedText =
    'Your Slack workspace is not available for the alertsConnect your Slack to start collaborating!Add to SlackThis allows you to:Share cases through SlackSend messages through the internal Slack channel';

  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.alerts);
    alertsPage.createNewAlert();
  });

  afterEach(() => alertsPage.deleteAlert());

  it('C753: setup slack notification', { tags: ['Alerts', 'staging'] }, () => {
    alertsPage.notificationMethodSecondMailContainer().should('exist').should('be.visible').should('have.text', 'qa.automation@supportlogic.io');
    alertsPage.notificationMethodSecondDropDown().click();
    alertsPage.notificationMethodDropDownSlackCheckbox().click({ force: true });
    alertsPage.slackContainerLabel().click();
    alertsPage.slackContainerLabel().should('contain.text', expectedText);
  });

  /*
   * Open the Alert page .
   * Create one new alert
   * Go to notification section.
   * Check the selection & deselection of check boxes working fine
   */
  it('C766: notification Method selection functionality checks', { tags: ['Alerts'] }, () => {
    alertsPage.notificationMethodFirstDropDown().click();
    alertsPage.notificationMethodDropDownEmailCheckbox().invoke('attr', 'data-status').should('eq', 'checked');
    alertsPage.notificationMethodDropDownSlackCheckbox().invoke('attr', 'data-status').should('eq', 'unchecked');
    alertsPage.alertTitleNameLabel().click();
    alertsPage.notificationMethodSecondDropDown().click();
    alertsPage.notificationMethodDropDownEmailCheckbox().invoke('attr', 'data-status').should('eq', 'checked');
    alertsPage.notificationMethodDropDownSlackCheckbox().invoke('attr', 'data-status').should('eq', 'unchecked');
    alertsPage.notificationMethodDropDownSlackCheckbox().click({ force: true });
    alertsPage.alertTitleHeader().click();
    alertsPage.slackContainerLabel().should('contain.text', expectedText);
  });

  it('C767: notification Method deselection functionality checks', { tags: ['Alerts'] }, () => {
    alertsPage.notificationMethodFirstDropDown().click();
    alertsPage.notificationMethodDropDownEmailCheckbox().invoke('attr', 'data-status').should('eq', 'checked');
    alertsPage.notificationMethodDropDownSlackCheckbox().invoke('attr', 'data-status').should('eq', 'unchecked');
    alertsPage.notificationMethodDropDownEmailCheckbox().eq(0).click({ force: true });
    alertsPage.alertTitleHeader().click();
    alertsPage.notificationMethodFirstCheckbox().should('have.attr', 'data-status', 'unchecked');
    alertsPage.slackContainerTitle().should('not.to.exist');
    alertsPage.slackContainerSignInTitle().should('not.to.exist');
    alertsPage.slackContainerErrorTitle().should('not.to.exist');
  });
});
