import { urlHelpers } from '../../../utils';
import { alertsPage } from '../../../pages';

describe('Alerts - Page loading', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.alerts);
  });

  it('C750: should verify page loading', { tags: 'Alerts' }, () => {
    alertsPage.createNewAlertButton().should('be.visible').and('have.text', 'New Alert');
    cy.get('body').then((body) => {
      const zeroStateCreateNewAlertButton = '[data-testid=alert--CreateNewAlert]';
      if (body.find(zeroStateCreateNewAlertButton).length) {
        cy.get(zeroStateCreateNewAlertButton).should('be.visible').and('have.text', 'Create a new alert');
      } else {
        alertsPage.alertTitleNameLabel().should('be.visible');
        alertsPage.deleteAlertButton().should('be.visible');
        alertsPage.alertExpandButton().should('be.visible');
      }
    });
  });
});
