import { urlHelpers } from '../../../utils';
import { alertsPage } from '../../../pages';

beforeEach(() => {
  cy.loginByApi();
  cy.visit(urlHelpers.alerts);
});

describe('Alert page - Mute and Unmute an Alert functionality checks', () => {
  /*
   * Open the Alert page.
   * Create one new alert
   * Hover over on mute button and checks functionality
   * Click on mute button and checks functionality
   */
  it('C755: muting an alert functionality checks', { tags: ['Alerts'] }, () => {
    alertsPage.createNewAlert();
    alertsPage.alertMuteButton().trigger('mouseover');
    alertsPage.mouseHoverTooltip().should('be.visible').should('have.text', 'Mute alert');
    alertsPage.alertMuteButton().click();
    alertsPage.muteContainerText().invoke('text').should('include', 'Alert muted!');
    alertsPage.alertUnMuteButton().trigger('mouseover');
    alertsPage.mouseHoverTooltip().should('be.visible').should('have.text', 'Unmute alert');
    alertsPage.alertUnMuteButton().click();
    alertsPage.muteContainerText().invoke('text').should('include', 'Alert un-muted!');
    alertsPage.deleteAlert();
  });
});
