import { urlHelpers } from '../../../utils';
import { alertsPage } from '../../../pages';

describe('Adding Email Recipient', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.alerts);
  });

  /**
   * Open the Alert page.
   * Create one new alert.
   * In the email recipients,while the user start to type itself will show the user suggestions..
   * The user can select the desired user from the user suggestions.
   * Selected user should showing on the email recipient section.
   */
  it('C769: Adding Email Recipient Functionality Check', { tags: ['Alerts', 'staging'] }, () => {
    alertsPage.addingEmailRecipientAlert();
  });
});
