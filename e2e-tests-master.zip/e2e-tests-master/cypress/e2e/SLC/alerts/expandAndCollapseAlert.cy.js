import { urlHelpers } from '../../../utils';
import { alertsPage } from '../../../pages';

beforeEach(() => {
  cy.loginByApi();
  cy.visit(urlHelpers.alerts);
});

describe('Alerts Page - Expand_functionality_check', () => {
  /*
   * Open the Alerts and alerts are displayed.
   * Press Expand option on top right side.
   * Check the functionality of collapse and expand behavior.
   */
  it('C764: Expand_functionality_check', { tags: 'Alerts' }, () => {
    alertsPage.alertConditionsHeaderTitle().should('contain', 'Alert Conditions');
    alertsPage.customFieldsHeaderTitle().should('be.visible').and('have.text', 'Custom Fields');
    alertsPage.alertExpandButton().click();
    alertsPage.alertConditionsHeaderTitle().should('contain', 'Alert Conditions');
    alertsPage.customFieldsHeaderTitle().should('not.be.visible').and('have.text', 'Custom Fields');
    alertsPage.alertExpandButton().click({ force: true });
    alertsPage.alertConditionsHeaderTitle().should('contain', 'Alert Conditions');
    alertsPage.customFieldsHeaderTitle().should('be.visible').and('have.text', 'Custom Fields');
  });
});
