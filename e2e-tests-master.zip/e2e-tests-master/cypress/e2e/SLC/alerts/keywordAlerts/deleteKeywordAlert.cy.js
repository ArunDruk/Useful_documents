import { urlHelpers } from '../../../../utils';
import { alertsPage } from '../../../../pages';

describe('Keyword Alert - Delete Keyword Alert functionality checks', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.alerts);
  });

  /*
   * Open the Alert page, Create one new alert.
   * Select 'Keyword Alert' option and click 'create' button.
   * Note the Title of the Keyword Title, Click the "Delete" button.
   * Click 'Delete' option in the delete popup.
   * Validate that Title should not be same with the previous one.
   */
  it('C134593: Deleting the Keyword Alert', { tags: ['Alerts', 'staging'] }, () => {
    alertsPage.createNewKeywordAlert();
    alertsPage
      .alertTitleNameLabel()
      .invoke('text')
      .then((alertName) => {
        alertsPage.deleteAlert();
        alertsPage.alertTitleNameLabel().should('not.have.text', alertName);
      });
  });
});
