import { randId, urlHelpers } from '../../../../utils';
import { alertsPage } from '../../../../pages';

describe('Keyword Alert Test Cases', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.alerts);
  });

  afterEach(() => alertsPage.deleteAlert());

  /*
   * Open the Alert page, Create one new alert.
   * Select 'Keyword Alert' option and click 'create' button.
   * Validate the title include the text 'Keyword'.
   * Validate the Delete button should be visible.
   * Validate the Mute button should be visible.
   * Validate the Expand trigger should be visible.
   * Validate the Keyword Header should be visible.
   * Deleting the created alert after verify
   */
  it('C134589: Visiting the Keyword Alert page', { tags: ['Alerts', 'staging'] }, () => {
    alertsPage.createNewKeywordAlert();
    alertsPage.alertTitleNameLabel().should('be.visible').and('contain', 'Keyword');
    alertsPage.deleteAlertButton().should('be.visible');
    alertsPage.alertMuteButton().should('be.visible');
    alertsPage.alertExpandButton().should('be.visible');
    alertsPage.keywordsExpandTriggerHeader().should('be.visible').and('have.text', 'Keywords');
  });

  /*
   * Open the Alert page, Create one new alert.
   * Select 'Keyword Alert' option and click 'create' button.
   * Validate the title include the text 'Keyword'.
   * Validate the Canvas Empty text in the container.
   * Click and type any name in the keyword expand trigger.
   * Validate the 'no keywords matching your search..' text while entering new keyword title.
   * Press 'Enter' and double tab on the newly created keyword.
   * Validate the 'Where would you like to extract the keyword?' text in canvas popup header.
   * Edit the keyword alert title and validate that it should be reflected.
   * Deleting the created alert after verify
   */
  it('C134605: Adding a keyword alert functionality checks', { tags: ['Alerts', 'staging'] }, () => {
    const keywordText = `${randId()} Keyword Alert `;
    const expectedText = 'It seems that you have no keywords matching your search. press enter to add a new one.';

    alertsPage.createNewKeywordAlert();
    alertsPage.alertTitleNameLabel().should('be.visible').and('contain', 'Keyword');
    alertsPage.keywordAlertCanvasEmptyContainer().invoke('text').should('include', '1. Expand the list on the right.2. Drag and drop conditions here!');
    alertsPage.keywordsExpandTriggerHeader().click();
    alertsPage
      .keywordsExpandTriggerInput()
      .type(keywordText)
      .then(() => {
        alertsPage.keywordsExpandTriggerNoResultSpace().invoke('text').should('include', expectedText);
      });
    alertsPage.keywordsExpandTriggerInput().type('{Enter}');
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(2000);
    alertsPage.keywordsExpandTriggerKeywordsLists().eq(0).dblclick();
    alertsPage.keywordsExpandCanvasPopupHeader().invoke('text').should('include', 'Where would you like to extract the keyword?');
    alertsPage.alertTitleNameLabel().dblclick();
    alertsPage.alertTitleNameInput().clear().type(' Keyword edited 1');
    alertsPage.alertTitleHeader().click();
    alertsPage.alertTitleNameLabel().invoke('text').should('include', 'Keyword edited 1');
  });

  /*
   * Open the Alert page, Create one new alert.
   * Select 'Keyword Alert' option and click 'create' button.
   * In the email recipients,while the user start to type itself will show the user suggestions.
   * The user can select the desired user from the user suggestions.
   * Selected user should showing on the email recipient section.
   * Deleting the created alert after verify
   */
  it('C134601: Adding Email Recipient Functionality Check', { tags: ['Alerts', 'staging'] }, () => {
    alertsPage.createNewKeywordAlert();
    alertsPage.notificationMethodSecondMailContainer().should('be.visible').and('have.text', 'qa.automation@supportlogic.io');
    alertsPage.notificationMethodSecondMailInput().last().type('qa.automation.prod2@');
    alertsPage.notificationMethodMailSuggestionDropDown().click({ force: true });
    alertsPage.notificationMethodSecondMailContainerFirstMail().should('be.visible').and('have.text', 'qa.automation@supportlogic.io');
    alertsPage.notificationMethodSecondMailContainerSecondMail().should('be.visible').and('have.text', 'qa.automation.prod2@supportlogic.io');
  });

  /*
   * Open the Alert page, Create one new alert.
   * Select 'Keyword Alert' option and click 'create' button.
   * Validate the keyword alert condition header and keyword header Title both are visible.
   * Press Expand button on top right side.
   * Validate the keyword alert condition header are visible  and keyword header Title are not visible.
   * Press Expand button on top right side.
   * Validate the keyword alert condition header and keyword header Title both are visible.
   * Deleting the created alert after verify
   */
  it('C134598: Expand_functionality_check', { tags: ['Alerts', 'staging'] }, () => {
    alertsPage.createNewKeywordAlert();
    alertsPage.keywordAlertConditionsHeaderTitle().should('contain', 'Alert Triggers');
    alertsPage.keywordsExpandTriggerHeader().should('be.visible').and('have.text', 'Keywords');
    alertsPage.alertExpandButton().click();
    alertsPage.keywordAlertConditionsHeaderTitle().should('contain', 'Alert Triggers');
    alertsPage.keywordsExpandTriggerHeader().should('not.be.visible');
    alertsPage.alertExpandButton().click({ force: true });
    alertsPage.keywordAlertConditionsHeaderTitle().should('contain', 'Alert Triggers');
    alertsPage.keywordsExpandTriggerHeader().should('be.visible').and('have.text', 'Keywords');
  });

  /*
   * Open the Alert page, Create one new alert.
   * Select 'Keyword Alert' option and click 'create' button.
   * Hover over on mute button and validate 'Mute alert' tooltip text.
   * Click on mute button and checks 'Alert muted!' message is displayed.
   * Hover over on unmute button and validate 'Unmute alert' tooltip text.
   * Click on mute button and checks 'Unmute alert' message is displayed.
   * Deleting the created alert after verify
   */
  it('C134591: Muting a keyword alert functionality checks', { tags: ['Alerts', 'staging'] }, () => {
    alertsPage.createNewKeywordAlert();
    alertsPage.alertMuteButton().trigger('mouseover');
    alertsPage.mouseHoverTooltip().should('be.visible').should('have.text', 'Mute alert');
    alertsPage.alertMuteButton().click();
    alertsPage.muteContainerText().invoke('text').should('include', 'Alert muted!');
    alertsPage.alertUnMuteButton().trigger('mouseover');
    alertsPage.mouseHoverTooltip().should('be.visible').should('have.text', 'Unmute alert');
    alertsPage.alertUnMuteButton().click();
    alertsPage.muteContainerText().invoke('text').should('include', 'Alert un-muted!');
  });
});
