import { urlHelpers } from '../../../../utils';
import { alertsPage } from '../../../../pages';

describe('Keyword Alert - Notification Method deselection and Slack container functionality check', () => {
  const expectedText =
    'Your Slack workspace is not available for the alertsConnect your Slack to start collaborating!Add to SlackThis allows you to:Share cases through SlackSend messages through the internal Slack channel';

  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.alerts);
    alertsPage.createNewAlert();
  });

  afterEach(() => alertsPage.deleteAlert());

  /*
   * Open the Alert page, Create one new alert.
   * Select 'Keyword Alert' option and click 'create' button.
   * In the email recipients,while the user start to type itself will show the user suggestions.
   * Validate that slack container text.
   * Deleting the created alert after verify
   */
  it('C134590: Vaidate that setup slack notification', { tags: ['Alerts', 'staging'] }, () => {
    alertsPage.createNewKeywordAlert();
    alertsPage.notificationMethodSecondMailContainer().should('exist').should('be.visible').should('have.text', 'qa.automation@supportlogic.io');
    alertsPage.slackContainerLabel().should('contain.text', expectedText);
  });

  /*
   * Open the Alert page, Create one new alert.
   * Select 'Keyword Alert' option and click 'create' button.
   * Go to notification section, Check the data status of the notification dropdown
   * Uncheck the email check box.
   * Validate that Email container and Slack Container is not displayed
   * Deleting the created alert after verify
   */
  it('C134600: Vaidate that Notification Method deselection functionality checks', { tags: ['Alerts', 'staging'] }, () => {
    alertsPage.createNewKeywordAlert();
    alertsPage.notificationMethodFirstDropDown().click();
    alertsPage.notificationMethodDropDownEmailCheckbox().invoke('attr', 'data-status').should('eq', 'checked');
    alertsPage.notificationMethodDropDownSlackCheckbox().invoke('attr', 'data-status').should('eq', 'unchecked');
    alertsPage.notificationMethodDropDownEmailCheckbox().eq(0).click({ force: true });
    alertsPage.alertTitleHeader().click();
    alertsPage.notificationMethodFirstCheckbox().should('have.attr', 'data-status', 'unchecked');
    alertsPage.slackContainerTitle().should('not.to.exist');
    alertsPage.slackContainerSignInTitle().should('not.to.exist');
    alertsPage.slackContainerErrorTitle().should('not.to.exist');
  });
});
