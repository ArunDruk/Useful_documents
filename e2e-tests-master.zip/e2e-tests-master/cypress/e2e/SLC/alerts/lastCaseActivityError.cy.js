import { urlHelpers } from '../../../utils';
import { alertsPage } from '../../../pages';

describe('Alert page - Error message showing functionality checks', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.alerts);
  });

  /*
   * Open the Alert page.
   * Create one new alert
   * Add some condition in the alert message, i.e all last case activity
   * Check for an error message if the fields for last case activity condition is left blank
   */
  it('C779: should shown an error message if the fields for last case activity condition is left blank', { tags: ['Alerts'] }, () => {
    alertsPage.createNewAlert();
    alertsPage.alertLastCaseActivityDropDown().click();
    alertsPage.lastCaseActivityInboundRadio().dblclick();
    alertsPage.alertTitleHeader().click();
    alertsPage.alertErrorContainer().invoke('text').should('include', 'This field cannot be left blank.');
    alertsPage.deleteAlert();
  });
});
