import { urlHelpers } from '../../../utils';
import { alertsPage } from '../../../pages';

beforeEach(() => {
  cy.loginByApi();
  cy.visit(urlHelpers.alerts);
});

describe('Alert Page - Adding an alert functionality checks', () => {
  /*
   * Open the Alert page.
   * Create one new alert.
   * Add some condition in the alert message.
   * Edit the alert name in the alert title check behavior.
   */
  it('C752: adding an alert functionality checks', { tags: ['Alerts'] }, () => {
    cy.waitForLoaders();
    alertsPage.createNewAlert();
    alertsPage.alertBaseTextContainerFirst().should('have.text', '1. Expand the list on the right.');
    alertsPage.alertBaseTextContainerSecond().should('have.text', '2. Drag and drop a condition here!');
    alertsPage.alertConditionDropDown().eq(0).should('be.visible').click();
    alertsPage
      .alertNegativeSentimentSecondSignalTitle()
      .invoke('text')
      .then((secondSignalName) => {
        alertsPage.alertNegativeSentimentFirstSignalTitle().dblclick({ force: true });
        alertsPage.alertNegativeSentimentSecondSignalTitle().dblclick({ force: true });
        alertsPage.alertSentimentContainerText().last().should('exist');
        alertsPage.alertSentimentContainerText().last().invoke('text').should('includes', secondSignalName);
      });
    alertsPage.alertTitleNameLabel().dblclick();
    alertsPage.alertTitleNameInput().type(' new 1');
    alertsPage.alertTitleHeader().click();
    alertsPage.alertTitleNameLabel().invoke('text').should('include', 'new 1');
    alertsPage.alertBaseTextContainerFirst().should('not.to.exist');
    alertsPage.deleteAlert();
  });
});
