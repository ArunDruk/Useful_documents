import { urlHelpers } from '../../../utils';
import { alertsPage } from '../../../pages';

describe('Alerts - Undo', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.alerts);
    alertsPage.createNewAlert();
  });

  afterEach(() => alertsPage.deleteAlert());

  it('C758: should check undo functionality in conditions section', { tags: ['Alerts', 'staging'] }, () => {
    alertsPage.alertConditionDropDown().eq(0).should('be.visible').click();
    alertsPage.alertNegativeSentimentFirstSignalTitle().dblclick({ force: true });
    alertsPage.alertSentimentContainerText().should('be.visible');
    alertsPage.alertConditionsundoButton().should('be.visible').click();
    alertsPage.alertSentimentContainerText().should('not.exist');
    cy.contains('1. Expand the list on the right.').should('be.visible');
    cy.contains('2. Drag and drop a condition here!').should('be.visible');
  });

  it('C759: undo functionality check in notification section', { tags: ['Alerts', 'staging'] }, () => {
    const expectedText =
      'Your Slack workspace is not available for the alertsConnect your Slack to start collaborating!Add to SlackThis allows you to:Share cases through SlackSend messages through the internal Slack channel';

    alertsPage.notificationMethodSecondMailContainer().should('exist').should('be.visible').should('have.text', 'qa.automation@supportlogic.io');
    alertsPage.notificationMethodSecondDropDown().click();
    alertsPage.notificationMethodDropDownSlackCheckbox().click({ force: true });
    alertsPage.slackContainerLabel().click();
    alertsPage.slackContainerLabel().should('contain.text', expectedText);
    alertsPage.alertNotificationsundoButton().should('be.visible').click();
    alertsPage.slackContainerTitle().should('not.exist');
    alertsPage.slackContainerSignInTitle().should('not.exist');
    alertsPage.slackContainerErrorTitle().should('not.exist');
  });

  /**
   * Open the Alert page.
   * Create one new alert.
   * Go to the alert Payload section.
   * Add some condition in the Payload section, the Undo button will appear.
   * Click on the undo button and checks the very last changes made will be reverted back.
   */
  it('C760: Payload Undo Functionality check', { tags: ['Alerts', 'staging'] }, () => {
    alertsPage.payloadDropDownTitle().should('have.text', 'Payload');
    alertsPage.payloadInputContainer().contains('add additional alert conditions');
    alertsPage.payloadInput().type('/Negative{enter}');
    alertsPage.payloadContainerText().should('have.text', 'Negative Sentiment');
    alertsPage.payloadUndoButton().trigger('mouseover');
    alertsPage.mouseHoverTooltip().should('be.visible').should('have.text', 'Undo message changes');
    alertsPage.payloadUndoButton().should('be.visible').click();
    alertsPage.payloadContainerText().should('not.exist');
  });

  /*
   Undo_condition_changes_tooltip_checks:
   Test steps:
   1. Open the Alert page.
   2. Create one new alert.
   3. Add some condition in the alert message, the Undo button will appear.
   4. Hovering over the undo button will show a tooltip message.
   */
  it('C762: undo tooltip check', { tags: ['Alerts'] }, () => {
    alertsPage.alertConditionDropDown().eq(0).should('be.visible').click();
    alertsPage.alertNegativeSentimentFirstSignalTitle().dblclick({ force: true });
    alertsPage.alertConditionsundoButton().trigger('mouseover');
    alertsPage.mouseHoverTooltip().should('be.visible').and('have.text', 'Undo condition changes');
  });
});
