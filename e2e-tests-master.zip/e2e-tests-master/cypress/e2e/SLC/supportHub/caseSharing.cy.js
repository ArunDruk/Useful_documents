import { getOpenCaseDetails, getUserInitials, getUserName } from './support';
import { urlHelpers } from '../../../utils';
import { supportHub } from '../../../pages';

beforeEach(() => {
  cy.intercept('POST', 'api/mail*').as('waitForCaseShare');

  cy.loginByApi();
  getOpenCaseDetails().then((caseDetails) => {
    const caseDetail = Cypress._.sample(caseDetails);

    cy.visit(urlHelpers.supportHubCasePage(caseDetail.caseId));

    cy.getByTestId('supportHub-caseShare-trigger').click();
    cy.get('#case-share-popover').should('be.visible');
  });
});

it('C289: should verify share button is disabled', { tags: 'SupportHub' }, () => {
  cy.getByTestId('supportHub-caseShare-EmailInputTab').click();
  cy.getByTestId('supportHub-caseShare-shareWithInput').type('{backspace}').type(Cypress.env('userEmail')).type('{enter}');

  cy.getByTestId('support-hub.share-button-inner').should('be.visible').and('be.enabled');
});

/*
 * TODO: Remove skip once https://supportlogic.atlassian.net/browse/SLC-30312 is fixed
 * NOTE: Adding extra validation (line 41) as per 5.17.0 changes
 *       Clarify with functional team at the time of removing skip on required validations
 */
it.skip('C292: should verify shared with message after sharing case', { tags: 'SupportHub' }, () => {
  cy.getByTestId('supportHub-caseShare-EmailInputTab').click();
  cy.getByTestId('supportHub-caseShare-shareWithInput').type('{backspace}').type(Cypress.env('userEmail')).type('{enter}');
  cy.getByTestId('support-hub.share-button-inner').should('be.visible').and('be.enabled').click();
  cy.wait('@waitForCaseShare');

  cy.get('#case-share-popover [data-icon=check]').should('be.visible');
  getUserName().then((name) => {
    const userInitials = getUserInitials(name);

    cy.getByTestId('supportHub-caseShare-successMessage').should('contain', 'Shared With').and('contain', Cypress.env('userEmail')).and('contain', userInitials);
    cy.getByTestId('supportHub-caseTimeline-shareAction-container').should('contain.text', `Shared this case with ${userInitials}email`);
  });
});

/*
 * Open case share popup (in before each hook)
 * Verify share popup title is 'Share Case'
 * Verify close popup button is visible
 */
it('C288: should verify share popup title & close button', () => {
  supportHub.sharePopupHeader().should('be.visible').and('have.text', 'Share Case');

  supportHub.sharePopupCloseButton().should('be.visible');
});
