import { getOpenCaseDetails } from './support';
import { urlHelpers } from '../../../utils';
import { apiHelpers, supportHub } from '../../../pages';

describe('SH - Score Popup Validations', () => {
  beforeEach(function beforeEachHook() {
    // cy.intercept('POST', 'api/v0/support/case_notes').as('addCaseNote');
    cy.loginByApi();
    apiHelpers.enablePublicComments();
    getOpenCaseDetails().then((caseDetails) => {
      const caseDetail = Cypress._.sample(caseDetails);

      cy.visit(urlHelpers.supportHubCasePage(caseDetail.caseId));
    });
    cy.waitForLoaders();
  });

  /*
   * Hover over the Sentiment score in Support Hub.
   * Validate that pop up contain 'Contributing factors effects on your case'.
   * Validate that pop up contain 'Explore factors - Should display "what is contributing factors"'.
   * Validate that pop up contain 'What is Sentiment score?'.
   */
  it('C27919: Validate popup hover over sentiment score in SH', () => {
    supportHub.supportHubSentimentScoreLabel().trigger('mouseover');
    supportHub.supportHubScorePopupGrid().contains('Sentiment score insights');
    supportHub.supportHubScorePopupGrid().contains('Contributing factors effects on your case');
    supportHub.supportHubScorePopupGrid().contains('Explore factors');
    supportHub.supportHubScorePopupGrid().contains('What is Sentiment score?');
    supportHub.supportHubSentimentScoreLabel().trigger('mouseout');
  });

  /*
   * Hover over the Attention score in Support Hub.
   * Validate that pop up contain 'Contributing factors effects on your case'.
   * Validate that pop up contain 'Explore factors - Should display "what is contributing factors"'.
   * Validate that pop up contain 'What is Attention score?'.
   */
  it('C27920: Validate popup hover over Need Attention score in SH', () => {
    supportHub.supportHubAttentionScoreLabel().trigger('mouseover');
    supportHub.supportHubScorePopupGrid().contains('Need Attention score insights');
    supportHub.supportHubScorePopupGrid().contains('Contributing factors effects on your case');
    supportHub.supportHubScorePopupGrid().contains('Explore factors');
    supportHub.supportHubScorePopupGrid().contains('What is Need Attention score?');
    supportHub.supportHubAttentionScoreLabel().trigger('mouseout');
  });
});
