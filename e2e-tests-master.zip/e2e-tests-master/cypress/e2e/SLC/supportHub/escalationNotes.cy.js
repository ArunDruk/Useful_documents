import { randId, urlHelpers } from '../../../utils';
import { escalations, supportHub } from '../../../pages';

describe('SH-Escalation Notes', () => {
  beforeEach(() => {
    cy.intercept('POST', 'api/escalation-notes').as('postEscalationNote');

    cy.loginByApi();
    cy.visit(urlHelpers.escalationBoard);

    escalations.activeEscalationsCaseCard().first().click();
    cy.waitForLoaders();
  });

  /*
   * Click add escalation note icon button
   * Type a value into the popup textarea
   *
   * Validate that the newly added escalation note is visible in the section below the textarea
   */
  it('C2275: should add escalation notes', () => {
    const escalationNote = `Test Escalation Note ${randId()}`;

    supportHub.addEscalationNotesIconButton().click();
    supportHub.clearEscalationNotesWelcomeScreen();
    supportHub.escalationNotesTextarea().type(`${escalationNote}{enter}`);
    cy.wait('@postEscalationNote');

    supportHub.postedEscalationNoteText().first().should('be.visible').and('contain.text', escalationNote);
  });
});
