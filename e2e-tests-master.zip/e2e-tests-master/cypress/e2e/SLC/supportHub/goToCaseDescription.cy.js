import { getOpenCaseDetails } from './support';
import { urlHelpers } from '../../../utils';

beforeEach(() => {
  cy.loginByApi();
  getOpenCaseDetails().then((caseDetails) => {
    const caseDetail = Cypress._.sample(caseDetails);

    cy.visit(urlHelpers.supportHubCasePage(caseDetail.caseId));
  });
});

it('C6865: should verify go to case description button functionality', { tags: 'SupportHub' }, () => {
  cy.getByTestId('supportHub-caseSubject-descriptionContent')
    .invoke('text')
    .then((caseDescription) => {
      cy.getByTestId('supporthub-go-to-description').click();

      // remove the first and last double quotes.
      const expectedText = caseDescription.slice(1, -1);
      cy.getByTestId('supportHub-caseComments-body-0').should('be.visible').should('include.text', expectedText);
    });
});
