import moment from 'moment';

import { urlHelpers } from '../../../utils';
import { apiHelpers, supportHub } from '../../../pages';

const removeAcknowledgement = (commentId) =>
  cy.request({
    method: 'POST',
    url: 'api/spansActions/removeSpansAcknowledgment',
    body: { spanIds: [commentId], lastAcknowledgeChange: moment().toISOString() },
  });

describe('SupportHub - Sentiments Bar', () => {
  beforeEach(() => {
    cy.intercept('POST', 'api/spansActions/markSpansAsAcknowledged').as('markAsAcknowledged');
    cy.intercept('POST', 'api/spansActions/removeSpansAcknowledgment').as('removeAcknowledgement');

    cy.loginByApi();
    apiHelpers.getCasesWithSentiments().then((caseDetails) => {
      const caseDetail = Cypress._.sample(caseDetails);

      cy.visit(urlHelpers.supportHubCasePage(caseDetail.id));
    });
  });

  afterEach(function afterEachHook() {
    removeAcknowledgement(this.commentId);
  });

  // TODO: (ikhalikov) figure out a way of ensuring we're working with not-acknowledged signal
  // for now - use first one and let's hope retry strategy will save us if test will be unlucky to open case with acks.
  // Also, logic can be simplified with it (potentially)
  it('C316: should acknowledge sentiment', { tags: ['staging'] }, () => {
    cy.getByTestId('supportHub-sentiment-acknowledge').first().click();
    cy.wait('@markAsAcknowledged').then(({ request }) => cy.wrap(request.body.spanIds[0]).as('commentId'));

    cy.getByTestId('supportHub-sentiment-card')
      .first()
      .within(() => cy.getByTestId('supportHub-sentiment-acknowledgedWatermarkIcon').should('be.visible'));
  });

  it('C317: should remove sentiment acknowledgement', { tags: ['staging'] }, () => {
    cy.getByTestId('supportHub-sentiment-acknowledge').then((acknowledgeButton) => {
      cy.getByTestId('supportHub-sentiment-acknowledge').first().click();
      cy.wait('@markAsAcknowledged').then(({ request }) => cy.wrap(request.body.spanIds[0]).as('commentId'));

      cy.getByTestId('supportHub-sentiment-card')
        .first()
        .within(() => cy.getByTestId('supportHub-sentiment-acknowledgedWatermarkIcon').should('be.visible'));

      cy.getByTestId('supportHub-sentiment-removeAcknowledge').click({ force: true });
      cy.wait('@removeAcknowledgement');

      cy.getByTestId('supportHub-sentiment-acknowledge').should('have.length', acknowledgeButton.length);
    });
  });

  it('C315: should scroll to the sentiment on clicking label', { tags: ['staging'] }, () => {
    cy.getByTestId('supportHub-sentiment-card-caseComment')
      .first()
      .invoke('text')
      .then((sentimentText) => {
        supportHub.sentimentCard().first().click();

        cy.getByTestId('supportHub-caseTimeline-caseComment-markedText').should('include.text', sentimentText);
      });
  });

  /*
   * Get the count of detected sentiments
   *
   * Verify sentiment card is visible if the count is not 0
   * Also, verify that the right scroll button is visible in the sentiment bar if the count is above 4
   *
   * If the count is 0, verify 'No Sentiments detected' text is displayed
   */
  it('C313: should display sentiment bar', () => {
    cy.get('body').then((body) => {
      const sentimentCount = body.find('[data-testid=supportHub-sentiment-card]').length;

      if (sentimentCount === 0) {
        supportHub.noSentimentLabel().should('be.visible');
      } else {
        supportHub.sentimentCard().first().should('be.visible');

        if (sentimentCount > 4) supportHub.sentimentBarLeftScrollButton().should('be.visible');
      }
    });
  });
});
