import { consolePage } from '../../../pages';
import { urlHelpers } from '../../../utils';

beforeEach(() => {
  cy.loginByApi();
  cy.visit(urlHelpers.console.withTimeFilter.lastSevenDays);

  cy.slcHelpers.clearCustomersQuickFilter();
  cy.slcHelpers.clearAgentsQuickFilter();
  cy.slcHelpers.clearCustomersQuickFilter();
  cy.slcHelpers.deleteGlobalFilter();
});

afterEach(() => {
  cy.slcHelpers.disableAgentsQuickFilter();
  cy.slcHelpers.clearAgentsQuickFilter();
  cy.slcHelpers.deleteGlobalFilter();
});

describe('SupportHub Tests', () => {
  // Smoke & Sanity C272
  it('C272: Opening SupportHub', { tags: 'SupportHub' }, () => {
    cy.getByTestId('layout-navigation-module-item--console').should('be.visible').click();
    // cy.getByTestId('consolePage-tabsSlider-tab-Escalations').click();
    consolePage.lteTab().click();
    cy.getByTestId('dropdown-trigger-text').then((groupValue) => {
      const dropdownValue = groupValue.text();
      if (dropdownValue !== 'Priority') {
        cy.getByTestId('common-dropdown-btn').eq(1).click();
        // cy.getByTestId('common-dropdown-escActivityType').click();
        consolePage.sentimentsGroupByDrodownOptionPriority().click();
        cy.getByTestId('optionsSwitcherNew-list').eq(0).should('be.visible').click();
      } else {
        cy.getByTestId('optionsSwitcherNew-list').eq(0).should('be.visible').click();
      }
    });
    cy.getByTestId('case-card-base-wrapper').eq(0).click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(5000);
    cy.waitForLoaders();
    cy.getByTestId('supportHub-SHContainer').should('be.visible');
    // Verify the SupportHub Field values
    // Case comments
    cy.getByTestId('supportHub-caseComments-body-0').should('exist');
    // Custom fields
    cy.getByTestId('supportHub-caseField-expandButton').click();
    cy.get('[data-field="sl_severity_c"]').should('exist');
    // Case Owner
    cy.getByTestId('supportHub-caseOwnerSelect-caseOwnerName').should('exist');
    // Case Reporter
    cy.getByTestId('supportHub-caseHeader-caseReporterName').should('exist');
    // Timeline of the case comments
    cy.getByTestId('supportHub-customerWaitTime').should('exist');
    // Likely to Escalate
    cy.contains('Likely to Escalate').should('exist');
    // tags for missing SLA
    cy.getByTestId('supportHub-caseComments-highLightButton').click({ force: true });
    cy.getByTestId('supportHub-caseTimeline-label-likelyToEscalate').should('be.visible');
    // About to miss SLA tags
    cy.getByTestId('supportHub-caseTimeline-label-isSlaMissed').eq(0).scrollIntoView().should('exist');
    cy.contains('Response Time SLA Missed').should('exist');
    // Closing the Ticket
    cy.getByTestId('supportHub-actionWrapper-closeDialog').should('be.visible').click();
    cy.getByTestId('supportHub-SHContainer').should('not.exist');
    // For Escalation tickets - escalation Details
    // cy.get('[data-testid="optionsSwitcherNew-list"] button').contains('Active Escalations').click();
    consolePage.newEscalationsTab().click();
    cy.waitForLoaders();
    cy.getByTestId('dropdown-trigger-text').then((groupValue) => {
      const dropdownValue = groupValue.text();
      if (dropdownValue !== 'Priority') {
        cy.getByTestId('common-dropdown-btn').eq(1).click();
        consolePage.sentimentsGroupByDrodownOptionPriority().click();
      }
    });
    cy.waitForLoaders();
    cy.getByTestId('case-card-base-wrapper').eq(0).click();
    cy.waitForLoaders();
    cy.contains('Response Time SLA Missed').should('exist');
    // Closing the Ticket
    cy.getByTestId('supportHub-actionWrapper-closeDialog').should('be.visible').click();

    // Commenting the below lines, as this is failing in qa-automation
    // I will create a jira ticket for this.
    // Selecting active escalation tab
    // cy.getByTestId('optionsSwitcherNew-option-Active Escalations').click()
    // cy.getByTestId('case-card-base-wrapper').eq(0).click();
    // cy.getByTestId('supportHub-escalationStatusIndicator-escalationLabel').then(() => {
    //   cy.getByTestId('supportHub-escalationStatusIndicator-escalationLabel').contains('Escalated').click();
    //   cy.getByTestId('supportHub-caseTimeline-escalationHistoryEntry-title').should('exist');
    // });
    // // Closing the Ticket
    // cy.getByTestId('supportHub-actionWrapper-closeDialog').should('be.visible').click();
    cy.getByTestId('supportHub-SHContainer').should('not.exist');
  });

  // Smoke & Sanity C276
  it('C276: Customer Notes (add)', { tags: 'SupportHub' }, () => {
    cy.getByTestId('layout-navigation-module-item--console').should('be.visible').click();
    cy.getByTestId('consolePage-tabsSlider-tab-Tickets').click({ force: true });
    cy.getByTestId('consolePage-tabsSlider-tab-Tickets').should('be.visible');
    cy.getByTestId('common-caseList-defaultItem-cardTitle').eq(0).click();
    cy.waitForLoaders();
    cy.getByTestId('supportHub-SHContainer').should('be.visible');
    // Click on Add Case Notes
    cy.getByTestId('supportHub-caseCommentForm-addCaseNoteButton').should('be.visible').click();
    // Verify the Case Notes
    cy.getByTestId('supportHub-caseCommentForm-addNewCaseNoteInput').should('be.visible');
    cy.getByTestId('supportHub-caseCommentForm-cancelButton').should('be.visible');
    cy.getByTestId('supportHub-caseCommentForm-saveSendButton').should('be.visible');
    cy.getByTestId('supportHub-caseComments-body-0').should('exist');
    // Closing the SupportHub
    cy.getByTestId('supportHub-actionWrapper-closeDialog').should('be.visible').click();
    cy.getByTestId('supportHub-SHContainer').should('not.exist');
  });

  // Draft C6539
  it('C6539: Verify SH 3.0 new UI changes', { tags: 'SupportHub' }, () => {
    cy.getByTestId('layout-navigation-module-item--console').should('be.visible').click();
    cy.getByTestId('consolePage-tabsSlider-tab-Tickets').click({ force: true });
    cy.getByTestId('consolePage-tabsSlider-tab-Tickets').should('be.visible');
    cy.getByTestId('common-caseList-defaultItem-cardTitle').eq(0).click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(3000);
    cy.getByTestId('supportHub-SHContainer').should('be.visible');
    cy.getByTestId('supportHub-sideBar').should('be.visible');
    // Closing the SupportHub
    cy.getByTestId('supportHub-actionWrapper-closeDialog').should('be.visible').click();
    cy.getByTestId('supportHub-SHContainer').should('not.exist');
  });
});
