import { getOpenCaseDetails } from './support';
import { urlHelpers } from '../../../utils';
import { supportHub } from '../../../pages';

beforeEach(() => {
  cy.loginByApi();
  getOpenCaseDetails().then((caseDetails) => {
    const caseDetail = Cypress._.sample(caseDetails);

    cy.wrap(caseDetail.customerId).as('customerId');
    cy.wrap(caseDetail.customerName).as('customerName');
    cy.wrap(caseDetail.reporterName).as('reporterName');
    cy.wrap(caseDetail.reporterEmail).as('reporterEmail');
    cy.wrap(caseDetail.assigneeName).as('assigneeName');

    cy.visit(urlHelpers.supportHubCasePage(caseDetail.caseId));
  });
});

// TODO: Fix once https://supportlogic.atlassian.net/browse/SLC-34700 is fixed
// NOTE: We show tooltip only for long names that are cropped this is not the case for most of the customers in foundry
it.skip('C304: should show full name as tooltip on hovering over customer name', { tags: 'SupportHub' }, function verifyCustomerNameTooltip() {
  cy.getByTestId('supportHub-caseCustomer-CustomerName').trigger('mouseover');
  cy.getByTestId('supportHub-caseCustomer-CustomerNameTooltip').should('be.visible').and('have.text', this.customerName);
});

it('C306: should show edit status tooltip on hovering over status', { tags: 'SupportHub' }, function verifyEditStatusTooltip() {
  cy.getByTestId('supportHub-caseField-status').trigger('mouseover');
  cy.getByTestId('supportHub-caseStatus-statusTagTooltip').should('be.visible').and('include.text', 'Edit case status');
});

it('C305: should show edit priority tooltip on hovering over priority', { tags: 'SupportHub' }, function verifyEditPriorityTooltip() {
  cy.getByTestId('supportHub-caseField-priority').trigger('mouseover');
  cy.getByTestId('supportHub-caseField-priorityTooltip').should('be.visible').and('include.text', 'Edit case priority');
});

it('C308: should open insights on customer name click', { tags: 'SupportHub' }, function verifyCustomerNameClick() {
  // stub window.open call without loading the page
  cy.window().then((win) => {
    cy.stub(win, 'open').as('open');
  });
  // // open the URL in the same window
  // cy.window().then((win) => {
  //   cy.stub(win, 'open')
  //     .callsFake((url, target) => {
  //       expect(target).to.eq('_blank');
  //       // call the original `win.open` method
  //       // but pass the `_self` argument
  //       return win.open.wrappedMethod.call(win, url, '_self');
  //     })
  //     .as('open');
  // });
  cy.getByTestId('supportHub-caseCustomer-CustomerName').click();
  cy.get('@open').should('have.been.calledOnceWith', `/support/customer-insights?searchCustomer=${this.customerId}`);
});

it('C302: should verify case reporter popup details', { tags: 'SupportHub' }, function reporterDetails() {
  cy.getByTestId('supportHub-caseHeader-caseReporterName').trigger('mouseover');

  cy.getByTestId('supportHub-caseHeader-popover-reporterName').should('be.visible').and('have.text', this.reporterName);
  cy.getByTestId('supportHub-caseHeader-popover-reporterEmail').should('be.visible').and('have.text', this.reporterEmail);
  cy.getByTestId('supportHub-caseHeader-popover-reporterActiveHours').should('be.visible');
  cy.getByTestId('supportHub-sentimentsHistoryTable-caseItem').should('be.visible').and('have.length.at.least', 1);
});

/*
 * Hover over agent avatar
 * Verify agent details tooltip is visible and has agent's name and active hours
 */
it('C303: should verify agent details in popup', function agentDetails() {
  supportHub.agentAvatar().realHover({ pointer: 'mouse' });
  // eslint-disable-next-line cypress/no-unnecessary-waiting
  cy.wait(1000);

  supportHub.agentAvatarDetailsPopup().should('be.visible').and('contain.text', this.assigneeName).and('contain.text', 'Active Hours:');
});
