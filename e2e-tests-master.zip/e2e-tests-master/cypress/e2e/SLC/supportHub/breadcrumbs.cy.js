import { urlHelpers } from '../../../utils';
import { escalations, supportHub } from '../../../pages';

describe('SH - Breadcrumbs', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.escalationBoard);

    escalations.activeEscalationsCaseCard().first().click();
    cy.waitForLoaders();
  });

  /*
   * Get current ticket ID
   * Verify that the breadcrumb container in the top left corner of the SupportHub modal window contains the correct path and ticket id
   */
  it('C309: should display correct ticket path as breadcrumbs', { tags: ['staging', 'prod'] }, () => {
    supportHub
      .caseIdLabel()
      .invoke('text')
      .then((caseId) => {
        supportHub.breadcrumbContent().should('be.visible').and('contain', 'Escalations Board').and('contain', 'Active Escalations').and('contain', caseId);
      });
  });

  /*
   * Get current ticket id
   *
   * Click the right arrow button in the SupportHub modal window's top right corner
   * Verify that the ticket id of the current case is not the same as the previous one
   *
   * Click the left arrow button in the SupportHub modal window's top right corner
   * Verify that the ticket id of the current case is the same as the first one
   */
  it('C310: should navigate to previous/next case through breadcrumb nav buttons', { tags: ['staging', 'prod'] }, () => {
    supportHub
      .caseIdLabel()
      .invoke('text')
      .then((caseId) => {
        supportHub.breadcrumbScrollLeftButton().should('not.be.visible');
        supportHub.breadcrumbScrollRightButton().should('be.visible');
        supportHub.breadcrumbScrollRightButton().click();
        cy.waitForLoaders();

        supportHub.caseIdLabel().should('not.have.text', caseId);
        supportHub.breadcrumbScrollRightButton().should('be.visible');
        supportHub.breadcrumbScrollLeftButton().should('be.visible');
        supportHub.breadcrumbScrollLeftButton().click();
        cy.waitForLoaders();

        supportHub.breadcrumbScrollLeftButton().should('not.be.visible');
        supportHub.breadcrumbScrollRightButton().should('be.visible');
        supportHub.caseIdLabel().should('have.text', caseId);
      });
  });
});
