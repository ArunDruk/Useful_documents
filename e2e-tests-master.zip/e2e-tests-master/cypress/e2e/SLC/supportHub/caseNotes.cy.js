import { getOpenCaseDetails } from './support';
import { randId, urlHelpers } from '../../../utils';
import { apiHelpers, pluginErrorPopup, supportHub } from '../../../pages';

describe('SH - Case Notes', () => {
  beforeEach(function beforeEachHook() {
    cy.intercept('POST', 'api/v0/support/case_notes').as('addCaseNote');

    cy.loginByApi();
    apiHelpers.enablePublicComments();
    getOpenCaseDetails().then((caseDetails) => {
      const caseDetail = Cypress._.sample(caseDetails);

      cy.visit(urlHelpers.supportHubCasePage(caseDetail.caseId));
    });
  });

  /*
   * Click 'Reply to Customer' button
   * Type the note text and click save button
   * Wait for note to reflect in the UI
   * Verify that a case comment with the given note text is visible
   */
  it('C285: should add public case note', () => {
    const publicCaseNote = `Test public case note ${randId()}`;

    supportHub.addPublicCaseNote(publicCaseNote);
    cy.wait('@addCaseNote').then(({ response }) => {
      if (response.statusCode !== 200) {
        pluginErrorPopup.maybeLaterButton().should('be.visible');
      } else {
        supportHub.caseCommentByText(publicCaseNote).should('be.visible');
      }
    });
  });

  /*
   * Click 'Add case note' button
   * Type the note text and click save button
   * Wait for note to reflect in the UI
   * Verify that a case comment with the given note text is visible
   * Also, verify that the case comment has a little note icon
   */
  it('C286: should add private case note (reply to customer)', () => {
    const privateCaseNote = `Test private case note ${randId()}`;

    supportHub.addPrivateCaseNote(privateCaseNote);
    cy.wait('@addCaseNote').then(({ response }) => {
      if (response.statusCode !== 200) {
        pluginErrorPopup.maybeLaterButton().should('be.visible');
      } else {
        supportHub.caseCommentByText(privateCaseNote).within((element) => {
          cy.wrap(element).should('be.visible');

          supportHub.privateCaseNoteIcon().should('be.visible');
        });
      }
    });
  });

  /*
   * Disable Public comments in SH settings via API and reload the page
   * Verify that the 'Reply to Customer' button is disabled
   *
   * Enable the public comments back via API
   * Verify that the 'Reply to Customer' button is enabled
   */
  it('C319: should disable reply to customer button on disabling public comments', () => {
    apiHelpers.disablePublicComments();
    cy.reload();

    supportHub.replyToCustomerButton().should('be.disabled');
    apiHelpers.enablePublicComments();
    cy.reload();

    supportHub.replyToCustomerButton().should('be.enabled');
  });
});
