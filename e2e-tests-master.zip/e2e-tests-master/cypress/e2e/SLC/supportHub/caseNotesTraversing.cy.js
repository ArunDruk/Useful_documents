import { randId, urlHelpers } from '../../../utils';
import { pluginErrorPopup, supportHub } from '../../../pages';

beforeEach(function beforeEachHook() {
  // Ticket update test, hence skipped.
  // if (!Cypress.config().baseUrl.includes('foundry')) this.skip();

  cy.intercept('POST', 'api/v0/support/case_notes').as('addCaseNote');

  cy.loginByApi();
  cy.visit(urlHelpers.console.tabsWithTimeFilterLastSevenDays.newCases);

  cy.getByTestId('common-caseList-sideListItem').first().click();
  cy.waitForLoaders({ waitForGlobalLoader: true });

  cy.getByTestId('supportHub-SHContainer').should('be.visible');
  cy.getByTestId('supportHub-caseCustomer-CustomerName').should('be.visible');
  cy.getByTestId('supportHub-caseHeader-caseNumber')
    .invoke('text')
    .then((caseId) => cy.wrap(caseId).as('firstOpenedCaseId'));
});

it("C3771: should add public case note-traverse to next ticket-add private note to verify SH doesn't crash", { tags: 'SupportHub' }, function caseNotesTraverse() {
  const publicCaseNote = `Test public case note ${randId()}`;
  const privateCaseNote = `Test private case note ${randId()}`;

  // add public case note
  supportHub.addPublicCaseNote(publicCaseNote);
  cy.wait('@addCaseNote').then(({ response }) => {
    if (response.statusCode !== 200) {
      pluginErrorPopup.maybeLaterButton().should('be.visible');
    } else {
      cy.contains('[data-testid^=supportHub-caseComments-body]', publicCaseNote).should('be.visible');

      // traverse to next ticket using the breadcrumb navigation button and verify ticket is displayed
      cy.getByTestId('supportHub-breadcrumbs-paginationForwardBtn').click();
      cy.getByTestId('supportHub-caseCustomer-CustomerName').should('be.visible');
      cy.getByTestId('supportHub-caseHeader-caseNumber').should('not.have.text', this.firstOpenedCaseId);

      // add private case note
      supportHub.addPrivateCaseNote(privateCaseNote);
      cy.wait('@addCaseNote');
      cy.contains('[data-testid^=supportHub-caseComments-body]', privateCaseNote).should('be.visible');

      // traverse to next ticket using the breadcrumb navigation button and verify ticket is displayed
      cy.getByTestId('supportHub-breadcrumbs-paginationBackBtn').click();
      cy.getByTestId('supportHub-caseCustomer-CustomerName').should('be.visible');
      cy.getByTestId('supportHub-caseHeader-caseNumber').should('have.text', this.firstOpenedCaseId);
    }
  });
});
