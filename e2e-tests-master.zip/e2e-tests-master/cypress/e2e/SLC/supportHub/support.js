/* eslint-disable camelcase */

import { targetDatabase } from '../../../utils';

const basePredicates = [
  { column: 'sl_is_closed', op: '=', value: 'false' },
  { column: 'sl_account_id', op: '<>', value: 'null' },
  { column: 'sl_requester_id', op: '<>', value: 'null' },
];

export const getOpenCaseDetails = () =>
  cy.slcHelpers.getCaseDetails({ predicates: basePredicates }).then(({ body }) =>
    body.map(({ id, sl_account_id, sl_account_name, sl_requester_name, sl_requester_email, sl_assignee_id, sl_assignee_name }) => ({
      caseId: id,
      customerId: sl_account_id,
      customerName: sl_account_name,
      reporterName: sl_requester_name,
      reporterEmail: sl_requester_email,
      agentId: sl_assignee_id,
      assigneeName: sl_assignee_name,
    }))
  );

export const getUserName = () => cy.request('api/users/profile').then(({ body }) => body.name);

export function getUserInitials(name) {
  let initials = name
    .split(' ')
    .map((n) => n[0])
    .join('');

  // repeat first char if name has only one word
  if (initials.length === 1) initials = initials.repeat(2);

  return initials;
}

export const getOpenCaseDetailsWithSignals = () =>
  cy
    .request({
      method: 'POST',
      url: `api/cache/${targetDatabase}/tickets/v2/data`,
      headers: { 'Content-Type': 'application/json' },
      body: {
        fieldIds: ['id', 'sl_account_id', 'sl_account_name'],
        filters: {
          sl_is_closed: false,
          sl_has_signals: true,
        },
        limit: 50,
        sortAsc: false,
        sortKey: 'sl_created_at',
        utcOffset: 0,
        offset: 0,
      },
    })
    .then(({ body }) => body.tickets.map(({ id, sl_account_id, sl_account_name }) => ({ caseId: id, customerId: sl_account_id, customerName: sl_account_name })));

export const getSlaMissedCaseDetails = () =>
  cy
    .request({
      method: 'POST',
      url: `api/cache/${targetDatabase}/tickets/v2/data`,
      body: {
        fieldIds: ['id', 'sl_account_id', 'sl_account_name'],
        filters: {
          sl_is_closed: false,
          sl_open_time_sla_buckets: ['missed'], // case resolution
          sl_follow_up_time_sla_buckets: ['missed'],
          sl_first_response_time_sla_buckets: ['missed'],
        },
        limit: 50,
        sortAsc: false,
        sortKey: 'sl_created_at',
        utcOffset: 0,
        offset: 0,
      },
    })
    .then(({ body }) => body.tickets.map(({ id, sl_account_id, sl_account_name }) => ({ caseId: id, customerId: sl_account_id, customerName: sl_account_name })));

export const getEditableCaseFields = () =>
  cy.request('api/v0/plugin/fields?object_name=Case').then(({ body }) => body.filter(({ editable }) => editable).reduce((acc, { field_label }) => [...acc, field_label], []));

export const getUnassignedOpenCaseDetails = () =>
  cy.slcHelpers
    .getCaseDetails({
      predicates: [{ column: 'sl_assignee_id', op: 'is_null' }, ...basePredicates],
    })
    .then(({ body }) => body);

export const getCaseDetailsWithNoSignals = () =>
  cy
    .request({
      method: 'POST',
      url: `api/cache/${targetDatabase}/tickets/v2/data`,
      headers: { 'Content-Type': 'application/json' },
      body: {
        fieldIds: ['id', 'sl_account_id', 'sl_account_name'],
        filters: {
          sl_is_closed: false,
          sl_has_signals: false,
        },
        limit: 50,
        sortAsc: false,
        sortKey: 'sl_created_at',
        utcOffset: 0,
        offset: 0,
      },
    })
    .then(({ body }) => body.tickets.map(({ id, sl_account_id, sl_account_name }) => ({ caseId: id, customerId: sl_account_id, customerName: sl_account_name })));
