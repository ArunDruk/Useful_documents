import moment from 'moment-timezone';

import { getSlaMissedCaseDetails } from './support';
import { randId, urlHelpers } from '../../../utils';
import { supportHub } from '../../../pages';

const formattedCaseCreationTime = (caseCreationTime) => {
  let dateTimeText;
  if (caseCreationTime.includes(moment().format('MMMM D, YYYY'))) {
    dateTimeText = `Today, ${moment(caseCreationTime, 'MMMM D, YYYY at H:mm').format('h:mm A')}`;
  } else if (caseCreationTime.includes(moment().subtract(1, 'day').format('MMMM D, YYYY'))) {
    dateTimeText = `Yesterday, ${moment(caseCreationTime, 'MMMM D, YYYY at H:mm').format('h:mm A')}`;
  } else {
    dateTimeText = moment(caseCreationTime, 'MMMM D, YYYY at H:mm').format('D MMM, h:mm A');
  }

  return dateTimeText;
};

beforeEach(() => {
  cy.intercept('POST', 'api/v2/note').as('postCaseComment');

  cy.loginByApi();
  getSlaMissedCaseDetails().then((caseDetails) => {
    const caseDetail = Cypress._.sample(caseDetails);

    cy.visit(urlHelpers.supportHubCasePage(caseDetail.caseId));
  });
});

it('C311: should search for given text in case comments', { tags: ['staging', 'prod'] }, () => {
  const searchText = 'th';

  supportHub.searchButton().click();
  supportHub.searchTextfield().should('be.visible').type(searchText);

  cy.contains('[data-search-result]', RegExp(searchText, 'i')).first().should('be.visible');
});

it('C320: should display notify agent button for SLA missed cases', { tags: ['staging', 'prod'] }, () => {
  supportHub.notifyAgentButton().should('be.visible').click();
  supportHub.sharePopup().should('be.visible');

  // Verify the presence of Slack & email share options
  supportHub.sharePopupSlackButton().should('be.visible');
  supportHub.sharePopupEmailButton().should('be.visible');
});

it('C295: should add comment to case comment', { tags: ['staging'] }, () => {
  const annotationText = `Testing case annotations ${randId()}`;

  supportHub.gotoCaseDescriptionButton().click();

  // select text from comment body
  supportHub.selectCaseCommentText(-1);

  supportHub.addAnnotationButton().click();
  // eslint-disable-next-line cypress/no-unnecessary-waiting
  cy.wait(1000);
  supportHub.addAnnotationTextarea().realType(annotationText);
  supportHub.addAnnotationSendButton().click();
  cy.wait('@postCaseComment').then(({ response }) => {
    supportHub.annotationText().first().should('be.visible').and('have.text', annotationText);

    cy.request('DELETE', `api/v2/note/${response.body.data[0].s_id}`);
  });
});

it('C318: should verify case comment collapse & collapse all button', { tags: ['staging', 'prod'] }, () => {
  supportHub.gotoCaseDescriptionButton().click();
  supportHub.collapseAllCaseCommentsButton().click();

  supportHub
    .caseReporterNameText()
    .invoke('text')
    .then((reporterName) => {
      supportHub.highlightsButton().click();
      supportHub.highlightsPopupCaseCreationTimeText().realHover();

      supportHub
        .highlightsPopupCaseCreationTimeTooltip()
        .invoke('text')
        .then((caseCreationTime) => {
          supportHub
            .caseCommentsHeader()
            .last()
            .should('have.attr', 'data-collapse-control', 'collapsed')
            .and('contain.text', reporterName + formattedCaseCreationTime(caseCreationTime));
        });
    });

  supportHub.collapseAllCaseCommentsButton().click();
  supportHub.caseCommentsHeaderCollapseButton().last().click();

  supportHub
    .caseReporterNameText()
    .invoke('text')
    .then((reporterName) => {
      supportHub.highlightsButton().click();
      supportHub.highlightsPopupCaseCreationTimeText().realHover();

      supportHub
        .highlightsPopupCaseCreationTimeTooltip()
        .invoke('text')
        .then((caseCreationTime) => {
          supportHub
            .caseCommentsHeader()
            .last()
            .should('have.attr', 'data-collapse-control', 'collapsed')
            .and('contain.text', reporterName + formattedCaseCreationTime(caseCreationTime));
        });
    });
});
