import { getOpenCaseDetails } from './support';
import { urlHelpers } from '../../../utils';
import { apiHelpers, supportHub } from '../../../pages';

beforeEach(() => {
  cy.loginByApi();
  apiHelpers.removeAllFavoriteCustomers();
  getOpenCaseDetails().then((caseDetails) => {
    const caseDetail = Cypress._.sample(caseDetails);

    cy.wrap(caseDetail.customerName).as('customerName');

    cy.visit(urlHelpers.supportHubCasePage(caseDetail.caseId));
  });
});

afterEach(() => apiHelpers.removeAllFavoriteCustomers());

/*
 * Click favorite button
 * Verify data-status attr value is checked
 * Again click favorite button
 * Verify data-status attr value is unchecked
 */
it('C299: should add/remove customer as favorite', () => {
  supportHub.favoriteButton().click();
  supportHub.favoriteButton().invoke('attr', 'data-status').should('equal', 'checked');

  supportHub.favoriteButton().click();
  supportHub.favoriteButton().invoke('attr', 'data-status').should('equal', 'unchecked');
});

/*
 * Hover over the favorite button (should be unchecked).
 * Verify that a tooltip is displayed with text 'Add {customer name} to Favorites'
 */
it('C300: should verify add favorite tooltip', { tags: 'SupportHub' }, function addFavoriteTooltip() {
  supportHub.favoriteButton().trigger('mouseover');
  supportHub.favoriteButtonTooltip().should('be.visible').should('have.text', `Add "${this.customerName}" to Favorites`);
});

/*
 * Click and hover over the favorite button.
 * Verify that a tooltip is displayed with text 'Remove {customer name} from Favorites'
 */
it('C301: should verify remove favorite tooltip', { tags: 'SupportHub' }, function removeFavoriteTooltip() {
  supportHub.favoriteButton().click().trigger('mouseover');
  supportHub.favoriteButtonTooltip().should('be.visible').should('have.text', `Remove "${this.customerName}" from Favorites`);
});
