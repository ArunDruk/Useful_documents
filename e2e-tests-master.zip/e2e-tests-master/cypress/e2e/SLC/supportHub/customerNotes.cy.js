import { getOpenCaseDetails, getUserInitials, getUserName } from './support';
import { randId, urlHelpers } from '../../../utils';
import { apiHelpers, supportHub } from '../../../pages';

describe('Customer Notes verifications', () => {
  beforeEach(() => {
    cy.intercept('POST', 'api/customer-notes').as('postCustomerNote');

    cy.loginByApi();
    getOpenCaseDetails().then((caseDetails) => {
      const caseDetail = Cypress._.sample(caseDetails);

      cy.visit(urlHelpers.supportHubCasePage(caseDetail.caseId));

      supportHub.customerNotesTriggerButton().click();
      cy.get('body').then(($body) => {
        const emptyNotesBtnSelector = '[data-testid=supportHub-caseCustomerNotesEmpty-addNewNotesButton]';

        if ($body.find(emptyNotesBtnSelector).length) {
          cy.get(emptyNotesBtnSelector).should('be.visible').click();
        } else {
          supportHub.customerNotesAddNewNotesButton().click();
        }
      });
    });
  });

  it('C278: should close customer notes textarea on clicking cancel', { tags: 'SupportHub' }, () => {
    supportHub.customerNotesTextField().should('be.visible');
    supportHub.addCustomerNoteCancelButton().click();
    supportHub.customerNotesTextField().should('not.exist');
  });

  it('C279: should disable Add button on empty textarea', { tags: 'SupportHub' }, () => {
    supportHub.customerNotesTextField().should('be.empty');
    supportHub.addCustomerNoteAddButton().should('be.disabled');
  });

  it('C280: should add note on clicking add button', { tags: 'SupportHub' }, () => {
    const noteText = `Test customer notes ${randId()}`;

    supportHub.customerNotesTextField().type(noteText);
    supportHub.addCustomerNoteAddButton().should('be.enabled').click();

    cy.wait('@postCustomerNote').then(({ response }) => {
      const noteId = response.body.note.id;

      supportHub.customerNotesNoteText(noteId).should('have.text', noteText);
      apiHelpers.deleteCustomerNote(noteId);
    });
  });
});

describe('Edit/Delete Customer notes', () => {
  beforeEach(() => {
    const noteText = `Test customer notes ${randId()}`;

    cy.intercept('POST', 'api/customer-notes').as('postCustomerNote');
    cy.intercept('DELETE', 'api/customer-notes/*').as('deleteCustomerNote');

    cy.loginByApi();
    getOpenCaseDetails().then((caseDetails) => {
      const caseDetail = Cypress._.sample(caseDetails);

      apiHelpers.addCustomerNote(noteText, caseDetail.customerId, caseDetail.customerName).then((noteId) => {
        cy.wrap(noteId).as('noteId');
        cy.wrap(noteText).as('noteText');
      });

      cy.visit(urlHelpers.supportHubCasePage(caseDetail.caseId));

      supportHub.customerNotesTriggerButton().click();
    });
  });

  it('C281: should edit customer note', { tags: 'SupportHub' }, function editCustomerNoteTest() {
    const editedNoteText = `Edited Customer Note ${randId()}`;

    supportHub.customerNotesNoteText(this.noteId).should('have.text', this.noteText);

    supportHub.customerNotesEditIconButton().first().click({ force: true });
    supportHub.customerNotesEditTextarea().clear().type(editedNoteText);
    supportHub.customerNotesSaveEditButton().click();

    cy.wait('@postCustomerNote');
    supportHub.customerNotesNoteText(this.noteId).should('have.text', editedNoteText);

    apiHelpers.deleteCustomerNote(this.noteId);
  });

  it('C282: should delete customer note', { tags: 'SupportHub' }, function deleteCustomerNoteTest() {
    supportHub.customerNotesDeleteIconButton().first().click({ force: true });
    cy.wait('@deleteCustomerNote');

    supportHub.customerNotesNoteText(this.noteId).should('not.exist');
  });
});

describe('Customer Notes verifications - with note creation', () => {
  beforeEach(() => {
    const noteText = `Test customer notes ${randId()}`;

    cy.intercept('POST', 'api/customer-notes').as('postCustomerNote');
    cy.intercept('DELETE', 'api/customer-notes/*').as('deleteCustomerNote');

    cy.loginByApi();
    getOpenCaseDetails().then((caseDetails) => {
      const caseDetail = Cypress._.sample(caseDetails);

      apiHelpers.addCustomerNote(noteText, caseDetail.customerId, caseDetail.customerName).then((noteId) => {
        cy.wrap(noteId).as('noteId');
        cy.wrap(noteText).as('noteText');
      });

      cy.visit(urlHelpers.supportHubCasePage(caseDetail.caseId));

      supportHub.customerNotesTriggerButton().click();
    });
  });

  afterEach(function afterEachHook() {
    apiHelpers.deleteCustomerNote(this.noteId);
  });

  /*
   * Verify user avatar is visible and have User's initials
   * Hover over user avatar
   * Verify tooltip is visible with User's display name
   * Verify time of comment creation is visible
   */
  it('C277: should verify author details and time added', () => {
    getUserName().then((name) => {
      supportHub.customerNotesUserAvatar().first().should('be.visible').and('have.text', getUserInitials(name));

      supportHub.customerNotesUserAvatar().realHover();
      // eslint-disable-next-line cypress/no-unnecessary-waiting
      cy.wait(1000);
      supportHub.customerNotesUserAvatarTooltip().first().should('be.visible').and('have.text', name);

      supportHub.customerNotesCreationTimeLabel().first().should('be.visible').and('contain.text', 'a few seconds ago');
    });
  });
});
