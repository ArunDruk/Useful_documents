import { getCaseDetailsWithNoSignals } from './support';
import { urlHelpers } from '../../../utils';
import { supportHub } from '../../../pages';

const removeSentimentLabel = (feedbackRequest, feedbackResponse) => {
  const feedbackReqBody = feedbackRequest;
  Object.keys(feedbackReqBody.feedbackLabels).forEach((key) => {
    if (Object.hasOwn(feedbackReqBody.feedbackLabels, key)) feedbackReqBody.feedbackLabels[key] = false;
  });

  cy.request({
    method: 'POST',
    url: 'api/spans-feedback',
    body: { ...feedbackReqBody, span: feedbackResponse.insertedEntry.span },
  });
};

beforeEach(() => {
  cy.intercept('POST', 'api/spans-feedback').as('markSentimentLabel');
  cy.intercept('POST', 'api/v2/case/comment/search*').as('updateSentimentLabels');

  cy.loginByApi();
  getCaseDetailsWithNoSignals().then((caseDetails) => {
    const caseDetail = Cypress._.sample(caseDetails);

    cy.visit(urlHelpers.supportHubCasePage(caseDetail.caseId));
  });
});

afterEach(function afterEachHook() {
  removeSentimentLabel(this.feedbackRequest, this.feedbackResponse);
});

// TODO: FIX. fails here if found comment body is a case note
it('C294: should add sentiment label', { tags: 'SupportHub' }, () => {
  supportHub.selectCaseCommentText(-1);

  // verify Add label button is displayed
  cy.getByTestId('supportHub-caseTimeline-caseComment-addLabel').should('be.visible').click();

  // apply first unchecked label in popup
  // TODO data-testid request SLC-32160
  cy.getByTestId('common-scrollList').last().find('div').first().click();
  cy.get('[data-testid^=animated-checkbox-default-group][data-status=unchecked]')
    .first()
    .siblings('label')
    .click()
    .siblings('input')
    .invoke('attr', 'data-status')
    .should('equal', 'checked');
  cy.getByTestId('supportHub-apply-labelling-button').click();

  cy.wait('@markSentimentLabel').then(({ request, response }) => {
    const labeledText = request.body.selection.text;

    cy.wrap(request.body).as('feedbackRequest');
    cy.wrap(response.body).as('feedbackResponse');

    cy.wait('@updateSentimentLabels');
    cy.getByTestId('supportHub-sentiment-card-caseComment').first().should('exist').and('have.text', labeledText).click();
  });
});
