import { getOpenCaseDetails } from './support';

beforeEach(() => {
  cy.intercept('POST', 'search/subjects/_search/').as('globalSearch');

  cy.loginByApi();
  cy.visit('/');
  getOpenCaseDetails().then((caseDetails) => {
    const caseDetail = Cypress._.sample(caseDetails);

    cy.wrap(caseDetail.caseId).as('currentOpenCaseId');

    cy.getByTestId('global-search-trigger').click();
    cy.getByTestId('global-search-input').type(caseDetail.caseId);
    cy.wait('@globalSearch');

    cy.getByTestId('global-search-caseView-listItem').first().click();
    cy.waitForLoaders({ waitForGlobalLoader: true });

    cy.getByTestId('supportHub-SHContainer').should('be.visible');
  });
});

it('C273: should close SupportHub modal', { tags: 'SupportHub' }, () => {
  cy.getByTestId('supportHub-actionWrapper-closeDialog').should('be.visible').click();
  cy.getByTestId('supportHub-SHContainer').should('not.exist');
});

it('C274: should have valid URL for CRM link', { tags: 'SupportHub' }, () => {
  cy.request('api/company/settings/support').then(({ body }) => {
    const customLink = body.activeCompanySettings.custom_links_settings.custom_case_url.split('{sor_case_id}')[0];

    cy.getByTestId('supportHub-actionWrapper-openNewTab').invoke('attr', 'href').should('contain', customLink);
  });
});

it('C275: should copy case URL to clipboard', { browser: 'chrome', tags: 'SupportHub' }, function copyCaseUrl() {
  // grant access to the clipboard in Chrome browser
  cy.wrap(
    Cypress.automation('remote:debugger:protocol', {
      command: 'Browser.grantPermissions',
      params: {
        permissions: ['clipboardReadWrite', 'clipboardSanitizedWrite'],
        // make the permission tighter by allowing the current origin only
        // like 'https://localhost:56978'
        origin: window.location.origin,
      },
    })
  );
  // query the window's clipboard permission to get the current state
  // possible values are prompt, denied & granted
  // cy.window().its('navigator.permissions').invoke('query', { name: 'clipboard-read' }).its('state').then(cy.log);

  cy.getByTestId('supportHub-actionWrapper-copyURL').should('be.visible').click();

  // invoke the text available in the clipboard using readText
  cy.window().then((win) => win.navigator.clipboard.readText().then((clipboardText) => expect(clipboardText).to.include(this.currentOpenCaseId)));
});
