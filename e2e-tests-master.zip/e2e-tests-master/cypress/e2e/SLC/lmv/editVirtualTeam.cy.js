import { urlHelpers } from '../../../utils';
import { lmvTeamPage, apiHelpers } from '../../../pages';

const randId = () => Cypress._.random(0, 1e6);
describe('Edit virtual team functionality', () => {
  let vtName = '';
  let vtId = '';
  before(() => {
    cy.loginByApi();
    vtName = `Test Personal Team ${randId()}`;
    cy.slcHelpers
      .getAgentIds(5)
      .then((agentIds) => cy.slcHelpers.createVT(vtName, agentIds))
      .then((response) => {
        vtId = response.body.id;
      });
  });
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.setToDefaultTeamLMV(vtId);
    apiHelpers.removeExistingListAndTileLMV();
    cy.visit(urlHelpers.myDashboard);
  });
  after(() => {
    cy.slcHelpers.deleteVgroup(vtId);
  });

  /**
   * Open the My Dashboard page.
   * Click the three dot option on the team tile and click edit team button.
   * Change team and click save button
   * Check the team change is reflected in the page
   */
  it('C2248: Edit virtual team in LMV', { tags: ['My Dashboard', 'staging'] }, () => {
    lmvTeamPage.editLMVTeam();
  });
});
