import { lmvTeamPage, navBar, virtualTeam } from '../../../pages';
import { urlHelpers } from '../../../utils';

const randId = () => Cypress._.random(0, 1e6);

beforeEach(() => {
  cy.loginByApi();
  cy.visit(urlHelpers.virtualTeams);

  cy.intercept('POST', 'api/v2/group').as('createGroup');
  cy.intercept('search/virtual_groups/_search*').as('search');
});

describe('LMV Tests', () => {
  // Regression C880
  it('C880: Create a new VT and assign it as primary team (Create)', { tags: 'LMV' }, () => {
    // Click on the Create Virtual Team
    virtualTeam.createVirtualTeamButton().scrollIntoView().should('be.visible').click();
    // Selecting the Personal Team
    virtualTeam.teamTypePersonalButton().should('be.visible').click();
    // Enter the VA Name
    const vaTeam = `CypressTest ${randId()}`;
    virtualTeam.virtualTeamNameInput().type(vaTeam);
    // Click on Next button
    virtualTeam.vtCreatePopupNextOrSubmitButton().should('be.visible').click();
    // Enter the Customer name and select customer
    virtualTeam.vtCreatePopupSearchCustomerNameInput().should('be.visible').type('a');
    cy.wait('@search');
    virtualTeam.vtCreatePopupCustomerSearchResultList().eq(0).click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(2000);
    virtualTeam.vtCreatePopupCustomerSearchResultList().eq(1).click();
    virtualTeam.vtCreatePopupNextOrSubmitButton().should('be.visible').click();
    cy.wait('@createGroup');
    // Selecting the Created Virtual Team as Primary team
    virtualTeam.searchVirtualTeamInput().type(vaTeam);
    virtualTeam.searchResultVirtualTeamList().should('have.text', vaTeam);
    virtualTeam.setAsYourTeamButton(vaTeam).click();
    cy.contains('My Team');
    // Navigate to the My Dashboard
    cy.visit(urlHelpers.myDashboard);
    lmvTeamPage.lmvTeamTitleName().should('contain.text', vaTeam);
    // Deleting the Created Virtual Team
    navBar.virtualTeams().should('be.visible').click();
    virtualTeam.searchVirtualTeamInput().type(vaTeam);
    virtualTeam.searchResultVirtualTeamList().should('have.text', vaTeam);
    virtualTeam.deleteVirtualTeamButton().click();
    virtualTeam.confirmDeleteVirtualTeamPopupButton().click();
  });

  // Regression C882
  it('C882: Check if user can change the personal VT over a period of time (Delete)', { tags: 'LMV' }, () => {
    cy.waitForLoaders();
    // Click on the Create Virtual Team
    virtualTeam.createVirtualTeamButton().scrollIntoView().should('be.visible').click();
    // Selecting the Personal Team
    virtualTeam.teamTypePersonalButton().should('be.visible').click();
    // Enter the VA Name
    const vaTeam = `CypressTest ${randId()}`;
    virtualTeam.virtualTeamNameInput().type(vaTeam);
    // Click on Next button
    virtualTeam.vtCreatePopupNextOrSubmitButton().should('be.visible').click();
    // Enter the Customer name and select customer
    virtualTeam.vtCreatePopupSearchCustomerNameInput().should('be.visible').type('a');
    cy.wait('@search');
    virtualTeam.vtCreatePopupCustomerSearchResultList().eq(0).click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(2000);
    virtualTeam.vtCreatePopupCustomerSearchResultList().eq(1).click();
    virtualTeam.vtCreatePopupNextOrSubmitButton().should('be.visible').click();
    cy.wait('@createGroup');
    // Selecting the Created Virtual Team as Primary team
    virtualTeam.searchVirtualTeamInput().type(vaTeam);
    virtualTeam.searchResultVirtualTeamList().should('have.text', vaTeam);
    virtualTeam.setAsYourTeamButton(vaTeam).click();
    cy.contains('My Team');
    // Navigate to the My Dashboard
    cy.visit(urlHelpers.myDashboard);
    cy.waitForLoaders();
    lmvTeamPage.lmvTeamTitleName().should('contain.text', vaTeam);
    // Deleting the Created Virtual Team
    navBar.virtualTeams().should('be.visible').click();
    cy.waitForLoaders();
    virtualTeam.searchVirtualTeamInput().type(vaTeam);
    virtualTeam.searchResultVirtualTeamList().should('have.text', vaTeam);
    virtualTeam.deleteVirtualTeamButton().click();
    virtualTeam.confirmDeleteVirtualTeamPopupButton().click();
    // Navigate to the My Dashboard
    cy.visit(urlHelpers.myDashboard);
    cy.waitForLoaders();
    cy.contains('You haven’t chosen your team yet!');
  });

  // Regression C883
  it('C883: Verify all the agents from the team is shown', { tags: 'LMV' }, () => {
    // Click on the Create Virtual Team
    virtualTeam.createVirtualTeamButton().scrollIntoView().should('be.visible').click();
    // Selecting the Personal Team
    virtualTeam.teamTypePersonalButton().should('be.visible').click();
    // Enter the VA Name
    const vaTeam = `CypressTest ${randId()}`;
    virtualTeam.virtualTeamNameInput().type(vaTeam);
    // Click on Next button
    virtualTeam.vtCreatePopupNextOrSubmitButton().should('be.visible').click();
    // Enter the Customer name and select customer
    virtualTeam.vtCreatePopupSearchCustomerNameInput().should('be.visible').type('a');
    cy.wait('@search');
    virtualTeam.vtCreatePopupCustomerSearchResultList().eq(0).click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(2000);
    virtualTeam.vtCreatePopupCustomerSearchResultList().eq(1).click();
    virtualTeam.vtCreatePopupNextOrSubmitButton().should('be.visible').click();
    cy.wait('@createGroup');
    // Selecting the Created Virtual Team as Primary team
    virtualTeam.searchVirtualTeamInput().type(vaTeam);
    virtualTeam.searchResultVirtualTeamList().should('have.text', vaTeam);
    virtualTeam.setAsYourTeamButton(vaTeam).click();
    cy.contains('My Team');
    virtualTeam.agentNameInVirtualTeamList().then((agentName) => {
      const vaName1 = agentName.text();
      const agentName1 = vaName1.split('My Team')[1].split(',')[0];
      const agentName2 = vaName1.split('My Team')[1].split(',')[1];
      // Navigate to the My Dashboard
      cy.visit(urlHelpers.myDashboard);
      lmvTeamPage.lmvTeamTitleName().should('contain.text', vaTeam);
      lmvTeamPage.teamAgentList().should('contain.text', agentName1.trim());
      lmvTeamPage.lmvAgentName().eq(1).should('contain.text', agentName2.trim());
    });
    // Deleting the Created Virtual Team
    navBar.virtualTeams().should('be.visible').click();
    virtualTeam.searchVirtualTeamInput().type(vaTeam);
    virtualTeam.searchResultVirtualTeamList().should('have.text', vaTeam);
    virtualTeam.deleteVirtualTeamButton().click();
    virtualTeam.confirmDeleteVirtualTeamPopupButton().click();
  });

  // Regression C879
  it('C879: Verify the Banner Visibility in VT page (Banner)', { tags: 'LMV' }, () => {
    // Navigate to the My Dashboard
    cy.visit(urlHelpers.myDashboard);
    lmvTeamPage.teamCard().then(($btn) => {
      const keyWord = $btn.text();
      if (keyWord.split('!')[0] === 'You haven’t chosen your team yet') {
        cy.contains('You haven’t chosen your team yet!');
        // Navigate to Virtual teams and verify the Banner visibility in VT page
        cy.visit(urlHelpers.virtualTeams);
        cy.contains('You haven’t chosen your team yet!');
      } else {
        lmvTeamPage.lmvTeamTitleName().then(($btn1) => {
          const vaTeam = $btn1.text().split('|')[0];
          // Navigate to Virtual teams
          cy.visit(urlHelpers.virtualTeams);
          virtualTeam.searchVirtualTeamInput().type(vaTeam);
          virtualTeam.searchResultVirtualTeamList().should('have.text', vaTeam);
          cy.contains('My Team');
          // Click on Dart icon to check the Banner visibility in VT page
          virtualTeam.setAsYourTeamButton(vaTeam).click();
          cy.contains('You haven’t chosen your team yet!');
          virtualTeam.setAsYourTeamButton(vaTeam).click();
          cy.contains('My Team');
        });
      }
    });
  });
});
