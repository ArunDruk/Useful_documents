import { urlHelpers } from '../../../utils';
import { lmvTeamPage, apiHelpers } from '../../../pages';

const randId = () => Cypress._.random(0, 1e6);
describe('Case tile functionality', () => {
  let vtName = '';
  let vtId = '';
  before(() => {
    cy.loginByApi();
    vtName = `Test Personal Team ${randId()}`;
    cy.slcHelpers
      .getAgentIds(5)
      .then((agentIds) => cy.slcHelpers.createVT(vtName, agentIds))
      .then((response) => {
        vtId = response.body.id;
      });
  });
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.setToDefaultTeamLMV(vtId);
    apiHelpers.removeExistingListAndTileLMV();
    cy.visit(urlHelpers.myDashboard);
  });
  after(() => {
    cy.slcHelpers.deleteVgroup(vtId);
  });

  /**
   * Open the My Dashboard page.
   * Click on add(plus) button.
   * Select the case tile option in the add a card dialog box and click add button.
   * Once tile created check the tile is visible in the page.
   */
  it('C2243: Create case tile in my dashboard', { tags: ['My Dashboard', 'staging'] }, () => {
    lmvTeamPage.createCaseTile();
    lmvTeamPage.deleteCaseTile();
  });

  /**
   * Open the My Dashboard page.
   * Click on add(plus) button.
   * Select the case tile option in the add a card dialog box and click add button.
   * Once tile created check the tile is visible in the page.
   * Click on any SH ticket and checks its opens correctly
   */
  it('C2247: Opening support hub in case tile', { tags: ['My Dashboard', 'staging'] }, () => {
    lmvTeamPage.createCaseTile();

    for (let i = 0; i < 3; i += 1) {
      // eslint-disable-next-line cypress/no-unnecessary-waiting
      cy.wait(500);
      lmvTeamPage.caseStatisticsDropdown().eq(i).click({ force: true });
      cy.waitForLoaders();
      lmvTeamPage.verifyTileSupportHub();
    }
    lmvTeamPage.deleteCaseTile();
  });
});
