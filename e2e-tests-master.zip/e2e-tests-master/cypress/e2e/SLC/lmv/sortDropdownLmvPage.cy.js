import { randId, urlHelpers } from '../../../utils';
import { lmvTeamPage, apiHelpers } from '../../../pages';

describe('LMV - Sort Dropdown Functionality Check', () => {
  let vtName = '';
  let vtId = '';

  before(() => {
    cy.loginByApi();
    vtName = `Test Personal Team ${randId()}`;
    cy.slcHelpers
      .getAgentIds(5)
      .then((agentIds) => cy.slcHelpers.createVT(vtName, agentIds))
      .then((response) => {
        vtId = response.body.id;
      });
  });
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.setToDefaultTeamLMV(vtId);
    apiHelpers.removeExistingListAndTileLMV();
    cy.visit(urlHelpers.myDashboard);
  });
  afterEach(() => {
    lmvTeamPage.deleteCaseList();
  });
  after(() => {
    cy.slcHelpers.deleteVgroup(vtId);
  });

  /**
   * // TODO- Sort order validation will cover once feature is implemented,Tracking via- SLC-35399.
   *
   * Open the My Dashboard page, click on add(plus) button.
   * Select the case list option in the add a card dialog box.
   * In case list, from the dropdown select any other option (Attention Score).
   * Validate that 'Sentiment Score' is not displayed on the dropdown text.
   * In case list, from the dropdown select Sentiment Score.
   * Validate that 'Sentiment Score' is displayed on the dropdown text.
   */
  it('C134579: Validate ticket list sort by Sentiment score', { tags: ['My Dashboard', 'staging'] }, () => {
    lmvTeamPage.createCaseList();
    lmvTeamPage.lmvCaseListSortDropdown().should('have.text', 'Sentiment Score');
    lmvTeamPage.lmvCaseListSortDropdown().click();
    lmvTeamPage.lmvCaseListSortDropdownAttentionScoreOption().click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    lmvTeamPage.lmvCaseListSortDropdownText().should('not.have.text', 'Sentiment Score');
    lmvTeamPage.lmvCaseListSortDropdown().click();
    lmvTeamPage.lmvCaseListSortDropdownSentimentScoreOption().click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    lmvTeamPage.lmvCaseListSortDropdownText().should('have.text', 'Sentiment Score');
  });

  /**
   * // TODO- Sort order validation will cover once feature is implemented,Tracking via- SLC-35399.
   *
   * Open the My Dashboard page, click on add(plus) button.
   * Select the case list option in the add a card dialog box.
   * In case list, from the dropdown select Attention Score.
   * Validate that 'Attention Score' is displayed on the dropdown text.
   */
  it('C134580: Validate ticket list sort by Attention score', { tags: ['My Dashboard', 'staging'] }, () => {
    lmvTeamPage.createCaseList();
    lmvTeamPage.lmvCaseListSortDropdown().should('have.text', 'Sentiment Score');
    lmvTeamPage.lmvCaseListSortDropdown().click();
    lmvTeamPage.lmvCaseListSortDropdownAttentionScoreOption().click();
    lmvTeamPage.lmvCaseListSortDropdownText().should('have.text', 'Attention Score');
  });

  /**
   * // TODO- Sort order validation will cover once feature is implemented,Tracking via- SLC-35399.
   *
   * Open the My Dashboard page, click on add(plus) button.
   * Select the case list option in the add a card dialog box.
   * In case list, from the dropdown select Conversation Count.
   * Validate that 'Conversation Count' is displayed on the dropdown text.
   */
  it('C134581: Validate ticket list sort by Conversation Count', { tags: ['My Dashboard', 'staging'] }, () => {
    lmvTeamPage.createCaseList();
    lmvTeamPage.lmvCaseListSortDropdown().should('have.text', 'Sentiment Score');
    lmvTeamPage.lmvCaseListSortDropdown().click();
    lmvTeamPage.lmvCaseListSortDropdownConversationCountOption().click();
    lmvTeamPage.lmvCaseListSortDropdownText().should('have.text', 'Conversation Count');
  });

  /**
   * // TODO- Sort order validation will cover once feature is implemented,Tracking via- SLC-35399.
   *
   * Open the My Dashboard page, click on add(plus) button.
   * Select the case list option in the add a card dialog box.
   * In case list, from the dropdown select Case Open Time.
   * Validate that 'Case Open Time' is displayed on the dropdown text.
   */
  it('C134582: Validate ticket list sort by Case Open time', { tags: ['My Dashboard', 'staging'] }, () => {
    lmvTeamPage.createCaseList();
    lmvTeamPage.lmvCaseListSortDropdown().should('have.text', 'Sentiment Score');
    lmvTeamPage.lmvCaseListSortDropdown().click();
    lmvTeamPage.lmvCaseListSortDropdownCaseOpenTimeOption().click();
    lmvTeamPage.lmvCaseListSortDropdownText().should('have.text', 'Case Open Time');
  });

  /**
   * // TODO- Sort order validation will cover once feature is implemented,Tracking via- SLC-35399.
   *
   * Open the My Dashboard page, click on add(plus) button.
   * Select the case list option in the add a card dialog box.
   * In case list, from the dropdown select Responder Count.
   * Validate that 'Responder Count' is displayed on the dropdown text.
   */
  it('C134613: Validate ticket list sort by Responder Count', { tags: ['My Dashboard', 'staging'] }, () => {
    lmvTeamPage.createCaseList();
    lmvTeamPage.lmvCaseListSortDropdown().should('have.text', 'Sentiment Score');
    lmvTeamPage.lmvCaseListSortDropdown().click();
    lmvTeamPage.lmvCaseListSortDropdownResponderCountOption().click();
    lmvTeamPage.lmvCaseListSortDropdownText().should('have.text', 'Responder Count');
  });

  /**
   * // TODO- Sort order validation will cover once feature is implemented,Tracking via- SLC-35399.
   *
   * Open the My Dashboard page, click on add(plus) button.
   * Select the case list option in the add a card dialog box.
   * In case list, from the dropdown select Last Outbound message.
   * Validate that 'Last Outbound message' is displayed on the dropdown text.
   */
  it('C134614: Validate ticket list sort by Last Outbound message', { tags: ['My Dashboard', 'staging'] }, () => {
    lmvTeamPage.createCaseList();
    lmvTeamPage.lmvCaseListSortDropdown().should('have.text', 'Sentiment Score');
    lmvTeamPage.lmvCaseListSortDropdown().click();
    lmvTeamPage.lmvCaseListSortDropdownLastOutboundMessageOption().click();
    lmvTeamPage.lmvCaseListSortDropdownText().should('have.text', 'Last Outbound message');
  });

  /**
   * // TODO- Sort order validation will cover once feature is implemented,Tracking via- SLC-35399.
   *
   * Open the My Dashboard page, click on add(plus) button.
   * Select the case list option in the add a card dialog box.
   * In case list, from the dropdown select Last Inbound message.
   * Validate that 'Last Inbound message' is displayed on the dropdown text.
   */
  it('C134615: Validate ticket list sort by Last inbound message', { tags: ['My Dashboard', 'staging'] }, () => {
    lmvTeamPage.createCaseList();
    lmvTeamPage.lmvCaseListSortDropdown().should('have.text', 'Sentiment Score');
    lmvTeamPage.lmvCaseListSortDropdown().click();
    lmvTeamPage.lmvCaseListSortDropdownLastInboundMessageOption().click();
    lmvTeamPage.lmvCaseListSortDropdownText().should('have.text', 'Last Inbound Message');
  });

  /**
   * // TODO- Sort order validation will cover once feature is implemented,Tracking via- SLC-35399.
   *
   * Open the My Dashboard page, click on add(plus) button.
   * Select the case list option in the add a card dialog box.
   * In case list, from the dropdown select Case Views.
   * Validate that 'Case Views' is displayed on the dropdown text.
   */
  it('C134616: Validate ticket list sort by Case Views', { tags: ['My Dashboard', 'staging'] }, () => {
    lmvTeamPage.createCaseList();
    lmvTeamPage.lmvCaseListSortDropdown().should('have.text', 'Sentiment Score');
    lmvTeamPage.lmvCaseListSortDropdown().click();
    lmvTeamPage.lmvCaseListSortDropdownCaseViewsOption().click();
    lmvTeamPage.lmvCaseListSortDropdownText().should('have.text', 'Case Views');
  });
});
