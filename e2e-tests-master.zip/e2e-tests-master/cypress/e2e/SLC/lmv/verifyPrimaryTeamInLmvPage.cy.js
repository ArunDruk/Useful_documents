import { urlHelpers } from '../../../utils';
import { lmvTeamPage, virtualTeam } from '../../../pages';

describe('Verify Primary Team In LMV Page', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.virtualTeams);
  });

  /**
   * Regression C872
   *  - Go to VT page .
   * Hover over the Virtual teams in the page.
   * A dart symbol will appear on the right side of the name of the VT
   * Hover over the dart symbol of the VT which you want to make your primary team. A tool tip will appear which says Set as Your team
   * Click on the Dart symbol.
   */
  it('C872: Check If an existing VT is getting selected as primary teams from Virtual teams page', { tags: ['LMV', 'staging'] }, () => {
    virtualTeam.closeSetAsYourTeamPopup();
    const vtName = virtualTeam.createVirtualTeam('Global');
    virtualTeam.setAsYourTeamButton(vtName).click();
    cy.visit(urlHelpers.myDashboard);
    lmvTeamPage.lmvTeamTitleName().should('contain.text', vtName);
    cy.visit(urlHelpers.virtualTeams);
    virtualTeam.deleteVirtualTeam(vtName);
  });

  /**
   * Regression C876
   *  - Go to VT page .
   * Hover over the personal VT present .
   */
  it('C876: Check If personal VT is getting selected as primary teams', { tags: ['LMV', 'staging'] }, () => {
    virtualTeam.closeSetAsYourTeamPopup();
    const vtName = virtualTeam.createVirtualTeam('Personal');
    virtualTeam.setAsYourTeamButton(vtName).click();
    cy.visit(urlHelpers.myDashboard);
    lmvTeamPage.lmvTeamTitleName().should('contain.text', vtName);
    cy.visit(urlHelpers.virtualTeams);
    virtualTeam.deleteVirtualTeam(vtName);
  });

  /**
   * Regression C881
   *  Go to VT page
   * Edit the personal VT added as primary team for summary page.
   * Save the details.
   * Traverse to Summary page and check the change's effect
   */
  it('C881: Check if user can change the personal VT over a period of time (Edit)', { tags: ['LMV', 'staging'] }, () => {
    virtualTeam.closeSetAsYourTeamPopup();
    const vtName = virtualTeam.createVirtualTeam('Global');
    virtualTeam.setAsYourTeamButton(vtName).click();
    cy.visit(urlHelpers.myDashboard);
    lmvTeamPage.lmvTeamTitleName().should('contain.text', vtName);
    cy.visit(urlHelpers.virtualTeams);
    virtualTeam.editVirtualTeamButton(vtName).click();
    const newAgentName = virtualTeam.addNewAgentInVirtualTeam(vtName);
    cy.visit(urlHelpers.myDashboard);
    lmvTeamPage.lmvTeamTitleName().should('contain.text', vtName);
    lmvTeamPage.lmvAgentName().should('contain.text', newAgentName);
    cy.visit(urlHelpers.virtualTeams);
    virtualTeam.deleteVirtualTeam(vtName);
  });
});
