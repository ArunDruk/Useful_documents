import { urlHelpers } from '../../../utils';
import { lmvTeamPage, apiHelpers, supportHub } from '../../../pages';

const randId = () => Cypress._.random(0, 1e6);
describe('Case list functionality', () => {
  let vtName = '';
  let vtId = '';

  before(() => {
    cy.loginByApi();
    vtName = `Test Personal Team ${randId()}`;
    cy.slcHelpers
      .getAgentIds(5)
      .then((agentIds) => cy.slcHelpers.createVT(vtName, agentIds))
      .then((response) => {
        vtId = response.body.id;
      });
  });
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.setToDefaultTeamLMV(vtId);
    apiHelpers.removeExistingListAndTileLMV();
    cy.visit(urlHelpers.myDashboard);
  });
  after(() => {
    cy.slcHelpers.deleteVgroup(vtId);
  });

  /**
   * Open the My Dashboard page.
   * Click on add(plus) button.
   * Select the case list option in the add a card dialog box.
   * Once list created check the list is visible in the page.
   */
  it('C2242: Create case list in my dashboard', { tags: ['My Dashboard', 'staging'] }, () => {
    lmvTeamPage.createCaseList();
    lmvTeamPage.deleteCaseList();
  });

  /**
   * Open the My Dashboard page.
   * Click on add(plus) button.
   * Select the case list option in the add a card dialog box.
   * Delete the case list, Once list deleted check the list is not exist in the page.
   */
  it('C2244: Delete case list in my dashboard', { tags: ['My Dashboard', 'staging'] }, () => {
    lmvTeamPage.createCaseList();
    lmvTeamPage.deleteCaseList();
  });

  /**
   * Open the My Dashboard page.
   * Click on add(plus) button.
   * Select the case list option in the add a card dialog box.
   * Once list created check the list is visible in the page.
   * Click the three dot option and click edit case list button.
   * Change the name of the case list and click some other label and click add button
   * Once list edited check the list is updated in the page.
   */
  it('C2245: Edit case list in my dashboard', { tags: ['My Dashboard', 'staging'] }, () => {
    lmvTeamPage.createCaseList();
    lmvTeamPage.editCaseList();
    lmvTeamPage.deleteCaseList();
  });

  /**
   * Open the My Dashboard page.
   * Click on the plus icon on the top right corner.
   * Select the case list option in the add a card dialog box and click add button.
   * Once list created check the list is visible in the page.
   * Click on any SH ticket and checks its opens correctly
   */
  it('C2246: Opening support hub in case list', { tags: ['My Dashboard', 'staging'] }, () => {
    lmvTeamPage.createCaseList();
    lmvTeamPage.verifyListSupportHub();
    lmvTeamPage.deleteCaseList();
  });

  /**
   * Open the My Dashboard page.
   * Note the first agent name in the Team.
   * Mouseover on the first agent case number band click on it.
   * Open any caselist supporthub
   * Validate that agent name should be same in the support hub bread crump.
   */
  it('C9125: Opening support hub in case list', { tags: ['My Dashboard', 'staging'] }, () => {
    lmvTeamPage.lmvTeamTitleName().should('contain.text', vtName);
    lmvTeamPage
      .lmvTeamFirstAgentName()
      .first()
      .then(($agentName) => {
        const agentName = $agentName.text();

        lmvTeamPage.lmvTeamFirstAgentCaseNumber().trigger('mouseover');
        lmvTeamPage.lmvTeamFirstAgentCaseNumber().click();
        cy.waitForLoaders();
        lmvTeamPage.caseTileSupportHubCardId().eq(0).click();
        cy.waitForLoaders();
        supportHub.baseContainer().should('be.visible');
        supportHub.breadcrumbContent().invoke('text').should('contains', agentName);
        lmvTeamPage.supportHubPopupCloseIcon().click();
      });
  });
});
