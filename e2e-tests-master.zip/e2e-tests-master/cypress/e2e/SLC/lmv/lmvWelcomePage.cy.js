import { urlHelpers } from '../../../utils';
import { lmvTeamPage, apiHelpers } from '../../../pages';

describe('Welcome Page Visibility', () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.setToWelcomePageLMV();
    cy.visit(urlHelpers.myDashboard);
  });

  /**
   * Open the My Dashboard page first time.
   * Check the welcome note text-"You haven’t chosen your team yet!".
   */
  it('C2241: Welcome page visibility check in LMV', { tags: ['My Dashboard', 'staging'] }, () => {
    lmvTeamPage.verifyWelcomePage();
  });
});
