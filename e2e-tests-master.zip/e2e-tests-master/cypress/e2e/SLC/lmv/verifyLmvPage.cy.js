import { urlHelpers } from '../../../utils';
import { lmvTeamPage, apiHelpers, agentInsights } from '../../../pages';

const randId = () => Cypress._.random(0, 1e6);
describe('Verify LMV Page', () => {
  let vtName = '';
  let vtId = '';

  before(() => {
    cy.loginByApi();
    apiHelpers.clearRecentlyVisitedAgentInsight();
    vtName = `Test Personal Team ${randId()}`;
    cy.slcHelpers
      .getAgentIds(2)
      .then((agentIds) => cy.slcHelpers.createVT(vtName, agentIds))
      .then((response) => {
        vtId = response.body.id;
      });
  });
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.setToDefaultTeamLMV(vtId);
    apiHelpers.removeExistingListAndTileLMV();
    cy.visit(urlHelpers.myDashboard);
  });
  after(() => {
    cy.slcHelpers.deleteVgroup(vtId);
  });

  /**
   * Regression C893
   *  - There are two cancel buttons in the 'Add a card' flow :
   * One while choosing the type of card - when user clicks the cancel button -the modal should close.
   * Once the user selects the card type and clicks on next option, the card name and its nature can be defines - if user clicks on the cancel button present there then the flow should discard.
   */
  it('C893: Verify cancel button should discard the process', { tags: ['LMV', 'staging'] }, () => {
    lmvTeamPage.addCardButton().click();
    lmvTeamPage.addCardCancelButton().click();
    lmvTeamPage.addCardPopup().should('not.exist');
    lmvTeamPage.addCardButton().should('be.visible');
    // Click Cancel after Navigating to Next Tab
    lmvTeamPage.addCardButton().click();
    lmvTeamPage.caseListButton().click();
    lmvTeamPage.addCardNextButton().click();
    lmvTeamPage.caseListEditorCancelButton().click();
    lmvTeamPage.addCardPopup().should('not.exist');
    lmvTeamPage.addCardButton().should('be.visible');
  });

  /**
   * Regression C894
   *  - When user clicks on Back button during 'Add a card' flow after selecting the type of card to be added,
   * the date whatever given in the next section should get rest and user will be able to start fresh from the first section again
   * i.e select the type of card and then specify a name(not necessary) and then selects the which kind of info user wants to see in the card .
   */
  it('C894: Verify back button takes to the previous section', { tags: ['LMV', 'staging'] }, () => {
    lmvTeamPage.addCardButton().click();
    lmvTeamPage.caseListButton().click();
    lmvTeamPage.addCardNextButton().click();
    lmvTeamPage.caseListEditorTitleInput().clear().type('Cypress');
    lmvTeamPage.addCardBackButton().click();
    lmvTeamPage.addCardNextButton().click();
    lmvTeamPage.caseListEditorTitleInput().should('not.have.text', 'Cypress');
    lmvTeamPage.caseListEditorCancelButton().click();
  });

  /**
   * Regression C887
   *  - Click on 'Add a card' icon -present in top right corner - plus icon.
   * Check the Flow.
   */
  it('C887: Check Add a card flow (Add)', { tags: ['LMV', 'staging'] }, () => {
    lmvTeamPage.addCardButton().click();
    lmvTeamPage.caseListButton().should('be.visible');
    lmvTeamPage.caseTileButton().should('be.visible');
    lmvTeamPage.addCardPopup().should('exist');
    lmvTeamPage.addCardCancelButton().click();
    lmvTeamPage.addCardButton().should('be.visible');
  });

  /**
   * Regression C888
   *  Click on 'Add a card' icon -present in top right corner - plus icon.
   *  Check the Flow. (Add 02)
   */
  it('C888: Check Add a card flow (Add 02)', { tags: ['LMV', 'staging'] }, () => {
    lmvTeamPage.addCardButton().click();
    lmvTeamPage.addCardPopup().should('exist');
    lmvTeamPage.caseListButton().should('be.visible').click();
    lmvTeamPage.addCardNextButton().click();
    cy.contains('Negative Sentiments').should('exist');
    cy.contains('about to miss SLA').should('exist');
    cy.contains('greater than 2 months old').should('exist');
    cy.contains('inactive over 2 months').should('exist');
    lmvTeamPage.addCardBackButton().scrollIntoView().click();
    lmvTeamPage.caseTileButton().should('be.visible').click();
    lmvTeamPage.addCardNextButton().click();
    cy.contains('Need Attention').should('exist');
    cy.contains('Negative Sentiments').should('exist');
    cy.contains('Product Feedback').should('exist');
    cy.contains('Likely to escalate').should('exist');
    cy.contains('Escalated Today').should('exist');
    cy.contains('Escalation Requests').should('exist');
    cy.contains('Active Escalations').should('exist');
    cy.contains('Cases about to miss').should('exist');
    cy.contains('Missed First Response Time').should('exist');
    cy.contains('Missed Follow-up Response Time').should('exist');
    lmvTeamPage.caseTileEditorCancelButton().click();
    lmvTeamPage.addCardButton().should('be.visible');
  });

  /**
   * Regression C889
   *  Click on 'Add a card' icon -present in top right corner - plus icon.
   *  Check the Flow. (Edit)
   */
  it('C889: Check Add a card flow (Edit)', { tags: ['LMV', 'staging'] }, () => {
    lmvTeamPage.createCaseList();
    lmvTeamPage.editCaseList();
    lmvTeamPage.deleteCaseList();
  });

  /**
   * Regression C890
   *  Click on 'Add a card' icon -present in top right corner - plus icon.
   *  Check the Flow. (Delete)
   */
  it('C890: Check Add a card flow (Delete)', { tags: ['LMV', 'staging'] }, () => {
    lmvTeamPage.createCaseList();
    lmvTeamPage.deleteCaseList();
  });

  /**
   * Regression C891
   *  Click on 'Add a card' icon -present in top right corner - plus icon.
   *  Check the Flow. (Data)
   */
  it('C891: Check Add a card flow (Data)', { tags: ['LMV', 'staging'] }, () => {
    lmvTeamPage.createCaseList();
    lmvTeamPage.caseListSupportHubCardName().should('exist');
    lmvTeamPage.deleteCaseList();
  });

  /**
   * Regression C884
   * - Search for the agent present in primary team.
   * Check the ticket details from the profile.
   * Check the same data in summary page.
   */
  it('C884: Verify the ticket count for agents from the team shown', { tags: ['LMV', 'staging'] }, () => {
    lmvTeamPage
      .lmvAgentName()
      .eq(0)
      .then(($name) => {
        const agentName = $name.text();
        lmvTeamPage
          .lmvAgentOpenCaseCount()
          .eq(0)
          .then((lmvCount) => {
            const lmvAgentCount = lmvCount.text().replace(' ', '');
            cy.visit(urlHelpers.agentInsights.home);
            agentInsights.agentInsightsSearchFieldInput().type(agentName);
            agentInsights.agentSearchResultList().eq(0).click();
            cy.waitForLoaders();
            agentInsights.agentOpenCasesCountTab().then((caseCount) => {
              expect(caseCount.text()).to.eq(lmvAgentCount);
            });
          });
      });
  });

  /**
   * Regression C885
   * - Click on 'Open profile in new tab' icon- from My Dashboard page.
   * Check the page it opens the details in.
   */
  it('C885: Check if user can check profile of any agents from summary page', { tags: ['LMV', 'staging'] }, () => {
    cy.waitForLoaders();
    lmvTeamPage
      .lmvAgentName()
      .eq(0)
      .then(($name) => {
        const agentName = $name.text();
        lmvTeamPage
          .lmvAgentLinkButton()
          .eq(0)
          .invoke('attr', 'href')
          .then(($agentLink) => {
            cy.visit($agentLink);
            cy.waitForLoaders();
            agentInsights
              .agentNameInsightViewLabel()
              .invoke('text')
              .then((actualName) => {
                expect(actualName).to.eq(agentName);
              });
          });
      });
  });

  /**
   * Regression C886
   *  - Click on 'Open profile in new tab' icon- from summary page.
   * Check the page it opens the details in.
   * Sum up all the cases count, match the same with summary page's data
   */
  it('C886: Verify the total number of cases shown is equal to the add up for all the individual agents cases from the team', { tags: ['LMV', 'staging'] }, () => {
    cy.waitForLoaders();
    lmvTeamPage
      .lmvTeamTitleName()
      .eq(0)
      .then(($title) => {
        const lmvTotalCount = $title.text().split('|')[1];
        lmvTeamPage
          .lmvAgentOpenCaseCount()
          .eq(0)
          .then((lmvCount1) => {
            const lmvAgentCount1 = lmvCount1.text().split(' ')[0];
            lmvTeamPage
              .lmvAgentOpenCaseCount()
              .eq(1)
              .then((lmvCount2) => {
                const lmvAgentCount2 = lmvCount2.text().split(' ')[0];
                const actualAgentCount = parseInt(lmvAgentCount1, 10) + parseInt(lmvAgentCount2, 10);
                expect(actualAgentCount).to.eq(parseInt(lmvTotalCount.split(' ')[0], 10));
              });
          });
      });
  });
});
