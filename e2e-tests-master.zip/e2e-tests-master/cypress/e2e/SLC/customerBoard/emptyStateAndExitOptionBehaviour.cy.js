import { closeOnboardingPage, setToStandardList } from './support';
import { urlHelpers } from '../../../utils';
import { customerBoardPage } from '../../../pages';

beforeEach(() => {
  cy.loginByApi();
  closeOnboardingPage();
  setToStandardList();
  cy.visit(urlHelpers.customerBoard);
});

describe('Customer Board page - Empty state and Exit option functionality check', () => {
  it('C87: Exit option functionality checks in add/edit flow', { tags: 'Customer Board' }, () => {
    /*
     Exit option(cancel_button)_behavior:
     Test steps:
     1. Open the customer board page
     2. Click 'Create New List'
     3. Click any option and click cancel button
     4. Page should retain the previous state
     */

    customerBoardPage
      .listTitleNameLabel()
      .eq(1)
      .then(($btn) => {
        const expectedName = $btn.text();

        customerBoardPage.createNewListButton().click();
        customerBoardPage.createListEscalationPredictionLabelCheckbox().click({ force: true });
        customerBoardPage.createListCancelButton().click();

        customerBoardPage
          .listTitleNameLabel()
          .eq(1)
          .then(($btnAfterCancel) => {
            const titleNameAfterCancel = $btnAfterCancel.text();

            expect(titleNameAfterCancel).to.eq(expectedName);
          });
      });
  });

  it('C85: Empty state functionality checks', { tags: 'Customer Board' }, () => {
    /*
     List empty state behavior:
     Test steps:
     1. Open the customer board page
     2. Click 'Create New List'
     3. Apply some changes which will lead to an empty state in the list
     4. Check the empty state behavior in the list shown
     */

    customerBoardPage.createNewListButton().click();
    customerBoardPage.createListEscalationPredictionLabelCheckbox().click({ force: true });
    customerBoardPage.createListAddButton().click();

    customerBoardPage.threeDotMenuDropdown().eq(0).click();
    customerBoardPage.editListButton().eq(0).should('be.visible').click();
    customerBoardPage.editListCustomFieldDropDown().click(); //
    customerBoardPage.editListOptionModalTitle().eq(0).should('be.visible').click();
    customerBoardPage.editListOptionModalList().eq(2).should('be.visible').click();
    customerBoardPage.editListOptionFilterButton().should('be.visible').click();
    customerBoardPage.editListApplyButton().should('be.visible').click();
    customerBoardPage.customerBoardEmptyStateList().invoke('text').should('include', 'No customers!Try broadening your filters');

    customerBoardPage.threeDotMenuDropdown().eq(0).click();
    customerBoardPage.deleteListButton().eq(0).should('be.visible').click();
    customerBoardPage.deleteListPopupButton().should('be.visible').click();
  });
});
