export const setToStandardList = () =>
  cy.request({
    method: 'PUT',
    url: '/api/users/dashboard_settings',
    headers: { 'Content-Type': 'application/json' },
    body: {
      dashboardName: 'support',
      settingsKey: 'customer_board_page_settings',
      settingsSubKey: 'lists',
      settingsValue: {
        _aQdksHXcFc_qf0Og_FoA: { type: 'score', value: 'sl_account_health_score', name: 'Customers ranked by Health Score', order: 0 },
        'JgusCJ-pzS1Up_mJj2U48': { type: 'escalation', value: 'escalation', escalationState: 'total', name: 'Customers with Escalations', order: 1 },
        '-NsumVu4HPoqn-4EDL7Y7': { type: 'escalationPrediction', value: 'escalationPrediction', name: 'Customers with likely to escalate cases', order: 2 },
        uzU5Nsm7gfRfpkaqz1rLv: { type: 'signal', value: 'Production Issue', timePeriod: { value: 3, unit: 'months' }, name: 'Customers with production issues', order: 3 },
        'xyR0orfs-3PR5EJQswrVa': { type: 'signal', value: 'Critical Issue', timePeriod: { value: 3, unit: 'months' }, name: 'Customers with critical issues', order: 4 },
        'O_F0xdaRI2uAPWf-JzfWj': { type: 'icon', value: 'caseVolume', timePeriod: { value: 3, unit: 'months' }, name: 'Customers ranked by case volume', order: 5 },
        Me2NgPxTqFdLGDXKcyurq: { type: 'signal', value: 'Escalation Request', timePeriod: { value: 3, unit: 'months' }, name: 'Customers with Escalation requests', order: 6 },
      },
      replace: true,
    },
  });

export const closeOnboardingPage = () =>
  cy.request({
    method: 'PUT',
    url: '/api/users/dashboard_settings',
    headers: { 'Content-Type': 'application/json' },
    body: {
      dashboardName: 'support',
      settingsKey: 'customer_board_page_settings',
      settingsSubKey: 'is_onboarding_done',
      settingsValue: true,
      replace: true,
    },
  });

export const removeExistingList = () =>
  cy.request({
    method: 'PUT',
    url: '/api/users/dashboard_settings',
    headers: { 'Content-Type': 'application/json' },
    body: {
      dashboardName: 'support',
      settingsKey: 'customer_board_page_settings',
      settingsSubKey: 'lists',
      settingsValue: {},
      replace: true,
    },
  });

export const resetOnboarding = () =>
  cy.request({
    method: 'PUT',
    url: '/api/users/dashboard_settings',
    headers: { 'Content-Type': 'application/json' },
    body: {
      dashboardName: 'support',
      settingsKey: 'customer_board_page_settings',
      settingsSubKey: 'is_onboarding_done',
      settingsValue: false,
      replace: true,
    },
  });
