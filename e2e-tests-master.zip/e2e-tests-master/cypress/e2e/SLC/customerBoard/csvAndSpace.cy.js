import path from 'path';
import { closeOnboardingPage, setToStandardList } from './support';
import { urlHelpers } from '../../../utils';
import { customerBoardPage } from '../../../pages';

const randId = () => Cypress._.random(0, 1e6);

beforeEach(() => {
  cy.loginByApi();
  closeOnboardingPage();
  setToStandardList();
  cy.visit(urlHelpers.customerBoard);
});

describe('Customer Board Page - CSV download, Multiple list added, Space not accepting functionality checks', () => {
  it('C83: Space not accepting in the list name', { tags: 'Customer Board' }, () => {
    /*
        Space not accepting in the list name_check:
        Test steps:
        1. Open the customer backlog page
        2. Click on 'create custom list'
        3. In the name text enter area enter name with includes some spaces
        4. After list created, list tile shows with only one space included
        */

    customerBoardPage.createNewListButton().click();

    customerBoardPage.createListEscalationPredictionLabelCheckbox().click({ force: true });
    customerBoardPage.createListTitleNameInput().click().clear().type('test                      1');
    customerBoardPage.createListAddButton().click();

    customerBoardPage.listTitleNameLabel().eq(0).invoke('text').should('include', '');
  });
  it('C80: Multiple list is getting added in the list', { tags: 'Customer Board' }, () => {
    /*
      Multiple list creation flow:
      Test steps:
      1. Open the customer backlog page
      2. click on 'create custom list' with multiple list options
      3. Completed the case list creation flow successfully
      */

    customerBoardPage.createNewListButton().click();

    customerBoardPage.createListCaseVolumeLabelCheckbox().click({ force: true }); //

    customerBoardPage.createListCaseBacklogLabelCheckbox().click({ force: true });

    customerBoardPage.createListNewIdLabelCheckbox().click({ force: true });

    customerBoardPage.createListAddButton().click();

    customerBoardPage.listTitleNameLabel().eq(0).invoke('text').should('include', 'Customers ranked by case volume');
    customerBoardPage.listTitleNameLabel().eq(1).invoke('text').should('include', 'Customers ranked by case backlog');
    customerBoardPage.listTitleNameLabel().eq(2).invoke('text').should('include', 'New Customer Accounts');
  });

  it("C2160: CSV is getting downloaded after list's name change", { tags: 'Customer Board' }, () => {
    /*
        CSV_is_getting_downloaded_after_list's_name_change_check:
        Test steps:
        1. Open the customer backlog page
        2. Click on 'create custom list'
        3. After list created, edit the ame of the list
        4. Export CSV sucessfully
        */

    const date = new Date();

    const day = `0${date.getDate()}`.slice(-2);
    const month = `0${date.getMonth() + 1}`.slice(-2);
    const year = date.getFullYear();

    const currentDate = `${year}-${month}-${day}`;

    const caseName = `CypressTest_${randId()}`;

    const expectedFileName = `${caseName}-${currentDate}.csv`;
    const downloadsFolder = Cypress.config('downloadsFolder');

    customerBoardPage.threeDotMenuDropdown().eq(0).click({ force: true });
    customerBoardPage.editListButton().eq(0).should('be.visible').click({ force: true });
    customerBoardPage.createListTitleNameInput().should('be.visible').click().clear().type(caseName);
    customerBoardPage.editListApplyButton().click();

    customerBoardPage.threeDotMenuDropdown().eq(0).click();
    customerBoardPage.downloadCSVListButton().eq(0).should('be.visible').click();

    cy.readFile(path.join(downloadsFolder, expectedFileName)).should('exist');
  });
});
