import { closeOnboardingPage, setToStandardList } from './support';
import { urlHelpers } from '../../../utils';
import { customerBoardPage, navBar } from '../../../pages';

beforeEach(() => {
  cy.loginByApi();
  closeOnboardingPage();
  setToStandardList();
  cy.visit(urlHelpers.customerBoard);
});

describe('Customer Board Smoke Tests', () => {
  // Smoke & Sanity C2196
  it('C2196:Test customer page loaded', { tags: 'Customer Board' }, () => {
    navBar.customerBoard().should('be.visible').click();
    // Verify the Customer board page is displaying
    customerBoardPage.createNewListButton().should('be.visible');
    // Verify the Customer board title is displaying
    customerBoardPage.listTitleNameLabel().should('exist');
  });
});
