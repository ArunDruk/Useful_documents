import { setToStandardList } from './support';
import { urlHelpers } from '../../../utils';
import { customerBoardPage } from '../../../pages';

describe('Customer Board - Default list name', () => {
  beforeEach(() => {
    cy.loginByApi();
    setToStandardList();

    cy.visit(urlHelpers.customerBoard);
  });

  afterEach(() => setToStandardList());

  /*
   * Open the customer board page
   * Click 'Create New List' button
   * Create a list without entering/modifying the name field
   *
   * Verify a new list is created with a default name
   */
  it('C82: List has a default name when no name is provided', { tags: 'Customer Board' }, () => {
    customerBoardPage.createNewListButton().click();
    customerBoardPage.createListEscalationPredictionLabelCheckbox().click({ force: true });
    customerBoardPage
      .createListTitleNameInput()
      .invoke('attr', 'value')
      .then((expectedListName) => {
        customerBoardPage.createListAddButton().click();

        customerBoardPage.listTitleNameLabel().first().should('have.text', expectedListName);
      });
  });

  /*
   * Click the 'Create New List' button
   * Click the 'Customers with production issues' checkbox
   * Select 'Last 6 months' in the time period dropdown
   * Open the customer fields filter
   * Select 'Bad' in the Health Score section
   * Apply the filter and create the list without entering/modifying the name field
   *
   * Verify a list is created with the default name and the selected time period
   */
  it('C90: should create list with default name on configuring time period & customer fields', { tags: ['Customer Board', 'staging'] }, () => {
    customerBoardPage.createNewListButton().click();
    customerBoardPage.createListProductionIssueLabelCheckbox().click({ force: true });
    customerBoardPage
      .createListTitleNameInput()
      .invoke('attr', 'value')
      .then((expectedListName) => {
        customerBoardPage.createListPopupTimePeriodDropdown().click();
        customerBoardPage.customerBoardTimePeriodSixMonthLabel().click();

        customerBoardPage.createListPopupCustomerFieldDropdown().click();
        customerBoardPage.editListOptionModalTitle().contains('Health Score').click();
        customerBoardPage.editListOptionModalList().contains('Bad').click();
        customerBoardPage.editListOptionModalTitle().parent().should('contain.text', 'Selected: Bad');

        customerBoardPage.editListOptionFilterButton().click();
        customerBoardPage.createListAddButton().click();

        customerBoardPage.listTitleNameLabel().first().should('have.text', expectedListName);
        customerBoardPage
          .listTitleNameLabel()
          .contains(expectedListName)
          .parents('[data-list]')
          .within(() => {
            customerBoardPage.customerBoardTimePeriodDropDown().should('be.visible').and('contain.text', 'Last 6 months');
          });
      });
  });
});
