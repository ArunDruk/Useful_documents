import { removeExistingList, resetOnboarding } from './support';
import { urlHelpers } from '../../../utils';
import { customerBoardPage } from '../../../pages';

describe('Verifying Standard list, Time period functionality in customer board list', () => {
  beforeEach(() => {
    cy.loginByApi();
    removeExistingList();
    resetOnboarding();
    cy.visit(urlHelpers.customerBoard);
    customerBoardPage.welcomePageDefaultListButton().click();
  });
  it("C77: Default list gets created after selecting 'Standard list'", { tags: 'Customer Board' }, () => {
    /*
    Default list gets created after selecting 'Standard list':
    Test steps:
    1. Open the customer backlog page
    2. Click on 'Standard list' in the onboarding page
    3. Page will show the default 7 lists
    4. Check the titles of the each list after created
    */

    // These API calls & url visit not advised to move to beforeEach.Since this will affect the next case
    // Added to the beforeEach if its not failing will remove this on Oct-16
    // removeExistingList();
    // resetOnboarding();
    // cy.visit(urlHelpers.customerBoard);
    // customerBoardPage.welcomePageDefaultListButton().click();
    customerBoardPage.listTitleNameLabel().eq(0).invoke('text').should('include', 'Customers ranked by Health Score');
    customerBoardPage.listTitleNameLabel().eq(1).invoke('text').should('include', 'Customers with Escalations');
    customerBoardPage.listTitleNameLabel().eq(2).invoke('text').should('include', 'Customers with likely to escalate cases');
    customerBoardPage.listTitleNameLabel().eq(3).invoke('text').should('include', 'Customers with production issues');
    customerBoardPage.listTitleNameLabel().eq(4).invoke('text').should('include', 'Customers with critical issues');
    customerBoardPage.listTitleNameLabel().eq(5).invoke('text').should('include', 'Customers ranked by case volume');
    customerBoardPage.listTitleNameLabel().eq(6).invoke('text').should('include', 'Customers with Escalation requests');
  });

  it('C2202: time period in list functionality check', { tags: 'Customer Board' }, () => {
    /*
    Time period functionality checks:
    Test steps:
    1. Open the customer backlog page
    2. Click on Showing customers of 'Last 6 months','All time'
    3. Now the list will show the list based on the option selected
    4. Check the text shown in the Showing customers of dropdown
    */
    cy.visit(urlHelpers.customerBoard);
    customerBoardPage.customerBoardTimePeriodDropDown().eq(0).click();
    customerBoardPage.customerBoardTimePeriodSixMonthLabel().click();
    customerBoardPage.customerBoardTimePeriodDropDown().eq(0).should('contain.text', 'Last 6 months');
    customerBoardPage.customerBoardTimePeriodDropDown().eq(0).click();
    customerBoardPage.customerBoardTimePeriodAllTimeLabel().click();
    customerBoardPage.customerBoardTimePeriodDropDown().eq(0).should('contain.text', 'All time');
  });
});
