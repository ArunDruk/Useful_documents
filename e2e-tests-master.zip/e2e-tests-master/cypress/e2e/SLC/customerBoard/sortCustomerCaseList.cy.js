import { urlHelpers } from '../../../utils';
import { customerBoardPage, apiHelpers } from '../../../pages';

describe('Verifying sort in customer board list', () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.closeOnboardingPageCustomerBoard();
    apiHelpers.setToStandardListCustomerBoard();
    cy.visit(urlHelpers.customerBoard);
  });

  /**
   * Open the Customer board  page.
   * Click on three dot option.
   * Click the change switch sort direction.
   * Check that sort is happening in the respective list.
   */
  it('C2199: Test switch sort direction', { tags: ['Customer Board', 'staging'] }, () => {
    customerBoardPage.customerBoardSwitchSortOrder();
  });
});
