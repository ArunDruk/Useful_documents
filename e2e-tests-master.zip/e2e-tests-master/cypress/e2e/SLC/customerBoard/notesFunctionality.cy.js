import { closeOnboardingPage, setToStandardList } from './support';
import { urlHelpers } from '../../../utils';
import { customerBoardPage } from '../../../pages';

beforeEach(() => {
  cy.loginByApi();
  cy.visit(urlHelpers.customerBoard);
  closeOnboardingPage();
  setToStandardList();
});

describe('Customer Board page - Add, Edit and Delete Notes functionality checks in the lists', () => {
  it('C2203: Add notes in the existing list ', { tags: 'Customer Board' }, () => {
    /*
        Add, Edit and Delete Notes functionality checks in the lists:
        Test steps:
        1. Open the customer backlog page
        2. Click on 'Add/Edit customer notes' button
        3. Create a note and save it and checks functionality
        4. Edit a note and save it and checks functionality
        5. Delete a note and save it and checks functionality
      */

    customerBoardPage.createNewListButton().click();
    customerBoardPage.createListEscalationPredictionLabelCheckbox().click({ force: true });
    customerBoardPage.createListAddButton().click();

    customerBoardPage.customerNotesContainer().eq(0).click({ force: true });

    customerBoardPage.customerNotesAddNewNotesButton().click({ force: true });
    customerBoardPage.customerNotesInput().click({ force: true }).clear().type('test new added 1');
    customerBoardPage.customerNotesAddButton().click({ force: true });

    // since data-testid is dynamic using ^ to indicate that a string must start with the specified string
    customerBoardPage.customerNotesTitle().eq(0).invoke('text').should('eq', 'test new added 1');

    customerBoardPage.customerNotesCloseIcon().click({ force: true });
  });

  it('C2204: Edit notes in the existing list', { tags: 'Customer Board' }, () => {
    customerBoardPage.createNewListButton().click();
    customerBoardPage.createListEscalationPredictionLabelCheckbox().click({ force: true });
    customerBoardPage.createListAddButton().click();
    customerBoardPage.customerNotesContainer().eq(0).click({ force: true });
    // cy.getByTestId('support-hub.customer-notes-flag').eq(0).click();
    customerBoardPage.customerNotesEditNoteIcon().eq(0).click();
    customerBoardPage.customerNotesEditNoteInput().click().clear().type('test new edited 1');
    customerBoardPage.customerNotesEditNoteSaveButton().click();

    // since data-testid is dynamic using ^ to indicate that a string must start with the specified string
    customerBoardPage.customerNotesTitle().eq(0).invoke('text').should('eq', 'test new edited 1');

    customerBoardPage.customerNotesCloseIcon().click();
  });

  it('C2205: Delete notes in the existing list', { tags: 'Customer Board' }, () => {
    customerBoardPage.createNewListButton().click();
    customerBoardPage.createListEscalationPredictionLabelCheckbox().click({ force: true });
    customerBoardPage.createListAddButton().click();
    customerBoardPage.customerNotesContainer().eq(0).click({ force: true });
    customerBoardPage.customerNotesDeleteNoteIcon().eq(0).click();

    // since data-testid is dynamic using ^ to indicate that a string must start with the specified string
    customerBoardPage.customerNotesTitle().eq(0).invoke('text').should('not.eq', 'test new edited 1');

    customerBoardPage.customerNotesCloseIcon().click();
  });
});
