import { closeOnboardingPage, setToStandardList } from './support';
import { urlHelpers } from '../../../utils';
import { customerBoardPage } from '../../../pages';

beforeEach(() => {
  cy.loginByApi();
  closeOnboardingPage();
  setToStandardList();
  cy.visit(urlHelpers.customerBoard);
});

describe('Customer Board page - Details and scrolling functionality check in the lists', () => {
  it('C6914: Scrolling behavior check', { tags: 'Customer Board' }, () => {
    /*
    Details_and_scroll_behavior_check:
    Test steps:
    1. Open the customer backlog page
    2. Click on 'create custom list'
    3. Complete the case creation flow and created few case lists
    4. Check details of the list(# of open cases, # of escalated cases, # of likely to be escalated cases)
        and check page loaded properly or not and check scroll functionality.
    */
    customerBoardPage.createNewListButton().click();
    customerBoardPage.createListEscalationPredictionLabelCheckbox().click({ force: true });
    customerBoardPage.createListProductionIssueLabelCheckbox().click({ force: true });
    customerBoardPage.createListCriticalIssueLabelCheckbox().click({ force: true });
    customerBoardPage.createListCaseVolumeLabelCheckbox().click({ force: true });
    customerBoardPage.createListCaseBacklogLabelCheckbox().click({ force: true });
    customerBoardPage.createListNewIdLabelCheckbox().click({ force: true });
    customerBoardPage.createListAddButton().click();

    customerBoardPage.appContentContainer().scrollTo('bottom');
    customerBoardPage.appContentContainer().scrollTo('top');
    customerBoardPage.appContentContainer().scrollTo('bottom');

    customerBoardPage.createNewListButton().should('have.text', 'Create New List');

    customerBoardPage.expandButton().should('be.visible');
    customerBoardPage.appContentContainer().scrollTo('top');

    customerBoardPage.listTitleNameLabel().eq(0).invoke('text').should('include', 'Customers with likely to escalate cases');
    customerBoardPage.listTitleNameLabel().eq(1).invoke('text').should('include', 'Customers with production issues');
    customerBoardPage.listTitleNameLabel().eq(2).invoke('text').should('include', 'Customers with critical issues');
    customerBoardPage.listTitleNameLabel().eq(3).invoke('text').should('include', 'Customers ranked by case volume');
    customerBoardPage.listTitleNameLabel().eq(4).invoke('text').should('include', 'Customers ranked by case backlog');
    customerBoardPage.listTitleNameLabel().eq(5).invoke('text').should('include', 'New Customer Accounts');
  });

  it('C97: Details of the list check', { tags: 'Customer Board' }, () => {
    customerBoardPage
      .customerBoardCaseListStats()
      .eq(0)
      .invoke('text')

      .should('match', /\d{1,4} Open Cases/)
      .should('match', /\d{1,4} Escalated/)
      .should('match', /\d{1,4} likely to escalate/);

    customerBoardPage
      .customerBoardCaseListLabel()
      .eq(0)
      .invoke('text')

      .should('match', /\d{1,4} "Churn Risk" {2}|| "New"/);
  });
});
