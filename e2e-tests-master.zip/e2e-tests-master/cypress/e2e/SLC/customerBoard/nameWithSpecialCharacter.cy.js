import { removeExistingList, setToStandardList } from './support';
import { urlHelpers } from '../../../utils';
import { customerBoardPage } from '../../../pages';

describe('Customer Board - List name with special char', () => {
  beforeEach(() => {
    cy.loginByApi();
    removeExistingList();

    cy.visit(urlHelpers.customerBoard);
  });

  afterEach(() => setToStandardList());

  it('C84: should create list with special character names', { tags: 'Customer Board' }, () => {
    const listNameWithSpecialChar = '`~!@#$%^&*wer()-_=+[]|;:\'",<.>/?';

    customerBoardPage.welcomePageCreateCustomListButton().click();
    customerBoardPage.createListProductionIssueLabelCheckbox().click({ force: true });
    customerBoardPage.createListTitleNameInput().clear().type(listNameWithSpecialChar);
    customerBoardPage.createListAddButton().click();

    customerBoardPage.listTitleNameLabel().first().should('have.text', listNameWithSpecialChar);
  });

  it('C88: should create list with special character names on configuring time period & customer fields', { tags: 'Customer Board' }, () => {
    const listNameWithSpecialChar = '`~!@#$%^&*wer()-_=+[]|;:\'",<.>/?';

    customerBoardPage.welcomePageCreateCustomListButton().click();
    customerBoardPage.createListProductionIssueLabelCheckbox().click({ force: true });
    customerBoardPage.createListTitleNameInput().clear().type(listNameWithSpecialChar);

    customerBoardPage.createListPopupTimePeriodDropdown().click();
    customerBoardPage.customerBoardTimePeriodSixMonthLabel().click();

    customerBoardPage.createListPopupCustomerFieldDropdown().click();
    customerBoardPage.editListOptionModalTitle().contains('Health Score').click();
    customerBoardPage.editListOptionModalList().contains('Bad').click();
    customerBoardPage.editListOptionModalTitle().parent().should('contain.text', 'Selected: Bad');

    customerBoardPage.editListOptionFilterButton().click();
    customerBoardPage.createListAddButton().click();

    customerBoardPage.listTitleNameLabel().first().should('have.text', listNameWithSpecialChar);
    customerBoardPage
      .listTitleNameLabel()
      .contains(listNameWithSpecialChar)
      .parents('[data-list]')
      .within(() => {
        customerBoardPage.customerBoardTimePeriodDropDown().should('be.visible').and('contain.text', 'Last 6 months');
      });
  });

  it('C89: should not allow duplicates when creating lists', { tags: ['Customer Board', 'staging'] }, () => {
    customerBoardPage.welcomePageCreateCustomListButton().click();
    customerBoardPage.createListEscalationPredictionLabelCheckbox().click({ force: true });
    customerBoardPage.createListAddButton().click();

    customerBoardPage.createNewListButton().click();
    customerBoardPage.createListEscalationPredictionLabelCheckbox().click({ force: true });
    customerBoardPage.createListAddButton().click();

    customerBoardPage
      .listTitleNameLabel()
      .first()
      .invoke('text')
      .then((newListTitle) => customerBoardPage.listTitleNameLabel().eq(1).should('not.equal', newListTitle));

    customerBoardPage.threeDotMenuDropdown().first().click();
    customerBoardPage.editListButton().first().click();

    customerBoardPage.createListTitleNameInput().type('{backspace}');
    cy.contains('This name is taken').should('be.visible');
  });
});
