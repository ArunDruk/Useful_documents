import { removeExistingList, resetOnboarding } from './support';
import { urlHelpers } from '../../../utils';
import { customerBoardPage } from '../../../pages';

describe('Customer Board Page - Case create & Delete functionality check', () => {
  beforeEach(() => {
    cy.loginByApi();
  });

  it('C79:  New case creation flow', { tags: 'Customer Board' }, () => {
    /*
     New case list creation functionality check:
     Test steps:
     1. Open the customer board page.
     2. Click 'Create New List' option.
     3. Completed the case list creation flow successfully.
     4. Delete a created list and check the functionality.
     */

    // These API calls & url visit not advised to move to beforeEach.Since this will affect the next case.
    removeExistingList();
    resetOnboarding();
    cy.visit(urlHelpers.customerBoard);
    customerBoardPage.welcomePageCreateCustomListButton().click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(500);
    customerBoardPage.createListEscalationPredictionLabelCheckbox().click({ force: true });
    customerBoardPage.createListAddButton().click();
    customerBoardPage.listTitleNameLabel().eq(0).invoke('text').should('include', 'Customers with likely to escalate cases');
  });

  it('C2197: Delete a list functionality check', { tags: 'Customer Board' }, () => {
    /*
     Delete list functionality check:
     Test steps:
     1. Open the customer backlog page
     2. Click on three dot menu option.
     3. Click delete list button.
     4. Click the delete button in delete pop up window.
     */
    cy.visit(urlHelpers.customerBoard);
    customerBoardPage.threeDotMenuDropdown().eq(0).click();
    customerBoardPage.deleteListButton().eq(0).should('be.visible').click();
    customerBoardPage.deleteListPopupButton().should('be.visible').click();
    customerBoardPage.welcomePageTitle().invoke('text').should('include', 'Top Customers');
  });
});
