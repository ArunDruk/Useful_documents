import { urlHelpers } from '../../../utils';
import { pluginErrorPopup } from '../../../pages';

beforeEach(function beforeEachHook() {
  // Ticket Update test, hence skipped
  // if (!Cypress.config().baseUrl.includes('foundry')) this.skip();

  cy.intercept('search/virtual_groups/_search*').as('search');
  cy.intercept('POST', 'api/v0/support/case_owners/*').as('waitForAgentAssignment');

  cy.loginByApi();
  cy.visit(urlHelpers.caseAssignment);
});

it('C815: should successfully assign a case to an agent', { tags: 'ICA' }, () => {
  cy.slcHelpers.getAgentDetails().then((agentDetails) => {
    const agentDetail = Cypress._.sample(agentDetails);
    const agentName = agentDetail.sl_name;
    cy.getByTestId('caseAssignment-sideListTab-unassigned-tab').click();

    cy.getByTestId('caseAssignmentPage-caseAssignmentTab-unassigned-sortTrigger').click();
    cy.getByTestId('caseAssignmentPage-caseAssignmentTab-sortOptions-created_at').click();

    cy.getByTestId('supportHub-caseOwnerSelect-caseOwnerName').click();
    cy.getByTestId('supportHub-caseOwnerSelect-caseAssignmentListPopoverBeta-search').click();
    cy.getByTestId('supportHub-caseOwnerSelect-searchInput').type(agentName);
    cy.wait('@search');

    cy.getByTestId('supportHub-caseOwnerSelect-ica-itemCard-assignButton').first().invoke('show').should('be.visible').click({ force: true });
    cy.wait('@waitForAgentAssignment').then(({ response }) => {
      if (response.statusCode !== 200) {
        pluginErrorPopup.maybeLaterButton().should('be.visible');
      } else {
        cy.getByTestId('supportHub-caseOwnerSelect-caseOwnerName').should('not.have.text', 'Unassigned');
        cy.getByTestId('supportHub-caseOwnerSelect-ownerContainer').should('not.contain.text', 'Unassigned');
      }
    });
  });
});
