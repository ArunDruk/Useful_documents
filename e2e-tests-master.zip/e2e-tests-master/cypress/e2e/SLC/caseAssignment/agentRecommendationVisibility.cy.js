import { getQueueIds } from './support';
import { urlHelpers } from '../../../utils';

const basePredicate = [
  { column: 'sl_is_closed', op: '=', value: 'false' },
  { column: 'sl_account_id', op: '<>', value: 'null' },
  { column: 'sl_requester_id', op: '<>', value: 'null' },
];

const getOpenCaseIdsByAssignee = (assigneeIds) =>
  cy.slcHelpers
    .getCaseDetails({
      predicates: [{ column: 'sl_assignee_id', op: 'in', value: assigneeIds.join('|') }, ...basePredicate],
    })
    .then(({ body }) => body.map(({ id }) => id));

const getUnassignedOpenCaseIds = () =>
  cy.slcHelpers
    .getCaseDetails({
      predicates: [{ column: 'sl_assignee_id', op: 'is_null' }, ...basePredicate],
    })
    .then(({ body }) => body.map(({ id }) => id));

// TODO: Pointing the baseUrl to foundry due to SLC-33550, remove this once the ticket is fixed
describe('ICA - Agent Recommendations', () => {
  beforeEach(function beforeEachHook() {
    cy.intercept('POST', 'api/v2/ticket/assignment/recommendation').as('recommendations');

    cy.loginByApi();
  });

  // ML model for ICA has to run in qa-automation instance. This is tracked in SLC-33550
  it("C6896: should show recommendations for unassigned ticket that's in a queue", { tags: 'ICA' }, () => {
    getQueueIds().then((queueIds) =>
      getOpenCaseIdsByAssignee(queueIds).then((unassignedCaseIds) => {
        cy.visit(urlHelpers.supportHubCasePage(unassignedCaseIds[0]));

        cy.getByTestId('supportHub-caseOwnerSelect-caseOwnerName').click();
        cy.wait('@recommendations', { responseTimeout: 45000 });

        cy.getByTestId('supportHub-caseOwnerSelect-ica-queueDropdownTrigger').should('not.have.text', 'Select a queue ');
        cy.getByTestId('supportHub-caseOwnerSelect-optionsItem').should('be.visible').should('have.length.at.least', 1);
      })
    );
  });

  // ML model for ICA has to run in qa-automation instance. This is tracked in  SLC-33550
  it('C6897: should show recommendations for assigned ticket', { tags: 'ICA' }, () => {
    cy.slcHelpers.getAgentIds(5).then((agentIds) =>
      getOpenCaseIdsByAssignee(agentIds).then((assignedCaseIds) => {
        cy.visit(urlHelpers.supportHubCasePage(assignedCaseIds[0]));

        cy.getByTestId('supportHub-caseOwnerSelect-caseOwnerName').click();
        cy.wait('@recommendations', { responseTimeout: 45000 });

        // TODO: text doesn't have to be "Select a queue" if case is assigned to a queue
        // we should either account for it, or test it only on cases assigned to actual agents
        // cy.getByTestId('supportHub-caseOwnerSelect-ica-queueDropdownTrigger').should('have.text', 'Select a queue ');
        cy.getByTestId('supportHub-caseOwnerSelect-optionsItem').should('be.visible').should('have.length.at.least', 1);
      })
    );
  });

  // ML model for ICA has to run in qa-automation instance. This is tracked in  SLC-33550
  it("C6898: should show recommendations for unassigned ticket that's not in a queue", { tags: 'ICA' }, () => {
    getUnassignedOpenCaseIds().then((unassignedCaseIds) => {
      cy.visit(urlHelpers.supportHubCasePage(unassignedCaseIds[0]));

      cy.getByTestId('supportHub-caseOwnerSelect-caseOwnerName').click();
      cy.wait('@recommendations', { responseTimeout: 45000 });

      cy.getByTestId('supportHub-caseOwnerSelect-ica-queueDropdownTrigger').should('have.text', 'Select a queue ');
      cy.getByTestId('supportHub-caseOwnerSelect-optionsItem').should('be.visible').should('have.length.at.least', 1);
    });
  });
});
