import { urlHelpers } from '../../../utils';
import { agents, apiHelpers, assignmentQueues, customerFavorites, globalFilters } from '../../../pages';

describe('ICA - Virtual Queues Create', { tags: ['ICA', 'staging', '@VirtualQueues'] }, () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.assignmentQueues);
    cy.waitForLoaders();

    // removing existing virtual queues to avoid issues while locating tab headers
    assignmentQueues.removeVirtualQueues();
  });

  /*
   * TODO Deprecate OpsSystem Case Field Option , Remove on Sept 30.
   *
   * Visit the Assignment Queues module
   * Click on the Add Virtual Queue button in the bottom of the page
   * Click on Create Virtual Queue Button
   * Create a virtual queue without filters
   */
  it('C9346: Creation of Virtual Queue with no filters applied', () => {
    assignmentQueues.addVirtualQueueButton().click();
    assignmentQueues.caseFieldPriorityCollapseButton().scrollIntoView().should('be.visible');
    assignmentQueues.createVirtualQueueCancelButton().should('be.visible');
    assignmentQueues.saveVirtualQueueButton().click();
    assignmentQueues.assignmentQueueNameList().last().should('have.text', 'Virtual Queue');
    assignmentQueues.addAgentButtonByQueueName('Virtual Queue').should('exist');
    assignmentQueues.queueFilterTabList().should('contain', 'Case Fields').and('contain', 'Customers').and('contain', 'Agents');
    assignmentQueues.autoAssignDropdownByQueueName('Virtual Queue').should('have.text', 'Do nothing');
  });

  /*
   * TODO Deprecate OpsSystem Case Field Option , Remove on Sept 30.
   *
   * Visit the Assignment Queues module
   * Click on the Add Virtual Queue button in the bottom of the page
   * Click on Create Virtual Queue Button
   * Create a virtual queue with Case Fields filters
   */
  it('C9355: Add a virtual Queue with Case Field filters Selected', () => {
    assignmentQueues.addVirtualQueueButton().click();
    cy.waitForLoaders();
    // assignmentQueues.caseFieldOpsSysCollapseButton().click();
    // assignmentQueues.caseFieldOpsSysMacOSXJaguarPill().click();
    // assignmentQueues.caseFieldOpsSysUbuntuSaucySalamanderPill().click();
    // assignmentQueues.caseFieldOpsSysUbuntuOneiricOcelotPill().click();
    assignmentQueues.caseFieldPriorityCollapseButton().scrollIntoView().click();
    assignmentQueues.caseFieldPriorityHighPill().click();
    assignmentQueues.caseFieldSeverityCollapseButton().click();
    assignmentQueues.caseFieldSeverityHighPill().click();
    assignmentQueues.saveVirtualQueueButton().click();
    assignmentQueues.assignmentQueueNameList().last().should('have.text', 'Virtual Queue');
    assignmentQueues.addAgentButtonByQueueName('Virtual Queue').should('exist');
    assignmentQueues.queueFilterTabList().should('contain', 'Case Fields').and('contain', 'Customers').and('contain', 'Agents');
    // assignmentQueues.caseFieldOpsSysMacOSXJaguarSelectedPill().should('exist');
    // assignmentQueues.caseFieldOpsSysUbuntuSaucySalamanderSelectedPill().should('exist');
    // assignmentQueues.caseFieldOpsSysUbuntuOneiricOcelotSelectedPill().should('exist');
    assignmentQueues.caseFieldPriorityHighSelectedPill().should('exist');
    assignmentQueues.caseFieldSeverityHighSelectedPill().should('exist');
    assignmentQueues.autoAssignDropdownByQueueName('Virtual Queue').should('have.text', 'Do nothing');
  });

  /*
   * TODO Deprecate OpsSystem Case Field Option , Remove on Sept 30.
   *
   * Visit the Assignment Queues module
   * Click on the Add Virtual Queue button in the bottom of the page
   * Click on Create Virtual Queue Button
   * Create a virtual queue with Customer filters
   */
  it('C9364: Add a virtual Queue with Customer filters Selected', () => {
    cy.slcHelpers.getCustomerDetails().then((customerDetails) => {
      const customerDetail = Cypress._.sample(customerDetails);

      assignmentQueues.addVirtualQueueButton().click();
      assignmentQueues.caseFieldPriorityCollapseButton().scrollIntoView().should('be.visible');
      // assignmentQueues.caseFieldOpsSysCollapseButton().should('be.visible');
      assignmentQueues.queueFilterTabList().eq(1).click();
      assignmentQueues.virtualQueueFilterSearchTextField().type(customerDetail.name);
      assignmentQueues.virtualQueueFilterCheckboxList().first().click({ force: true });
      assignmentQueues.saveVirtualQueueButton().click();
      assignmentQueues.assignmentQueueNameList().last().should('have.text', 'Virtual Queue');
      assignmentQueues.addAgentButtonByQueueName('Virtual Queue').should('exist');
      assignmentQueues.queueFilterTabList().should('contain', 'Case Fields').and('contain', 'Customers').and('contain', 'Agents');
      assignmentQueues.queueFilterTabList().eq(1).click();
      assignmentQueues.virtualQueueFilterLabel().should('have.text', customerDetail.name);
      assignmentQueues.autoAssignDropdownByQueueName('Virtual Queue').should('have.text', 'Do nothing');
    });
  });

  /*
   * TODO Deprecate OpsSystem Case Field Option , Remove on Sept 30.
   *
   * Visit the Assignment Queues module
   * Click on the Add Virtual Queue button in the bottom of the page
   * Click on Create Virtual Queue Button
   * Create a virtual queue with Agent filters
   */
  it('C9365: Add a virtual Queue with Agent filters Selected', () => {
    // Using static data as due to SLC-34290, a new newly created virtual queue cannot always be found
    const vtName = 'C9365 VQ DO NOT DELETE';

    assignmentQueues.addVirtualQueueButton().click();
    assignmentQueues.caseFieldPriorityCollapseButton().scrollIntoView().should('be.visible');
    // assignmentQueues.caseFieldOpsSysCollapseButton().should('be.visible');
    assignmentQueues.queueFilterTabList().eq(2).click();
    assignmentQueues.virtualQueueFilterSearchTextField().type(vtName);
    assignmentQueues.virtualQueueFilterCheckboxList().first().click({ force: true });
    assignmentQueues.saveVirtualQueueButton().click();
    assignmentQueues.assignmentQueueNameList().last().should('have.text', 'Virtual Queue');
    assignmentQueues.addAgentButtonByQueueName('Virtual Queue').should('exist');
    assignmentQueues.queueFilterTabList().should('contain', 'Case Fields').and('contain', 'Customers').and('contain', 'Agents');
    assignmentQueues.queueFilterTabList().eq(2).click();
    assignmentQueues.virtualQueueFilterLabel().should('have.text', vtName);
    assignmentQueues.autoAssignDropdownByQueueName('Virtual Queue').should('have.text', 'Do nothing');
  });
});

describe('ICA - Virtual Queues Edit', { tags: ['ICA', 'staging', '@VirtualQueues'] }, () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.assignmentQueues);
    cy.waitForLoaders();

    // removing existing virtual queues to avoid issues while locating tab headers
    assignmentQueues.removeVirtualQueues();
  });

  /*
   * TODO Deprecate OpsSystem Case Field Option , Remove on Sept 30.
   *
   * Visit the Assignment Queues module
   * Click on the Add Virtual Queue button in the bottom of the page
   * Click on Create Virtual Queue Button
   * Update the name of the newly created VQ
   */
  it('C9376: Virtual Queue - Editing the name of VQ', () => {
    assignmentQueues.addVirtualQueueButton().click();
    // assignmentQueues.caseFieldOpsSysCollapseButton().should('be.visible');
    assignmentQueues.caseFieldPriorityCollapseButton().scrollIntoView().should('be.visible');
    assignmentQueues.createVirtualQueueCancelButton().should('be.visible');
    assignmentQueues.saveVirtualQueueButton().click();
    assignmentQueues.assignmentQueueNameList().last().should('have.text', 'Virtual Queue');
    assignmentQueues.assignmentQueueNameEditButton().last().should('be.visible').click();
    assignmentQueues.editQueueNameInputField().clear().type('VQ1 {enter}');
    assignmentQueues.assignmentQueueNameList().last().should('have.text', 'VQ1');
    assignmentQueues.assignmentQueueNameEditButton().last().should('be.visible');
  });

  /*
   * TODO Deprecate OpsSystem Case Field Option , Remove on Sept 30.
   *
   * Visit the Assignment Queues module
   * Click on the Add Virtual Queue button in the bottom of the page
   * Click on Create Virtual Queue Button
   * Edit the virtual queue to add/remove Case Fields filters
   */
  it('C9393: VQ - Edit Case fields in a VQ', () => {
    assignmentQueues.addVirtualQueueButton().click();
    cy.waitForLoaders();
    // assignmentQueues.caseFieldOpsSysCollapseButton().click();
    // assignmentQueues.caseFieldOpsSysMacOSXJaguarPill().click();
    // assignmentQueues.caseFieldOpsSysUbuntuSaucySalamanderPill().click();
    // assignmentQueues.caseFieldOpsSysUbuntuOneiricOcelotPill().click();
    assignmentQueues.caseFieldPriorityCollapseButton().scrollIntoView().click();
    assignmentQueues.caseFieldPriorityHighPill().click();
    assignmentQueues.caseFieldSeverityCollapseButton().click();
    assignmentQueues.caseFieldSeverityHighPill().click();
    assignmentQueues.saveVirtualQueueButton().click();
    cy.waitForLoaders();
    assignmentQueues.assignmentQueueNameList().last().should('have.text', 'Virtual Queue');
    // assignmentQueues.caseFieldOpsSysMacOSXJaguarSelectedPill().should('exist');
    // assignmentQueues.caseFieldOpsSysUbuntuSaucySalamanderSelectedPill().should('exist');
    // assignmentQueues.caseFieldOpsSysUbuntuOneiricOcelotSelectedPill().should('exist');
    assignmentQueues.caseFieldPriorityHighSelectedPill().should('exist');
    assignmentQueues.caseFieldSeverityHighSelectedPill().should('exist');
    assignmentQueues.vqEditFilterButton('Virtual Queue').click();
    cy.waitForLoaders();
    // assignmentQueues.caseFieldOpsSysCollapseButton().click();
    // assignmentQueues.caseFieldOpsSysMacOSXJaguarPill().click();
    assignmentQueues.caseFieldPriorityCollapseButton().scrollIntoView().click();
    assignmentQueues.caseFieldPriorityHighPill().click();
    assignmentQueues.caseFieldSeverityCollapseButton().click();
    assignmentQueues.caseFieldSeverityHighPill().click();
    assignmentQueues.caseFieldSeverityMediumPill().click();
    assignmentQueues.saveVirtualQueueButton().click();
    // assignmentQueues.caseFieldOpsSysMacOSXJaguarSelectedPill().should('not.exist');
    // assignmentQueues.caseFieldOpsSysUbuntuSaucySalamanderSelectedPill().should('exist');
    // assignmentQueues.caseFieldOpsSysUbuntuOneiricOcelotSelectedPill().should('exist');
    assignmentQueues.caseFieldPriorityHighSelectedPill().should('exist');
    assignmentQueues.caseFieldSeverityHighSelectedPill().should('not.exist');
    assignmentQueues.caseFieldSeverityMediumSelectedPill().should('exist');
  });

  /*
   * TODO Deprecate OpsSystem Case Field Option , Remove on Sept 30.
   *
   * Visit the Assignment Queues module
   * Click on the Add Virtual Queue button in the bottom of the page
   * Click on Create Virtual Queue Button
   * Edit the virtual queue to add/remove Customer filters
   */
  it('C9394: VQ - Edit Customer filter in a VQ', () => {
    cy.slcHelpers.getCustomerDetails().then((customerDetails) => {
      const uniqueCustomers = Cypress._.uniqBy(customerDetails, (customer) => customer.name);
      const customerName = uniqueCustomers[0].name;
      const newCustomerName = uniqueCustomers[1].name;

      assignmentQueues.addVirtualQueueButton().click();
      // assignmentQueues.caseFieldOpsSysCollapseButton().should('be.visible');
      assignmentQueues.caseFieldPriorityCollapseButton().scrollIntoView().should('be.visible');
      assignmentQueues.queueFilterTabList().eq(1).click();
      assignmentQueues.virtualQueueFilterSearchTextField().type(customerName);
      assignmentQueues.virtualQueueFilterCheckboxList().first().click({ force: true });
      assignmentQueues.saveVirtualQueueButton().click();
      assignmentQueues.assignmentQueueNameList().last().should('have.text', 'Virtual Queue');
      assignmentQueues.queueFilterTabList().eq(1).click();
      assignmentQueues.virtualQueueFilterLabel().should('have.text', customerName);
      assignmentQueues.vqEditFilterButton('Virtual Queue').click();
      cy.waitForLoaders();
      // assignmentQueues.caseFieldOpsSysCollapseButton().should('be.visible');
      assignmentQueues.caseFieldPriorityCollapseButton().scrollIntoView().should('be.visible');

      assignmentQueues.queueFilterTabList().eq(4).should('be.visible').click();
      assignmentQueues.virtualQueueFilterSearchTextField().clear().type(customerName);
      cy.waitForLoaders();
      assignmentQueues.virtualQueueFilterCheckboxList().first().click({ force: true });
      assignmentQueues.virtualQueueFilterCheckboxList().first().invoke('attr', 'data-status').should('equal', 'unchecked');
      assignmentQueues.virtualQueueFilterSearchTextField().clear().type(newCustomerName);
      cy.waitForLoaders();
      assignmentQueues.virtualQueueFilterCheckboxList().first().click({ force: true });
      assignmentQueues.virtualQueueFilterCheckboxList().first().invoke('attr', 'data-status').should('equal', 'checked');
      assignmentQueues.saveVirtualQueueButton().click();
      assignmentQueues.assignmentQueueNameList().last().should('have.text', 'Virtual Queue');
      assignmentQueues.queueFilterTabList().eq(1).click();
      assignmentQueues.virtualQueueFilterLabel().should('have.text', newCustomerName);
    });
  });

  /*
   * TODO Deprecate OpsSystem Case Field Option , Remove on Sept 30.
   *
   * Visit the Assignment Queues module
   * Click on the Add Virtual Queue button in the bottom of the page
   * Click on Create Virtual Queue Button
   * Edit the virtual queue to add/remove Agent filters
   */
  it('C9397: VQ - Edit Agent filter in a VQ ', () => {
    // Using static data as due to SLC-34290, a new newly created virtual queue cannot always be found
    // this case will be modified once the elastic wrapper is implemented to use realtime data
    const vtName = 'C9365 VQ DO NOT DELETE';
    const vtNameUpdated = 'UPDATED DONT DELETE';

    assignmentQueues.addVirtualQueueButton().click();
    // assignmentQueues.caseFieldOpsSysCollapseButton().should('be.visible');
    assignmentQueues.caseFieldPriorityCollapseButton().scrollIntoView().should('be.visible');
    assignmentQueues.queueFilterTabList().eq(2).click();
    assignmentQueues.virtualQueueFilterSearchTextField().type(vtName);
    assignmentQueues.virtualQueueFilterCheckboxList().first().click({ force: true });
    assignmentQueues.saveVirtualQueueButton().click();
    assignmentQueues.assignmentQueueNameList().last().should('have.text', 'Virtual Queue');
    assignmentQueues.queueFilterTabList().eq(2).click();
    assignmentQueues.virtualQueueFilterLabel().should('have.text', vtName);
    assignmentQueues.vqEditFilterButton('Virtual Queue').click();
    cy.waitForLoaders();
    // assignmentQueues.caseFieldOpsSysCollapseButton().should('be.visible');
    assignmentQueues.caseFieldPriorityCollapseButton().scrollIntoView().should('be.visible');

    assignmentQueues.queueFilterTabList().eq(5).should('be.visible').click();
    assignmentQueues.virtualQueueFilterSearchTextField().type(vtName);
    assignmentQueues.virtualQueueFilterCheckboxList().first().click({ force: true });
    assignmentQueues.virtualQueueFilterCheckboxList().first().invoke('attr', 'data-status').should('equal', 'unchecked');
    assignmentQueues.virtualQueueFilterSearchTextField().clear().type(vtNameUpdated);
    cy.waitForLoaders();
    assignmentQueues.virtualQueueFilterCheckboxList().first().click({ force: true });
    assignmentQueues.virtualQueueFilterCheckboxList().first().invoke('attr', 'data-status').should('equal', 'checked');
    assignmentQueues.saveVirtualQueueButton().click();

    assignmentQueues.assignmentQueueNameList().last().should('have.text', 'Virtual Queue');
    assignmentQueues.queueFilterTabList().eq(2).click();
    assignmentQueues.virtualQueueFilterLabel().should('have.text', vtNameUpdated);
  });

  /*
   * TODO Deprecate OpsSystem Case Field Option , Remove on Sept 30.
   *
   * Visit the Assignment Queues module
   * Click on the Add Virtual Queue button in the bottom of the page
   * Click on Create Virtual Queue Button
   * Create a virtual queue without filters
   * Hide the virtual queue
   */
  it('C9378: VQ - Hide a Virtual Queue from Assignment Queue page', () => {
    assignmentQueues.addVirtualQueueButton().click();
    // assignmentQueues.caseFieldOpsSysCollapseButton().should('be.visible');
    assignmentQueues.caseFieldPriorityCollapseButton().scrollIntoView().should('be.visible');
    assignmentQueues.createVirtualQueueCancelButton().should('be.visible');
    assignmentQueues.saveVirtualQueueButton().click();
    assignmentQueues.assignmentQueueNameList().last().should('have.text', 'Virtual Queue');
    assignmentQueues.addAgentButtonByQueueName('Virtual Queue').should('exist');
    assignmentQueues.queueFilterTabList().should('contain', 'Case Fields').and('contain', 'Customers').and('contain', 'Agents');
    assignmentQueues.autoAssignDropdownByQueueName('Virtual Queue').should('have.text', 'Do nothing');
    assignmentQueues.queueVisibilityToggleButton('Virtual Queue').last().click();
    assignmentQueues.queueVisibilityToggleButton('Virtual Queue').last().find('svg').invoke('attr', 'class').should('contain', 'EyeClosed');
    assignmentQueues.addAgentButtonByQueueName('Virtual Queue').should('not.exist');
    assignmentQueues.queueFilterTabList().should('not.exist');
    assignmentQueues.autoAssignDropdownByQueueName('Virtual Queue').should('not.exist');
    assignmentQueues.queueDeleteButtonByQueueName('Virtual Queue').should('not.exist');
    assignmentQueues.queueVisibilityToggleButton('Virtual Queue').last().click();
    cy.waitForLoaders();
  });

  /*
   * TODO Deprecate OpsSystem Case Field Option , Remove on Sept 30.
   *
   * Visit the Assignment Queues module
   * Click on the Add Virtual Queue button in the bottom of the page
   * Click on Create Virtual Queue Button
   * Create a virtual queue without filters
   * Hide and unhide the virtual queue
   */
  it('C9379: VQ - Unhide a Virtual Queue from Assignment Queue page', () => {
    assignmentQueues.addVirtualQueueButton().click();
    // assignmentQueues.caseFieldOpsSysCollapseButton().should('be.visible');
    assignmentQueues.caseFieldPriorityCollapseButton().scrollIntoView().should('be.visible');
    assignmentQueues.createVirtualQueueCancelButton().should('be.visible');
    assignmentQueues.saveVirtualQueueButton().click();
    assignmentQueues.assignmentQueueNameList().last().should('have.text', 'Virtual Queue');
    assignmentQueues.addAgentButtonByQueueName('Virtual Queue').should('exist');
    assignmentQueues.queueFilterTabList().should('contain', 'Case Fields').and('contain', 'Customers').and('contain', 'Agents');
    assignmentQueues.autoAssignDropdownByQueueName('Virtual Queue').should('have.text', 'Do nothing');
    assignmentQueues.queueVisibilityToggleButton('Virtual Queue').last().click();
    assignmentQueues.queueVisibilityToggleButton('Virtual Queue').last().find('svg').invoke('attr', 'class').should('contain', 'EyeClosed');
    assignmentQueues.addAgentButtonByQueueName('Virtual Queue').should('not.exist');
    assignmentQueues.queueFilterTabList().should('not.exist');
    assignmentQueues.autoAssignDropdownByQueueName('Virtual Queue').should('not.exist');
    assignmentQueues.queueDeleteButtonByQueueName('Virtual Queue').should('not.exist');
    assignmentQueues.queueVisibilityToggleButton('Virtual Queue').last().click();
    assignmentQueues.queueVisibilityToggleButton('Virtual Queue').last().find('svg').invoke('attr', 'class').should('contain', 'EyeOpened');
    assignmentQueues.addAgentButtonByQueueName('Virtual Queue').should('exist');
    assignmentQueues.queueFilterTabList().should('contain', 'Case Fields').and('contain', 'Customers').and('contain', 'Agents');
    assignmentQueues.autoAssignDropdownByQueueName('Virtual Queue').should('have.text', 'Do nothing');
  });
  /*
   * TODO Deprecate OpsSystem Case Field Option , Remove on Sept 30.
   *
   * Visit the Assignment Queues module
   * Click on the Add Virtual Queue button in the bottom of the page
   * Click on Create Virtual Queue Button
   * Update the auto assign flag to Always
   */
  it('C9387: VQ - Marking auto assign flag as `Always`', () => {
    assignmentQueues.addVirtualQueueButton().click();
    // assignmentQueues.caseFieldOpsSysCollapseButton().should('be.visible');
    assignmentQueues.caseFieldPriorityCollapseButton().scrollIntoView().should('be.visible');
    assignmentQueues.createVirtualQueueCancelButton().should('be.visible');
    assignmentQueues.saveVirtualQueueButton().click();
    assignmentQueues.assignmentQueueNameList().last().should('have.text', 'Virtual Queue');
    assignmentQueues.autoAssignDropdownByQueueName('Virtual Queue').should('have.text', 'Do nothing').click();
    assignmentQueues.autoAssignDropdownOptionAlways().click();
    assignmentQueues.autoAssignDropdownByQueueName('Virtual Queue').should('have.text', 'Always');
  });
  /*
   * TODO Deprecate OpsSystem Case Field Option , Remove on Sept 30.
   *
   * Visit the Assignment Queues module
   * Click on the Add Virtual Queue button in the bottom of the page
   * Click on Create Virtual Queue Button
   * Update the auto assign flag to Optional
   */
  it('C9388: VQ - Marking auto assign flag as `Optional`', () => {
    assignmentQueues.addVirtualQueueButton().click();
    // assignmentQueues.caseFieldOpsSysCollapseButton().should('be.visible');
    assignmentQueues.caseFieldPriorityCollapseButton().scrollIntoView().should('be.visible');
    assignmentQueues.createVirtualQueueCancelButton().should('be.visible');
    assignmentQueues.saveVirtualQueueButton().click();
    assignmentQueues.assignmentQueueNameList().last().should('have.text', 'Virtual Queue');
    assignmentQueues.autoAssignDropdownByQueueName('Virtual Queue').should('have.text', 'Do nothing').click();
    assignmentQueues.autoAssignDropdownOptionOptional().click();
    assignmentQueues.autoAssignDropdownByQueueName('Virtual Queue').should('have.text', 'Optional');
  });
  /*
   * TODO Deprecate OpsSystem Case Field Option , Remove on Sept 30.
   *
   * Visit the Assignment Queues module
   * Click on the Add Virtual Queue button in the bottom of the page
   * Click on Create Virtual Queue Button
   * Update the auto assign flag to Never
   */
  it('C9389: VQ - Marking auto assign flag as `Never`', () => {
    assignmentQueues.addVirtualQueueButton().click();
    // assignmentQueues.caseFieldOpsSysCollapseButton().should('be.visible');
    assignmentQueues.caseFieldPriorityCollapseButton().scrollIntoView().should('be.visible');
    assignmentQueues.createVirtualQueueCancelButton().should('be.visible');
    assignmentQueues.saveVirtualQueueButton().click();
    assignmentQueues.assignmentQueueNameList().last().should('have.text', 'Virtual Queue');
    assignmentQueues.autoAssignDropdownByQueueName('Virtual Queue').should('have.text', 'Do nothing').click();
    assignmentQueues.autoAssignDropdownOptionNever().click();
    assignmentQueues.autoAssignDropdownByQueueName('Virtual Queue').should('have.text', 'Never');
  });
  /*
   * TODO Deprecate OpsSystem Case Field Option , Remove on Sept 30.
   *
   * Visit the Assignment Queues module
   * Click on the Add Virtual Queue button in the bottom of the page
   * Click on Create Virtual Queue Button
   * Update the auto assign flag to Never
   */
  it('C9390: VQ - Marking auto assign flag as `Do Nothing`', () => {
    assignmentQueues.addVirtualQueueButton().click();
    // assignmentQueues.caseFieldOpsSysCollapseButton().should('be.visible');
    assignmentQueues.caseFieldPriorityCollapseButton().scrollIntoView().should('be.visible');
    assignmentQueues.createVirtualQueueCancelButton().should('be.visible');
    assignmentQueues.saveVirtualQueueButton().click();
    assignmentQueues.assignmentQueueNameList().last().should('have.text', 'Virtual Queue');
    assignmentQueues.autoAssignDropdownByQueueName('Virtual Queue').should('have.text', 'Do nothing');
    assignmentQueues.autoAssignDropdownByQueueName('Virtual Queue').click();
    assignmentQueues.autoAssignDropdownOptionOptional().click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    assignmentQueues.autoAssignDropdownByQueueName('Virtual Queue').should('have.text', 'Optional');
    assignmentQueues.autoAssignDropdownByQueueName('Virtual Queue').click();
    assignmentQueues.autoAssignDropdownOptionDoNothing().click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    assignmentQueues.autoAssignDropdownByQueueName('Virtual Queue').should('have.text', 'Do nothing');
  });

  /*
   * TODO Deprecate OpsSystem Case Field Option , Remove on Sept 30.
   *
   * Visit the Assignment Queues module
   * Click on the Add Virtual Queue button in the bottom of the page
   * Click on Create Virtual Queue Button
   * Edit the virtual queue to filter by a favorite customer
   */
  it('C9409: VQ - Edit Customer filter from Customer Favourites', () => {
    cy.slcHelpers.getCustomerDetails().then((customerDetails) => {
      cy.intercept('PUT', 'api/users/dashboard_settings').as('editFavoriteCustomers');
      apiHelpers.removeAllFavoriteCustomers();
      cy.visit(urlHelpers.myCustomers);
      customerFavorites.zeroStateAddFavoriteButton().click();
      const customerDetail = Cypress._.sample(customerDetails);

      customerFavorites.searchFor(customerDetail.name);
      customerFavorites.searchResultsListItem().should('be.visible').and('have.length.at.least', 1).first().should('have.text', customerDetail.name).click();
      cy.wait('@editFavoriteCustomers');
      customerFavorites.favoritesTableCustomerNameLabel().should('have.text', customerDetail.name);
      cy.visit(urlHelpers.assignmentQueues);
      cy.waitForLoaders();
      assignmentQueues.addVirtualQueueButton().click();
      // assignmentQueues.caseFieldOpsSysCollapseButton().should('be.visible');
      assignmentQueues.caseFieldPriorityCollapseButton().scrollIntoView().should('be.visible');
      assignmentQueues.createVirtualQueueCancelButton().should('be.visible');
      assignmentQueues.saveVirtualQueueButton().click();
      assignmentQueues.assignmentQueueNameList().last().should('have.text', 'Virtual Queue');
      assignmentQueues.vqEditFilterButton('Virtual Queue').last().click();
      cy.waitForLoaders();
      // assignmentQueues.caseFieldOpsSysCollapseButton().should('be.visible');
      assignmentQueues.caseFieldPriorityCollapseButton().scrollIntoView().should('be.visible');
      assignmentQueues.queueFilterTabList().eq(4).should('be.visible').click();
      globalFilters.quickFilterCustomerFavoritesLink().click();
      assignmentQueues.virtualQueueFilterCheckboxList().first().click({ force: true });
      assignmentQueues.virtualQueueFilterCheckboxList().first().invoke('attr', 'data-status').should('equal', 'checked');
      assignmentQueues.saveVirtualQueueButton().click();
      assignmentQueues.assignmentQueueNameList().last().should('have.text', 'Virtual Queue');
      assignmentQueues.queueFilterTabList().eq(1).click();
      assignmentQueues.virtualQueueFilterLabel().should('have.text', customerDetail.name);
      apiHelpers.removeAllFavoriteCustomers();
    });
  });

  /*
   * TODO Deprecate OpsSystem Case Field Option , Remove on Sept 30.
   *
   * Visit the Assignment Queues module
   * Click on the Add Virtual Queue button in the bottom of the page
   * Click on Create Virtual Queue Button
   * Edit the virtual queue to filter by a favorite agent
   */
  it('C9408: VQ - Edit Agent filter to add VT/VO from Agent Favourites', () => {
    // Using static data as due to SLC-34290, a new newly created virtual queue cannot always be found
    // this case will be modified once the elastic wrapper is implemented to use realtime data
    const vtName = 'C9365 VQ DO NOT DELETE';

    apiHelpers.removeAllFavoriteAgents();
    cy.visit(urlHelpers.myAgents);
    agents.agentSearchInputField().click().type(vtName);
    agents.agentSearchResultListItem().first().click();
    agents.removeFavoriteAgentButton().should('be.visible');
    cy.visit(urlHelpers.assignmentQueues);
    cy.waitForLoaders();
    assignmentQueues.addVirtualQueueButton().click();
    // assignmentQueues.caseFieldOpsSysCollapseButton().should('be.visible');
    assignmentQueues.caseFieldPriorityCollapseButton().scrollIntoView().should('be.visible');
    assignmentQueues.createVirtualQueueCancelButton().should('be.visible');
    assignmentQueues.saveVirtualQueueButton().click();
    assignmentQueues.assignmentQueueNameList().last().should('have.text', 'Virtual Queue');
    assignmentQueues.vqEditFilterButton('Virtual Queue').last().click();
    cy.waitForLoaders();
    // assignmentQueues.caseFieldOpsSysCollapseButton().should('be.visible');
    assignmentQueues.caseFieldPriorityCollapseButton().scrollIntoView().should('be.visible');
    assignmentQueues.queueFilterTabList().eq(5).should('be.visible').click();
    globalFilters.quickFilterAgentFavoritesLink().click();
    assignmentQueues.virtualQueueFilterCheckboxList().first().click({ force: true });
    assignmentQueues.virtualQueueFilterCheckboxList().first().invoke('attr', 'data-status').should('equal', 'checked');
    assignmentQueues.saveVirtualQueueButton().click();
    assignmentQueues.assignmentQueueNameList().last().should('have.text', 'Virtual Queue');
    assignmentQueues.queueFilterTabList().eq(2).click();
    assignmentQueues.virtualQueueFilterLabel().should('have.text', vtName);
    apiHelpers.removeAllFavoriteAgents();
  });

  /*
   * TODO Deprecate OpsSystem Case Field Option , Remove on Sept 30.
   *
   * Visit the Assignment Queues module
   * Click on the Add Virtual Queue button in the bottom of the page
   * Click on Create Virtual Queue Button
   * Click the add agent button to add Agents/Virtual Teams
   */
  it('C9377: VQ - Map Agents or Virtual teams/Org to a Virtual Queue', () => {
    // Using static data as due to SLC-34290, a new newly created virtual queue cannot always be found
    // this case will be modified once the elastic wrapper is implemented to use realtime data
    const vtName = 'C9365 VQ DO NOT DELETE';
    cy.slcHelpers.getAgentDetails().then((agentDetails) => {
      const agentDetail = Cypress._.sample(agentDetails);
      assignmentQueues.addVirtualQueueButton().click();
      // assignmentQueues.caseFieldOpsSysCollapseButton().should('be.visible');
      assignmentQueues.caseFieldPriorityCollapseButton().scrollIntoView().should('be.visible');
      assignmentQueues.createVirtualQueueCancelButton().should('be.visible');
      assignmentQueues.saveVirtualQueueButton().click();
      assignmentQueues.assignmentQueueNameList().last().should('have.text', 'Virtual Queue');
      assignmentQueues.addAgentButtonByQueueName('Virtual Queue').last().click();
      assignmentQueues.addAgentPopupFilterButton().click();
      cy.waitForLoaders();
      assignmentQueues.virtualQueueFilterCheckboxList().parent().should('contain', 'Individual Agent').and('contain', 'Virtual Team').and('contain', 'Virtual Org');
      assignmentQueues.addAgentPopupSearchBox().clear().type(vtName);
      assignmentQueues.addAgentPopupSearchResultItem().first().click({ force: true });
      assignmentQueues.addAgentPopupSearchBox().clear().type(agentDetail.sl_name);
      cy.waitForLoaders();
      assignmentQueues.addAgentPopupSearchResultItem().first().click({ force: true });
      assignmentQueues.assignmentQueueNameList().last().should('have.text', 'Virtual Queue');
      assignmentQueues.assignedAgentItemsByQueueName('Virtual Queue').should('contain', vtName);
      assignmentQueues.assignedAgentItemsByQueueName('Virtual Queue').should('contain', agentDetail.sl_name);
    });
  });

  /*
   * TODO Deprecate OpsSystem Case Field Option , Remove on Sept 30.
   *
   * Visit the Assignment Queues module
   * Click on the Add Virtual Queue button in the bottom of the page
   * Create two virtual queues
   * Edit the second queue name and press enter without changing the name
   */
  it('C11802: Two VQs should not have same name', () => {
    assignmentQueues.addVirtualQueueButton().click();
    // assignmentQueues.caseFieldOpsSysCollapseButton().should('be.visible');
    assignmentQueues.caseFieldPriorityCollapseButton().scrollIntoView().should('be.visible');
    assignmentQueues.saveVirtualQueueButton().click();
    cy.waitForLoaders();
    assignmentQueues.addVirtualQueueButton().click();
    // assignmentQueues.caseFieldOpsSysCollapseButton().should('be.visible');
    assignmentQueues.caseFieldPriorityCollapseButton().scrollIntoView().should('be.visible');
    assignmentQueues.saveVirtualQueueButton().click();
    cy.waitForLoaders();
    assignmentQueues.assignmentQueueNameList().last().should('have.text', 'Virtual Queue');
    assignmentQueues.assignmentQueueNameEditButton().last().should('be.visible').click();
    assignmentQueues.editQueueNameInputField().type('{enter}');
    assignmentQueues.editQueueNameErrorMessage().last().should('have.text', 'Duplicate queue name is not allowed');
    assignmentQueues.assignmentQueueNameEditButton().last().should('be.visible');
  });

  /*
   * TODO Deprecate OpsSystem Case Field Option , Remove on Sept 30.
   *
   * Visit the Assignment Queues module
   * Click on the Add Virtual Queue button in the bottom of the page
   * Click on Create Virtual Queue Button
   * Cancel the creation flow and verify the count remains unchanged
   */
  it('C11801: VQ - Cancel VQ creation workflow', () => {
    assignmentQueues.assignmentQueueNameList().then((list) => {
      assignmentQueues.addVirtualQueueButton().click();
      // assignmentQueues.caseFieldOpsSysCollapseButton().should('be.visible');
      assignmentQueues.caseFieldPriorityCollapseButton().scrollIntoView().should('be.visible');
      assignmentQueues.createVirtualQueueCancelButton().click();
      assignmentQueues.assignmentQueueNameList().last().should('not.have.text', 'Virtual Queue');
      assignmentQueues.assignmentQueueNameList().should('have.length', list.length);
    });
  });
});

describe('ICA - Virtual Queues Delete', { tags: ['ICA', 'staging', '@VirtualQueues'] }, () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.assignmentQueues);
    cy.waitForLoaders();

    // removing existing virtual queues to avoid issues while locating tab headers
    assignmentQueues.removeVirtualQueues();
  });

  after(() => {
    // cleaning up virtual queues
    assignmentQueues.removeVirtualQueues();
  });

  /*
   * TODO Deprecate OpsSystem Case Field Option , Remove on Sept 30.
   *
   * Visit the Assignment Queues module
   * Click on the Add Virtual Queue button in the bottom of the page
   * Click on Create Virtual Queue Button
   * Delete the virtual queue and verify the count is reduced by one
   */
  it('C9373: Delete a Virtual Queue', () => {
    assignmentQueues.addVirtualQueueButton().click();
    // assignmentQueues.caseFieldOpsSysCollapseButton().should('be.visible');
    assignmentQueues.caseFieldPriorityCollapseButton().scrollIntoView().should('be.visible');
    assignmentQueues.createVirtualQueueCancelButton().should('be.visible');
    assignmentQueues.saveVirtualQueueButton().click();
    cy.waitForLoaders();
    assignmentQueues.assignmentQueueNameList().then((list) => {
      assignmentQueues.assignmentQueueNameList().last().should('have.text', 'Virtual Queue');
      assignmentQueues.queueDeleteButtonByQueueName('Virtual Queue').last().realHover();
      assignmentQueues.virtualQueueDeleteButtonTooltip().should('have.text', 'Remove');
      assignmentQueues.queueDeleteButtonByQueueName('Virtual Queue').last().click();
      assignmentQueues.vqDeletePopupCancelButton().should('have.text', 'Cancel');
      assignmentQueues.deleteQueueConfirmButton().should('have.text', 'Delete').click();
      cy.waitForLoaders();
      assignmentQueues.assignmentQueueNameList().last().should('not.have.text', 'Virtual Queue');
      assignmentQueues.assignmentQueueNameList().should('have.length', list.length - 1);
    });
  });

  /*
   * TODO Deprecate OpsSystem Case Field Option , Remove on Sept 30.
   *
   * Visit the Assignment Queues module
   * Click on the Add Virtual Queue button in the bottom of the page
   * Click on Create Virtual Queue Button
   * Cancel deletion and verify the count remains unchanged
   */
  it('C9374: Cancel a deletion workflow of VQ', () => {
    assignmentQueues.addVirtualQueueButton().click();
    // assignmentQueues.caseFieldOpsSysCollapseButton().should('be.visible');
    assignmentQueues.caseFieldPriorityCollapseButton().scrollIntoView().should('be.visible');
    assignmentQueues.createVirtualQueueCancelButton().should('be.visible');
    assignmentQueues.saveVirtualQueueButton().click();
    cy.waitForLoaders();
    assignmentQueues.assignmentQueueNameList().then((list) => {
      assignmentQueues.assignmentQueueNameList().last().should('have.text', 'Virtual Queue');
      assignmentQueues.queueDeleteButtonByQueueName('Virtual Queue').last().realHover();
      assignmentQueues.virtualQueueDeleteButtonTooltip().should('have.text', 'Remove');
      assignmentQueues.queueDeleteButtonByQueueName('Virtual Queue').last().click();
      assignmentQueues.vqDeletePopupCancelButton().should('have.text', 'Cancel').click();
      assignmentQueues.assignmentQueueNameList().last().should('have.text', 'Virtual Queue');
      assignmentQueues.assignmentQueueNameList().should('have.length', list.length);
    });
  });
});
