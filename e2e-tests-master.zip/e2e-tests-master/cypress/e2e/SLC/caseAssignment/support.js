export const randId = () => Cypress._.random(0, 1e6);

export const createAssignmentQueue = (queueName, agentId, userSid, enableAutoAssign = false) =>
  cy.request({
    method: 'POST',
    url: 'api/v2/object/group',
    body: {
      s_id_parent: null,
      name: queueName,
      description: '',
      group_type: 'TICKET_QUEUE',
      metadata_list: [
        { metadata_type: 'TICKET_QUEUE', metadata_key: 'crm_queue_id', metadata_value: agentId, metadata_value_type: 'STRING' },
        { metadata_type: 'TICKET_QUEUE', metadata_key: 'auto_assign', metadata_value: enableAutoAssign, metadata_value_type: 'BOOL' },
      ],
      membership_list: [],
      s_object_creator: { object_id: userSid, object_type: 'SL_USER' },
    },
  });

export const deleteAssignmentQueue = (queueSid) => cy.request('DELETE', `/api/v2/object/group/${queueSid}`);

export const getQueueIds = () =>
  cy
    .request({
      method: 'POST',
      url: 'api/v2/object/group/query',
      body: {
        page_number: 0,
        page_size: 1000,
        sort_key: 's_seq_id',
        sort_direction: 'asc',
        filter_list: [
          { column: 'group_type', op: '=', value: 'TICKET_QUEUE' },
          { column: 's_deleted_at', op: '=', value: null },
        ],
      },
    })
    // eslint-disable-next-line camelcase
    .then(({ body }) => body.data.map(({ membership_list }) => membership_list[0].object_reference.object.value));
