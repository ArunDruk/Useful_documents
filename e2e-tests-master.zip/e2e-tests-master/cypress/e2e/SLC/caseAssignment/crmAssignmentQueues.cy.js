import { createAssignmentQueue, deleteAssignmentQueue, getQueueIds, randId } from './support';
import { urlHelpers } from '../../../utils';
import { assignmentQueues } from '../../../pages';

// NOTE: All TCs in this 'describe' block utilizes the CRM queue created via API in the beforeEach block
describe('ICA - CRM Assignment Queues', { tags: ['ICA', 'staging'] }, () => {
  beforeEach(() => {
    const queueName = `Test Queue ${randId()}`;

    cy.intercept('api/users/profile').as('profile');
    cy.intercept('POST', 'api/v2/object/group').as('createQueue');
    cy.intercept('DELETE', 'api/v2/object/group/*').as('deleteQueue');
    cy.intercept('POST', 'api/v2/object/group/member').as('addAgentToQueue');
    cy.intercept('POST', 'api/v2/object/group/query').as('fetchAssignmentQueues');
    cy.intercept('POST', 'search/virtual_groups/_search*').as('searchVirtualGroup');

    cy.loginByApi();
    cy.visit(urlHelpers.caseAssignment);

    cy.wait('@profile').then(({ response }) =>
      cy.slcHelpers.getAgentIds(1).then((agentIds) =>
        createAssignmentQueue(queueName, agentIds[0], response.body.s_id).then(({ body }) => {
          cy.wrap(queueName).as('queueName');
          cy.wrap(body.data[0].s_id).as('queueSid');
        })
      )
    );

    cy.visit(urlHelpers.assignmentQueues);
    cy.wait('@fetchAssignmentQueues');
  });

  afterEach(function afterEachHook() {
    deleteAssignmentQueue(this.queueSid);
  });

  /*
   * Check if the created CRM queue exists
   * Then, click on it to open the edit field
   * Clear the current name and type a really long text
   *
   * Verify that 'Queue name should not exceed 50 characters' error message is displayed
   */
  it('C6277: should throw error when name length exceeds limit', function nameLimitError() {
    const { queueName } = this;

    // Asserting existence instead of visibility since the element has CSS property 'overflow: hidden'
    assignmentQueues.crmQueueListItemByQueueName(queueName).should('exist');
    assignmentQueues.crmQueueListItemByQueueName(queueName).click();
    assignmentQueues.editQueueNameInputField().clear().type('testing error message when name length exceeds limit{enter}');

    assignmentQueues.editQueueNameErrorMessage().should('have.text', 'Queue name should not exceed 50 characters');
  });

  /*
   * TODO: (ikhalikov) exp. kickoff wait wrapper for elastic
   *
   * Fetch 5 agent IDs via API
   * Create a Virtual Team via API using the fetched agent IDs
   *
   * Click the + button in the column next to the target CRM Queue
   * Type the virtual team name in the agent search box
   * wait for the results
   *
   * Click the first item in the search results
   * wait for the agent to be added
   *
   * Verify that the target Queue has the newly added virtual team name
   *
   * Delete the created virtual team
   */
  it.skip('C2188: should add virtual team to a queue', function addVirtualTeam() {
    const { queueName } = this;
    const vtName = `Test Personal Team ${randId()}`;

    cy.slcHelpers
      .getAgentIds(5)
      .then((agentIds) => cy.slcHelpers.createVT(vtName, agentIds))
      .wait(30000) // wait for the VT to appear in the elastic index
      .then((response) => {
        assignmentQueues.addAgentButtonByQueueName(queueName).click();
        assignmentQueues.addAgentPopupSearchBox().type(vtName);
        cy.wait('@searchVirtualGroup');

        assignmentQueues.addAgentPopupSearchResultItem().first().click();
        cy.wait('@addAgentToQueue');

        assignmentQueues.assignedAgentItemsByQueueName(queueName).should('have.text', vtName);

        cy.slcHelpers.deleteVgroup(response.body.id);
      });
  });

  /*
   * Verify that the last CRM queue name matches the expected value
   * Click the delete button in the same row
   * wait for the delete API call to happen
   *
   * Verify that the CRM queue is removed
   */
  it('C2171: should be able to delete a queue', function deleteQueue() {
    const { queueName } = this;

    assignmentQueues.commonCrmQueueListItem().last().should('have.text', queueName);
    assignmentQueues.queueDeleteButtonByQueueName(queueName).click();
    cy.wait('@deleteQueue');

    assignmentQueues.crmQueueListItemByQueueName(queueName).should('not.exist');
  });

  /*
   * Verify that the last CRM queue name matches the expected value
   * Click the + button in the column next to the target CRM Queue
   *
   * Get agent details via API and pick a random agent from the response
   * Type the agent name in the agent search box
   * wait for the results
   *
   * Click the first item in the search results
   * wait for the agent to be added
   *
   * Verify that the target Queue has the newly added agent name
   */
  it('C2173: should be able to assign agents to queue', function assignAgents() {
    const { queueName } = this;

    assignmentQueues.commonCrmQueueListItem().last().should('have.text', queueName);
    assignmentQueues.addAgentButtonByQueueName(queueName).click();

    cy.slcHelpers.getAgentDetails().then((agentDetails) => {
      const agentDetail = Cypress._.sample(agentDetails);
      const agentName = agentDetail.sl_name;

      assignmentQueues.addAgentPopupSearchBox().type(agentName);
      cy.wait('@searchVirtualGroup');

      assignmentQueues.addAgentPopupSearchResultItem().first().click();
      cy.wait('@addAgentToQueue');

      assignmentQueues.assignedAgentItemsByQueueName(queueName).should('be.visible').and('have.text', agentName);
    });
  });
});

// NOTE: This 'describe' block is for TCs that need to create a CRM queue using the UI
describe('ICA - CRM Assignment Queues', { tags: ['ICA', 'staging'] }, () => {
  beforeEach(() => {
    cy.intercept('POST', 'api/v2/object/group/query').as('fetchAssignmentQueues');
    cy.intercept('POST', 'search/virtual_groups/_search*').as('searchVirtualGroup');
    cy.intercept('POST', 'api/v2/object/group').as('createQueue');

    cy.loginByApi();
    cy.visit(urlHelpers.assignmentQueues);
    cy.wait('@fetchAssignmentQueues');
  });

  afterEach(function afterEachHook() {
    deleteAssignmentQueue(this.queueSid);
  });

  /*
   * Fetch agent details & existing assignment queue IDs
   * Filter agentDetails that are already assigned to a queue
   *
   * Click the 'Add a CRM queue' button
   * Type the agent ID in the add queue search box
   * wait for the search results
   *
   * Select the first item in the search results
   * wait for the queue to be created (store the queue s_id from the response)
   *
   * Verify that the last CRM queue item is visible and has the agent name whose ID was used to create the queue
   */
  it('C2170: should be able to add a CRM queue', function addCrmQueue() {
    cy.slcHelpers.getAgentDetails().then((agentDetails) => {
      // Filter agentDetails that are already assigned to a queue
      getQueueIds().then((queueIds) => {
        const randomAgent = Cypress._.sample(
          agentDetails.filter(function filterQueues(e) {
            return this.indexOf(e) < 0;
          }, queueIds)
        );
        const agentId = randomAgent.id;
        const agentName = randomAgent.sl_name;

        assignmentQueues.addCrmQueueButton().click();
        assignmentQueues.addCrmQueueSearchBox().type(agentId);
        cy.wait('@searchVirtualGroup');

        assignmentQueues.addQueueSearchResultItems().first().click();
        cy.wait('@createQueue').then(({ response }) => cy.wrap(response.body.data[0].s_id).as('queueSid'));

        assignmentQueues.commonCrmQueueListItem().last().should('be.visible').and('have.text', agentName);
      });
    });
  });
});
