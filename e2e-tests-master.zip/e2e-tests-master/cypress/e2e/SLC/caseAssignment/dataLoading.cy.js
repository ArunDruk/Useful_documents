import { urlHelpers } from '../../../utils';
import { caseAssignment, globalFilters } from '../../../pages';

const caseAssignmentTabs = [
  {
    name: 'Unassigned',
    tabElement: caseAssignment.unassignedTab,
    tabCountLabel: caseAssignment.unassignedTabCountLabel,
    sortByDropdown: caseAssignment.unassignedTabSortByDropdown,
    zeroStateText: caseAssignment.unassignedTabZeroStateLabel,
  },
  {
    name: 'Assigned Today',
    tabElement: caseAssignment.assignedTodayTab,
    tabCountLabel: caseAssignment.assignedTodayTabCountLabel,
    sortByDropdown: caseAssignment.assignedTodayTabSortByDropdown,
    zeroStateText: caseAssignment.assignedTodayTabZeroStateLabel,
  },
];

describe('ICA - Data loading', () => {
  beforeEach(() => {
    cy.loginByApi(Cypress.env('normalUserEmail'));
    cy.slcHelpers.deleteGlobalFilter();
    cy.slcHelpers.clearAgentsQuickFilter();
    cy.slcHelpers.clearCustomersQuickFilter();
    cy.slcHelpers.clearCaseFieldQuickFilter();

    cy.visit(urlHelpers.caseAssignment);

    caseAssignment.unassignedTab().click();
  });

  afterEach(() => {
    cy.slcHelpers.deleteGlobalFilter();
    cy.slcHelpers.clearAgentsQuickFilter();
    cy.slcHelpers.clearCustomersQuickFilter();
    cy.slcHelpers.clearCaseFieldQuickFilter();
    cy.slcHelpers.clearCustomersQuickFilter();
  });

  /*
   * Get the priority value from the first case list item in Unassigned tab
   * Apply quick filter for the fetched priority value
   *
   * Verify that the displayed data respects the applied filter
   */
  it('C814: should check data validity after applying global filter', { tags: ['staging'] }, () => {
    caseAssignment
      .caseListCasePriorityLabel()
      .first()
      .invoke('text')
      .then((expectedPriority) => {
        globalFilters.filterByPriorityCaseField(expectedPriority);
        caseAssignment
          .caseListCasePriorityLabel()
          .text()
          .then((priorities) => expect(priorities.every((priority) => priority === expectedPriority)).to.be.true);
      });
  });
});

describe('ICA - Data loading', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.caseAssignment);

    caseAssignment.unassignedTab().click();
  });

  /*
   * Click on the tab
   * verify the visibility of the sort button
   *
   * If count is not 0, verify case list cards are visible
   * Else, verify zero-state message is displayed
   */
  it('C816: should check for cases in ICA tabs', { tags: ['ICA', 'staging', 'prod'] }, () => {
    caseAssignmentTabs.forEach((tab) => {
      cy.log(tab.name);
      tab
        .tabCountLabel()
        .invoke('text')
        .then((count) => {
          tab.tabElement().click();
          tab.sortByDropdown().should('be.visible');

          if (count === '0') {
            tab.zeroStateText().should('be.visible');
          } else {
            caseAssignment.caseListItemCard().should('be.visible');
          }
        });
    });
  });

  /*
   * Fetch and compare the customer name of first case list item with customer name in summary view
   * Fetch and compare the case id of first case list item with case id in summary view
   * Fetch and compare the case subject of first case list item with case subject in summary view
   * Fetch and compare the case priority of first case list item with case priority in summary view
   */
  it('C2239: should compare case card data against case summary data', { tags: ['ICA', 'staging', 'prod'] }, () => {
    caseAssignment
      .caseListCardTitleLabel()
      .first()
      .invoke('text')
      .then((customerName) => caseAssignment.summaryCustomerNameLabel().should('have.text', customerName));

    caseAssignment
      .caseListCaseIdLabel()
      .first()
      .invoke('text')
      .then((caseId) => caseAssignment.summaryCaseIdLabel().should('have.text', caseId));

    caseAssignment
      .caseListCaseSubjectLabel()
      .first()
      .invoke('text')
      .then((caseSubject) => caseAssignment.summaryCaseSubjectLabel().should('have.text', caseSubject));

    caseAssignment
      .caseListCasePriorityLabel()
      .first()
      .invoke('text')
      .then((casePriority) => caseAssignment.summaryCasePriorityLabel().should('have.text', casePriority));
  });
});
