import { createAssignmentQueue, deleteAssignmentQueue, randId } from './support';
import { urlHelpers } from '../../../utils';
import { assignmentQueues, navBar, productModules } from '../../../pages';

// Skipping Enable Disable module test cases
describe.skip('', () => {
  beforeEach(() => {
    const queueName = `Test Queue ${randId()}`;

    cy.intercept('/api/users/profile').as('profile');
    cy.intercept('POST', 'api/v2/object/group/query').as('fetchAssignmentQueues');

    cy.loginByApi();
    cy.visit(`${urlHelpers.controlCenter.settingsHome}/product_edition`);

    cy.wait('@profile').then(({ response }) =>
      cy.slcHelpers.getAgentIds(1).then((agentIds) =>
        createAssignmentQueue(queueName, agentIds[0], response.body.s_id).then(({ body }) => {
          cy.wrap(queueName).as('queueName');
          cy.wrap(body.data[0].s_id).as('queueSid');
        })
      )
    );
  });

  afterEach(function afterEachHook() {
    cy.slcHelpers.enableModule('caseAssignment');
    deleteAssignmentQueue(this.queueSid);
  });

  /*
   * Disable Assignment Board in Settings -> Product Modules
   * Verify Assignment Board navbar item does not exist in the DOM
   *
   * Verify there's at least 1 assignment queue present
   */
  it('C3788: should disable ICA & verify assignment queues and unassigned case visibility', { tags: ['@EnableDisableLockTests', '@NotThreadSafe'] }, () => {
    productModules.assignmentBoardDropdown().click();
    productModules.assignmentBoardDropdownDisableOption().click();

    navBar.assignmentBoard().should('not.exist');

    cy.visit(urlHelpers.assignmentQueues);
    assignmentQueues.commonCrmQueueListItem().should('be.visible').should('have.length.at.least', 1);
    // TODO: Replace with data-status attribute once added
    assignmentQueues.commonAutoAssignDropdown().should('be.visible').and('have.class', 'FiZPIt6oF6PT1aT1BizCg');
    assignmentQueues.commonAddAgentButton().should('not.exist');
  });
});
