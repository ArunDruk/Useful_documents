const queryVgroup = () =>
  cy.request({
    method: 'POST',
    url: 'api/v2/group/search?page_size=5000',
    body: {
      selected: ['id', 'name'],
      ordering: [{ column: 'created_at', direction: 'desc' }],
      predicates: [],
    },
  });

beforeEach(() => {
  cy.intercept('DELETE', 'api/alert-definitions').as('waitForAlertDeletion');

  cy.loginByApi();
});

it('should delete V* items', () => {
  const expectedNames = ['Test shift', 'Test Personal', 'Test Global', 'VA Global', 'VT Global', 'CypressTest'];

  queryVgroup().then(({ body }) => {
    body.forEach((vGroupEntry) => {
      expectedNames.forEach((name) => {
        if (vGroupEntry.name.includes(name)) {
          cy.slcHelpers.deleteVgroup(vGroupEntry.id);
          cy.log(vGroupEntry.name);
        }
      });
    });
  });
});

it('should delete all personal alerts', () => {
  // TODO: Convert below to cypress request
  (async () => {
    const data = await fetch('/api/alert-definitions', {
      headers: {
        'content-type': 'application/json',
      },
      method: 'GET',
    }).then((r) => r.json());

    const userPersonalAlerts = data.definitions.filter((x) => x.isPersonal && x.created_by === window.getState().user.email);

    const batches = Array(Math.ceil(userPersonalAlerts.length / 10))
      .fill(10)
      .map((x, i) => x * i);

    let previousPromise = Promise.resolve();

    batches.forEach((x) => {
      const batch = userPersonalAlerts.slice(x, x + 10);

      previousPromise = previousPromise.then(() =>
        Promise.all(
          batch.map((y) =>
            fetch('/api/alert-definitions', {
              headers: {
                'content-type': 'application/json',
              },
              body: JSON.stringify({
                id: y.id,
              }),
              method: 'DELETE',
            })
          )
        )
      );
    });

    await previousPromise;
  })();
});

it('should delete case list', () => {
  cy.request({
    method: 'PUT',
    url: 'api/users/dashboard_settings',
    body: {
      dashboardName: 'support',
      settingsKey: 'summary_page_settings',
      settingsSubKey: 'cards',
      settingsValue: {},
      replace: true,
    },
  });
});
