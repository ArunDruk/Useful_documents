import { randId, urlHelpers } from '../../../utils';
import { acePage, supportHub, apiHelpers, datePicker } from '../../../pages';

describe('Agent Coaching Feedback', () => {
  beforeEach(function beforeEachHook() {
    cy.loginByApi();
    apiHelpers.clearAgentFilterInACEPage();
    cy.visit(urlHelpers.caseEvaluation);

    acePage
      .recommendedContainerHeader()
      .invoke('text')
      .then((headerText) => {
        if (headerText === '0Recommended') {
          acePage.recommendedSidebarExpandButton().click();
          datePicker.datePickerTrigger().eq(0).click();
          datePicker.selectLastMonthWithOption(3);
          datePicker.datePickerTrigger().eq(0).should('have.text', 'Last 3 months');
          cy.waitForLoaders();
        }
      });

    acePage
      .recommendedSidebarCaseIDs()
      .eq(0)
      .invoke('attr', 'data-testid')
      .then((attrVal) => {
        const caseId = attrVal.split('-')[4];

        cy.wrap(caseId).as('caseId');
        acePage.recommendedCaseCard(caseId).then(() => {
          acePage.recommendedCaseCard(caseId).click();
          cy.waitForLoaders();
          cy.get('#case-comments-annotations').then(($ele) => {
            if ($ele.find('[data-testid=supportHub-caseComments_coaching-content]').length > 0) {
              this.skip();
            }
            supportHub.closeButton().click();
          });
        });
      });
  });

  /*
   * Todo: API request to get ACE tickets without any comments, coaching feedback or automated feedback
   * This is tracked in SLC-34640
   *
   * Open any ticket in ACE Recommended column
   * Highlight the text in case description
   * Select coaching feedback from the options
   * Add a coaching feedback and click on "Comment" button
   * Click on edit from the coaching feedback menu
   * "Comment" button should be disabled
   * Change/add the text to existing coaching feedback
   * "Comment" button should be enabled
   * Click on "Cancel" button
   * Coaching feedback text added before editing should be displayed
   */
  it('C6410: Verify the cancel workflow while editing existing coaching feedback', { tags: ['ace', 'staging'] }, function cancelExistingCoachingFeedback() {
    const coachingFeedbackText = `Test coaching feedback ${randId()}`;
    const coachingFeedbackTextEdited = `Test coaching feedback ${randId()}`;
    const targetCaseCommentIndex = -1;

    acePage.recommendedCaseCard(this.caseId).click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
    supportHub.gotoCaseDescriptionButton().click();

    // Highlighting text in case description
    supportHub.selectCaseCommentText(targetCaseCommentIndex);
    acePage.coachingFeedbackButton().click();

    // Adding coaching feedback
    acePage.coachingFeedbackTextbox().type(coachingFeedbackText);
    acePage.commentButtonInCoachingFeedbackWindow().click();
    acePage.addedCoachingFeedbackText().scrollIntoView().should('be.visible').and('contain', coachingFeedbackText);
    acePage.coachingFeedbackMenuButton().click();
    acePage.coachingFeedbackEditButton().click();
    acePage.commentButtonInCoachingFeedbackWindow().should('be.disabled');

    // Modifying the existing coaching feedback and canceling it
    acePage.coachingFeedbackTextbox().clear();
    acePage.coachingFeedbackTextbox().type(coachingFeedbackTextEdited);
    acePage.commentButtonInCoachingFeedbackWindow().should('be.enabled');
    acePage.cancelButtonInCoachingFeedbackWindow().click();

    // Verifying the display of initially added coaching feedback
    acePage.addedCoachingFeedbackText().should('be.visible').and('contain', coachingFeedbackText);
    acePage.coachingFeedbackMenuButton().click();
    acePage.coachingFeedbackDeleteButton().click();
  });

  /*
   * Todo: API request to get ACE tickets without any comments, coaching feedback or automated feedback
   * This is tracked in SLC-34640
   *
   * Open any ticket in ACE Recommended column
   * Highlight the text in case description
   * Select coaching feedback from the options
   * Add a coaching feedback and click on "Comment" button
   * Click on edit from the coaching feedback menu
   * "Comment" button should be disabled
   * Change the text to existing coaching feedback
   * "Comment" button should be enabled
   * Click on "Comment" button
   * Modified Coaching feedback text should be displayed
   */
  it('C6409: Verify the editing existing coaching feedback', { tags: ['ace', 'staging'] }, function editingExistingCoachingFeedback() {
    const coachingFeedbackText = `Test coaching feedback ${randId()}`;
    const coachingFeedbackTextEdited = `Test coaching feedback ${randId()}`;
    const targetCaseCommentIndex = -1;

    acePage.recommendedCaseCard(this.caseId).click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
    supportHub.gotoCaseDescriptionButton().click();

    // Highlighting text in case description
    supportHub.selectCaseCommentText(targetCaseCommentIndex);
    acePage.coachingFeedbackButton().click();

    // Adding coaching feedback
    acePage.coachingFeedbackTextbox().type(coachingFeedbackText);
    acePage.commentButtonInCoachingFeedbackWindow().click();
    acePage.addedCoachingFeedbackText().scrollIntoView().should('be.visible').and('contain', coachingFeedbackText);
    acePage.coachingFeedbackMenuButton().click();
    acePage.coachingFeedbackEditButton().click();
    acePage.commentButtonInCoachingFeedbackWindow().should('be.disabled');

    // Modifying the existing coaching feedback and saving it
    acePage.coachingFeedbackTextbox().clear();
    acePage.coachingFeedbackTextbox().type(coachingFeedbackTextEdited);
    acePage.commentButtonInCoachingFeedbackWindow().should('be.enabled');
    acePage.commentButtonInCoachingFeedbackWindow().click();

    // Verifying the display of updated coaching feedback
    acePage.addedCoachingFeedbackText().should('be.visible').and('contain', coachingFeedbackTextEdited);
    acePage.coachingFeedbackMenuButton().click();
    acePage.coachingFeedbackDeleteButton().click();
  });

  /*
   * Todo: API request to get ACE tickets without any comments, coaching feedback or automated feedback
   * This is tracked in SLC-34640
   *
   * Open any ticket in ACE Recommended column
   * Highlight the text in case description
   * Select coaching feedback from the options
   * Add a coaching feedback and click on "Comment" button
   * Click on edit from the coaching feedback menu
   * Delete all the text in existing coaching feedback
   * "Comment" button should be disabled
   * Empty state warning message should be displayed
   */
  it('C6412: Verify the display of message when coaching feedback is empty', { tags: ['ace', 'staging'] }, function emptyCoachingFeedback() {
    const coachingFeedbackText = `Test coaching feedback ${randId()}`;
    const emptyStateMessage = 'Please add coaching feedback';
    const targetCaseCommentIndex = -1;

    acePage.recommendedCaseCard(this.caseId).click();
    cy.waitForLoaders();
    supportHub.gotoCaseDescriptionButton().click();

    // Highlighting text in case description
    supportHub.selectCaseCommentText(targetCaseCommentIndex);
    acePage.coachingFeedbackButton().click();

    // Adding coaching feedback
    acePage.coachingFeedbackTextbox().type(coachingFeedbackText);
    acePage.commentButtonInCoachingFeedbackWindow().click();
    acePage.addedCoachingFeedbackText().scrollIntoView().should('be.visible').and('contain', coachingFeedbackText);
    acePage.coachingFeedbackMenuButton().click();
    acePage.coachingFeedbackEditButton().click();

    // Deleting the coaching feedback
    acePage.coachingFeedbackTextbox().clear();
    acePage.commentButtonInCoachingFeedbackWindow().should('be.disabled');
    acePage.coachingFeedbackEmptyStateMessage().should('be.visible').and('contain', emptyStateMessage);

    // Verifying the display of error/warning message when existing coaching feedback is cleared
    acePage.cancelButtonInCoachingFeedbackWindow().click();

    acePage.coachingFeedbackMenuButton().click();
    acePage.coachingFeedbackDeleteButton().click();
  });

  /*
   * Todo: API request to get ACE tickets without any comments, coaching feedback or automated feedback
   * This is tracked in SLC-34640
   *
   * Open any ticket in ACE Recommended column
   * Highlight the text in case description
   * Select coaching feedback from the options
   * Add a coaching feedback and click on "Comment" button
   * Validate that added Coaching feedback text should be displayed
   */
  it('C6305: Verify the adding coaching feedback workflow', { tags: ['ace', 'staging'] }, function addingCoachingFeedback() {
    const coachingFeedbackText = `Test coaching feedback ${randId()}`;
    const targetCaseCommentIndex = -1;

    acePage.recommendedCaseCard(this.caseId).click();
    cy.waitForLoaders();
    supportHub.gotoCaseDescriptionButton().click();
    supportHub.selectCaseCommentText(targetCaseCommentIndex);
    acePage.coachingFeedbackButton().click();
    acePage.coachingFeedbackTextbox().type(coachingFeedbackText);
    acePage.commentButtonInCoachingFeedbackWindow().click();
    acePage.addedCoachingFeedbackText().scrollIntoView().should('be.visible').and('contain', coachingFeedbackText);
    acePage.coachingFeedbackMenuButton().click();
    acePage.coachingFeedbackDeleteButton().click();
  });

  /*
   * Todo: API request to get ACE tickets without any comments, coaching feedback or automated feedback
   * This is tracked in SLC-34640
   *
   * Open any ticket in ACE Recommended column.
   * Highlight the text in case description.
   * Select coaching feedback from the options.
   * Add a coaching feedback and click on "Cancel" button.
   * Validate that Coaching feedback should not be displayed.
   *
   */
  it('C6405: Verify the coaching feedback cancelworkflow', { tags: ['ace', 'staging'] }, function cancelcoachingFeedback() {
    const coachingFeedbackText = `Test coaching feedback ${randId()}`;
    const targetCaseCommentIndex = -1;

    acePage.recommendedCaseCard(this.caseId).click();
    cy.waitForLoaders();
    supportHub.gotoCaseDescriptionButton().click();
    supportHub.selectCaseCommentText(targetCaseCommentIndex);
    acePage.coachingFeedbackButton().click();
    acePage.coachingFeedbackTextbox().type(coachingFeedbackText);
    acePage.cancelButtonInCoachingFeedbackWindow().click();
    cy.waitForLoaders();
    cy.get('body').should('not.contain', coachingFeedbackText);
  });

  /*
   * Todo: API request to get ACE tickets without any comments, coaching feedback or automated feedback
   * This is tracked in SLC-34640
   *
   * Open any ticket in ACE Recommended column.
   * Highlight the text in case description.
   * Select coaching feedback from the options.
   * Add a coaching feedback and click on "Comment" button.
   * Validate that added Coaching feedback text should be displayed.
   * Delete the coaching feedback using three dot menu option.
   * Validate that deleted Coaching feedback text should not be displayed.
   *
   */
  it('C6411: Verify the coaching feedback delete workflow', { tags: ['ace', 'staging'] }, function deleteCoachingFeedback() {
    const coachingFeedbackText = `Test coaching feedback ${randId()}`;
    const targetCaseCommentIndex = -1;

    acePage.recommendedCaseCard(this.caseId).click();
    cy.waitForLoaders();
    supportHub.gotoCaseDescriptionButton().click();
    supportHub.selectCaseCommentText(targetCaseCommentIndex);
    acePage.coachingFeedbackButton().click();
    acePage.coachingFeedbackTextbox().type(coachingFeedbackText);
    acePage.commentButtonInCoachingFeedbackWindow().click();
    cy.waitForLoaders();
    acePage.addedCoachingFeedbackText().scrollIntoView().should('be.visible').and('contain', coachingFeedbackText);
    acePage.coachingFeedbackMenuButton().click();
    acePage.coachingFeedbackDeleteButton().click();
    acePage.addedCoachingFeedbackText().should('not.exist');
    cy.get('body').should('not.contain', coachingFeedbackText);
  });
});
