import { apiHelpers, topics, filters, acePage, supportHub } from '../../../pages/index';
import { urlHelpers } from '../../../utils';

describe('Dynamic Filters Tests', { tags: '@FilterTests' }, () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.removeDynamicFilterAcePage();
    cy.slcHelpers.clearCustomersQuickFilter();
    cy.slcHelpers.clearAgentsQuickFilter();
    cy.slcHelpers.clearCaseFieldQuickFilter();
    cy.slcHelpers.deleteGlobalFilter();
    apiHelpers.clearAgentFilterInACEPage();
    cy.visit(urlHelpers.caseEvaluation);
    cy.waitForLoaders();
  });

  afterEach(() => {
    apiHelpers.removeDynamicFilterAcePage();
  });

  /*
   * Navigate to ACE Page.
   * Click on the Dynamic Filter icon.
   * Choose any field in "Dynamic Filter Settings" window and save.
   * Data should be displayed on the selected value.
   */
  it('C825: Check functionality of dynamic filter ', { tags: ['Filters', 'staging'] }, () => {
    filters.addDynamicFilterButton().click();
    filters.dynamicFilterWelcomePopupVisibilityCheck();
    topics.dynamicFilterPriorityCheckbox().click();
    topics.dynamicFilterStatusCheckbox().click();
    topics.dynamicFilterSaveButton().click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(3000);
    topics.dynamicFilterDropdown().eq(0).should('be.visible').click();
    filters.dynamicFilterDropdownListFirstItem().should('be.visible').contains('Closed').click({ force: true });
    filters.dynamicFilterDropdownApplyButton().should('be.visible').click();
    topics.dynamicFilterDropdown().eq(1).should('be.visible').click();
    filters.dynamicFilterDropdownListFirstItem().should('be.visible').contains('Medium').click({ force: true });
    filters.dynamicFilterDropdownApplyButton().should('be.visible').click();
    cy.waitForLoaders();
    acePage
      .aceAgentCaseList()
      .first()
      .then(() => {
        acePage.aceAgentCaseList().eq(0).should('be.visible').click();
        cy.waitForLoaders();
        supportHub.caseFieldStatusLabel().invoke('text').should('be.equal', 'Closed');
        supportHub.caseFieldPriorityLabel().invoke('text').should('be.equal', 'Medium');
        supportHub.closeButton().click();
      });
  });
});
