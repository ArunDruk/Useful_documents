import { urlHelpers } from '../../../../utils';
import { acePage, apiHelpers, datePicker, supportHub } from '../../../../pages';

describe('ACE - Re-Edit Review validations', () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.clearAgentFilterInACEPage();
    apiHelpers.sortReviewedColumnByTimeInACEPage();
    cy.visit(urlHelpers.caseEvaluation);
    cy.waitForLoaders();

    acePage
      .recommendedContainerHeader()
      .invoke('text')
      .then((headerText) => {
        if (headerText === '0Recommended') {
          acePage.recommendedSidebarExpandButton().click();
          datePicker.datePickerTrigger().eq(0).click();
          datePicker.selectLastMonthWithOption(3);
          datePicker.datePickerTrigger().eq(0).should('have.text', 'Last 3 months');
          cy.waitForLoaders();
        }
      });

    acePage
      .recommendedSidebarCaseIDs()
      .eq(1)
      .invoke('attr', 'data-testid')
      .then((attrVal) => {
        cy.wrap(attrVal.split('-')[4]).as('caseId');
      });
  });

  /*
   * Under recommendation tab,Open any ticket.
   * Click on 'Start Review' button.
   * Give rating for all items and click on "Next"button.
   * Click on 'Complete Review' button,Validate Ratings and Complete review success page should displayed.
   * Validate the "Would you like to review more cases for this agent? " message should be displayed.
   * Open the same ticket in the recently review ticket, Click 'View case review' button.
   * Click the 'Edit review' button , Change the ratings and click nect button.
   * Validate that Edited ratings should be updated in the Completed review page.
   */
  it('C6813: Verify the display of review details after re-editing the completed review', { tags: ['ACE', 'staging'] }, function reEditReviewPage() {
    acePage.recommendedCaseCard(this.caseId).click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
    supportHub.caseOwnerLabel().then((buttonTextFirst) => {
      const agentName = buttonTextFirst.text();
      acePage.startReviewButton().then(() => {
        acePage.startReviewButton().click();
        cy.waitForLoaders();
        acePage.neutralRatingButton().click({ multiple: true });
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(1000);
        acePage.nextReviewConfirmationPopupWindow().should('be.visible').click();
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(1000);
        acePage.completedReviewPageAverageRating().invoke('text').should('include', `Neutral`);
        acePage.completedReviewPageNeutralRatingButton().trigger('mouseover');
        acePage.markForReviewPopup().should('be.visible').should('have.text', 'Neutral');
        acePage.completedReviewPageNeutralRatingButton().last().trigger('mouseout');
        acePage.completeReviewConfirmationPopupWindow().should('be.visible').click();
        acePage.caseReviewMessageContainer().should('be.visible').and('contain', `You completed a case review for ${agentName}!`);
        acePage.completedSummaryPageAverageRating().invoke('text').should('include', `Neutral`);
        acePage.completedReviewPublishedTitle().should('be.visible').and('contain', `Would you like to review more cases for this agent?`);
        acePage.aceCaseSummaryCloseButton().click();
        supportHub.closeButton().click();
      });
      cy.waitForLoaders();
      // since there is page loading , adding hard wait
      // eslint-disable-next-line cypress/no-unnecessary-waiting
      cy.wait(3000);
      acePage.reviewListCaseCard(this.caseId).click();
      cy.waitForLoaders();
      supportHub.baseContainer().should('be.visible');
      cy.waitForLoaders();
      acePage.viewCaseReviewButton().should('be.visible').and('contain', `View case review`);
      acePage.viewCaseReviewButton().click();
      acePage.caseReviewDetailsEditButton().should('be.visible').and('contain', `Edit review`);
      acePage.caseReviewDetailsEditButton().click();
      cy.waitForLoaders();
      acePage.badRatingButton().click({ multiple: true });
      // eslint-disable-next-line cypress/no-unnecessary-waiting
      cy.wait(1000);
      acePage.nextReviewConfirmationPopupWindow().should('be.visible').click();
      // eslint-disable-next-line cypress/no-unnecessary-waiting
      cy.wait(1000);
      acePage.completedReviewPageAverageRating().invoke('text').should('include', `Bad`);
      acePage.completedReviewPageBadRatingButton().trigger('mouseover');
      acePage.markForReviewPopup().should('be.visible').should('have.text', 'Bad');
      acePage.completedReviewPageBadRatingButton().trigger('mouseout');
      acePage.completeReviewConfirmationPopupWindow().should('be.visible').click();
      acePage.caseReviewMessageContainer().should('be.visible').and('contain', `You completed a case review for ${agentName}!`);
      acePage.completedSummaryPageAverageRating().invoke('text').should('include', `Bad`);
      acePage.completedReviewPublishedTitle().should('be.visible').and('contain', `Would you like to review more cases for this agent?`);
      acePage.aceCaseSummaryCloseButton().click();
      supportHub.closeButton().click();
    });
  });
});
