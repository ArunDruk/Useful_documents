import { urlHelpers } from '../../../../utils';
import { acePage, apiHelpers, agentInsights, datePicker, globalSearch, supportHub } from '../../../../pages';

describe('ACE - Agent insight page verify', () => {
  beforeEach(() => {
    cy.intercept('POST', 'search/subjects/_search/').as('globalSearch');
    cy.loginByApi();
    apiHelpers.clearAgentFilterInACEPage();
    cy.visit(urlHelpers.caseEvaluation);
    cy.waitForLoaders();

    acePage
      .recommendedContainerHeader()
      .invoke('text')
      .then((headerText) => {
        if (headerText === '0Recommended') {
          acePage.recommendedSidebarExpandButton().click();
          datePicker.datePickerTrigger().eq(0).click();
          datePicker.selectLastMonthWithOption(3);
          datePicker.datePickerTrigger().eq(0).should('have.text', 'Last 3 months');
          cy.waitForLoaders();
        }
      });
    acePage
      .recommendedSidebarCaseIDs()
      .eq(1)
      .invoke('attr', 'data-testid')
      .then((attrVal) => {
        cy.wrap(attrVal.split('-')[4]).as('caseId');
      });
  });

  /*
   * Under recommendation tab,Open any ticket.
   * Click on "Start Review" button.
   * Validate agent name should be displayed in review page same as in agent insight page.
   * Validate case details[ case status, priority, caseid] should be same as in agent insight page.
   */
  it('C6770: Verify the display of correct agent and case details in same page review', { tags: ['ACE', 'staging'] }, function agentCaseDetails() {
    acePage.recommendedCaseCard(this.caseId).click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
    supportHub.caseOwnerLabel().then((buttonTextFirst) => {
      const agentName = buttonTextFirst.text();
      acePage.startReviewButton().click();
      cy.waitForLoaders();

      acePage.reviewPageCaseId().then((buttonTextSecond) => {
        const caseId = buttonTextSecond.text();

        acePage.reviewPageCaseFieldPriority().then((buttonTextThird) => {
          const priorityLabel = buttonTextThird.text();

          acePage.reviewPageCaseFieldStatus().then((buttonTextFourth) => {
            const caseStatus = buttonTextFourth.text();

            supportHub.closeButton().click();

            cy.visit(urlHelpers.agentInsights.home);
            agentInsights.agentInsightsSearchFieldInput().click().type(agentName);
            agentInsights.agentSearchResultList().first().click();
            agentInsights.agentNameInsightViewLabel().invoke('text').should('eq', agentName);
            globalSearch.globalSearchButton().click();
            globalSearch.globalSearchInput().type(caseId);
            cy.wait('@globalSearch');
            globalSearch.globalSearchResultListItem().first().click();
            cy.waitForLoaders({ waitForGlobalLoader: true });
            supportHub.baseContainer().should('be.visible');
            supportHub.caseOwnerLabel().invoke('text').should('be.equal', agentName);
            supportHub.caseIdLabel().invoke('text').should('be.equal', caseId);
            supportHub.caseFieldStatusLabel().invoke('text').should('be.equal', caseStatus);
            supportHub.caseFieldPriorityLabel().invoke('text').should('be.equal', priorityLabel);
          });
          supportHub.closeButton().click();
        });
      });
    });
  });

  /*
   * Under recommendation tab,Open any ticket.
   * Click on "Start Review" button.
   * Validate case insight value details should be same as in agent insight page Support Hub .
   */
  it('C13300: Verify the display of correct agent insight details in same page review', { tags: ['ACE', 'staging'] }, function agentInsightDetails() {
    acePage.recommendedCaseCard(this.caseId).click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
    supportHub.caseOwnerLabel().then((buttonTextFirst) => {
      const agentName = buttonTextFirst.text();
      acePage.startReviewButton().then(() => {
        acePage.startReviewButton().click();
        cy.waitForLoaders();
        acePage.reviewPageCaseId().then((buttonTextSecond) => {
          const caseId = buttonTextSecond.text();
          acePage.reviewPageAgentNameHeader().find('svg').click();
          acePage
            .reviewPageCaseInsightListItem()
            .eq(0)
            .then((buttonTextThird) => {
              const insightValueFirst = buttonTextThird.text();
              acePage
                .reviewPageCaseInsightListItem()
                .eq(3)
                .then((buttonTextFifth) => {
                  const insightValueThird = buttonTextFifth.text();
                  acePage
                    .reviewPageCaseInsightListItem()
                    .eq(4)
                    .then((buttonTextSixth) => {
                      const insightValueFourth = buttonTextSixth.text();
                      supportHub.closeButton().click();
                      cy.visit(urlHelpers.agentInsights.home);
                      agentInsights.agentInsightsSearchFieldInput().click().type(agentName);
                      agentInsights.agentSearchResultList().first().click();
                      agentInsights.agentNameInsightViewLabel().invoke('text').should('eq', agentName);
                      globalSearch.globalSearchButton().click();
                      globalSearch.globalSearchInput().type(caseId);
                      cy.wait('@globalSearch');
                      globalSearch.globalSearchResultListItem().first().click();
                      cy.waitForLoaders({ waitForGlobalLoader: true });
                      // cy.waitForLoaders();
                      supportHub.baseContainer().should('be.visible');
                      supportHub.caseInsightListItem().eq(0).invoke('text').should('includes', insightValueFirst);
                      supportHub.caseInsightListItem().eq(2).invoke('text').should('includes', insightValueThird);
                      supportHub.caseInsightListItem().eq(3).invoke('text').should('includes', insightValueFourth);
                    });
                  supportHub.closeButton().click();
                });
            });
        });
      });
    });
  });
});
