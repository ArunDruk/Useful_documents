import { urlHelpers } from '../../../../utils';
import { acePage, apiHelpers, datePicker, navBar, supportHub } from '../../../../pages';

describe('ACE - Verify Review Details Page, Order of category', () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.clearAgentFilterInACEPage();
    cy.visit(urlHelpers.aceQaScorecards);
    acePage.creatingSingleChecklistWithSixRatings();
    cy.waitForLoaders();
    // To avoid checklist page crashing issue currently using navbar flow tracking via-SLC-30928
    navBar.agentCoaching().click();
    cy.waitForLoaders();

    acePage
      .recommendedContainerHeader()
      .invoke('text')
      .then((headerText) => {
        if (headerText === '0Recommended') {
          acePage.recommendedSidebarExpandButton().click();
          datePicker.datePickerTrigger().eq(0).click();
          datePicker.selectLastMonthWithOption(3);
          datePicker.datePickerTrigger().eq(0).should('have.text', 'Last 3 months');
          cy.waitForLoaders();
        }
      });

    acePage
      .recommendedSidebarCaseIDs()
      .eq(0)
      .invoke('attr', 'data-testid')
      .then((attrVal) => {
        cy.wrap(attrVal.split('-')[4]).as('caseId');
      });
  });

  /*
   * Under recommendation tab,Open any ticket.
   * Click on 'Start Review' button.
   * Validate the color of all the ratings in the page.
   * Validate that after selected it border color should be changed.
   * Click next button, Validate the color of all the ratings in the summary page.
   * Click Completed review button, Validate the Overrall average rating should be displayed.
   * Validate that 'You completed a case review for respective agent name should be displayed.
   */
  it('C37657: Validate that rating are highlighted and color validations in same page review', { tags: '@PublishChecklist' }, function ratingColorVerify() {
    acePage.recommendedCaseCard(this.caseId).click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
    supportHub.caseOwnerLabel().then((buttonTextFirst) => {
      const agentName = buttonTextFirst.text();
      acePage.startReviewButton().then(() => {
        acePage.startReviewButton().click();
        cy.waitForLoaders();
        acePage.poorRatingButton().eq(0).and('have.css', 'color', 'rgb(157, 8, 8)');
        acePage.badRatingButton().eq(1).and('have.css', 'color', 'rgb(239, 173, 67)');
        acePage.neutralRatingButton().eq(2).and('have.css', 'color', 'rgb(172, 140, 88)');
        acePage.goodRatingButton().eq(3).and('have.css', 'color', 'rgb(69, 171, 40)');
        acePage.greatRatingButton().eq(4).and('have.css', 'color', 'rgb(61, 140, 39)');
        acePage.notApplicableRatingButton().eq(5).and('have.css', 'color', 'rgb(74, 74, 74)');

        acePage.poorRatingButton().eq(0).and('have.css', 'border-bottom-color', 'rgba(0, 0, 0, 0)').click();
        acePage.badRatingButton().eq(1).and('have.css', 'border-bottom-color', 'rgba(0, 0, 0, 0)').click();
        acePage.neutralRatingButton().eq(2).and('have.css', 'border-bottom-color', 'rgba(0, 0, 0, 0)').click();
        acePage.goodRatingButton().eq(3).and('have.css', 'border-bottom-color', 'rgba(0, 0, 0, 0)').click();
        acePage.greatRatingButton().eq(4).and('have.css', 'border-bottom-color', 'rgba(0, 0, 0, 0)').click();
        acePage.notApplicableRatingButton().eq(5).and('have.css', 'border-bottom-color', 'rgba(0, 0, 0, 0)').click();

        acePage.poorRatingButton().eq(0).and('have.css', 'border-bottom-color', 'rgb(15, 188, 249)');
        acePage.badRatingButton().eq(1).and('have.css', 'border-bottom-color', 'rgb(15, 188, 249)');
        acePage.neutralRatingButton().eq(2).and('have.css', 'border-bottom-color', 'rgb(15, 188, 249)');
        acePage.goodRatingButton().eq(3).and('have.css', 'border-bottom-color', 'rgb(15, 188, 249)');
        acePage.greatRatingButton().eq(4).and('have.css', 'border-bottom-color', 'rgb(15, 188, 249)');
        acePage.notApplicableRatingButton().eq(5).and('have.css', 'border-bottom-color', 'rgb(15, 188, 249)');
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(1000);
        acePage.nextReviewConfirmationPopupWindow().should('be.visible').click();
        cy.waitForLoaders();

        acePage.completedReviewPageAverageRating().invoke('text').should('include', `Neutral`);
        acePage.completedReviewPagePoorRatingButton().should('have.css', 'color', 'rgb(157, 8, 8)');
        acePage.completedReviewPageBadRatingButton().should('have.css', 'color', 'rgb(239, 173, 67)');
        acePage.completedReviewPageNeutralRatingButton().should('have.css', 'color', 'rgb(172, 140, 88)');
        acePage.completedReviewPageGoodRatingButton().last().should('have.css', 'color', 'rgb(69, 171, 40)');
        acePage.completedReviewPageGreatRatingButton().should('have.css', 'color', 'rgb(61, 140, 39)');
        acePage.completedReviewPageNotApplicableRatingButton().should('have.css', 'color', 'rgb(74, 74, 74)');
        acePage.completedReviewPagePoorRatingButton().trigger('mouseover');
        acePage.markForReviewPopup().should('be.visible').should('have.text', 'Poor');
        acePage.completedReviewPagePoorRatingButton().trigger('mouseout');

        acePage.completedReviewPageBadRatingButton().last().trigger('mouseover');
        acePage.markForReviewPopup().should('be.visible').should('have.text', 'Bad');
        acePage.completedReviewPageBadRatingButton().trigger('mouseout');

        acePage.completedReviewPageNeutralRatingButton().last().trigger('mouseover');
        acePage.markForReviewPopup().should('be.visible').should('have.text', 'Neutral');
        acePage.completedReviewPageNeutralRatingButton().last().trigger('mouseout');

        acePage.completedReviewPageGoodRatingButton().trigger('mouseover');
        acePage.markForReviewPopup().should('be.visible').should('have.text', 'Good');
        acePage.completedReviewPageGoodRatingButton().trigger('mouseout');

        acePage.completedReviewPageGreatRatingButton().trigger('mouseover');
        acePage.markForReviewPopup().should('be.visible').should('have.text', 'Great');
        acePage.completedReviewPageGreatRatingButton().trigger('mouseout');

        acePage.completedReviewPageNotApplicableRatingButton().trigger('mouseover');
        acePage.markForReviewPopup().should('be.visible').should('have.text', 'Not Applicable');
        acePage.completedReviewPageNotApplicableRatingButton().trigger('mouseout');

        acePage.completeReviewConfirmationPopupWindow().should('be.visible').click();
        acePage.caseReviewMessageContainer().should('be.visible').and('contain', `You completed a case review for ${agentName}!`);
        acePage.completedSummaryPageAverageRating().invoke('text').should('include', `Neutral`);

        acePage.aceCaseSummaryCloseButton().click();
      });
    });
    supportHub.closeButton().click();
  });
});
