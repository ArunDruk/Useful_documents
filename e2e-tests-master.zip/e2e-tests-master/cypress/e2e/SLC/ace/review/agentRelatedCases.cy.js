import { urlHelpers } from '../../../../utils';
import { acePage, apiHelpers, datePicker, supportHub } from '../../../../pages';

describe('ACE - Agent Related Test Cases Verify', () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.clearAgentFilterInACEPage();
    cy.visit(urlHelpers.caseEvaluation);
    cy.waitForLoaders();

    acePage
      .recommendedContainerHeader()
      .invoke('text')
      .then((headerText) => {
        if (headerText === '0Recommended') {
          acePage.recommendedSidebarExpandButton().click();
          datePicker.datePickerTrigger().eq(0).click();
          datePicker.selectLastMonthWithOption(3);
          datePicker.datePickerTrigger().eq(0).should('have.text', 'Last 3 months');
          cy.waitForLoaders();
        }
      });

    acePage
      .recommendedSidebarCaseIDs()
      .eq(0)
      .invoke('attr', 'data-testid')
      .then((attrVal) => {
        cy.wrap(attrVal.split('-')[4]).as('caseId');
      });
  });

  /*
   * Under recommendation tab,Open any ticket.
   * Click on 'Start Review' button.
   * Give rating for all items and click on "Next"button.
   * Click on 'Complete Review' button, Validate 'Back to case', 'Review details', 'Download PDF' buttons.
   * Validate that agent name related cases displayed .
   * Click one ticket and validate same agent name dispalyed on it.
   */
  it('C6354: Verify same agent name related cases displayed on review details flow', { tags: ['ACE', 'staging'] }, function agentRelatedCases() {
    acePage.recommendedCaseCard(this.caseId).click();
    supportHub.caseOwnerLabel().then((labelText) => {
      const agentName = labelText.text();

      cy.waitForLoaders();
      supportHub.baseContainer().should('be.visible');
      cy.waitForLoaders();
      acePage.startReviewButton().then(() => {
        acePage.startReviewButton().click();
        cy.waitForLoaders();
        acePage.neutralRatingButton().click({ multiple: true });
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(1000);
        acePage.nextReviewConfirmationPopupWindow().should('be.visible').click();
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(1000);
        acePage.completeReviewConfirmationPopupWindow().should('be.visible').click();
        acePage.caseReviewSummaryPageBackToCaseButton().should('be.visible').and('contain', 'Back to case');
        acePage.caseReviewSummaryReviewDetailsButton().should('be.visible').and('contain', 'Review Details');
        acePage.caseReviewSummaryDownloadPdfButton().should('be.visible').and('contain', ' Download PDF');
        acePage.completedReviewPublishedTitle().should('be.visible').and('contain', `Would you like to review more cases for this agent?`);
        cy.waitForLoaders();
        acePage.completedReviewPublishedContainer().then(($ele) => {
          if ($ele.find('[data-testid="case-card-base-wrapper"]').length > 0) {
            acePage
              .completedReviewCaseCard()
              .first()
              .then(() => {
                acePage.completedReviewCaseCard().first().click();
                cy.waitForLoaders();
                supportHub.caseOwnerLabel().invoke('text').should('be.equal', agentName);
              });
          } else {
            acePage.completedReviewEmptyMessageTitle().should('be.visible').and('contain', `No recommendations found for this agent.`);
          }
        });
        acePage.aceCaseSummaryCloseButton().click();
      });
      supportHub.closeButton().click();
    });
  });
});
