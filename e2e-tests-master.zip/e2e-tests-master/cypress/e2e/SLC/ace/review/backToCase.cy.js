import { urlHelpers } from '../../../../utils';
import { acePage, apiHelpers, datePicker } from '../../../../pages';

beforeEach(() => {
  cy.loginByApi();
  apiHelpers.clearAgentFilterInACEPage();
  cy.visit(urlHelpers.caseEvaluation);
  cy.waitForLoaders();
  acePage
    .recommendedContainerHeader()
    .invoke('text')
    .then((headerText) => {
      if (headerText === '0Recommended') {
        acePage.recommendedSidebarExpandButton().click();
        datePicker.datePickerTrigger().eq(0).click();
        datePicker.selectLastMonthWithOption(3);
        datePicker.datePickerTrigger().eq(0).should('have.text', 'Last 3 months');
        cy.waitForLoaders();
      }
    });
});

/*
 * Open any ticket in ACE Recommended column
 * Click on "Start Review" button
 * Select rating for first 2 items under category 1
 * Click on "Back to Case" button
 * Click on "Continue Review" button
 * Verify that the previously selected rating is retained
 */
// This has the ACE checklist required for the below 2 test cases.
// So this should not be skipped. This is done to prevent crashing and this will updated once SLC-30928 is fixed
// When clicking on "Start Review" SH gets crashed,its tracked in SLC-30928
it('C6348: Verify the back to case workflow while reviewing a case', { tags: 'Ace' }, function backtocaseWorkflow() {
  acePage.recommendedCaseCard().eq(1).click();
  cy.waitForLoaders();

  // Starting review and selecting rating
  acePage.startReviewButton().click();
  cy.waitForLoaders();
  acePage.badRatingButton().click({ multiple: true });
  // eslint-disable-next-line cypress/no-unnecessary-waiting
  cy.wait(1000);
  acePage.backButtonInSamePageReview().click();

  acePage.startReviewButton().should('not.exist');
  acePage.continueReviewButton().should('be.visible').click();
  cy.waitForLoaders();

  //  Verifying the display of selected rating
  // Requested data-testid and data-status and its tracked in SLC-32654
  // Todo : Update the code once SLC-32654 is fixed
  acePage.badRatingSelectedInSamePageReview().should('be.visible');
});

/*
 * Open any ticket in ACE Recommended column
 * Click on "Start Review" button
 * Select rating for first 2 items under category 1
 * Click on "Cancel" button
 * Click on "Cancel" button in Cancel confirmation window
 * Verify that the previously selected rating is retained
 */
// When clicking on "Start Review" SH gets crashed,its tracked in SLC-30928
it('C6349: Verify the cancel workflow while canceling review process', { tags: 'Ace' }, function cancelingReviewCancelWorkflow() {
  acePage.recommendedCaseCard().eq(2).click();
  cy.waitForLoaders();

  // Starting review and selecting rating
  acePage.startReviewButton().click();
  cy.waitForLoaders();
  acePage.badRatingButton().click({ multiple: true });
  // eslint-disable-next-line cypress/no-unnecessary-waiting
  cy.wait(1000);
  acePage.cancelButtonInSamePageReview().click();
  acePage.cancelReviewConfirmationPopupWindow().should('be.visible');

  // Cancelling the review procress
  acePage.cancelButtonInCancelReviewConfirmationPopupWindow().click();
  // eslint-disable-next-line cypress/no-unnecessary-waiting
  cy.wait(3000);

  //  Verifying the display of selected rating
  // Requested data-testid and data-status and its tracked in SLC-32654
  // Todo : Update the code once SLC-32654 is fixed
  acePage.badRatingSelectedInSamePageReview().should('be.visible');
});

/*
 * Open any ticket in ACE Recommended column
 * Click on "Start Review" button
 * Select rating for first 2 items under category 1
 * Click on "Cancel" button
 * Click on "Submit/Ok" button in Cancel confirmation window
 * Click on "Start Review" button
 * Verify that the previously selected rating is not retained
 */
// When clicking on "Start Review" SH gets crashed,its tracked in SLC-30928
it('C6350: Verify the review canceling workflow', { tags: 'Ace' }, function cancelingReviewWorkflow() {
  acePage.recommendedCaseCard().eq(3).click();
  cy.waitForLoaders();
  acePage.startReviewButton().then(() => {
    acePage.startReviewButton().click();
    cy.waitForLoaders();
    acePage.badRatingButton().click({ multiple: true });
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    acePage.cancelButtonInSamePageReview().click();
    acePage.cancelReviewConfirmationPopupWindow().should('be.visible');
    // Cancelling the review process
    acePage.submitButtonInCancelReviewConfirmationPopupWindow().click();
    acePage.continueReviewButton().should('not.exist');
    acePage.startReviewButton().should('be.visible').click();
    cy.waitForLoaders();
    //  Verifying that the selected rating is not retained
    // Requested data-testid and data-status and its tracked in SLC-32654
    acePage.badRatingSelectedInSamePageReview().should('not.exist');
  });
});
