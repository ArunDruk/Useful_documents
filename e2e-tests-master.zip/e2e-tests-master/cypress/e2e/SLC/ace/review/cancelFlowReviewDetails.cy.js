import { urlHelpers } from '../../../../utils';
import { acePage, apiHelpers, datePicker, supportHub } from '../../../../pages';

describe('ACE - Review Details Page Cancel Flow', () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.clearAgentFilterInACEPage();
    apiHelpers.sortReviewedColumnByTimeInACEPage();
    cy.visit(urlHelpers.caseEvaluation);
    cy.waitForLoaders();

    acePage
      .recommendedContainerHeader()
      .invoke('text')
      .then((headerText) => {
        if (headerText === '0Recommended') {
          acePage.recommendedSidebarExpandButton().click();
          datePicker.datePickerTrigger().eq(0).click();
          datePicker.selectLastMonthWithOption(3);
          datePicker.datePickerTrigger().eq(0).should('have.text', 'Last 3 months');
          cy.waitForLoaders();
        }
      });
    acePage
      .recommendedSidebarCaseIDs()
      .eq(2)
      .invoke('attr', 'data-testid')
      .then((attrVal) => {
        cy.wrap(attrVal.split('-')[4]).as('caseId');
      });
  });

  /*
   * Under recommendation tab,Open any ticket.
   * Click on 'Start Review' button.
   * Give rating for all items and click on "Next"button.
   * Click on 'Complete Review' button and click 'Ok' in the pop up.
   * Validate that SH should be displayed with 'Start Review'.
   */
  it('C6791: Verify cancel workflow while editing review comments', { tags: ['ACE', 'staging'] }, function cancelEditingReview() {
    acePage.recommendedCaseCard(this.caseId).click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
    supportHub.caseOwnerLabel().then((buttonTextFirst) => {
      const agentName = buttonTextFirst.text();
      acePage.startReviewButton().then(() => {
        acePage.startReviewButton().click();
        cy.waitForLoaders();
        acePage.neutralRatingButton().click({ multiple: true });
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(1000);
        acePage.nextReviewConfirmationPopupWindow().should('be.visible').click();
        acePage.completeReviewConfirmationPopupWindow().should('be.visible').click();
        acePage.caseReviewMessageContainer().should('be.visible').and('contain', `You completed a case review for ${agentName}!`);
        acePage.caseReviewSummaryReviewDetailsButton().should('be.visible').click();
        acePage.caseReviewDetailsEditButton().should('be.visible').click();
        acePage.nextReviewConfirmationPopupWindow().should('be.visible');
        acePage.cancelButtonInSamePageReview().should('be.visible').click();
        acePage.submitButtonInCancelReviewConfirmationPopupWindow().should('be.visible').click();
        cy.waitForLoaders();
        acePage.startReviewButton().should('be.visible').and('contain', 'Start case review');
      });
      supportHub.closeButton().click();
    });
  });
});
