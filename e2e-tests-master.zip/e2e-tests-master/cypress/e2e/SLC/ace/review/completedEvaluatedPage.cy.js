import { urlHelpers } from '../../../../utils';
import { acePage, apiHelpers, datePicker, globalFilters, supportHub } from '../../../../pages';

describe('ACE - Completed Evaluated Page Validations', () => {
  beforeEach(() => {
    cy.intercept('POST', 'search/virtual_groups/_search*').as('agentSearch');
    cy.intercept('PUT', 'api/users/dashboard_settings').as('updateUserSettings');

    cy.loginByApi();
    apiHelpers.clearAgentFilterInACEPage();
    cy.visit(urlHelpers.caseEvaluation);

    cy.waitForLoaders();
    acePage
      .recommendedContainerHeader()
      .invoke('text')
      .then((headerText) => {
        if (headerText === '0Recommended') {
          acePage.recommendedSidebarExpandButton().click();
          datePicker.datePickerTrigger().eq(0).click();
          datePicker.selectLastMonthWithOption(3);
          datePicker.datePickerTrigger().eq(0).should('have.text', 'Last 3 months');
          cy.waitForLoaders();
        }
      });
  });

  /*
   * Under recommendation tab,Open any ticket.
   * Click on 'Start Review' button.
   * Give rating for all items and click on "Next"button.
   * Click on 'Complete Review' button,Go to completed evaluation column
   * Validate the display of Customer Name in the Customer column.
   */
  it('C6522: Verify the display of customer name in Completed Evaluation table', { tags: ['ACE', 'staging'] }, () => {
    acePage.recommendedCaseCard().first().click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
    supportHub.caseCustomerNameLabel().then((buttonTextFirst) => {
      const customerName = buttonTextFirst.text().trim();

      acePage.startReviewButton().then(() => {
        acePage.startReviewButton().click();
        cy.waitForLoaders();
        acePage.neutralRatingButton().should('be.visible').click({ multiple: true });
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(1000);
        acePage.nextReviewConfirmationPopupWindow().should('be.visible').click();
        acePage.completeReviewConfirmationPopupWindow().should('be.visible').click();
        acePage.aceCaseSummaryCloseButton().click();
        supportHub.closeButton().click();
      });
      acePage.completedEvaluationsTab().click();
      cy.waitForLoaders();
      acePage.completedEvaluationsTableCustomerColumn().scrollIntoView().should('be.visible').and('contain', customerName);
    });
  });

  /*
   * Under recommendation tab,Open any ticket,Noted the agent name
   * Click on 'Start Review' button,Complete the review
   * Go to completed evaluation tab.
   * Validate group by week Functionality in it.
   * Validate the agent we reviewed should be in the top of the table.
   */
  it('C6524: Verify the group by week Functionality in Completed Evaluation table', { tags: ['ACE', 'staging'] }, () => {
    acePage
      .commonAgentNameLabel()
      .first()
      .invoke('text')
      .then((agentName) => {
        acePage.recommendedCaseCard().first().click();
        cy.waitForLoaders();
        supportHub.baseContainer().should('be.visible');
        cy.waitForLoaders();
        acePage.startReviewButton().then(() => {
          acePage.startReviewButton().click();
          cy.waitForLoaders();
          acePage.neutralRatingButton().should('be.visible').click({ multiple: true });
          // eslint-disable-next-line cypress/no-unnecessary-waiting
          cy.wait(1000);
          acePage.nextReviewConfirmationPopupWindow().should('be.visible').click();
          // eslint-disable-next-line cypress/no-unnecessary-waiting
          cy.wait(1000);
          acePage.completeReviewConfirmationPopupWindow().should('be.visible').click();
          acePage.aceCaseSummaryCloseButton().click();
          supportHub.closeButton().click();
        });
        acePage.completedEvaluationsTab().click();
        cy.waitForLoaders();
        acePage.agentFilterButton().click();
        globalFilters.quickFilterSearchFieldInput().type(agentName);
        cy.wait('@agentSearch');
        globalFilters.quickFilterSearchResultList().first().find('input[type=checkbox]').click({ force: true });
        globalFilters.filterApplyButton().click();
        cy.wait('@updateUserSettings');
        acePage.groupByWeek();
        acePage.completedEvaluationsTableAgentColumnLists().then((agentLists) => {
          const agentCount = Cypress.$(agentLists).length;

          acePage.completedEvaluationsTableTicketsCountTitle().then((tableSectionTitle) => {
            const completedEvaluationCount = tableSectionTitle.text().split(' ')[0];

            acePage.dropdownText().should('be.visible').and('contain', 'Week');
            acePage.completedEvaluationsTableWeekGroupContainer().should('be.visible').and('contain', 'Week');
            acePage.completedEvaluationsTableAgentColumn().should('be.visible').and('contain', agentName);
            expect(agentCount).to.eq(parseInt(completedEvaluationCount, 10));
          });
        });
      });
  });

  /*
   * Under recommendation tab,Open any ticket,Noted the agent name
   * Click on 'Start Review' button,Complete the review
   * Go to completed evaluation tab.
   * Validate evaluater column should display 'Me' in the Evaluater column.
   * Validate evaluated column should display seconds / minutes ago in the Evaluated column.
   * Validate the ratings mentioned in the completed review page.
   * Validate the agent name and customer name.
   */
  it('C6526: Verify that display of details in Evaluated column', { tags: ['ACE', 'staging'] }, () => {
    acePage
      .commonAgentNameLabel()
      .first()
      .invoke('text')
      .then((agentName) => {
        acePage.recommendedCaseCard().first().click();
        cy.waitForLoaders();
        supportHub.baseContainer().should('be.visible');
        cy.waitForLoaders();
        supportHub.caseCustomerNameLabel().then((buttonTextFirst) => {
          const customerName = buttonTextFirst.text().trim();
          acePage.startReviewButton().then(() => {
            acePage.startReviewButton().click();
            cy.waitForLoaders();
            acePage.neutralRatingButton().should('be.visible').click({ multiple: true });
            // eslint-disable-next-line cypress/no-unnecessary-waiting
            cy.wait(1000);
            acePage.nextReviewConfirmationPopupWindow().should('be.visible').click();
            // eslint-disable-next-line cypress/no-unnecessary-waiting
            cy.wait(1000);
            acePage.completeReviewConfirmationPopupWindow().should('be.visible').click();
            acePage.aceCaseSummaryCloseButton().click();
            supportHub.closeButton().click();
          });
          acePage.completedEvaluationsTab().click();
          cy.waitForLoaders();
          acePage.agentFilterButton().click();
          globalFilters.quickFilterSearchFieldInput().type(agentName);
          cy.wait('@agentSearch');
          globalFilters.quickFilterSearchResultList().first().find('input[type=checkbox]').click({ force: true });
          globalFilters.filterApplyButton().click();
          cy.wait('@updateUserSettings');
          acePage.groupByWeek();
          cy.waitForLoaders();
          acePage.completedEvaluationsTableAgentColumn().should('be.visible').and('contain', agentName);
          acePage.completedEvaluationsTableEvaluaterColumn().should('be.visible').and('contain', 'Me');
          acePage
            .completedEvaluationsTableEvaluatedTimeColumn()
            .invoke('text')
            .should('match', /(seconds ago|minute ago)/);
          acePage.completedEvaluationsTableNeutralRatingColumn().trigger('mouseover');
          acePage.markForReviewPopup().should('be.visible').should('have.text', 'Neutral');
          acePage.completedEvaluationsTableNeutralRatingColumn().trigger('mouseout');
          acePage.completedEvaluationsTableCustomerColumn().should('be.visible').and('contain', customerName);
        });
      });
  });
});
