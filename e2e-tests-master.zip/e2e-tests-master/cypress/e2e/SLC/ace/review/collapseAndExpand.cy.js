import { creatingOneCategoryChecklistUI } from '../support';
import { urlHelpers } from '../../../../utils';
import { acePage, apiHelpers, datePicker, navBar, supportHub } from '../../../../pages';

describe('ACE - Validate Review Details Collapse all / Expand all', () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.clearAgentFilterInACEPage();
    cy.visit(urlHelpers.aceQaScorecards);
    creatingOneCategoryChecklistUI();
    cy.waitForLoaders();
    // To avoid checklist page crashing issue currently using navbar flow tracking via-SLC-30928
    navBar.agentCoaching().click();
    cy.waitForLoaders();

    acePage
      .recommendedContainerHeader()
      .invoke('text')
      .then((headerText) => {
        if (headerText === '0Recommended') {
          acePage.recommendedSidebarExpandButton().click();
          datePicker.datePickerTrigger().eq(0).click();
          datePicker.selectLastMonthWithOption(3);
          datePicker.datePickerTrigger().eq(0).should('have.text', 'Last 3 months');
          cy.waitForLoaders();
        }
      });
  });

  /*
   * Under recommendation tab,Open any ticket.
   * Click on 'Start Review' button.
   * Click on "Collapse All"  button, Validate that all the categories of the checklist should be collapsed.
   * 'Not reviewed' text displayed in the top right corner.
   * Click on "Expand All"  button, Validate that all the categories of the checklist should be Expanded.
   * 'No comments' text displayed under first description.
   */
  it('C6343: Verify the ability to collapse all/expand all in review page', { tags: '@PublishChecklist' }, function collapseExpand() {
    acePage.recommendedCaseCard().eq(0).click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
    acePage.startReviewButton().then(() => {
      acePage.startReviewButton().click();
      cy.waitForLoaders();
      acePage.reviewPageCategoryCommentsArea().should('be.visible').and('contain', 'No comments');
      acePage.reviewPageCollapseAllButton().click();
      acePage.reviewPageCategoryHeader().should('be.visible').and('contain', 'Not reviewed');
      acePage.reviewPageCollapseAllButton().click();
      acePage.reviewPageCategoryCommentsArea().should('be.visible').and('contain', 'No comments');
    });
    supportHub.closeButton().click();
  });
});
