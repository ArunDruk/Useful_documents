import { urlHelpers } from '../../../../utils';
import { acePage, apiHelpers, datePicker, navBar, supportHub } from '../../../../pages';

describe('ACE - Verify Review Details Page, Order of category', () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.clearAgentFilterInACEPage();
    cy.visit(urlHelpers.aceQaScorecards);
    acePage.creatingSingleChecklist();
  });

  /*
   * Navigate to "Evaluation Checklist" page and select "Current" tab.
   * Notice the category order.
   * Navigate to ACE module and Start review for a ticket
   * Validate that category order is same in the current tab "Evaluation Checklist" page.
   */
  it('C6468: Verify the order of category is same', { tags: '@PublishChecklist' }, () => {
    acePage.checklistHeaderTitle().then((buttonTextFirst) => {
      const titleName = buttonTextFirst.text().trim();
      acePage
        .checklistItemTitle()
        .eq(0)
        .then((buttonTextSecond) => {
          const itemNameFirst = buttonTextSecond.text().trim();
          acePage
            .checklistItemTitle()
            .eq(1)
            .then((buttonTextThird) => {
              const itemNameSecond = buttonTextThird.text().trim();
              acePage
                .checklistItemTitle()
                .eq(2)
                .then((buttonTextFourth) => {
                  const itemNameThird = buttonTextFourth.text().trim();

                  // To avoid checklist page crashing issue currently using navbar flow tracking via-SLC-30928
                  navBar.agentCoaching().click();
                  cy.waitForLoaders();
                  acePage
                    .recommendedContainerHeader()
                    .invoke('text')
                    .then((headerTitle) => {
                      if (headerTitle === '0Recommended') {
                        acePage.recommendedSidebarExpandButton().click();
                        datePicker.datePickerTrigger().eq(0).click();
                        datePicker.selectLastMonthWithOption(3);
                        datePicker.datePickerTrigger().eq(0).should('have.text', 'Last 3 months');
                        cy.waitForLoaders();
                      }
                    });
                  cy.waitForLoaders();

                  acePage.recommendedCaseCard().first().click();
                  cy.waitForLoaders();
                  supportHub.baseContainer().should('be.visible');
                  cy.waitForLoaders();
                  acePage.startReviewButton().then(() => {
                    acePage.startReviewButton().click();
                    cy.waitForLoaders();
                    acePage.categoryTitleTextInSamePageReview().invoke('text').should('include', titleName);
                    acePage.categoryChecklistItemInSamePageReview().eq(0).invoke('text').should('include', itemNameFirst);
                    acePage.categoryChecklistItemInSamePageReview().eq(1).invoke('text').should('include', itemNameSecond);
                    acePage.categoryChecklistItemInSamePageReview().eq(2).invoke('text').should('include', itemNameThird);
                  });
                });
            });
          supportHub.closeButton().click();
        });
    });
  });

  /*
   * Under recommendation tab,Open any ticket.
   * Click on 'Start Review' button.
   * Validate that,while hovering over any of the ratings it should show the tooltip for the rating.
   * Complete the review and validate the same in the complete review details page too.
   */
  it('C6347: Verify tool tip for ratings in same page review page while hovering', { tags: ['ACE', 'staging'] }, () => {
    // To avoid checklist page crashing issue currently using navbar flow tracking via-SLC-30928
    navBar.agentCoaching().click();
    cy.waitForLoaders();
    acePage
      .recommendedContainerHeader()
      .invoke('text')
      .then((headerText) => {
        if (headerText === '0Recommended') {
          acePage.recommendedSidebarExpandButton().click();
          datePicker.datePickerTrigger().eq(0).click();
          datePicker.selectLastMonthWithOption(3);
          datePicker.datePickerTrigger().eq(0).should('have.text', 'Last 3 months');
          cy.waitForLoaders();
        }
      });
    acePage.recommendedCaseCard().first().click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
    acePage.startReviewButton().then(() => {
      acePage.startReviewButton().click();
      cy.waitForLoaders();
      acePage.poorRatingButton().first().trigger('mouseover');
      acePage.markForReviewPopup().should('be.visible').should('have.text', 'Poor');
      acePage.poorRatingButton().first().trigger('mouseout');
      acePage.badRatingButton().first().trigger('mouseover');
      acePage.markForReviewPopup().should('be.visible').should('have.text', 'Bad');
      acePage.badRatingButton().first().trigger('mouseout');
      acePage.neutralRatingButton().first().trigger('mouseover');
      acePage.markForReviewPopup().should('be.visible').should('have.text', 'Neutral');
      acePage.neutralRatingButton().first().trigger('mouseout');
      acePage.goodRatingButton().first().trigger('mouseover');
      acePage.markForReviewPopup().should('be.visible').should('have.text', 'Good');
      acePage.goodRatingButton().first().trigger('mouseout');
      acePage.greatRatingButton().first().trigger('mouseover');
      acePage.markForReviewPopup().should('be.visible').should('have.text', 'Great');
      acePage.greatRatingButton().first().trigger('mouseout');
      acePage.notApplicableRatingButton().first().trigger('mouseover');
      acePage.markForReviewPopup().should('be.visible').should('have.text', 'Not Applicable');
      acePage.notApplicableRatingButton().first().trigger('mouseout');
      // eslint-disable-next-line cypress/no-unnecessary-waiting
      cy.wait(500);
      acePage.badRatingButton().eq(0).click();
      acePage.goodRatingButton().eq(1).click();
      acePage.greatRatingButton().eq(2).click();
      // eslint-disable-next-line cypress/no-unnecessary-waiting
      cy.wait(500);
      acePage.nextReviewConfirmationPopupWindow().should('be.visible').click();
      cy.waitForLoaders();
      acePage.completedReviewPageBadRatingButton().trigger('mouseover');
      acePage.markForReviewPopup().should('have.text', 'Bad');
      acePage.badRatingButton().last().trigger('mouseout');
      acePage.completedReviewPageGoodRatingButton().trigger('mouseover');
      acePage.markForReviewPopup().should('have.text', 'Good');
      acePage.goodRatingButton().last().trigger('mouseout');
      acePage.completedReviewPageGreatRatingButton().trigger('mouseover');
      acePage.markForReviewPopup().should('have.text', 'Great');
      acePage.greatRatingButton().last().trigger('mouseout');
      acePage.aceCaseSummaryCloseButton().click();
    });
    supportHub.closeButton().click();
  });
});
