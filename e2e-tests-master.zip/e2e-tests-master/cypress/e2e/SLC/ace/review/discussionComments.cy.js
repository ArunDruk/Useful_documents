import { randId, urlHelpers } from '../../../../utils';
import { acePage, apiHelpers, datePicker, supportHub } from '../../../../pages';

describe('ACE- Discussion comment validations', () => {
  beforeEach(function beforeEachHook() {
    cy.loginByApi();
    apiHelpers.clearAgentFilterInACEPage();
    cy.visit(urlHelpers.caseEvaluation);
    cy.waitForLoaders();

    acePage
      .recommendedContainerHeader()
      .invoke('text')
      .then((headerText) => {
        if (headerText === '0Recommended') {
          acePage.recommendedSidebarExpandButton().click();
          datePicker.datePickerTrigger().eq(0).click();
          datePicker.selectLastMonthWithOption(3);
          datePicker.datePickerTrigger().eq(0).should('have.text', 'Last 3 months');
          cy.waitForLoaders();
        }
      });

    acePage
      .recommendedSidebarCaseIDs()
      .eq(0)
      .invoke('attr', 'data-testid')
      .then((attrVal) => {
        const caseId = attrVal.split('-')[4];

        cy.wrap(caseId).as('caseId');
        acePage.recommendedCaseCard(caseId).then(() => {
          acePage.recommendedCaseCard(caseId).click();
          cy.waitForLoaders();
          cy.get('#case-comments-annotations').then(($ele) => {
            if ($ele.find('[data-testid=supportHub-caseComments_annotation-header]').length > 0) {
              this.skip();
            }
            supportHub.closeButton().click();
          });
        });
      });
  });

  /*
   * Under recommendation tab,Open any ticket.
   * Highlight the text in case description.
   * Select discussion comment from the options.
   * Comment and cancel button should be displayed.
   * Add a comment, "comment" button should be enabled
   * Click on "Comment" button, Validate that added comment is displayed.
   * Validate that 'Today' text is displayed on the added comment.
   */
  it('C6400: Verify the discussion comment workflow', { tags: ['ace', 'staging'] }, function addingDiscussionComment() {
    const discussionCommentText = `Test discussion comment ${randId()}`;
    const targetCaseCommentIndex = -1;

    acePage.recommendedCaseCard(this.caseId).click();
    cy.waitForLoaders();
    supportHub.gotoCaseDescriptionButton().click();
    supportHub.selectCaseCommentText(targetCaseCommentIndex);
    supportHub.addAnnotationButton().click();
    supportHub.addAnnotationCancelButton().should('be.visible');
    supportHub.addAnnotationSendButton().should('be.disabled');
    supportHub.addAnnotationCommentTextarea().type(discussionCommentText);
    supportHub.addAnnotationSendButton().should('be.enabled');
    supportHub.addAnnotationSendButton().should('be.visible').click();
    cy.waitForLoaders();
    supportHub.annotationText().scrollIntoView().should('be.visible').and('contain', discussionCommentText);
    supportHub.annotationCreationDetailsField().invoke('text').should('includes', 'Today');
    supportHub.addAnnotationDeleteIcon().click({ force: true });
    supportHub.closeButton().click();
  });

  /*
   * Under recommendation tab,Open any ticket.
   * Highlight the text in case description.
   * Select discussion comment from the options.
   * Comment and cancel button should be displayed.
   * Add a comment, "comment" button should be enabled
   * Click on "Comment" button, Validate that added comment is displayed.
   * Add one more comment in the reply button, Validate that added reply is displayed.
   * Validate that recent added reply will display on the bottom.
   */
  it('C6401: Verify the multiple reply to discussion comment', { tags: ['ace', 'staging'] }, function addingMultiplyDiscussionComment() {
    const discussionCommentText = `Test discussion comment ${randId()}`;
    const discussionCommentSecondText = `Test discussion comment edited ${randId()}`;
    const targetCaseCommentIndex = -1;

    acePage.recommendedCaseCard(this.caseId).click();
    cy.waitForLoaders();
    supportHub.gotoCaseDescriptionButton().click();
    supportHub.selectCaseCommentText(targetCaseCommentIndex);
    supportHub.addAnnotationButton().click();
    supportHub.addAnnotationCommentTextarea().type(discussionCommentText);
    supportHub.addAnnotationSendButton().should('be.visible').click();
    cy.waitForLoaders();
    supportHub.annotationUserNameHeader().scrollIntoView().realHover('mouse');
    supportHub.addAnnotationTextarea().scrollIntoView().should('be.visible');
    supportHub.addAnnotationCancelButton().should('be.visible');
    supportHub.addAnnotationSendButton().should('be.disabled');
    supportHub.addAnnotationTextarea().type(discussionCommentSecondText);
    supportHub.addAnnotationSendButton().should('be.enabled').click();
    supportHub.annotationUserNameHeader().scrollIntoView().realHover('mouse');
    supportHub.annotationText().last().invoke('text').should('contains', discussionCommentSecondText);
    for (let i = 1; i >= 0; i -= 1) {
      supportHub.annotationText().eq(i).trigger('mouseover');
      supportHub.addAnnotationDeleteIcon().click({ force: true });
      cy.waitForLoaders();
    }
    supportHub.closeButton().click();
  });

  /*
   * Under recommendation tab,Open any ticket.
   * Highlight the text in case description.
   * Select discussion comment from the options.
   * Add a comment and click on "Comment" button.
   * Hover over the "Reply", Validate that delete icon should be displayed.
   * Click on the Delete Icon, Validate that reply should be deleted..
   */
  it('C6402: Verify the discussion comment delete workflow', { tags: ['ace', 'staging'] }, function deletingDiscussionComment() {
    const discussionCommentText = `Test discussion comment ${randId()}`;
    const targetCaseCommentIndex = -1;

    acePage.recommendedCaseCard(this.caseId).click();
    cy.waitForLoaders();
    supportHub.gotoCaseDescriptionButton().click();
    supportHub.selectCaseCommentText(targetCaseCommentIndex);
    supportHub.addAnnotationButton().click();
    supportHub.addAnnotationCancelButton().should('be.visible');
    supportHub.addAnnotationSendButton().should('be.disabled');
    supportHub.addAnnotationDeleteIcon().should('not.exist');
    supportHub.addAnnotationCommentTextarea().type(discussionCommentText);
    supportHub.addAnnotationSendButton().should('be.enabled');
    supportHub.addAnnotationSendButton().should('be.visible').click();
    cy.waitForLoaders();
    supportHub.annotationText().scrollIntoView().should('be.visible').and('contain', discussionCommentText);
    supportHub.addAnnotationDeleteIcon().should('exist');
    supportHub.addAnnotationDeleteIcon().scrollIntoView().click({ force: true });
    supportHub.addAnnotationDeleteIcon().click({ force: true });
    supportHub.annotationText().should('not.exist');
    supportHub.closeButton().click();
  });

  /*
   * Under recommendation tab,Open any ticket.
   * Highlight the text in case description.
   * Select discussion comment from the options.
   * Comment and cancel button should be displayed.
   * Add a comment, "comment" button should be enabled
   * Click on "Comment" button, Validate that added comment is displayed.
   * Add one more comment in the reply button, Validate that added reply is displayed.
   * Delete the reply, Validate that deleted reply not displayed.
   */
  it('C35797: Validate the workflow to delete the reply discussion comment', { tags: ['ace', 'staging'] }, function deleteDiscussionReply() {
    const discussionCommentText = `Test discussion comment ${randId()}`;
    const discussionCommentSecondText = `Test discussion comment edited ${randId()}`;
    const targetCaseCommentIndex = -1;

    acePage.recommendedCaseCard(this.caseId).click();
    cy.waitForLoaders();
    supportHub.gotoCaseDescriptionButton().click();
    supportHub.selectCaseCommentText(targetCaseCommentIndex);
    supportHub.addAnnotationButton().click();
    supportHub.addAnnotationCommentTextarea().type(discussionCommentText);
    supportHub.addAnnotationSendButton().should('be.visible').click();
    cy.waitForLoaders();
    supportHub.annotationUserNameHeader().scrollIntoView().realHover('mouse');
    supportHub.addAnnotationTextarea().scrollIntoView().should('be.visible');
    supportHub.addAnnotationCancelButton().should('be.visible');
    supportHub.addAnnotationSendButton().should('be.disabled');
    supportHub.addAnnotationTextarea().type(discussionCommentSecondText);
    supportHub.addAnnotationSendButton().should('be.enabled').click();
    supportHub.annotationUserNameHeader().scrollIntoView().realHover('mouse');
    supportHub.annotationText().last().invoke('text').should('contains', discussionCommentSecondText);

    supportHub.annotationText().eq(1).trigger('mouseover');
    supportHub.addAnnotationDeleteIcon().click({ force: true });
    cy.waitForLoaders();
    cy.get('body').should('not.contain', discussionCommentSecondText);
    cy.get('body').should('contain', discussionCommentText);
    supportHub.annotationText().eq(0).trigger('mouseover');
    supportHub.addAnnotationDeleteIcon().click({ force: true });
    cy.waitForLoaders();
    cy.get('body').should('not.contain', discussionCommentText);
    supportHub.closeButton().click();
  });
});
