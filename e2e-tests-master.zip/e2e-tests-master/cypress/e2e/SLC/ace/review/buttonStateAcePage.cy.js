import { urlHelpers } from '../../../../utils';
import { acePage, apiHelpers, datePicker, supportHub, globalFilters } from '../../../../pages';

describe('ACE - Button state for various status', () => {
  beforeEach(() => {
    cy.intercept('POST', 'search/virtual_groups/_search*').as('agentSearch');
    cy.intercept('PUT', 'api/users/dashboard_settings').as('updateUserSettings');
    cy.loginByApi();
    apiHelpers.clearAgentFilterInACEPage();
    apiHelpers.sortReviewedColumnByTimeInACEPage();
    cy.visit(urlHelpers.caseEvaluation);
    cy.waitForLoaders();

    acePage
      .recommendedContainerHeader()
      .invoke('text')
      .then((headerText) => {
        if (headerText === '0Recommended') {
          acePage.recommendedSidebarExpandButton().click();
          datePicker.datePickerTrigger().eq(0).click();
          datePicker.selectLastMonthWithOption(3);
          datePicker.datePickerTrigger().eq(0).should('have.text', 'Last 3 months');
          cy.waitForLoaders();
        }
      });

    acePage
      .recommendedSidebarCaseIDs()
      .eq(0)
      .invoke('attr', 'data-testid')
      .then((attrVal) => {
        cy.wrap(attrVal.split('-')[4]).as('caseId');
      });
  });

  afterEach(() => apiHelpers.clearAgentFilterInACEPage());

  /*
   * Under recommendation tab, click on "Mark for review" button.
   * Open the same ticket as previous step,Verify "Remove review" tooltip should be displayed on hovering.
   * Click on "Start ticket Review" button and close.
   *
   * Open the same ticket as previous step,Verify "Remove review" button should not be displayed next to "Continue review" button.
   * Click on "Start ticket Review" button and complete review.
   *
   * Open the same ticket as previous step, Verify "View ticket review" button should be displayed.
   * Also verify "Remove review"button should not  be displayed next to "View ticket review" button.
   */
  it('C26571: Verify button state for various status- Recommended flow', { tags: ['ACE', 'staging'] }, function buttonStatusRecommendationFlow() {
    acePage.recommendedCaseCard(this.caseId).click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
    supportHub.caseOwnerLabel().then((buttonTextFirst) => {
      const agentName = buttonTextFirst.text();
      supportHub.closeButton().click();

      acePage.agentFilterButton().click();
      globalFilters.quickFilterSearchFieldInput().type(agentName);
      cy.wait('@agentSearch');
      globalFilters.quickFilterSearchResultList().first().find('input[type=checkbox]').click({ force: true });
      globalFilters.filterApplyButton().click();
      cy.wait('@updateUserSettings');

      acePage.recommendedCaseCard(this.caseId).click();
      cy.waitForLoaders();
      supportHub.baseContainer().should('be.visible');
      cy.waitForLoaders();
      acePage.markForReviewButton().trigger('mouseover');
      acePage.markForReviewPopup().should('be.visible').should('have.text', 'Mark for review');
      acePage.markForReviewButton().click();
      supportHub.closeButton().click();
      cy.waitForLoaders();

      acePage.reviewListCaseCard(this.caseId).click();
      cy.waitForLoaders();
      acePage.unmarkForReviewButton().trigger('mouseover');
      acePage.markForReviewPopup().should('be.visible').should('have.text', 'Remove review');
      cy.waitForLoaders();
      acePage.startReviewButton().then(() => {
        acePage.startReviewButton().click();
        cy.waitForLoaders();
        acePage.nextReviewConfirmationPopupWindow().should('be.visible');
      });
      supportHub.closeButton().click();

      cy.waitForLoaders();
      acePage.reviewListCaseCard(this.caseId).click();
      supportHub.baseContainer().should('be.visible');
      acePage.unmarkForReviewButton().should('not.exist');
      cy.waitForLoaders();
      acePage.continueReviewButton().then(() => {
        acePage.continueReviewButton().click();
        cy.waitForLoaders();
      });
      acePage.goodRatingButton().click({ multiple: true });
      // eslint-disable-next-line cypress/no-unnecessary-waiting
      cy.wait(1000);
      acePage.nextReviewConfirmationPopupWindow().click();
      acePage.completeReviewConfirmationPopupWindow().click();
      acePage.aceCaseSummaryCloseButton().click();
      supportHub.closeButton().click();

      // since there is page loading , adding hard wait
      // eslint-disable-next-line cypress/no-unnecessary-waiting
      cy.wait(3000);
      acePage.reviewListCaseCard(this.caseId).click();
      acePage.viewCaseReviewButton().should('be.visible').not('Mark for review');
      acePage.viewCaseReviewButton().should('be.visible').contains('View case review');
      supportHub.closeButton().click();
    });
  });

  /*
   * Under recommendation tab, click on "Evaluate later" button.
   * Validate ticket should be moved to "To review" column.
   * Open the same ticket as previous step,Verify "Remove review" tooltip should be displayed on hovering.
   * Click on "Start ticket Review" button and close.
   *
   * Open the same ticket as previous step,Verify "Remove review" button should not be displayed next to "Continue review" button.
   * Click on "Start ticket Review" button and complete review.
   *
   * Open the same ticket as previous step, Verify "View ticket review" button should be displayed.
   * Also verify "Remove review"button should not  be displayed next to "View ticket review" button.
   */
  it('C9168: Verify button state for various status- Evaluate later flow', { tags: ['ACE', 'staging'] }, function buttonStatusEvaluaterLaterFlow() {
    const reviewListCaseId = `[data-testid="caseEvaluation-list-container-reviewList-${this.caseId}"]`;

    cy.waitForLoaders();
    acePage.recommendedCaseCard(this.caseId).click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
    supportHub.caseOwnerLabel().then((buttonTextFirst) => {
      const agentName = buttonTextFirst.text();
      supportHub.closeButton().click();

      acePage.agentFilterButton().click();
      globalFilters.quickFilterSearchFieldInput().type(agentName);
      cy.wait('@agentSearch');
      globalFilters.quickFilterSearchResultList().first().find('input[type=checkbox]').click({ force: true });
      globalFilters.filterApplyButton().click();
      cy.wait('@updateUserSettings');
      cy.waitForLoaders();

      acePage.recommendedContainer().find(`[data-testid="caseEvaluation-list-container-recommended-${this.caseId}"]`).should('exist');
      acePage.evaluateLaterListToggle().trigger('mouseover', { force: true });
      acePage.markForReviewPopup().should('have.text', 'Evaluate later');
      acePage.evaluateLaterListToggle().click({ force: true });
      cy.waitForLoaders();

      // since there is page loading , adding hard wait.
      // eslint-disable-next-line cypress/no-unnecessary-waiting
      cy.wait(3000);
      acePage.toReviewContainer().find(reviewListCaseId).should('exist');
      acePage.reviewListCaseCard(this.caseId).click();
      cy.waitForLoaders();
      acePage.unmarkForReviewButton().trigger('mouseover');
      acePage.markForReviewPopup().should('be.visible').and('have.text', 'Remove review');
      acePage.unmarkForReviewButton().trigger('mouseout');

      // eslint-disable-next-line cypress/no-unnecessary-waiting
      cy.wait(500);
      cy.waitForLoaders();
      acePage.startReviewButton().then(() => {
        acePage.startReviewButton().click();
        cy.waitForLoaders();
        acePage.nextReviewConfirmationPopupWindow().should('be.visible');
      });
      supportHub.closeButton().click();
      cy.waitForLoaders();

      // since there is page loading , adding hard wait.
      // eslint-disable-next-line cypress/no-unnecessary-waiting
      cy.wait(3000);
      acePage.inProgressContainer().find(reviewListCaseId).should('exist');
      acePage.reviewListCaseCard(this.caseId).click();
      cy.waitForLoaders();
      supportHub.baseContainer().should('be.visible');
      cy.waitForLoaders();
      acePage.unmarkForReviewButton().should('not.exist');
      cy.waitForLoaders();
      acePage.continueReviewButton().then(() => {
        acePage.continueReviewButton().click();
        cy.waitForLoaders();
      });
      acePage.goodRatingButton().click({ multiple: true });
      // eslint-disable-next-line cypress/no-unnecessary-waiting
      cy.wait(1000);
      acePage.nextReviewConfirmationPopupWindow().click();
      // eslint-disable-next-line cypress/no-unnecessary-waiting
      cy.wait(1000);
      acePage.completeReviewConfirmationPopupWindow().click();
      acePage.aceCaseSummaryCloseButton().click();
      supportHub.closeButton().click();
      cy.waitForLoaders();

      // since there is page loading , adding hard wait.
      // eslint-disable-next-line cypress/no-unnecessary-waiting
      cy.wait(3000);
      acePage.recentlyReviewedContainer().find(reviewListCaseId).should('exist');
      acePage.reviewListCaseCard(this.caseId).click();
      cy.waitForLoaders();
      acePage.viewCaseReviewButton().should('be.visible').and('not.have.text', 'Mark for review');
      acePage.viewCaseReviewButton().should('be.visible').and('contain', 'View case review');
      supportHub.closeButton().click();
    });
  });
});
