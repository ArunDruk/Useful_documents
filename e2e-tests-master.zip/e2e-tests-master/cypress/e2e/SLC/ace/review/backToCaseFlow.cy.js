import { urlHelpers } from '../../../../utils';
import { acePage, apiHelpers, datePicker, supportHub } from '../../../../pages';

describe('ACE - Review Page "Back to case" validations', () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.clearAgentFilterInACEPage();
    apiHelpers.sortReviewedColumnByTimeInACEPage();
    cy.visit(urlHelpers.caseEvaluation);
    cy.waitForLoaders();
    acePage
      .recommendedContainerHeader()
      .invoke('text')
      .then((headerText) => {
        if (headerText === '0Recommended') {
          acePage.recommendedSidebarExpandButton().click();
          datePicker.datePickerTrigger().eq(0).click();
          datePicker.selectLastMonthWithOption(3);
          datePicker.datePickerTrigger().eq(0).should('have.text', 'Last 3 months');
          cy.waitForLoaders();
        }
      });
    acePage
      .recommendedSidebarCaseIDs()
      .eq(3)
      .invoke('attr', 'data-testid')
      .then((attrVal) => {
        cy.wrap(attrVal.split('-')[4]).as('caseId');
      });
  });

  /*
   * Under recommendation tab,Open any ticket.
   * Click on 'Start Review' button.
   * Give rating for all items and click on "Next"button.
   * Click on 'Complete Review' button,Validate Complete review success page should displayed.
   * Validate the buttons [Back to cases, Review details, Download Review].
   * Validate the "Would you like to review more cases for this agent? " message should be displayed.
   * Click 'back to case' button, Validate the view case review button should display.
   */
  it('C6352: Verify the review success page "back to case" workflow', { tags: ['ACE', 'staging'] }, function backToCaseSuccessReviewPage() {
    acePage.recommendedCaseCard(this.caseId).click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
    supportHub.caseOwnerLabel().then((buttonTextFirst) => {
      const agentName = buttonTextFirst.text();
      acePage.startReviewButton().then(() => {
        acePage.startReviewButton().click();
        cy.waitForLoaders();
        acePage.neutralRatingButton().click({ multiple: true });
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(1000);
        acePage.nextReviewConfirmationPopupWindow().should('be.visible').click();
        acePage.completeReviewConfirmationPopupWindow().should('be.visible').click();
        acePage.caseReviewMessageContainer().should('be.visible').and('contain', `You completed a case review for ${agentName}!`);
        acePage.caseReviewSummaryPageBackToCaseButton().should('be.visible').and('contain', `Back to case`);
        acePage.caseReviewSummaryReviewDetailsButton().should('be.visible').and('contain', `Review Details`);
        acePage.caseReviewSummaryDownloadPdfButton().should('be.visible').and('contain', ` Download PDF`);
        acePage.completedReviewPublishedTitle().should('be.visible').and('contain', `Would you like to review more cases for this agent?`);
        acePage.caseReviewSummaryPageBackToCaseButton().click();
        acePage.viewCaseReviewButton().should('be.visible').and('contain', `View case review`);
      });
      supportHub.closeButton().click();
    });
  });
});
