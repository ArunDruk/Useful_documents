import { randId, urlHelpers } from '../../../../utils';
import { acePage, apiHelpers, datePicker, supportHub } from '../../../../pages';

describe('ACE -  Multiple review Comments validation', () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.clearAgentFilterInACEPage();
    cy.visit(urlHelpers.caseEvaluation);
    cy.waitForLoaders();

    acePage
      .recommendedContainerHeader()
      .invoke('text')
      .then((headerText) => {
        if (headerText === '0Recommended') {
          acePage.recommendedSidebarExpandButton().click();
          datePicker.datePickerTrigger().eq(0).click();
          datePicker.selectLastMonthWithOption(3);
          datePicker.datePickerTrigger().eq(0).should('have.text', 'Last 3 months');
          cy.waitForLoaders();
        }
      });

    acePage
      .recommendedSidebarCaseIDs()
      .eq(1)
      .invoke('attr', 'data-testid')
      .then((attrVal) => {
        cy.wrap(attrVal.split('-')[4]).as('caseId');
      });
  });

  /*
   * Under recommendation tab,Open any ticket.
   * Click on 'Start Review' button.
   * Highlight text in same page review,enter the text in the review comments text box.
   * Click comment button, Check the '1 comment is uncategorized' link is displayed.
   * Highlight text in same page review,enter the text in the review comments text box.
   * Click comment button, Check the '2 comment are uncategorized' link is displayed.
   * Click the link, Validate that added comments is displayed.
   */
  it('C37779: Verify the multiple review comment workflow with ONLY comments', { tags: ['ACE', 'staging'] }, function onlyCommentReviewComment() {
    const targetCaseCommentIndex = -1;
    const reviewCommentsFirstText = `Test review comment ${randId()}`;
    const reviewCommentsSecondText = `Test review second comment ${randId()}`;

    acePage.recommendedCaseCard(this.caseId).click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
    acePage.startReviewButton().then(() => {
      acePage.startReviewButton().click();
      cy.waitForLoaders();
      cy.get('#case-comments-annotations').then(($ele) => {
        if ($ele.find('[data-testid=ace-evaluation-review-comment-header]').length > 0) {
          this.skip();
        } else {
          supportHub.selectCaseCommentText(targetCaseCommentIndex);
          supportHub.reviewCommentHeader().last().scrollIntoView().should('be.visible').and('contain', `Review Comment`);
          supportHub.reviewCommentInput().type(reviewCommentsFirstText);
          supportHub.reviewCommentsSendButton().should('be.visible').click();
          cy.waitForLoaders();
          // eslint-disable-next-line cypress/no-unnecessary-waiting
          cy.wait(5000);
          acePage.reviewCommentTriggerLink().scrollIntoView().should('be.visible').and('contain', `1 comment is uncategorized`);
          supportHub.selectCaseCommentText(targetCaseCommentIndex);
          supportHub.reviewCommentHeader().last().scrollIntoView().should('be.visible').and('contain', `Review Comment`);
          supportHub.reviewCommentInput().type(reviewCommentsSecondText);
          supportHub.reviewCommentsSendButton().should('be.visible').click();
          cy.waitForLoaders();
          // eslint-disable-next-line cypress/no-unnecessary-waiting
          cy.wait(5000);
          acePage.reviewCommentTriggerLink().scrollIntoView().should('be.visible').and('contain', `2 comments are uncategorized`);
          acePage.reviewCommentTriggerLink().scrollIntoView().click();
          acePage.reviewCommentListText().should('be.visible').and('contain', `2 comments are uncategorized`);
          acePage.reviewCommentViewListText().first().invoke('text').should('contain', reviewCommentsSecondText);
          acePage.reviewCommentViewListText().last().invoke('text').should('contain', reviewCommentsFirstText);
          supportHub.reviewCommentDeleteButton().click({ multiple: true, force: true });
          supportHub.closeButton().click();
        }
      });
    });
  });

  /*
   * Under recommendation tab,Open any ticket.
   * Click on 'Start Review' button.
   * Highlight text in same page review,enter the text and select one category.
   * Click comment button, Check the '1 comment' link is displayed.
   * Highlight text in same page review,enter the text and select one category.
   * Click comment button, Check the '2 comment' link is displayed.
   * Click the link, Validate that added comments and category  is displayed.
   */
  it('C37780: Verify the multiple review comment workflow with ONLY comments and category', { tags: ['ACE', 'staging'] }, function withCategoryReviewComment() {
    const targetCaseCommentIndex = -1;
    const reviewCommentsFirstText = `Test review comment ${randId()}`;
    const reviewCommentsSecondText = `Test review second comment ${randId()}`;
    const categoryFirstTitle = `Testing Category 1`;

    acePage.recommendedCaseCard(this.caseId).click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
    acePage.startReviewButton().then(() => {
      acePage.startReviewButton().click();
      cy.waitForLoaders();
      cy.get('#case-comments-annotations').then(($ele) => {
        if ($ele.find('[data-testid=ace-evaluation-review-comment-header]').length > 0) {
          this.skip();
        } else {
          supportHub.selectCaseCommentText(targetCaseCommentIndex);
          // eslint-disable-next-line cypress/no-unnecessary-waiting
          cy.wait(500);
          supportHub.reviewCommentHeader().last().scrollIntoView().should('be.visible').and('contain', `Review Comment`);
          supportHub.reviewCommentInput().type(reviewCommentsFirstText);
          supportHub.reviewCommentDropdown().click();
          supportHub.reviewCommentsDropdown().eq(0).click({ force: true });
          supportHub.reviewCommentHeader().last().click();
          supportHub.reviewCommentsSendButton().should('be.visible').click();
          cy.waitForLoaders();
          acePage.reviewCommentTriggerLink().scrollIntoView().should('be.visible').and('contain', `1 comment`);
          supportHub.selectCaseCommentText(targetCaseCommentIndex);
          // eslint-disable-next-line cypress/no-unnecessary-waiting
          cy.wait(500);
          supportHub.reviewCommentHeader().last().scrollIntoView().should('be.visible').and('contain', `Review Comment`);
          supportHub.reviewCommentInput().type(reviewCommentsSecondText);
          supportHub.reviewCommentDropdown().click();
          supportHub.reviewCommentsDropdown().eq(0).click({ force: true });
          supportHub.reviewCommentHeader().last().click();
          supportHub.reviewCommentsSendButton().should('be.visible').click();
          cy.waitForLoaders();
          acePage.reviewCommentTriggerLink().scrollIntoView().should('be.visible').and('contain', `2 comments`);
          acePage.reviewCommentTriggerLink().scrollIntoView().click();
          acePage.reviewCommentListText().should('be.visible').and('contain', `2 comments for this category`);
          acePage.reviewCommentViewListText().first().invoke('text').should('contain', reviewCommentsSecondText);
          acePage.reviewCommentViewListText().last().invoke('text').should('contain', reviewCommentsFirstText);
          acePage.reviewCommentViewCategoryText().first().invoke('text').should('contain', categoryFirstTitle);
          acePage.reviewCommentViewCategoryText().last().invoke('text').should('contain', categoryFirstTitle);
          supportHub.reviewCommentDeleteButton().click({ multiple: true, force: true });
          supportHub.closeButton().click();
        }
      });
    });
  });
});
