import { randId, urlHelpers } from '../../../../utils';
import { acePage, apiHelpers, datePicker, navBar, supportHub } from '../../../../pages';

describe('ACE -  Comments error message validation', () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.clearAgentFilterInACEPage();
    cy.visit(urlHelpers.caseEvaluation);
    cy.waitForLoaders();

    acePage
      .recommendedContainerHeader()
      .invoke('text')
      .then((headerText) => {
        if (headerText === '0Recommended') {
          acePage.recommendedSidebarExpandButton().click();
          datePicker.datePickerTrigger().eq(0).click();
          datePicker.selectLastMonthWithOption(3);
          datePicker.datePickerTrigger().eq(0).should('have.text', 'Last 3 months');
          cy.waitForLoaders();
        }
      });

    acePage
      .recommendedSidebarCaseIDs()
      .eq(3)
      .invoke('attr', 'data-testid')
      .then((attrVal) => {
        cy.wrap(attrVal.split('-')[4]).as('caseId');
      });
  });

  /*
   * Under recommendation tab,Open any ticket.
   * Click on 'Start Review' button.
   * Highlight text in same page review
   * Review comment window should be displayed
   * Do not enter any text or select any emoji
   * Validate that error message 'Select an emoji or add a note to submit your review comment' is displayed.
   */
  it('C6783:  Verify the review comment workflow with ONLY category', { tags: ['ACE', 'staging'] }, function errorMessageWithCategory() {
    const targetCaseCommentIndex = -1;

    acePage.recommendedCaseCard(this.caseId).click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
    acePage.startReviewButton().then(() => {
      acePage.startReviewButton().click();
      cy.waitForLoaders();
      supportHub.selectCaseCommentText(targetCaseCommentIndex);
      supportHub.reviewCommentsSendButton().trigger('mouseover', { force: true });
      acePage.markForReviewPopup().should('have.text', 'Select an emoji or add a note to submit your review comment');
    });
    supportHub.closeButton().click();
  });

  /*
   * Under recommendation tab,Open any ticket.
   * Click on 'Start Review' button.
   * Highlight text in same page review,enter the text in the review comments text box.
   * Select one category  and click on comment button, Validate Enter text and category should be displayed
   * Give rating for all items and click on "Next"button.
   * Click on "Back to Review" button.edit/update the existing review comment and click on comment button.
   * Validate updated review  comment should be displayed in same page review
   * Click on next button, Validate updated review  comment should be displayed.
   */
  it('C6800: Verify the edit functionality in review window', { tags: ['ACE', 'staging'] }, function editReviewComment() {
    const targetCaseCommentIndex = -1;
    const reviewCommentsText = `Test review comment ${randId()}`;
    const reviewCommentsTextEdited = `Test review comment edited ${randId()}`;
    const categoryName = 'Testing Category 1';

    acePage.recommendedCaseCard(this.caseId).click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
    acePage.startReviewButton().then(() => {
      acePage.startReviewButton().click();
      cy.waitForLoaders();
      cy.get('#case-comments-annotations').then(($ele) => {
        if ($ele.find('[data-testid=ace-evaluation-review-comment-header]').length > 0) {
          this.skip();
        } else {
          supportHub.selectCaseCommentText(targetCaseCommentIndex);
          supportHub.reviewCommentHeader().last().scrollIntoView().should('be.visible').and('contain', `Review Comment`);
          supportHub.reviewCommentInput().type(reviewCommentsText);
          supportHub.reviewCommentDropdown().click();
          supportHub.reviewCommentsDropdown().eq(0).click({ force: true });
          supportHub.reviewCommentHeader().last().click();
          supportHub.reviewCommentsSendButton().should('be.visible').click();
          cy.waitForLoaders();
          supportHub.reviewPageCommentText().scrollIntoView().should('be.visible').and('contain', reviewCommentsText);
          supportHub.reviewPageCategoryText().scrollIntoView().should('be.visible').and('contain', categoryName);
          // eslint-disable-next-line cypress/no-unnecessary-waiting
          cy.wait(1000);
          acePage.badRatingButton().click({ multiple: true });
          // eslint-disable-next-line cypress/no-unnecessary-waiting
          cy.wait(1000);
          acePage.nextReviewConfirmationPopupWindow().should('be.visible').click();
          cy.waitForLoaders();
          supportHub.reviewSummaryCommentText().first().scrollIntoView().should('be.visible').and('contain', reviewCommentsText);
          supportHub.reviewSummaryCategoryText().first().scrollIntoView().should('be.visible').and('contain', categoryName);
          acePage.caseReviewSummaryPageBackToCaseButton().should('be.visible').click();
          supportHub.reviewPageCommentText().last().scrollIntoView().scrollIntoView().trigger('mouseover');
          supportHub.reviewCommentEditButton().click({ force: true });
          supportHub.reviewCommentInput().clear().type(reviewCommentsTextEdited);
          supportHub.reviewCommentsSendButton().should('be.visible').click();
          cy.waitForLoaders();
          supportHub.reviewPageCommentText().last().scrollIntoView().should('be.visible').and('contain', reviewCommentsTextEdited);
          // eslint-disable-next-line cypress/no-unnecessary-waiting
          cy.wait(1000);
          acePage.nextReviewConfirmationPopupWindow().should('be.visible').click();
          cy.waitForLoaders();
          supportHub.reviewSummaryCommentText().scrollIntoView().should('be.visible').and('contain', reviewCommentsTextEdited);
          acePage.aceCaseSummaryCloseButton().click();
        }
      });
      supportHub.closeButton().click();
    });
  });

  /*
   * Under recommendation tab,Open any ticket.
   * Click on 'Start Review' button.
   * Highlight text in same page review,enter the text in the review comments text box.
   * Select one category  and click on comment button, Validate Enter text and category should be displayed
   * Give rating for all items and click on "Next"button.
   * Click on "Back to Review" button.delete the existing review comment.
   * Validate review comment should be not displayed in same page review.
   * Click on next button, Validate review comment should be not displayed in same page review.
   */
  it('C6801: Verify the delete functionality in review window', { tags: ['ACE', 'staging'] }, function deleteReviewComment() {
    const targetCaseCommentIndex = -1;
    const reviewCommentsText = `Test review comment ${randId()}`;
    const categoryName = 'Testing Category 1';

    acePage.recommendedCaseCard(this.caseId).click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
    acePage.startReviewButton().then(() => {
      acePage.startReviewButton().click();
      cy.waitForLoaders();
      cy.get('#case-comments-annotations').then(($ele) => {
        if ($ele.find('[data-testid=ace-evaluation-review-comment-header]').length > 0) {
          this.skip();
        } else {
          supportHub.selectCaseCommentText(targetCaseCommentIndex);
          supportHub.reviewCommentHeader().last().scrollIntoView().should('be.visible').and('contain', `Review Comment`);
          supportHub.reviewCommentInput().type(reviewCommentsText);
          supportHub.reviewCommentDropdown().click();
          supportHub.reviewCommentsDropdown().eq(0).click({ force: true });
          supportHub.reviewCommentHeader().last().click();
          supportHub.reviewCommentsSendButton().should('be.visible').click();
          cy.waitForLoaders();
          supportHub.reviewPageCommentText().should('be.visible').and('contain', reviewCommentsText);
          supportHub.reviewPageCategoryText().should('be.visible').and('contain', categoryName);
          // eslint-disable-next-line cypress/no-unnecessary-waiting
          cy.wait(1000);
          acePage.badRatingButton().click({ multiple: true });
          // eslint-disable-next-line cypress/no-unnecessary-waiting
          cy.wait(1000);
          acePage.nextReviewConfirmationPopupWindow().should('be.visible').click();
          cy.waitForLoaders();
          supportHub.reviewSummaryCommentText().first().scrollIntoView().should('be.visible').and('contain', reviewCommentsText);
          supportHub.reviewSummaryCategoryText().first().scrollIntoView().should('be.visible').and('contain', categoryName);
          acePage.caseReviewSummaryPageBackToCaseButton().should('be.visible').click();
          supportHub.reviewPageCommentText().last().scrollIntoView().trigger('mouseover');
          supportHub.reviewCommentDeleteButton().click({ force: true });
          supportHub.reviewCommentsContainer().should('not.exist');
          acePage.nextReviewConfirmationPopupWindow().should('be.visible').click();
          cy.waitForLoaders();
          supportHub.reviewSummaryCommentText().should('not.exist');
          acePage.aceCaseSummaryCloseButton().click();
        }
      });
      supportHub.closeButton().click();
    });
  });

  /*
   * Under recommendation tab,Open any ticket.
   * Click on 'Start Review' button.
   * Highlight text in same page review,enter the text in the review comments text box.
   * Select one emoji  and click on comment button.
   * Click on '1 comment is uncategorized' link.
   * Validate selected emoji should be displayed.
   */
  it('C6778: Verify the review comment workflow with ONLY emoji', { tags: ['ACE', 'staging'] }, function emojiReviewComment() {
    const targetCaseCommentIndex = -1;

    acePage.recommendedCaseCard(this.caseId).click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
    acePage.startReviewButton().then(() => {
      acePage.startReviewButton().click();
      cy.waitForLoaders();
      cy.get('#case-comments-annotations').then(($ele) => {
        if ($ele.find('[data-testid=ace-evaluation-review-comment-header]').length > 0) {
          this.skip();
        } else {
          supportHub.selectCaseCommentText(targetCaseCommentIndex);
          supportHub.reviewCommentHeader().last().scrollIntoView().should('be.visible').and('contain', `Review Comment`);
          acePage.starEmojiButton().should('be.visible').click();
          supportHub.reviewCommentsSendButton().should('be.visible').click();
          cy.waitForLoaders();
          acePage.reviewCommentTriggerLink().scrollIntoView().should('be.visible').and('contain', `1 comment is uncategorized`);
          acePage.reviewCommentTriggerLink().scrollIntoView().click();
          acePage.reviewCommentListText().should('be.visible').and('contain', `1 comment is uncategorized`);
          acePage.starEmojiSelectedInSamePageReview().should('be.visible');
          supportHub.reviewCommentDeleteButton().click({ force: true });
          supportHub.closeButton().click();
        }
      });
    });
  });

  /*
   * Under recommendation tab,Open any ticket.
   * Click on 'Start Review' button.
   * Highlight text in same page review,enter the text in the review comments text box.
   * Click comment button, Check the '1 comment is uncategorized' link is displayed.
   * Click the link, Validate that added comments is displayed.
   */
  it('C6777: Verify the review comment workflow with ONLY comments', { tags: ['ACE', 'staging'] }, function onlyCommentReviewComment() {
    const targetCaseCommentIndex = -1;
    const reviewCommentsText = `Test review comment ${randId()}`;

    acePage.recommendedCaseCard(this.caseId).click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
    acePage.startReviewButton().then(() => {
      acePage.startReviewButton().click();
      cy.waitForLoaders();
      cy.get('#case-comments-annotations').then(($ele) => {
        if ($ele.find('[data-testid=ace-evaluation-review-comment-header]').length > 0) {
          this.skip();
        } else {
          supportHub.selectCaseCommentText(targetCaseCommentIndex);
          supportHub.reviewCommentHeader().last().scrollIntoView().should('be.visible').and('contain', `Review Comment`);
          supportHub.reviewCommentInput().type(reviewCommentsText);
          supportHub.reviewCommentsSendButton().should('be.visible').click();
          cy.waitForLoaders();
          acePage.reviewCommentTriggerLink().scrollIntoView().should('be.visible').and('contain', `1 comment is uncategorized`);
          acePage.reviewCommentTriggerLink().scrollIntoView().click();
          acePage.reviewCommentListText().should('be.visible').and('contain', `1 comment is uncategorized`);
          acePage.reviewCommentViewListText().invoke('text').should('contain', reviewCommentsText);
          supportHub.reviewCommentDeleteButton().click({ force: true });
          supportHub.closeButton().click();
        }
      });
    });
  });

  /*
   * Under recommendation tab,Open any ticket.
   * Click on 'Start Review' button.
   * Highlight text in same page review,enter the text and select one category.
   * Click comment button, Check the '1 comment' link is displayed.
   * Click the link, Validate that added comments and category  is displayed.
   */
  it('C6780: Verify the review comment workflow with ONLY comments and category', { tags: ['ACE', 'staging'] }, function withCategoryReviewComment() {
    const targetCaseCommentIndex = -1;
    const reviewCommentsText = `Test review comment ${randId()}`;

    acePage.recommendedCaseCard(this.caseId).click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
    acePage.startReviewButton().then(() => {
      acePage.startReviewButton().click();
      cy.waitForLoaders();
      cy.get('#case-comments-annotations').then(($ele) => {
        if ($ele.find('[data-testid=ace-evaluation-review-comment-header]').length > 0) {
          this.skip();
        } else {
          supportHub.selectCaseCommentText(targetCaseCommentIndex);
          // eslint-disable-next-line cypress/no-unnecessary-waiting
          cy.wait(500);
          supportHub.reviewCommentHeader().last().scrollIntoView().should('be.visible').and('contain', `Review Comment`);
          supportHub.reviewCommentInput().type(reviewCommentsText);
          supportHub.reviewCommentDropdown().click();
          acePage
            .categoryDropdownCheckboxLabel()
            .first()
            .then((categoryText) => {
              const categoryTitle = categoryText.text();

              supportHub.reviewCommentsDropdown().eq(0).click({ force: true });
              supportHub.reviewCommentHeader().last().click();
              supportHub.reviewCommentsSendButton().should('be.visible').click();
              cy.waitForLoaders();
              supportHub.reviewPageCommentText().scrollIntoView().should('be.visible').and('contain', reviewCommentsText);
              supportHub.reviewPageCategoryText().scrollIntoView().should('be.visible').and('contain', categoryTitle);
              acePage.reviewCommentTriggerLink().scrollIntoView().should('be.visible').and('contain', `1 comment`);
              acePage.reviewCommentTriggerLink().scrollIntoView().click();
              acePage.reviewCommentListText().should('be.visible').and('contain', `1 comment for this category`);
              acePage.reviewCommentViewListText().invoke('text').should('contain', reviewCommentsText);
              acePage.reviewCommentViewCategoryText().invoke('text').should('contain', categoryTitle);
              supportHub.reviewCommentDeleteButton().click({ force: true });
              supportHub.closeButton().click();
            });
        }
      });
    });
  });

  /*
   * Under recommendation tab,Open any ticket.
   * Click on 'Start Review' button.
   * Highlight text in same page review,enter the text in the review comments text box.
   * Select one emoji  and click on comment button.
   * Click on '1 comment is uncategorized' link.
   * Validate that comments is collapsed in a bubble.
   */
  it('C6793: Verify the comments is collapsed in a bubble', { tags: ['ACE', 'staging'] }, function reviewCommentCollapsed() {
    const targetCaseCommentIndex = -1;

    acePage.recommendedCaseCard(this.caseId).click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
    acePage.startReviewButton().then(() => {
      acePage.startReviewButton().click();
      cy.waitForLoaders();
      cy.get('#case-comments-annotations').then(($ele) => {
        if ($ele.find('[data-testid=ace-evaluation-review-comment-header]').length > 0) {
          this.skip();
        } else {
          supportHub.selectCaseCommentText(targetCaseCommentIndex);
          acePage.starEmojiButton().should('be.visible').click();
          supportHub.reviewCommentsSendButton().should('be.visible').click();
          cy.waitForLoaders();
          acePage.reviewCommentTriggerLink().scrollIntoView().click();
          acePage.bubbleViewedInSamePageReview().scrollIntoView().should('be.visible').should('exist');
          supportHub.reviewCommentDeleteButton().click({ force: true });
          supportHub.closeButton().click();
        }
      });
    });
  });

  /*
   * Under recommendation tab,Open any ticket.
   * Highlight the text in case description.
   * Select coaching feedback from the options.
   * Add a coaching feedback and click on "Comment" button
   * Click on 'Start Review' button.
   * Highlight text in same page review,enter the text in the review comments text box.
   * Click '1 comment is uncategorized', Validate the review comments is displayed.
   * Give rating for all items and click on "Next"button.
   * Validate that 'review comments' and 'Coaching feedback' added is displayed on the review summary page.
   */
  it('C6807: Verify the display of categorised review comments and feedback', { tags: ['ACE', 'staging'] }, function reviewCommentCoachingFeedback() {
    const targetCaseCommentIndex = -1;
    const coachingFeedbackText = `Test coaching feedback ${randId()}`;
    const reviewCommentsText = `Test review comment ${randId()}`;

    acePage.recommendedCaseCard(this.caseId).click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
    cy.get('#case-comments-annotations').then(($ele) => {
      if ($ele.find('[data-testid=supportHub-caseComments_coaching-content]').length > 0) {
        this.skip();
      } else {
        supportHub.gotoCaseDescriptionButton().click();
        supportHub.selectCaseCommentText(targetCaseCommentIndex);
        acePage.coachingFeedbackButton().click();
        acePage.coachingFeedbackTextbox().type(coachingFeedbackText);
        acePage.commentButtonInCoachingFeedbackWindow().click();
        acePage.addedCoachingFeedbackText().scrollIntoView().should('be.visible').and('contain', coachingFeedbackText);
        acePage.startReviewButton().then(() => {
          acePage.startReviewButton().click();
          cy.waitForLoaders();

          cy.get('#case-comments-annotations').then(($ele1) => {
            if ($ele1.find('[data-testid=ace-evaluation-review-comment-header]').length > 0) {
              this.skip();
            } else {
              supportHub.selectCaseCommentText(targetCaseCommentIndex);
              supportHub.reviewCommentHeader().last().scrollIntoView().should('be.visible').and('contain', `Review Comment`);
              supportHub.reviewCommentInput().type(reviewCommentsText);
              supportHub.reviewCommentsSendButton().should('be.visible').click();
              cy.waitForLoaders();

              acePage.reviewCommentTriggerLink().scrollIntoView().should('be.visible').and('contain', `1 comment is uncategorized`);
              acePage.reviewCommentTriggerLink().scrollIntoView().click();
              acePage.reviewCommentListText().should('be.visible').and('contain', `1 comment is uncategorized`);
              acePage.reviewCommentViewListText().invoke('text').should('contain', reviewCommentsText);

              acePage.goodRatingButton().click({ multiple: true });
              // eslint-disable-next-line cypress/no-unnecessary-waiting
              cy.wait(1000);
              acePage.nextReviewConfirmationPopupWindow().click();
              acePage.reviewSummaryCoachingFeedbackTitle().scrollIntoView().should('be.visible').and('contain', `Coaching feedback`);
              acePage.reviewSummaryCoachingFeedbackContent().scrollIntoView().should('be.visible').and('contain', coachingFeedbackText);
              acePage.reviewSummaryOtherCommentsTitle().scrollIntoView().should('be.visible').and('contain', `Other Review Comments`);
              acePage.reviewSummaryCategorySliderComment().scrollIntoView().should('be.visible').and('contain', reviewCommentsText);
              acePage.caseReviewSummaryPageBackToCaseButton().click();
              // eslint-disable-next-line cypress/no-unnecessary-waiting
              cy.wait(1000);
              acePage.coachingFeedbackMenuButton().click();
              acePage.coachingFeedbackDeleteButton().click();
              supportHub.reviewCommentDeleteButton().last().click({ force: true });
              supportHub.closeButton().click();
            }
          });
        });
      }
    });
  });

  /*
   * Under recommendation tab,Open any ticket.
   * Highlight the text in case description.
   * Select coaching feedback from the options.
   * Add a coaching feedback and click on "Comment" button
   * Click on 'Start Review' button.
   * Highlight text in same page review,enter the text in the review comments text box.
   * Click '1 comment is uncategorized', Validate the review comments is displayed.
   * Add some text in key take away text box.
   * Give rating for all items and click on "Next"button.
   * Validate that 'review comments', 'Key take away comments' and 'Coaching feedback' added is displayed on the review summary page.
   */
  it(
    'C6808: Verify the display of uncategorised review comments, category comment , Coaching feedback and Key take away notes',
    { tags: ['ACE', 'staging'] },
    function uncategorisedCommentReviewComment() {
      const targetCaseCommentIndex = -1;
      const coachingFeedbackText = `Test coaching feedback ${randId()}`;
      const reviewCommentsText = `Test review comment ${randId()}`;
      const keyTakeAwayCommentsText = `Test key take away comment ${randId()}`;

      acePage.recommendedCaseCard(this.caseId).click();
      cy.waitForLoaders();
      supportHub.baseContainer().should('be.visible');
      cy.waitForLoaders();
      cy.get('#case-comments-annotations').then(($ele) => {
        if ($ele.find('[data-testid=supportHub-caseComments_coaching-content]').length > 0) {
          this.skip();
        } else {
          supportHub.gotoCaseDescriptionButton().click();
          supportHub.selectCaseCommentText(targetCaseCommentIndex);
          acePage.coachingFeedbackButton().click();
          acePage.coachingFeedbackTextbox().type(coachingFeedbackText);
          acePage.commentButtonInCoachingFeedbackWindow().click();
          cy.waitForLoaders();
          acePage.addedCoachingFeedbackText().scrollIntoView().should('be.visible').and('contain', coachingFeedbackText);
          acePage.startReviewButton().then(() => {
            acePage.startReviewButton().click();
            cy.waitForLoaders();
            cy.get('#case-comments-annotations').then(($ele1) => {
              if ($ele1.find('[data-testid=ace-evaluation-review-comment-header]').length > 0) {
                this.skip();
              } else {
                supportHub.selectCaseCommentText(targetCaseCommentIndex);
                supportHub.reviewCommentHeader().last().scrollIntoView().should('be.visible').and('contain', `Review Comment`);
                supportHub.reviewCommentInput().type(reviewCommentsText);
                supportHub.reviewCommentsSendButton().should('be.visible').click();
                cy.waitForLoaders();
                acePage.reviewCommentTriggerLink().scrollIntoView().should('be.visible').and('contain', `1 comment is uncategorized`);
                acePage.reviewCommentTriggerLink().scrollIntoView().click();
                acePage.reviewCommentListText().should('be.visible').and('contain', `1 comment is uncategorized`);
                acePage.reviewCommentViewListText().invoke('text').should('contain', reviewCommentsText);
                // eslint-disable-next-line cypress/no-unnecessary-waiting
                cy.wait(1000);
                acePage.caseReviewPanelTitle().invoke('text').should('contain', 'Key takeaways ');
                acePage.goodRatingButton().click({ multiple: true });
                // eslint-disable-next-line cypress/no-unnecessary-waiting
                cy.wait(1000);
                acePage.reviewKeyTakeAwayInputTextbox().type(keyTakeAwayCommentsText);
                // eslint-disable-next-line cypress/no-unnecessary-waiting
                cy.wait(1000);
                acePage.nextReviewConfirmationPopupWindow().click();
                acePage.reviewSummaryKeyTakeAwayTitle().scrollIntoView().should('be.visible').and('contain', `Key takeaways `);
                acePage.reviewSummaryKeyTakeAwayContent().should('be.visible').and('contain', keyTakeAwayCommentsText);
                acePage.reviewSummaryCoachingFeedbackTitle().scrollIntoView().should('be.visible').and('contain', `Coaching feedback`);
                acePage.reviewSummaryCoachingFeedbackContent().scrollIntoView().should('be.visible').and('contain', coachingFeedbackText);
                acePage.reviewSummaryOtherCommentsTitle().last().scrollIntoView().should('be.visible').and('contain', `Other Review Comments`);
                acePage.reviewSummaryCategorySliderComment().last().scrollIntoView().should('be.visible').and('contain', reviewCommentsText);
                acePage.caseReviewSummaryPageBackToCaseButton().click();
                acePage.coachingFeedbackMenuButton().click();
                acePage.coachingFeedbackDeleteButton().click();
                supportHub.reviewCommentDeleteButton().last().click({ force: true });
                supportHub.closeButton().click();
              }
            });
          });
        }
      });
    }
  );

  /*
   * Under recommendation tab,Open any ticket.
   * Highlight the text in case description.
   * Select coaching feedback from the options.
   * Add a coaching feedback and click on "Comment" button
   * Click on 'Start Review' button.
   * Highlight text in same page review,enter the text and select one category and click cooment button.
   * Click '1 comment', Validate the review comments and category is displayed.
   * Add some text in key take away text box.
   * Give rating for all items and click on "Next"button.
   * Validate that 'review comments', 'Key take away comments', 'text given in the checklist category'  and 'Coaching feedback' added is displayed on the review summary page.
   */
  it(
    'C35816: Verify the display of categorised review comments, category comment , Coaching feedback and Key take away notes',
    { tags: '@PublishChecklist' },
    function categorisedCommentReviewComment() {
      const targetCaseCommentIndex = -1;
      const coachingFeedbackText = `Test coaching feedback ${randId()}`;
      const reviewCommentsWithCategoryText = `Test review comment with category ${randId()}`;
      const CommentsInCategory = `Test comment in category ${randId()}`;
      const keyTakeAwayCommentsText = `Test key take away comment ${randId()}`;

      cy.visit(urlHelpers.aceQaScorecards);
      acePage.creatingDoubleCategoryChecklist();
      cy.waitForLoaders();
      // To avoid checklist page crashing issue currently using navbar flow tracking via-SLC-30928
      navBar.agentCoaching().click();
      cy.waitForLoaders();
      acePage.recommendedCaseCard(this.caseId).click();
      cy.waitForLoaders();
      supportHub.baseContainer().should('be.visible');
      cy.waitForLoaders();
      cy.get('#case-comments-annotations').then(($ele) => {
        if ($ele.find('[data-testid=supportHub-caseComments_coaching-content]').length > 0) {
          this.skip();
        } else {
          supportHub.gotoCaseDescriptionButton().click();
          supportHub.selectCaseCommentText(targetCaseCommentIndex);
          acePage.coachingFeedbackButton().click();
          acePage.coachingFeedbackTextbox().type(coachingFeedbackText);
          acePage.commentButtonInCoachingFeedbackWindow().click();
          cy.waitForLoaders();
          acePage.addedCoachingFeedbackText().scrollIntoView().should('be.visible').and('contain', coachingFeedbackText);
          acePage.startReviewButton().then(() => {
            acePage.startReviewButton().click();
            cy.waitForLoaders();
            cy.get('#case-comments-annotations').then(($ele1) => {
              if ($ele1.find('[data-testid=ace-evaluation-review-comment-header]').length > 0) {
                this.skip();
              } else {
                supportHub.selectCaseCommentText(targetCaseCommentIndex);
                supportHub.reviewCommentHeader().last().scrollIntoView().should('be.visible').and('contain', `Review Comment`);
                supportHub.reviewCommentInput().type(reviewCommentsWithCategoryText);
                supportHub.reviewCommentDropdown().click();
                acePage
                  .categoryDropdownCheckboxLabel()
                  .first()
                  .then((categoryText) => {
                    const categoryTitle = categoryText.text();

                    supportHub.reviewCommentsDropdown().eq(0).click({ force: true });
                    supportHub.reviewCommentHeader().last().click();
                    supportHub.reviewCommentsSendButton().should('be.visible').click();
                    cy.waitForLoaders();
                    acePage.reviewCommentTriggerLink().scrollIntoView().should('be.visible').and('contain', `1 comment`);
                    acePage.reviewCommentTriggerLink().scrollIntoView().click();
                    acePage.reviewCommentListText().should('be.visible').and('contain', `1 comment for this category`);
                    acePage.reviewCommentViewListText().invoke('text').should('contain', reviewCommentsWithCategoryText);
                    acePage.reviewCommentViewCategoryText().invoke('text').should('contain', categoryTitle);
                    acePage.reviewCategoryInputTextbox().type(CommentsInCategory);
                    acePage.caseReviewPanelTitle().invoke('text').should('contain', 'Key takeaways ');
                    acePage.goodRatingButton().click({ multiple: true });
                    // eslint-disable-next-line cypress/no-unnecessary-waiting
                    cy.wait(1000);
                    acePage.reviewKeyTakeAwayInputTextbox().type(keyTakeAwayCommentsText);
                    // eslint-disable-next-line cypress/no-unnecessary-waiting
                    cy.wait(1000);
                    acePage.nextReviewConfirmationPopupWindow().click();
                    acePage.reviewSummaryKeyTakeAwayTitle().scrollIntoView().should('be.visible').and('contain', `Key takeaways `);
                    acePage.reviewSummaryKeyTakeAwayContent().first().should('be.visible').and('contain', keyTakeAwayCommentsText);
                    acePage.reviewSummaryCoachingFeedbackTitle().scrollIntoView().should('be.visible').and('contain', `Coaching feedback`);
                    acePage.reviewSummaryCoachingFeedbackContent().scrollIntoView().should('be.visible').and('contain', coachingFeedbackText);
                    acePage.reviewSummaryCategoryTitle().first().scrollIntoView().should('be.visible').and('contain', categoryTitle);
                    acePage.reviewSummaryKeyTakeAwayContent().last().should('be.visible').and('contain', CommentsInCategory);
                    acePage.reviewSummaryCategorySliderComment().first().scrollIntoView().should('be.visible').and('contain', reviewCommentsWithCategoryText);
                    acePage.caseReviewSummaryPageBackToCaseButton().click();
                    acePage.coachingFeedbackMenuButton().click();
                    acePage.coachingFeedbackDeleteButton().click();
                    supportHub.reviewCommentDeleteButton().last().click({ force: true });
                    supportHub.reviewCommentDeleteButton().last().click({ force: true });
                    supportHub.closeButton().click();
                  });
              }
            });
          });
        }
      });
    }
  );

  /*
   * Under recommendation tab,Open any ticket.
   * Click on 'Start Review' button.
   * Highlight text in same page review,enter the text in the review comments text box.
   * Select one category , one emoji and click on comment button, Validate Enter text and category should be displayed
   * Give rating for all items and click on "Next"button.
   * Click on "Back to Review" button. edit/update the existing review comment, category, emoji and click on comment button.
   * Validate updated review comment, category, emoji should be displayed in same page review
   * Click on next button, Validate updated review comment, category, emoji should be displayed.
   */
  it('C6784: Verify the updation of review comment workflow', { tags: '@PublishChecklist' }, function updateReviewComment() {
    const targetCaseCommentIndex = -1;
    const reviewCommentsText = `Test review comment ${randId()}`;
    const reviewCommentsTextEdited = `Test review comment edited ${randId()}`;
    const categoryName = 'Testing Category 1';

    cy.visit(urlHelpers.aceQaScorecards);
    acePage.creatingDoubleCategoryChecklist();
    cy.waitForLoaders();
    // To avoid checklist page crashing issue currently using navbar flow tracking via-SLC-30928
    navBar.agentCoaching().click();
    cy.waitForLoaders();
    acePage.recommendedCaseCard(this.caseId).click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
    acePage.startReviewButton().then(() => {
      acePage.startReviewButton().click();
      cy.waitForLoaders();
      cy.get('#case-comments-annotations').then(($ele) => {
        if ($ele.find('[data-testid=ace-evaluation-review-comment-header]').length > 0) {
          this.skip();
        } else {
          supportHub.selectCaseCommentText(targetCaseCommentIndex);
          supportHub.reviewCommentHeader().last().scrollIntoView().should('be.visible').and('contain', `Review Comment`);
          acePage.starEmojiButton().should('be.visible').click();
          supportHub.reviewCommentInput().type(reviewCommentsText);
          supportHub.reviewCommentDropdown().click();
          acePage
            .categoryDropdownCheckboxLabel()
            .first()
            .then((categoryText) => {
              const categoryTitle = categoryText.text();

              supportHub.reviewCommentsDropdown().eq(0).click({ force: true });
              supportHub.reviewCommentHeader().last().click();
              supportHub.reviewCommentsSendButton().should('be.visible').click();
              cy.waitForLoaders();
              acePage.starEmojiSelectedInSamePageReview().should('be.visible');
              supportHub.reviewPageCommentText().scrollIntoView().should('be.visible').and('contain', reviewCommentsText);
              supportHub.reviewPageCategoryText().scrollIntoView().should('be.visible').and('contain', categoryName);
              acePage.reviewCommentTriggerLink().scrollIntoView().should('be.visible').and('contain', `1 comment`);
              acePage.reviewCommentTriggerLink().scrollIntoView().click();
              acePage.starEmojiSelectedInSamePageReview().should('be.visible');
              acePage.reviewCommentListText().should('be.visible').and('contain', `1 comment for this category`);
              acePage.reviewCommentViewListText().invoke('text').should('contain', reviewCommentsText);
              acePage.reviewCommentViewCategoryText().invoke('text').should('contain', categoryTitle);
              // eslint-disable-next-line cypress/no-unnecessary-waiting
              cy.wait(1000);
              acePage.badRatingButton().click({ multiple: true });
              // eslint-disable-next-line cypress/no-unnecessary-waiting
              cy.wait(1000);
              acePage.nextReviewConfirmationPopupWindow().should('be.visible').click();
              cy.waitForLoaders();
              supportHub.reviewSummaryCommentText().first().scrollIntoView().should('be.visible').and('contain', reviewCommentsText);
              supportHub.reviewSummaryCategoryText().first().scrollIntoView().should('be.visible').and('contain', categoryName);
              acePage.caseReviewSummaryPageBackToCaseButton().should('be.visible').click();
              supportHub.reviewPageCommentText().last().scrollIntoView().scrollIntoView().trigger('mouseover');
              supportHub.reviewCommentEditButton().click({ force: true });
              acePage.celebrateEmojiButton().should('be.visible').click();
              supportHub.reviewCommentInput().clear().type(reviewCommentsTextEdited);
              supportHub.reviewCommentDropdown().click();
              acePage
                .categoryDropdownCheckboxLabel()
                .eq(1)
                .then((categoryTextSecond) => {
                  const categoryTitleSecond = categoryTextSecond.text();

                  supportHub.reviewCommentsDropdown().eq(0).click({ force: true });
                  supportHub.reviewCommentsDropdown().eq(1).click({ force: true });
                  supportHub.reviewCommentHeader().last().click();
                  supportHub.reviewCommentsSendButton().should('be.visible').click();
                  cy.waitForLoaders();
                  supportHub.reviewPageCommentText().last().scrollIntoView().should('be.visible').and('contain', reviewCommentsTextEdited);
                  supportHub.reviewPageCommentText().scrollIntoView().should('be.visible').and('contain', reviewCommentsTextEdited);
                  supportHub.reviewPageCategoryText().scrollIntoView().should('be.visible').and('contain', categoryTitleSecond);
                  acePage.reviewCommentTriggerLink().scrollIntoView().should('be.visible').and('contain', `1 comment`);
                  acePage.reviewCommentTriggerLink().scrollIntoView().click();
                  acePage.celebrateEmojiSelectedInSamePageReview().should('be.visible');
                  acePage.reviewCommentListText().should('be.visible').and('contain', `1 comment for this category`);
                  acePage.reviewCommentViewListText().invoke('text').should('contain', reviewCommentsTextEdited);
                  acePage.reviewCommentViewCategoryText().invoke('text').should('contain', categoryTitleSecond);
                  // eslint-disable-next-line cypress/no-unnecessary-waiting
                  cy.wait(1000);
                  acePage.nextReviewConfirmationPopupWindow().should('be.visible').click();
                  cy.waitForLoaders();
                  supportHub.reviewSummaryCommentText().scrollIntoView().should('be.visible').and('contain', reviewCommentsTextEdited);
                  acePage.caseReviewSummaryPageBackToCaseButton().click();
                  supportHub.reviewCommentDeleteButton().click({ multiple: true, force: true });
                });
            });
        }
      });
      supportHub.closeButton().click();
    });
  });
});
