import moment from 'moment';

import { urlHelpers } from '../../../utils';
import { acePage, apiHelpers, agentInsights, datePicker, globalFilters, navBar } from '../../../pages';

describe('ACE - Agent Event Check', () => {
  beforeEach(() => {
    cy.intercept('POST', 'search/virtual_groups/_search*').as('agentSearch');
    cy.intercept('PUT', 'api/users/dashboard_settings').as('updateUserSettings');

    cy.loginByApi();
    apiHelpers.clearRecentlyVisitedAgentInsight();
    cy.slcHelpers.getDetailsOfAgentsWithCases().then((agentDetails) => {
      const agentDetail = Cypress._.sample(agentDetails);
      cy.wrap(agentDetail).as('agentDetail');
      cy.visit(urlHelpers.agentInsights.home);
      cy.waitForLoaders();
    });
  });

  afterEach(() => apiHelpers.clearAgentFilterInACEPage());

  /*
   * Select an Agent in Agent insights.
   * Add an Out of office event for the present date.
   * Navigate to Agent coaching and click completed evaluation tab.
   * In the Agents filter, filter with the above selected agent in pre-condition.
   * Out of office event should be displayed in the same line
   * Mouse hover near to the agent, Out of office event should be displayed
   */
  it('C6531: verify Out of Office status belonging to filtered agents', { tags: ['ACE', 'staging'] }, function agentNames() {
    const dayToday = moment().add(0, 'days');
    const agentName = this.agentDetail.sl_name;

    agentInsights.agentInsightsSearchFieldInput().click().type(agentName);
    agentInsights.agentSearchResultList().first().click();
    cy.waitForLoaders();
    datePicker.calendarDayButton(dayToday.format('MMMM D,')).dblclick();
    agentInsights.eventDetailTextArea().type('OOO');
    agentInsights.agentInsightsOOOSaveButton().click();
    agentInsights.agentInAgentOOOLabel().scrollIntoView().should('be.visible').invoke('text').should('include', 'Out of office');
    navBar.agentCoaching().click();
    cy.waitForLoaders();
    acePage.agentFilterButton().click();
    globalFilters.quickFilterSearchFieldInput().type(agentName);
    cy.wait('@agentSearch');
    globalFilters.quickFilterSearchResultList().first().find('input[type=checkbox]').click({ force: true });
    globalFilters.filterApplyButton().click();
    cy.wait('@updateUserSettings');
    acePage.completedEvaluationsTab().should('be.visible').click();
    cy.waitForLoaders();
    acePage.aceAgentAvatarIcon().trigger('mouseover');
    acePage.aceAgentAvatarDetailsPopup().should('be.visible');
    acePage.aceAgentAvatarDetailsPopup().invoke('text').should('include', 'Returning');
    navBar.agentInsights().click();
    cy.waitForLoaders();
    datePicker.calendarDayButton(dayToday.format('MMMM D,')).dblclick();
    agentInsights.agentInsightsOOODeleteButton().should('be.visible').click();
    agentInsights.agentInAgentOOOLabel().should('not.to.exist');
  });
});
