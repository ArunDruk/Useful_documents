// Test Case Added to SLC-Production folder
import { urlHelpers } from '../../../utils';
import { acePage } from '../../../pages';

describe('QA Scorecard - Verify all tabs', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.aceQaScorecards);
  });

  /**
   * Open the QA Scorecard page.
   * Validate the visibility of the Current, Drafts & Previous Versions tabs.
   */
  it('C9320: Validate the display of QA Scorecards page', { tags: ['Ace', 'staging'] }, () => {
    acePage.currentDraftTab().should('be.visible').invoke('text').should('be.equal', 'Current');
    acePage.draftsTab().should('be.visible').invoke('text').should('be.equal', 'Drafts');
    acePage.previousVersionsTab().should('be.visible').invoke('text').should('be.equal', 'Previous Versions');
  });
});
