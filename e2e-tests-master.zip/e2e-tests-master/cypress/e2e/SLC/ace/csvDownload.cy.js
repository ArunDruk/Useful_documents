import path from 'path';

import { urlHelpers } from '../../../utils';
import { acePage, apiHelpers, datePicker } from '../../../pages';

describe('ACE - CSV Download', () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.clearAgentFilterInACEPage();
    cy.visit(urlHelpers.caseEvaluation);
    cy.waitForLoaders();

    acePage
      .recommendedContainerHeader()
      .invoke('text')
      .then((headerText) => {
        if (headerText === '0Recommended') {
          acePage.recommendedSidebarExpandButton().click();
          datePicker.datePickerTrigger().eq(0).click();
          datePicker.selectLastMonthWithOption(3);
          datePicker.datePickerTrigger().eq(0).should('have.text', 'Last 3 months');
          cy.waitForLoaders();
        }
      });
  });

  /*
   * Open the ACE page.
   * validate the CSV download functionality check.
   */
  it('C3781: ACE Page CSV download functionality check', { tags: ['ACE', 'staging'] }, () => {
    const expectedFileName = `Recently reviewed.csv`;
    const downloadsFolder = Cypress.config('downloadsFolder');

    acePage.downloadCSVButton().should('be.visible').click();
    cy.readFile(path.join(downloadsFolder, expectedFileName)).should('exist');
  });

  /*
   * Open the ACE page.
   * Go to completed evaluation tab.
   * validate the CSV download functionality check.
   */
  it('C27906: Validate Export CSV from Completed Evaluations tab', { tags: ['ACE', 'staging'] }, () => {
    const expectedFileName = `Export-completed-evaluation.csv`;
    const downloadsFolder = Cypress.config('downloadsFolder');

    acePage.completedEvaluationsTab().click();
    cy.waitForLoaders();
    acePage.downloadCSVButtonCompletedEvaluationTab().should('be.visible').and('contain', 'Export as CSV');
    acePage.downloadCSVButtonCompletedEvaluationTab().click();

    cy.readFile(path.join(downloadsFolder, expectedFileName)).should('exist');
  });
});
