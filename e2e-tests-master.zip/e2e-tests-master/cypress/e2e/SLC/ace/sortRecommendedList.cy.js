// Test Case Added to SLC-Production folder

import { urlHelpers } from '../../../utils';
import { acePage, apiHelpers, datePicker } from '../../../pages';

describe('ACE - Sort functionality check', () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.clearAgentFilterInACEPage();
    cy.visit(urlHelpers.caseEvaluation);
    cy.waitForLoaders();
    acePage
      .recommendedContainerHeader()
      .invoke('text')
      .then((headerTitle) => {
        if (headerTitle === '0Recommended') {
          acePage.recommendedSidebarExpandButton().click();
          datePicker.datePickerTrigger().eq(0).click();
          datePicker.selectLastMonthWithOption(3);
          datePicker.datePickerTrigger().eq(0).should('have.text', 'Last 3 months');
          cy.waitForLoaders();
        }
      });
  });

  /*
   * Open the ACE page.
   * Change the sort option in recommended column (all 3 options).
   * Validate the sort dropdown is displaying the selected value.
   * Validate cases are sorted correctly based on the selected value
   */
  it('C9292: Verify the sort option in recommended column', { tags: ['ACE', 'staging'] }, () => {
    acePage
      .dropdownText()
      .eq(0)
      .then((button) => {
        const textmsg = button.text();

        if (textmsg === 'Recommended') {
          cy.waitForLoaders();
        } else {
          acePage.recommendedSidebarDropdown().click();
          acePage.dropdownRecommendedList().click();
          acePage.dropdownText().eq(0).should('be.visible').and('contain', 'Recommended');
          cy.waitForLoaders();
        }
      });

    acePage
      .commonAgentNameLabel()
      .eq(0)
      .then((buttonText) => {
        const customerName = buttonText.text();

        acePage.recommendedSidebarDropdown().click();
        acePage.dropdownConversationsList().click();
        cy.waitForLoaders();
        acePage.dropdownText().eq(0).should('be.visible').and('contain', 'Conversations');
        acePage.commonAgentNameLabel().eq(0).should('not.have.text', customerName);
      });

    acePage
      .commonAgentNameLabel()
      .eq(0)
      .then((buttonText) => {
        const customerName = buttonText.text();

        acePage.recommendedSidebarDropdown().click();
        acePage.dropdownCollaboratorsList().click();
        cy.waitForLoaders();
        acePage.dropdownText().eq(0).should('be.visible').and('contain', 'Collaborators');
        acePage.commonAgentNameLabel().eq(0).should('not.have.text', customerName);
      });

    acePage
      .commonAgentNameLabel()
      .eq(0)
      .then((buttonText) => {
        const customerName = buttonText.text();

        acePage.recommendedSidebarDropdown().click();
        acePage.dropdownRecommendedList().click();
        cy.waitForLoaders();
        acePage.dropdownText().eq(0).should('be.visible').and('contain', 'Recommended');
        acePage.commonAgentNameLabel().eq(0).should('not.have.text', customerName);
      });
  });
});
