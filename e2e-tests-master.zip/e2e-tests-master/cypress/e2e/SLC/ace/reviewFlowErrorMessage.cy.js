import { urlHelpers } from '../../../utils';
import { acePage, apiHelpers, datePicker, supportHub } from '../../../pages';

describe('ACE - Error message validation', () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.clearAgentFilterInACEPage();
    cy.visit(urlHelpers.caseEvaluation);
    cy.waitForLoaders();

    acePage
      .recommendedContainerHeader()
      .invoke('text')
      .then((headerText) => {
        if (headerText === '0Recommended') {
          acePage.recommendedSidebarExpandButton().click();
          datePicker.datePickerTrigger().eq(0).click();
          datePicker.selectLastMonthWithOption(3);
          datePicker.datePickerTrigger().eq(0).should('have.text', 'Last 3 months');
          cy.waitForLoaders();
        }
      });
  });

  /*
   * Under recommendation tab,Open any ticket.
   * Click on "Start Review" button.
   * Do not give rating for all items and click on "Next"button.
   * Validate the error message thrown in the popup.
   */
  it('C6773: Verify empty rating flow error message', { tags: ['ACE', 'staging'] }, () => {
    acePage.recommendedCaseCard().first().click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
    acePage.startReviewButton().then(() => {
      acePage.startReviewButton().click();
      cy.waitForLoaders();
      acePage.nextReviewConfirmationPopupWindow().should('be.visible').click();
      acePage.reviewPageErrorNotificationPopup().should('be.visible').and('contain', 'You need to complete the review before proceeding!');
    });
    supportHub.closeButton().click();
  });
});
