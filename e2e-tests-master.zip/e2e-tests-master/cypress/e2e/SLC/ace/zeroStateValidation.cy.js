import { urlHelpers } from '../../../utils';
import { acePage, apiHelpers, agentInsights, navBar, globalFilters } from '../../../pages';

describe('ACE - Agent zero state validation', () => {
  beforeEach(() => {
    cy.intercept('POST', 'search/virtual_groups/_search*').as('agentSearch');

    cy.loginByApi();
    apiHelpers.clearAgentFilterInACEPage();
    cy.visit(urlHelpers.caseEvaluation);
    cy.waitForLoaders();
  });

  /*
   * Open the Agent Insight page.s
   * Search for any Agent and click.
   * Click on performance(Beta) tab.
   * Validate the zero state validation,i.e should have placeholder value.
   */
  it('C6368: Validate the zero state validation on performance beta', { tags: ['ACE', 'staging'] }, function placeholderAgentPerformance() {
    // Agent Name is hardcoded. This will be used until we get API to fetch agent whose cases is not reviewed
    const agentName = 'Evan Boehm';
    acePage.agentFilterButton().click();
    globalFilters.quickFilterSearchFieldInput().type(agentName);
    cy.wait('@agentSearch');
    acePage
      .agentCaseCount()
      .invoke('text')
      .then((agentCaseCountText) => {
        if (!agentCaseCountText.includes('5 cases')) {
          this.skip();
        } else {
          navBar.agentInsights().click();
          agentInsights.agentInsightsSearchFieldInput().click().type(agentName);
          agentInsights.agentSearchResultList().first().click();
          agentInsights.agentPerformanceBetaTab().should('be.visible').click();
          agentInsights.performanceTabWelcomePageVisibilityCheck();
          agentInsights.agentPerformanceBetaContainer().should('be.visible').contains(`There are no completed case reviews for ${agentName} in the selected period.`);
        }
      });
  });
});
