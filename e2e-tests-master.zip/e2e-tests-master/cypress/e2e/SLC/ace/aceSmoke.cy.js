import { clearAgentFilter } from './support';
import { urlHelpers } from '../../../utils';
import { acePage } from '../../../pages';

beforeEach(() => {
  cy.loginByApi();
  cy.visit(urlHelpers.caseEvaluation);
  clearAgentFilter();
});

describe('ACE Smoke Test Cases', () => {
  it('C6862: Verify the agent filter in Recommendations & Completed evaluations tab', { tags: 'Ace' }, () => {
    cy.getByTestId('ace__agentFilter__trigger').click();
    cy.getByTestId('filters-scoreFilters-searchOptionFilter-searchInput').type('A');
    cy.get("[type='checkbox']").first().click({ force: true });
    cy.getByTestId('filters-scoreFilters-searchResult-optionItem')
      .first()
      .get('[data-testid^=animated-checkbox-gid-]')
      .invoke('attr', 'data-testid')
      .then((attrVal1) => {
        cy.wrap(attrVal1.split('-')[4]).as('agentEleRecommendationTab');
        cy.get('@agentEleRecommendationTab').then((agentNameRecommendationTab) => {
          cy.getByTestId('filters-scoreFilters-searchOptionFilter-applyFilterBtn').click();
          cy.getByTestId('ace__tabs__completedReviews').click();
          cy.getByTestId('ace__agentFilter__trigger').should('be.visible');
          cy.getByTestId('ace__agentFilter__trigger').click();
          cy.getByTestId('global-filter--selected--sl_assignee_id').click();
          cy.get('[data-testid^=animated-checkbox-gid-]')
            .invoke('attr', 'data-testid')
            .then((attrVal2) => {
              cy.wrap(attrVal2.split('-')[4]).as('agentEleCompletedTab');
              cy.get('@agentEleCompletedTab').then((agentNameCompletedTab) => {
                expect(agentNameRecommendationTab).to.eq(agentNameCompletedTab);
              });
            });
        });
      });
  });

  it('C6312: Verify the display of Evaluation Checklist', { tags: 'Ace' }, () => {
    cy.visit(urlHelpers.aceQaScorecards);
    cy.getByTestId('ace-evaluation-checklist-title').contains('QA Scorecards').should('be.visible');
    cy.getByTestId('ace-evaluation-checklist-description')
      .should('be.visible')
      .and('have.text', 'This is what reviewers use to help them provide feedback to agents on their support cases');
    cy.getByTestId('ace__settings__tabs__current').should('be.visible');
    cy.getByTestId('ace__settings__tabs__drafts').should('be.visible');
    cy.getByTestId('ace__settings__tabs__previous-versions').should('be.visible');
  });

  it('C6859: Verify the display of Recommendations tab', { tags: 'Ace' }, () => {
    cy.getByTestId('ace__tabs__recommendations').should('be.visible');
    cy.getByTestId('caseEvaluation-collapsibleSidebar-title-Recommended').should('be.visible');
    cy.getByTestId('caseEvaluation-collapsibleSidebar-title-In_progress').should('be.visible');
    cy.getByTestId('caseEvaluation-collapsibleSidebar-title-Recently_reviewed').should('be.visible');
    cy.getByTestId('filters-dynamicFilters-addAFilter').should('be.visible');
    cy.getByTestId('ace__agentFilter__trigger').should('be.visible');
  });

  it('C6858: Verify the display of Completed evaluations tab', { tags: 'Ace' }, () => {
    cy.getByTestId('ace__tabs__completedReviews').should('be.visible');
    cy.getByTestId('ace__tabs__completedReviews').click();
    cy.getByTestId('ace__datePeriodSwitcher__last-week,3').should('be.visible');
    cy.getByTestId('ace__datePeriodSwitcher__last-week,2').should('be.visible');
    cy.getByTestId('ace__datePeriodSwitcher__this-week').should('be.visible');
    cy.getByTestId('ace-evaluation-completed-pending').contains('agents left to review').should('be.visible');
    cy.getByTestId('ace-evaluation-completed-completed').contains('completed evaluation').should('be.visible');
    cy.getByTestId('ace__agentFilter__trigger').should('be.visible');
    cy.getByTestId('ace-evaluations-completed-evaluations-table').should('be.visible');
    cy.getByTestId('dropdown-trigger-text').siblings().contains('Group by').should('be.visible');
    cy.getByTestId('table-header-cell_Evaluated').contains('Evaluated').should('be.visible');
    cy.getByTestId('table-header-cell_Evaluator').contains('Evaluator').should('be.visible');
  });

  it('C2227: Verify the display of ACE page', { tags: 'Ace' }, () => {
    cy.getByTestId('ace__tabs__recommendations').should('be.visible');
    cy.getByTestId('ace__tabs__completedReviews').should('be.visible');
    cy.getByTestId('ace__agentFilter__trigger').should('be.visible');
  });

  describe('ACE Smoke test cases - Adding review', () => {
    beforeEach(function caseIdGetter() {
      cy.getByTestId('caseEvaluation-collapsibleSidebar-title-Recommended')
        .invoke('text')
        .then((headerText) => {
          if (headerText === '0Recommended') {
            this.skip();
          } else {
            cy.get('[data-testid^=caseEvaluation-list-container-recommended]')
              .first()
              .invoke('attr', 'data-testid')
              .then((attrVal) => {
                cy.wrap(attrVal.split('-')[4]).as('caseId');
              });
          }
        });
    });

    it('C6861: Verify the display of three ACE options when comments are highlighted', { tags: 'Ace' }, function verifyAceOptions() {
      cy.getByTestId(`caseEvaluation-list-container-recommended-${this.caseId}`).click();
      cy.waitForLoaders();
      cy.getByTestId('supporthub-go-to-description');
      cy.getByTestId('supportHub-caseComments-body-0')
        .trigger('mousedown')
        .then(($commentElement) => {
          const elementText = Cypress.$($commentElement)
            .contents()
            .filter(function caseDescription() {
              return this.nodeType === Node.TEXT_NODE;
            })[0];
          const document = elementText.ownerDocument;
          const range = document.createRange();
          range.selectNodeContents(elementText);
          document.getSelection().removeAllRanges(range);
          document.getSelection().addRange(range);
        })
        .trigger('mouseup');
      cy.document().trigger('selectionchange');
      cy.getByTestId('supportHub-caseTimeline-caseComment-addAnnotation').should('be.visible');
      cy.getByTestId('supportHub-caseTimeline-caseComment-addCoachComment').should('be.visible');
      cy.getByTestId('supportHub-caseTimeline-caseComment-addACELabel').should('be.visible');
    });

    // When clicking on "Start Review" SH gets crashed,its tracked in SLC-30928
    it('C6860: Verify the display of same page review', { tags: 'Ace' }, function verifySamePageReview() {
      cy.getByTestId(`caseEvaluation-list-container-recommended-${this.caseId}`)
        .find('[data-testid="ace-case-review-agantName"]')
        .then((agentNameEle) => {
          const agentName = agentNameEle.text();
          cy.getByTestId(`caseEvaluation-list-container-recommended-${this.caseId}`).click();
          cy.waitForLoaders();
          acePage.startReviewButton().click();
          cy.waitForLoaders();
          cy.getByTestId('ace-case-review-agantName').contains(agentName).should('be.visible');
          cy.getByTestId('ace-case-review-title').contains('Case Review').should('be.visible');
          cy.get('[data-testid^="ace-case-review-category-Textarea_"]').should('be.visible');
          cy.getByTestId('ace-case-review-textarea-keyTakeaways').scrollIntoView().should('be.visible');
          cy.getByTestId('ace__caseReviewContainer__next').should('be.visible');
        });
    });
  });
});

//     // Skipping this test case as functional test case is modif to verifu PDF
//     it.skip('C6358: Verify the review with both positive and negative rating', { tags: 'Ace' }, function verifyPositiveNegativeReview() {
//       createFiveItemsChecklist();
//       cy.getByTestId(`caseEvaluation-list-container-recommended-${this.caseId}`).click();
//       acePage.startReviewButton().click();
//       cy.getByTestId('supportHub-caseComment-caseReview-rating-Poor').eq(0).click();
//       cy.getByTestId('supportHub-caseComment-caseReview-rating-Bad').eq(1).click();
//       cy.getByTestId('supportHub-caseComment-caseReview-rating-Neutral').eq(2).click();
//       cy.getByTestId('supportHub-caseComment-caseReview-rating-Good').eq(3).click();
//       cy.getByTestId('supportHub-caseComment-caseReview-rating-Great').eq(4).click();
//       cy.getByTestId('supportHub-caseComment-caseReview-rating-Not_Applicable').eq(5).click();
//       cy.getByTestId('ace-case-review-category-Textarea_Testing Category 1').type('test-comments');
//       cy.getByTestId('ace__caseReviewContainer__next').click();
//       cy.getByTestId('ace-review-rating-control-wrapper').eq(0).find('[data-testid="supportHub-caseComment-caseReview-rating-Poor"]').should('be.visible');
//       cy.getByTestId('ace-review-rating-control-wrapper').eq(1).find('[data-testid="supportHub-caseComment-caseReview-rating-Bad"]').should('be.visible');
//       cy.getByTestId('ace-review-rating-control-wrapper').eq(2).find('[data-testid="supportHub-caseComment-caseReview-rating-Neutral"]').should('be.visible');
//       cy.getByTestId('ace-review-rating-control-wrapper').eq(2).find('[data-testid="supportHub-caseComment-caseReview-rating-Neutral"]').scrollIntoView();
//       cy.getByTestId('ace-review-rating-control-wrapper').eq(3).find('[data-testid="supportHub-caseComment-caseReview-rating-Good"]').should('be.visible');
//       cy.getByTestId('ace-review-rating-control-wrapper').eq(4).find('[data-testid="supportHub-caseComment-caseReview-rating-Great"]').should('be.visible');
//       cy.getByTestId('ace-review-rating-control-wrapper').eq(5).find('[data-testid="supportHub-caseComment-caseReview-rating-Not_Applicable"]').should('be.visible');
//     });
//   });
// });
