import { urlHelpers } from '../../../utils';
import { acePage, supportHub, apiHelpers, datePicker } from '../../../pages';

describe('ACE- Automated Feedback', () => {
  beforeEach(function beforeEachHook() {
    cy.loginByApi();
    apiHelpers.clearAgentFilterInACEPage();
    apiHelpers.groupByAllCommentsInsideSupportHubInACEPage();
    cy.visit(urlHelpers.caseEvaluation);

    acePage
      .recommendedContainerHeader()
      .invoke('text')
      .then((headerText) => {
        if (headerText === '0Recommended') {
          acePage.recommendedSidebarExpandButton().click();
          datePicker.datePickerTrigger().eq(0).click();
          datePicker.selectLastMonthWithOption(3);
          datePicker.datePickerTrigger().eq(0).should('have.text', 'Last 3 months');
          cy.waitForLoaders();
        }
      });

    acePage
      .recommendedSidebarCaseIDs()
      .eq(0)
      .invoke('attr', 'data-testid')
      .then((attrVal) => {
        cy.wrap(attrVal.split('-')[4]).as('caseId');
      });
  });

  afterEach(() => apiHelpers.groupByAllCommentsInsideSupportHubInACEPage());

  /*
   * Todo: API request to get ACE tickets with automated feedback.
   * This is tracked in SLC-34640
   *
   * Open any ticket in ACE Recommended column
   * Click on comments dropdown.
   * Select automated feedback from the options.
   * Validate that 'Coaching feedback from supportlogic company' is displayed.
   */
  it('C6538: Verify the Automated feedback panel workflow', { tags: ['ace', 'staging'] }, function automatedFeedback() {
    acePage.recommendedCaseCard(this.caseId).click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
    cy.get('#case-comments-annotations').then(($ele) => {
      if ($ele.find('[data-testid=supportHub-caseComments_coaching-header]').length > 0) {
        supportHub.commentsDropdown().click();
        supportHub.commentsDropdownAutomatedFeedbackOption().click();
        supportHub.caseCommentsCoachingHeader().first().scrollIntoView().invoke('text').should('contain', 'Coaching feedback(from SupportLogic)');
      } else {
        this.skip();
      }
    });
  });
});
