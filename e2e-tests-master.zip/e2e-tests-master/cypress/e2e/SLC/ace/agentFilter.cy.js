import { urlHelpers } from '../../../utils';
import { acePage, apiHelpers, globalFilters } from '../../../pages';

describe('ACE - Agent Filter', () => {
  beforeEach(() => {
    cy.intercept('POST', 'search/virtual_groups/_search*').as('agentSearch');
    cy.intercept('PUT', 'api/users/dashboard_settings').as('updateUserSettings');

    cy.loginByApi();
    apiHelpers.clearAgentFilterInACEPage();
    cy.visit(urlHelpers.caseEvaluation);
    cy.waitForLoaders();
  });

  afterEach(() => apiHelpers.clearAgentFilterInACEPage());

  /*
   * Get the agent name from the first case card (can be in any column)
   * Click the agent filter button
   * Type the agent name and wait for the search results
   * Click the first item in the search results
   * Click the 'Apply Filter' button
   * Wait for the filter to be applied
   * Validation 0 case displayed on evaluation
   */
  it('C6532: verify 0 case displayed on evaluation belonging to filtered agents', { tags: ['ACE', 'staging'] }, function zeroClosedCase() {
    // Agent Name is hardcoded. This will be used until we get API to fetch agent whose cases is not reviewed
    const agentName = 'Evan Boehm';
    acePage.agentFilterButton().click();
    globalFilters.quickFilterSearchFieldInput().type(agentName);
    cy.wait('@agentSearch');
    acePage
      .agentCaseCount()
      .invoke('text')
      .then((agentCaseCountText) => {
        if (!agentCaseCountText.includes('5 cases')) {
          this.skip();
        } else {
          globalFilters.quickFilterSearchResultList().first().find('input[type=checkbox]').click({ force: true });
          globalFilters.filterApplyButton().click();
          cy.wait('@updateUserSettings');
          acePage.completedEvaluationsTab().should('be.visible').click();
          acePage.aceAgentListTextfield().invoke('text').should('include', '0 cases closed');
        }
      });
  });
});
