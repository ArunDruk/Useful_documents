import { randId, urlHelpers } from '../../../utils';
import { acePage, apiHelpers, supportHub } from '../../../pages';

describe('ACE - Customer Notes', { tags: ['ACE', 'staging'] }, () => {
  beforeEach(function beforeEachHook() {
    cy.intercept('POST', 'api/customer-notes').as('postCustomerNote');
    cy.intercept('DELETE', 'api/customer-notes/*').as('deleteCustomerNote');

    cy.loginByApi();
    cy.visit(urlHelpers.caseEvaluation);

    acePage.recommendationsTab().click();

    acePage
      .recommendedContainerHeader()
      .invoke('text')
      .then((headerTitle) => {
        if (headerTitle === '0Recommended') this.skip();
      });

    acePage.recommendedCaseCard().first().click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
  });

  afterEach(function afterEachHook() {
    if (!this.skipAfterEachDelete) apiHelpers.deleteCustomerNote(this.noteId);
  });

  /*
   * Add customer note with desired note text
   * Wait for the API request to happen
   * Get the noteId from the API response
   *
   * Verify the added customer note is visible
   */
  it('C847: should add customer note', function addCustomerNote() {
    const noteText = `Test customer notes ${randId()}`;

    supportHub.addCustomerNotes(noteText);
    cy.wait('@postCustomerNote').then(({ response }) => {
      const noteId = response.body.note.id;
      cy.wrap(noteId).as('noteId');

      supportHub.customerNotesNoteText(noteId).should('have.text', noteText);
    });
  });

  /*
   * Add customer note with desired note text
   * Wait for API request to happen
   * Get the noteId from the API response
   *
   * Validate the successful addition of customer note
   *
   * Click the first 'Edit' icon button
   * Clear the textfield & type the new value
   * Click the Save button
   * Wait for API request to happen
   *
   * Validate the customer note has the new text
   */
  it('C848: should edit customer note', function editCustomerNote() {
    const noteText = `Test customer notes ${randId()}`;
    const editedNoteText = `Edited Customer Note ${randId()}`;

    supportHub.addCustomerNotes(noteText);
    cy.wait('@postCustomerNote').then(({ response }) => {
      const noteId = response.body.note.id;
      cy.wrap(noteId).as('noteId');

      supportHub.customerNotesNoteText(noteId).should('have.text', noteText);

      supportHub.customerNotesEditIconButton().first().click({ force: true });
      supportHub.customerNotesEditTextarea().clear();
      supportHub.customerNotesEditTextarea().type(editedNoteText);
      supportHub.customerNotesSaveEditButton().click();
      cy.wait('@postCustomerNote');

      supportHub.customerNotesNoteText(noteId).should('have.text', editedNoteText);
    });
  });

  /*
   * Set skipAfterEachDelete flag to true
   *
   * Add customer note with desired note text
   * Wait for API request to happen
   * Get the noteId from the API response
   *
   * Validate the successful addition of customer note
   *
   * Click the first 'Delete' icon button
   * Wait for API request to happen
   *
   * Validate the successful deletion of customer note
   */
  it('C849: should delete customer note', function deleteCustomerNoteTest() {
    const noteText = `Test customer notes ${randId()}`;

    cy.wrap(true).as('skipAfterEachDelete');

    supportHub.addCustomerNotes(noteText);
    cy.wait('@postCustomerNote').then(({ response }) => {
      const noteId = response.body.note.id;
      cy.wrap(noteId).as('noteId');

      supportHub.customerNotesNoteText(noteId).should('have.text', noteText);

      supportHub.customerNotesDeleteIconButton().first().click({ force: true });
      cy.wait('@deleteCustomerNote');

      supportHub.customerNotesNoteText(noteId).should('not.exist');
    });
  });
});
