import { urlHelpers } from '../../../utils';

export const clearAgentFilter = () =>
  cy.request({
    method: 'PUT',
    url: '/api/users/dashboard_settings',
    headers: { 'Content-Type': 'application/json' },
    body: {
      dashboardName: 'support',
      settingsKey: 'ace_page_settings',
      settingsSubKey: null,
      settingsValue: { agent_filters: {} },
      replace: true,
    },
  });

export const deleteRatingAPI = (ratingElementSid) => cy.request('DELETE', `/api/v2/ticket/review/template/rating_element/${ratingElementSid}`);

export const creatingTwoCategoryChecklist = () =>
  cy
    .request({
      method: 'POST',
      url: '/api/v2/ticket/review/template',
      headers: { 'Content-Type': 'application/json' },
      body: {
        description: '',
        is_default: false,
        name: "Logo ipsum TEST123's checklist",
        root_template: null,
        s_object_creator: { object_id: 'ce7821ab-eeff-4e1b-8b24-8175669f9152', object_type: 'SL_USER' },
      },
    })
    .then((templateSid) => {
      cy.request({
        method: 'GET',
        url: `/api/v2/ticket/review/template/${templateSid.body.data[0].s_id}`,
        headers: { 'Content-Type': 'application/json' },
        body: {
          data: [{ s_id: templateSid.body.data[0].s_id }],
        },
      }).then((ratingElement) => {
        ratingElement.body.data[0].rating_element_list.forEach(function deleteRatingList(existingRatingList) {
          deleteRatingAPI(existingRatingList.s_id);
        });
      });
      cy.request({
        method: 'POST',
        url: '/api/v2/ticket/review/template/rating_element',
        headers: { 'Content-Type': 'application/json' },
        body: {
          description: '',
          rating_score: 1,
          template: { s_id: templateSid.body.data[0].s_id },
        },
      });
      cy.request({
        method: 'POST',
        url: '/api/v2/ticket/review/template/rating_element',
        headers: { 'Content-Type': 'application/json' },
        body: {
          description: '',
          rating_score: 2,
          template: { s_id: templateSid.body.data[0].s_id },
        },
      });
      cy.request({
        method: 'POST',
        url: '/api/v2/ticket/review/template/rating_element',
        headers: { 'Content-Type': 'application/json' },
        body: {
          description: '',
          rating_score: 3,
          template: { s_id: templateSid.body.data[0].s_id },
        },
      });
      cy.request({
        method: 'POST',
        url: '/api/v2/ticket/review/template/rating_element',
        headers: { 'Content-Type': 'application/json' },
        body: {
          description: '',
          rating_score: 4,
          template: { s_id: templateSid.body.data[0].s_id },
        },
      });
      cy.request({
        method: 'POST',
        url: '/api/v2/ticket/review/template/rating_element',
        headers: { 'Content-Type': 'application/json' },
        body: {
          description: '',
          rating_score: 5,
          template: { s_id: templateSid.body.data[0].s_id },
        },
      });
      cy.request({
        method: 'POST',
        url: '/api/v2/metadata',
        headers: { 'Content-Type': 'application/json' },
        body: {
          groupid: null,
          metadata_key: 'category_name',
          metadata_type: 'TICKET_REVIEW_CHECKLIST_CATEGORY',
          metadata_value: 'Testing Category 1',
          metadata_value_type: 'STRING',
          object_owner: null,
          object_target: { object_id: templateSid.body.data[0].s_id, object_type: 'TICKET_REVIEW_TEMPLATE' },
          s_object_creator: { object_id: 'ce7821ab-eeff-4e1b-8b24-8175669f9152', object_type: 'SL_USER' },
          object_id: 'ce7821ab-eeff-4e1b-8b24-8175669f9152',
          object_type: 'SL_USER',
          visibility: 'PUBLIC',
        },
      }).then((categoryMetadata) => {
        cy.request({
          method: 'POST',
          url: '/api/v2/ticket/review/template/checklist_item',
          headers: { 'Content-Type': 'application/json' },
          body: {
            category_metadata: { s_id: categoryMetadata.body.data[0].s_id },
            description: 'Testing description 1 for item 1 under Category 1',
            is_draft: true,
            template: { s_id: templateSid.body.data[0].s_id },
            template_checklist_item_target_list: [],
            title: 'Testing Item 1 under Category 1',
          },
        });
        cy.request({
          method: 'POST',
          url: '/api/v2/ticket/review/template/checklist_item',
          headers: { 'Content-Type': 'application/json' },
          body: {
            category_metadata: { s_id: categoryMetadata.body.data[0].s_id },
            description: 'Checks whether agent handled escalation',
            is_draft: true,
            template: { s_id: templateSid.body.data[0].s_id },
            template_checklist_item_target_list: [{ object_target: { object_id: 'ba921835-cef2-5ca7-a973-281025ecc67a', object_type: 'DECISION_TREE' } }],
            title: 'Escalation Handling',
          },
        });
        cy.request({
          method: 'POST',
          url: '/api/v2/metadata',
          headers: { 'Content-Type': 'application/json' },
          body: {
            groupid: null,
            metadata_key: 'category_name',
            metadata_type: 'TICKET_REVIEW_CHECKLIST_CATEGORY',
            metadata_value: 'Testing Category 2',
            metadata_value_type: 'STRING',
            object_owner: null,
            object_target: { object_id: templateSid.body.data[0].s_id, object_type: 'TICKET_REVIEW_TEMPLATE' },
            s_object_creator: { object_id: 'ce7821ab-eeff-4e1b-8b24-8175669f9152', object_type: 'SL_USER' },
            object_id: 'ce7821ab-eeff-4e1b-8b24-8175669f9152',
            object_type: 'SL_USER',
            visibility: 'PUBLIC',
          },
        }).then((categoryMetadataTwo) => {
          cy.request({
            method: 'POST',
            url: '/api/v2/ticket/review/template/checklist_item',
            headers: { 'Content-Type': 'application/json' },
            body: {
              category_metadata: { s_id: categoryMetadataTwo.body.data[0].s_id },
              description: 'Testing description 1 for item 1 under Category 2',
              is_draft: true,
              template: { s_id: templateSid.body.data[0].s_id },
              template_checklist_item_target_list: [],
              title: 'Testing Item 1 under Category 2',
            },
          });
          cy.request({
            method: 'POST',
            url: '/api/v2/ticket/review/template/checklist_item',
            headers: { 'Content-Type': 'application/json' },
            body: {
              category_metadata: { s_id: categoryMetadataTwo.body.data[0].s_id },
              description: 'Checks whether agent handled case closure properly',
              is_draft: true,
              template: { s_id: templateSid.body.data[0].s_id },
              template_checklist_item_target_list: [{ object_target: { object_id: '5376113a-0852-55cb-be36-9d6109eb6346', object_type: 'DECISION_TREE' } }],
              title: 'Closure Requests',
            },
          });
          cy.request({
            method: 'POST',
            url: '/api/company/settings/support',
            headers: { 'Content-Type': 'application/json' },
            body: {
              keys: ['ace_settings', 'default_review_template'],
              replace: false,
              settings: { ace_settings: { default_review_template: templateSid.body.data[0].s_id } },
            },
          });
        });
      });
    });

export const creatingDraftChecklistTemplate = () => {
  const firstCategoryTitle = 'Testing Category 1';
  const firstCategoryFirstItemTitle = 'Testing Item 1 under Category 1';
  cy.visit(urlHelpers.aceQaScorecards);
  // eslint-disable-next-line cypress/no-unnecessary-waiting
  cy.wait(5000);
  cy.getByTestId('ace__reviewTemplateEditor__createNew').click();
  cy.waitForLoaders();
  cy.getByTestId('ace__reviewTemplateEditor__goToDrafts').click();
  // eslint-disable-next-line cypress/no-unnecessary-waiting
  cy.wait(5000);
  cy.getByTestId('ace__reviewTemplateListItem__0').click();
  cy.getByTestId('ace__reviewTemplateEditor__enterEditMode').click();
  // eslint-disable-next-line cypress/no-unnecessary-waiting
  cy.wait(3000);
  cy.getByTestId('ace__configurationChecklist__newCategory').click();
  // eslint-disable-next-line cypress/no-unnecessary-waiting
  cy.wait(3000);
  cy.getByTestId('ace__categoryItem__Input').should('be.visible');
  cy.getByTestId('ace__categoryItem__Input').type(firstCategoryTitle);
  cy.getByTestId('ace__checklistItem__title').should('be.visible');
  cy.getByTestId('ace__checklistItem__title').type(firstCategoryFirstItemTitle);
  cy.getByTestId('ace__checklistItem__save').click({ force: true });
  cy.getByTestId('ace__settings__tabs__current').click();
};

export const createFiveItemsChecklist = () =>
  cy
    .request({
      method: 'POST',
      url: '/api/v2/ticket/review/template',
      headers: { 'Content-Type': 'application/json' },
      body: {
        description: '',
        is_default: false,
        name: "Logo ipsum TEST123's checklist",
        root_template: null,
        s_object_creator: { object_id: 'ce7821ab-eeff-4e1b-8b24-8175669f9152', object_type: 'SL_USER' },
      },
    })
    .then((templateSid) => {
      cy.request({
        method: 'GET',
        url: `/api/v2/ticket/review/template/${templateSid.body.data[0].s_id}`,
        headers: { 'Content-Type': 'application/json' },
        body: {
          data: [{ s_id: templateSid.body.data[0].s_id }],
        },
      }).then((ratingElement) => {
        ratingElement.body.data[0].rating_element_list.forEach(function deleteRatingList1(existingRatingList) {
          deleteRatingAPI(existingRatingList.s_id);
        });
      });
      cy.request({
        method: 'POST',
        url: '/api/v2/ticket/review/template/rating_element',
        headers: { 'Content-Type': 'application/json' },
        body: {
          description: '',
          rating_score: 1,
          template: { s_id: templateSid.body.data[0].s_id },
        },
      });
      cy.request({
        method: 'POST',
        url: '/api/v2/ticket/review/template/rating_element',
        headers: { 'Content-Type': 'application/json' },
        body: {
          description: '',
          rating_score: 2,
          template: { s_id: templateSid.body.data[0].s_id },
        },
      });
      cy.request({
        method: 'POST',
        url: '/api/v2/ticket/review/template/rating_element',
        headers: { 'Content-Type': 'application/json' },
        body: {
          description: '',
          rating_score: 3,
          template: { s_id: templateSid.body.data[0].s_id },
        },
      });
      cy.request({
        method: 'POST',
        url: '/api/v2/ticket/review/template/rating_element',
        headers: { 'Content-Type': 'application/json' },
        body: {
          description: '',
          rating_score: 4,
          template: { s_id: templateSid.body.data[0].s_id },
        },
      });
      cy.request({
        method: 'POST',
        url: '/api/v2/ticket/review/template/rating_element',
        headers: { 'Content-Type': 'application/json' },
        body: {
          description: '',
          rating_score: 5,
          template: { s_id: templateSid.body.data[0].s_id },
        },
      });
      cy.request({
        method: 'POST',
        url: '/api/v2/metadata',
        headers: { 'Content-Type': 'application/json' },
        body: {
          groupid: null,
          metadata_key: 'category_name',
          metadata_type: 'TICKET_REVIEW_CHECKLIST_CATEGORY',
          metadata_value: 'Testing Category 1',
          metadata_value_type: 'STRING',
          object_owner: null,
          object_target: { object_id: templateSid.body.data[0].s_id, object_type: 'TICKET_REVIEW_TEMPLATE' },
          s_object_creator: { object_id: 'ce7821ab-eeff-4e1b-8b24-8175669f9152', object_type: 'SL_USER' },
          object_id: 'ce7821ab-eeff-4e1b-8b24-8175669f9152',
          object_type: 'SL_USER',
          visibility: 'PUBLIC',
        },
      }).then((categoryMetadata) => {
        cy.request({
          method: 'POST',
          url: '/api/v2/ticket/review/template/checklist_item',
          headers: { 'Content-Type': 'application/json' },
          body: {
            category_metadata: { s_id: categoryMetadata.body.data[0].s_id },
            description: 'Checks whether agent handled escalation',
            is_draft: true,
            template: { s_id: templateSid.body.data[0].s_id },
            template_checklist_item_target_list: [{ object_target: { object_id: 'ba921835-cef2-5ca7-a973-281025ecc67a', object_type: 'DECISION_TREE' } }],
            title: 'Escalation Handling',
          },
        });
        cy.request({
          method: 'POST',
          url: '/api/v2/ticket/review/template/checklist_item',
          headers: { 'Content-Type': 'application/json' },
          body: {
            category_metadata: { s_id: categoryMetadata.body.data[0].s_id },
            description: 'Testing description 1 for item 1',
            is_draft: true,
            template: { s_id: templateSid.body.data[0].s_id },
            template_checklist_item_target_list: [],
            title: 'Testing Item 1 under Category 1',
          },
        });
        cy.request({
          method: 'POST',
          url: '/api/v2/ticket/review/template/checklist_item',
          headers: { 'Content-Type': 'application/json' },
          body: {
            category_metadata: { s_id: categoryMetadata.body.data[0].s_id },
            description: 'Checks whether agent handled case closure properly',
            is_draft: true,
            template: { s_id: templateSid.body.data[0].s_id },
            template_checklist_item_target_list: [{ object_target: { object_id: '5376113a-0852-55cb-be36-9d6109eb6346', object_type: 'DECISION_TREE' } }],
            title: 'Closure Requests',
          },
        });
        cy.request({
          method: 'POST',
          url: '/api/v2/ticket/review/template/checklist_item',
          headers: { 'Content-Type': 'application/json' },
          body: {
            category_metadata: { s_id: categoryMetadata.body.data[0].s_id },
            description: 'Checks whether agent scheduled a requested call',
            is_draft: true,
            template: { s_id: templateSid.body.data[0].s_id },
            template_checklist_item_target_list: [{ object_target: { object_id: '62667080-8c9e-5c0e-95d6-885c0ab75758', object_type: 'DECISION_TREE' } }],
            title: 'Call Scheduling',
          },
        });
        cy.request({
          method: 'POST',
          url: '/api/v2/ticket/review/template/checklist_item',
          headers: { 'Content-Type': 'application/json' },
          body: {
            category_metadata: { s_id: categoryMetadata.body.data[0].s_id },
            description: 'Checks whether agent handled a priority change.',
            is_draft: true,
            template: { s_id: templateSid.body.data[0].s_id },
            template_checklist_item_target_list: [{ object_target: { object_id: 'c60e7a86-38f5-51d5-bb84-ea94835db47b', object_type: 'DECISION_TREE' } }],
            title: 'Priority Change Handling',
          },
        });
        cy.request({
          method: 'POST',
          url: '/api/v2/ticket/review/template/checklist_item',
          headers: { 'Content-Type': 'application/json' },
          body: {
            category_metadata: { s_id: categoryMetadata.body.data[0].s_id },
            description: 'Checks whether agent greeted customer and paraphrased issue.',
            is_draft: true,
            template: { s_id: templateSid.body.data[0].s_id },
            template_checklist_item_target_list: [{ object_target: { object_id: '5986a72a-041b-553f-a6bf-370aea44583b', object_type: 'DECISION_TREE' } }],
            title: 'Agent Greeting',
          },
        });
        cy.request({
          method: 'POST',
          url: '/api/company/settings/support',
          headers: { 'Content-Type': 'application/json' },
          body: {
            keys: ['ace_settings', 'default_review_template'],
            replace: false,
            settings: { ace_settings: { default_review_template: templateSid.body.data[0].s_id } },
          },
        });
      });
    });

export const creatingOneCategoryChecklist = () =>
  cy
    .request({
      method: 'POST',
      url: '/api/v2/ticket/review/template',
      headers: { 'Content-Type': 'application/json' },
      body: {
        description: '',
        is_default: false,
        name: "Logo ipsum TEST123's checklist",
        root_template: null,
        s_object_creator: { object_id: 'ce7821ab-eeff-4e1b-8b24-8175669f9152', object_type: 'SL_USER' },
      },
    })
    .then((templateSid) => {
      cy.request({
        method: 'GET',
        url: `/api/v2/ticket/review/template/${templateSid.body.data[0].s_id}`,
        headers: { 'Content-Type': 'application/json' },
        body: {
          data: [{ s_id: templateSid.body.data[0].s_id }],
        },
      }).then((ratingElement) => {
        ratingElement.body.data[0].rating_element_list.forEach(function deleteRatingList(existingRatingList) {
          deleteRatingAPI(existingRatingList.s_id);
        });
      });
      cy.request({
        method: 'POST',
        url: '/api/v2/ticket/review/template/rating_element',
        headers: { 'Content-Type': 'application/json' },
        body: {
          description: '',
          rating_score: 1,
          template: { s_id: templateSid.body.data[0].s_id },
        },
      });
      cy.request({
        method: 'POST',
        url: '/api/v2/ticket/review/template/rating_element',
        headers: { 'Content-Type': 'application/json' },
        body: {
          description: '',
          rating_score: 2,
          template: { s_id: templateSid.body.data[0].s_id },
        },
      });
      cy.request({
        method: 'POST',
        url: '/api/v2/ticket/review/template/rating_element',
        headers: { 'Content-Type': 'application/json' },
        body: {
          description: '',
          rating_score: 3,
          template: { s_id: templateSid.body.data[0].s_id },
        },
      });
      cy.request({
        method: 'POST',
        url: '/api/v2/ticket/review/template/rating_element',
        headers: { 'Content-Type': 'application/json' },
        body: {
          description: '',
          rating_score: 4,
          template: { s_id: templateSid.body.data[0].s_id },
        },
      });
      cy.request({
        method: 'POST',
        url: '/api/v2/ticket/review/template/rating_element',
        headers: { 'Content-Type': 'application/json' },
        body: {
          description: '',
          rating_score: 5,
          template: { s_id: templateSid.body.data[0].s_id },
        },
      });
      cy.request({
        method: 'POST',
        url: '/api/v2/metadata',
        headers: { 'Content-Type': 'application/json' },
        body: {
          groupid: null,
          metadata_key: 'category_name',
          metadata_type: 'TICKET_REVIEW_CHECKLIST_CATEGORY',
          metadata_value: 'Testing Category 1',
          metadata_value_type: 'STRING',
          object_owner: null,
          object_target: { object_id: templateSid.body.data[0].s_id, object_type: 'TICKET_REVIEW_TEMPLATE' },
          s_object_creator: { object_id: 'ce7821ab-eeff-4e1b-8b24-8175669f9152', object_type: 'SL_USER' },
          object_id: 'ce7821ab-eeff-4e1b-8b24-8175669f9152',
          object_type: 'SL_USER',
          visibility: 'PUBLIC',
        },
      }).then((categoryMetadata) => {
        cy.request({
          method: 'POST',
          url: '/api/v2/ticket/review/template/checklist_item',
          headers: { 'Content-Type': 'application/json' },
          body: {
            category_metadata: { s_id: categoryMetadata.body.data[0].s_id },
            description: 'Testing description 1 for item 1 under Category 1',
            is_draft: true,
            template: { s_id: templateSid.body.data[0].s_id },
            template_checklist_item_target_list: [],
            title: 'Testing Item 1 under Category 1',
          },
        });
        cy.request({
          method: 'POST',
          url: '/api/v2/ticket/review/template/checklist_item',
          headers: { 'Content-Type': 'application/json' },
          body: {
            category_metadata: { s_id: categoryMetadata.body.data[0].s_id },
            description: 'Checks whether agent handled escalation',
            is_draft: true,
            template: { s_id: templateSid.body.data[0].s_id },
            template_checklist_item_target_list: [{ object_target: { object_id: 'ba921835-cef2-5ca7-a973-281025ecc67a', object_type: 'DECISION_TREE' } }],
            title: 'Escalation Handling',
          },
        });
        cy.request({
          method: 'POST',
          url: '/api/v2/ticket/review/template/checklist_item',
          headers: { 'Content-Type': 'application/json' },
          body: {
            category_metadata: { s_id: categoryMetadata.body.data[0].s_id },
            description: 'Checks whether agent handled case closure properly',
            is_draft: true,
            template: { s_id: templateSid.body.data[0].s_id },
            template_checklist_item_target_list: [{ object_target: { object_id: '5376113a-0852-55cb-be36-9d6109eb6346', object_type: 'DECISION_TREE' } }],
            title: 'Closure Requests',
          },
        });
        cy.request({
          method: 'POST',
          url: '/api/company/settings/support',
          headers: { 'Content-Type': 'application/json' },
          body: {
            keys: ['ace_settings', 'default_review_template'],
            replace: false,
            settings: { ace_settings: { default_review_template: templateSid.body.data[0].s_id } },
          },
        });
      });
    });
export const creatingOneCategoryChecklistUI = () => {
  const firstCategoryTitle = 'Testing Category 1';
  const firstCategoryFirstItemTitle = 'Testing Item 1 under Category 1';
  cy.visit(urlHelpers.aceQaScorecards);
  // cy.getByTestId('ace__settings__trigger').click();
  // eslint-disable-next-line cypress/no-unnecessary-waiting
  cy.wait(5000);
  cy.getByTestId('ace__reviewTemplateEditor__createNew').click();
  // eslint-disable-next-line cypress/no-unnecessary-waiting
  cy.wait(5000);
  cy.getByTestId('ace__reviewTemplateEditor__goToDrafts').click();
  // eslint-disable-next-line cypress/no-unnecessary-waiting
  cy.wait(5000);
  cy.getByTestId('ace__reviewTemplateListItem__0').click();
  cy.getByTestId('ace__reviewTemplateEditor__enterEditMode').click();
  cy.getByTestId('ace__reviewTemplateEditor__ratingControl__5').click();
  cy.getByTestId('ace__configurationChecklist__newCategory').click();

  // Adding new category with custom item and library items
  cy.getByTestId('ace__categoryItem__Input').type(firstCategoryTitle);
  cy.getByTestId('ace__checklistItem__title').type(firstCategoryFirstItemTitle);
  cy.getByTestId('ace__checklistItem__save').click();

  // Adding Library items
  cy.getByTestId('ace__decisionTreePicker__trigger').click();
  cy.getByTestId('ace__decisionTreePicker__item__Escalation_Handling').click({ force: true });
  cy.getByTestId('ace__decisionTreePicker__add').click({ force: true });
  // eslint-disable-next-line cypress/no-unnecessary-waiting
  cy.wait(1000);
  cy.getByTestId('ace__decisionTreePicker__trigger').click();
  cy.getByTestId('ace__decisionTreePicker__item__Closure_Requests').click({ force: true });
  cy.getByTestId('ace__decisionTreePicker__add').click({ force: true });
  // eslint-disable-next-line cypress/no-unnecessary-waiting
  cy.wait(1000);
  cy.getByTestId('ace__reviewTemplateEditor__exitEditMode').click();
  cy.getByTestId('ace__reviewTemplateEditor__publish').click();
  cy.getByTestId('ace__confirmationModal__submit').click();
  cy.waitForLoaders();
};

export const creatingTwoCategoryChecklistUI = () => {
  const firstCategoryTitle = 'Testing Category 1';
  const firstCategoryFirstItemTitle = 'Testing Item 1 under Category 1';
  const secondCategoryTitle = 'Testing Category 2';
  const secondCategoryFirstItemTitle = 'Testing Item 1 under Category 2';
  cy.visit(urlHelpers.aceQaScorecards);
  // eslint-disable-next-line cypress/no-unnecessary-waiting
  cy.wait(5000);
  cy.getByTestId('ace__reviewTemplateEditor__createNew').click();
  cy.waitForLoaders();
  cy.getByTestId('ace__reviewTemplateEditor__goToDrafts').click();
  // eslint-disable-next-line cypress/no-unnecessary-waiting
  cy.wait(5000);
  cy.getByTestId('ace__reviewTemplateListItem__0').click();
  cy.getByTestId('ace__reviewTemplateEditor__enterEditMode').click();
  cy.getByTestId('ace__reviewTemplateEditor__ratingControl__5').click();
  cy.getByTestId('ace__configurationChecklist__newCategory').click();

  // Adding new category with custom item and library items
  cy.getByTestId('ace__categoryItem__Input').type(firstCategoryTitle);
  cy.getByTestId('ace__checklistItem__title').type(firstCategoryFirstItemTitle);
  cy.getByTestId('ace__checklistItem__save').click();

  // Adding Library items
  cy.getByTestId('ace__decisionTreePicker__trigger').click();
  cy.getByTestId('ace__decisionTreePicker__item__Escalation_Handling').click({ force: true });
  cy.getByTestId('ace__decisionTreePicker__add').click({ force: true });
  // eslint-disable-next-line cypress/no-unnecessary-waiting
  cy.wait(1000);

  cy.getByTestId('ace__configurationChecklist__newCategory').click();

  // Adding new category with custom item and library items
  cy.getByTestId('ace__categoryItem__Input').type(secondCategoryTitle);
  cy.getByTestId('ace__checklistItem__title').type(secondCategoryFirstItemTitle);
  cy.getByTestId('ace__checklistItem__save').click();

  // Adding Library items
  cy.getByTestId('ace__decisionTreePicker__trigger').click();
  cy.getByTestId('ace__decisionTreePicker__item__Closure_Requests').click({ force: true });
  cy.getByTestId('ace__decisionTreePicker__add').click({ force: true });
  // eslint-disable-next-line cypress/no-unnecessary-waiting
  cy.wait(1000);

  cy.getByTestId('ace__reviewTemplateEditor__exitEditMode').click();
  cy.getByTestId('ace__reviewTemplateEditor__publish').click();
  cy.getByTestId('ace__confirmationModal__submit').click();
  cy.waitForLoaders();
};

export const creatingOneCategoryWithOneItemChecklistUI = () => {
  const firstCategoryTitle = 'Testing Category 1';
  const firstCategoryFirstItemTitle = 'Testing Item 1 under Category 1';
  cy.visit(urlHelpers.aceQaScorecards);
  // cy.getByTestId('ace__settings__trigger').click();
  // eslint-disable-next-line cypress/no-unnecessary-waiting
  cy.wait(5000);
  cy.getByTestId('ace__reviewTemplateEditor__createNew').click();
  // eslint-disable-next-line cypress/no-unnecessary-waiting
  cy.wait(5000);
  cy.getByTestId('ace__reviewTemplateEditor__goToDrafts').click();
  cy.waitForLoaders();
  // hard wait is added for recent checklist to load in the draft page.
  // eslint-disable-next-line cypress/no-unnecessary-waiting
  cy.wait(5000);
  cy.getByTestId('ace__reviewTemplateListItem__0').click();
  cy.getByTestId('ace__reviewTemplateEditor__enterEditMode').click();
  cy.getByTestId('ace__reviewTemplateEditor__ratingControl__5').click();
  cy.getByTestId('ace__configurationChecklist__newCategory').click();

  // Adding new category with custom item and library items
  cy.getByTestId('ace__categoryItem__Input').type(firstCategoryTitle);
  cy.getByTestId('ace__checklistItem__title').type(firstCategoryFirstItemTitle);
  cy.getByTestId('ace__checklistItem__save').click();

  // Adding Library items
  cy.getByTestId('ace__decisionTreePicker__trigger').click();
  cy.getByTestId('ace__decisionTreePicker__item__Escalation_Handling').click({ force: true });
  cy.getByTestId('ace__decisionTreePicker__add').click({ force: true });
  // eslint-disable-next-line cypress/no-unnecessary-waiting
  cy.wait(1000);
  cy.getByTestId('ace__decisionTreePicker__trigger').click();
  cy.getByTestId('ace__decisionTreePicker__item__Closure_Requests').click({ force: true });
  cy.getByTestId('ace__decisionTreePicker__add').click({ force: true });
  // eslint-disable-next-line cypress/no-unnecessary-waiting
  cy.wait(1000);
  cy.getByTestId('ace__reviewTemplateEditor__exitEditMode').click();
  cy.getByTestId('ace__reviewTemplateEditor__publish').click();
  cy.getByTestId('ace__confirmationModal__submit').click();
  cy.waitForLoaders();
};
