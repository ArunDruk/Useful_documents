import { urlHelpers } from '../../../../utils';
import { acePage } from '../../../../pages';

describe('ACE Checklist Previous version', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.aceQaScorecards);
  });

  /*
   * Create checklist 1 and publish it.
   * Create checklist 2 and publish it.
   * Navigate to "Previous Version"  and select Checklist 1.
   * Click on "Duplicate" button for the checklist 1 version.
   * Edit the existing category with items.
   * Click on "Publish" button and navigate to current tab.
   * Validate that current checklist is updated with last made changes.
   */
  it('C6337: Verify the creation flow previous version non-empty state', { tags: '@PublishChecklist' }, () => {
    const secondCategoryTitle = 'Testing Category 2';

    acePage.creatingSingleChecklist();
    acePage.currentDraftTab().click();
    acePage.creatingSingleChecklist();
    acePage.previousVersionsTab().click();
    acePage.recentDraftTemplateLink().click();
    acePage.checklistDuplicateButton().click();
    acePage.gotoDraftButton().click();
    acePage.recentDraftTemplateLink().click();
    acePage.editDraftChecklistButton().click();
    acePage.categoryTitleTextInSamePageReview().eq(0).type(secondCategoryTitle);
    acePage.finishEditingButton().click();
    acePage.draftPublishButton().click();
    acePage.draftPublishConfirmButton().click();
    acePage.currentDraftTab().click();
    acePage.checklistHeaderTitle().contains(secondCategoryTitle);
  });
});
