import { creatingOneCategoryChecklistUI, creatingTwoCategoryChecklistUI } from '../support';
import { urlHelpers } from '../../../../utils';

beforeEach(() => {
  cy.loginByApi();
});

describe('ACE Checklist-Delete-worklfow', () => {
  const firstCategoryTitle = 'Testing Category 1';
  const firstCategoryFirstItemTitle = 'Testing Item 1 under Category 1';
  const secondCategoryTitle = 'Testing Category 2';
  const secondCategoryFirstItemTitle = 'Testing Item 1 under Category 2';

  it('C6331: Verify the ability to delete one item', { tags: '@PublishChecklist' }, function deleteOneItem() {
    // Removing checklist created via API as its crashing ACE/SH and its tracked in SLC-30928
    // creatingOneCategoryChecklist();
    creatingOneCategoryChecklistUI();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(5000);
    cy.visit(urlHelpers.aceQaScorecards);
    cy.getByTestId('ace__reviewTemplateEditor__duplicate').click();
    cy.getByTestId('ace__reviewTemplateEditor__goToDrafts').click();
    cy.getByTestId('ace__reviewTemplateListItem__0').click();
    cy.getByTestId('ace__reviewTemplateEditor__enterEditMode').click();

    // Deleting one custom item and one library
    cy.getByTestId('ace__checklistItem__delete').eq(0).click({ force: true });
    cy.getByTestId('ace__confirmationModal__submit').click({ force: true });
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(3000);
    cy.getByTestId('ace__checklistItem__delete').eq(0).click({ force: true });
    cy.getByTestId('ace__confirmationModal__submit').click({ force: true });
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(3000);
    cy.getByTestId('ace__reviewTemplateEditor__exitEditMode').click();
    cy.getByTestId('ace__reviewTemplateEditor__publish').click();
    cy.getByTestId('ace__confirmationModal__submit').click({ force: true });

    // Verifying that the deleted items are not displayed under category 1 in current tab
    cy.getByTestId('category-header-title').contains(firstCategoryTitle).should('be.visible');
    cy.getByTestId('category-item-title').contains(firstCategoryFirstItemTitle).should('not.to.exist');
    cy.getByTestId('category-item-title').contains('Closure Request').should('be.visible');
    cy.getByTestId('category-item-title').contains('Escalation Handling').should('not.to.exist');

    // Deleting the draft
    cy.getByTestId('ace__settings__tabs__current').click();
    cy.getByTestId('ace__settings__tabs__drafts').click();
    cy.getByTestId('ace__reviewTemplateListItem__0').click();
    cy.getByTestId('ace__reviewTemplateEditor__delete').click();
    cy.getByTestId('ace__confirmationModal__submit').click({ force: true });
  });

  it('C6332: Verify the ability to delete all items under a category', { tags: '@PublishChecklist' }, function deleteAlItems() {
    // Removing checklist created via API as its crashing ACE/SH and its tracked in SLC-30928
    // creatingTwoCategoryChecklist();
    creatingTwoCategoryChecklistUI();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(5000);
    cy.visit(urlHelpers.aceQaScorecards);
    cy.getByTestId('ace__reviewTemplateEditor__duplicate').click({ force: true });
    cy.getByTestId('ace__reviewTemplateEditor__goToDrafts').click();
    cy.getByTestId('ace__reviewTemplateListItem__0').click();
    cy.getByTestId('ace__reviewTemplateEditor__enterEditMode').click();

    // Deleting all items under a category
    cy.getByTestId('ace__checklistItem__delete').eq(2).click({ force: true });
    cy.getByTestId('ace__confirmationModal__submit').click({ force: true });
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(5000);

    cy.getByTestId('ace__checklistItem__delete').eq(2).click({ force: true });
    cy.getByTestId('ace__confirmationModal__submit').click({ force: true });
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(5000);
    cy.getByTestId('ace__reviewTemplateEditor__exitEditMode').click();
    cy.getByTestId('ace__reviewTemplateEditor__publish').click();
    cy.getByTestId('ace__confirmationModal__submit').click({ force: true });

    // Verifying that the deleted items are not displayed under category 1 in current tab
    cy.getByTestId('category-header-title').contains(secondCategoryTitle).should('not.to.exist');
    cy.getByTestId('category-item-title').contains(secondCategoryFirstItemTitle).should('not.to.exist');
    cy.getByTestId('category-item-title').contains('Closure Requests').should('not.to.exist');

    // Deleting the draft
    cy.getByTestId('ace__settings__tabs__current').click();
    cy.getByTestId('ace__settings__tabs__drafts').click();
    cy.getByTestId('ace__reviewTemplateListItem__0').click();
    cy.getByTestId('ace__reviewTemplateEditor__delete').click();
    cy.getByTestId('ace__confirmationModal__submit').click({ force: true });
  });
});
