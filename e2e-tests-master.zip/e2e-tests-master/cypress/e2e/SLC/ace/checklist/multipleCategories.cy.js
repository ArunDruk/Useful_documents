import { clearAgentFilter, creatingDraftChecklistTemplate, creatingOneCategoryWithOneItemChecklistUI, creatingTwoCategoryChecklistUI } from '../support';
import { urlHelpers } from '../../../../utils';
import { acePage } from '../../../../pages';

beforeEach(() => {
  cy.loginByApi();
  clearAgentFilter();
});

describe('ACE Checklist Page Third Part-multiple categories', () => {
  const firstCategoryTitle = 'Testing Category 1';
  const firstCategoryFirstItemTitle = 'Testing Item 1 under Category 1';
  // const firstCategorySecondtItemTitle = 'Testing Item 2 under Category 1';
  // const firstCategorySecondItemDescription = 'Testing description 2 for item 2 under Category 1';
  const firstCategoryFirstItemDescription = 'Testing description 1 for item 1 under Category 1';
  const firstCategoryThirdItemTitle = 'Testing Item 3 under Category 1';
  const secondCategoryTitle = 'Testing Category 2';
  const secondCategoryFirstItemTitle = 'Testing Item 1 under Category 2';
  const secondCategoryFirstItemDescription = 'Testing description 1 for item 1 under Category 2';

  // Inner block to apply beforeEach hook only for required tests
  describe('ACE - add 3-scale & 5-scale rating', () => {
    beforeEach(function caseIdGetter() {
      // TODO: (ikhalikov) Eliminate callback hell?
      cy.visit(urlHelpers.caseEvaluation);
      cy.getByTestId('caseEvaluation-collapsibleSidebar-title-Recommended')
        .invoke('text')
        .then((headerText) => {
          if (headerText === '0Recommended') {
            this.skip();
          } else {
            cy.get('[data-testid^=caseEvaluation-list-container-recommended]')
              .first()
              .invoke('attr', 'data-testid')
              .then((attrVal) => {
                cy.wrap(attrVal.split('-')[4]).as('caseId');
              });
          }
        });
    });

    // When clicking on "Start Review" SH gets crashed,its tracked in SLC-30928
    it('C6415: Verify the ability to add five scale rating checklist', { tags: '@PublishChecklist' }, function verifyFiveRating() {
      //  Few steps to select standard labels will be added soon
      cy.visit(urlHelpers.aceQaScorecards);
      cy.getByTestId('ace__reviewTemplateEditor__createNew').click();
      cy.waitForLoaders();
      cy.getByTestId('ace__reviewTemplateEditor__goToDrafts').click();
      // eslint-disable-next-line cypress/no-unnecessary-waiting
      cy.wait(5000);
      cy.getByTestId('ace__reviewTemplateListItem__0').click();
      cy.getByTestId('ace__reviewTemplateEditor__enterEditMode').click();
      cy.getByTestId('ace__reviewTemplateEditor__ratingControl__5').click();
      cy.getByTestId('ace__configurationChecklist__newCategory').click();

      // Adding new category with custom item and library items
      cy.getByTestId('ace__categoryItem__Input').type(firstCategoryTitle);
      cy.getByTestId('ace__checklistItem__title').type(firstCategoryFirstItemTitle);
      cy.getByTestId('ace__checklistItem__description').type(firstCategoryFirstItemDescription);
      cy.getByTestId('ace__checklistItem__save').click();

      // Adding five Library items
      cy.getByTestId('ace__decisionTreePicker__trigger').click();
      cy.getByTestId('ace__decisionTreePicker__item__Closure_Requests').click({ force: true });
      cy.getByTestId('ace__decisionTreePicker__add').click({ force: true });
      cy.getByTestId('ace__decisionTreePicker__trigger').click({ force: true });
      cy.getByTestId('ace__decisionTreePicker__item__Call_Scheduling').click({ force: true });
      cy.getByTestId('ace__decisionTreePicker__add').click({ force: true });
      cy.getByTestId('ace__decisionTreePicker__trigger').click();
      cy.getByTestId('ace__decisionTreePicker__item__Escalation_Handling').click({ force: true });
      cy.getByTestId('ace__decisionTreePicker__add').click({ force: true });
      cy.getByTestId('ace__decisionTreePicker__trigger').click();
      cy.getByTestId('ace__decisionTreePicker__item__Priority_Change_Handling').click({ force: true });
      cy.getByTestId('ace__decisionTreePicker__add').click({ force: true });
      // eslint-disable-next-line cypress/no-unnecessary-waiting
      cy.wait(1000);
      cy.getByTestId('ace__decisionTreePicker__trigger').click();
      cy.getByTestId('ace__decisionTreePicker__item___agent_capitalize__Greeting').click({ force: true });
      cy.getByTestId('ace__decisionTreePicker__add').click({ force: true });
      cy.getByTestId('ace__reviewTemplateEditor__exitEditMode').click();
      cy.getByTestId('ace__reviewTemplateEditor__publish').click();
      cy.getByTestId('ace__confirmationModal__submit').click();
      cy.waitForLoaders();
      cy.getByTestId('ace__settings__tabs__current').click();

      // Checking the published checklist is displayed in current checklist tab with five scale ratings
      cy.getByTestId('category-header-title').eq(0).contains(firstCategoryTitle).should('be.visible');
      cy.getByTestId('category-item-title').eq(0).contains(firstCategoryFirstItemTitle).should('be.visible');
      cy.getByTestId('category-item-description').eq(0).contains(firstCategoryFirstItemDescription).should('be.visible');
      cy.getByTestId('category-item-title').eq(1).contains('Closure Requests').should('be.visible');
      cy.getByTestId('category-item-description').eq(1).contains('Checks whether agent handled case closure properly').should('be.visible');
      cy.getByTestId('category-item-title').eq(2).contains('Call Scheduling').should('be.visible');
      cy.getByTestId('category-item-description').eq(2).contains('Checks whether agent scheduled a requested call').should('be.visible');
      cy.getByTestId('category-item-title').eq(3).contains('Escalation Handling').should('be.visible');
      cy.getByTestId('category-item-description').eq(3).contains('Checks whether agent handled escalation').should('be.visible');
      cy.getByTestId('category-item-title').eq(4).contains('Priority Change Handling').should('be.visible');
      cy.getByTestId('category-item-description').eq(4).contains('Checks whether agent handled a priority change.').should('be.visible');
      cy.getByTestId('category-item-title').eq(5).contains('Agent Greeting').should('be.visible');
      cy.getByTestId('category-item-description').eq(5).contains('greeted customer').should('be.visible');
      // TODO Ask Felipe to update the text in all Environment
      // cy.getByTestId('category-item-description').eq(5).contains('Checks whether agent greeted customer and paraphrased issue.').should('be.visible');
      cy.getByTestId('supportHub-caseComment-caseReview-rating-Poor').should('be.visible');
      cy.getByTestId('supportHub-caseComment-caseReview-rating-Bad').should('be.visible');
      cy.getByTestId('supportHub-caseComment-caseReview-rating-Neutral').should('be.visible');
      cy.getByTestId('supportHub-caseComment-caseReview-rating-Good').should('be.visible');
      cy.getByTestId('supportHub-caseComment-caseReview-rating-Great').should('be.visible');

      // Navigation to Manual QA page
      cy.visit(urlHelpers.caseEvaluation);
      cy.getByTestId(`caseEvaluation-list-container-recommended-${this.caseId}`).click();
      cy.waitForLoaders();
      acePage.startReviewButton().click();
      cy.waitForLoaders();

      // Checking whether five scale ratings are displayed in same page review page
      cy.getByTestId('supportHub-caseComment-caseReview-rating-Poor').eq(0).click();
      cy.getByTestId('supportHub-caseComment-caseReview-rating-Bad').eq(1).click();
      cy.getByTestId('supportHub-caseComment-caseReview-rating-Neutral').eq(2).click();
      cy.getByTestId('supportHub-caseComment-caseReview-rating-Good').eq(3).click();
      cy.getByTestId('supportHub-caseComment-caseReview-rating-Great').eq(4).click();
      cy.getByTestId('supportHub-caseComment-caseReview-rating-Not_Applicable').eq(5).click();
      cy.getByTestId('ace-case-review-category-Textarea_Testing Category 1').type('test-comments');
      cy.getByTestId('ace__caseReviewContainer__next').click();
      // eslint-disable-next-line cypress/no-unnecessary-waiting
      cy.wait(5000);
      // Checking whether selected ratings are displayed in review preview page
      cy.getByTestId('ace-review-rating-control-wrapper').eq(0).find('[data-testid="supportHub-caseComment-caseReview-rating-Poor"]').should('be.visible');
      cy.getByTestId('ace-review-rating-control-wrapper').eq(1).find('[data-testid="supportHub-caseComment-caseReview-rating-Bad"]').should('be.visible');
      cy.getByTestId('ace-review-rating-control-wrapper').eq(2).find('[data-testid="supportHub-caseComment-caseReview-rating-Neutral"]').should('be.visible');
      cy.getByTestId('ace-review-rating-control-wrapper').eq(2).find('[data-testid="supportHub-caseComment-caseReview-rating-Neutral"]').scrollIntoView();
      cy.getByTestId('ace-review-rating-control-wrapper').eq(3).find('[data-testid="supportHub-caseComment-caseReview-rating-Good"]').should('be.visible');
      cy.getByTestId('ace-review-rating-control-wrapper').eq(4).find('[data-testid="supportHub-caseComment-caseReview-rating-Great"]').should('be.visible');
      cy.getByTestId('ace-review-rating-control-wrapper').eq(5).find('[data-testid="supportHub-caseComment-caseReview-rating-Not_Applicable"]').should('be.visible');
    });

    // When clicking on "Start Review" SH gets crashed,its tracked in SLC-30928
    it('C6414: Verify the ability to add three scale rating checklist', { tags: '@PublishChecklist' }, function verifyThreeRating() {
      cy.visit(urlHelpers.aceQaScorecards);
      cy.getByTestId('ace__reviewTemplateEditor__createNew').click();
      cy.waitForLoaders();
      cy.getByTestId('ace__reviewTemplateEditor__goToDrafts').click();
      // eslint-disable-next-line cypress/no-unnecessary-waiting
      cy.wait(5000);
      cy.getByTestId('ace__reviewTemplateListItem__0').click();
      cy.getByTestId('ace__reviewTemplateEditor__enterEditMode').click();
      cy.getByTestId('ace__reviewTemplateEditor__ratingControl__3').click();
      cy.getByTestId('ace__configurationChecklist__newCategory').click();

      // Adding new category with custom item and library items
      cy.getByTestId('ace__categoryItem__Input').type(firstCategoryTitle);
      cy.getByTestId('ace__checklistItem__title').type(firstCategoryFirstItemTitle);
      cy.getByTestId('ace__checklistItem__description').type(firstCategoryFirstItemDescription);
      cy.getByTestId('ace__checklistItem__save').click();

      // Adding three library items
      cy.getByTestId('ace__decisionTreePicker__trigger').click();
      cy.getByTestId('ace__decisionTreePicker__item__Closure_Requests').click({ force: true });
      cy.getByTestId('ace__decisionTreePicker__add').click();
      cy.getByTestId('ace__decisionTreePicker__trigger').click();
      cy.getByTestId('ace__decisionTreePicker__item__Call_Scheduling').click({ force: true });
      cy.getByTestId('ace__decisionTreePicker__add').click({ force: true });
      cy.getByTestId('ace__decisionTreePicker__trigger').click();
      cy.getByTestId('ace__decisionTreePicker__item__Escalation_Handling').click({ force: true });
      cy.getByTestId('ace__decisionTreePicker__add').click({ force: true });
      cy.getByTestId('ace__reviewTemplateEditor__exitEditMode').click();
      cy.getByTestId('ace__reviewTemplateEditor__publish').click();
      cy.getByTestId('ace__confirmationModal__submit').click();
      cy.waitForLoaders();
      cy.getByTestId('ace__settings__tabs__current').click();

      // Checking the published checklist is displayed in current checklist tab with three scale ratings
      cy.getByTestId('category-header-title').eq(0).contains(firstCategoryTitle).should('be.visible');
      cy.getByTestId('category-item-title').eq(0).contains(firstCategoryFirstItemTitle).should('be.visible');
      cy.getByTestId('category-item-description').eq(0).contains(firstCategoryFirstItemDescription).should('be.visible');
      cy.getByTestId('category-item-title').eq(1).contains('Closure Requests').should('be.visible');
      cy.getByTestId('category-item-description').eq(1).contains('Checks whether agent handled case closure properly').should('be.visible');
      cy.getByTestId('category-item-title').eq(2).contains('Call Scheduling').should('be.visible');
      cy.getByTestId('category-item-description').eq(2).contains('Checks whether agent scheduled a requested call').should('be.visible');
      cy.getByTestId('category-item-title').eq(3).contains('Escalation Handling').should('be.visible');
      cy.getByTestId('category-item-description').eq(3).contains('Checks whether agent handled escalation').should('be.visible');
      cy.getByTestId('supportHub-caseComment-caseReview-rating-Bad').should('be.visible');
      cy.getByTestId('supportHub-caseComment-caseReview-rating-Neutral').should('be.visible');
      cy.getByTestId('supportHub-caseComment-caseReview-rating-Good').should('be.visible');

      // Navigation to Manual QA page
      cy.visit(urlHelpers.caseEvaluation);
      cy.getByTestId(`caseEvaluation-list-container-recommended-${this.caseId}`).click();
      cy.waitForLoaders();
      acePage.startReviewButton().click();
      cy.waitForLoaders();

      // Checking whether three scale ratings are displayed in same page review page
      cy.getByTestId('supportHub-caseComment-caseReview-rating-Bad').eq(0).click();
      cy.getByTestId('supportHub-caseComment-caseReview-rating-Neutral').eq(1).click();
      cy.getByTestId('supportHub-caseComment-caseReview-rating-Good').eq(2).click();
      cy.getByTestId('supportHub-caseComment-caseReview-rating-Not_Applicable').eq(3).click();
      cy.getByTestId('ace-case-review-category-Textarea_Testing Category 1').type('test-comments');
      cy.getByTestId('ace__caseReviewContainer__next').click();

      // Checking whether selected ratings are displayed in review preview page
      cy.getByTestId('ace-review-rating-control-wrapper').eq(0).find('[data-testid="supportHub-caseComment-caseReview-rating-Bad"]').should('be.visible');
      cy.getByTestId('ace-review-rating-control-wrapper').eq(1).find('[data-testid="supportHub-caseComment-caseReview-rating-Neutral"]').should('be.visible');
      cy.getByTestId('ace-review-rating-control-wrapper').eq(1).find('[data-testid="supportHub-caseComment-caseReview-rating-Neutral"]').scrollIntoView();
      cy.getByTestId('ace-review-rating-control-wrapper').eq(2).find('[data-testid="supportHub-caseComment-caseReview-rating-Good"]').should('be.visible');
      cy.getByTestId('ace-review-rating-control-wrapper').eq(3).find('[data-testid="supportHub-caseComment-caseReview-rating-Not_Applicable"]').should('be.visible');
    });
  });

  it('C6321: Verify the ability to create checklist with second category', { tags: '@PublishChecklist' }, () => {
    creatingDraftChecklistTemplate();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(5000);
    cy.getByTestId('ace__settings__tabs__drafts').click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(5000);
    cy.getByTestId('ace__reviewTemplateListItem__0').click();
    cy.getByTestId('ace__reviewTemplateEditor__enterEditMode').click({ force: true });
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(5000);
    cy.getByTestId('ace__configurationChecklist__newCategory').should('be.visible');
    cy.getByTestId('ace__configurationChecklist__newCategory').click({ force: true });
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(3000);

    // Adding second category to the existing draft
    cy.getByTestId('ace__categoryItem__Input').should('be.visible');
    cy.getByTestId('ace__categoryItem__Input').type(secondCategoryTitle);
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    cy.getByTestId('ace__checklistItem__title').type(secondCategoryFirstItemTitle);
    cy.getByTestId('ace__checklistItem__description').type(secondCategoryFirstItemDescription);
    cy.getByTestId('ace__checklistItem__save').click({ force: true });
    cy.getByTestId('ace__reviewTemplateEditor__exitEditMode').click();
    cy.getByTestId('ace__reviewTemplateEditor__publish').click();
    cy.getByTestId('ace__confirmationModal__submit').click();
    cy.waitForLoaders();
    cy.getByTestId('ace__settings__tabs__current').click();

    // Verifying the display of 2 categories in current tab
    cy.getByTestId('category-header-title').eq(0).contains(firstCategoryTitle).should('be.visible');
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(2000);
    cy.getByTestId('category-header-title').eq(1).contains(secondCategoryTitle).should('be.visible');
    cy.getByTestId('category-item-title').eq(1).contains(secondCategoryFirstItemTitle).should('be.visible');
    cy.getByTestId('category-item-description').eq(0).contains(secondCategoryFirstItemDescription).should('be.visible');
  });

  it('C6328: Verify the ability switch between three and five rating', { tags: '@PublishChecklist' }, () => {
    // Removing checklist created via API as its crashing ACE/SH and its tracked in SLC-30928
    // creatingTwoCategoryChecklist();
    creatingTwoCategoryChecklistUI();
    cy.visit(urlHelpers.aceQaScorecards);
    cy.getByTestId('ace__reviewTemplateEditor__duplicate').click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(5000);
    cy.getByTestId('ace__reviewTemplateEditor__goToDrafts').click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(5000);
    cy.getByTestId('ace__reviewTemplateListItem__0').click();
    cy.getByTestId('ace__reviewTemplateEditor__enterEditMode').click();

    // Verifying the diplay of 5 scale rating icon
    cy.getByTestId('ace__reviewTemplateEditor__ratingControl__5').click();
    cy.getByTestId('supportHub-caseComment-caseReview-rating-Poor').should('be.visible');
    cy.getByTestId('supportHub-caseComment-caseReview-rating-Bad').should('be.visible');
    cy.getByTestId('supportHub-caseComment-caseReview-rating-Neutral').should('be.visible');
    cy.getByTestId('supportHub-caseComment-caseReview-rating-Good').should('be.visible');
    cy.getByTestId('supportHub-caseComment-caseReview-rating-Great').should('be.visible');

    // Verifying the diplay of 3 scale rating icon
    cy.getByTestId('ace__reviewTemplateEditor__ratingControl__3').click();
    cy.getByTestId('supportHub-caseComment-caseReview-rating-Poor').should('not.to.exist');
    cy.getByTestId('supportHub-caseComment-caseReview-rating-Bad').should('be.visible');
    cy.getByTestId('supportHub-caseComment-caseReview-rating-Neutral').should('be.visible');
    cy.getByTestId('supportHub-caseComment-caseReview-rating-Good').should('be.visible');
    cy.getByTestId('supportHub-caseComment-caseReview-rating-Great').should('not.to.exist');
  });

  it('C6325: Verify the Cancel workflow while publishing a checklist', { tags: '@PublishChecklist' }, () => {
    // Removing checklist created via API as its crashing ACE/SH and its tracked in SLC-30928
    // creatingTwoCategoryChecklist();
    creatingTwoCategoryChecklistUI();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(5000);
    creatingDraftChecklistTemplate();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(5000);
    cy.getByTestId('ace__settings__tabs__drafts').click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(5000);
    cy.getByTestId('ace__reviewTemplateListItem__0').click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(3000);

    // Modifying the existing checklist draft
    cy.getByTestId('ace__reviewTemplateEditor__enterEditMode').click({ force: true });
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(4000);
    cy.getByTestId('ace__configurationChecklist__newCategory').click();
    cy.getByTestId('ace__categoryItem__Input').type('Testing Category 2-Cancel');
    cy.getByTestId('ace__checklistItem__title').type('Testing Item 1 under Category 2-Cancel');
    cy.getByTestId('ace__checklistItem__description').type('Testing description 1 for item 1 under Category 2-Cancel');
    cy.getByTestId('ace__checklistItem__save').click();
    cy.getByTestId('ace__decisionTreePicker__trigger').click({ force: true });
    cy.getByTestId('ace__decisionTreePicker__item__Priority_Change_Handling').scrollIntoView();
    cy.getByTestId('ace__decisionTreePicker__item___agent_capitalize__Greeting').should('be.visible');
    cy.getByTestId('ace__decisionTreePicker__item___agent_capitalize__Greeting').click({ force: true });
    cy.getByTestId('ace__decisionTreePicker__add').click();
    cy.getByTestId('ace__reviewTemplateEditor__exitEditMode').click();
    cy.getByTestId('ace__reviewTemplateEditor__publish').click();

    // Cancelling the Publish workflow
    cy.getByTestId('ace__confirmationModal__cancel').click({ force: true });
    cy.getByTestId('ace__settings__tabs__current').click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(2000);

    // Verifying that the checklist in current tab is same as checlist created in 703
    cy.getByTestId('category-header-title').eq(0).contains(firstCategoryTitle).should('be.visible');
    cy.getByTestId('category-header-title').eq(1).contains(secondCategoryTitle).should('be.visible');
    cy.getByTestId('category-header-title').contains('Testing Category 2-Cancel').should('not.to.exist');
    cy.getByTestId('category-item-title').contains('Testing Item 1 under Category 2-Cancel').should('not.to.exist');
    cy.getByTestId('category-item-title').contains('Agent Greeting').should('not.to.exist');
    cy.getByTestId('ace__settings__tabs__drafts').click();
    cy.getByTestId('ace__reviewTemplateListItem__0').click();
    cy.getByTestId('ace__reviewTemplateEditor__delete').click();
    cy.getByTestId('ace__confirmationModal__submit').click();
    cy.waitForLoaders();
  });

  it('C6333: Verify the ability to add a valid custom and libary item to a non-empty state checklist', { tags: '@PublishChecklist' }, () => {
    // creatingTwoCategoryChecklist();
    creatingTwoCategoryChecklistUI();
    cy.visit(urlHelpers.aceQaScorecards);

    cy.getByTestId('ace__reviewTemplateEditor__duplicate').click();
    cy.waitForLoaders();
    cy.getByTestId('ace__reviewTemplateEditor__goToDrafts').click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(3000);
    cy.getByTestId('ace__reviewTemplateListItem__0').click();

    // Adding a library item
    cy.getByTestId('ace__reviewTemplateEditor__enterEditMode').click();
    cy.getByTestId('ace__decisionTreePicker__trigger').eq(0).click({ force: true });
    cy.getByTestId('ace__decisionTreePicker__item__Call_Scheduling').click({ force: true });
    cy.getByTestId('ace__decisionTreePicker__add').click();

    // Adding a valid custom item
    cy.getByTestId('ace__configurationChecklist__newItem').eq(0).click();
    cy.getByTestId('ace__checklistItem__title').type(firstCategoryThirdItemTitle);
    cy.getByTestId('ace__checklistItem__save').click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(2000);
    cy.getByTestId('ace__reviewTemplateEditor__exitEditMode').click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    cy.getByTestId('ace__reviewTemplateEditor__publish').click();
    cy.getByTestId('ace__confirmationModal__submit').click();
    cy.waitForLoaders();
    cy.getByTestId('ace__settings__tabs__current').click();

    // verifying the display of valid custom in the current tab
    cy.getByTestId('category-item-title').contains('Call Scheduling').should('be.visible');
    cy.contains('[data-testid=category-item-title]', firstCategoryThirdItemTitle).should('be.visible');
  });

  it('C6416: Verify the publish workflow of duplicate checklist', { tags: '@PublishChecklist' }, () => {
    // creatingTwoCategoryChecklist();
    creatingOneCategoryWithOneItemChecklistUI();
    cy.visit(urlHelpers.aceQaScorecards);

    cy.getByTestId('ace__reviewTemplateEditor__duplicate').click();
    cy.waitForLoaders();
    cy.getByTestId('ace__reviewTemplateEditor__goToDrafts').click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(3000);
    cy.getByTestId('ace__reviewTemplateListItem__0').click();

    // Adding a library item
    cy.getByTestId('ace__reviewTemplateEditor__enterEditMode').click();
    cy.getByTestId('ace__decisionTreePicker__trigger').eq(0).click({ force: true });
    cy.getByTestId('ace__decisionTreePicker__item__Call_Scheduling').click({ force: true });
    cy.getByTestId('ace__decisionTreePicker__add').click();

    // Adding a valid custom item
    cy.getByTestId('ace__configurationChecklist__newItem').eq(0).click();
    cy.getByTestId('ace__checklistItem__title').type(firstCategoryThirdItemTitle);
    cy.getByTestId('ace__checklistItem__save').click();
    cy.waitForLoaders();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(2000);

    // Adding second category
    cy.getByTestId('ace__configurationChecklist__newCategory').click();
    cy.getByTestId('ace__categoryItem__Input').type(secondCategoryTitle);
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    cy.getByTestId('ace__checklistItem__title').type(secondCategoryFirstItemTitle);
    cy.getByTestId('ace__checklistItem__save').click();
    cy.waitForLoaders();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(2000);

    cy.getByTestId('ace__reviewTemplateEditor__exitEditMode').click();
    cy.waitForLoaders();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    cy.getByTestId('ace__reviewTemplateEditor__publish').click();
    cy.getByTestId('ace__confirmationModal__submit').click();
    cy.waitForLoaders();
    cy.getByTestId('ace__settings__tabs__current').click();
    cy.waitForLoaders();

    // verifying the display of valid custom in the current tab
    cy.getByTestId('category-item-title').contains('Call Scheduling').should('be.visible');
    cy.contains('[data-testid=category-item-title]', firstCategoryThirdItemTitle).should('be.visible');
    cy.contains('[data-testid=category-item-title]', secondCategoryFirstItemTitle).should('be.visible');
    cy.contains('[data-testid=category-header-title]', secondCategoryTitle).should('be.visible');
  });
});
