import { clearAgentFilter, creatingOneCategoryWithOneItemChecklistUI } from '../support';
import { urlHelpers } from '../../../../utils';

beforeEach(() => {
  cy.loginByApi();
  clearAgentFilter();
});

describe('ACE Checklist Page Second Part-library-items', () => {
  const firstCategoryTitle = 'Testing Category 1';
  const firstCategoryFirstItemTitle = 'Testing Item 1 under Category 1';
  const firstCategoryFirstItemDescription = 'Testing description for item 1 under Category 1';
  const firstCategorySecondItemDescription = 'Testing description for item 2 under Category 1';

  it('C6319: Verify the ability to create new checklist with library item', { tags: '@PublishChecklist' }, () => {
    cy.visit(urlHelpers.aceQaScorecards);
    cy.getByTestId('ace__reviewTemplateEditor__createNew').click();
    cy.waitForLoaders();
    cy.getByTestId('ace__reviewTemplateEditor__goToDrafts').click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(5000);
    cy.getByTestId('ace__reviewTemplateListItem__0').click();
    cy.getByTestId('ace__reviewTemplateEditor__enterEditMode').click();
    cy.getByTestId('ace__configurationChecklist__newCategory').click();
    cy.getByTestId('ace__categoryItem__Input').type(firstCategoryTitle);

    // Adding Custom Item 1
    cy.getByTestId('ace__checklistItem__title').type(firstCategoryFirstItemTitle);
    cy.getByTestId('ace__checklistItem__description').type(firstCategoryFirstItemDescription);
    cy.getByTestId('ace__checklistItem__save').click();

    // Adding Library Item 1
    cy.getByTestId('ace__decisionTreePicker__trigger').click();
    cy.getByTestId('ace__decisionTreePicker__item__Call_Scheduling').click({ force: true });
    cy.getByTestId('ace__decisionTreePicker__add').click();
    cy.getByTestId('ace__reviewTemplateEditor__exitEditMode').click();
    cy.getByTestId('ace__reviewTemplateEditor__publish').click();
    cy.getByTestId('ace__confirmationModal__submit').click();
    cy.waitForLoaders();
    cy.getByTestId('ace__settings__tabs__current').click();
    cy.getByTestId('category-item-title').contains('Call Scheduling').should('be.visible');
  });

  it('C6364: Verify the cancel workflow while adding a library item', { tags: '@PublishChecklist' }, () => {
    cy.visit(urlHelpers.aceQaScorecards);
    cy.getByTestId('ace__reviewTemplateEditor__createNew').click();
    cy.waitForLoaders();
    cy.getByTestId('ace__reviewTemplateEditor__goToDrafts').click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(5000);
    cy.getByTestId('ace__reviewTemplateListItem__0').click();
    cy.getByTestId('ace__reviewTemplateEditor__enterEditMode').click();
    cy.getByTestId('ace__configurationChecklist__newCategory').click();
    cy.getByTestId('ace__categoryItem__Input').type(firstCategoryTitle);

    //  Adding Custom Item 1
    cy.getByTestId('ace__checklistItem__title').type(firstCategoryFirstItemTitle);
    cy.getByTestId('ace__checklistItem__description').type(firstCategoryFirstItemDescription);
    cy.getByTestId('ace__checklistItem__save').click();

    // Adding Library Item and cancelling it
    cy.getByTestId('ace__configurationChecklist__newItem').should('be.visible');
    cy.getByTestId('ace__decisionTreePicker__trigger').should('be.visible');
    cy.getByTestId('ace__configurationChecklist__newCategory').should('be.visible');
    cy.getByTestId('ace__decisionTreePicker__trigger').click();
    cy.getByTestId('ace__decisionTreePicker__item__Call_Scheduling').click();
    cy.getByTestId('ace__decisionTreePicker__cancel').click();
    cy.getByTestId('ace__reviewTemplateEditor__exitEditMode').click();
    cy.getByTestId('ace__reviewTemplateEditor__publish').click();
    cy.getByTestId('ace__confirmationModal__submit').click();
    cy.waitForLoaders();
    cy.getByTestId('ace__settings__tabs__current').click();

    // Verifying that Library Item is not displayed in current tab
    cy.getByTestId('category-item-title').eq(0).contains(firstCategoryFirstItemTitle).should('be.visible');
    cy.getByTestId('category-item-title').eq(1).should('not.to.exist');
  });

  it('C6363: Verify that the previously added library item is disabled', { tags: '@PublishChecklist' }, () => {
    cy.visit(urlHelpers.aceQaScorecards);
    cy.getByTestId('ace__reviewTemplateEditor__createNew').click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(2000);
    cy.getByTestId('ace__reviewTemplateEditor__goToDrafts').click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(3000);
    cy.getByTestId('ace__reviewTemplateListItem__0').click();
    cy.getByTestId('ace__reviewTemplateEditor__enterEditMode').click();
    cy.getByTestId('ace__configurationChecklist__newCategory').click();
    cy.getByTestId('ace__categoryItem__Input').type(firstCategoryTitle);
    cy.getByTestId('ace__checklistItem__title').type(firstCategoryFirstItemTitle);
    cy.getByTestId('ace__checklistItem__description').type(firstCategoryFirstItemDescription);
    cy.getByTestId('ace__checklistItem__save').click();
    cy.getByTestId('ace__decisionTreePicker__trigger').click();

    // Adding Library item 1
    cy.getByTestId('ace__decisionTreePicker__item__Call_Scheduling').click();
    cy.getByTestId('ace__decisionTreePicker__add').click();
    cy.getByTestId('ace__decisionTreePicker__trigger').click();

    // Adding same Library item added previously
    cy.getByTestId('ace__decisionTreePicker__item__Call_Scheduling').should('not.to.exist');
    cy.getByTestId('ace__reviewTemplateEditor__cancel').click();
    cy.getByTestId('ace__reviewTemplateEditor__delete').click();
    cy.getByTestId('ace__confirmationModal__submit').click();
    cy.waitForLoaders();
  });

  it('C6334: Verify the ability to add an invalid custom item to a non-empty state checklist', { tags: '@PublishChecklist' }, () => {
    // Removing checklist created via API as its crashing ACE/SH and its tracked in SLC-30928
    // Duplicating an existing checklist is non-empty state checklist
    creatingOneCategoryWithOneItemChecklistUI();
    cy.visit(urlHelpers.aceQaScorecards);
    cy.getByTestId('ace__reviewTemplateEditor__duplicate').click();
    cy.waitForLoaders();
    cy.getByTestId('ace__reviewTemplateEditor__goToDrafts').click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(5000);
    cy.getByTestId('ace__reviewTemplateListItem__0').click();

    // Adding a Invalid custom item
    cy.getByTestId('ace__reviewTemplateEditor__enterEditMode').click();
    cy.getByTestId('ace__configurationChecklist__newItem').eq(0).click();
    cy.getByTestId('ace__checklistItem__description').type(firstCategorySecondItemDescription);
    cy.getByTestId('ace__checklistItem__save').should('be.disabled');
  });

  it('C6335: Verify the ability to add a valid library item to a non-empty state checklist', { tags: '@PublishChecklist' }, () => {
    // Removing checklist created via API as its crashing ACE/SH and its tracked in SLC-30928
    // Duplicating an existing checklist is non-empty state checklist
    creatingOneCategoryWithOneItemChecklistUI();
    cy.visit(urlHelpers.aceQaScorecards);
    cy.getByTestId('ace__reviewTemplateEditor__duplicate').click();
    cy.waitForLoaders();
    cy.getByTestId('ace__reviewTemplateEditor__goToDrafts').click();
    cy.waitForLoaders();
    // hard wait is added for recent checklist to load in the draft page.
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(5000);
    cy.getByTestId('ace__reviewTemplateListItem__0').click();

    // Adding a library item
    cy.getByTestId('ace__reviewTemplateEditor__enterEditMode').click();
    cy.getByTestId('ace__decisionTreePicker__trigger').eq(0).click({ force: true });
    cy.getByTestId('ace__decisionTreePicker__item__Call_Scheduling').click({ force: true });
    cy.getByTestId('ace__decisionTreePicker__add').click();
    cy.getByTestId('ace__reviewTemplateEditor__exitEditMode').click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(2000);
    cy.getByTestId('ace__reviewTemplateEditor__publish').click();
    cy.getByTestId('ace__confirmationModal__submit').click();
    cy.getByTestId('ace__settings__tabs__current').click();

    // verifying in current tab
    cy.getByTestId('category-item-title').contains('Call Scheduling').should('be.visible');
  });
});
