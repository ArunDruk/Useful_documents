import { creatingDraftChecklistTemplate, creatingOneCategoryChecklistUI } from '../support';
import { urlHelpers } from '../../../../utils';
import { acePage } from '../../../../pages';

describe('ACE Checklist-cancel-workflow', () => {
  beforeEach(() => {
    cy.loginByApi();
  });

  const firstCategoryTitle = 'Testing Category 1';
  const secondCategoryTitle = 'Testing Category 2-cancel';
  const secondCategoryFirstItemTitle = 'Testing Item 1 under Category 2-cancel';

  /**
   * Regression - C6329
   * - Navigate to the ace(QA scorecard) page
   * - Click on edit checklist button and entering flow of new checklist creation
   * - After traversing to Draft entering the edit flow of checklist
   * - Enter one edited name, click save button
   * - Verify whether the edited name is displayed by adding assertion for Title, Header
   */
  it('C6329: Verify the cancel workflow while modifying current checklist', { tags: '@PublishChecklist' }, function CancelModifiedChecklist() {
    // Removing checklist created via API as its crashing ACE/SH and its tracked in SLC-30928
    creatingOneCategoryChecklistUI();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(5000);
    cy.visit(urlHelpers.aceQaScorecards);
    acePage.editDraftChecklistButton().click();
    acePage.categoryTitleTextInSamePageReview().type('Testing Category 1-Edit');
    acePage.itemEditingButton().click({ force: true });
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(3000);
    acePage.itemEditSaveButton().click({ force: true });
    acePage.itemTitleTextField().type('Testing Item 1 under Category 1-Edit');
    acePage.aceChecklistReviewTemplateEditorCancleButton().click();
    acePage.checklistHeaderTitle().contains('Testing Category 1-Edit').should('be.visible');
    acePage.checklistItemTitle().contains('Testing Item 1 under Category 1-Edit').should('not.to.exist');
    acePage.checklistItemTitle().contains('Testing Item 1 under Category 1').should('be.visible');
  });

  /**
   * Regression - C6322
   * - Navigate to the ace(QA scorecard) page
   * - Navigate to Current tab
   * - Click on edit button
   * - Category name should be Editable.
   * - Only Manually added items title should be Editable.
   * - Only Manually added items description should be Editable.
   * - Items added from library should NOT be Editable.
   * - Edit Category name, Manually added items title  and  Manually added items description should be Editable.
   * - click on cancel button
   * - Verify whether the edited name is not retained for  Manually added items title  and  Manually added items description.
   * - Verify whether the edited category name is retained
   */
  it('C6322: Verify the cancel workflow while adding second category', { tags: '@PublishChecklist' }, () => {
    creatingDraftChecklistTemplate();
    cy.waitForLoaders();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(5000);
    acePage.draftsTab().click();
    cy.waitForLoaders();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(5000);
    acePage
      .recentDraftTemplateLink()
      .should('be.visible')
      .then(() => {
        acePage.recentDraftTemplateLink().click();
      });

    acePage.editDraftChecklistButton().click({ force: true });
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    acePage.addNewCategoryButton().click({ force: true });
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(2000);
    acePage.categoryTitleTextfield().should('be.visible');
    acePage.categoryTitleTextfield().type(secondCategoryTitle);
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    acePage.itemTitleTextField().type(secondCategoryFirstItemTitle);
    acePage.aceChecklistItemCancelButton().click();
    acePage.aceChecklistReviewTemplateEditorCancleButton().click();
    acePage.draftPublishButton().click({ force: true });
    acePage.draftPublishConfirmButton().click();
    cy.waitForLoaders();
    acePage.currentDraftTab().click();
    acePage.checklistHeaderTitle().eq(0).contains(firstCategoryTitle).should('be.visible');
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(2000);
    acePage.checklistHeaderTitle().contains(secondCategoryTitle).should('not.to.exist');
  });
});
