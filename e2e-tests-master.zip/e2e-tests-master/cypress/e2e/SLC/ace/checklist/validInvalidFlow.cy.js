import { clearAgentFilter } from '../support';
import { urlHelpers } from '../../../../utils';

beforeEach(() => {
  cy.loginByApi();
  clearAgentFilter();
});

describe('ACE Checklist Page First Part-valid-invalid-flow', () => {
  const firstCategoryTitle = 'Testing Category 1';
  const firstCategoryFirstItemTitle = 'Testing Item 1 under Category 1';
  const firstCategoryFirstItemDescription = 'Testing description 1 for item 1 under Category 1';
  const firstCategorysecondItemTitle = 'Testing Item 2 under Category 1';
  const firstCategorysecondItemDescription = 'Testing description 2 for item 2 under Category 1';

  it('C6413: Verify the empty Template creation flow', { tags: '@PublishChecklist' }, () => {
    cy.visit(urlHelpers.aceQaScorecards);
    cy.getByTestId('ace__reviewTemplateEditor__createNew').click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(2000);
    cy.getByTestId('ace__reviewTemplateEditor__goToDrafts').click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(3000);
    cy.getByTestId('ace__reviewTemplateListItem__0').click();
    cy.getByTestId('ace__reviewTemplateEditor__enterEditMode').click();
    cy.getByTestId('ace__configurationChecklist__newCategory').click();

    // Verifying the display of placeholder message
    cy.get("[placeholder='Define a category by which you are evaluating the case']").should('be.visible');
    cy.get("[placeholder='Enter an evaluation criterion that represents this category']").should('be.visible');
    cy.get("[placeholder='Criterion description (optional)']").should('be.visible');
    cy.getByTestId('ace__checklistItem__save').should('be.disabled');
    cy.getByTestId('ace__reviewTemplateEditor__exitEditMode').click();
    cy.getByTestId('ace__reviewTemplateEditor__publish').should('be.disabled');
    cy.getByTestId('ace__reviewTemplateEditor__delete').click();
    cy.getByTestId('ace__confirmationModal__submit').click();
    cy.waitForLoaders();
  });

  it('C6316: Verify the ability to create draft with empty category, valid item and description', { tags: '@PublishChecklist' }, () => {
    cy.visit(urlHelpers.aceQaScorecards);
    cy.getByTestId('ace__reviewTemplateEditor__createNew').click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(2000);
    cy.getByTestId('ace__reviewTemplateEditor__goToDrafts').click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(3000);
    cy.getByTestId('ace__reviewTemplateListItem__0').click();
    cy.getByTestId('ace__reviewTemplateEditor__enterEditMode').click();
    cy.getByTestId('ace__configurationChecklist__newCategory').click();
    cy.getByTestId('ace__checklistItem__title').type(firstCategoryFirstItemTitle);
    cy.getByTestId('ace__checklistItem__description').type(firstCategoryFirstItemDescription);
    cy.getByTestId('ace__checklistItem__save').should('be.disabled');
    cy.getByTestId('ace__reviewTemplateEditor__exitEditMode').click();
    cy.getByTestId('ace__reviewTemplateEditor__publish').should('be.disabled');
    cy.getByTestId('ace__reviewTemplateEditor__delete').click();
    cy.getByTestId('ace__confirmationModal__submit').click();
    cy.waitForLoaders();
  });

  it('C6317: Verify the ability to create draft with valid category, empty item and valid description', { tags: '@PublishChecklist' }, () => {
    cy.visit(urlHelpers.aceQaScorecards);
    cy.getByTestId('ace__reviewTemplateEditor__createNew').click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(2000);
    cy.getByTestId('ace__reviewTemplateEditor__goToDrafts').click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(3000);
    cy.getByTestId('ace__reviewTemplateListItem__0').click();
    cy.getByTestId('ace__reviewTemplateEditor__enterEditMode').click();
    cy.getByTestId('ace__configurationChecklist__newCategory').click();
    cy.getByTestId('ace__categoryItem__Input').type(firstCategoryTitle);
    cy.getByTestId('ace__checklistItem__description').type(firstCategoryFirstItemDescription);
    cy.getByTestId('ace__checklistItem__save').should('be.disabled');
    cy.getByTestId('ace__reviewTemplateEditor__exitEditMode').click();
    cy.getByTestId('ace__reviewTemplateEditor__publish').should('be.disabled');
    cy.getByTestId('ace__reviewTemplateEditor__delete').click();
    cy.getByTestId('ace__confirmationModal__submit').click();
    cy.waitForLoaders();
  });

  it('C6318: Verify the ability to create checklist with two items', { tags: '@PublishChecklist' }, () => {
    cy.visit(urlHelpers.aceQaScorecards);
    cy.getByTestId('ace__reviewTemplateEditor__createNew').click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(2000);
    cy.getByTestId('ace__reviewTemplateEditor__goToDrafts').click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(3000);
    cy.getByTestId('ace__reviewTemplateListItem__0').click();
    cy.getByTestId('ace__reviewTemplateEditor__enterEditMode').click();
    cy.getByTestId('ace__configurationChecklist__newCategory').click();
    cy.getByTestId('ace__categoryItem__Input').type(firstCategoryTitle);

    // Adding Custom Item 1
    cy.getByTestId('ace__checklistItem__title').type(firstCategoryFirstItemTitle);
    cy.getByTestId('ace__checklistItem__description').type(firstCategoryFirstItemDescription);
    cy.getByTestId('ace__checklistItem__save').click();

    // Adding Custom Item 2
    cy.getByTestId('ace__configurationChecklist__newItem').click();
    cy.getByTestId('ace__checklistItem__title').type(firstCategorysecondItemTitle);
    cy.getByTestId('ace__checklistItem__description').type(firstCategorysecondItemDescription);
    cy.getByTestId('ace__checklistItem__save').click({ force: true });
    cy.getByTestId('ace__configurationChecklist__newItem').click();
    cy.getByTestId('ace__reviewTemplateEditor__exitEditMode').click();
    cy.getByTestId('ace__reviewTemplateEditor__publish').click();
    cy.getByTestId('ace__confirmationModal__submit').click();
    cy.waitForLoaders();
    cy.getByTestId('ace__settings__tabs__current').click();
    cy.getByTestId('category-item-title').eq(1).contains(firstCategorysecondItemTitle).should('be.visible');
    cy.getByTestId('category-item-description').eq(1).contains(firstCategorysecondItemDescription).should('be.visible');
  });

  it('C6320: Verify the Cancel flow in checklist creation', { tags: '@PublishChecklist' }, () => {
    cy.visit(urlHelpers.aceQaScorecards);
    cy.getByTestId('ace__reviewTemplateEditor__createNew').click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(2000);
    cy.getByTestId('ace__reviewTemplateEditor__goToDrafts').click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(3000);
    cy.getByTestId('ace__reviewTemplateListItem__0').click();
    cy.getByTestId('ace__reviewTemplateEditor__enterEditMode').click();
    cy.getByTestId('ace__configurationChecklist__newCategory').click();
    cy.getByTestId('ace__categoryItem__Input').type(firstCategoryTitle);
    cy.getByTestId('ace__checklistItem__title').type(firstCategoryFirstItemTitle);
    cy.getByTestId('ace__checklistItem__description').type(firstCategoryFirstItemDescription);
    cy.getByTestId('ace__checklistItem__cancel').click();
    cy.getByTestId('ace__categoryItem__enterEditMode').contains(firstCategoryTitle).should('be.visible');
    cy.getByTestId('category-item-title').should('not.to.exist');
    cy.getByTestId('category-item-description').should('not.to.exist');
    cy.getByTestId('ace__reviewTemplateEditor__cancel').click();
    cy.getByTestId('ace__reviewTemplateEditor__delete').click();
    cy.getByTestId('ace__confirmationModal__submit').click();
    cy.waitForLoaders();
  });
});
