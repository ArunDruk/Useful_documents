import { urlHelpers } from '../../../../utils';
import { acePage, apiHelpers, datePicker, navBar, supportHub } from '../../../../pages';

describe('ACE - Verify Review Details Page, Order of category', () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.clearAgentFilterInACEPage();
    cy.visit(urlHelpers.aceQaScorecards);
    acePage.creatingDoubleCategoryChecklist();
    cy.waitForLoaders();

    acePage
      .checklistHeaderTitle()
      .first()
      .then((titleTextFirst) => {
        const titleNameFirst = titleTextFirst.text().trim();
        acePage
          .checklistHeaderTitle()
          .last()
          .then((titleTextSecond) => {
            const titleNameSecond = titleTextSecond.text().trim();

            cy.wrap(titleNameFirst).as('titleNameFirst');
            cy.wrap(titleNameSecond).as('titleNameSecond');

            // To avoid checklist page crashing issue currently using navbar flow tracking via-SLC-30928
            navBar.agentCoaching().click();
            cy.waitForLoaders();
            acePage
              .recommendedContainerHeader()
              .invoke('text')
              .then((headerTitle) => {
                if (headerTitle === '0Recommended') {
                  acePage.recommendedSidebarExpandButton().click();
                  datePicker.datePickerTrigger().eq(0).click();
                  datePicker.selectLastMonthWithOption(3);
                  datePicker.datePickerTrigger().eq(0).should('have.text', 'Last 3 months');
                  cy.waitForLoaders();
                }
              });
          });
      });
  });

  /*
   * Create checklist with 2 category and notice name of the category in the checklist.
   * Navigate to Ace page, Open any ticket in recommended tab.
   * Start review for a ticket, Complete a review.
   * Validate that category order is same in the recentlyt reviewed tab on the first ticket.
   */
  it('C6604: Verify that display of categories as individual column', { tags: '@PublishChecklist' }, function checklistVerify() {
    cy.waitForLoaders();
    acePage.recommendedCaseCard().first().click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
    acePage.startReviewButton().then(() => {
      acePage.startReviewButton().click();
      cy.waitForLoaders();
      acePage.categoryTitleTextInSamePageReview().eq(0).invoke('text').should('include', this.titleNameFirst);
      acePage.categoryTitleTextInSamePageReview().eq(1).invoke('text').should('include', this.titleNameSecond);
      acePage.goodRatingButton().click({ multiple: true });
      // eslint-disable-next-line cypress/no-unnecessary-waiting
      cy.wait(1000);
      acePage.nextReviewConfirmationPopupWindow().click();
      // eslint-disable-next-line cypress/no-unnecessary-waiting
      cy.wait(1000);
      acePage.completeReviewConfirmationPopupWindow().click();
      acePage.aceCaseSummaryCloseButton().click();
      supportHub.closeButton().click();
      cy.waitForLoaders();

      acePage.aceCardRatingItemLabel().eq(0).invoke('text').should('be.equal', this.titleNameFirst);
      acePage.aceCardRatingItemLabel().eq(1).invoke('text').should('be.equal', this.titleNameSecond);
    });
  });

  /*
   * Create checklist with 2 category and notice name of the category in the checklist.
   * Navigate to Ace page, Go to completed evaluation tab.
   * Validate that category title 1 and category title  is same in the recentlyt reviewed tab on the first ticket.
   */
  it('C6528: Verify that display of categories in completed evaluation page', { tags: '@PublishChecklist' }, function checklistCompletedEvaluationPageVerify() {
    acePage.completedEvaluationsTab().click();
    cy.waitForLoaders();
    acePage.groupByWeek();
    cy.waitForLoaders();
    acePage.completedEvaluationsTableChecklistHeaderTitleFirst().invoke('text').should('be.equal', this.titleNameFirst);
    acePage.completedEvaluationsTableChecklistHeaderTitleSecond().invoke('text').should('be.equal', this.titleNameSecond);
  });
});
