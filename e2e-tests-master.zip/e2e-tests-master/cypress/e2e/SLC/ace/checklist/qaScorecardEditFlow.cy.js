import { urlHelpers } from '../../../../utils';
import { acePage, apiHelpers } from '../../../../pages';

const firstCategoryEditTitle = 'Testing Category Edited 1';
const firstCategoryEditFirstItemTitle = 'Testing Item 1 Edited under Category 1';

describe('ACE - Verify Checklist Edit Verify', () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.clearAgentFilterInACEPage();
    cy.visit(urlHelpers.aceQaScorecards);
    acePage.creatingSingleChecklist();
    cy.waitForLoaders();
  });

  /*
   * Create checklist with 1 category and notice name of the category in the checklist.
   * Go to current tab, Click on edit button.
   * Change the tile name and item name, Items added from library should NOT be Editable.
   * Validate Title name and Item name are updated.
   */
  it('C6431: Verify that template creation flow non-empty state ', { tags: '@PublishChecklist' }, function checklistEditVerify() {
    acePage.currentDraftTab().click();
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    acePage.editDraftChecklistButton().click();
    acePage.categoryTitleTextInSamePageReview().click();
    acePage.categoryTitleTextfield().clear().type(firstCategoryEditTitle);
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(3000);
    // Items added from library should NOT be Editable are verified by below line itself
    acePage.itemEditingButton().click({ force: true });
    acePage.itemEditSaveButton().click();
    acePage.itemTitleTextField().clear().type(firstCategoryEditFirstItemTitle);
    acePage.saveChecklistButton().click();
    acePage.finishEditingButton().click();
    cy.waitForLoaders();
    acePage.checklistHeaderTitle().eq(0).invoke('text').should('contain', firstCategoryEditTitle);
    acePage.checklistItemTitle().eq(0).invoke('text').should('contain', firstCategoryEditFirstItemTitle);
  });
});
