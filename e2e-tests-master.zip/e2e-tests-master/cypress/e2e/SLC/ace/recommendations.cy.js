import { clearAgentFilter } from './support';
import { urlHelpers } from '../../../utils';
import { acePage, apiHelpers, datePicker, supportHub } from '../../../pages';

beforeEach(() => {
  cy.loginByApi();
  cy.visit(urlHelpers.caseEvaluation);
  clearAgentFilter();
  cy.slcHelpers.defaultToSupportHubThree();

  acePage
    .recommendedContainerHeader()
    .invoke('text')
    .then((headerText) => {
      if (headerText === '0Recommended') {
        acePage.recommendedSidebarExpandButton().click();
        datePicker.datePickerTrigger().eq(0).click();
        datePicker.selectLastMonthWithOption(3);
        datePicker.datePickerTrigger().eq(0).should('have.text', 'Last 3 months');
        cy.waitForLoaders();
      }
    });
});

afterEach(() => apiHelpers.clearAgentFilterInACEPage());

describe('ACE Recommendations Tab', () => {
  beforeEach(() => {
    cy.get('[data-testid^=caseEvaluation-list-container-recommended]')
      .first()
      .invoke('attr', 'data-testid')
      .then((attrVal) => {
        cy.wrap(attrVal.split('-')[4]).as('caseId');
      });
  });

  // When clicking on "Start Review" SH gets crashed,its tracked in SLC-30928
  it('C6535: Verify the display of progress percentage', { tags: 'Ace' }, function verifyProgressPercentage() {
    cy.getByTestId(`caseEvaluation-list-container-recommended-${this.caseId}`).click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
    acePage.startReviewButton().then(() => {
      acePage.startReviewButton().click();
      cy.waitForLoaders();
      cy.getByTestId('supportHub-actionWrapper-closeDialog').click();
      cy.reload();
      // eslint-disable-next-line cypress/no-unnecessary-waiting
      cy.wait(4000);
      cy.getByTestId(`caseEvaluation-list-container-reviewList-${this.caseId}`)
        .find('[data-testid="ace-card-percent-value"]')
        .should((percentage) => {
          expect(percentage.text().trim()).equal('0%');
        });
      cy.getByTestId(`caseEvaluation-list-container-reviewList-${this.caseId}`).click();
      acePage.continueReviewButton().should('be.visible');
      cy.getByTestId('supportHub-actionWrapper-closeDialog').click();
    });
  });

  // Test Case Added to SLC-Production folder
  it('C824: Verify that the tickets are filtered as per selected agent', { tags: 'Ace' }, () => {
    cy.waitForLoaders();
    cy.getByTestId('ace-case-review-agantName')
      .first()
      .invoke('text')
      .then((agentNameRecommendationTab) => {
        cy.getByTestId('ace__agentFilter__trigger').click();
        cy.getByTestId('filters-scoreFilters-searchOptionFilter-searchInput').type(agentNameRecommendationTab);
        cy.get("[type='checkbox']").first().click({ force: true });
        cy.getByTestId('global-filter--selected--sl_assignee_id').contains('1 selected').should('be.visible');
        cy.getByTestId('global-filter--selected--sl_assignee_id').click();
        cy.getByTestId('ace-evaluations-filters-agent-label').contains(agentNameRecommendationTab).should('be.visible');
        cy.getByTestId('filters-scoreFilters-searchOptionFilter-applyFilterBtn').click();
        cy.getByTestId('ace-case-review-agantName').eq(0).contains(agentNameRecommendationTab).should('be.visible');
      });
  });
});
