import { urlHelpers } from '../../../utils';
import { acePage, supportHub } from '../../../pages';

describe('ACE - Interaction labels', () => {
  beforeEach(() => {
    cy.intercept('POST', 'api/v2/signal').as('postInteraction');
    cy.intercept('DELETE', 'api/v2/signal/*').as('deleteInteraction');

    cy.loginByApi();
    cy.visit(urlHelpers.caseEvaluation);

    acePage.recommendationsTab().click();
    acePage
      .recommendedContainerHeader()
      .invoke('text')
      .then((headerTitle) => {
        if (headerTitle === '0Recommended') this.skip();
      });

    acePage.recommendedCaseCard().eq(3).click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
  });

  /*
   * Get the case comment text at a given index
   * Select the same case comment completely
   *
   * Click the 'Interaction' icon button that appears in a popup
   * Select the first option in the interaction label options popup
   * Click the Apply button
   * Wait for the API request to happen
   *
   * Verify that first interacted case comment matches that of the selected comment
   *
   * Hover over that interacted case comment
   * Verify that the Preview popup is visible
   * Click the 'Remove label' button
   * Wait for the delete request to happen
   *
   * Verify that first interacted case comment doesn't match the selected comment
   */
  it('C840: should remove disagreed label', { tags: ['ACE', 'staging'] }, () => {
    const targetCaseCommentIndex = 0;

    supportHub
      .commonCaseCommentText()
      .eq(targetCaseCommentIndex)
      .text()
      .then((caseComment) => {
        supportHub.selectCaseCommentText(targetCaseCommentIndex);
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(500);
        supportHub.caseCommentAddInteractionButton().click();
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(500);
        supportHub.commonInteractionPopupCheckbox().first().click({ force: true });
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(500);
        supportHub.interactionPopupApplyButton().click({ force: true });
        cy.wait('@postInteraction');
        cy.waitForLoaders();

        supportHub.interactedCaseCommentText().first().should('be.visible').and('have.text', caseComment);

        supportHub.interactedCaseCommentText().first().realHover({ pointer: 'mouse' });
        supportHub.interactionPreviewPopupContainer().should('be.visible');
        supportHub.interactionPreviewPopupRemoveButton().click();
        cy.wait('@deleteInteraction');

        supportHub.interactedCaseCommentText().first().should('not.have.text', caseComment);
      });
  });
});
