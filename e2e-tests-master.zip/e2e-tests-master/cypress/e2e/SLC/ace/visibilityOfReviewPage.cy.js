import { urlHelpers } from '../../../utils';
import { acePage, apiHelpers, datePicker, supportHub } from '../../../pages';

describe('ACE - Review page validations', () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.clearAgentFilterInACEPage();
    cy.visit(urlHelpers.caseEvaluation);
    cy.waitForLoaders();

    acePage
      .recommendedContainerHeader()
      .invoke('text')
      .then((headerText) => {
        if (headerText === '0Recommended') {
          acePage.recommendedSidebarExpandButton().click();
          datePicker.datePickerTrigger().eq(0).click();
          datePicker.selectLastMonthWithOption(3);
          datePicker.datePickerTrigger().eq(0).should('have.text', 'Last 3 months');
          cy.waitForLoaders();
        }
      });
    acePage
      .recommendedSidebarCaseIDs()
      .eq(0)
      .invoke('attr', 'data-testid')
      .then((attrVal) => {
        cy.wrap(attrVal.split('-')[4]).as('caseId');
      });
  });

  /*
   * Under recommendation tab,Open any ticket.
   * Click on "Start Review" button.
   * Validate the display of top bar of SH panel{Agent Name, Case number, CRM link, Case status, Case Priority}.
   */
  // Todo: CRM link verification link is missing here.
  it('C6768: validate display of review page', { tags: ['ACE', 'staging'] }, function validateReviewPage() {
    acePage.recommendedCaseCard(this.caseId).click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
    supportHub.caseOwnerLabel().then((buttonTextFirst) => {
      const agentName = buttonTextFirst.text();
      supportHub.caseFieldPriorityLabel().then((buttonTextThird) => {
        const priorityLabel = buttonTextThird.text();

        acePage.startReviewButton().then(() => {
          acePage.startReviewButton().click();
          cy.waitForLoaders();
          acePage.nextReviewConfirmationPopupWindow().should('be.visible');
          acePage.caseReviewHeaderTitle().should('be.visible').and('contain', 'Case Review');
          acePage.commonAgentNameLabel().should('be.visible').and('contain', agentName);
          acePage.reviewPageCaseId().should('be.visible').and('contain', this.caseId);
          acePage.reviewPageCaseFieldPriority().should('be.visible').and('contain', priorityLabel);
          acePage.reviewPageCaseFieldStatus().should('be.visible').and('contain', 'Closed');
          acePage.crmLinkReviewPage().should('be.visible');
        });
        supportHub.closeButton().click();
      });
    });
  });

  /*
   * Under recommendation tab,Open any ticket.
   * Click on "Start Review" button.
   * Validate the display of top bar of SH panel{Agent Name, Case number, CRM link, Case status, Case Priority}
   * Click on 'Back to case details' button.
   * Validate the display of top bar of SH panel{Continue case review option}
   */
  it('C6769: Verify the display of different panel', { tags: ['ACE', 'staging'] }, () => {
    acePage
      .aceCaseID()
      .eq(0)
      .then((buttonTextFirst) => {
        const caseId = buttonTextFirst.text();
        acePage
          .commonAgentNameLabel()
          .eq(0)
          .then((buttonTextSecond) => {
            const agentName = buttonTextSecond.text();

            acePage.recommendedCaseCard().eq(0).click();
            cy.waitForLoaders();
            supportHub.baseContainer().should('be.visible');
            cy.waitForLoaders();
            supportHub.caseFieldPriorityLabel().then((buttonTextThird) => {
              const priorityLabel = buttonTextThird.text();

              acePage.startReviewButton().then(() => {
                acePage.startReviewButton().click();
                cy.waitForLoaders();
                acePage.nextReviewConfirmationPopupWindow().should('be.visible');
                acePage.caseReviewHeaderTitle().should('be.visible').and('contain', 'Case Review');
                acePage.commonAgentNameLabel().should('be.visible').and('contain', agentName);
                acePage.reviewPageCaseId().should('be.visible').and('contain', caseId);
                acePage.reviewPageCaseFieldPriority().should('be.visible').and('contain', priorityLabel);
                acePage.reviewPageCaseFieldStatus().should('be.visible').and('contain', 'Closed');
                acePage.crmLinkReviewPage().should('be.visible');
                // eslint-disable-next-line cypress/no-unnecessary-waiting
                cy.wait(500);
                acePage.backButtonInSamePageReview().should('be.visible').click();
                acePage.continueReviewButton().should('be.visible').and('contain', 'Continue case review');
              });
              supportHub.closeButton().click();
            });
          });
      });
  });
});
