import { urlHelpers } from '../../../utils';
import { acePage, apiHelpers, globalFilters, supportHub } from '../../../pages';

describe('Ace Page - Verify all tabs', () => {
  beforeEach(() => {
    cy.intercept('POST', 'search/virtual_groups/_search*').as('agentSearch');
    cy.intercept('PUT', 'api/users/dashboard_settings').as('updateUserSettings');

    cy.loginByApi();
    apiHelpers.clearAgentFilterInACEPage();
    cy.visit(urlHelpers.caseEvaluation);
    cy.waitForLoaders();
  });

  afterEach(() => apiHelpers.clearAgentFilterInACEPage());

  /* // Test Case Added to SLC-Production folder
   * Open the Ace page.
   * Verify the visibility of Recommendations and Completed Evaluations tab.
   */
  it('C9293: Validate the display of agent coaching tabs', { tags: ['Ace', 'staging', 'prod'] }, () => {
    acePage.recommendationsTab().invoke('attr', 'data-active').should('include', 'true');
    acePage.recommendationsTab().should('be.visible').invoke('text').should('be.equal', 'Recommendations');
    acePage.completedEvaluationsTab().invoke('attr', 'data-active').should('include', 'false');
    acePage.completedEvaluationsTab().should('be.visible').invoke('text').should('be.equal', 'Completed evaluations');
  });

  /** // Test Case Added to SLC-Production folder
   * Open the Ace page.
   * Click on Recommended Tab.
   * Validate that at least 1 ticket is displayed in the recommended column.
   */
  it('C9336: Validate the display of tickets in the recommended tab', { tags: ['Ace', 'staging', 'prod'] }, () => {
    acePage.recommendationsTab().should('be.visible').click();
    acePage.aceCaseListContainer().find('[class^="CaseListBase__CardWrapper"]').its('length').should('be.gte', 1);
    acePage.aceAgentCaseList().should('be.visible');
    acePage.recommendedCaseCard().first().click();
    supportHub.baseContainer().should('be.visible');
    supportHub.closeButton().click();
  });

  /** // Test Case Added to SLC-Production folder
   * Open the Ace page.
   * Click on Completed Evaluation Tab.
   * Validate the display of Timeframes[Last 3 weeks, Last 2 Weeks, This week]in the top left corner below the tabs.
   */
  it('C9319: Verify the display of timeframes in Completed evaluations tab', { tags: ['Ace', 'staging', 'prod'] }, () => {
    acePage.completedEvaluationsTab().click();
    acePage.datePeriod3WeeksTab().should('be.visible').and('contain', 'Last 3 weeks');
    acePage.datePeriod2WeeksTab().should('be.visible').and('contain', 'Last 2 weeks');
    acePage.datePeriodThisWeekTab().should('be.visible').and('contain', 'This week');
  });

  /**
   * Open the Ace page.
   * Click on Completed Evaluation Tab.
   * Validate the display of data 0 completed tickets, nn in progress, nn recommended should be displayed.
   */
  it('C6521: Verify the display of "Agents to be reviewed" details in Completed evaluations tab', { tags: ['Ace', 'staging'] }, function verifyAgentsReviewedDetails() {
    // Agent Name is hardcoded. This will be used until we get API to fetch agent whose cases have some completed tickets, nn in progress, nn recommended.
    const agentName = 'Evan Boehm';

    acePage.completedEvaluationsTab().click();
    cy.waitForLoaders();
    acePage.agentFilterButton().click();
    globalFilters.quickFilterSearchFieldInput().type(agentName);
    cy.wait('@agentSearch');
    acePage
      .agentCaseCount()
      .invoke('text')
      .then((agentCaseCountText) => {
        if (!agentCaseCountText.includes('6 cases')) {
          this.skip();
        } else {
          globalFilters.quickFilterSearchResultList().first().find('input[type=checkbox]').click({ force: true });
          globalFilters.filterApplyButton().click();
          cy.wait('@updateUserSettings');
          cy.waitForLoaders();
          acePage.completedEvaluationsTableAgentColumn().should('be.visible').and('contain', 'Evan Boehm');
          acePage.completedEvaluationsTableAgentItemContent().should('be.visible').and('contain', '0 cases closed this week');
        }
      });
  });
});
