import moment from 'moment';

import { urlHelpers } from '../../../utils';
import { agentInsights, apiHelpers } from '../../../pages';

const calculateMedianDuration = (time) => {
  const duration = moment.duration(time).asDays();
  const durationInDays = Math.floor(duration);
  const durationInHours = Math.round((duration - durationInDays) * 24);

  return durationInDays > 0 ? `${durationInDays} Days, ${durationInHours} Hours` : `${durationInHours} Hours`;
};

describe('Agent Insights - Median Metrics', { tags: ['Agent Insights', 'staging', 'prod'] }, () => {
  beforeEach(() => {
    cy.loginByApi();

    cy.slcHelpers.getDetailsOfAgentsWithCases().then((agentDetails) => {
      const agentDetail = Cypress._.sample(agentDetails);
      cy.wrap(agentDetail.id).as('agentId');

      cy.visit(urlHelpers.agentInsights.agentPage(agentDetail.id));
    });
  });

  /*
   * Validate the following,
   * - Median Case Open Time label is visible and the value matches API data
   * - Median Response Time label is visible and the value matches API data
   * - Median Conversation Count Label is visible and the value matches API data
   */
  it('C485: should validate median metrics format', function validateMedianMetrics() {
    apiHelpers.getAgentMedianMetrics(this.agentId).then((metrics) => {
      agentInsights.medianCaseOpenTimeLabel().should('be.visible');
      agentInsights.medianCaseOpenTimeValue().should('have.text', calculateMedianDuration(metrics.sl_open_time_ms));

      agentInsights.medianResponseTimeLabel().should('be.visible');
      agentInsights.medianResponseTimeValue().should('have.text', calculateMedianDuration(metrics.sl_max_follow_up_time_ms));

      agentInsights.medianConversationCountLabel().should('be.visible');
      agentInsights.medianConversationCountValue().should('have.text', metrics.sl_comment_count);
    });
  });
});
