import { urlHelpers } from '../../../utils';
import { agentInsights, apiHelpers, consolePage } from '../../../pages';

describe('Agent Insights: Acknowledgement Workflow', () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.clearRecentlyVisitedAgentInsight();
    cy.slcHelpers.getDetailsOfAgentsWithCases().then((agentDetails) => {
      const agentDetail = Cypress._.sample(agentDetails);
      cy.wrap(agentDetail).as('agentDetail');
      cy.visit(urlHelpers.agentInsights.agentPage(agentDetail.id));
      cy.waitForLoaders();
    });
  });

  afterEach(() => {
    consolePage.selectAllSignalsInDropdown();
    consolePage.selectShowAllInDropdown();
    consolePage.groupByElapsedTime();
  });

  /*
   * Go to Agents insights page, Search any Agent name.
   * Click on the Need Attention tab, Click the Elasped Time option in the groupedby dropdown.
   * While hovering on cases 'Acknowledge' tick mark is showing. Click the tick mark.
   * Validate that Acknowledged by QA with Cross icon should be displayed.
   * Click the Show Acknowledged option in the dropdown, Click on Cross icon in a feed.
   * Validate that Acknowledged by QA with Cross icon should not be displayed.
   */
  it('C129419: Verify the acknowledgement workflow in  Need attention tab', { tags: ['Agents', 'staging'] }, () => {
    agentInsights.getTabsByName('need_attention').eq(1).click();
    consolePage.selectAllSignalsInDropdown();
    consolePage.selectShowAllInDropdown();
    consolePage.groupByElapsedTime();
    consolePage.expandAllConsoleLists();
    consolePage.consoleTabsShowingHeaderTitle().should('exist');
    consolePage.consoleTabsShowingHeaderTitle().invoke('text').should('contain', `Showing`);
    consolePage.consoleSentimentsTabsHeaderTitle().should('exist');
    consolePage.consoleSentimentsTabsHeaderTitle().invoke('text').should('contain', `Need Attention`);
    cy.waitForLoaders();
    consolePage.acknowledgeDropdown().click({ force: true });
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    consolePage.acknowledgeDropdownValueAll().should('be.visible').and('contain', `Show all`);
    consolePage.acknowledgeDropdownValueAck().should('be.visible').and('contain', `Show Acknowledged`);
    consolePage.acknowledgeDropdownValueUnack().should('be.visible').and('contain', `Show Unacknowledged`);
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    consolePage.caseCard().eq(0).scrollIntoView().trigger('mouseover');
    consolePage.sentimentAckButton().eq(0).scrollIntoView().click({ force: true });
    consolePage
      .caseCardHeaderText()
      .invoke('text')
      .should('match', /acknowledged\s*byQA/);
    consolePage.acknowledgeLabelWithCrossIcon().eq(0).scrollIntoView().should('be.visible');
    consolePage.selectShowAcknowledgedInDropdown();
    consolePage.caseCard().eq(0).invoke('text').should('contain', 'acknowledged by');
    consolePage
      .caseCardTicketIdLabel()
      .eq(0)
      .then((caseNo) => {
        const caseID = caseNo.text();

        consolePage.acknowledgeLabelWithCrossIcon().eq(0).scrollIntoView().should('be.visible');
        consolePage.acknowledgeLabelWithCrossIcon().eq(0).trigger('mouseover');
        consolePage.acknowledgeLabelTooltip().invoke('text').should('include', 'Remove acknowledgement');
        consolePage.acknowledgeLabelWithCrossIcon().eq(0).scrollIntoView().click();
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(1000);
        consolePage.selectShowUnacknowledgedInDropdown();
        cy.get('body').should('contain', caseID);
        consolePage.selectShowAcknowledgedInDropdown();
        cy.get('body').should('not.contain', caseID);
      });
  });

  /*
   * Go to Agents insights page, Search any Agent name.
   * Click on the Negative sentiment tab, Click the Elasped Time option in the groupedby dropdown.
   * While hovering on cases 'Acknowledge' tick mark is showing. Click the tick mark.
   * Validate that Acknowledged by QA with Cross icon should be displayed.
   * Click the Show Acknowledged option in the dropdown, Click on Cross icon in a feed.
   * Validate that Acknowledged by QA with Cross icon should not be displayed.
   */
  it('C129420: Verify the acknowledgement workflow in Negative Sentiment tab', { tags: ['Agents', 'staging'] }, () => {
    agentInsights.getTabsByName('negative_sentiments').eq(1).click();
    consolePage.selectAllSignalsInDropdown();
    consolePage.selectShowAllInDropdown();
    consolePage.groupByElapsedTime();
    consolePage.expandAllConsoleLists();
    consolePage.consoleTabsShowingHeaderTitle().should('exist');
    consolePage.consoleTabsShowingHeaderTitle().invoke('text').should('contain', `Showing`);
    consolePage.consoleSentimentsTabsHeaderTitle().should('exist');
    consolePage.consoleSentimentsTabsHeaderTitle().invoke('text').should('contain', `Negative Sentiments`);
    consolePage.acknowledgeDropdown().click({ force: true });
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    consolePage.acknowledgeDropdownValueAll().should('be.visible').and('contain', `Show all`);
    consolePage.acknowledgeDropdownValueAck().should('be.visible').and('contain', `Show Acknowledged`);
    consolePage.acknowledgeDropdownValueUnack().should('be.visible').and('contain', `Show Unacknowledged`);
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    consolePage.caseCard().eq(0).scrollIntoView().trigger('mouseover');
    consolePage.sentimentAckButton().eq(0).scrollIntoView().click({ force: true });
    consolePage
      .caseCardHeaderText()
      .invoke('text')
      .should('match', /acknowledged\s*byQA/);
    consolePage.acknowledgeLabelWithCrossIcon().eq(0).scrollIntoView().should('be.visible');
    consolePage.selectShowAcknowledgedInDropdown();
    consolePage.caseCard().eq(0).invoke('text').should('contain', 'acknowledged by');
    consolePage
      .caseCardTicketIdLabel()
      .eq(0)
      .then((caseNo) => {
        const caseID = caseNo.text();

        consolePage.acknowledgeLabelWithCrossIcon().eq(0).scrollIntoView().should('be.visible');
        consolePage.acknowledgeLabelWithCrossIcon().eq(0).trigger('mouseover');
        consolePage.acknowledgeLabelTooltip().invoke('text').should('include', 'Remove acknowledgement');
        consolePage.acknowledgeLabelWithCrossIcon().eq(0).scrollIntoView().click();
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(1000);
        consolePage.selectShowUnacknowledgedInDropdown();
        cy.get('body').should('contain', caseID);
        consolePage.selectShowAcknowledgedInDropdown();
        cy.get('body').should('not.contain', caseID);
      });
  });

  /*
   * Go to Agents insights page, Search any Agent name.
   * Click on the Positive sentiment tab, Click the Elasped Time option in the groupedby dropdown.
   * While hovering on cases 'Acknowledge' tick mark is showing. Click the tick mark.
   * Validate that Acknowledged by QA with Cross icon should be displayed.
   * Click the Show Acknowledged option in the dropdown, Click on Cross icon in a feed.
   * Validate that Acknowledged by QA with Cross icon should not be displayed.
   */
  it('C129421: Verify the acknowledgement workflow in Positive Sentiment tab', { tags: ['Agents', 'staging'] }, () => {
    agentInsights.getTabsByName('positive_sentiments').eq(1).click();
    consolePage.selectAllSignalsInDropdown();
    consolePage.selectShowAllInDropdown();
    consolePage.groupByElapsedTime();
    consolePage.expandAllConsoleLists();
    consolePage.consoleTabsShowingHeaderTitle().should('exist');
    consolePage.consoleTabsShowingHeaderTitle().invoke('text').should('contain', `Showing`);
    consolePage.consoleSentimentsTabsHeaderTitle().should('exist');
    consolePage.consoleSentimentsTabsHeaderTitle().invoke('text').should('contain', `Positive Sentiments`);
    cy.waitForLoaders();
    consolePage.acknowledgeDropdown().click({ force: true });
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    consolePage.acknowledgeDropdownValueAll().should('be.visible').and('contain', `Show all`);
    consolePage.acknowledgeDropdownValueAck().should('be.visible').and('contain', `Show Acknowledged`);
    consolePage.acknowledgeDropdownValueUnack().should('be.visible').and('contain', `Show Unacknowledged`);
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    consolePage.caseCard().eq(0).scrollIntoView().trigger('mouseover');
    consolePage.sentimentAckButton().eq(0).scrollIntoView().click({ force: true });
    consolePage
      .caseCardHeaderText()
      .invoke('text')
      .should('match', /acknowledged\s*byQA/);
    consolePage.acknowledgeLabelWithCrossIcon().eq(0).scrollIntoView().should('be.visible');
    consolePage.selectShowAcknowledgedInDropdown();
    consolePage.caseCard().eq(0).invoke('text').should('contain', 'acknowledged by');
    consolePage
      .caseCardTicketIdLabel()
      .eq(0)
      .then((caseNo) => {
        const caseID = caseNo.text();

        consolePage.acknowledgeLabelWithCrossIcon().eq(0).scrollIntoView().should('be.visible');
        consolePage.acknowledgeLabelWithCrossIcon().eq(0).trigger('mouseover');
        consolePage.acknowledgeLabelTooltip().invoke('text').should('include', 'Remove acknowledgement');
        consolePage.acknowledgeLabelWithCrossIcon().eq(0).scrollIntoView().click();
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(1000);
        consolePage.selectShowUnacknowledgedInDropdown();
        cy.get('body').should('contain', caseID);
        consolePage.selectShowAcknowledgedInDropdown();
        cy.get('body').should('not.contain', caseID);
      });
  });

  /*
   * Go to Agents insights page, Search any Agent name.
   * Click on the Product Feedback tab, Click the Elasped Time option in the groupedby dropdown.
   * While hovering on cases 'Acknowledge' tick mark is showing. Click the tick mark.
   * Validate that Acknowledged by QA with Cross icon should be displayed.
   * Click the Show Acknowledged option in the dropdown, Click on Cross icon in a feed.
   * Validate that Acknowledged by QA with Cross icon should not be displayed.
   */
  it('C129422: Verify the acknowledgement workflow in Product Feedback tab', { tags: ['Agents', 'staging'] }, () => {
    agentInsights.getTabsByName('product_feedback').eq(1).click();
    consolePage.selectAllSignalsInDropdown();
    consolePage.selectShowAllInDropdown();
    consolePage.groupByElapsedTime();
    consolePage.expandAllConsoleLists();
    consolePage.consoleTabsShowingHeaderTitle().should('exist');
    consolePage.consoleTabsShowingHeaderTitle().invoke('text').should('contain', `Showing`);
    consolePage.consoleSentimentsTabsHeaderTitle().should('exist');
    consolePage.consoleSentimentsTabsHeaderTitle().invoke('text').should('contain', `Product Feedback`);
    cy.waitForLoaders();
    consolePage.acknowledgeDropdown().click({ force: true });
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    consolePage.acknowledgeDropdownValueAll().should('be.visible').and('contain', `Show all`);
    consolePage.acknowledgeDropdownValueAck().should('be.visible').and('contain', `Show Acknowledged`);
    consolePage.acknowledgeDropdownValueUnack().should('be.visible').and('contain', `Show Unacknowledged`);
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    consolePage.caseCard().eq(0).scrollIntoView().trigger('mouseover');
    consolePage.sentimentAckButton().eq(0).scrollIntoView().click({ force: true });
    consolePage
      .caseCardHeaderText()
      .invoke('text')
      .should('match', /acknowledged\s*byQA/);
    consolePage.acknowledgeLabelWithCrossIcon().eq(0).scrollIntoView().should('be.visible');
    consolePage.selectShowAcknowledgedInDropdown();
    consolePage.caseCard().eq(0).invoke('text').should('contain', 'acknowledged by');
    consolePage
      .caseCardTicketIdLabel()
      .eq(0)
      .then((caseNo) => {
        const caseID = caseNo.text();
        consolePage.acknowledgeLabelWithCrossIcon().eq(0).scrollIntoView().should('be.visible');
        consolePage.acknowledgeLabelWithCrossIcon().eq(0).trigger('mouseover');
        consolePage.acknowledgeLabelTooltip().invoke('text').should('include', 'Remove acknowledgement');
        consolePage.acknowledgeLabelWithCrossIcon().eq(0).scrollIntoView().click();
        // eslint-disable-next-line cypress/no-unnecessary-waiting
        cy.wait(1000);
        consolePage.selectShowUnacknowledgedInDropdown();
        cy.get('body').should('contain', caseID);
        consolePage.selectShowAcknowledgedInDropdown();
        cy.get('body').should('not.contain', caseID);
      });
  });
});
