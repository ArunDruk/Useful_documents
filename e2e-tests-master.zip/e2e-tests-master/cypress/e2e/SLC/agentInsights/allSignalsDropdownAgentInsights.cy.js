import { urlHelpers } from '../../../utils';
import { agentInsights, apiHelpers, consolePage } from '../../../pages';

describe('Agent Insights: All Signals Dropdown Workflow', () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.clearRecentlyVisitedAgentInsight();
    cy.slcHelpers.getDetailsOfAgentsWithCases().then((agentDetails) => {
      const agentDetail = Cypress._.sample(agentDetails);
      cy.wrap(agentDetail).as('agentDetail');
      cy.visit(urlHelpers.agentInsights.agentPage(agentDetail.id));
      cy.waitForLoaders();
    });
  });

  afterEach(() => {
    consolePage.selectAllSignalsInDropdown();
    consolePage.groupByElapsedTime();
  });

  /*
   * Go to Agents insights page, Search any Agent name.
   * Navigate to the Need Attention tab and verify we have landed in expected tab.
   * Verify the Sentiment Signal dropdown text is All Signal if not select All in the Dropdown value.
   * Click on Select All Signals and verify the data-status is unchecked.
   * Select only one signal value and verify the case card with selected signal alone is displaying.
   * After verify Select All Signals in the Sentiment Signal dropdown.
   */
  it('C129413: Agent Insights - Need Attention tabs - Sentiment Signal filter', { tags: ['Agents', 'staging'] }, () => {
    agentInsights.getTabsByName('need_attention').eq(1).click();
    consolePage.selectAllSignalsInDropdown();
    consolePage.selectShowAllInDropdown();
    consolePage.groupByElapsedTime();
    consolePage.expandAllConsoleLists();
    consolePage.consoleTabsShowingHeaderTitle().should('be.exist');
    consolePage.consoleTabsShowingHeaderTitle().invoke('text').should('contain', `Showing`);
    consolePage.consoleSentimentsTabsHeaderTitle().should('be.exist');
    consolePage.consoleSentimentsTabsHeaderTitle().invoke('text').should('contain', `Need Attention`);
    consolePage.sentimentsTabsSignalsDropdown().click();
    consolePage.signalsDropdownSentimentSignalHeader().invoke('text').should('contain', `Sentiment Signal`);
    consolePage.signalsDropdownSentimentSignalCheckbox().invoke('attr', 'data-status').should('eq', 'checked');
    cy.waitForLoaders();
    consolePage
      .sentimentSignalsdropdown()
      .should('be.visible')
      .then(($value) => {
        const signalValue = $value.text();
        consolePage.sentimentSignalsdropdown().click();
        if (signalValue !== 'All Signals') {
          consolePage.sentimentSignalsAllCheckBox().click({ force: true }).invoke('attr', 'data-status').should('equal', 'checked');
        }
        consolePage.sentimentSignalsAllCheckBox().click({ force: true }).invoke('attr', 'data-status').should('equal', 'unchecked');
        consolePage.sentimentSignalsdropdown().click();
        consolePage
          .sentimentSignalsIndividualNameLabel()
          .eq(0)
          .should('be.visible')
          .then(($name) => {
            const signalName = $name.text();
            consolePage.sentimentSignalsIndividualCheckbox(signalName).eq(0).invoke('attr', 'data-status').should('equal', 'unchecked');
            consolePage.sentimentSignalsIndividualCheckbox(signalName).eq(0).click({ force: true }).invoke('attr', 'data-status').should('equal', 'checked');
            cy.waitForLoaders();
            consolePage.sentimentSignalsdropdown().click();
            consolePage.sentimentSignalsdropdown().invoke('text').should('contain', signalName);
            consolePage.caseCardDetectedSentimentLabel().should('contain', signalName);
          });
      });
  });

  /*
   * Go to Agents insights page, Search any Agent name.
   * Navigate to the Negative Sentiment tab and verify we have landed in expected tab.
   * Verify the Sentiment Signal dropdown text is All Signal if not select All in the Dropdown value.
   * Click on Select All Signals and verify the data-status is unchecked.
   * Select only one signal value and verify the case card with selected signal alone is displaying.
   * After verify Select All Signals in the Sentiment Signal dropdown.
   */
  it('C129414: Agent Insights - Negative Sentiment Tab - Sentiment Signal filter', { tags: ['Agents', 'staging'] }, () => {
    agentInsights.getTabsByName('negative_sentiments').eq(1).click();
    consolePage.selectAllSignalsInDropdown();
    consolePage.selectShowAllInDropdown();
    consolePage.groupByElapsedTime();
    consolePage.expandAllConsoleLists();
    consolePage.consoleTabsShowingHeaderTitle().should('be.exist');
    consolePage.consoleTabsShowingHeaderTitle().invoke('text').should('contain', `Showing`);
    consolePage.consoleSentimentsTabsHeaderTitle().should('be.exist');
    consolePage.consoleSentimentsTabsHeaderTitle().invoke('text').should('contain', `Negative Sentiments`);
    consolePage.sentimentsTabsSignalsDropdown().click();
    consolePage.signalsDropdownSentimentSignalHeader().invoke('text').should('contain', `Sentiment Signal`);
    consolePage.signalsDropdownSentimentSignalCheckbox().invoke('attr', 'data-status').should('eq', 'checked');
    cy.waitForLoaders();
    consolePage
      .sentimentSignalsdropdown()
      .should('be.visible')
      .then(($value) => {
        const signalValue = $value.text();
        consolePage.sentimentSignalsdropdown().click();
        if (signalValue !== 'All Signals') {
          consolePage.sentimentSignalsAllCheckBox().click({ force: true }).invoke('attr', 'data-status').should('equal', 'checked');
        }
        consolePage.sentimentSignalsAllCheckBox().click({ force: true }).invoke('attr', 'data-status').should('equal', 'unchecked');
        consolePage.sentimentSignalsdropdown().click();
        consolePage
          .sentimentSignalsIndividualNameLabel()
          .eq(0)
          .should('be.visible')
          .then(($name) => {
            const signalName = $name.text();
            consolePage.sentimentSignalsIndividualCheckbox(signalName).eq(0).invoke('attr', 'data-status').should('equal', 'unchecked');
            consolePage.sentimentSignalsIndividualCheckbox(signalName).eq(0).click({ force: true }).invoke('attr', 'data-status').should('equal', 'checked');
            cy.waitForLoaders();
            consolePage.sentimentSignalsdropdown().click();
            consolePage.sentimentSignalsdropdown().invoke('text').should('contain', signalName);
            consolePage.caseCardDetectedSentimentLabel().should('contain', signalName);
          });
      });
  });

  /*
   * Go to Agents insights page, Search any Agent name.
   * Navigate to the Positive Sentiment tab and verify we have landed in expected tab.
   * Verify the Sentiment Signal dropdown text is All Signal if not select All in the Dropdown value.
   * Click on Select All Signals and verify the data-status is unchecked.
   * Select only one signal value and verify the case card with selected signal alone is displaying.
   * After verify Select All Signals in the Sentiment Signal dropdown.
   */
  it('C129415: Agent Insights - Positive Sentiment Tab - Sentiment Signal filter', { tags: ['Agents', 'staging'] }, () => {
    agentInsights.getTabsByName('positive_sentiments').eq(1).click();
    consolePage.selectAllSignalsInDropdown();
    consolePage.selectShowAllInDropdown();
    consolePage.groupByElapsedTime();
    consolePage.expandAllConsoleLists();
    consolePage.consoleTabsShowingHeaderTitle().should('be.exist');
    consolePage.consoleTabsShowingHeaderTitle().invoke('text').should('contain', `Showing`);
    consolePage.consoleSentimentsTabsHeaderTitle().should('be.exist');
    consolePage.consoleSentimentsTabsHeaderTitle().invoke('text').should('contain', `Positive Sentiments`);
    consolePage.sentimentsTabsSignalsDropdown().click();
    consolePage.signalsDropdownSentimentSignalHeader().invoke('text').should('contain', `Sentiment Signal`);
    consolePage.signalsDropdownSentimentSignalCheckbox().invoke('attr', 'data-status').should('eq', 'checked');
    cy.waitForLoaders();
    consolePage
      .sentimentSignalsdropdown()
      .should('be.visible')
      .then(($value) => {
        const signalValue = $value.text();
        consolePage.sentimentSignalsdropdown().click();
        if (signalValue !== 'All Signals') {
          consolePage.sentimentSignalsAllCheckBox().click({ force: true }).invoke('attr', 'data-status').should('equal', 'checked');
        }
        consolePage.sentimentSignalsAllCheckBox().click({ force: true }).invoke('attr', 'data-status').should('equal', 'unchecked');
        consolePage.sentimentSignalsdropdown().click();
        consolePage
          .sentimentSignalsIndividualNameLabel()
          .eq(0)
          .should('be.visible')
          .then(($name) => {
            const signalName = $name.text();
            consolePage.sentimentSignalsIndividualCheckbox(signalName).eq(0).invoke('attr', 'data-status').should('equal', 'unchecked');
            consolePage.sentimentSignalsIndividualCheckbox(signalName).eq(0).click({ force: true }).invoke('attr', 'data-status').should('equal', 'checked');
            cy.waitForLoaders();
            consolePage.sentimentSignalsdropdown().click();
            consolePage.sentimentSignalsdropdown().invoke('text').should('contain', signalName);
            consolePage.caseCardDetectedSentimentLabel().should('contain', signalName);
          });
      });
  });

  /*
   * Go to Agents insights page, Search any Agent name.
   * Navigate to the Product Feedback tab and verify we have landed in expected tab.
   * Verify the Sentiment Signal dropdown text is All Signal if not select All in the Dropdown value.
   * Click on Select All Signals and verify the data-status is unchecked.
   * Select only one signal value and verify the case card with selected signal alone is displaying.
   * After verify Select All Signals in the Sentiment Signal dropdown.
   */
  it('C129416: Agent Insights - Product Feedback tabs - Sentiment Signal filter', { tags: ['Agents', 'staging'] }, () => {
    agentInsights.getTabsByName('product_feedback').eq(1).click();
    consolePage.selectAllSignalsInDropdown();
    consolePage.selectShowAllInDropdown();
    consolePage.groupByElapsedTime();
    consolePage.expandAllConsoleLists();
    consolePage.consoleTabsShowingHeaderTitle().should('be.exist');
    consolePage.consoleTabsShowingHeaderTitle().invoke('text').should('contain', `Showing`);
    consolePage.consoleSentimentsTabsHeaderTitle().should('be.exist');
    consolePage.consoleSentimentsTabsHeaderTitle().invoke('text').should('contain', `Product Feedback`.trim());
    consolePage.sentimentsTabsSignalsDropdown().click();
    consolePage.signalsDropdownSentimentSignalHeader().invoke('text').should('contain', `Sentiment Signal`);
    consolePage.signalsDropdownSentimentSignalCheckbox().invoke('attr', 'data-status').should('eq', 'checked');
    cy.waitForLoaders();
    consolePage
      .sentimentSignalsdropdown()
      .should('be.visible')
      .then(($value) => {
        const signalValue = $value.text();
        consolePage.sentimentSignalsdropdown().click();
        if (signalValue !== 'All Signals') {
          consolePage.sentimentSignalsAllCheckBox().click({ force: true }).invoke('attr', 'data-status').should('equal', 'checked');
        }
        consolePage.sentimentSignalsAllCheckBox().click({ force: true }).invoke('attr', 'data-status').should('equal', 'unchecked');
        cy.waitForLoaders();
        consolePage.sentimentSignalsdropdown().click();
        consolePage
          .sentimentSignalsIndividualNameLabel()
          .eq(0)
          .should('be.visible')
          .then(($name) => {
            const signalName = $name.text();
            consolePage.sentimentSignalsIndividualCheckbox(signalName).eq(0).invoke('attr', 'data-status').should('equal', 'unchecked');
            consolePage.sentimentSignalsIndividualCheckbox(signalName).eq(0).click({ force: true }).invoke('attr', 'data-status').should('equal', 'checked');
            consolePage.sentimentSignalsdropdown().click();
            consolePage.sentimentSignalsdropdown().invoke('text').should('contain', 'All Signals');
            consolePage.caseCardDetectedSentimentLabel().should('contain', signalName);
          });
      });
  });
});
