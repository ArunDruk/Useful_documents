import { urlHelpers } from '../../../utils';
import { agentInsights, shiftManagement } from '../../../pages';
import { getShiftId, randId } from '../shiftCalendar/support';

describe('Agent Insights - Shift Assignment', { tags: ['Agent Insights', 'staging', 'prod'] }, () => {
  const shiftNames = [];

  beforeEach(() => {
    cy.loginByApi();
    for (let i = 0; i < 2; i += 1) {
      cy.visit(urlHelpers.shiftCalendar);
      shiftNames.push(`Test shift ${randId()}`);
      shiftManagement.addShiftButton().click();
      shiftManagement.createShiftDialogNameTextField().type(shiftNames[i]);
      shiftManagement.createShiftDialogCreateButton().click({ force: true });
      cy.waitForLoaders();
    }
    cy.visit(urlHelpers.agentInsights.home);
  });

  afterEach(() => {
    for (let i = 0; i < 2; i += 1) {
      getShiftId(shiftNames[i]).then((shiftId) => cy.slcHelpers.deleteVgroup(shiftId));
    }
  });

  /*
   * Visit the Agent Insight home page
   * Fetch details for an agent with active cases
   * Enter the agent name in the search box
   * Click the search result
   * Assign the agent to a shift
   * Verify that the shiftname appears in the Assignment Hours section
   */
  it('C37656: Agent Insights - Assign Agent to a shift', function validateMedianMetrics() {
    cy.slcHelpers.getDetailsOfAgentsWithCases().then((agentDetails) => {
      const agentDetail = Cypress._.sample(agentDetails);
      agentInsights.agentInsightsSearchFieldInput().type(agentDetail.sl_name);
      agentInsights.expandFilterButton().click();
      agentInsights.filterByType('Individual Agent');
      agentInsights.agentSearchResultListNameLabel().should('contain', agentDetail.sl_name).click();
      agentInsights.agentNameLabel().should('have.text', agentDetail.sl_name);

      agentInsights.assignThisAgentButton().click();
      agentInsights.shiftAssignmentModal().should('contain', `Assign ${agentDetail.sl_name} to one or more shift`);
      agentInsights.shiftCheckbox(shiftNames[0]).check({ force: true });

      shiftManagement.assignAgentPopoverSubmitButton().click();

      cy.waitForLoaders();

      agentInsights.agentInsightsAssignmentHours().parent().should('contain', shiftNames[0]);
      agentInsights.editAssignmentHours().should('be.visible').and('have.text', 'Edit');
    });
  });

  /*
   * Visit the Agent Insight home page
   * Fetch details for an agent with active cases
   * Enter the agent name in the search box
   * Click the search result
   * Assign the agent to 2 shifts
   * Verify that both shiftnames appears in the Assignment Hours section
   */
  it('C37691: Agent Insights - Assign agent to multiple shifts', function validateMedianMetrics() {
    cy.slcHelpers.getDetailsOfAgentsWithCases().then((agentDetails) => {
      const agentDetail = Cypress._.sample(agentDetails);
      agentInsights.agentInsightsSearchFieldInput().type(agentDetail.sl_name);
      agentInsights.expandFilterButton().click();
      agentInsights.filterByType('Individual Agent');
      agentInsights.agentSearchResultListNameLabel().should('contain', agentDetail.sl_name).click();
      agentInsights.agentNameLabel().should('have.text', agentDetail.sl_name);

      agentInsights.assignThisAgentButton().click();
      agentInsights.shiftAssignmentModal().should('contain', `Assign ${agentDetail.sl_name} to one or more shift`);
      agentInsights.shiftCheckbox(shiftNames[0]).check({ force: true });
      agentInsights.shiftCheckbox(shiftNames[1]).check({ force: true });

      shiftManagement.assignAgentPopoverSubmitButton().click();

      cy.waitForLoaders();

      agentInsights.agentInsightsAssignmentHours().parent().should('contain', shiftNames[0]).and('contain', shiftNames[1]);
      agentInsights.editAssignmentHours().should('be.visible').and('have.text', 'Edit');
    });
  });

  /*
   * Visit the Agent Insight home page
   * Fetch details for an agent with active cases
   * Enter the agent name in the search box
   * Click the search result
   * Assign the agent to a shifts
   * Hover over the shift and visit the Shift Calendar link
   */
  it('C37696: Agent Insights - Visit Shift calendar from agent shift pop up', function validateMedianMetrics() {
    cy.slcHelpers.getDetailsOfAgentsWithCases().then((agentDetails) => {
      const agentDetail = Cypress._.sample(agentDetails);
      agentInsights.agentInsightsSearchFieldInput().type(agentDetail.sl_name);
      agentInsights.expandFilterButton().click();
      agentInsights.filterByType('Individual Agent');
      agentInsights.agentSearchResultListNameLabel().should('contain', agentDetail.sl_name).click();
      agentInsights.agentNameLabel().should('have.text', agentDetail.sl_name);

      agentInsights.assignThisAgentButton().click();

      agentInsights.shiftCheckbox(shiftNames[0]).check({ force: true });

      shiftManagement.assignAgentPopoverSubmitButton().click();
      cy.waitForLoaders();

      agentInsights.agentInsightsAssignmentHours().parent().should('contain', shiftNames[0]);

      agentInsights.agentInsightsAssignmentHours().siblings('div').last().realHover();
      agentInsights.shiftPopupCalendarLink(shiftNames[0]).invoke('attr', 'href').should('equal', '/support/shift-management?mode=agent-assignment-shifts');
    });
  });

  /*
   * Visit the Agent Insight home page
   * Fetch details for an agent with active cases
   * Enter the agent name in the search box
   * Click the search result
   * Assign the agent to 2 shifts
   * Edit assignment and remove both shifts
   * Verify that no shiftnames appears in the Assignment Hours section
   */
  it('C37697: Agent insights - Un assign all shifts from an agent', function validateMedianMetrics() {
    cy.slcHelpers.getDetailsOfAgentsWithCases().then((agentDetails) => {
      const agentDetail = Cypress._.sample(agentDetails);
      agentInsights.agentInsightsSearchFieldInput().type(agentDetail.sl_name);
      agentInsights.expandFilterButton().click();
      agentInsights.filterByType('Individual Agent');
      agentInsights.agentSearchResultListNameLabel().should('contain', agentDetail.sl_name).click();
      agentInsights.agentNameLabel().should('have.text', agentDetail.sl_name);

      agentInsights.assignThisAgentButton().click();

      agentInsights.shiftCheckbox(shiftNames[0]).check({ force: true });
      agentInsights.shiftCheckbox(shiftNames[1]).check({ force: true });

      shiftManagement.assignAgentPopoverSubmitButton().click();
      cy.waitForLoaders();

      agentInsights.agentInsightsAssignmentHours().parent().should('contain', shiftNames[0]).and('contain', shiftNames[1]);
      agentInsights.assignThisAgentButton().should('not.exist');
      agentInsights.editAssignmentHours().should('be.visible').and('have.text', 'Edit').click();

      agentInsights.shiftCheckbox(shiftNames[0]).uncheck({ force: true });
      agentInsights.shiftCheckbox(shiftNames[1]).uncheck({ force: true });

      shiftManagement.assignAgentPopoverSubmitButton().click();
      cy.waitForLoaders();

      agentInsights.agentInsightsAssignmentHours().parent().should('not.contain', shiftNames[0]).and('not.contain', shiftNames[1]);
      agentInsights.editAssignmentHours().should('not.exist');
      agentInsights.assignThisAgentButton().should('be.visible').and('have.text', 'Assign this agent');
    });
  });
});
