import { urlHelpers } from '../../../utils';
import { agentInsights, datePicker } from '../../../pages';

describe('Agent Insights - Home', { tags: ['Agent Insights', 'staging', 'prod'] }, () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.agentInsights.home);
  });

  /*
   * Visit the Agent Insight home page
   * Agent Insights page should have a searchbar
   * Recently visited section will have the icons showing Agent initials.
   */
  it('C27922: Agents - Visit Agent Insights page', function validateMedianMetrics() {
    agentInsights.agentInsightsSearchFieldInput().should('be.visible');
    agentInsights.agentInsightsSearchFieldInput().invoke('attr', 'placeholder').should('equal', 'Agent name');
    if (!agentInsights.recentlyVisited()) {
      agentInsights.recentlyVisitedAgentItems().each(($el) => {
        expect($el.find('span').text()).to.have.length.of.at.most(2);
      });
    }
  });

  /*
   * Visit the Agent Insight home page
   * Fetch details for an agent with active cases
   * Enter the agent name in the search box
   * Verify that the name appears in search results
   * Click the search result
   * Verify agent insight page elements
   */
  it('C27923: Agents - Visit agent page from agent search', function validateMedianMetrics() {
    cy.slcHelpers.getDetailsOfAgentsWithCases().then((agentDetails) => {
      const agentDetail = Cypress._.sample(agentDetails);
      agentInsights.agentInsightsSearchFieldInput().type(agentDetail.sl_name);
      agentInsights.expandFilterButton().click();
      agentInsights.filterByType('Individual Agent');
      agentInsights.agentSearchResultListNameLabel().should('contain', agentDetail.sl_name).click();
      agentInsights.agentNameLabel().should('have.text', agentDetail.sl_name);
      agentInsights.medianCaseOpenTimeLabel().should('have.text', 'Median Case Open Time');
      agentInsights.medianCaseOpenTimeValue().should('contain', 'Days');
      agentInsights.medianResponseTimeLabel().should('have.text', 'Median Response Time');
      agentInsights.medianResponseTimeValue().should('contain', 'Hours');
      agentInsights.medianConversationCountLabel().should('have.text', 'Median Conversation Count');
      agentInsights
        .medianConversationCountValue()
        .invoke('text')
        .then((value) => {
          expect(parseInt(value, 10)).to.be.above(0);
        });
      agentInsights.agentInsightsOutOfOfficeWidget().should('contain', 'Out of Office');
      agentInsights.agentInsightsAssignmentHours().should('be.visible');
      agentInsights.agentInsightsFavoriteButton().should('be.visible');
      datePicker.datePickerTrigger().should('be.visible');
    });
  });

  /*
   * Visit the Agent Insight home page
   * Click one of the recently visited agent link
   * Verify agent insight page elements
   */
  it('C27924: Agent - Visit agent page from Recently visited', function validateMedianMetrics() {
    cy.slcHelpers.getDetailsOfAgentsWithCases().then((agentDetails) => {
      const agentDetail = Cypress._.sample(agentDetails);
      agentInsights.agentInsightsSearchFieldInput().type(agentDetail.sl_name);
      agentInsights.expandFilterButton().click();
      agentInsights.filterByType('Individual Agent');
      agentInsights.agentSearchResultListNameLabel().should('contain', agentDetail.sl_name).click();
      cy.waitForLoaders();
      agentInsights.backButton().click();
      cy.waitForLoaders();
      agentInsights
        .recentlyVisitedAgentItems()
        .first()
        .then(($el) => {
          const agentname = $el.text().replace($el.find('span').text(), '');
          cy.wrap($el).click();
          agentInsights.agentNameLabel().should('have.text', agentname);
          agentInsights.medianCaseOpenTimeLabel().should('have.text', 'Median Case Open Time');
          agentInsights.medianCaseOpenTimeValue().should('contain', 'Days');
          agentInsights.medianResponseTimeLabel().should('have.text', 'Median Response Time');
          agentInsights.medianResponseTimeValue().should('contain', 'Hours');
          agentInsights.medianConversationCountLabel().should('have.text', 'Median Conversation Count');
          agentInsights
            .medianConversationCountValue()
            .invoke('text')
            .then((value) => {
              expect(parseInt(value, 10)).to.be.above(0);
            });
          agentInsights.agentInsightsOutOfOfficeWidget().should('contain', 'Out of Office');
          agentInsights.agentInsightsAssignmentHours().should('be.visible');
          agentInsights.agentInsightsFavoriteButton().should('be.visible');
          datePicker.datePickerTrigger().should('be.visible');
        });
    });
  });

  /*
   * Visit the Agent Insight home page
   * Enter a virtual team name in the search box
   * Verify that the name appears in search results
   * Click the search result
   * Verify agent insight page elements
   */
  it('C27925: Agent - Open a virtual team from agent search in agent insights', function validateMedianMetrics() {
    // Using static data as due to SLC-34290, a new newly created virtual queue cannot always be found
    // this case will be modified once the elastic wrapper is implemented to use realtime data
    const vtName = 'DO NOT DELETE';
    agentInsights.agentInsightsSearchFieldInput().type(vtName);
    agentInsights.expandFilterButton().click();
    agentInsights.filterByType('Virtual Team');
    agentInsights.agentSearchResultListNameLabel().should('contain', vtName).first().click();
    agentInsights.agentNameLabel().should('contain', vtName);
    agentInsights.medianCaseOpenTimeLabel().should('have.text', 'Median Case Open Time');
    agentInsights.medianCaseOpenTimeValue().should('contain', 'Days');
    agentInsights.medianResponseTimeLabel().should('have.text', 'Median Response Time');
    agentInsights.medianResponseTimeValue().should('contain', 'Hours');
    agentInsights.medianConversationCountLabel().should('have.text', 'Median Conversation Count');
    agentInsights
      .medianConversationCountValue()
      .invoke('text')
      .then((value) => {
        expect(parseInt(value, 10)).to.be.above(0);
      });
    agentInsights.agentInsightsFavoriteButton().should('be.visible');
    datePicker.datePickerTrigger().should('be.visible');
  });

  /*
   * Visit the Agent Insight home page
   * Fetch details for an agent with active cases
   * Enter the agent name in the search box
   * Click the search result
   * Expand the remaining portion of the component chart
   * Verify the back button
   */
  it('C2330: Verify the display of pie/donut chart for closed cases.', function validateMedianMetrics() {
    cy.slcHelpers.getDetailsOfAgentsWithCases().then((agentDetails) => {
      const agentDetail = Cypress._.sample(agentDetails);
      agentInsights.agentInsightsSearchFieldInput().type(agentDetail.sl_name);
      agentInsights.expandFilterButton().click();
      agentInsights.filterByType('Individual Agent');
      agentInsights.agentSearchResultListNameLabel().should('contain', agentDetail.sl_name).click();
      agentInsights.agentNameLabel().should('have.text', agentDetail.sl_name);
      agentInsights.getTabsByName('Closed Cases').last().click();
      agentInsights.remainingComponents().click({ force: true });
      agentInsights.remainingComponentsBackButton().should('exist');
    });
  });
});
