import { urlHelpers } from '../../../utils';
import { agentInsights, apiHelpers, customerInsights, consolePage, experientialMetrics, supportHub } from '../../../pages';

describe('Agent Insights: Visibility of the tabs', () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.clearRecentlyVisitedAgentInsight();
    cy.slcHelpers.getDetailsOfAgentsWithCases().then((agentDetails) => {
      const agentDetail = Cypress._.sample(agentDetails);
      cy.wrap(agentDetail.id).as('agentId');
      cy.visit(urlHelpers.agentInsights.agentPage(agentDetail.id));
    });
  });

  /*
   * Go to Agent Insights page.
   * Search for any Agent name and click enter.
   * Click on the need attention tab, Click the Attention score option in the groupedby dropdown.
   * Check 'Show ALL' dropdown options are displayed and Check 'All Signals' dropdown options whether all signals are checked.
   * Validate the display of Need Attention header title , Open any SH and check Attention score label is displayed.
   */
  it('C129375: Verify the display of Need attention tab', { tags: ['Agents', 'staging'] }, () => {
    agentInsights.getTabsByName('need_attention').eq(1).click();
    consolePage.consoleTabsShowingHeaderTitle().should('be.exist');
    consolePage.consoleTabsShowingHeaderTitle().invoke('text').should('contain', `Showing`);
    consolePage.consoleSentimentsTabsHeaderTitle().should('be.exist');
    consolePage.consoleSentimentsTabsHeaderTitle().invoke('text').should('contain', `Need Attention`);
    consolePage.acknowledgeDropdown().click({ force: true });
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    consolePage.acknowledgeDropdownValueAll().should('be.visible').and('contain', `Show all`);
    consolePage.acknowledgeDropdownValueAck().should('be.visible').and('contain', `Show Acknowledged`);
    consolePage.acknowledgeDropdownValueUnack().should('be.visible').and('contain', `Show Unacknowledged`);
    consolePage.sentimentsTabsSignalsDropdown().click();
    consolePage.signalsDropdownSentimentSignalHeader().invoke('text').should('contain', `Sentiment Signal`);
    consolePage.signalsDropdownSentimentSignalCheckbox().invoke('attr', 'data-status').should('eq', 'checked');
    cy.waitForLoaders();
    consolePage.groupByAttentionScoreOption();
    cy.waitForLoaders();
    consolePage.consoleSubTabsOptionSwitcher().eq(0).click();
    cy.waitForLoaders();
    consolePage.caseCard().eq(0).click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
    supportHub.supportHubAttentionScoreLabel().then(($attentionScore) => {
      const attentionScore = $attentionScore.text();

      expect(parseInt(attentionScore, 10)).to.be.at.least(parseInt(80, 10)).and.to.be.at.most(parseInt(100, 10));
      supportHub.closeButton().click();
    });
  });

  /*
   * Go to Agent Insights page.
   * Search for any Agent name and click enter.
   * Click on the Positive Sentiments tab, Click the Sentiment score option in the groupedby dropdown.
   * Check 'Show ALL' dropdown options are displayed and Check 'All Signals' dropdown options whether all signals are checked.
   * Validate the display of Positive Sentiments header title , Open any SH and check Sentiment score label is displayed.
   */
  it('C129377: Verify the display of Positive Sentiments tab', { tags: ['Agents', 'staging'] }, () => {
    agentInsights.getTabsByName('positive_sentiments').eq(1).click();
    consolePage.consoleTabsShowingHeaderTitle().should('be.exist');
    consolePage.consoleTabsShowingHeaderTitle().invoke('text').should('contain', `Showing`);
    consolePage.consoleSentimentsTabsHeaderTitle().should('be.exist');
    consolePage.consoleSentimentsTabsHeaderTitle().invoke('text').should('contain', `Positive Sentiments`);
    consolePage.acknowledgeDropdown().click({ force: true });
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    consolePage.acknowledgeDropdownValueAll().should('be.visible').and('contain', `Show all`);
    consolePage.acknowledgeDropdownValueAck().should('be.visible').and('contain', `Show Acknowledged`);
    consolePage.acknowledgeDropdownValueUnack().should('be.visible').and('contain', `Show Unacknowledged`);
    consolePage.sentimentsTabsSignalsDropdown().click();
    consolePage.signalsDropdownSentimentSignalHeader().invoke('text').should('contain', `Sentiment Signal`);
    consolePage.signalsDropdownSentimentSignalCheckbox().invoke('attr', 'data-status').should('eq', 'checked');
    consolePage.groupBySentimentScoreOption();
    cy.waitForLoaders();
    consolePage
      .consoleSubTabsOptionSwitcher()
      .eq(0)
      .then(($scoreRange) => {
        const minScoreRange = $scoreRange.text().split('-')[0];
        const maxScoreRange = $scoreRange.text().split('-')[1];

        consolePage.consoleSubTabsOptionSwitcher().eq(0).click();
        cy.waitForLoaders();
        consolePage.caseCard().eq(0).click();
        cy.waitForLoaders();
        supportHub.baseContainer().should('be.visible');
        cy.waitForLoaders();
        supportHub.supportHubSentimentScoreLabel().then(($sentimentScore) => {
          const sentimentScore = $sentimentScore.text();

          expect(parseInt(sentimentScore, 10)).to.be.at.least(parseInt(minScoreRange, 10)).and.to.be.at.most(parseInt(maxScoreRange, 10));
          supportHub.closeButton().click();
        });
      });
  });

  /*
   * Go to Agent Insights page.
   * Search for any Agent name and click enter.
   * Click on the Negative Sentiments tab, Click the Sentiment score option in the groupedby dropdown.
   * Check 'Show ALL' dropdown options are displayed and Check 'All Signals' dropdown options whether all signals are checked.
   * Validate the display of Negative Sentiments header title , Open any SH and check Sentiment score label is displayed.
   */
  it('C129376: Verify the display of Negative Sentiments tab', { tags: ['Agents', 'staging'] }, () => {
    agentInsights.getTabsByName('negative_sentiments').eq(1).click();
    consolePage.consoleTabsShowingHeaderTitle().should('be.exist');
    consolePage.consoleTabsShowingHeaderTitle().invoke('text').should('contain', `Showing`);
    consolePage.consoleSentimentsTabsHeaderTitle().should('be.exist');
    consolePage.consoleSentimentsTabsHeaderTitle().invoke('text').should('contain', `Negative Sentiments`);
    consolePage.acknowledgeDropdown().click({ force: true });
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    consolePage.acknowledgeDropdownValueAll().should('be.visible').and('contain', `Show all`);
    consolePage.acknowledgeDropdownValueAck().should('be.visible').and('contain', `Show Acknowledged`);
    consolePage.acknowledgeDropdownValueUnack().should('be.visible').and('contain', `Show Unacknowledged`);
    consolePage.sentimentsTabsSignalsDropdown().click();
    consolePage.signalsDropdownSentimentSignalHeader().invoke('text').should('contain', `Sentiment Signal`);
    consolePage.signalsDropdownSentimentSignalCheckbox().invoke('attr', 'data-status').should('eq', 'checked');
    consolePage.groupBySentimentScoreOption();
    cy.waitForLoaders();
    consolePage
      .consoleSubTabsOptionSwitcher()
      .eq(0)
      .then(($scoreRange) => {
        const minScoreRange = $scoreRange.text().split('-')[0];
        const maxScoreRange = $scoreRange.text().split('-')[1];

        consolePage.consoleSubTabsOptionSwitcher().eq(0).click();
        cy.waitForLoaders();
        consolePage.caseCard().eq(0).click();
        cy.waitForLoaders();
        supportHub.baseContainer().should('be.visible');
        cy.waitForLoaders();
        supportHub.supportHubSentimentScoreLabel().then(($sentimentScore) => {
          const sentimentScore = $sentimentScore.text();

          expect(parseInt(sentimentScore, 10)).to.be.at.least(parseInt(minScoreRange, 10)).and.to.be.at.most(parseInt(maxScoreRange, 10));
          supportHub.closeButton().click();
        });
      });
  });

  /*
   * Go to Agent insight page.
   * Search for any customer name and click enter.
   * Click on the Engineering Issues tab.
   * Validate the display of Top Entities, Status, Priority chart title.
   */
  it('C129379: Verify the display of Engineering Issues  tab', { tags: ['Agents', 'staging'] }, () => {
    agentInsights.getTabsByName('Engineering_Issues').eq(1).click();
    cy.waitForLoaders();
    consolePage.engIssuesChartWrapperEntities().invoke('text').should('contain', `Top Entities`);
    consolePage.engIssuesChartWrapperStatus().invoke('text').should('contain', `Status`);
    consolePage.engIssuesChartWrapperPriority().invoke('text').should('contain', `Priority`);
  });

  /*
   * Go to Agent Insights page.
   * Search for any Agent name and click enter.
   * Click on the New escalation  tab, Click the Status Option in the groupedby dropdown.
   * Validate the display of Escalation header title , Open any SH and check Escalated status label is displayed.
   */
  it('C129373: Verify the display of New escalation tab', { tags: ['Agents', 'staging'] }, () => {
    agentInsights.getTabsByName('new_escalations').eq(1).click();
    consolePage.consoleEscalatedTabHeaderTitle().should('be.exist');
    consolePage.consoleEscalatedTabHeaderTitle().invoke('text').should('contain', `Escalations`);
    consolePage.groupByStatusOption();
    cy.waitForLoaders();
    consolePage.newEscalationEscalatedOptionSwitcher().click();
    consolePage.newEscalationEscalatedOptionSwitcher().should('be.visible').and('contain', `Escalated`);
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    consolePage.newEscalationEscalatedOptionSwitcher().should('be.visible').realHover();
    consolePage.consoleTabsHeaderTitleTooltip().should('have.text', 'Escalated');
    cy.waitForLoaders();
    consolePage.escalationCaseCard().eq(0).click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
    supportHub.escalationStatusLabel().invoke('text').should('contain', `Escalated`);
    supportHub.closeButton().click();
  });

  /*
   * Go to Agent Insights page.
   * Search for any Agent name and click enter.
   * Click on the Product Feedback tab, Click the Sentiment score option in the groupedby dropdown.
   * Check 'Show ALL' dropdown options are displayed and Check 'All Signals' dropdown Options whether all signals are checked.
   * Validate the display of Product Feedback header title , Open any SH and check Sentiment score label is displayed.
   */
  it('C129378: Verify the display of Product Feedback tab', { tags: ['Agents', 'staging'] }, () => {
    agentInsights.getTabsByName('product_feedback').eq(1).click();
    consolePage.consoleTabsShowingHeaderTitle().should('be.exist');
    consolePage.consoleTabsShowingHeaderTitle().invoke('text').should('contain', `Showing`);
    consolePage.consoleSentimentsTabsHeaderTitle().should('be.exist');
    consolePage.consoleSentimentsTabsHeaderTitle().invoke('text').should('contain', `Product Feedback`.trim());
    consolePage.acknowledgeDropdown().click({ force: true });
    // eslint-disable-next-line cypress/no-unnecessary-waiting
    cy.wait(1000);
    consolePage.acknowledgeDropdownValueAll().should('be.visible').and('contain', `Show all`);
    consolePage.acknowledgeDropdownValueAck().should('be.visible').and('contain', `Show Acknowledged`);
    consolePage.acknowledgeDropdownValueUnack().should('be.visible').and('contain', `Show Unacknowledged`);
    consolePage.sentimentsTabsSignalsDropdown().click();
    consolePage.signalsDropdownSentimentSignalHeader().invoke('text').should('contain', `Sentiment Signal`);
    consolePage.signalsDropdownSentimentSignalCheckbox().invoke('attr', 'data-status').should('eq', 'checked');
    consolePage.groupBySentimentScoreOption();
    cy.waitForLoaders();
    consolePage
      .consoleSubTabsOptionSwitcher()
      .eq(0)
      .then(($scoreRange) => {
        const minScoreRange = $scoreRange.text().split('-')[0];
        const maxScoreRange = $scoreRange.text().split('-')[1];

        consolePage.consoleSubTabsOptionSwitcher().eq(0).click();
        cy.waitForLoaders();
        consolePage.caseCard().eq(0).click();
        cy.waitForLoaders();
        supportHub.baseContainer().should('be.visible');
        cy.waitForLoaders();
        supportHub.supportHubSentimentScoreLabel().then(($sentimentScore) => {
          const sentimentScore = $sentimentScore.text();

          expect(parseInt(sentimentScore, 10)).to.be.at.least(parseInt(minScoreRange, 10)).and.to.be.at.most(parseInt(maxScoreRange, 10));
          supportHub.closeButton().click();
        });
      });
  });

  /*
   * Go to Agent Insights page.
   * Search for any Agent name and click enter.
   * Click on the Open Cases tab,Validate the display of open status, sortorderbutton, all the sort dropdown options.
   * Click on the Closed Cases tab,Validate the display of Status, Priority, Response Time, Case age and Component Chart [ Experimental Charts Exist].
   */
  it('C129417: Verify the display of Open cases and Closed cases', { tags: ['Agents', 'staging'] }, () => {
    agentInsights.getTabsByName('open_cases').eq(1).click();
    cy.waitForLoaders();
    customerInsights.overviewTabRecentCasesHeader().should('be.visible').should('have.text', 'Backlog');
    agentInsights.caseDistributionChartHeader().should('be.visible').should('have.text', 'Case Distribution');
    agentInsights.agentInsightsCaseSortOrderButton().scrollIntoView().trigger('mouseover');
    customerInsights.overviewTabSortOrderButtonTooltip().should('have.text', 'Switch sort direction');
    agentInsights.overviewTabStatusChartTitle().should('be.visible').and('contain', `Status`);
    agentInsights.overviewTabPriorityChartTitle().should('be.visible').and('contain', `Priority`);
    agentInsights.agentInsightsCaseSortDropdown().click();
    customerInsights.overviewTabSortByDropdownCreatedAtOption().should('be.visible').and('contain', `Created Date`);
    customerInsights.overviewTabSortByDropdownRecentActivityOption().should('be.visible').and('contain', `Recent Activity`);
    customerInsights.overviewTabSortByDropdownSentimentScoreOption().should('be.visible').and('contain', `Sentiment Score`);
    customerInsights.overviewTabSortByDropdownAttentionScoreOption().should('be.visible').and('contain', `Attention Score`);
    agentInsights.getTabsByName('Closed_Cases').eq(1).click();
    cy.waitForLoaders();
    agentInsights.closedCaseTabStatusChartWrapper().should('be.visible').and('contain', `Status`);
    agentInsights.closedCaseTabPriorityChartWrapper().should('be.visible').and('contain', `Priority`);
    agentInsights.closedCaseTabResponseTimeChartWrapper().scrollIntoView().should('be.visible').and('contain', `Response Time`);
    agentInsights.closedCaseTabCaseAgeChartWrapper().scrollIntoView().should('be.visible').and('contain', `Case Age`);
    agentInsights.closedCaseTabComponentChartWrapper().scrollIntoView().should('be.visible').and('contain', `Component`);
    experientialMetrics.chartLabels().should('exist');
    experientialMetrics.chartBarPoints().should('exist');
  });
});
