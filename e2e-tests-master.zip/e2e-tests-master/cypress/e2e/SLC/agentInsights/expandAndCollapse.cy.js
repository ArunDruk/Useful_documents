import { urlHelpers } from '../../../utils';
import { agentInsights, apiHelpers, consolePage } from '../../../pages';

describe('Agent Insights: Expand All Collapse All Functionality Check', () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.clearRecentlyVisitedAgentInsight();
    cy.slcHelpers.getDetailsOfAgentsWithCases().then((agentDetails) => {
      const agentDetail = Cypress._.sample(agentDetails);
      cy.wrap(agentDetail).as('agentDetail');
      cy.visit(urlHelpers.agentInsights.agentPage(agentDetail.id));
    });
  });

  /*
   * Go to Agents insights page, Search any Agent name.
   * Navigate to the Need Attention tab and verify we have landed in expected tab.
   * Verify the Sentiment Signal dropdown text is All Signal if not select All in the Dropdown value.
   * Select 'Elasped Time' in the dropdown, Click 'Collapse all' button and validate case card is not exist.
   * Click 'Expand all' button and validate case card is exist.
   */
  it('C129408: Agent Insights - Need Attention tab - Expand all <-> Collapse all Functionality Check', { tags: ['Agents', 'staging'] }, function needAttentionExpandAll() {
    agentInsights.agentNameLabel().should('be.visible').and('have.text', this.agentDetail.sl_name);
    agentInsights.getTabsByName('need_attention').eq(1).click();
    consolePage.selectAllSignalsInDropdown();
    consolePage.selectShowAllInDropdown();
    consolePage.groupByElapsedTime();
    consolePage.expandAllConsoleLists();
    cy.waitForLoaders();
    consolePage.collapseExpandButton().should('be.visible').and('have.text', 'Collapse All');
    consolePage.caseCard().should('be.visible');
    consolePage.caseListCustomerName().should('be.visible');
    consolePage.collapseExpandButton().click();
    cy.waitForLoaders();
    consolePage.collapseExpandButton().should('be.visible').and('have.text', 'Expand All');
    consolePage.caseCard().should('not.exist');
    consolePage.caseListCustomerName().should('not.exist');
  });

  /*
   * Go to Agents insights page, Search any Agent name.
   * Navigate to the Negative Sentiment tab and verify we have landed in expected tab.
   * Verify the Sentiment Signal dropdown text is All Signal if not select All in the Dropdown value.
   * Select 'Elasped Time' in the dropdown, Click 'Collapse all' button and validate case card is not exist.
   * Click 'Expand all' button and validate case card is exist.
   */
  it('C129409: Agent Insights - Negative Sentiment tab - Expand all <-> Collapse all Functionality Check', { tags: ['Agents', 'staging'] }, function negativeSentimentExpandAll() {
    agentInsights.agentNameLabel().should('be.visible').and('have.text', this.agentDetail.sl_name);
    agentInsights.getTabsByName('negative_sentiments').eq(1).click();
    consolePage.selectAllSignalsInDropdown();
    consolePage.selectShowAllInDropdown();
    consolePage.groupByElapsedTime();
    consolePage.expandAllConsoleLists();
    cy.waitForLoaders();
    consolePage.collapseExpandButton().should('be.visible').and('have.text', 'Collapse All');
    consolePage.caseCard().should('be.visible');
    consolePage.caseListCustomerName().should('be.visible');
    consolePage.collapseExpandButton().click();
    cy.waitForLoaders();
    consolePage.collapseExpandButton().should('be.visible').and('have.text', 'Expand All');
    consolePage.caseCard().should('not.exist');
    consolePage.caseListCustomerName().should('not.exist');
  });

  /*
   * Go to Agents insights page, Search any Agent name.
   * Navigate to the Positive Sentiment tab and verify we have landed in expected tab.
   * Verify the Sentiment Signal dropdown text is All Signal if not select All in the Dropdown value.
   * Select 'Elasped Time' in the dropdown, Click 'Collapse all' button and validate case card is not exist.
   * Click 'Expand all' button and validate case card is exist.
   */
  it('C129410: Agent Insights - Positive Sentiment tabs - Expand all <-> Collapse all Functionality Check', { tags: ['Agents', 'staging'] }, function positiveSentimentExpandAll() {
    agentInsights.agentNameLabel().should('be.visible').and('have.text', this.agentDetail.sl_name);
    agentInsights.getTabsByName('positive_sentiments').eq(1).click();
    consolePage.selectAllSignalsInDropdown();
    consolePage.selectShowAllInDropdown();
    consolePage.groupByElapsedTime();
    consolePage.expandAllConsoleLists();
    cy.waitForLoaders();
    consolePage.collapseExpandButton().should('be.visible').and('have.text', 'Collapse All');
    consolePage.caseCard().should('be.visible');
    consolePage.caseListCustomerName().should('be.visible');
    consolePage.collapseExpandButton().click();
    cy.waitForLoaders();
    consolePage.collapseExpandButton().should('be.visible').and('have.text', 'Expand All');
    consolePage.caseCard().should('not.exist');
    consolePage.caseListCustomerName().should('not.exist');
  });

  /*
   * Go to Agents insights page, Search any Agent name.
   * Navigate to the Product Feedback tab and verify we have landed in expected tab.
   * Verify the Sentiment Signal dropdown text is All Signal if not select All in the Dropdown value.
   * Select 'Elasped Time' in the dropdown, Click 'Collapse all' button and validate case card is not exist.
   * Click 'Expand all' button and validate case card is exist.
   */
  it('C129411: Agent Insights - Product Feedback tabs - Expand all <-> Collapse all Functionality Check', { tags: ['Agents', 'staging'] }, function productFeedbackExpandAll() {
    agentInsights.agentNameLabel().should('be.visible').and('have.text', this.agentDetail.sl_name);
    agentInsights.getTabsByName('product_feedback').eq(1).click();
    consolePage.selectAllSignalsInDropdown();
    consolePage.selectShowAllInDropdown();
    consolePage.groupByElapsedTime();
    consolePage.expandAllConsoleLists();
    cy.waitForLoaders();
    consolePage.collapseExpandButton().should('be.visible').and('have.text', 'Collapse All');
    consolePage.caseCard().should('be.visible');
    consolePage.caseListCustomerName().should('be.visible');
    consolePage.collapseExpandButton().click();
    cy.waitForLoaders();
    consolePage.collapseExpandButton().should('be.visible').and('have.text', 'Expand All');
    consolePage.caseCard().should('not.exist');
    consolePage.caseListCustomerName().should('not.exist');
  });
});
