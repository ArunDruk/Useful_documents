import { arrayEquals, urlHelpers } from '../../../utils';
import { agentInsights } from '../../../pages';
import sortTimePhrases from '../../../utils/sortTimePhrases';

describe('Agent Insights - Open Cases', { tags: ['Agent Insights', 'staging', 'prod'] }, () => {
  let agentDetail;

  beforeEach(() => {
    cy.intercept('POST', 'api/cache/qa-automation/tickets/sortByWithData').as('sortBy');
    cy.loginByApi();
    cy.slcHelpers.getDetailsOfAgentsWithCases().then((agentDetails) => {
      agentDetail = Cypress._.sample(agentDetails);
      cy.visit(urlHelpers.agentInsights.home);
      agentInsights.agentInsightsSearchFieldInput().type(agentDetail.sl_name);
      agentInsights.expandFilterButton().click();
      agentInsights.filterByType('Individual Agent');
      agentInsights.agentSearchResultListNameLabel().should('contain', agentDetail.sl_name).click();
      agentInsights.agentNameLabel().should('have.text', agentDetail.sl_name);
      agentInsights.agentOpenCasesCountTab().click();
    });
  });

  /*
   * Visit the Agent Insight page
   * Lookup an agent and load insights for them
   * The Open cases tab will be selected.
   * Case Distribution chart will load.
   * Case Backlog section should show up.
   */
  it('C37650: Agent Insights - Open Cases - visit Open cases tab', function validateMedianMetrics() {
    agentInsights.caseDetails().should('contain', 'Backlog');
    agentInsights.caseDetails().should('contain', 'Case Distribution');
  });

  /*
   * Visit the Agent Insight page
   * Lookup an agent and load insights for them
   * The Open cases tab will be selected.
   * Sort by sentiment score
   */
  it('C37651: Agent Insights - Open Cases -> Sort by Sentiment Score', function validateMedianMetrics() {
    agentInsights.sortCasesBy('Sentiment Score');
    // cy.wait('@sortBy');
    cy.waitForLoaders();
    agentInsights.switchSortDirection();
    agentInsights
      .openCaseListItemSentimentScoreLabel()
      .text()
      .then(async (targetValue) => arrayEquals(targetValue, sortTimePhrases(targetValue, true)))
      .should('be.true');

    agentInsights.switchSortDirection('asc');
    agentInsights
      .openCaseListItemSentimentScoreLabel()
      .text()
      .then(async (targetValue) => arrayEquals(targetValue, sortTimePhrases(targetValue, false)))
      .should('be.true');
  });

  /*
   * Visit the Agent Insight page
   * Lookup an agent and load insights for them
   * The Open cases tab will be selected.
   * Sort by attention score
   */
  it('C37652: Agent Insights - Open Cases -> Sort by Attention Score', function validateMedianMetrics() {
    agentInsights.sortCasesBy('Attention Score');
    // cy.wait('@sortBy');
    cy.waitForLoaders();
    agentInsights.switchSortDirection();
    agentInsights
      .openCaseListItemAttentionScoreLabel()
      .text()
      .then(async (targetValue) => arrayEquals(targetValue, sortTimePhrases(targetValue, true)))
      .should('be.true');

    agentInsights.switchSortDirection('asc');
    agentInsights
      .openCaseListItemAttentionScoreLabel()
      .text()
      .then(async (targetValue) => arrayEquals(targetValue, sortTimePhrases(targetValue, false)))
      .should('be.true');
  });

  /*
   * Visit the Agent Insight page
   * Lookup an agent and load insights for them
   * The Open cases tab will be selected.
   * Sort by created date
   */
  it('C37653: Agent Insights - Open Cases -> Sort by Created Date', function validateMedianMetrics() {
    agentInsights.sortCasesBy('Created Date');
    // cy.wait('@sortBy');
    cy.waitForLoaders();
    agentInsights.switchSortDirection();
    agentInsights
      .openCaseListItemTimeLabel()
      .text()
      .then(async (targetValue) => arrayEquals(targetValue, sortTimePhrases(targetValue, true)))
      .should('be.true');

    agentInsights.switchSortDirection('asc');
    agentInsights
      .openCaseListItemTimeLabel()
      .text()
      .then(async (targetValue) => arrayEquals(targetValue, sortTimePhrases(targetValue, false)))
      .should('be.true');
  });

  /*
   * Visit the Agent Insight page
   * Lookup an agent and load insights for them
   * The Open cases tab will be selected.
   * Sort by recent activity
   */
  it('C37654: Agent Insights - Open Cases -> Sort by Reecent Activity', function validateMedianMetrics() {
    agentInsights.sortCasesBy('Recent Activity');
    // cy.wait('@sortBy');
    cy.waitForLoaders();
    agentInsights.switchSortDirection();
    agentInsights
      .openCaseListItemTimeLabel()
      .text()
      .then(async (targetValue) => arrayEquals(targetValue, sortTimePhrases(targetValue, true)))
      .should('be.true');

    agentInsights.switchSortDirection('asc');
    agentInsights
      .openCaseListItemTimeLabel()
      .text()
      .then(async (targetValue) => arrayEquals(targetValue, sortTimePhrases(targetValue, false)))
      .should('be.true');
  });
});
