import { urlHelpers } from '../../../utils';
import { agentInsights, agents, apiHelpers } from '../../../pages';

describe('Agents Insights: Favourite Agent workflow', () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.clearRecentlyVisitedAgentInsight();
    apiHelpers.removeAllFavoriteAgents();
    cy.slcHelpers.getDetailsOfAgentsWithCases().then((agentDetails) => {
      const agentDetail = Cypress._.sample(agentDetails);
      cy.wrap(agentDetail.id).as('agentId');
      cy.wrap(agentDetail).as('agentDetail');
      cy.visit(urlHelpers.agentInsights.agentPage(agentDetail.id));
      cy.waitForLoaders();
    });
  });

  afterEach(() => apiHelpers.removeAllFavoriteAgents());

  /*
   * Go to Agent insight page.
   * Search for any Agent name and click enter.
   * Click on favorite icon and validate that it reflects on the my agents page.
   */
  it('C129380: Verify the workflow of adding favourite agent from Agents insight page', { tags: ['Agents', 'staging'] }, function addingFavoriteAgent() {
    agentInsights.agentNameLabel().should('be.visible').and('have.text', this.agentDetail.sl_name);
    agentInsights.agentInsightsFavoriteButton().should('be.visible').click();
    cy.visit(urlHelpers.myAgents);
    cy.waitForLoaders();
    agents.agentList().invoke('text').should('be.equal', this.agentDetail.sl_name);
  });

  /*
   * Go to Agent insight page.
   * Search for any Agent name and click enter.
   * Click on favorite icon and validate that it reflects on the my agents page.
   * Go to Agent insight page, search for the same agent.
   * Uncheck favorite icon for that agent and validate that it reflects on the my agents page.
   */
  it('C129412: Verify the workflow of removing favourite agent from Agents insight page', { tags: ['Agents', 'staging'] }, function addingAndRemovingFavoriteAgent() {
    agentInsights.agentNameLabel().should('be.visible').and('have.text', this.agentDetail.sl_name);
    agentInsights.agentInsightsFavoriteButton().should('be.visible').click();
    cy.visit(urlHelpers.myAgents);
    cy.waitForLoaders();
    agents.agentList().invoke('text').should('be.equal', this.agentDetail.sl_name);
    cy.visit(urlHelpers.agentInsights.home);
    cy.waitForLoaders();
    agentInsights.agentInsightsSearchFieldInput().click().type(this.agentDetail.sl_name);
    agentInsights.agentSearchResultList().first().click();
    cy.waitForLoaders();
    agentInsights.agentInsightsFavoriteButton().should('be.visible').click();
    cy.visit(urlHelpers.myAgents);
    cy.waitForLoaders();
    cy.get('body').should('not.contain', this.agentDetail.sl_name);
  });
});
