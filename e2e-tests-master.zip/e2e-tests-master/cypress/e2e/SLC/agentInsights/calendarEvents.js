import moment from 'moment';
import { urlHelpers } from '../../../utils';
import { agentInsights, datePicker } from '../../../pages';

describe('Agent Insights - Events', { tags: ['Agent Insights', 'staging', 'prod'] }, () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.agentInsights.home);
  });

  /*
   * Visit the Agent Insight home page
   * Fetch details for an agent with active cases
   * Enter the agent name in the search box
   * Click the search result
   * Add an Out of office event and check the status
   * Add an Away event and check the status
   */
  it('C495: Checking the functionality of Adding Events for the Agents. (Today)', function validateMedianMetrics() {
    cy.slcHelpers.getDetailsOfAgentsWithCases().then((agentDetails) => {
      const agentDetail = Cypress._.sample(agentDetails);
      agentInsights.agentInsightsSearchFieldInput().type(agentDetail.sl_name);
      agentInsights.expandFilterButton().click();
      agentInsights.filterByType('Individual Agent');
      agentInsights.agentSearchResultListNameLabel().should('contain', agentDetail.sl_name).click();
      agentInsights.agentNameLabel().should('have.text', agentDetail.sl_name);

      const dayToday = moment().add(0, 'days');
      datePicker.calendarDayButton(dayToday.format('MMMM D,')).dblclick();
      agentInsights.agentInsightsEventOOOSelectionButton().click({ force: true });
      agentInsights.eventReasonPill('Vacation').click();
      agentInsights.eventDetailTextArea().type('OOO');
      agentInsights.agentInsightsOOOSaveButton().click();
      cy.waitForLoaders();
      datePicker.calendarDayButton(dayToday.format('MMMM D,')).trigger('mouseover');
      agentInsights.eventTooltip().should('contain', 'Vacation').and('contain', 'OOO').and('contain', 'Click to edit');
      agentInsights.OOOStatus().should('contain', '!Out of office');

      datePicker.calendarDayButton(dayToday.format('MMMM D,')).dblclick();
      agentInsights.agentInsightsEventAwaySelectionButton().click({ force: true });
      agentInsights.eventReasonPill('Training').click();
      agentInsights.eventDetailTextArea().clear().type('Away');
      agentInsights.agentInsightsOOOSaveButton().click();
      cy.waitForLoaders();
      datePicker.calendarDayButton(dayToday.format('MMMM D,')).trigger('mouseover');
      agentInsights.eventTooltip().should('contain', 'Training').and('contain', 'Away').and('contain', 'Click to edit');
      agentInsights.OOOStatus().should('contain', '!Away');
    });
  });
});
