import moment from 'moment';
import { urlHelpers } from '../../../utils';
import { agentInsights, apiHelpers, datePicker } from '../../../pages';

describe('Agent Insights - Events', { tags: ['Agent Insights', 'staging'] }, () => {
  beforeEach(() => {
    cy.loginByApi();
    apiHelpers.clearRecentlyVisitedAgentInsight();
    cy.visit(urlHelpers.agentInsights.home);
  });

  /*
   * Visit the Agent Insight home page.
   * Fetch details for an agent with active cases.
   * Enter the agent name in the search box, Click the search result.
   * Add an Out of office event for today and validate that 'Click to edit' tool tip message is diplayed while hovering.
   * '!Out of office' Status label is diplayed on the top of the agent name.
   * Deleting the Event after verify.
   *
   */
  it('C134607: Checking the functionality of Adding Events for the Agents. (Today)', () => {
    cy.slcHelpers.getDetailsOfAgentsWithCases().then((agentDetails) => {
      const agentDetail = Cypress._.sample(agentDetails);
      const dayToday = moment().add(0, 'days');

      agentInsights.agentInsightsSearchFieldInput().type(agentDetail.sl_name);
      agentInsights.expandFilterButton().click();
      agentInsights.filterByType('Individual Agent');
      agentInsights.agentSearchResultListNameLabel().should('contain', agentDetail.sl_name).click();
      agentInsights.agentNameLabel().should('have.text', agentDetail.sl_name);
      datePicker.calendarDayButton(dayToday.format('MMMM D,')).dblclick();
      agentInsights.eventDetailTextArea().type('OOO');
      agentInsights.agentInsightsOOOSaveButton().click();
      cy.waitForLoaders();
      datePicker.calendarDayButton(dayToday.format('MMMM D,')).trigger('mouseover');
      agentInsights.eventTooltip().should('contain', 'OOO').and('contain', 'Click to edit');
      agentInsights.OOOStatus().should('contain', '!Out of office');
      datePicker.calendarDayButton(dayToday.format('MMMM D,')).dblclick();
      agentInsights.agentInsightsOOODeleteButton().should('be.visible').click();
    });
  });

  /*
   * Visit the Agent Insight home page.
   * Fetch details for an agent with active cases.
   * Enter the agent name in the search box, Click the search result.
   * Add an Out of office event for any single day other than today and validate that 'Click to edit' tool tip message is diplayed while hovering.
   * '!Out of office' Status label is tag not exist.
   * Deleting the Event after verify.
   */
  it('C134621: Checking the functionality of Adding Events for the Agents. (Not Today)', () => {
    cy.slcHelpers.getDetailsOfAgentsWithCases().then((agentDetails) => {
      const agentDetail = Cypress._.sample(agentDetails);
      const dayNotToday = moment().add(1, 'days');

      agentInsights.agentInsightsSearchFieldInput().type(agentDetail.sl_name);
      agentInsights.expandFilterButton().click();
      agentInsights.filterByType('Individual Agent');
      agentInsights.agentSearchResultListNameLabel().should('contain', agentDetail.sl_name).click();
      agentInsights.agentNameLabel().should('have.text', agentDetail.sl_name);
      datePicker.calendarDayButton(dayNotToday.format('MMMM D,')).dblclick();
      agentInsights.eventDetailTextArea().type('OOO');
      agentInsights.agentInsightsOOOSaveButton().click();
      cy.waitForLoaders();
      datePicker.calendarDayButton(dayNotToday.format('MMMM D,')).trigger('mouseover');
      agentInsights.eventTooltip().should('contain', 'OOO').and('contain', 'Click to edit');
      agentInsights.OOOStatus().should('not.exist');
      datePicker.calendarDayButton(dayNotToday.format('MMMM D,')).dblclick();
      agentInsights.agentInsightsOOODeleteButton().should('be.visible').click();
    });
  });

  /*
   * Visit the Agent Insight home page.
   * Fetch details for an agent with active cases.
   * Enter the agent name in the search box, Click the search result.
   * Add an Out of office event for multiple days starting from Today, Validate that it should be reflected.
   * Add an Out of office event for today and validate that 'Click to edit' tool tip message is diplayed while hovering.
   * '!Out of office' Status label is diplayed on the top of the agent name.
   * Deleting the Event after verify.
   */
  it('C134622: Checking the functionality of Adding Events for the Agents. (multiple days starting from Today)', () => {
    cy.slcHelpers.getDetailsOfAgentsWithCases().then((agentDetails) => {
      const agentDetail = Cypress._.sample(agentDetails);
      const dayToday = moment().add(0, 'days');
      const multipleDays = moment().add(4, 'days');

      agentInsights.agentInsightsSearchFieldInput().type(agentDetail.sl_name);
      agentInsights.expandFilterButton().click();
      agentInsights.filterByType('Individual Agent');
      agentInsights.agentSearchResultListNameLabel().should('contain', agentDetail.sl_name).click();
      agentInsights.agentNameLabel().should('have.text', agentDetail.sl_name);
      datePicker.calendarDayButton(dayToday.format('MMMM D,')).click();
      datePicker.calendarDayButton(multipleDays.format('MMMM D,')).click();
      agentInsights.OOOAllDayCheckBox().invoke('attr', 'data-status').should('eq', 'checked');
      agentInsights.eventDetailTextArea().type('OOO');
      agentInsights.agentInsightsOOOSaveButton().click();
      cy.waitForLoaders();
      datePicker.calendarDayButton(dayToday.format('MMMM D,')).trigger('mouseover');
      agentInsights.eventTooltip().should('contain', 'Click to edit');
      agentInsights.OOOStatus().should('contain', '!Out of office');
      datePicker.calendarDayButton(dayToday.format('MMMM D,')).dblclick();
      agentInsights.agentInsightsOOODeleteButton().should('be.visible').click();
    });
  });

  /*
   * Visit the Agent Insight home page.
   * Fetch details for an agent with active cases.
   * Enter the agent name in the search box, Click the search result.
   * Add an Out of office event for multiple days starting other than Today, Validate that it should be reflected.
   * Add an Out of office event for multiple days starting other than Today and validate that 'Click to edit' tool tip message is diplayed while hovering.
   * '!Out of office' Status label is tag not exist.
   * Deleting the Event after verify.
   */
  it('C134608: Checking the functionality of Adding Events for the Agents. (multiple days starting other than Today)', () => {
    cy.slcHelpers.getDetailsOfAgentsWithCases().then((agentDetails) => {
      const agentDetail = Cypress._.sample(agentDetails);
      const dayNotToday = moment().add(1, 'days');
      const multipleDays = moment().add(4, 'days');

      agentInsights.agentInsightsSearchFieldInput().type(agentDetail.sl_name);
      agentInsights.expandFilterButton().click();
      agentInsights.filterByType('Individual Agent');
      agentInsights.agentSearchResultListNameLabel().should('contain', agentDetail.sl_name).click();
      agentInsights.agentNameLabel().should('have.text', agentDetail.sl_name);
      datePicker.calendarDayButton(dayNotToday.format('MMMM D,')).click();
      datePicker.calendarDayButton(multipleDays.format('MMMM D,')).click();
      cy.getByTestId('animated-checkbox-default-group-All Day-id').invoke('attr', 'data-status').should('eq', 'checked');
      agentInsights.eventDetailTextArea().type('OOO');
      agentInsights.agentInsightsOOOSaveButton().click();
      cy.waitForLoaders();
      datePicker.calendarDayButton(dayNotToday.format('MMMM D,')).trigger('mouseover');
      agentInsights.eventTooltip().should('contain', 'Click to edit');
      agentInsights.OOOStatus().should('not.exist');
      datePicker.calendarDayButton(dayNotToday.format('MMMM D,')).dblclick();
      agentInsights.agentInsightsOOODeleteButton().should('be.visible').click();
    });
  });
});
