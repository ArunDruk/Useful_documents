import { urlHelpers } from '../../../utils';
import { agentInsights, consolePage, supportHub } from '../../../pages';

describe('Agents Insights: Visibility of the LTE tab', () => {
  beforeEach(() => {
    cy.loginByApi();
    cy.visit(urlHelpers.console.withTimeFilter.lastSevenDays);
    cy.slcHelpers.clearCustomersQuickFilter();
    cy.slcHelpers.clearAgentsQuickFilter();
    cy.slcHelpers.clearCaseFieldQuickFilter();
    cy.slcHelpers.deleteGlobalFilter();
  });

  /*
   * Go to console page, Click LTE tab.
   * Get any Agent name in the list, Go to Agent insights page.
   * Search for that Agent name and click enter.
   * Click on the LTE tab, Validate the display of LTE header title.
   * Open any SH and check 'Likely to Escalate' status label is displayed.
   */
  it('C129374: Verify the display of LTE tab', { tags: ['Agents', 'staging'] }, () => {
    consolePage.lteTab().click({ force: true });
    consolePage.consoleEscalatedTabHeaderTitle().should('be.exist');
    // Update the title to 'Likely To Escalate' in future tracking via -SLC-34629
    consolePage.consoleEscalatedTabHeaderTitle().invoke('text').should('contain', `Escalations`);
    consolePage.groupByPriorityOption();
    cy.waitForLoaders();
    consolePage.caseCardCustomerName().eq(0).click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    cy.waitForLoaders();
    supportHub
      .caseOwnerLabel()
      .eq(0)
      .then((labelText) => {
        const agentName = labelText.text();
        cy.visit(urlHelpers.agentInsights.home);
        cy.waitForLoaders();
        agentInsights.agentInsightsSearchFieldInput().click().type(agentName);
        agentInsights.agentSearchResultList().first().click();
        cy.waitForLoaders();
        agentInsights.getTabsByName('Likely_to_Escalate').eq(1).click();
        consolePage.consoleEscalatedTabHeaderTitle().should('be.exist');
        // Update the title to 'Likely To Escalate' in future tracking via -SLC-34629
        consolePage.consoleEscalatedTabHeaderTitle().invoke('text').should('contain', `Escalations`);
        consolePage.escalationCaseCard().eq(0).click();
        cy.waitForLoaders();
        supportHub.baseContainer().should('be.visible');
        cy.waitForLoaders();
        supportHub.supportHubLteLabel().invoke('text').should('contain', `Likely to Escalate`);
        supportHub.closeButton().click();
      });
  });
});
