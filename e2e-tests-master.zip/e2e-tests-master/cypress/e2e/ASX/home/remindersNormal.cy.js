// This file has all the test scenarios that can be executed for reminders feature for ASX
import { reminderPage } from '../../../pages/ASX';

describe('Check and validate reminder feature', { tags: ['@ASX'] }, () => {
  beforeEach(() => {
    cy.loginAgentSX();
  });

  // This test case will verify the empty state text presence for reminder column.
  // First it checks if the text is visible and then checks for the text.
  it('C9142: should show the empty state of reminder', () => {
    reminderPage.reminderEmptyText().should('be.visible').and('contain', 'No outstanding reminders.');
  });

  // This test case checks whether the plus icon is visible and when it opens the modal
  // checks for the focus moved to textarea or not.
  it('C9131:should verify plus icon opens the reminder creation modal', { tags: ['@ASX'] }, () => {
    reminderPage.reminderCreationPlusIcon().should('be.visible').click();
    reminderPage.reminderCreationTextArea().should('have.focus');
  });
});
