beforeEach(() => {
  cy.loginAgentSX();
});
describe('Check home page', { tags: ['@ASX'] }, () => {
  it('should render the page', () => {
    cy.get('body').should('contain.text', 'Home');
  });

  it('should open feedback popup', () => {
    cy.get('[data-testid="feedback-button"]').click(true);
    cy.get('body').should('contain.text', 'Share your feedback');
  });
});
