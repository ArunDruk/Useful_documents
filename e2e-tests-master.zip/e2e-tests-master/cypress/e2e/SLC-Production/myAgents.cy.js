import { urlHelpers } from '../../utils';
import { apiHelpers, agents, agentInsights, commonElements } from '../../pages';

describe('My Agents Production Tests', () => {
  before(function beforeHook() {
    cy.loginWithOktaUI();
    apiHelpers.isModuleEnabled('myAgents').then((isEnabled) => {
      if (!isEnabled) this.skip();
    });
    cy.visit(urlHelpers.myAgents);
    apiHelpers.removeAllFavoriteAgents();
    cy.slcHelpers.getDetailsOfAgentsWithCases().then((agentDetails) => {
      const agentDetail = Cypress._.sample(agentDetails);
      cy.wrap(agentDetail).as('agentDetail');
    });
    cy.waitForLoaders();
    commonElements.clickWelcomePageGetStartedButton();
  });

  after(() => {
    apiHelpers.removeAllFavoriteAgents();
  });

  /**
   * C9261
   * - Verify "My agents" page should be displayed with "Add a favorite" button.
   * - Add a agent as Favourite and verify the added agent is displaying
   * - Remove the agent from Favorite at the end
   */
  it('C9261: Validate the display of "My agents" page with "Add a favorite" button', { tags: 'Agents' }, function favoriteAgentList() {
    cy.waitForLoaders();
    agents.addFavoriteButton().should('be.visible');
    commonElements.appWrapper().should('contain', 'My Agents');
    agents.agentSearchInputField().click().type(this.agentDetail.sl_name);
    agentInsights.expandFilterButton().click();
    agentInsights.filterByType('Individual Agent');
    agents.agentSearchResultListItem().should('contain', this.agentDetail.sl_name).click();
    agents.agentList().eq(0).contains(this.agentDetail.sl_name);
  });
});
