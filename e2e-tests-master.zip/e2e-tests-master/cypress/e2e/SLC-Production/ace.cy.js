import { urlHelpers } from '../../utils';
import { acePage, apiHelpers, commonElements, datePicker, supportHub } from '../../pages';

describe('ACE Production Tests', () => {
  before(function beforeHook() {
    cy.loginWithOktaUI();
    apiHelpers.isModuleEnabled('manualQA').then((isEnabled) => {
      if (!isEnabled) this.skip();
    });
    apiHelpers.clearAgentFilterInACEPage();
    cy.visit(urlHelpers.caseEvaluation);
    cy.waitForLoaders();
    commonElements.clickWelcomePageGetStartedButton();
    acePage
      .recommendedContainerHeader()
      .invoke('text')
      .then((headerTitle) => {
        if (headerTitle === '0Recommended') {
          acePage.recommendedSidebarExpandButton().click();
          datePicker.datePickerTrigger().eq(0).click();
          datePicker.selectLastMonthWithOption(3);
          datePicker.datePickerTrigger().eq(0).should('have.text', 'Last 3 months');
          cy.waitForLoaders();
        }
      });
  });

  after(() => apiHelpers.clearAgentFilterInACEPage());

  /**
   * C9294
   * - Verify the visibility of the below 4 columns - Recommended, To review, In progress and Recently reviewed
   */
  it('C9294: [Agent Coaching] Verify the display of columns in Recmmendations tab', { tags: 'Ace' }, function favoriteCustomerList() {
    acePage.recommendedContainer().should('exist').and('contain', 'Recommended');
    acePage.toReviewContainer().should('exist').and('contain', 'To review');
    acePage.inProgressContainer().should('exist').and('contain', 'In progress');
    acePage.recentlyReviewedContainer().should('exist').and('contain', 'Recently reviewed');
  });

  /*
   * Open the ACE page.
   * Change the sort option in recommended column (all 3 options).
   * Validate the sort dropdown is displaying the selected value.
   * Validate cases are sorted correctly based on the selected value
   */
  it('C9292: Verify the sort option in recommended column', { tags: ['ACE', 'staging'] }, () => {
    acePage
      .dropdownText()
      .eq(0)
      .then((button) => {
        const textmsg = button.text();
        if (textmsg === 'Recommended') {
          cy.waitForLoaders();
        } else {
          acePage.recommendedSidebarDropdown().click();
          acePage.dropdownRecommendedList().click();
          acePage.dropdownText().eq(0).should('be.visible').and('contain', 'Recommended');
          cy.waitForLoaders();
        }
      });

    acePage
      .commonAgentNameLabel()
      .eq(0)
      .then((buttonText) => {
        const customerName = buttonText.text();
        acePage.recommendedSidebarDropdown().click();
        acePage.dropdownConversationsList().click();
        cy.waitForLoaders();
        acePage.dropdownText().eq(0).should('be.visible').and('contain', 'Conversations');
        acePage.commonAgentNameLabel().eq(0).should('not.have.text', customerName);
      });

    acePage
      .commonAgentNameLabel()
      .eq(0)
      .then((buttonText) => {
        const customerName = buttonText.text();
        acePage.recommendedSidebarDropdown().click();
        acePage.dropdownCollaboratorsList().click();
        cy.waitForLoaders();
        acePage.dropdownText().eq(0).should('be.visible').and('contain', 'Collaborators');
        acePage.commonAgentNameLabel().eq(0).should('not.have.text', customerName);
      });

    acePage
      .commonAgentNameLabel()
      .eq(0)
      .then((buttonText) => {
        const customerName = buttonText.text();
        acePage.recommendedSidebarDropdown().click();
        acePage.dropdownRecommendedList().click();
        cy.waitForLoaders();
        acePage.dropdownText().eq(0).should('be.visible').and('contain', 'Recommended');
        acePage.commonAgentNameLabel().eq(0).should('not.have.text', customerName);
      });
  });

  /**
   * Open the Ace page.
   * Verify the visibility of Recommendations and Completed Evaluations tab.
   */
  it('C9293: Validate the display of agent coaching tabs', { tags: ['Ace', 'staging', 'prod'] }, () => {
    acePage.recommendationsTab().invoke('attr', 'data-active').should('include', 'true');
    acePage.recommendationsTab().should('be.visible').invoke('text').should('be.equal', 'Recommendations');
    acePage.completedEvaluationsTab().invoke('attr', 'data-active').should('include', 'false');
    acePage.completedEvaluationsTab().should('be.visible').invoke('text').should('be.equal', 'Completed evaluations');
  });

  /**
   * Open the Ace page.
   * Click on Recommended Tab.
   * Validate that at least 1 ticket is displayed in the recommended column.
   */
  it('C9336: Validate the display of tickets in the recommended tab', { tags: ['Ace', 'staging', 'prod'] }, () => {
    acePage.recommendationsTab().should('be.visible').click();
    acePage.aceCaseListContainer().find('[class^="CaseListBase__CardWrapper"]').its('length').should('be.gte', 1);
    acePage.aceAgentCaseList().should('be.visible');
    acePage.recommendedCaseCard().first().click();
    supportHub.baseContainer().should('be.visible');
    supportHub.closeButton().click();
  });

  /**
   * Open the Ace page.
   * Click on Completed Evaluation Tab.
   * Validate the display of Timeframes[Last 3 weeks, Last 2 Weeks, This week]in the top left corner below the tabs.
   */
  it('C9319: Verify the display of timeframes in Completed evaluations tab', { tags: ['Ace', 'staging', 'prod'] }, () => {
    acePage.completedEvaluationsTab().click();
    acePage.datePeriod3WeeksTab().should('be.visible').and('contain', 'Last 3 weeks');
    acePage.datePeriod2WeeksTab().should('be.visible').and('contain', 'Last 2 weeks');
    acePage.datePeriodThisWeekTab().should('be.visible').and('contain', 'This week');
  });

  it('C824: Verify that the tickets are filtered as per selected agent', { tags: 'Ace' }, () => {
    cy.waitForLoaders();
    acePage.recommendationsTab().should('be.visible').click();
    cy.waitForLoaders();
    cy.getByTestId('ace-case-review-agantName')
      .first()
      .invoke('text')
      .then((agentNameRecommendationTab) => {
        cy.getByTestId('ace__agentFilter__trigger').click();
        cy.getByTestId('filters-scoreFilters-searchOptionFilter-searchInput').type(agentNameRecommendationTab);
        cy.get("[type='checkbox']").first().click({ force: true });
        cy.getByTestId('global-filter--selected--sl_assignee_id').contains('1 selected').should('be.visible');
        cy.getByTestId('global-filter--selected--sl_assignee_id').click();
        cy.getByTestId('ace-evaluations-filters-agent-label').contains(agentNameRecommendationTab).should('be.visible');
        cy.getByTestId('filters-scoreFilters-searchOptionFilter-applyFilterBtn').click();
        cy.getByTestId('ace-case-review-agantName').eq(0).contains(agentNameRecommendationTab).should('be.visible');
      });
  });
});
