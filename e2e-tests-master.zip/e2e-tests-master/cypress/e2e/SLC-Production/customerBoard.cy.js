import { urlHelpers } from '../../utils';
import { apiHelpers, commonElements, customerBoardPage, healthScore } from '../../pages';

describe('Customer Board Production Tests', () => {
  before(function beforeHook() {
    cy.loginWithOktaUI();
    apiHelpers.isModuleEnabled('customerBoard').then((isEnabled) => {
      if (!isEnabled) this.skip();
    });
    cy.visit(urlHelpers.customerBoard);
  });

  /**
   * C9331
   * - If page is empty, validate the presence of the Load standard list set and Create Custom list button
   * - If the page have data, validate the presence of customer lists and Create New List button
   */
  it('C9331: Validate the display of "Top Customers" page', { tags: ['Customer Board'] }, () => {
    cy.waitForLoaders();
    commonElements.appWrapper().then(($parentDiv) => {
      if ($parentDiv.find('[data-testid="module-common-welcome-page-container"]').length > 0) {
        customerBoardPage.welcomePageCreateCustomListButton().should('exist');
        customerBoardPage.welcomePageDefaultListButton().should('exist');
      } else {
        customerBoardPage.createNewListButton().should('exist');
        customerBoardPage.listTitleNameLabel().should('exist');
        customerBoardPage.customerBoardCustomerNameLabel().should('exist');
      }
    });
  });

  /**
   * C9333
   * - Validate whether the sort is happening or not in normal view
   */
  it('C9333: Click on sort direction in the normal view', { tags: ['Customer Board'] }, () => {
    cy.waitForLoaders();
    commonElements.appWrapper().then(($parentDiv) => {
      if ($parentDiv.find('[data-testid="module-common-welcome-page-container"]').length > 0) {
        customerBoardPage.welcomePageDefaultListButton().click();
        cy.waitForLoaders();
      }
    });
    customerBoardPage.customerBoardSwitchSortOrder();
  });

  /**
   * C9330
   * - Validate should be expanded and the title should be the same as before.
   * - Validate list should close and retain the previous state
   */
  it('C9330: View the list in the expanded view and close', { tags: ['Customer Board'] }, () => {
    cy.waitForLoaders();
    commonElements.appWrapper().then(($parentDiv) => {
      if ($parentDiv.find('[data-testid="module-common-welcome-page-container"]').length > 0) {
        customerBoardPage.welcomePageDefaultListButton().click();
        cy.waitForLoaders();
      }
    });
    customerBoardPage
      .listTitleNameLabel()
      .eq(0)
      .then(($listTitle) => {
        const firstCardTitle = $listTitle.text();
        customerBoardPage.expandButton().eq(0).click();
        customerBoardPage
          .customerBoardExpandPopupListTitleLabel()
          .eq(0)
          .then((titleValue) => {
            customerBoardPage.customerBoardExpandPopupListTitleLabel().should('exist');
            customerBoardPage.customerBoardExpandPopupListBodyLabel().should('exist');
            expect(titleValue.text()).to.include(firstCardTitle);
          });
      });
    customerBoardPage.expandPopupCloseIcon().click();
    cy.waitForLoaders();
    customerBoardPage.customerBoardExpandPopupListTitleLabel().should('not.exist');
    customerBoardPage.listTitleNameLabel().should('be.visible');
  });

  /**
   * C9332
   * - Validate whether the sort is happening or not in expanded view
   */
  it('C9332: Click on sort direction in the expanded view', { tags: ['Customer Board'] }, () => {
    cy.waitForLoaders();
    commonElements.appWrapper().then(($parentDiv) => {
      if ($parentDiv.find('[data-testid="module-common-welcome-page-container"]').length > 0) {
        customerBoardPage.welcomePageDefaultListButton().click();
        cy.waitForLoaders();
      }
    });
    customerBoardPage.expandButton().eq(0).click();
    cy.waitForLoaders();
    customerBoardPage
      .customerBoardExpandPopupCustomerNameLabel()
      .eq(0)
      .then((buttonText) => {
        const customerNameBeforeSorted = buttonText.text();
        customerBoardPage.expandPopupThreeDotMenuDropdown().eq(0).should('be.visible').click({ force: true });
        customerBoardPage.expandPopupSortListButton().eq(0).should('be.visible').click({ force: true });
        cy.waitForLoaders();
        customerBoardPage
          .customerBoardExpandPopupCustomerNameLabel()
          .eq(0)
          .then((textAfterSort) => {
            const customerNameAfterSorted = textAfterSort.text();
            expect(customerNameAfterSorted).to.not.equal(customerNameBeforeSorted);
          });
      });
    customerBoardPage.expandPopupCloseIcon().click();
  });

  /**
   * C9338
   * - Create Custom List flow, validate the presence of customer lists and Create New List button
   * - Create Standard List flow, validate the presence of customer lists and Create New List button
   */
  it("C9338: Check the 'Load standard list set '/ 'Create Custom list' work flows", { tags: ['Customer Board'] }, () => {
    apiHelpers.removeExistingListCustomerBoard();
    cy.visit(urlHelpers.customerBoard);
    cy.waitForLoaders();
    // Custom List Creation
    customerBoardPage.welcomePageCreateCustomListButton().click();
    cy.waitForLoaders();
    customerBoardPage.createCaseListHeaderTitle().eq(0).click();
    customerBoardPage.createListAddButton().click();
    customerBoardPage.createNewListButton().should('exist');
    customerBoardPage.listTitleNameLabel().should('exist');
    customerBoardPage.customerBoardCustomerNameLabel().should('exist');
    customerBoardPage.deleteCaseList();
    cy.waitForLoaders();
    customerBoardPage.createListCancelButton().click();
    cy.waitForLoaders();
    // Default List Creation
    customerBoardPage.welcomePageDefaultListButton().click();
    cy.waitForLoaders();
    customerBoardPage.createNewListButton().should('exist');
    customerBoardPage.listTitleNameLabel().should('exist');
    customerBoardPage.customerBoardCustomerNameLabel().should('exist');
  });

  /**
   * C6510
   * - Should be able to create list based and HS icon should be displayed
   */
  it('C6510: Verify the display of AHS list in customer board', { tags: ['AHS'] }, () => {
    const createdCardTitle = customerBoardPage.createHealthScoreCaseList('Fair');
    cy.waitForLoaders();
    customerBoardPage.expandButton().eq(0).click();
    cy.waitForLoaders();
    customerBoardPage
      .customerBoardExpandPopupListTitleLabel()
      .eq(0)
      .then((titleValue) => {
        expect(titleValue.text()).to.include(createdCardTitle);
      });
    healthScore.healthScoreBadgeIcon().should('exist');
    customerBoardPage.expandPopupCloseIcon().click();
  });
});
