import { apiHelpers, caseAssignment, commonElements, globalFilters } from '../../pages';
import { urlHelpers } from '../../utils';

describe('ICA Production Tests', () => {
  before(function beforeHook() {
    cy.loginWithOktaUI();
    apiHelpers.isModuleEnabled('caseAssignment').then((isEnabled) => {
      if (!isEnabled) this.skip();
    });

    cy.visit(urlHelpers.caseAssignment);
    cy.waitForLoaders();
    commonElements.clickWelcomePageGetStartedButton();
  });

  /**
   * C9290
   * - Verify the visibility of the Unassigneed & Assigned Today tabs
   */
  it('C9290: validate display of 2 tabs', { tags: 'ICA' }, () => {
    caseAssignment.unassignedTab().should('be.visible');
    caseAssignment.assignedTodayTab().should('be.visible');
  });

  /**
   * C9291
   * - In Unassigned tab, Verify at least 1 ticket is visible with a customer name is exist
   * - In Assigned today tab, Verify at least 1 ticket is visible with a customer name is exist
   */
  it('C9291: validate the display of tickets with customer name', { tags: 'ICA' }, () => {
    caseAssignment
      .unassignedTabCountLabel()
      .invoke('text')
      .then((unassignedCount) => {
        if (unassignedCount !== '0') {
          caseAssignment.unassignedTab().click();
          caseAssignment.caseListItemCard().should('be.visible');
          caseAssignment.caseListCardTitleLabel().should('be.visible');
          caseAssignment
            .caseListCardTitleLabel()
            .first()
            .invoke('text')
            .then((expectedCustomerName) => caseAssignment.summaryCustomerNameLabel().should('be.visible').and('have.text', expectedCustomerName));
        }
      });

    caseAssignment
      .assignedTodayTabCountLabel()
      .invoke('text')
      .then((assignedCount) => {
        if (assignedCount !== '0') {
          caseAssignment.assignedTodayTab().click();
          caseAssignment.caseListItemCard().should('be.visible');
          caseAssignment.caseListCardTitleLabel().should('be.visible');
          caseAssignment
            .caseListCardTitleLabel()
            .first()
            .invoke('text')
            .then((expectedCustomerName) => caseAssignment.summaryCustomerNameLabel().should('be.visible').and('have.text', expectedCustomerName));
        }
      });
  });

  /**
   * C9337
   * - Validate the Filter Icon and Case Field filter dropdown are displaying.
   */
  it('C9337: Validate the presence of Case Field filter in the case assignment left side panel', { tags: 'ICA' }, () => {
    cy.waitForLoaders();
    caseAssignment.caseAssignmentFilterButton().should('be.visible').click();
    cy.contains('Case Fields');
    globalFilters.caseFieldsAgeHeaderDialogBox().should('be.visible');
    caseAssignment.caseAssignmentFilterApplyButton().should('be.visible');
    caseAssignment.caseAssignmentFilterResetAllButotn().should('be.visible');
    caseAssignment.caseAssignmentFilterButton().should('be.visible').click();
  });
});
