import { urlHelpers } from '../../utils';
import { healthScore, supportHub } from '../../pages';
import { getOpenCaseDetails } from '../SLC/supportHub/support';

describe('SupportHub Production Tests', () => {
  before(function beforeHook() {
    cy.loginWithOktaUI();
    getOpenCaseDetails().then((caseDetails) => {
      const caseDetail = Cypress._.sample(caseDetails);

      cy.visit(urlHelpers.supportHubCasePage(caseDetail.caseId));
    });
  });

  it('C9329: validate presence of some incoming/outgoing comments', () => {
    supportHub
      .timelineStatsLabel()
      .invoke('text')
      .should('match', /^[1-9][0-9]*\sInbound|[0-9]+\sOutbound/);
  });

  it('C9335: validate sentiment & attention scores are between 0 and 100', () => {
    supportHub
      .supportHubSentimentScoreLabel()
      .invoke('text')
      .then((sentimentScore) => {
        const value = parseInt(sentimentScore, 10);
        const isWithinRange = value >= 0 && value <= 100;

        cy.wrap(isWithinRange).should('be.true');
      });

    supportHub
      .supportHubAttentionScoreLabel()
      .invoke('text')
      .then((attentionScore) => {
        const value = parseInt(attentionScore, 10);
        const isWithinRange = value >= 0 && value <= 100;

        cy.wrap(isWithinRange).should('be.true');
      });
  });

  /**
   * C6436
   * - In the opened SupportHub , Verify the display of Health score
   */
  it('C6436: Verify the display of AHS in SupportHub', { tags: ['AHS'] }, () => {
    healthScore.healthScoreBadgeIcon().first().invoke('attr', 'class').should('include', 'AHSBadge');
    healthScore
      .healthScoreBadgeIcon()
      .first()
      .invoke('text')
      .should('not.be.empty')
      .then((ahsValue) => {
        expect(parseInt(ahsValue, 10)).lessThan(100);
      });
  });
});
