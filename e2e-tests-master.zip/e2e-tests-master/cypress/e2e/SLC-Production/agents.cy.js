import { urlHelpers } from '../../utils';
import { apiHelpers, agentInsights, commonElements, consolePage, supportHub } from '../../pages';

describe('Agent Insights Production Tests', () => {
  /**
   * - Login and navigate to the Agent Insights page
   * - Enter the agent name and verify the Individual Agent checkbox is displaying as checked (beforeEach)
   * - Verify the entered agent name is displaying in the search field (beforeEach)
   */
  before(function beforeHook() {
    cy.loginWithOktaUI();
    apiHelpers.isModuleEnabled('agents').then((isEnabled) => {
      if (!isEnabled) this.skip();
    });
    cy.visit(urlHelpers.agentInsights.home);
    cy.slcHelpers.getDetailsOfAgentsWithCases().then((agentDetails) => {
      const agentDetail = Cypress._.sample(agentDetails);
      cy.waitForLoaders();
      commonElements.clickWelcomePageGetStartedButton();
      agentInsights.agentInsightsSearchFieldInput().clear().type(agentDetail.sl_name);
      agentInsights.expandFilterButton().click();
      agentInsights.filterByType('Individual Agent');
      agentInsights.agentSearchResultListNameLabel().should('contain', agentDetail.sl_name).click();
      agentInsights.agentNameLabel().should('have.text', agentDetail.sl_name);
    });
  });

  /**
   * C9253
   * - Click on the Open case tab and verify the tab count
   * - If case count is not 0cases, verify the backlog and Case Distribution widget are displaying else check no cases found text is displaying
   */
  it('C9253: Validate data present in agent insights details tab [ Open cases tab ]', { tags: 'Agents' }, () => {
    cy.waitForLoaders();
    agentInsights.agentOpenCasesCountTab().eq(0).click();
    cy.waitForLoaders();
    agentInsights.agentOpenCasesCountTab().then((count) => {
      const openCase = count.text();
      if (openCase !== '0cases') {
        agentInsights.caseDetails().should('contain', 'Backlog');
        agentInsights.caseDetails().should('contain', 'Case Distribution');
        agentInsights.agentInsightsOpenCaseList().eq(0).click();
        cy.waitForLoaders();
        supportHub.baseContainer().should('be.visible');
        supportHub.closeButton().click({ force: true });
      } else {
        agentInsights.caseDetails().should('contain', 'No cases found');
      }
    });
  });

  /**
   * C9252
   * - Click on the Closed case tab and verify the tab count
   * - If case count is not 0cases, Validate Graph are visible else check no cases found text is displaying
   */
  it('C9252: Validate data present in agent insights details tab [ Closed cases tab ]', { tags: 'Agents' }, () => {
    cy.waitForLoaders();
    agentInsights.agentClosedCasesCountTab().eq(0).click();
    cy.waitForLoaders();
    agentInsights.agentClosedCasesCountTab().then((count) => {
      const openCase = count.text();
      if (openCase !== '0cases') {
        agentInsights.closedCaseTabStatusChartWrapper().should('exist');
        agentInsights.closedCaseTabPriorityChartWrapper().should('exist');
        agentInsights.closedCaseTabResponseTimeChartWrapper().should('exist');
        agentInsights.closedCaseTabCaseAgeChartWrapper().should('exist');
      } else {
        agentInsights.caseDetails().should('contain', 'No cases found');
      }
    });
  });

  /**
   * C9254
   * - Click on the Negative Sentiment tab and verify the tab count
   * - If case count is not 0cases, verify Open a ticket in Supporthub else check no cases found text is displaying
   */
  it('C9254: Validate data present in agent insights details tab [ Negative sentiments tab ]', { tags: 'Agents' }, () => {
    cy.waitForLoaders();
    agentInsights.getTabsByName('Negative Sentiments').first().click();
    consolePage.negativeSentimentsTabCount().then((count) => {
      const openCase = count.text();
      if (openCase !== '0signals') {
        cy.waitForLoaders();
        consolePage.groupedByDropdown().eq(0).click();
        cy.contains('Priority').click();
        cy.waitForLoaders();
        consolePage.caseCard().eq(0).click();
        cy.waitForLoaders();
        supportHub.baseContainer().should('be.visible');
        supportHub.closeButton().click();
      } else {
        agentInsights.caseDetails().should('contain', 'No cases found');
      }
    });
  });

  /**
   * C9255
   * - Click on the Positive sentiments tab and verify the tab count
   * - If case count is not 0cases, verify Open a ticket in Supporthub else check no cases found text is displaying
   */
  it('C9255: Validate data present in agent insights details tab [ Positive sentiments tab ]', { tags: 'Agents' }, () => {
    cy.waitForLoaders();
    agentInsights.getTabsByName('Positive sentiments').first().click();
    consolePage.positiveSentimentsTabCount().then((count) => {
      const openCase = count.text();
      if (openCase !== '0signals') {
        cy.waitForLoaders();
        consolePage.groupedByDropdown().eq(0).click();
        cy.contains('Priority').click();
        cy.waitForLoaders();
        consolePage.caseCard().eq(0).click();
        cy.waitForLoaders();
        supportHub.baseContainer().should('be.visible');
        supportHub.closeButton().click();
      } else {
        agentInsights.caseDetails().should('contain', 'No cases found');
      }
    });
  });

  /**
   * C9256
   * - Click on the Need Attention tab and verify the tab count
   * - If case count is not 0cases, verify Open a ticket in Supporthub else check no cases found text is displaying
   */
  it('C9256: Validate data present in agent insights details tab [ Need Attention tab ]', { tags: 'Agents' }, () => {
    cy.waitForLoaders();
    agentInsights.getTabsByName('Need Attention').first().click();
    cy.waitForLoaders();
    agentInsights.agentNeedAttentionTabCaseCount().then((count) => {
      const openCase = count.text();
      if (openCase !== '0signals') {
        cy.waitForLoaders();
        consolePage.groupedByDropdown().eq(0).click();
        cy.contains('Priority').click();
        cy.waitForLoaders();
        consolePage.caseCard().eq(0).click();
        cy.waitForLoaders();
        supportHub.baseContainer().should('be.visible');
        supportHub.closeButton().click();
      } else {
        agentInsights.caseDetails().should('contain', 'No cases found');
      }
    });
  });

  /**
   * C9257
   * - Click on the Engineering Issues tab and verify the tab count
   * - If case count is not 0cases, verify charts are visible else check no cases found text is displaying
   */
  it('C9257: Validate data present in agent insights details tab [ Engineering Issues tab ]', { tags: 'Agents' }, () => {
    cy.waitForLoaders();
    agentInsights.getTabsByName('Engineering Issues').first().click();
    consolePage.engineeringIssuesTabCount().then((count) => {
      const openCase = count.text();
      if (openCase !== '0cases') {
        cy.waitForLoaders();
        agentInsights.engineeringIssuesChartsContainer().should('exist');
        agentInsights.engineeringIssuesEntitiesChartWrapper().should('exist');
        agentInsights.engineeringIssuesStatusChartWrapper().should('exist');
        agentInsights.engineeringIssuesPriorityChartWrapper().should('exist');
      } else {
        agentInsights.caseDetails().should('contain', 'No cases found');
      }
    });
  });

  /**
   * C9258
   * - Click on the Product Feedback tab and verify the tab count
   * - If case count is not 0cases, verify Open a ticket in Supporthub else check no cases found text is displaying
   */
  it('C9258: Validate data present in agent insights details tab [ Product Feedback tab ]', { tags: 'Agents' }, () => {
    cy.waitForLoaders();
    agentInsights.getTabsByName('Product Feedback').first().click();
    consolePage.productFeedbackTabCount().then((count) => {
      const openCase = count.text();
      if (openCase !== '0signals') {
        cy.waitForLoaders();
        consolePage.groupedByDropdown().eq(0).click();
        cy.contains('Priority').click();
        cy.waitForLoaders();
        consolePage.caseCard().eq(0).click();
        cy.waitForLoaders();
        supportHub.baseContainer().should('be.visible');
        supportHub.closeButton().click();
      } else {
        agentInsights.caseDetails().should('contain', 'No cases found');
      }
    });
  });

  /**
   * C9259
   * - Click on the Escalations tab and verify the tab count
   * - If case count is not 0cases, verify Open a ticket in Supporthub else check no cases found text is displaying
   */
  it('C9259: Validate data present in agent insights details tab [ New Escalations tab ]', { tags: 'Agents' }, () => {
    cy.waitForLoaders();
    agentInsights.getTabsByName('New Escalations').first().click();
    consolePage.newEscalationsTabCount().then((count) => {
      const openCase = count.text();
      if (openCase !== '0cases') {
        cy.waitForLoaders();
        consolePage.groupedByDropdown().eq(0).click();
        cy.contains('Priority').click();
        cy.waitForLoaders();
        consolePage.escalationCaseCard().eq(0).click();
        cy.waitForLoaders();
        supportHub.baseContainer().should('be.visible');
        supportHub.closeButton().click();
      } else {
        agentInsights.caseDetails().should('contain', 'No cases found');
      }
    });
  });

  /**
   * C9250
   * -  Verify the agent Insight page is with search option visible.
   */
  it('C9250: Go to agent insights page', { tags: 'Agents' }, () => {
    cy.visit(urlHelpers.agentInsights.home);
    cy.waitForLoaders();
    agentInsights.agentInsightsSearchFieldInput().should('be.visible');
    agentInsights.agentInsightsSearchFieldInput().invoke('attr', 'placeholder').should('equal', 'Agent name');
  });
});
