import { urlHelpers } from '../../utils';
import { apiHelpers, alertsPage, commonElements } from '../../pages';

describe('Alerts Production Tests', () => {
  before(function beforeHook() {
    cy.loginWithOktaUI();
    apiHelpers.isModuleEnabled('alerts').then((isEnabled) => {
      if (!isEnabled) this.skip();
    });
    cy.visit(urlHelpers.alerts);
    cy.waitForLoaders();
    commonElements.clickWelcomePageGetStartedButton();
  });

  /**
   * C9264
   * - If alert page is empty,Create a new Alert button should be visible in the middle of the page
   * - if the alert page have atleast one alert, validate : Mute button, Duplicate button, Delete button and New Alert button are visible
   */
  it('C9264: Go to Alerts', { tags: 'Alerts' }, () => {
    cy.waitForLoaders();
    commonElements.appWrapper().then(($parentDiv) => {
      if ($parentDiv.find('[data-testid="alert--AlertsNavigationList--item"]').length > 0) {
        alertsPage.createNewAlertButton().scrollIntoView().should('be.visible');
        alertsPage
          .alertsNavigationList()
          .eq(0)
          .then(($listItem) => {
            if ($listItem.find('[data-testid="alert-alertsNavigationList-muteButton"]').length > 0) {
              alertsPage.alertMuteButton().scrollIntoView().should('be.visible');
              alertsPage.alertsNavigationListMuteButton().eq(0).should('be.visible');
            } else {
              alertsPage.alertUnMuteButton().scrollIntoView().should('be.visible');
              alertsPage.alertsNavigationListUnmuteButton().eq(0).should('be.visible');
            }
          });
        alertsPage.duplicateAlertButton().scrollIntoView().should('be.visible');
        alertsPage.deleteAlertButton().scrollIntoView().should('be.visible');
      } else {
        alertsPage.alertsZeroStateCreateButton().should('be.visible');
        alertsPage.createNewAlertButton().should('be.visible');
        commonElements.appWrapper().invoke('text').should('contain', 'You don’t have any alerts at this time!');
      }
    });
  });

  /**
   * C9282
   * - If alert page is empty,Create a new Alert button should be visible in the middle of the page
   * - if the alert page have atleast one alert,alert conditions are listed and expand view of the alert conditions.
   */
  it('C9282: Alerts - Display of "Alert Conditions"', { tags: 'Alerts' }, () => {
    cy.waitForLoaders();
    commonElements.appWrapper().then(($parentDiv) => {
      if ($parentDiv.find('[data-testid="alert--AlertsNavigationList--item"]').length > 0) {
        alertsPage.createNewAlertButton().scrollIntoView().should('be.visible');
        alertsPage.alertConditionsHeaderTitle().should('contain', 'Alert Conditions');
        alertsPage
          .alertConditionDropDown()
          .eq(0)
          .then(($signals) => {
            const signalName = $signals.text();
            alertsPage.alertConditionDropDown().eq(0).scrollIntoView().should('be.visible').click();
            alertsPage.alertConditionDropdownOptionLabel(signalName).eq(0).should('be.visible');
            alertsPage.alertConditionDropDown().eq(0).scrollIntoView().click();
            alertsPage.alertConditionDropdownOptionLabel(signalName).should('not.exist');
          });
      } else {
        alertsPage.alertsZeroStateCreateButton().should('be.visible');
        alertsPage.createNewAlertButton().should('be.visible');
        commonElements.appWrapper().invoke('text').should('contain', 'You don’t have any alerts at this time!');
      }
    });
  });
});
