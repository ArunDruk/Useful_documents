import { urlHelpers } from '../../utils';
import { apiHelpers, kpiMetrics } from '../../pages';

describe('KPI Metrics Production Tests', () => {
  before(function beforeHook() {
    cy.loginWithOktaUI();
    apiHelpers.isModuleEnabled('kpiMetrics').then((isEnabled) => {
      if (!isEnabled) this.skip();
    });
    cy.visit(urlHelpers.kpiMetrics);
  });

  /**
   * C9247
   * - Response Time KPI, verify the pie chart, SLA Bar Chart, SLA Met Target details are displaying
   */
  it('C9247: KPI Metrics - Response time chart', { tags: 'Operational Metrics' }, () => {
    kpiMetrics.summaryCard().should('contain', 'Response Time');
    kpiMetrics.pieChartBackground('sla').should('exist');
    kpiMetrics.barChartBackground('sla').should('exist');
    kpiMetrics.metTargetChartLabel('sla').should('exist');
    // kpiMetrics.metTargetChartLabel('sla').should('not.have.text','0%met target')
  });

  /**
   * C9248
   * - Efficiency KPI, verify the pie chart, SLA Bar Chart, SLA Met Target details are displaying
   */
  it('C9248: KPI Metrics - Efficiency chart', { tags: 'Operational Metrics' }, () => {
    kpiMetrics.summaryCard().should('contain', 'Efficiency');
    kpiMetrics.pieChartBackground('Efficiency').should('exist');
    kpiMetrics.barChartBackground('Efficiency').should('exist');
    kpiMetrics.metTargetChartLabel('Efficiency').should('exist');
  });

  /**
   * C9249
   * - Customer experience KPI, verify the pie chart, SLA Bar Chart, SLA Met Target details are displaying
   */
  it('C9249: KPI Metrics - Customer experience chart', { tags: 'Operational Metrics' }, () => {
    kpiMetrics.summaryCard().should('contain', 'Customer Experience');
    kpiMetrics.pieChartBackground('Customer Experience').should('exist');
    kpiMetrics.barChartBackground('Customer Experience').should('exist');
    kpiMetrics.metTargetChartLabel('Customer Experience').should('exist');
  });
});
