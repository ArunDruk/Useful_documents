import { apiHelpers, commonElements, datePicker, escalationReport, filters, supportHub } from '../../pages';
import { urlHelpers } from '../../utils';

describe('Escalation Report Production Tests', () => {
  before(function beforeHook() {
    cy.loginWithOktaUI();
    apiHelpers.isModuleEnabled('escalationsReport').then((isEnabled) => {
      if (!isEnabled) this.skip();
    });
    cy.visit(urlHelpers.escalationReport);
    cy.waitForLoaders();
    commonElements.clickWelcomePageGetStartedButton();
  });

  /**
   * C2314
   * - Verify the display of the 15 columns that can be reordered but cannot be removed
   */
  it('C2314: Verify the display of standard column in Escalation List View', { tags: 'Escalations' }, () => {
    escalationReport.commonTableHeader('Customer').invoke('text').should('contain', 'Customer Name');
    escalationReport.commonTableHeader('Customer').find('[data-testid="ahs-badge"]').should('exist');
    escalationReport.commonTableHeader().should('contain', 'Reporter');
    escalationReport.commonTableHeader().should('contain', 'Case Status');
    escalationReport.commonTableHeader().should('contain', 'Escalation Status');
    escalationReport.commonTableHeader().should('contain', 'Escalated at');
    escalationReport.commonTableHeader().should('contain', 'Likely to Escalate First Predicted at');
    escalationReport.commonTableHeader().should('contain', 'Likely to Escalate Last Predicted at');
    escalationReport.commonTableHeader().should('contain', 'Case Priority');
    escalationReport.commonTableHeader().should('contain', 'Engineering Bugs');
    escalationReport.commonTableHeader().should('contain', 'Case Owner');
    escalationReport.commonTableHeader().should('contain', 'Viewed by');
    escalationReport.commonTableHeader().should('contain', 'Last Response');
    escalationReport.commonTableHeader().should('contain', 'Open for (Case Age)');
    escalationReport.commonTableHeader().should('contain', 'Days spent in the escalated state');
    escalationReport.commonTableHeader().should('contain', 'Days to escalation');
  });

  /**
   * C9279
   * - Verify the Filter, Settings icon, datepicker and  Export CSV button are displayed
   * - Verify the Customer Name column are displaying
   */
  it('C9279: Validate Escalation Reports page is displayed', { tags: 'Escalations' }, () => {
    filters.addDynamicFilterButton().should('exist');
    escalationReport.escalationsValueMetricsNavIcon().should('exist');
    datePicker.datePickerTrigger().should('exist');
    escalationReport.exportAsCsvButton().should('exist');
    escalationReport.commonTableHeader('Customer').invoke('text').should('contain', 'Customer Name');
  });

  /**
   * C9280
   * - Click on the CaseId from the Table and verify the SupportHub is opened and the CaseId is same
   */
  it('C9280: Escalation Reports cases should open in SupportHub', { tags: 'Escalations' }, () => {
    escalationReport
      .commonTableRowCaseIdLabel()
      .eq(0)
      .then((caseId) => {
        // escalationReport.commonTableRowCaseIdLabel()
        escalationReport.commonTableRowCaseIdLabel().eq(0).scrollIntoView().click();
        cy.waitForLoaders();
        supportHub.caseIdLabel().invoke('text').should('be.equal', caseId.text());
        supportHub.closeButton().click();
      });
  });

  /**
   * C9281
   * - Click on Escalation Value Metrics Icon
   * - Verify Escalation Value Metrics report Exec Tab displaying with Show closed cases toggle and Datepicker
   * - Verify Escalation Value Metrics report Manager Tab displaying with Agent filter button, Show closed cases toggle and Datepicker
   */
  it('C9281: [Escalation Reports] Verify the display of Escalation Value Metrics', { tags: 'Escalations' }, () => {
    escalationReport.escalationsValueMetricsNavIcon().click();
    cy.waitForLoaders();
    escalationReport.escalationValueMetricsContainer().should('exist');
    escalationReport.escalationValueMetricsTab().eq(0).invoke('text').should('contain', 'Escalation Value Metrics report Exec');
    escalationReport.escalationValueMetricsTab().eq(0).click();
    cy.waitForLoaders();
    escalationReport.escalationValueMetricsShowClosedCasesToggle().should('exist');
    datePicker.datePickerTrigger().should('exist');
    escalationReport.escalationValueMetricsTab().eq(1).invoke('text').should('contain', 'Escalation Value Metrics report Manager');
    escalationReport.escalationValueMetricsTab().eq(1).click();
    cy.waitForLoaders();
    escalationReport.escalationValueMetricsShowClosedCasesToggle().should('exist');
    datePicker.datePickerTrigger().should('exist');
    escalationReport.escalationValueMetricsAgentFilterButton().should('exist');
    escalationReport.escalationPageGoBackButton().click();
  });

  /**
   * C2315
   * - Hover over the i icon in the 'Escalation status' column header
   * - Verify the tooltip is visible with the below text, A case can have one of the following escalation statuses:
   * Escalated - The ticket is an active escalation
   * Escalation Request - An escalation request was made from the customer side or from your company side
   * Escalation Request[Declined] - Someone Declined this request (by clicking the Decline button)
   * Likely to Escalate - The ticket is currently likely to escalate (predicted by SupportLogic!)
   * Likely to Escalate (Disagreed) - Someone disagreed with this prediction (by clicking the Disagree button)
   * Likely to Escalate (Snoozed) - Someone snoozed this prediction (by clicking the Snooze button)
   * Likely to Escalate(Acknowledged) - Someone acknowledged this prediction (by clicking the Acknowledge button)
   * Resolved - The ticket is resolved
   */
  it('C2315: should verify escalation status info icon tooltip', { tags: ['staging'] }, () => {
    escalationReport.commonTableHeaderInfoIcon('Escalation Status').trigger('mouseover');
    escalationReport.escalationStatusTooltip().should('be.visible');
    escalationReport.escalationStatusTooltipTitle().should('be.visible').and('contain', 'A case can have one of the following escalation statuses:');
    escalationReport.escalationStatusTooltipRow().should('be.visible').and('have.length', 8);
    escalationReport.escalationStatusTooltipRow().eq(0).should('contain', 'Escalated').and('contain', 'The case is an active escalation');
    escalationReport
      .escalationStatusTooltipRow()
      .eq(1)
      .should('contain', 'Escalation Request')
      .and('contain', 'An escalation request was made from the customer side or from your company side');
    escalationReport
      .escalationStatusTooltipRow()
      .eq(2)
      .should('contain', 'Escalation Request')
      .and('contain', '(Declined)')
      .and('contain', 'Someone declined this request (by clicking the Decline button)');
    escalationReport
      .escalationStatusTooltipRow()
      .eq(3)
      .should('contain', 'Likely to Escalate')
      .and('contain', 'The case is currently likely to escalate (predicted by SupportLogic!)');
    escalationReport
      .escalationStatusTooltipRow()
      .eq(4)
      .should('contain', 'Likely to Escalate')
      .and('contain', '(Disagreed)')
      .and('contain', 'Someone disagreed with this prediction (by clicking the Disagree button)');
    escalationReport
      .escalationStatusTooltipRow()
      .eq(5)
      .should('contain', 'Likely to Escalate')
      .and('contain', '(Snoozed)')
      .and('contain', 'Someone snoozed this prediction (by clicking the Snooze button)');
    escalationReport
      .escalationStatusTooltipRow()
      .eq(6)
      .should('contain', 'Likely to Escalate')
      .and('contain', '(Acknowledged)')
      .and('contain', 'Someone acknowledged this prediction (by clicking the Acknowledge button)');
    escalationReport.escalationStatusTooltipRow().eq(7).should('contain', 'Resolved').and('contain', 'The case is resolved');
  });
});
