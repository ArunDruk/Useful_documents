import { urlHelpers } from '../../utils';
import { apiHelpers, commonElements, customerInsights, consolePage, trends, supportHub } from '../../pages';

describe('Text Analytics Production Tests', () => {
  before(function beforeHook() {
    cy.loginWithOktaUI();
    apiHelpers.isModuleEnabled('trends').then((isEnabled) => {
      if (!isEnabled) this.skip();
    });
    cy.visit(urlHelpers.trends);
    cy.waitForLoaders();
    commonElements.clickWelcomePageGetStartedButton();
  });

  afterEach(() => {
    cy.get('#trends--search--select').then(($parentDiv) => {
      if ($parentDiv.find('[data-testid="trends-search-select-value"]').length > 0) {
        trends.clearSearchButton().scrollIntoView().click();
      }
    });
  });
  /**
   * C9269
   * - If Overview tab count > 0, Validate the display of charts, groupBy Value in All Cases
   */
  it('C9269: Validate that count > 0 for Overview', { tags: ['Trends'] }, () => {
    trends.overviewTab().scrollIntoView().click();
    cy.waitForLoaders();
    customerInsights.tabCaseCountLabel('Overview').then(($count) => {
      const caseCount = $count.text();
      if (caseCount !== '0cases') {
        cy.waitForLoaders();
        trends.overviewChartPriorityWrapper().should('exist');
        trends.overviewChartStatusWrapper().should('exist');
        trends.groupByDropdownTrigger().then(($option) => {
          const groupbyValue = $option.text();
          trends.chartLegendCardHeaderLabel().should('have.text', groupbyValue);
        });
        trends.overviewCommonChartElements().first().click({ force: true });
        cy.waitForLoaders();
        consolePage.unassignedCaseCardLists().eq(0).should('be.visible').click();
        cy.waitForLoaders();
        supportHub.baseContainer().should('be.visible');
        supportHub.closeButton().click();
      }
    });
  });

  /**
   * C9317
   * - If Escalations tab count > 0, Validate the display of charts, groupBy Value in All Cases
   */
  it('C9317: Validate that count > 0 for Escalations', { tags: ['Trends'] }, () => {
    trends.escalationsTab().scrollIntoView().click();
    cy.waitForLoaders();
    customerInsights.tabCaseCountLabel('Escalations').then(($count) => {
      const caseCount = $count.text();
      if (caseCount !== '0cases') {
        cy.waitForLoaders();
        trends.overviewChartPriorityWrapper().should('exist');
        trends.overviewChartStatusWrapper().should('exist');
        trends.groupByDropdownTrigger().then(($option) => {
          const groupbyValue = $option.text();
          trends.chartLegendCardHeaderLabel().should('have.text', groupbyValue);
        });
        trends.overviewCommonChartElements().first().click({ force: true });
        cy.waitForLoaders();
        consolePage.unassignedCaseCardLists().eq(0).should('be.visible').click();
        cy.waitForLoaders();
        supportHub.baseContainer().should('be.visible');
        supportHub.closeButton().click();
      }
    });
  });

  /**
   * C9318
   * - If Negative Sentiments tab count > 0, Open a ticket in Supporthub else check no tickets found text is displaying
   */
  it('C9318: Validate that count > 0 for Negative Sentiments', { tags: ['Trends'] }, () => {
    trends.negativeSentimentsTab().scrollIntoView().click();
    cy.waitForLoaders();
    customerInsights.tabCaseCountLabel('Negative Sentiments').then(($count) => {
      const caseCount = $count.text();
      if (caseCount !== '0signals') {
        cy.waitForLoaders();
        consolePage.sentimentTabgroupByPriorityOption();
        cy.waitForLoaders();
        consolePage.caseCard().eq(0).click();
        cy.waitForLoaders();
        supportHub.baseContainer().should('be.visible');
        supportHub.closeButton().click();
      } else {
        commonElements.zeroStateContainer().invoke('text').should('contain', 'No tickets, try expanding your filter options');
      }
    });
  });

  /**
   * C9322
   * - If Positive Sentiments tab count > 0, Open a ticket in Supporthub else check no tickets found text is displaying
   */
  it('C9322: Validate that count > 0 for Positive Sentiments', { tags: ['Trends'] }, () => {
    trends.positiveSentimentsTab().scrollIntoView().click();
    cy.waitForLoaders();
    customerInsights.tabCaseCountLabel('Positive Sentiments').then(($count) => {
      const caseCount = $count.text();
      if (caseCount !== '0signals') {
        cy.waitForLoaders();
        consolePage.sentimentTabgroupByPriorityOption();
        cy.waitForLoaders();
        consolePage.caseCard().eq(0).click();
        cy.waitForLoaders();
        supportHub.baseContainer().should('be.visible');
        supportHub.closeButton().click();
      } else {
        commonElements.zeroStateContainer().invoke('text').should('contain', 'No tickets, try expanding your filter options');
      }
    });
  });

  /**
   * C9323
   * - If Need attention tab count > 0, Open a ticket in Supporthub else check no tickets found text is displaying
   */
  it('C9323: Validate that count > 0 for Need Attention', { tags: ['Trends'] }, () => {
    trends.needAttentionTab().scrollIntoView().click();
    cy.waitForLoaders();
    customerInsights.tabCaseCountLabel('Need Attention').then(($count) => {
      const caseCount = $count.text();
      if (caseCount !== '0signals') {
        cy.waitForLoaders();
        consolePage.sentimentTabgroupByPriorityOption();
        cy.waitForLoaders();
        cy.waitForLoaders();
        consolePage.caseCard().eq(0).click();
        cy.waitForLoaders();
        supportHub.baseContainer().should('be.visible');
        supportHub.closeButton().click();
      } else {
        commonElements.zeroStateContainer().invoke('text').should('contain', 'No tickets, try expanding your filter options');
      }
    });
  });

  /**
   * C9324
   * - If Product Feedback tab count > 0, Open a ticket in Supporthub else check no tickets found text is displaying
   */
  it('C9324: Validate that count > 0 for Product Feedback', { tags: ['Trends'] }, () => {
    trends.productFeedbackTab().scrollIntoView().click();
    cy.waitForLoaders();
    customerInsights.tabCaseCountLabel('Product Feedback').then(($count) => {
      const caseCount = $count.text();
      if (caseCount !== '0signals') {
        cy.waitForLoaders();
        consolePage.sentimentTabgroupByPriorityOption();
        cy.waitForLoaders();
        consolePage.caseCard().eq(0).click();
        cy.waitForLoaders();
        supportHub.baseContainer().should('be.visible');
        supportHub.closeButton().click();
      } else {
        commonElements.zeroStateContainer().invoke('text').should('contain', 'No tickets, try expanding your filter options');
      }
    });
  });

  /**
   * C9327
   * - Select a Keywords from the list and validate the display of tickets based on the Keywords
   */
  it('C9327: Search for keyword from the list and validate the display of tickets', { tags: ['Trends'] }, () => {
    cy.waitForLoaders();
    trends.searchKeywordDropdownListButton().click();
    trends
      .searchKeywordsOptionActiveList()
      .eq(0)
      .then(($OptionName) => {
        const keyword = $OptionName.text().split('Meta')[0];
        const metaKeyword = `Meta${keyword}`;
        trends.searchKeywordsOptionActiveList().eq(0).click();
        trends.searchKeywordDropdownListButton().click();
        trends.searchTextField().type('{enter}');
        cy.waitForLoaders();
        trends.currentlySearchedTextChips().invoke('text').should('contain', metaKeyword);
        trends.mainChartSearchedTextChips().invoke('text').should('contain', metaKeyword);
        trends.chartLegendCardHeaderLabel().invoke('text').should('contain', keyword);
        trends.chartLegendItems().invoke('text').should('contain', keyword);
        trends.overviewTab().scrollIntoView().click();
        cy.waitForLoaders();
        trends.topEntityListItem().invoke('text').should('contain', keyword);
        trends.clearSearchButton().click();
      });
  });

  /**
   * C9325
   * - Search for free text like ""help"" and validate the display of tickets based on the given text
   */
  it('C9325:Search for free text like ""help"" and validate the display of tickets', { tags: ['Trends'] }, () => {
    cy.waitForLoaders();
    const freeText = 'Support';
    trends.searchForKeyword(freeText);
    cy.waitForLoaders();
    trends.currentlySearchedTextChips().should('exist');
    trends.mainChartSearchedTextChips().invoke('text').should('contain', freeText);
    trends.overviewTab().scrollIntoView().click();
    cy.waitForLoaders();
    cy.waitForLoaders();
    customerInsights.tabCaseCountLabel('Overview').invoke('text').should('not.contain', '0cases');
    // customerInsights.tabCaseCountLabel('Overview').invoke('text').should('not.contain', '');
    customerInsights.tabCaseCountLabel('Overview').then(($count) => {
      const caseCount = $count.text();
      if (caseCount !== '0cases') {
        cy.waitForLoaders();
        trends.overviewChartPriorityWrapper().should('exist');
        trends.overviewChartStatusWrapper().should('exist');
        // verify the chart points are displaying in loaded chart
        trends.overviewCommonChartElements().should('exist');
      }
    });
  });
});
