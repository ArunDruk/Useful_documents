import { apiHelpers, escalations, commonElements } from '../../pages';
import { labelHelper, urlHelpers } from '../../utils';

describe('Escalation Board Production Tests', () => {
  before(function beforeHook() {
    cy.loginWithOktaUI();
    apiHelpers.isModuleEnabled('escalationsBoard').then((isEnabled) => {
      if (!isEnabled) this.skip();
    });
    cy.visit(urlHelpers.escalationBoard);
    cy.waitForLoaders();
    commonElements.clickWelcomePageGetStartedButton();
  });

  /**
   * C9244
   * - Validate the display of 3 columns for LTE, Esc request and Active escalation
   * - Validate the Likely escalate count is greater than zero.
   */
  it('C9244: Verify Escalation Board Column Count', { tags: 'Escalations' }, () => {
    escalations.lteContainer().should('be.visible');
    escalations.escalationRequestsContainer().should('be.visible');
    escalations.activeEscalationsContainer().should('be.visible');
    escalations
      .lteContainerHeader()
      .invoke('text')
      .then(($lteHeader) => {
        expect($lteHeader).not.to.eq('0Likely to Escalate');
      });
  });

  /*
   * Hover over the i icon in the LTE header
   * Verify tooltip is displayed with the expected text
   */
  it('C261: should verify LTE column info icon tooltip', { tags: 'Escalations' }, () => {
    const caseLabel = labelHelper.cases.toLowerCase();
    const expectedTooltipText = `Among the eligible prediction ${caseLabel} (i.e., ${caseLabel} that have been open for more than 12 hours but less than 30 days), the ${caseLabel} identified in this column have been predicted as "Likely to Escalate".`;

    escalations.lteHeaderInfoIcon().trigger('mouseover');
    escalations.lteInfoIconTooltip().should('be.visible').and('have.text', expectedTooltipText);
  });
});
