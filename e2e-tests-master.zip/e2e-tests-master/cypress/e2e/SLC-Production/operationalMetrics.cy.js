import { urlHelpers } from '../../utils';
import { apiHelpers, commonElements, datePicker, metrics } from '../../pages';

describe('Operational Metrics Production Tests', () => {
  before(function beforeHook() {
    cy.loginByApi();
    // cy.loginWithOktaUI();
    apiHelpers.isModuleEnabled('operationalMetrics').then((isEnabled) => {
      if (!isEnabled) this.skip();
    });
    cy.visit(urlHelpers.operationalMetrics.home);
    cy.waitForLoaders();
  });

  /**
   * C9245
   * - Validate the URL, page title, calender widget and add a chart button are displaying
   */
  it('C9245: Validate the display of the "Operational Metrics" page with the "Efficiency" and "Response Time" metrics', { tags: 'Operational Metrics' }, () => {
    cy.url().should('include', '/operational-metrics');
    commonElements.appWrapper().invoke('text').should('contain', 'Operational Metrics');
    metrics.opsMetricsContainer().should('exist');
    datePicker.datePickerTrigger().should('exist');
    metrics.addChartButton().should('be.visible');
  });

  it('C9265: Validate the display of the graph in the Escalations tab', { tags: 'Operational Metrics' }, () => {
    metrics.escalationSubTab().click();
    cy.waitForLoaders();
    metrics.escalationSubTab().invoke('attr', 'data-active').should('eq', 'true');
    metrics.escalationsTitle().eq(0).should('have.text', 'Escalations');
    metrics.activeEscalationCountLabel().should('be.visible');
    metrics.activeEscalationPercantageLabel().should('be.visible');
    metrics.opsMetricsDownloadButton().should('exist');
    metrics.opsMetricsThreeDotButton().should('exist');
  });

  it('C9266: Validate the display of the graph in the backlog tab', { tags: 'Operational Metrics' }, () => {
    metrics.backlogSubTab().click();
    cy.waitForLoaders();
    metrics.backlogSubTab().invoke('attr', 'data-active').should('eq', 'true');
    metrics.escalationsTitle().eq(0).should('have.text', 'Backlog');
    metrics.activeEscalationCountLabel().should('be.visible');
    metrics.activeEscalationPercantageLabel().should('be.visible');
    metrics.opsMetricsDownloadButton().should('exist');
    metrics.opsMetricsThreeDotButton().should('exist');
  });

  it('C9267: Validate the display of the graph in the Case Activity tab', { tags: 'Operational Metrics' }, () => {
    metrics.caseActivitySubTab().click();
    cy.waitForLoaders();
    metrics.caseActivitySubTab().invoke('attr', 'data-active').should('eq', 'true');
    metrics.chartBackground().should('exist');
    metrics.opsMetricsSentimentsCount().should('exist');
    metrics.opsMetricsDropdownValue().should('exist');
  });

  it('C9268: Validate the display of the graph in First Response tab', { tags: 'Operational Metrics' }, () => {
    metrics.firstResponseSubTab().click();
    cy.waitForLoaders();
    metrics.firstResponseSubTab().invoke('attr', 'data-active').should('eq', 'true');
    metrics.responseTimeDefaultChartTitle().eq(0).should('have.text', 'First Response Time');
    metrics.opsMetricsDownloadButton().should('exist');
    metrics.opsMetricsThreeDotButton().should('exist');
    metrics.opsMetricsSentimentsCount().should('exist');
    metrics.opsMetricsDropdownValue().should('exist');
  });

  it('C9270: Validate the display of the graph in Follow-up tab', { tags: 'Operational Metrics' }, () => {
    metrics.followUpSubTab().click();
    cy.waitForLoaders();
    metrics.followUpSubTab().invoke('attr', 'data-active').should('eq', 'true');
    metrics.responseTimeDefaultChartTitle().eq(0).should('have.text', 'Follow-up Time');
    metrics.opsMetricsDownloadButton().should('exist');
    metrics.opsMetricsThreeDotButton().should('exist');
    metrics.opsMetricsSentimentsCount().should('exist');
    metrics.opsMetricsDropdownValue().should('exist');
  });

  it('C9271: Validate the display of the graph in Case Resolution tab', { tags: 'Operational Metrics' }, () => {
    metrics.caseResolutionSubTab().click();
    cy.waitForLoaders();
    metrics.caseResolutionSubTab().invoke('attr', 'data-active').should('eq', 'true');
    metrics.responseTimeDefaultChartTitle().eq(0).should('have.text', 'Case Resolution Time');
    metrics.opsMetricsDownloadButton().should('exist');
    metrics.opsMetricsThreeDotButton().should('exist');
    metrics.opsMetricsSentimentsCount().should('exist');
    metrics.opsMetricsDropdownValue().should('exist');
  });
});
