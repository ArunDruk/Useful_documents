import { urlHelpers } from '../../utils';
import { apiHelpers, commonElements, virtualAccount } from '../../pages';

describe('Virtual Accounts Production Tests', () => {
  before(function beforeHook() {
    cy.loginWithOktaUI();
    apiHelpers.isModuleEnabled('virtualAccounts').then((isEnabled) => {
      if (!isEnabled) this.skip();
    });
    cy.visit(urlHelpers.virtualAccounts);
    cy.waitForLoaders();
    commonElements.clickWelcomePageGetStartedButton();
  });

  /**
   * C9314
   * - Navigate to the virtual account page in beforeEach
   * - Verify the Create button,search field and filter button for virtual Account are displaying
   * - Verify the Create button for virtual Group is displaying
   */
  it('C9314: Validate the display of "Virtual accounts" page', { tags: ['Virtual Accounts'] }, () => {
    cy.waitForLoaders();
    virtualAccount.createVaButton().scrollIntoView().should('be.visible');
    virtualAccount.searchVaNameInput().scrollIntoView().should('be.visible');
    virtualAccount.vaFilterTrigger().scrollIntoView().should('be.visible');
    virtualAccount.virtualGroupCreateButton().scrollIntoView().should('be.visible');
  });
});
