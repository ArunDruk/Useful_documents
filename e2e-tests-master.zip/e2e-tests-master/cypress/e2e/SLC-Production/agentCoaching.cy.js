import { urlHelpers } from '../../utils';
import { acePage, apiHelpers, commonElements } from '../../pages';

describe('Agent Coaching Production Tests', () => {
  before(function beforeHook() {
    cy.loginWithOktaUI();
    apiHelpers.isModuleEnabled('manualQA').then((isEnabled) => {
      if (!isEnabled) this.skip();
    });
    cy.visit(urlHelpers.caseEvaluation);
    cy.waitForLoaders();
    commonElements.clickWelcomePageGetStartedButton();
  });

  /**
   * C9294
   * - Verify the visibility of the below 4 columns - Recommended, To review, In progress and Recently reviewed
   */
  it('C9294: [Agent Coaching] Verify the display of columns in Recmmendations tab', { tags: 'Ace' }, function favoriteCustomerList() {
    cy.waitForLoaders();
    acePage.recommendedContainer().should('exist').and('contain', 'Recommended');
    acePage.toReviewContainer().should('exist').and('contain', 'To review');
    acePage.inProgressContainer().should('exist').and('contain', 'In progress');
    acePage.recentlyReviewedContainer().should('exist').and('contain', 'Recently reviewed');
  });
});
