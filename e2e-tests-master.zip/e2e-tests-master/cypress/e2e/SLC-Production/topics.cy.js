import { urlHelpers } from '../../utils';
import { apiHelpers, commonElements, topics } from '../../pages';
import { setStatusAsPrimaryTopic, setPriorityAsSecondaryTopic } from '../SLC/topics/support';

describe('Trend Analytics (Topics) Production Tests', () => {
  before(function beforeHook() {
    cy.loginWithOktaUI();
    apiHelpers.isModuleEnabled('topics').then((isEnabled) => {
      if (!isEnabled) this.skip();
    });
    cy.visit(urlHelpers.topics);
    cy.waitForLoaders();
    commonElements.clickWelcomePageGetStartedButton();
    setStatusAsPrimaryTopic();
    setPriorityAsSecondaryTopic();
  });

  /**
   * C9315
   * - Validate the display of 2 topics section
   */
  it('C9315: Topics - Validate that the case count is > 0', { tags: ['Topics'] }, () => {
    cy.waitForLoaders();
    topics.topicsHeaderTicketCount().invoke('text').should('not.equal', '0');
  });

  /**
   * C9316
   * - Validate the display of 2 topics section
   */
  it('C9316: Validate the display of 2 topics section', { tags: ['Topics'] }, () => {
    cy.waitForLoaders();
    topics.topicsFirstTopicDropdown().find('input').eq(0).invoke('attr', 'value').should('not.be.empty');
    topics.topicsSecondTopicDropdown().find('input').eq(0).invoke('attr', 'value').should('not.be.empty');
  });
});
