import { apiHelpers, assignmentQueues, commonElements } from '../../pages';
import { urlHelpers } from '../../utils';

describe('Assignment Queues Production Tests', () => {
  before(function beforeHook() {
    cy.loginWithOktaUI();
    apiHelpers.isModuleEnabled('virtualQueues').then((isEnabled) => {
      if (!isEnabled) this.skip();
    });
    cy.visit(urlHelpers.assignmentQueues);
    cy.waitForLoaders();
    commonElements.clickWelcomePageGetStartedButton();
  });

  /**
   * C9343
   * - The assignment queue page must load with the url /support/virtual-queues
   * - Default team section and Backlog Breakdown section are exist.
   * - Add a CRM Queue and Add a Virtual Queue buttons are visible.
   */
  it('C9343: Validate the display of "Assignment Queues" page', { tags: 'ICA' }, () => {
    cy.url().should('include', '/support/virtual-queues');
    assignmentQueues.assignmentQueueSettingsContainer().contains('Default Team');
    assignmentQueues.assignmentQueueSettingsContainer().contains('Backlog Breakdown');
    assignmentQueues.addCrmQueueButton().scrollIntoView().should('be.visible');
    assignmentQueues.addVirtualQueueButton().scrollIntoView().should('be.visible');
  });
});
