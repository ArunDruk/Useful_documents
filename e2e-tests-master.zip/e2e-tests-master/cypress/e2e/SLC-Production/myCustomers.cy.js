import { urlHelpers } from '../../utils';
import { apiHelpers, commonElements, customerFavorites } from '../../pages';

describe('My Customers Production Tests', () => {
  before(function beforeHook() {
    cy.loginWithOktaUI();
    apiHelpers.isModuleEnabled('myCustomers').then((isEnabled) => {
      if (!isEnabled) this.skip();
    });
    cy.visit(urlHelpers.myCustomers);
    apiHelpers.removeAllFavoriteCustomers();
    cy.slcHelpers.getCustomerDetails().then((customerDetails) => {
      const customerDetail = Cypress._.sample(customerDetails);
      cy.wrap(customerDetail).as('customerDetail');
    });
    cy.waitForLoaders();
    commonElements.clickWelcomePageGetStartedButton();
  });

  after(() => {
    apiHelpers.removeAllFavoriteCustomers();
  });

  /**
   * C9262
   * - Verify "My customers" page should be displayed with "Add a favorite" button.
   * - Add a customers as Favourite and verify the added customers is displaying
   * - Remove the customers from Favorite at the end (afterEach)
   */
  it('C9262: Validate the display of "My customers" page with "Add a favorite" and "Export to CSV" button', { tags: 'My Customers' }, function favoriteCustomerList() {
    cy.waitForLoaders();
    customerFavorites.addFavoriteButton().should('exist');
    customerFavorites.favoritesExportButton().should('exist');
    customerFavorites.addFavoriteButton().click();
    customerFavorites.searchFor(this.customerDetail.name);
    customerFavorites.searchResultsListItem().should('be.visible').and('have.length.at.least', 1).first().should('have.text', this.customerDetail.name).click();
    cy.waitForLoaders();
    customerFavorites.favoritesTableCustomerNameLabel().should('have.text', this.customerDetail.name);
  });
});
