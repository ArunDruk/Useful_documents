import { urlHelpers } from '../../utils';
import { apiHelpers, consolePage, commonElements } from '../../pages';

describe('Console Production Tests', () => {
  before(function beforeHook() {
    cy.loginWithOktaUI();
    apiHelpers.isModuleEnabled('console').then((isEnabled) => {
      if (!isEnabled) this.skip();
    });
    cy.visit(urlHelpers.console.home);
    cy.waitForLoaders();
    commonElements.clickWelcomePageGetStartedButton();
  });

  /**
   * C9422
   * - Navigate to the console page in beforeEach
   * - Click on the New Escalatio tab
   * - Select the Last 7 days in filter dropdown, Verify the Footer text
   * - Select the Yesterday in filter dropdown, Verify the Footer text
   * - Select the Today in filter dropdown, Verify the Footer text
   */
  it('C9422: Checking the feature of footer text in the New Escalations tab', { tags: 'Console' }, () => {
    cy.waitForLoaders();
    // Last 7 days
    consolePage.timeFilterButton().click().contains('Last 7 days').click();
    cy.waitForLoaders();
    consolePage.newEscalationsTab().click();
    cy.waitForLoaders();
    consolePage.newEscalationsTab().invoke('text').should('include', 'the previous 7 days');
    // Since yesterday
    consolePage.timeFilterButton().click().contains('Since yesterday').click();
    cy.waitForLoaders();
    consolePage.newEscalationsTab().invoke('text').should('include', 'the previous days');
    // Today
    consolePage.timeFilterButton().click().contains('Today').click();
    cy.waitForLoaders();
    consolePage.newEscalationsTab().invoke('text').should('include', 'yesterday');
  });

  /**
   * C9238
   * - Navigate to the console page in beforeEach
   * - Click on the New Escalatio tab
   * - Select the Last 7 days in filter dropdown,
   */
  it('C9238: Validate data present in New Escalations tab (Last 7 days time filter)', { tags: 'Console' }, () => {
    cy.waitForLoaders();
    // Last 7 days
    consolePage.timeFilterButton().click().contains('Last 7 days').click();
    cy.waitForLoaders();
    consolePage.newEscalationsTab().click();
    cy.waitForLoaders();
    consolePage.consoleEscalatedTabHeaderTitle().invoke('text').should('contain', `Escalations`);
    consolePage
      .newEscalationsTabCount()
      .then(($count) => Number($count.text().replace('cases', '').replace('case', '')))
      .should('be.gt', 0);
  });

  /**
   * C9423
   * - Navigate to the console page in beforeEach
   * - Click on the Likely to Escalate tab
   * - Select the Last 7 days in filter dropdown, Verify the Footer text
   * - Select the Yesterday in filter dropdown, Verify the Footer text
   * - Select the Today in filter dropdown, Verify the Footer text
   */
  it('C9423: Checking the feature of footer text in the Likely To Escalate tab', { tags: 'Console' }, () => {
    cy.waitForLoaders();
    // Last 7 days
    consolePage.timeFilterButton().click().contains('Last 7 days').click();
    cy.waitForLoaders();
    consolePage.newEscalationsTab().click();
    cy.waitForLoaders();
    consolePage.newEscalationsTab().invoke('text').should('include', 'the previous 7 days');
    // Since yesterday
    consolePage.timeFilterButton().click().contains('Since yesterday').click();
    cy.waitForLoaders();
    consolePage.newEscalationsTab().invoke('text').should('include', 'the previous days');
    // Today
    consolePage.timeFilterButton().click().contains('Today').click();
    cy.waitForLoaders();
    consolePage.newEscalationsTab().invoke('text').should('include', 'yesterday');
  });

  /*
   * Log in and load the console page
   * Select "Last 7 days" in the time filter
   * Click the positive sentiments tab
   * Validate case count in the tab is > 0
   * Validate case card is visible
   */
  it('C9239: Validate data present in Positive Sentiments tab (Last 7 days time filter)', { tags: 'Console' }, () => {
    consolePage.timeFilterButton().click().contains('Last 7 days').click();
    cy.waitForLoaders();
    consolePage
      .positiveSentimentsTabCount()
      .then(($count) => Number($count.text().replace('signals', '').replace('signal', '')))
      .should('be.gt', 0);
    consolePage.positiveSentimentsTab().scrollIntoView().click({ force: true });
    cy.waitForLoaders();
    consolePage.sentimentTabgroupByPriorityOption();
    cy.waitForLoaders();
    consolePage.caseCard().eq(0).should('be.visible');
  });

  /*
   * Log in and load the console page
   * Select "Last 7 days" in the time filter
   * Click the negative sentiments tab
   * Validate case count in the tab is > 0
   * Validate case card is visible
   */
  it('C9240: Validate data present in Negative Sentiments tab (Last 7 days time filter)', { tags: 'Console' }, () => {
    consolePage.timeFilterButton().click().contains('Last 7 days').click();
    cy.waitForLoaders();
    consolePage
      .negativeSentimentsTabCount()
      .then(($count) => Number($count.text().replace('signals', '').replace('signal', '')))
      .should('be.gt', 0);
    consolePage.negativeSentimentsTab().scrollIntoView().click({ force: true });
    cy.waitForLoaders();
    consolePage.sentimentTabgroupByPriorityOption();
    cy.waitForLoaders();
    consolePage.caseCard().eq(0).should('be.visible');
  });

  /*
   * Click the need attention tab
   * Validate case count in the tab is > 0, Validate case card is visible
   */
  it('C9241: Validate data present in Need Attention tab (Last 7 days time filter)', { tags: 'Console' }, () => {
    consolePage.timeFilterButton().click().contains('Last 7 days').click();
    cy.waitForLoaders();
    consolePage
      .needAttentionTabCaseCount()
      .then(($count) => Number($count.text().replace('signals', '').replace('signal', '')))
      .should('be.gt', 0);
    consolePage.needAttentionTab().scrollIntoView().click({ force: true });
    cy.waitForLoaders();
    consolePage.sentimentTabgroupByPriorityOption();
    cy.waitForLoaders();
    consolePage.caseCard().eq(0).should('be.visible');
  });

  /*
   * Log in and load the console page
   * Select "Last 7 days" in the time filter
   * Click the product feedback tab
   * Validate case count in the tab is > 0
   * Validate case card is visible
   */
  it('C9242: Validate data present in Product Feedback tab (Last 7 days time filter)', { tags: 'Console' }, () => {
    consolePage.timeFilterButton().click().contains('Last 7 days').click();
    cy.waitForLoaders();
    consolePage
      .productFeedbackTabCount()
      .then(($count) => Number($count.text().replace('signals', '').replace('signal', '')))
      .should('be.gt', 0);
    consolePage.productFeedbackTab().scrollIntoView().click({ force: true });
    cy.waitForLoaders();
    consolePage.sentimentTabgroupByPriorityOption();
    cy.waitForLoaders();
    consolePage.caseCard().eq(0).should('be.visible');
  });

  /**
   * C41
   * - Navigate to the console page in beforeEach
   * - Click on the Product Feedback tab
   * - Select the Last 7 days in filter dropdown, Verify the Footer text
   * - Select the Yesterday in filter dropdown, Verify the Footer text
   * - Select the Today in filter dropdown, Verify the Footer text
   */
  it('C41: Checking the feature of footer text in the Product Feedback tab', { tags: 'Console' }, () => {
    cy.waitForLoaders();
    // Last 7 days
    consolePage.timeFilterButton().click().contains('Last 7 days').click();
    cy.waitForLoaders();
    consolePage.productFeedbackTab().click();
    cy.waitForLoaders();
    consolePage.productFeedbackTab().invoke('text').should('include', 'the previous 7 days');
    // Since yesterday
    consolePage.timeFilterButton().click().contains('Since yesterday').click();
    cy.waitForLoaders();
    consolePage.productFeedbackTab().invoke('text').should('include', 'the previous days');
    // Today
    consolePage.timeFilterButton().click().contains('Today').click();
    cy.waitForLoaders();
    consolePage.productFeedbackTab().invoke('text').should('include', 'yesterday');
  });
});
