import { urlHelpers } from '../../utils';
import { apiHelpers, backlogPage, commonElements, globalFilters, globalSearch, supportHub } from '../../pages';

describe('Backlog Production Tests', () => {
  before(function beforeHook() {
    cy.loginWithOktaUI();
    apiHelpers.isModuleEnabled('cases').then((isEnabled) => {
      if (!isEnabled) this.skip();
    });
    cy.visit(urlHelpers.backlog);
    commonElements.appWrapper().then(($parentDiv) => {
      if ($parentDiv.find('[data-testid="module-common-welcome-page-container"]').length > 0) {
        backlogPage.welcomePageDefaultListButton().should('be.visible').click();
      }
    });
  });

  after(() => {
    cy.slcHelpers.clearCustomersQuickFilter();
  });

  it('C9263: verify case board correct url', { tags: 'Backlog' }, () => {
    cy.url().should('include', '/cases');
    commonElements.appWrapper().then(($parentDiv) => {
      if ($parentDiv.find('[data-testid="module-common-welcome-page-container"]').length > 0) {
        backlogPage.welcomePageCreateCustomListButton().should('exist');
      } else {
        backlogPage.createNewListButton().should('exist');
        backlogPage.backlogCustomerCaseList().should('exist');
      }
    });
  });

  it('C9286: View the list in the normal view (Not expanded) and close', { tags: 'Backlog' }, () => {
    cy.waitForLoaders();
    backlogPage.backlogCustomerCaseList().eq(0).click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    supportHub.closeButton().click();
  });

  it('C9287: Open a ticket in normal view(Not expanded) and check the navigation to next ticket', { tags: 'Backlog' }, () => {
    cy.waitForLoaders();
    backlogPage.backlogCustomerCaseList().eq(0).click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    supportHub.breadcrumbContent().then((breadcrumb) => {
      const firstbreadcrumb = breadcrumb.text();
      supportHub.breadcrumbScrollRightButton().should('be.visible');
      supportHub.breadcrumbScrollLeftButton().should('not.be.visible');
      supportHub.breadcrumbScrollRightButton().click();
      cy.waitForLoaders();
      supportHub.breadcrumbScrollLeftButton().should('be.visible');
      supportHub.breadcrumbContent().invoke('text').should('not.contain', firstbreadcrumb);
    });
    supportHub.closeButton().click();
  });

  it('C9288: Click on sort direction in the normal view (Not expanded)', { tags: 'Backlog' }, () => {
    cy.waitForLoaders();
    backlogPage.verifyListSortOrder();
  });

  it('C9311: Case Board - Validate the edit workflow', { tags: 'Backlog' }, () => {
    cy.waitForLoaders();
    backlogPage.createNewList();
    backlogPage.verifyListEditFLow();
  });

  it('C9312: Case Board - Validate the Delete workflow', { tags: 'Backlog' }, () => {
    cy.waitForLoaders();
    backlogPage.createNewList();
    backlogPage.deleteBacklogList();
  });

  it('C9289: Validate the list expand button shows.', { tags: 'Backlog' }, () => {
    cy.waitForLoaders();
    backlogPage.expandButton().should('be.visible');
  });

  it('C9283: Case Board - "View the list in the expanded view and close "', { tags: 'Backlog' }, () => {
    cy.waitForLoaders();
    backlogPage.expandButton().eq(0).click();
    cy.waitForLoaders();
    backlogPage.expandedListCloseIcon().should('be.visible');
    backlogPage.expandedListCloseIcon().click();
    backlogPage.expandedListCloseIcon().should('not.exist');
  });

  it('C9284: Open a ticket in Expanded view and check the navigation to next ticket', { tags: 'Backlog' }, () => {
    cy.waitForLoaders();
    backlogPage.expandButton().eq(0).click();
    cy.waitForLoaders();
    backlogPage.expandedListPopupCustomerCaseList().should('be.visible');
    backlogPage.expandedListPopupCustomerCaseList().eq(0).click({ force: true });
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    supportHub.breadcrumbContent().then((breadcrumb) => {
      const firstbreadcrumb = breadcrumb.text();
      supportHub.breadcrumbScrollRightButton().should('be.visible');
      supportHub.breadcrumbScrollLeftButton().should('not.be.visible');
      supportHub.breadcrumbScrollRightButton().click();
      cy.waitForLoaders();
      supportHub.breadcrumbScrollLeftButton().should('be.visible');
      supportHub.breadcrumbContent().invoke('text').should('not.contain', firstbreadcrumb);
    });
    supportHub.closeButton().click();
    cy.waitForLoaders();
    backlogPage.expandedListCloseIcon().click();
  });

  it('C9285: Click on sort direction in the expanded view', { tags: 'Backlog' }, () => {
    cy.waitForLoaders();
    backlogPage.expandButton().eq(0).click();
    cy.waitForLoaders();
    backlogPage
      .expandedListPopupCaseIdLabel()
      .eq(0)
      .then((buttonText) => {
        const customerNameBeforeSorted = buttonText.text();
        backlogPage.expandedListthreeDotMenuDropdown().eq(0).should('be.visible').click({ force: true });
        backlogPage.expandedListswitchSortButton().eq(0).should('be.visible').click({ force: true });
        cy.waitForLoaders();
        backlogPage
          .expandedListPopupCaseIdLabel()
          .eq(0)
          .then((buttonTextAfterSort) => {
            const customerNameAfterSorted = buttonTextAfterSort.text();
            expect(customerNameAfterSorted).to.not.equal(customerNameBeforeSorted);
          });
      });
    cy.waitForLoaders();
    backlogPage.expandedListCloseIcon().click();
  });

  /**
   * C9340
   * - Click on a Case Card and pick the caseId from the SupportHub, Close the Supporthub
   * - Click on the global search icon and enter the CaseId, Verify the same CaseId is displaying in the search result
   */
  it('C9340: Validate the display of ticket when searched via global search textbox', { tags: 'Filters' }, () => {
    cy.waitForLoaders();
    backlogPage.backlogCustomerCaseList().eq(0).click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    supportHub.caseIdLabel().then(($caseId) => {
      const caseId = $caseId.text();
      supportHub.closeButton().click();
      cy.waitForLoaders();
      globalSearch.globalSearchButton().click();
      globalSearch.globalSearchInput().clear().type(caseId);
      cy.waitForLoaders();
      globalSearch.globalSearchResultListItem().should('be.visible').and('contain', caseId);
      globalSearch.globalSearchInput().clear();
      // Click backlog title to close the global search popup
      backlogPage.listFullTitleNameLabel().eq(0).click({ force: true });
    });
  });

  /**
   * C9341
   * - Click on a Case Card and pick the customerName from the SupportHub, Close the Supporthub
   * - Select the Customer in quickfilter and verify the backlog case list is displaying with same CustomerName
   * - Clear the selected Customer from quickfilter once verified
   */
  it('C9341: Validate data are displayed as per the filter (any agent/customer/custom field)', { tags: 'Filters' }, () => {
    cy.waitForLoaders();
    backlogPage.backlogCustomerCaseList().eq(0).click();
    cy.waitForLoaders();
    supportHub.baseContainer().should('be.visible');
    supportHub.caseCustomerNameLabel().then(($custName) => {
      const customerName = $custName.text();
      supportHub.closeButton().click();
      cy.waitForLoaders();
      globalFilters.selectCustomerInQuickFilter(customerName);
      cy.waitForLoaders();
      backlogPage.backlogListCustomerName().should('contain', customerName);
      globalFilters.quickFilterCustomerLink().click();
      globalFilters.quickFilterCustomerClearAllLink().click();
      globalFilters.filterApplyButton().should('be.visible').click();
      globalFilters.filterButton().click();
    });
  });
});
