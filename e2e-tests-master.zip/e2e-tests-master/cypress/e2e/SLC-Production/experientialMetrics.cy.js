import { urlHelpers } from '../../utils';
import { apiHelpers, commonElements, datePicker, experientialMetrics, filters } from '../../pages';

describe('Experiental Metrics Production Tests', () => {
  before(function beforeHook() {
    cy.loginWithOktaUI();
    apiHelpers.isModuleEnabled('experientialMetrics').then((isEnabled) => {
      if (!isEnabled) this.skip();
    });
    cy.visit(urlHelpers.experientialMetrics.home);
    cy.waitForLoaders();
  });

  /**
   * C9246
   * - Validate the URL, page title, calender widget and add a chart button are displaying
   */
  it('C9246: Validate the display of the "Experiential Metrics" page with "Customer experience" and "Sentiments"', { tags: 'Operational Metrics' }, () => {
    cy.url().should('include', '/experiential-metrics');
    commonElements.appWrapper().invoke('text').should('contain', 'Experiential Metrics');
    experientialMetrics.experientialMetricsTabs().should('exist');
    experientialMetrics.customerExperienceSubTab().should('exist').and('have.text', 'Customer experience');
    experientialMetrics.sentimentsSubTab().should('exist').and('have.text', 'Sentiments');
    datePicker.datePickerTrigger().should('exist');
    experientialMetrics.addChartButton().should('be.visible');
  });

  /**
   * C9308
   * - Validate the URL, signal dropdown and its values and charts with data are displaying
   */
  it('C9308: Validate the display of the graph in the Customer experience tab', { tags: 'Operational Metrics' }, () => {
    experientialMetrics.customerExperienceSubTab().click();
    cy.waitForLoaders();
    cy.url().should('include', '/experiential-metrics/customerExperience');
    experientialMetrics.customerExperienceSubTab().invoke('attr', 'data-active').should('eq', 'true');
    experientialMetrics.sentimentSignalsDropdownTrigger().should('exist').click();
    experientialMetrics.chartGroupByDropdownOption().should('contain', 'Created');
    experientialMetrics.chartGroupByDropdownOption().should('contain', 'Closed');
    experientialMetrics.chartGroupByDropdownOption().should('contain', 'in the Open State');
    experientialMetrics.chartLabels().should('exist');
    experientialMetrics.chartBarPoints().should('exist');
  });

  /**
   * C9310
   * - Validate the Url, Includes Checkbox, Chart Legend type, Case Status filter and charts with data are displaying
   */
  it('C9310:Validate the display of the sentiments graph/card in the "Sentiments" tab', { tags: 'Operational Metrics' }, () => {
    experientialMetrics.sentimentsSubTab().click();
    cy.waitForLoaders();
    commonElements.clickWelcomePageGetStartedButton();
    cy.waitForLoaders();
    cy.url().should('include', '/experiential-metrics/sentiments');
    experientialMetrics.sentimentsSubTab().invoke('attr', 'data-active').should('eq', 'true');
    // Includes checkbox
    experientialMetrics.sentimentIncludesCheckBox('Incoming').should('exist');
    experientialMetrics.sentimentIncludesCheckBox('Outgoing').should('exist');
    experientialMetrics.sentimentIncludesCheckBox('CaseNote').should('exist');
    // Chart Legend Type
    experientialMetrics.sentimentChartLegentType('negative').should('exist');
    experientialMetrics.sentimentChartLegentType('positive').should('exist');
    experientialMetrics.sentimentChartLegentType('product feedback').should('exist');
    // Case Status filter
    filters.allCaseStatusFilterButton().should('exist');
    filters.openCaseStatusFilterButton().should('exist');
    filters.closedCaseStatusFilterButton().should('exist');
    // Chart Data
    experientialMetrics.chartLabels().should('exist');
    experientialMetrics.chartBarPoints().should('exist');
  });

  /**
   * C9309
   * - Validate the positive sentiment count > 0, validate the negative count > 0
   */
  it('C9309:Validate the positive sentiment count > 0, validate the negative count > 0', { tags: 'Operational Metrics' }, () => {
    experientialMetrics.sentimentsSubTab().click();
    cy.waitForLoaders();
    commonElements.clickWelcomePageGetStartedButton();
    cy.waitForLoaders();
    experientialMetrics.sentimentChartLegentType('negative').should('exist').and('not.contain.text', '0Negative sentiments');
    experientialMetrics.sentimentChartLegentType('positive').should('exist').and('not.contain.text', '0Positive sentiments');
  });
});
