import { navBar, preferences } from '../../pages';

describe('SFDC DataSync Production Tests', () => {
  before(function beforeHook() {
    cy.loginWithOktaUI();
    cy.visit(Cypress.config().baseUrl);
  });

  /**
   * C6433
   * - Click on the user menu and verify the data sync colour should be Green
   * - Verify the Data Sync status is not displaying in the Navigation bar.
   */
  it('C6433: Check of Data sync is happening from CRM', { tags: 'SFDC Sync' }, () => {
    cy.waitForLoaders();
    preferences.userMenuButton().click();
    preferences.dataSyncStatus().should('have.css', 'background-color').and('eq', 'rgb(133, 210, 111)');
    navBar.dataSyncStatus().should('not.exist');
  });
});
