import { urlHelpers } from '../../utils';
import { apiHelpers, commonElements, lmvTeamPage } from '../../pages';

describe('My Dashboard Production Tests', () => {
  before(function beforeHook() {
    cy.loginWithOktaUI();
    apiHelpers.isModuleEnabled('summary').then((isEnabled) => {
      if (!isEnabled) this.skip();
    });
    cy.visit(urlHelpers.myDashboard);
    cy.waitForLoaders();
    commonElements.clickWelcomePageGetStartedButton();
  });

  /**
   * C9236
   * - If Primary Team is set,Validate 'Add a card' button is visible
   * - If Primary Team is not set, Validate "You haven't chosen a team yet" message is displayed with a link to the virtual teams page
   */
  it('C9236: Go to My Dashboad page', { tags: 'My Dashboard' }, function favoriteAgentList() {
    cy.waitForLoaders();
    commonElements.appWrapper().then(($parentDiv) => {
      if ($parentDiv.find('[data-testid="caseBoard--floating-action-button"]').length > 0) {
        lmvTeamPage.addCardButton().should('be.visible');
      } else {
        lmvTeamPage.verifyWelcomePage();
      }
    });
  });
});
