import { urlHelpers } from '../../utils';
import { apiHelpers, commonElements, virtualTeam } from '../../pages';

describe('Virtual Teams Production Tests', () => {
  before(function beforeHook() {
    cy.loginWithOktaUI();
    apiHelpers.isModuleEnabled('virtualTeams').then((isEnabled) => {
      if (!isEnabled) this.skip();
    });
    cy.visit(urlHelpers.virtualTeams);
    cy.waitForLoaders();
    commonElements.clickWelcomePageGetStartedButton();
  });

  /**
   * C9313
   * - Navigate to the virtual team page in beforeEach
   * - Verify the Page title, Create button of virtual orgs, virtual team are displaying
   * - Verify the virtual team search field and filter button are displaying
   */
  it('C9313: Validate the display of "Virtual teams" page', { tags: ['Virtual Team'] }, () => {
    cy.waitForLoaders();
    virtualTeam.virtualTeamPageTitleLabel().should('contain', 'Virtual Orgs');
    virtualTeam.createVirtualOrgsButton().scrollIntoView().should('be.visible');
    virtualTeam.virtualTeamPageTitleLabel().should('contain', 'Virtual Teams');
    virtualTeam.createVirtualTeamButton().scrollIntoView().should('be.visible');
    virtualTeam.searchVirtualTeamInput().scrollIntoView().should('be.visible');
    virtualTeam.vtFilterTrigger().scrollIntoView().should('be.visible');
  });
});
