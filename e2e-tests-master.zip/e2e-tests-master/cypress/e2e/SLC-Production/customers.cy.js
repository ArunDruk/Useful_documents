import { urlHelpers } from '../../utils';
import { apiHelpers, agentInsights, commonElements, consolePage, customerInsights, healthScore, supportHub } from '../../pages';

describe('Customer Insights Production Tests', () => {
  let custName = '';
  before(function beforeHook() {
    cy.loginWithOktaUI();
    apiHelpers.isModuleEnabled('customerInsights').then((isEnabled) => {
      if (!isEnabled) this.skip();
    });
    apiHelpers.getCustomerDetailsWithHealthScore('0', '99').then((customerDetails) => {
      const customerDetail = Cypress._.sample(customerDetails);
      custName = customerDetail.name;
      cy.visit(urlHelpers.customerInsights.home);
      cy.waitForLoaders();
      commonElements.clickWelcomePageGetStartedButton();
      customerInsights.searchTextfield().clear().type(customerDetail.name).wait(2000).type('{enter}');
    });
  });

  /**
   * C9339
   * - Validate that the customer name should be the same and share option also visible and clickable
   * - Validate Score health score pop is shown
   */
  it('C9339: Validate display of AHS window', { tags: ['AHS'] }, () => {
    cy.waitForLoaders();
    // Navigate to the Health Score Page
    customerInsights.healthScoreTab().click();
    cy.waitForLoaders();
    // Validating the customer name in Health Score page
    healthScore.healthScoreTitleHeader().invoke('text').should('contain', custName);
    healthScore.ahsCaseListHeaderTitle().should('exist');
    // Validating the health score popup share
    healthScore.healthScoreShareIcon().scrollIntoView().click();
    healthScore.ahsShareFormBaseContainer().should('exist');
    healthScore.ahsShareImageCheckbox().should('exist');
    healthScore.ahsShareHealthScoreLinkCheckbox().should('exist');
    supportHub.sharePopupEmailButton().should('exist');
    healthScore.ahsShareMessageTextArea().should('exist');
    healthScore.ahsShareButton().should('exist');
    healthScore.healthScoreShareIcon().scrollIntoView().click();
  });

  /**
   * C9272
   * - Navigate to the Insight page and click on Overview tab
   * - If Overview tab count is >0, Open a ticket in Supporthub from the Recent cases section
   */
  it('C9272: Validate data present in client insights details tab [ Overview tab ]', { tags: ['Customers'] }, () => {
    cy.waitForLoaders();
    // Navigate to the Insights Page
    customerInsights.insightsTab().click();
    cy.waitForLoaders();
    customerInsights.commonTabCard('Overview').eq(1).scrollIntoView().click();
    customerInsights.tabCaseCountLabel('Overview').then(($count) => {
      const caseCount = $count.text();
      if (caseCount !== '0cases') {
        cy.waitForLoaders();
        customerInsights.overviewTabRecentlyClosedTab().should('be.visible').click();
        cy.waitForLoaders();
        customerInsights.overviewTabCaseListItem().eq(0).should('be.visible').click();
        cy.waitForLoaders();
        supportHub.baseContainer().should('be.visible');
        supportHub.closeButton().click();
        cy.waitForLoaders();
      } else {
        customerInsights.insightSubTabDataViewContainer().should('contain', 'No cases found');
      }
    });
  });

  /**
   * C9273
   * - Navigate to the Insight page and click on New Escalation tab
   * - If New Escalation tab count is >0, Open a ticket in Supporthub else check no cases found text is displaying
   */
  it('C9273: Validate data present in client insights details tab [New Escalations tab ]', { tags: ['Customers'] }, () => {
    cy.waitForLoaders();
    // Navigate to the Insights Page
    customerInsights.insightsTab().click();
    cy.waitForLoaders();
    customerInsights.commonTabCard('New Escalations').eq(1).scrollIntoView().click();
    customerInsights.tabCaseCountLabel('New Escalations').then(($count) => {
      const caseCount = $count.text();
      if (caseCount !== '0cases') {
        cy.waitForLoaders();
        consolePage.groupedByDropdown().eq(0).click();
        cy.contains('Priority').click();
        cy.waitForLoaders();
        consolePage.escalationCaseCard().eq(0).should('be.visible').click();
        cy.waitForLoaders();
        supportHub.baseContainer().should('be.visible');
        supportHub.closeButton().click();
      } else {
        customerInsights.insightSubTabDataViewContainer().should('contain', 'No cases found');
      }
    });
  });

  /**
   * C6508
   * - Click on the Escalation tab and then verify the AHS Icon is displaying and score below 100
   */
  it('C6508: AHS_Verify the display of AHS in escalation card in customer insight page.', { tags: ['AHS'] }, () => {
    cy.waitForLoaders();
    customerInsights.commonTabCard('New Escalations').last().scrollIntoView().click({ force: true });
    consolePage.groupedByDropdown().eq(0).click();
    cy.contains('Priority').click();
    cy.waitForLoaders();
    consolePage.caseCardScoreBadgeAhsIcon().first().invoke('attr', 'class').should('include', 'AHSBadge');
    consolePage
      .caseCardScoreBadgeAhsIcon()
      .first()
      .invoke('text')
      .should('not.be.empty')
      .then((ahsValue) => {
        expect(parseInt(ahsValue, 10)).lessThan(100);
      });
  });

  /**
   * C9274
   * - Navigate to the Insight page and click on Negative sentiments tab
   * - If Negative sentiments tab count is >0, Open a ticket in Supporthub else check no cases found text is displaying
   */
  it('C9274: Validate data present in client insights details tab [ Negative sentiments tab ]', { tags: ['Customers'] }, () => {
    cy.waitForLoaders();
    // Navigate to the Insights Page
    customerInsights.insightsTab().click();
    cy.waitForLoaders();
    customerInsights.commonTabCard('Negative Sentiments').eq(1).scrollIntoView().click();
    customerInsights.tabCaseCountLabel('Negative Sentiments').then(($count) => {
      const caseCount = $count.text();
      if (caseCount !== '0signals') {
        cy.waitForLoaders();
        consolePage.groupedByDropdown().eq(0).click();
        cy.contains('Priority').click();
        cy.waitForLoaders();
        consolePage.caseCard().eq(0).click();
        cy.waitForLoaders();
        supportHub.baseContainer().should('be.visible');
        supportHub.closeButton().click();
      } else {
        customerInsights.insightSubTabDataViewContainer().should('contain', 'No cases found');
      }
    });
  });

  /**
   * C9275
   * - Navigate to the Insight page and click on Engineering Issues tab
   * - If Engineering Issues tab count is >0, Verify the charts are visible else check no cases found text is displaying
   */
  it('C9275: Validate data present in client insights details tab [ Engineering Issues tab ]', { tags: ['Customers'] }, () => {
    cy.waitForLoaders();
    // Navigate to the Insights Page
    customerInsights.insightsTab().click();
    cy.waitForLoaders();
    customerInsights.commonTabCard('Engineering Issues').eq(1).scrollIntoView().click();
    customerInsights.tabCaseCountLabel('Engineering Issues').then(($count) => {
      const caseCount = $count.text();
      if (caseCount !== '0cases') {
        cy.waitForLoaders();
        agentInsights.engineeringIssuesChartsContainer().should('exist');
        agentInsights.engineeringIssuesEntitiesChartWrapper().should('exist');
        agentInsights.engineeringIssuesStatusChartWrapper().should('exist');
        agentInsights.engineeringIssuesPriorityChartWrapper().should('exist');
      } else {
        customerInsights.insightSubTabDataViewContainer().should('contain', 'No cases found');
      }
    });
  });

  /**
   * C9276
   * - Navigate to the Insight page and click on Product Feedback tab
   * - If Product Feedback tab count is >0, Open a ticket in Supporthub else check no cases found text is displaying
   */
  it('C9276: Validate data present in client insights details tab [ Product Feedback tab ]', { tags: ['Customers'] }, () => {
    cy.waitForLoaders();
    // Navigate to the Insights Page
    customerInsights.insightsTab().click();
    cy.waitForLoaders();
    customerInsights.commonTabCard('Product Feedback').eq(1).scrollIntoView().click();
    customerInsights.tabCaseCountLabel('Product Feedback').then(($count) => {
      const caseCount = $count.text();
      if (caseCount !== '0signals') {
        cy.waitForLoaders();
        consolePage.groupedByDropdown().eq(0).click();
        cy.contains('Priority').click();
        cy.waitForLoaders();
        consolePage.caseCard().eq(0).click();
        cy.waitForLoaders();
        supportHub.baseContainer().should('be.visible');
        supportHub.closeButton().click();
      } else {
        customerInsights.insightSubTabDataViewContainer().should('contain', 'No cases found');
      }
    });
  });

  /**
   * C9277
   * - Navigate to the Insight page and click on Need Attention tab
   * - If Need Attention tab count is >0, Open a ticket in Supporthub else check no cases found text is displaying
   */
  it('C9277: Validate data present in client insights details tab [ Need Attention tab ]', { tags: ['Customers'] }, () => {
    cy.waitForLoaders();
    // Navigate to the Insights Page
    customerInsights.insightsTab().click();
    cy.waitForLoaders();
    customerInsights.commonTabCard('Need Attention').eq(1).scrollIntoView().click();
    customerInsights.tabCaseCountLabel('Need Attention').then(($count) => {
      const caseCount = $count.text();
      if (caseCount !== '0signals') {
        cy.waitForLoaders();
        consolePage.groupedByDropdown().eq(0).click();
        cy.contains('Priority').click();
        cy.waitForLoaders();
        consolePage.caseCard().eq(0).click();
        cy.waitForLoaders();
        supportHub.baseContainer().should('be.visible');
        supportHub.closeButton().click();
      } else {
        customerInsights.insightSubTabDataViewContainer().should('contain', 'No cases found');
      }
    });
  });

  /**
   * C9278
   * - Navigate to the Insight page and click on Positive sentiments tab
   * - If Positive sentiments tab count is >0, Open a ticket in Supporthub else check no cases found text is displaying
   */
  it('C9278: Validate data present in client insights details tab [ Positive sentiments tab ]', { tags: ['Customers'] }, () => {
    cy.waitForLoaders();
    // Navigate to the Insights Page
    customerInsights.insightsTab().click();
    cy.waitForLoaders();
    customerInsights.commonTabCard('Positive Sentiments').eq(1).scrollIntoView().click();
    customerInsights.tabCaseCountLabel('Positive Sentiments').then(($count) => {
      const caseCount = $count.text();
      if (caseCount !== '0signals') {
        cy.waitForLoaders();
        consolePage.groupedByDropdown().eq(0).click();
        cy.contains('Priority').click();
        cy.waitForLoaders();
        consolePage.caseCard().eq(0).click();
        cy.waitForLoaders();
        supportHub.baseContainer().should('be.visible');
        supportHub.closeButton().click();
      } else {
        customerInsights.insightSubTabDataViewContainer().should('contain', 'No cases found');
      }
    });
  });

  /**
   * C476
   * - Navigate to the Insight page and click on Overview tab
   * - If Overview tab count is >0, Click on any graphs to see the Case lists pop up shows and check its features like Sort By Switch Sort Direction and Export to CSV
   */
  it('C476: Customers page - verify the ability to view,sort and download case list', { tags: ['Customers'] }, () => {
    cy.waitForLoaders();
    // Navigate to the Insights Page
    customerInsights.insightsTab().click();
    cy.waitForLoaders();
    customerInsights.commonTabCard('Overview').eq(1).scrollIntoView().click({ force: true });
    customerInsights.tabCaseCountLabel('Overview').then(($count) => {
      const caseCount = $count.text();
      if (caseCount !== '0cases') {
        cy.waitForLoaders();
        customerInsights.insightTabDataViewContainer().then(($parentDiv) => {
          if ($parentDiv.find('[data-testid^="chartWrapper-_support_customer_insights"]').length > 0) {
            customerInsights.overviewTabCommonChartPoint().eq(0).click();
            cy.waitForLoaders();
            customerInsights.commonCasesPopup().should('be.visible');
            customerInsights.commonCasesPopupDownloadButton().should('exist');
            customerInsights
              .commonCasesPopupListsCaseIdLabel()
              .eq(0)
              .then((caseId) => {
                const beforeSortCaseId = caseId.text();
                customerInsights.commonCasesPopupSortButton().scrollIntoView().click();
                cy.waitForLoaders();
                customerInsights.commonCasesPopupListsCaseIdLabel().eq(0).invoke('text').should('not.contain', beforeSortCaseId);
              });
          }
        });
      }
    });
  });
});
