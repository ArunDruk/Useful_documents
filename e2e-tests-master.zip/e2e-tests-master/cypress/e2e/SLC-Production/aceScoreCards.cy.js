import { urlHelpers } from '../../utils';
import { acePage, apiHelpers, commonElements } from '../../pages';

describe('QA Scorecard Production Tests', () => {
  before(function beforeHook() {
    cy.loginWithOktaUI();
    apiHelpers.isModuleEnabled('qaScorecards').then((isEnabled) => {
      if (!isEnabled) this.skip();
    });
    cy.visit(urlHelpers.aceQaScorecards);
    cy.waitForLoaders();
    commonElements.clickWelcomePageGetStartedButton();
  });

  /**
   * Open the QA Scorecard page.
   * Validate the visibility of the Current, Drafts & Previous Versions tabs.
   */
  it('C9320: Validate the display of QA Scorecards page', { tags: ['Ace', 'staging'] }, () => {
    acePage.currentDraftTab().should('be.visible').invoke('text').should('be.equal', 'Current');
    acePage.draftsTab().should('be.visible').invoke('text').should('be.equal', 'Drafts');
    acePage.previousVersionsTab().should('be.visible').invoke('text').should('be.equal', 'Previous Versions');
  });
});
