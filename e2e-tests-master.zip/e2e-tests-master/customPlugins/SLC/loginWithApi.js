const getSessionCookie = (cookies) =>
  Array.isArray(cookies)
    ? cookies
        .filter((cookie) => cookie.includes('supportlogic_session'))
        .map((cookie) => getSessionCookie(cookie))
        .join('; ')
    : cookies
        .split(';')
        .filter((cookie) => cookie.includes('supportlogic_session'))
        .join('; ');

const loginWithApi = async (baseUrl, email, password) => {
  const response = await fetch(`${baseUrl}/login/local`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: `email=${encodeURIComponent(email)}&passwd=${encodeURIComponent(password)}`,
    redirect: 'manual',
    credentials: 'include',
  });

  if (response.status !== 302 && response.status !== 307) {
    throw new Error(`HTTP error! Status: ${response.status}`);
  }
  const location = response.headers.get('location');
  const sessionCookie = getSessionCookie(response.headers.get('set-cookie'));

  const authSuccessResponse = await fetch(baseUrl + location, { headers: { Cookie: sessionCookie }, redirect: 'manual', credentials: 'include' });
  const finalSessionCookie = getSessionCookie(authSuccessResponse.headers.get('set-cookie')).split(',');

  return finalSessionCookie.length === 1 ? finalSessionCookie : finalSessionCookie[1].trim();
};

module.exports = loginWithApi;
