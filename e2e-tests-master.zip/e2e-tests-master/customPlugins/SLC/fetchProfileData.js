const fs = require('fs/promises');

const fetchProfileData = async (baseUrl, sessionCookie, dataStoreFilePath) => {
  const response = await fetch(`${baseUrl}/api/users/profile`, {
    headers: { Cookie: sessionCookie },
    credentials: 'include',
  });

  const json = await response.json();

  await fs.writeFile(dataStoreFilePath, JSON.stringify({ profileData: json }, null, 2));
};

module.exports = fetchProfileData;
