const fs = require('fs/promises');
const fsNormal = require('fs');

const removeProfileData = async (dataStoreFilePath) => {
  if (fsNormal.existsSync(dataStoreFilePath)) await fs.unlink(dataStoreFilePath);
};

module.exports = removeProfileData;
