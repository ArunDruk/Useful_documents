const pages = [
  // Workspace
  'summary',
  'console',
  'alerts',
  'myAgents',
  'myCustomers',
  'cases',

  // escalation management
  'escalationsBoard',
  'escalationsReport',

  // case assignment
  'caseAssignment',
  'shiftManagement',
  'virtualQueues',

  // Quality monitoring
  'manualQA',
  'qaScorecards',

  // Agent management
  'agents',
  'virtualTeams',

  // Customer management
  'customerBoard',
  'customerInsights',
  'virtualAccounts',

  // Analytics
  'operationalMetrics',
  'experientialMetrics',
  'kpiMetrics',
  'metrics',
  'trends',
  'topics',
  'sentiments',

  // Agent workspaces

  // Workspace
  'agentCases',
  'agentBacklogList',
  'agentInsights',
  'agentSubscriptions',
];

const now = new Date();

const onboardUser = async (baseUrl, sessionCookie) =>
  fetch(`${baseUrl}/api/users/dashboard_settings`, {
    method: 'PUT',
    mode: 'cors',
    headers: {
      accept: '*/*',
      'accept-language': 'en-US,en',
      'content-type': 'application/json',
      'sec-ch-ua': '"Not.A/Brand";v="8", "Chromium";v="114", "Brave";v="114"',
      'sec-ch-ua-mobile': '?0',
      'sec-ch-ua-platform': '"Windows"',
      'sec-fetch-dest': 'empty',
      'sec-fetch-mode': 'cors',
      'sec-fetch-site': 'same-origin',
      'sec-gpc': '1',
      Cookie: sessionCookie,
    },
    credentials: 'include',
    referrerPolicy: 'strict-origin-when-cross-origin',
    body: JSON.stringify({
      dashboardName: 'support',
      settingsKey: 'modules_onboarding',
      settingsSubKey: null,
      settingsValue: pages.reduce((acc, page) => ({ ...acc, [page]: now }), {}),
      replace: false,
    }),
  });

module.exports = onboardUser;
