/* eslint-disable import/no-extraneous-dependencies */
/* eslint-disable no-console */
/* eslint-disable no-await-in-loop */
/*  */
const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs');
const FileSystem = require('fs');
const csvToJson = require('convert-csv-to-json');

require('dotenv').config();

//  Please declare fileInputName and fileOutptName in .env file in order to run the code.
const fileInputName = process.env.FILE_INPUT_NAME || './cypress/sfdcTicketDetails.csv';
const fileOutputName = process.env.FILE_OUTPUT_NAME || 'myOutputFile.json';
//  form will pass all the necessary details needed to login to sfdc crm.
const form = new FormData();
form.append('username', process.env.CYPRESS_EMAIL || 'NA');
form.append('password', process.env.CYPRESS_SFDC_PASSWORD || 'NA');
form.append('grant_type', 'password');
form.append('client_secret', process.env.CLIENT_SECRET || 'NA');
form.append('client_id', process.env.CLIENT_ID || 'NA');

csvToJson.fieldDelimiter(',').formatValueByType().generateJsonFileFromCsv(fileInputName, fileOutputName);

let dataLogin = {};
async function caseToken() {
  //    This function helps to get the specific sfdc instance url and access token.
  const url = 'https://login.salesforce.com/services/oauth2/token?';
  const headersCase = {
    'Content-Type': 'application/x-www-form-urlencoded',
  };
  const responseLogin = await axios.post(url, form, headersCase);
  dataLogin = responseLogin.data;
  return dataLogin;
}
async function caseCreationStatus(res) {
  const polo = [];
  const token = res.access_token; // we need to pass access token to authenticate as the logged in user.
  const headers = {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${token}`,
  };
  const config = JSON.parse(fs.readFileSync(fileOutputName));
  const urlCaseCreation = `${res.instance_url}/services/data/v41.0/sobjects/Case`;
  for (let i = 0; i < config.length; i += 1) {
    const responseOfDataCreation = await axios.post(urlCaseCreation, config[i], { headers });
    polo.push(responseOfDataCreation.data); // saving the newly created ticket's id to delete them in future.
  }
  FileSystem.writeFile('file.json', JSON.stringify(polo), (error) => {
    if (error) throw error;

    // return response2;
  });
}

async function callFunctionToCreateCase() {
  await caseToken()
    .then((response) => {
      caseCreationStatus(response);
    })
    .catch(() => {
      console.error('Error happened');
    });
}
module.exports = { callFunctionToCreateCase };
