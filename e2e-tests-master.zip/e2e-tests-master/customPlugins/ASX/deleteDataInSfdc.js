/* eslint-disable import/no-extraneous-dependencies */
/* eslint-disable no-console */
/* eslint-disable no-await-in-loop */

const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs');

require('dotenv').config();

//  form will pass all the necessary details needed to login to sfdc crm.
const form = new FormData();
form.append('username', process.env.CYPRESS_EMAIL || 'NA');
form.append('password', process.env.CYPRESS_SFDC_PASSWORD || 'NA');
form.append('grant_type', 'password');
form.append('client_secret', process.env.CLIENT_SECRET || 'NA');
form.append('client_id', process.env.CLIENT_ID || 'NA');

// method which fetches the token after login and pass it so that we can authenticate and delete the created tickets.
async function authenticationTokenGenerationAndTicketDeletion() {
  //    This function helps to get the specific sfdc instance url and access token.
  const url = 'https://login.salesforce.com/services/oauth2/token?';
  const headersCase = {
    'Content-Type': 'application/x-www-form-urlencoded',
  };
  const responseLogin = await axios.post(url, form, headersCase);
  const dataLogin = responseLogin.data;
  const configFileRead = JSON.parse(fs.readFileSync('file.json'));
  const tokenLogin = dataLogin.access_token;
  const headers1 = {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${tokenLogin}`,
  };
  for (let i = 0; i < configFileRead.length; i += 1) {
    const urlForCaseDeletion = `${dataLogin.instance_url}/services/data/v57.0/composite/sobjects?ids=${configFileRead[i].id}`;
    const response3 = await axios.delete(urlForCaseDeletion, {
      headers: headers1,
    });
    console.log(response3.data);
  }
}

module.exports = { authenticationTokenGenerationAndTicketDeletion };
